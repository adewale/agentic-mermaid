import { readFileSync, writeFileSync } from 'node:fs'
import { renderMermaidSVGWithReceipt } from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-native-elk-df133-20261108/FIDELITY-CASES.json','utf8')).selected.filter((c:any)=>['features:flowchart:nesting-parallel-unicode','features:state:nesting-reciprocal-alias'].includes(c.id))
const phase=process.argv[2]??'before',rows=[]
for(const c of cases) for(const backend of ['elk','agentic','trinity']) {
 try { const p=renderMermaidSVGWithReceipt(c.source,{...c.renderOptions,graphLayout:{backend,fallback:'none'},embedFontImport:false});JSON.stringify(p.receipt);const stem=phase+'-'+c.family+'-'+backend;writeFileSync(import.meta.dir+'/'+stem+'.svg',p.svg);writeFileSync(import.meta.dir+'/'+stem+'.receipt.json',JSON.stringify(p.receipt,null,2)+'\n');rows.push({id:c.id,backend,delivery:'returned',proof:p.receipt.layoutCertification?.status,stem}) }
 catch(e:any){rows.push({id:c.id,backend,delivery:e.code==='GRAPH_LAYOUT_UNSUPPORTED'?'unsupported':'error',code:e.code,error:String(e)})}
}
writeFileSync(import.meta.dir+'/'+phase+'.json',JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows,null,2))
