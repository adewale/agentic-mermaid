import {readFileSync,writeFileSync,mkdirSync,appendFileSync} from 'node:fs'
import {join} from 'node:path'
import {runSerialJob} from '/tmp/pr449-week-comparison-20261101/trident-native-elk-df133-20261108/kit/execution.mjs'
import {portableSummary} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/report.ts'
import {median} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/statistics.ts'
const p=import.meta.dir,original='/tmp/pr449-week-comparison-20261101/trident-native-elk-df133-20261108'
const identity=JSON.parse(readFileSync(join(original,'IDENTITY-FINAL.json'),'utf8')),c=JSON.parse(readFileSync(join(original,'CASES.json'),'utf8')).selected.find((c:any)=>c.id==='scaling:class:128')
if(!c)throw Error('Missing frozen original case')
process.env.AGENTIC_MERMAID_ELK_CACHE='1';process.env.MERMAID_REFERENCE_DIR='/tmp/pr449-main-integration-20261029-762'
const plan={case:c,artifact:identity,cache:1,rounds:5,samples:31,minSampleMs:2,modes:['warm'],replicas:['A0','A1','B'],maximumControlSpread:.25,scope:'Focused qualification of observed cached Class128 repeat loss. Unchanged Trident compiled warm worker; both original tracks. No cold/resource measurements in this supplement; missing rows remain missing. Same frozen public artifact. No profiler/build/browser/compression overlap. Control calibration is per backend/options, not a Native/ELK ratio.'}
writeFileSync(join(p,'PLAN.json'),JSON.stringify(plan,null,2)+'\n');for(const s of ['jobs','results','svg','failures'])mkdirSync(join(p,s),{recursive:true})
const results:any[]=[]
for(let round=1;round<=5;round++)for(const replica of ['A0','A1','B'])for(const backend of (round+['A0','A1','B'].indexOf(replica))%2?['agentic','elk']:['elk','agentic']){
 const stem=`r${round}-${replica}-${backend}`,testCase={...c,renderOptions:{...c.renderOptions,graphLayout:{backend,fallback:'none'}}},job={artifact:identity.artifact.artifact,testCase,mode:'warm',samples:31,minSampleMs:2,workerTimeoutMs:120000,round,replica,sample:0,fullEvidence:replica==='B',diagnosticFile:join(p,'failures',stem+'.json'),...(replica==='B'?{svgFile:join(p,'svg',stem+'.svg')}:{})}
 writeFileSync(join(p,'jobs',stem+'.json'),JSON.stringify(job,null,2)+'\n')
 try{const result=await runSerialJob(job,'node');results.push({backend,result});writeFileSync(join(p,'results',stem+'.json'),JSON.stringify(result,null,2)+'\n');appendFileSync(join(p,'results.jsonl'),JSON.stringify({backend,result})+'\n');console.log(JSON.stringify({round,replica,backend,status:result.status,repeatMs:median(result.tracks['warm-repeat']??[])}))}
 catch(e){appendFileSync(join(p,'errors.jsonl'),JSON.stringify({backend,job,error:String(e)})+'\n');throw e}
}
for(const backend of ['agentic','elk']){const v=results.filter(r=>r.backend===backend).map(r=>r.result),summary=portableSummary([c],v,{rounds:5,samples:31,coldSamples:20,maximumControlSpread:.25});writeFileSync(join(p,'SUMMARY-'+backend+'.json'),JSON.stringify(summary,null,2)+'\n')}
writeFileSync(join(p,'COMPLETED.json'),JSON.stringify({workers:results.length,scope:plan.scope},null,2)+'\n')
