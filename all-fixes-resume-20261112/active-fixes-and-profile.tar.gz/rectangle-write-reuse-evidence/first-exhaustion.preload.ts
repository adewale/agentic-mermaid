import{plugin}from'bun';import{readFileSync}from'node:fs'
plugin({name:'actual-first-exhausted-owner',setup(build){
 build.onLoad({filter:/rectangle-write-reuse-candidate\/src\/scene\/svg-writer\.ts$/},args=>{
 let s=readFileSync(args.path,'utf8').replace("    if (!Number.isSafeInteger(count) || count < 0 || count > maxOperations - operations) { exhausted = true; return false }", "    if (!Number.isSafeInteger(count) || count < 0 || count > maxOperations - operations) { globalThis.__firstMeter.firstFailure ??= { operations, count, stack: new Error().stack }; exhausted = true; return false }")
 s=s.replace('    operations += count\n    return true','    if (count >= 1000) globalThis.__firstMeter.large.push({operations,count,stack:new Error().stack}); operations += count\n    return true')
 return{loader:'ts',contents:s}
 })
 build.onLoad({filter:/rectangle-write-reuse-candidate\/src\/scene\/native-paint-emission\.ts$/},args=>{
 let s=readFileSync(args.path,'utf8').replace('      let actualTextPaint: SvgTextPaintWrite | undefined','      globalThis.__firstMeter.beforeFirstObserve ??= work.operations(); let actualTextPaint: SvgTextPaintWrite | undefined')
 return{loader:'ts',contents:s}
 })
}})
