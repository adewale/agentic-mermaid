import{plugin}from'bun';import{readFileSync}from'node:fs'
plugin({name:'closed-leaf-owning-phase-bound',setup(build){build.onLoad({filter:/(?:chain-proof-candidate|rectangle-write-reuse-candidate)\/src\/scene\/native-paint-emission\.ts$/},args=>{
let s=readFileSync(args.path,'utf8')
s=s.replace("      let captured: Leaf | undefined\n      try { captured = copy", "      const bucket = globalThis.__leafPhases; let phaseBefore = work.operations(); const phase = name => { const row = bucket.costs[name] ??= { calls: 0, operations: 0 }; row.calls++; row.operations += work.operations() - phaseBefore; phaseBefore = work.operations(); if (work.exhausted() && !bucket.firstFailure) bucket.firstFailure = { phase: name, kind: node.kind, id: node.id, operations: phaseBefore }; };\n      let captured: Leaf | undefined\n      try { captured = copy")
s=s.replace("      if (!captured) return { node, paintNode: node, ...serialize(node), conditional: true }", "      phase('copy'); if (!captured) return { node, paintNode: node, ...serialize(node), conditional: true }")
s=s.replace("      const { svg, xmlWrite } = serialize(captured, sink)", "      phase('prewrite'); const { svg, xmlWrite } = serialize(captured, sink); phase('write')")
s=s.replace("      const textPaintCandidate = textPaintReceived", "      phase('written-geometry-paint'); const textPaintCandidate = textPaintReceived")
s=s.replace("      // An issued inspection cannot be resealed", "      globalThis.__leafPhases.finishStart = { operations: work.operations(), exhausted: work.exhausted() };\n      // An issued inspection cannot be resealed")
s=s.replace("      const checkedContext = emissionContext.finish(header)", "      globalThis.__leafPhases.beforeContext = { operations: work.operations(), exhausted: work.exhausted() }; const checkedContext = emissionContext.finish(header); globalThis.__leafPhases.afterContext = { operations: work.operations(), exhausted: work.exhausted() }")
s=s.replace("      if (hasMarkedConnector) {\n        const verified", "      if (hasMarkedConnector) { globalThis.__leafPhases.beforeXML = { operations: work.operations(), exhausted: work.exhausted() };\n        const verified")
s=s.replace("        if (!verified) uncertain = true", "        if (!verified) uncertain = true; globalThis.__leafPhases.afterXML = { operations: work.operations(), exhausted: work.exhausted() }")
return{loader:'ts',contents:s}
})}})
