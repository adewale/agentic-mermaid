import{readFileSync}from'node:fs'
const c=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-marker-paint-matched/MEASUREMENT-CASES.json','utf8')).find(c=>c.id==='diagnostic:chain300')
for(const root of ['chain-proof-candidate','rectangle-write-reuse-candidate']){
 globalThis.__leafPhases={costs:{}}
 const api=await import(`../${root}/src/index.ts`)
 const result=api.renderMermaidSVGWithReceipt(c.source,{...c.renderOptions,graphLayout:{backend:'agentic',fallback:'none'}})
 console.log(JSON.stringify({root,phases:globalThis.__leafPhases,proof:result.receipt.layoutCertification.status,checks:result.receipt.layoutCertification.checks}))
}
