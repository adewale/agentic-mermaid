import{readFileSync,writeFileSync}from'node:fs'
import{performance}from'node:perf_hooks'
const api=await import('../chain-proof-candidate/dist/index.js')
const source=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-e0cac-focused/profile-current.job.json','utf8')).source
const options={graphLayout:{backend:'agentic',fallback:'none'}}
for(let i=0;i<2;i++)JSON.stringify(api.renderMermaidSVGWithReceipt(source,options))
const original=JSON.stringify,now=performance.now.bind(performance)
let calls=0,milliseconds=0,bytes=0,maxBytes=0
JSON.stringify=function(value,...rest){
 const tracked=Array.isArray(value)&&value.length===4&&value[0]&&typeof value[0]==='object'&&value[0].geometry&&Object.hasOwn(value[0],'orient')&&Array.isArray(value[3])&&value[3].length===4
 const start=tracked?now():0
 const result=Reflect.apply(original,this,[value,...rest])
 if(tracked){milliseconds+=now()-start;calls++;bytes+=result.length;maxBytes=Math.max(maxBytes,result.length)}
 return result
}
let result
try{result=api.renderMermaidSVGWithReceipt(source,options);JSON.stringify(result)}finally{JSON.stringify=original}
const record={scope:'Oneactualemittedd4Native100warmcache0WithReceiptfullyconsumedafter2warmups;JSONsiteattributiononly,instrumentedN1notbenchmarkratio;excludesargument-spread/matrix-sliceallocationbeforeJSONcall.',calls,JSONMilliseconds:milliseconds,serializedUTF16Units:bytes,largestStringUnits:maxBytes,proof:result.receipt.layoutCertification.status,checks:result.receipt.layoutCertification.checks}
writeFileSync(new URL('JSON-BOUND.json',import.meta.url),original(record,null,2));console.log(original(record))
