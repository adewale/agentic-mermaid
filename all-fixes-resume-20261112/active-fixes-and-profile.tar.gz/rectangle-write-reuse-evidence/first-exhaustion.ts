import{readFileSync,writeFileSync}from'node:fs'
globalThis.__firstMeter={large:[]}
const api=await import('../rectangle-write-reuse-candidate/src/index.ts'),c=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-marker-paint-matched/MEASUREMENT-CASES.json','utf8')).find(c=>c.id==='diagnostic:chain300')
const product=api.renderMermaidSVGWithReceipt(c.source,{...c.renderOptions,graphLayout:{backend:'agentic',fallback:'none'}})
writeFileSync(new URL('FIRST-EXHAUSTION.json',import.meta.url),JSON.stringify({meter:globalThis.__firstMeter,proof:product.receipt.layoutCertification},null,2))
console.log(JSON.stringify({beforeFirstObserve:globalThis.__firstMeter.beforeFirstObserve,firstFailure:globalThis.__firstMeter.firstFailure,large:globalThis.__firstMeter.large.map(x=>({operations:x.operations,count:x.count,caller:x.stack.split('\n')[2]}))}))
