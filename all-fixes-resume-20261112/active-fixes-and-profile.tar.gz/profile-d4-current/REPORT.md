# Current d4 warm profile

Ten fully consumed public Native100 renders, cache off; sampled self and inclusive times stay separate. Inspector/GC overhead is recorded separately; nested inclusive totals must not be summed. These are profile costs, not a latency comparison.

| Function | Source | Self total / mean ms | Inclusive total / mean ms |
|---|---|---:|---:|
| copyInner | src/scene/native-paint-emission.ts:228 | 105.743 / 10.574 | 143.721 / 14.372 |
| include | src/scene/bounds.ts:358 | 80.545 / 8.055 | 93.230 / 9.323 |
| assessLayoutGeometry | src/layout-rubric.ts:493 | 48.696 / 4.870 | 96.321 / 9.632 |
| copy | src/scene/native-paint-emission.ts:410 | 43.848 / 4.385 | 154.421 / 15.442 |
| certifyNativePaint | src/scene/paint-certification.ts:1435 | 27.921 / 2.792 | 219.231 / 21.923 |

The marker-region include function serializes the full marker into a repaint equality key per occurrence. Any removal must preserve actual resource/orientation/unit-scale/transform equality; paint equality alone is insufficient. Copy/paint work is being removed at its actual producer, with generic fallbacks retained. No speedup estimate is asserted from these bounds.
