import type { SceneNode, SceneDoc, Geometry, ShapeMark } from './ir.ts'
import type { WrittenCompoundInput } from './written-geometry.ts'
export const sceneObserverCreate = Object.create, sceneObserverWeakMap = WeakMap
export const sceneObserverGet = WeakMap.prototype.get, sceneObserverSet = WeakMap.prototype.set, sceneObserverDelete = WeakMap.prototype.delete, sceneObserverApply = Reflect.apply
export const groupObserverHas = WeakSet.prototype.has, groupObserverAdd = WeakSet.prototype.add, groupObserverApply = Reflect.apply
export const groupFreeze = Object.freeze
export interface GroupComposition {
  readonly valid: boolean
  invalidate(): void
  beforeMap(children: unknown): void
  beforeSpread(mapped: unknown): void
  beforeJoin(parts: unknown): void
  indent(svg: string, spaces: number): string
}
/** First-write data belongs to one admission transaction, not a global node
 * proof cache. A later request cannot borrow an earlier cached serialization. */
declare const sceneWriteObserver: unique symbol
export interface SceneSerializationObserver { readonly [sceneWriteObserver]: true }
export type SceneWriteCallback = (node: SceneNode, source: Geometry, served: Geometry | undefined, svg: string) => void
export interface SceneWriteRecorder {
  string(node: Exclude<SceneNode, { kind: 'group' }>, svg: string): void
  root(scene: SceneDoc): { readonly composition: GroupComposition; underlay(svg: string): void; complete(sealed: boolean): void } | undefined
  reserve(): boolean
  reserveProjection(operations: number): boolean
  document(node: Extract<SceneNode, { kind: 'document' }>, svg: string): void
  connector(node: ConnectorNode): void
  group(node: Extract<SceneNode, { kind: 'group' }>): { readonly composition: GroupComposition | undefined; complete(sealed: boolean): void } | undefined
  hint(node: SceneNode): boolean
  compound(node: ShapeMark): WrittenCompoundInput | undefined
  compoundRecord(node: ShapeMark, input: WrittenCompoundInput, svg: string): void
  rectangle(node: ShapeMark): boolean
  rectangleRecord(node: ShapeMark, source: Geometry, served: Geometry | undefined, attributes: Readonly<Record<string, string>> | undefined, svg: string): void
  contextLeaf(node: Exclude<SceneNode, { kind: 'group' }>, svg: string): void
  leaf(node: Exclude<SceneNode, { kind: 'group' }>, svg: string): void
  record: SceneWriteCallback
}
// Explicit transaction tokens identify recorders; there is no active global
// observer, and callers cannot invoke or substitute a recorder callback.
const actualSceneObservers = new WeakSet<object>()
const sceneWriteObservers = new WeakMap<SceneSerializationObserver, SceneWriteRecorder>()
export function readSceneWriteObserver(observer: SceneSerializationObserver): SceneWriteRecorder | undefined { return groupObserverApply(groupObserverHas, actualSceneObservers, [observer]) ? sceneObserverApply(sceneObserverGet, sceneWriteObservers, [observer]) : sceneWriteObservers.get(observer) }
const backendWriteObservers = new WeakMap<object, SceneSerializationObserver>()
export function sceneBackendWriteObserver(context: object): SceneSerializationObserver | undefined { return sceneObserverApply(sceneObserverGet, backendWriteObservers, [context]) }
export function sceneDocumentComposition(observer: SceneSerializationObserver, scene: SceneDoc) { return sceneObserverApply(sceneObserverGet, sceneWriteObservers, [observer])?.root(scene) }
export type ConnectorNode = Extract<SceneNode, { kind: 'connector' }>

// Issuing this observation token does not admit a node or issue a Scene receipt.
// Only the Scene capture owner can complete its private CapturedSceneWrites.
export function newSceneWriteObserver(actualBackendWrite: boolean): SceneSerializationObserver {
  const observe = (actualBackendWrite ? groupFreeze(sceneObserverCreate(null)) : Object.freeze(Object.create(null))) as SceneSerializationObserver
  if (actualBackendWrite) groupObserverApply(groupObserverAdd, actualSceneObservers, [observe])
  return observe
}
export function recordSceneWriteObserver(observe: SceneSerializationObserver, recorder: SceneWriteRecorder, actualBackendWrite: boolean): void {
  if (actualBackendWrite) sceneObserverApply(sceneObserverSet, sceneWriteObservers, [observe, groupFreeze(recorder)])
  else sceneWriteObservers.set(observe, recorder)
}
export function setSceneBackendWriteObserver(context: object, observe: SceneSerializationObserver): void { sceneObserverApply(sceneObserverSet, backendWriteObservers, [context, observe]) }
export function deleteSceneBackendWriteObserver(context: object): void { sceneObserverApply(sceneObserverDelete, backendWriteObservers, [context]) }
