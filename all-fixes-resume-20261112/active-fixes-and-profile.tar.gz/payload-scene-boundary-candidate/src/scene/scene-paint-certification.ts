import type { RenderedLayout } from '../agent/types.ts'
import type { SceneDoc } from './ir.ts'
import type { SceneWriteReceipt } from './scene-write-capture.ts'
import { inspectScenePaintGeometry } from './scene-inspection.ts'
import { certifyNativePaint, type PaintLayoutCertification } from './paint-certification.ts'

export function certifyScenePaint(scene: SceneDoc, projection?: Pick<RenderedLayout, 'nodes' | 'labels'>, options: { outputSupported?: boolean; sceneWriteReceipt?: SceneWriteReceipt } = {}): PaintLayoutCertification {
  return certifyNativePaint(scene, inspectScenePaintGeometry(scene, options.sceneWriteReceipt), projection, options)
}

