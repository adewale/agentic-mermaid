import type { JsonSchema } from '../shared/schema-validation.ts'
import { styleOptionValidationRoot } from './style-registry.ts'

// The selected style fragment resolves to its canonical schema at the existing
// Style acquisition point; ordinary fields never demand that implementation.
export const STYLE_OPTION_SCHEMA = { $ref: '#/$defs/styleOption' } as const
export function renderOptionSchemaRoot(field: string, root: JsonSchema): JsonSchema {
  return field === 'style' ? styleOptionValidationRoot() : root
}
