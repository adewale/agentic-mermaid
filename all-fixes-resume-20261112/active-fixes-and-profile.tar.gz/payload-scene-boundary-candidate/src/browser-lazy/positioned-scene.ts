import { positionedSceneRuntime, sceneBackendLoaded } from './scene-backend.ts'
import type { FamilyLayoutResult } from '../agent/families.ts'
import type { ResolvedRenderRequest } from '../render-contract.ts'
import type { PaintLayoutCertification } from '../scene/paint-certification.ts'

// An unacquired Scene owner has no retained transactions. All operations that
// create/consume one require the already-selected genuine SPI, not a stand-in.
export function hasRetainedPositionedScene(layout: FamilyLayoutResult, request: ResolvedRenderRequest): boolean {
  return sceneBackendLoaded() && positionedSceneRuntime().hasRetainedPositionedScene(layout, request)
}
export function retainedPositionedScene(request: ResolvedRenderRequest, layout: FamilyLayoutResult) {
  return positionedSceneRuntime().retainedPositionedScene(request, layout)
}
export function actualPositionedSceneWriteEligible(request: ResolvedRenderRequest): boolean {
  return positionedSceneRuntime().actualPositionedSceneWriteEligible(request)
}
export function beginPositionedBackendEmission(request: ResolvedRenderRequest, layout: FamilyLayoutResult, context: object, proof: PaintLayoutCertification): boolean {
  return positionedSceneRuntime().beginPositionedBackendEmission(request, layout, context, proof)
}
export function finishPositionedBackendEmission(request: ResolvedRenderRequest, layout: FamilyLayoutResult, result: { kind: 'complete'; proof: PaintLayoutCertification } | { kind: 'abort' }) {
  return positionedSceneRuntime().finishPositionedBackendEmission(request, layout, result)
}
export function positionedScenePaintCertification(request: ResolvedRenderRequest, layout: FamilyLayoutResult): PaintLayoutCertification {
  return positionedSceneRuntime().positionedScenePaintCertification(request, layout)
}
