import { styleSpecJsonSchema } from './scene/style-spec.ts'
import { deepFreeze } from './shared/plain-data.ts'
import type { JsonSchema } from './shared/schema-validation.ts'
type JsonSchemaNode = JsonSchema

const STYLE_SPEC_SCHEMA = (() => {
  const styleSchema = styleSpecJsonSchema() as Record<string, unknown>
  const definitions = styleSchema.$defs as Record<string, Record<string, unknown>> | undefined
  const expandLocalReferences = (value: unknown): unknown => {
    if (Array.isArray(value)) return value.map(expandLocalReferences)
    if (value === null || typeof value !== 'object') return value
    const record = value as Record<string, unknown>
    const reference = record.$ref
    if (typeof reference === 'string' && reference.startsWith('#/$defs/')) {
      const definition = definitions?.[reference.slice('#/$defs/'.length)]
      if (!definition) throw new Error(`StyleSpec schema has unresolved local reference ${reference}`)
      return expandLocalReferences(definition)
    }
    return Object.fromEntries(Object.entries(record)
      .filter(([key]) => key !== '$defs')
      .map(([key, child]) => [key, expandLocalReferences(child)]))
  }
  const { $schema: _dialect, $id: _id, title: _title, ...fragment } = styleSchema
  return expandLocalReferences(fragment) as Record<string, unknown>
})()

const STYLE_INPUT_SCHEMA = {
  anyOf: [
    { type: 'string', description: 'Registered Style or Palette name.' },
    STYLE_SPEC_SCHEMA,
  ],
  'x-agentic-mermaid-validation-expectation': 'a registered Style name or StyleSpec',
} as const satisfies JsonSchemaNode

export const STYLE_OPTION_SCHEMA = {
  anyOf: [
    STYLE_INPUT_SCHEMA,
    { type: 'array', items: STYLE_INPUT_SCHEMA, description: 'Style stack merged from left to right.' },
  ],
  description: 'A registered name, inline StyleSpec, or left-to-right stack of either.',
  'x-agentic-mermaid-runtime-validator': 'styleInput',
} as const satisfies JsonSchemaNode

// The async style provider owns this exact closed validation root. Schema
// consumers outside that graph continue using the full canonical fragment.
export const STYLE_OPTION_VALIDATION_ROOT = deepFreeze({ $defs: { styleOption: STYLE_OPTION_SCHEMA } })
export function renderOptionSchemaRoot(_field: string, root: JsonSchemaNode): JsonSchemaNode { return root }
