from pathlib import Path
import re
r=Path('/dev/shm/pr449-four-final-20261111/payload-scene-boundary-candidate');p=r/'src/parser.ts';s=p.read_text();state_a=s.index('// ============================================================================\n// State diagram parser');state_z=s.index('// ============================================================================\n// Shared utilities',state_a);state=s[state_a:state_z];flow=s[:state_a]+s[state_z:]
# Keep one graph work-limit/count owner for both grammars, not duplicate state.
a=flow.index('const graphContainerCounts =');z=flow.index('\nfunction parseFlowchart(',a);work=flow[a:z].replace('function assertGraphNodeInsertion','export function assertGraphNodeInsertion');work+="\nexport function retainGraphContainerCount(graph: MermaidGraph, count: number): void { graphContainerCounts.set(graph, count) }\n";(r/'src/graph-parser-work.ts').write_text("import type { MermaidGraph } from './types.ts'\nimport { assertDiagramWorkLimit } from './shared/diagram-limits.ts'\n\n"+work+'\n');flow=flow[:a]+flow[z:]
for name,t in [('flow',flow),('state',state)]:
 t=re.sub(r'graphContainerCounts\.set\(graph, ([^)]+)\)',r'retainGraphContainerCount(graph, \1)',t)
 if name=='flow':flow=t
 else:state=t
# The same authored/decoded source fallback and Flow grammar are used by the
# public generic entry and the already-selected async Flow family adapter.
a=flow.index('export function parseFlowchartRenderSource(');z=flow.index('\nexport function parseMermaid(',a);render=flow[a:z];render=render.replace('export function parseFlowchartRenderSource(authoredFamilyText:', 'export function parseFlowchartRenderSourceWithParser(parse: (text: string) => MermaidGraph, authoredFamilyText:').replace('parseMermaid(', 'parse(');flow=flow[:a]+render+flow[z:];flow=flow.replace('export function parseMermaid(text: string): MermaidGraph {','export interface StateGraphGrammar {\n  lines(rawLines: string[]): string[]\n  parse(lines: string[]): MermaidGraph\n}\n\nexport function parseGraphSource(text: string, stateGrammar?: StateGraphGrammar): MermaidGraph {')
old="scanStateComments(rawLines).filter((line, index, scanned) => line.noteBody\n      || (line.text.length > 0 && (!line.text.startsWith('//') || scanned[index - 1]?.openQuote === true))).map(line => line.text)";assert old in flow;flow=flow.replace(old,'stateGrammar!.lines(rawLines)').replace('return parseStateDiagram(lines)','return stateGrammar!.parse(lines)')
flow="import { assertGraphNodeInsertion, retainGraphContainerCount } from './graph-parser-work.ts'\n"+flow
# State owns its original grammar/preprocessing. Imports are pruned by an AST
# helper afterward; all grammar code bodies remain byte-for-byte equivalent.
imports=s[:s.index('// ============================================================================')];state="import { assertGraphNodeInsertion, retainGraphContainerCount } from './graph-parser-work.ts'\n"+imports+state+'''
export const STATE_GRAPH_GRAMMAR = {
  lines: (rawLines: string[]) => scanStateComments(rawLines).filter((line, index, scanned) => line.noteBody
    || (line.text.length > 0 && (!line.text.startsWith('//') || scanned[index - 1]?.openQuote === true))).map(line => line.text),
  parse: parseStateDiagram,
}
'''
# Keep the original public/generic parser and helper export surface intact.
p.write_text('''import { parseGraphSource, parseFlowchartRenderSourceWithParser } from './parser-flowchart.ts'
import { STATE_GRAPH_GRAMMAR } from './parser-state.ts'
import type { MermaidGraph } from './types.ts'
export { parseStyleProps, splitInlineHeaderStatements, splitFlowchartStatements, emptyFlowchartGraph, flowchartStatementNotes, type FlowchartStatementNote } from './parser-flowchart.ts'

/** Public graph compatibility parsing retains both canonical grammars. */
export function parseMermaid(text: string): MermaidGraph {
  return parseGraphSource(text, STATE_GRAPH_GRAMMAR)
}
export function parseFlowchartRenderSource(authoredFamilyText: string, decodedFamilyText: string): MermaidGraph {
  return parseFlowchartRenderSourceWithParser(parseMermaid, authoredFamilyText, decodedFamilyText)
}
''');(r/'src/parser-flowchart.ts').write_text(flow);(r/'src/parser-state.ts').write_text(state)
(r/'src/flowchart-parser-entry.ts').write_text("// Synchronous SDK/complete entries retain generic graph compatibility.\nexport { parseFlowchartRenderSource } from './parser.ts'\n")
(r/'src/browser-lazy/flowchart-parser-entry.ts').write_text('''import { parseGraphSource, parseFlowchartRenderSourceWithParser } from '../parser-flowchart.ts'
/** This private adapter is used only after the async entry selected Flowchart.
 * Other graph/body adapters continue importing the generic public parser. */
export function parseFlowchartRenderSource(authoredFamilyText: string, decodedFamilyText: string) {
  return parseFlowchartRenderSourceWithParser(parseGraphSource, authoredFamilyText, decodedFamilyText)
}
''')
p=r/'src/svg-family-hooks/flowchart.ts';t=p.read_text().replace("import { parseFlowchartRenderSource } from '../parser.ts'","import { parseFlowchartRenderSource } from '../flowchart-parser-entry.ts'");p.write_text(t)
p=r/'tsup.browser-lazy.config.ts';t=p.read_text();needle="    const positionedScene = resolve(import.meta.dirname, 'src/scene/positioned-scene.ts')";assert needle in t;t=t.replace(needle,"""    const flowParser = resolve(import.meta.dirname, 'src/flowchart-parser-entry.ts')
    build.onResolve({ filter: /\\/flowchart-parser-entry\\.ts$/ }, args =>
      resolve(args.resolveDir, args.path) === flowParser
        ? { path: resolve(import.meta.dirname, 'src/browser-lazy/flowchart-parser-entry.ts') } : undefined)
"""+needle);p.write_text(t)
print('One canonical Flow/State grammar split; only selected async Flow adapter uses narrow parser entry')
