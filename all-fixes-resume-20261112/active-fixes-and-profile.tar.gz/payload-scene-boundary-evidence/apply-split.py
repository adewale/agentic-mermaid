from pathlib import Path
r=Path('/dev/shm/pr449-four-final-20261111/payload-scene-boundary-candidate');p=r/'src/scene/positioned.ts';s=p.read_text()
a=s.index('/** Resolve the transaction kind');z=s.index('/** Native crisp work');scene_methods=s[a:z]
a2=s.index('  const scene = retainedPositionedScene(request, layout)',s.index('export function positionedPaintCertification'));scene_cert=s[a2:s.rfind('\n}')]
imports='''import { isOwnedFamily } from '../experimental/owned-family.ts'
import { finalizeOwnedScene } from './owned-data.ts'
import { createSceneWriteCapture, type SceneWriteReceipt } from './serialization.ts'
import { MAX_OCCLUSION_OPERATIONS } from './native-paint-emission.ts'
import { isBuiltinDefaultBackend, isOriginalEnrolledDefaultBackend, getBackendDescriptor } from './backend.ts'
import { isOriginalSceneLowering } from './drawing.ts'
import type { FamilyLayoutResult } from '../agent/families.ts'
import type { ResolvedRenderRequest } from '../render-contract.ts'
import { resolvedFamilyRenderContextOf, resolvedRenderExecutionPlanOf } from '../render-contract.ts'
import { positionedForSceneLowering, retainedFamilyProjection } from '../positioning.ts'
import { withTextMeasurementExecution } from '../text-measurement-profile.ts'
import { admitFamilyScene } from './admission.ts'
import { sceneAssertionsEnabled } from './assertions.ts'
import { withDeferredTerminalProjections } from './deferred-terminal-projection.ts'
import type { SceneDoc } from './ir.ts'
import { certifyScenePaint, type PaintLayoutCertification } from './paint-certification.ts'
import { observeCache } from '../performance-observations.ts'

// One owner for admitted Scene transactions. The async source consumer acquires
// this module with the genuine SPI; synchronous SDK consumers import it eagerly.
interface PositionedScene { scene: SceneDoc; crossChecks: boolean; writes?: SceneWriteReceipt; pendingWrites?: ReturnType<typeof createSceneWriteCapture>; certification?: PaintLayoutCertification }
const positionedWeakGet = WeakMap.prototype.get, positionedApply = Reflect.apply
const retained = new WeakMap<FamilyLayoutResult, WeakMap<ResolvedRenderRequest, PositionedScene>>()
export function hasRetainedPositionedScene(layout: FamilyLayoutResult, request: ResolvedRenderRequest): boolean {
  return retained.get(layout)?.has(request) ?? false
}

'''
(r/'src/scene/positioned-scene.ts').write_text(imports+scene_methods+'export function positionedScenePaintCertification(request: ResolvedRenderRequest, layout: FamilyLayoutResult): PaintLayoutCertification {\n'+scene_cert+'\n}\n')
for line in ["import { finalizeOwnedScene } from './owned-data.ts'\n","import { createSceneWriteCapture, type SceneWriteReceipt } from './serialization.ts'\n","import { MAX_OCCLUSION_OPERATIONS } from './native-paint-emission.ts'\n","import { admitFamilyScene } from './admission.ts'\n","import { withDeferredTerminalProjections } from './deferred-terminal-projection.ts'\n","import type { SceneDoc } from './ir.ts'\n"]:s=s.replace(line,'')
s=s.replace('assertBackendConformance, isBuiltinDefaultBackend, isOriginalEnrolledDefaultBackend, getBackendDescriptor','assertBackendConformance, isBuiltinDefaultBackend').replace('originalNativeDrawingOf, isOriginalSceneLowering,','originalNativeDrawingOf,').replace('positionedForNativeProducer, positionedForSceneLowering, retainedFamilyProjection','positionedForNativeProducer, retainedFamilyProjection').replace('certifyNativePaint, certifyScenePaint,','certifyNativePaint,')
s=s.replace("interface PositionedScene { scene: SceneDoc; crossChecks: boolean; writes?: SceneWriteReceipt; pendingWrites?: ReturnType<typeof createSceneWriteCapture>; certification?: PaintLayoutCertification }\n",'').replace('const retained = new WeakMap<FamilyLayoutResult, WeakMap<ResolvedRenderRequest, PositionedScene>>()\n','')
s=s.replace(scene_methods,'').replace('retained.get(layout)?.has(request)','hasRetainedPositionedScene(layout, request)').replace(scene_cert,'  return positionedScenePaintCertification(request, layout)')
s="import { hasRetainedPositionedScene, positionedScenePaintCertification } from './positioned-scene.ts'\nexport { retainedPositionedScene, actualPositionedSceneWriteEligible, beginPositionedBackendEmission, finishPositionedBackendEmission } from './positioned-scene.ts'\n"+s;p.write_text(s)
f=r/'src/browser-lazy/scene-backend.ts';s=f.read_text();s+='\n/** Already-acquired real Scene transaction owner; no additional module await. */\nexport function positionedSceneRuntime(): NonNullable<typeof runtime> { return spi() }\n';f.write_text(s)
f=r/'src/browser-lazy/scene-backend-runtime.ts';s=f.read_text();s+="\nexport { retainedPositionedScene, actualPositionedSceneWriteEligible, beginPositionedBackendEmission, finishPositionedBackendEmission, positionedScenePaintCertification, hasRetainedPositionedScene } from '../scene/positioned-scene.ts'\n";f.write_text(s)
f=r/'src/browser-lazy/positioned-scene.ts';f.write_text('''import { positionedSceneRuntime, sceneBackendLoaded } from './scene-backend.ts'
import type * as Scene from '../scene/positioned-scene.ts'

// An unacquired Scene owner has no retained transactions. All operations that
// create/consume one require the already-selected genuine SPI, not a stand-in.
export function hasRetainedPositionedScene(...args: Parameters<typeof Scene.hasRetainedPositionedScene>): boolean {
  return sceneBackendLoaded() && positionedSceneRuntime().hasRetainedPositionedScene(...args)
}
'''+''.join(f"export function {n}(...args: Parameters<typeof Scene.{n}>): ReturnType<typeof Scene.{n}> {{ return positionedSceneRuntime().{n}(...args) }}\n" for n in ['retainedPositionedScene','actualPositionedSceneWriteEligible','beginPositionedBackendEmission','finishPositionedBackendEmission','positionedScenePaintCertification']))
f=r/'src/browser-lazy/scene-backend.ts';s=f.read_text()+"export function sceneBackendLoaded(): boolean { return runtime !== undefined }\n";f.write_text(s)
f=r/'tsup.browser-lazy.config.ts';s=f.read_text();needle="    const backend = resolve(import.meta.dirname, 'src/scene/backend.ts')";s=s.replace(needle,"""    const positionedScene = resolve(import.meta.dirname, 'src/scene/positioned-scene.ts')
    const sceneRuntime = resolve(import.meta.dirname, 'src/browser-lazy/scene-backend-runtime.ts')
    build.onResolve({ filter: /\\/positioned-scene\\.ts$/ }, args =>
      args.importer !== sceneRuntime && resolve(args.resolveDir, args.path) === positionedScene
        ? { path: resolve(import.meta.dirname, 'src/browser-lazy/positioned-scene.ts') } : undefined)
"""+needle);f.write_text(s)
print('Applied canonical Scene transaction split and existing-SPI acquisition facade')
