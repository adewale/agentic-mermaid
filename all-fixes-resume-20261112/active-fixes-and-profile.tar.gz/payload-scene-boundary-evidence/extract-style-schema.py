from pathlib import Path
r=Path('/dev/shm/pr449-four-final-20261111/payload-scene-boundary-candidate');p=r/'src/render-option-contract.ts';s=p.read_text();a=s.index('const STYLE_SPEC_SCHEMA =');z=s.index('export const JSON_VALUE_SCHEMA',a);block=s[a:z].replace('const STYLE_OPTION_SCHEMA =','export const STYLE_OPTION_SCHEMA =')
leaf='''import { styleSpecJsonSchema } from './scene/style-spec.ts'
import { deepFreeze } from './shared/plain-data.ts'
import type { JsonSchema } from './shared/schema-validation.ts'
type JsonSchemaNode = JsonSchema

'''+block+'''// The async style provider owns this exact closed validation root. Schema
// consumers outside that graph continue using the full canonical fragment.
export const STYLE_OPTION_VALIDATION_ROOT = deepFreeze({ $defs: { styleOption: STYLE_OPTION_SCHEMA } })
export function renderOptionSchemaRoot(_field: string, root: JsonSchemaNode): JsonSchemaNode { return root }
''';(r/'src/render-style-option-schema.ts').write_text(leaf)
s=s[:a]+s[z:];s=s.replace("import { styleSpecJsonSchema } from './scene/style-spec.ts'","import { STYLE_OPTION_SCHEMA, renderOptionSchemaRoot } from './render-style-option-schema.ts'");s=s.replace('validateJsonSchema(fieldValue, descriptor.schema, rootSchema, [field]','validateJsonSchema(fieldValue, descriptor.schema, renderOptionSchemaRoot(field, rootSchema), [field]');p.write_text(s)
# A second pre-existing unused import otherwise evaluates StyleSpec's tables.
p=r/'src/render-contract.ts';s=p.read_text();assert s.count('styleSpecJsonSchema')==1;s=s.replace("import { styleSpecJsonSchema } from './scene/style-spec.ts'\n",'');p.write_text(s)
(r/'src/browser-lazy/render-style-option-schema.ts').write_text('''import type { JsonSchema } from '../shared/schema-validation.ts'
import { styleOptionValidationRoot } from './style-registry.ts'

// The selected style fragment resolves to its canonical schema at the existing
// Style acquisition point; ordinary fields never demand that implementation.
export const STYLE_OPTION_SCHEMA = { $ref: '#/$defs/styleOption' } as const
export function renderOptionSchemaRoot(field: string, root: JsonSchema): JsonSchema {
  return field === 'style' ? styleOptionValidationRoot() : root
}
''')
p=r/'src/browser-lazy/style-runtime.ts';s=p.read_text()+"\nexport { STYLE_OPTION_VALIDATION_ROOT } from '../render-style-option-schema.ts'\n";p.write_text(s)
p=r/'src/browser-lazy/style-registry.ts';s=p.read_text()+"\nexport function styleOptionValidationRoot() { return styles().STYLE_OPTION_VALIDATION_ROOT }\n";p.write_text(s)
p=r/'tsup.browser-lazy.config.ts';s=p.read_text();needle="    const styleRuntime = resolve(import.meta.dirname, 'src/browser-lazy/style-runtime.ts')";assert needle in s;s=s.replace(needle,needle+'''
    const styleSchema = resolve(import.meta.dirname, 'src/render-style-option-schema.ts')
    build.onResolve({ filter: /\\/render-style-option-schema\\.ts$/ }, args =>
      args.importer !== styleRuntime && resolve(args.resolveDir, args.path) === styleSchema
        ? { path: resolve(import.meta.dirname, 'src/browser-lazy/render-style-option-schema.ts') } : undefined)''');p.write_text(s)
print('Canonical style schema extracted; existing async Style provider supplies exact schema with no new await/cache')
