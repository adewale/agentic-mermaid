from pathlib import Path
r=Path('/dev/shm/pr449-four-final-20261111/payload-scene-boundary-candidate');p=r/'src/scene/serialization.ts';s=p.read_text()
# Keep serialization/admission node provenance in its existing owner; expose
# read-only internal queries to the Scene-only transaction issuer.
s=s.replace('const TRANSFERRED_WRITABLE_NODES = new WeakSet<object>()','const TRANSFERRED_WRITABLE_NODES = new WeakSet<object>()\nexport function isTransferredWritableSceneNode(node: object): boolean { return TRANSFERRED_WRITABLE_NODES.has(node) }\nexport function transferredWritableSceneNodeInert(node: object): boolean { return sceneStateWeakApply(sceneStateWeakHas, TRANSFERRED_WRITABLE_NODES, [node]) }\nexport function writtenSceneNodeSerialization(node: object): string | undefined { return WRITTEN_SCENE_NODES.get(node) }')
a=s.index('/** First-write data belongs');z=s.index('interface SerializedAttribute');block=s[a:z];ga=s.index('const groupDefine =');gz=s.index('/** Indent every line',ga);group=s[ga:gz]
# Shared recorder registry remains a single canonical owner. The true receipt
# issuer/CapturedSceneWrites class stays private to Scene capture, as before.
state=block[:block.index('interface WrittenPath')]
state=state.replace('type SceneWriteCallback','export type SceneWriteCallback').replace('interface SceneWriteRecorder','export interface SceneWriteRecorder').replace('function readSceneWriteObserver','export function readSceneWriteObserver')
state=state.replace('type ConnectorNode = Extract<SceneNode, { kind: \'connector\' }>','export type ConnectorNode = Extract<SceneNode, { kind: \'connector\' }>')
state+='''
// Issuing this observation token does not admit a node or issue a Scene receipt.
// Only the Scene capture owner can complete its private CapturedSceneWrites.
export function newSceneWriteObserver(actualBackendWrite: boolean): SceneSerializationObserver {
  const observe = (actualBackendWrite ? groupFreeze(sceneObserverCreate(null)) : Object.freeze(Object.create(null))) as SceneSerializationObserver
  if (actualBackendWrite) groupObserverApply(groupObserverAdd, actualSceneObservers, [observe])
  return observe
}
export function recordSceneWriteObserver(observe: SceneSerializationObserver, recorder: SceneWriteRecorder, actualBackendWrite: boolean): void {
  if (actualBackendWrite) sceneObserverApply(sceneObserverSet, sceneWriteObservers, [observe, groupFreeze(recorder)])
  else sceneWriteObservers.set(observe, recorder)
}
export function setSceneBackendWriteObserver(context: object, observe: SceneSerializationObserver): void { sceneObserverApply(sceneObserverSet, backendWriteObservers, [context, observe]) }
export function deleteSceneBackendWriteObserver(context: object): void { sceneObserverApply(sceneObserverDelete, backendWriteObservers, [context]) }
'''
# Captured language intrinsics are shared values, not caller-dispatched helpers.
intrinsics='''export const sceneObserverCreate = Object.create, sceneObserverWeakMap = WeakMap
export const sceneObserverGet = WeakMap.prototype.get, sceneObserverSet = WeakMap.prototype.set, sceneObserverDelete = WeakMap.prototype.delete, sceneObserverApply = Reflect.apply
export const groupObserverHas = WeakSet.prototype.has, groupObserverAdd = WeakSet.prototype.add, groupObserverApply = Reflect.apply
export const groupFreeze = Object.freeze
'''
state=state.replace('const sceneObserverCreate = Object.create, sceneObserverWeakMap = WeakMap\n','').replace('const sceneObserverGet = WeakMap.prototype.get, sceneObserverSet = WeakMap.prototype.set, sceneObserverDelete = WeakMap.prototype.delete, sceneObserverApply = Reflect.apply\n','')
group_interface=group[group.index('interface GroupComposition'):group.index('function groupComposition')].replace('interface GroupComposition','export interface GroupComposition')
(r/'src/scene/scene-write-observer.ts').write_text("import type { SceneNode, SceneDoc, Geometry, ShapeMark } from './ir.ts'\nimport type { WrittenCompoundInput } from './written-geometry.ts'\n"+intrinsics+group_interface+state)
# Capture implementation moves byte-for-byte apart from private registry reads.
capture=block[block.index('interface WrittenPath'):]
capture=capture.replace('WRITTEN_SCENE_NODES.get(node)','writtenSceneNodeSerialization(node)').replace('TRANSFERRED_WRITABLE_NODES.has(node)','isTransferredWritableSceneNode(node)').replace('groupObserverApply(groupObserverHas, TRANSFERRED_WRITABLE_NODES, [node])','transferredWritableSceneNodeInert(node)')
capture=capture.replace("  const observe = (actualBackendWrite ? groupFreeze(sceneObserverCreate(null)) : Object.freeze(Object.create(null))) as SceneSerializationObserver\n  if (actualBackendWrite) groupObserverApply(groupObserverAdd, actualSceneObservers, [observe])",'  const observe = newSceneWriteObserver(actualBackendWrite)')
capture=capture.replace('  if (actualBackendWrite) sceneObserverApply(sceneObserverSet, sceneWriteObservers, [observe, groupFreeze(recorder)])\n  else sceneWriteObservers.set(observe, recorder)','  recordSceneWriteObserver(observe, recorder, actualBackendWrite)').replace('sceneObserverApply(sceneObserverDelete, backendWriteObservers, [backendContext])','deleteSceneBackendWriteObserver(backendContext)').replace('sceneObserverApply(sceneObserverSet, backendWriteObservers, [contextObject, observe])','setSceneBackendWriteObserver(contextObject, observe)')
group=group.replace('const groupDefine = Object.defineProperty, groupFreeze = Object.freeze','const groupDefine = Object.defineProperty').replace('const groupObserverHas = WeakSet.prototype.has, groupObserverAdd = WeakSet.prototype.add, groupObserverApply = Reflect.apply\n','').replace(group[group.index('interface GroupComposition'):group.index('function groupComposition')],'')
imports='''import { MAX_OCCLUSION_OPERATIONS } from './paint-work.ts'
import { connectorContourSemantics } from './connector-geometry.ts'
import { isAdmittedSceneDocument } from './scene-admission-state.ts'
import { isOwnDataSceneSnapshot, isOwnDataSceneSnapshotInert, isOwnDataSceneArrayInert } from './scene-data-snapshot.ts'
import type { SceneDoc, SceneNode, Geometry, MarkPaint, ShapeMark } from './ir.ts'
import { rectanglePaintFields, writtenPolylineProjectionOf, prepareWrittenCompoundShape, observeWrittenCompoundShape, completeWrittenCompoundShape, type WrittenCompoundInput } from './written-geometry.ts'
import { createEmissionContext, type EmissionColorResolver } from './emission-context.ts'
import { writtenSceneNodeSerialization, isTransferredWritableSceneNode, transferredWritableSceneNodeInert, indentLines } from './serialization.ts'
import { newSceneWriteObserver, recordSceneWriteObserver, setSceneBackendWriteObserver, deleteSceneBackendWriteObserver, sceneObserverWeakMap, sceneObserverGet, sceneObserverSet, sceneObserverApply, groupFreeze, groupObserverHas, groupObserverApply, type SceneSerializationObserver, type SceneWriteCallback, type SceneWriteRecorder, type ConnectorNode, type GroupComposition } from './scene-write-observer.ts'

'''
(r/'src/scene/scene-write-capture.ts').write_text(imports+capture+group)
s=s[:a]+s[z:];a=s.index('const groupDefine =');z=s.index('/** Indent every line',a);s=s[:a]+s[z:]
s=s.replace("import { createEmissionContext, type EmissionColorResolver } from './emission-context.ts'\n",'').replace("import { isAdmittedSceneDocument } from './scene-admission-state.ts'\n",'').replace("import { MAX_OCCLUSION_OPERATIONS } from './paint-work.ts'\n",'')
s="import { readSceneWriteObserver, groupObserverHas as sceneStateWeakHas, groupObserverApply as sceneStateWeakApply, type SceneSerializationObserver, type GroupComposition } from './scene-write-observer.ts'\nexport { sceneBackendWriteObserver, sceneDocumentComposition, type SceneSerializationObserver } from './scene-write-observer.ts'\nexport type { SceneWriteReceipt, SceneWriteWork } from './scene-write-capture.ts'\n"+s;p.write_text(s)
# The Scene capture function is private (not published by package entrypoints).
# Update its real callers directly; no eager re-export into Native serialization.
for f in (r/'src').rglob('*.ts'):
 if f.name in ['serialization.ts','scene-write-capture.ts','scene-write-observer.ts']:continue
 t=f.read_text()
 if 'createSceneWriteCapture' in t and "from './serialization.ts'" in t:t=t.replace("from './serialization.ts'","from './scene-write-capture.ts'")
 elif 'createSceneWriteCapture' in t and "from '../scene/serialization.ts'" in t:
  # Test imports can include other serialization bindings: separate captured API.
  import re
  t=re.sub(r'import \{([^}]*\bcreateSceneWriteCapture\b[^}]*)\} from ([\'"])([^\'\"]*serialization\.ts)\2',lambda m:"import { "+', '.join(v.strip() for v in m[1].split(',') if v.strip()!='createSceneWriteCapture')+" } from "+m[2]+m[3]+m[2]+"\nimport { createSceneWriteCapture } from "+m[2]+m[3].replace('serialization.ts','scene-write-capture.ts')+m[2],t)
 if t!=f.read_text():f.write_text(t)
print('Scene-only capture implementation extracted; private maps remain single-owner')
