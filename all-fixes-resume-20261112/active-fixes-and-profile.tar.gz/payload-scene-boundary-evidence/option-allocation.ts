import { writeFileSync } from 'node:fs'
const rows=[]
let publicSchema: string | undefined
for (const arm of ['before','after']) {
  const api=await import(`./option-allocation-${arm}.ts`)
  const refs=new Set<string>(), seen=new Set<object>()
  function references(value: unknown): void {
    if (!value||typeof value!=='object'||seen.has(value)) return
    seen.add(value)
    if (typeof (value as any).$ref==='string') refs.add((value as any).$ref)
    for(const child of Object.values(value)) references(child)
  }
  for(const descriptor of Object.values(api.SHARED_RENDER_OPTION_FIELD_DESCRIPTORS) as any[]) references(descriptor.schema)
  references(api.JSON_VALUE_SCHEMA)
  const cases=[{}, {style:['paper',{colors:{accent:'#005fcc'}}],mermaidConfig:{nested:[null,3,'UTF16 😀',true,{a:['b']}] }}, {style:{colors:{fg:'url(https://bad.example)'}}}, {mermaidConfig:{nested:[()=>1]}}]
  const diagnostics=cases.map(value=>api.validateSerializableRenderOptions(value))
  const root=api.retainedValidationRootForEvidence(); const visited=new Set<object>();let properties=0, frozen=0
  function count(value:unknown):void { if(!value||typeof value!=='object'||visited.has(value))return;visited.add(value);properties+=Object.keys(value).length;if(Object.isFrozen(value))frozen++;for(const child of Object.values(value))count(child) }
  count(root)
  const projection=JSON.stringify(api.sharedRenderOptionsJsonSchema())
  if(publicSchema===undefined)publicSchema=projection
  rows.push({arm,refs:[...refs].sort(),diagnostics,retainedObjects:visited.size,retainedProperties:properties,frozenObjects:frozen,retainedJSONBytes:Buffer.byteLength(JSON.stringify(root)),publicSchemaBytes:Buffer.byteLength(projection),publicSchemaExact:projection===publicSchema})
}
writeFileSync(new URL('./OPTION-ALLOCATION.json',import.meta.url),JSON.stringify({rows,scope:'Real validateSerializableRenderOptions producer/cache in diagnostic source copies; only private cache reader added, import URLs rebound to exact originals. Counts are actual retained JS object graph, not allocation timing or whole-render heap. Public browser heap measured separately.'},null,2)+'\n')
console.log(JSON.stringify(rows))
