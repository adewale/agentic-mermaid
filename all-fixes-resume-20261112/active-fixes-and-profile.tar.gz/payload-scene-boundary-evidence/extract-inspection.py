from pathlib import Path
import re
r=Path('/dev/shm/pr449-four-final-20261111/payload-scene-boundary-candidate');p=r/'src/scene/inspection.ts';s=p.read_text()
a=s.index('/** Inspect the actual lowered');z=s.index('function hasDisplayedText',a);wrappers=s[a:z];a2=s.index('function inspectScene(scene:');walk=s[a2:];s=s[:a2];s=s[:a]+s[z:]
s=s.replace("import { sceneNodeSerialization, beginSceneWriteInspection, type SceneWriteReceipt, type SceneWriteWork } from './serialization.ts'","import { sceneNodeSerialization, type SceneWriteWork } from './serialization.ts'").replace("import { isAdmittedSceneDocument } from './scene-admission-state.ts'\n",'').replace("import { assertInertGroup } from './group-emission.ts'\n",'')
s=s.replace('type TextDetails =','export type TextDetails =').replace('function ownerSnapshot(','export function ownerSnapshot(').replace('function createPaintRecorder(','export function createPaintRecorder(')
s=s.replace('const sceneWriteWork = new WeakMap<ScenePaintGeometryInspection, SceneWriteWork>()','const sceneWriteWork = new WeakMap<ScenePaintGeometryInspection, SceneWriteWork>()\nexport function retainScenePathEmissionWork(inspection: ScenePaintGeometryInspection, work: SceneWriteWork): void { sceneWriteWork.set(inspection, work) }');p.write_text(s)
wrappers=wrappers.replace('sceneWriteWork.set(inspection, writes.work())','retainScenePathEmissionWork(inspection, writes.work())')
(r/'src/scene/scene-inspection.ts').write_text('''import { isAdmittedSceneDocument } from './scene-admission-state.ts'
import { beginSceneWriteInspection, type SceneWriteReceipt } from './scene-write-capture.ts'
import { assertInertGroup } from './group-emission.ts'
import type { SceneDoc, SceneNode, SceneOwner } from './ir.ts'
import { composeMatrices, IDENTITY_MATRIX, transformMatrix, type AffineMatrix } from './transforms.ts'
import { createPaintRecorder, ownerSnapshot, retainScenePathEmissionWork, multiplySceneOpacity, sceneGroupOpacity, type ScenePaintInspection, type ScenePaintGeometryInspection, type TextDetails } from './inspection.ts'
const textPaintFreeze = Object.freeze

'''+wrappers+walk)
# The common proof algorithm is unchanged. Only its SceneDoc adapter moves.
p=r/'src/scene/paint-certification.ts';s=p.read_text();a=s.index('export function certifyScenePaint(');z=s.index('export type NativePaintHeader',a);wrapper=s[a:z];s=s[:a]+s[z:];s=s.replace('hasImmutablePaintRoster, inspectScenePaintGeometry,','hasImmutablePaintRoster,').replace("import type { SceneWriteReceipt } from './serialization.ts'\n",'');p.write_text(s)
(r/'src/scene/scene-paint-certification.ts').write_text('''import type { RenderedLayout } from '../agent/types.ts'
import type { SceneDoc } from './ir.ts'
import type { SceneWriteReceipt } from './scene-write-capture.ts'
import { inspectScenePaintGeometry } from './scene-inspection.ts'
import { certifyNativePaint, type PaintLayoutCertification } from './paint-certification.ts'

'''+wrapper)
# Update the internal import owners, including the existing owning tests; no
# new public export is created, and no stale re-export keeps the Scene edge.
changes={'inspection.ts':({'inspectScenePrimitives','inspectScenePaintGeometry'},'scene-inspection.ts'),'paint-certification.ts':({'certifyScenePaint'},'scene-paint-certification.ts'),'serialization.ts':({'beginSceneWriteInspection'},'scene-write-capture.ts')}
for f in (r/'src').rglob('*.ts'):
 if f.name in ['scene-inspection.ts','scene-paint-certification.ts','scene-write-capture.ts','scene-write-observer.ts']:continue
 t=f.read_text()
 for leaf,(names,dest) in changes.items():
  def sub(m):
   vals=[v.strip() for v in m[1].split(',') if v.strip()];moved=[v for v in vals if v.split(' as ')[0].removeprefix('type ') in names];stay=[v for v in vals if v not in moved]
   if not moved:return m[0]
   return ("import { "+', '.join(stay)+" } from '"+m[2]+"'\n" if stay else '')+"import { "+', '.join(moved)+" } from '"+m[2][:-len(leaf)]+dest+"'"
  t=re.sub(r"import\s*\{([^}]*)\}\s*from\s*'([^']*/"+re.escape(leaf)+r")'",sub,t)
 if t!=f.read_text():f.write_text(t)
print('Canonical Scene inspection/certification adapter extracted; Native proof algorithm unchanged')
