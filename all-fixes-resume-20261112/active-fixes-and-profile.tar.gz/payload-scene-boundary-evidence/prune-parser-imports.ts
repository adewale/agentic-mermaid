import ts from '/tmp/pr449-main-integration-20261029-762/node_modules/typescript/lib/typescript.js'
import {readFileSync,writeFileSync} from 'node:fs'
const root='/dev/shm/pr449-four-final-20261111/payload-scene-boundary-candidate'
for (const name of ['parser-flowchart.ts','parser-state.ts']) {
 const path=root+'/src/'+name;let source=readFileSync(path,'utf8')
 if(name==='parser-state.ts')source=source.replace("export { parseStyleProps } from './shared/style-props.ts'\n",'')
 const file=ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS),used=new Set<string>()
 for(const statement of file.statements)if(!ts.isImportDeclaration(statement)){
  const visit=(node:ts.Node):void=>{if(ts.isIdentifier(node))used.add(node.text);ts.forEachChild(node,visit)};visit(statement)
 }
 const edits:Array<{start:number,end:number,text:string}>=[],printer=ts.createPrinter()
 for(const statement of file.statements)if(ts.isImportDeclaration(statement)&&statement.importClause?.namedBindings&&ts.isNamedImports(statement.importClause.namedBindings)){
  const clause=statement.importClause,bindings=clause.namedBindings,kept=bindings.elements.filter(e=>used.has(e.name.text));if(kept.length===bindings.elements.length)continue
  const updated=kept.length?ts.factory.updateImportDeclaration(statement,statement.modifiers,ts.factory.updateImportClause(clause,clause.isTypeOnly,clause.name,ts.factory.updateNamedImports(bindings,kept)),statement.moduleSpecifier,statement.attributes):undefined
  edits.push({start:statement.getStart(file),end:statement.end,text:updated?printer.printNode(ts.EmitHint.Unspecified,updated,file):''})
 }
 for(const edit of edits.sort((a,b)=>b.start-a.start))source=source.slice(0,edit.start)+edit.text+source.slice(edit.end)
 writeFileSync(path,source)
}
