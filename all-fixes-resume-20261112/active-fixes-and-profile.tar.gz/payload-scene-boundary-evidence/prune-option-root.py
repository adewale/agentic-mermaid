from pathlib import Path
r=Path('/dev/shm/pr449-four-final-20261111/payload-scene-boundary-candidate');p=r/'src/render-option-contract.ts';s=p.read_text();old='''  // The schema is a projection of frozen module constants: build it once.
  const rootSchema = validationRootSchema ??= deepFreeze(sharedRenderOptionsJsonSchema())''';new='''  // Selected field fragments already own their exact schemas. Their only
  // enclosing references are the recursive JSON value definition; retaining
  // another full public schema duplicates every field and expanded StyleSpec.
  const rootSchema = validationRootSchema ??= deepFreeze({ $defs: { jsonValue: cloneSchema(JSON_VALUE_SCHEMA) } })''';assert old in s;p.write_text(s.replace(old,new))
p=r/'src/__tests__/render-options-authority.test.ts';s=p.read_text();needle="  test('accepts the exact nested public shapes and recursive Mermaid JSON', () => {";newtest='''  test('public schema copies cannot alter recursive JSON or Style admission', () => {
    const before = sharedRenderOptionsJsonSchema()
    const mutable = sharedRenderOptionsJsonSchema() as {
      properties: Record<string, Record<string, unknown>>
      $defs: { jsonValue: Record<string, unknown> }
    }
    mutable.$defs.jsonValue.anyOf = [{ const: 'foreign-schema' }]
    mutable.properties.style!.anyOf = [{ type: 'number' }]
    expect(validateSerializableRenderOptions({
      style: ['paper', { colors: { accent: '#005fcc' } }],
      mermaidConfig: { extensionData: [null, true, 4, 'value', { nested: ['ok'] }] },
    })).toEqual([])
    expect(sharedRenderOptionsJsonSchema()).toEqual(before)
    expect(validateSerializableRenderOptions({ mermaidConfig: { nested: [() => 1] } }).length).toBeGreaterThan(0)
  })

''';assert needle in s;p.write_text(s.replace(needle,newtest+needle))
# Diagnostic copies only: expose the actual existing private cache after the
# real validator executes, so retained allocation can be counted without a new
# production API or a synthetic surrogate producer.
for name,root in [('before',Path('/dev/shm/pr449-four-final-20261111/chain-proof-browser-candidate')),('after',r)]:
 text=(root/'src/render-option-contract.ts').read_text();f=root/'src/render-option-allocation-evidence.ts';f.write_text(text+'\nexport function retainedValidationRootForEvidence() { return validationRootSchema }\n')
print('Pruned duplicated runtime schema producer; owning public-copy regression added')
