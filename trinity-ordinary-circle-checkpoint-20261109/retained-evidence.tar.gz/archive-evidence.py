import pathlib,tarfile,hashlib,json,shutil,subprocess,os
repo=pathlib.Path('/tmp/pr449-main-integration-20261029-762');root=pathlib.Path('/tmp/pr449-week-comparison-20261101/trinity-ordinary-circle-20261109');stage=pathlib.Path('/tmp/pr449-evidence-stage-trinity-circle-20261109');name='trinity-ordinary-circle-checkpoint-20261109';out=stage/name;out.mkdir(parents=True,exist_ok=True);manifest=[]
with tarfile.open(out/'retained-evidence.tar.gz','w:gz',compresslevel=6) as tar:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  data=p.read_bytes();rel=str(p.relative_to(root));manifest.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});tar.add(p,arcname=rel,recursive=False)
with tarfile.open(out/'retained-evidence.tar.gz','r:gz') as tar:
 members={m.name:m for m in tar.getmembers() if m.isfile()};assert len(members)==len(manifest)
 for row in manifest:
  data=tar.extractfile(members[row['path']]).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
for file in ['README.md','COHORT-COMPARISON.json','COST-QUALIFICATION.json','PRODUCT-STREAMS.json','SOURCE-COMMITS.txt','campaign-state-complete.json','RASTER-DUAL.json','ENROLLED-INK.json','INDEPENDENT-REVIEW.txt','PAYLOAD-HYPOTHESIS-STOPPED.txt','CURRENT-COMPARISON.json','COMPARISON-TABLE.md','QUALIFIED-REVISION.json']:
 shutil.copy2(root/file,out/file)
for backend in ['elk','agentic','trinity']:shutil.copy2(root/f'rasters/{backend}-dual-labelled-circle-TB.png',out/f'{backend}-dual-TB.png')
shutil.copy2(root/'rasters/enrolled-trinity-circle.png',out/'enrolled-trinity-circle.png')
arc=out/'retained-evidence.tar.gz';v={'source':'dee908197a8fe678d05cb6e1c6827d05ae9d4fb7','files':len(manifest),'uncompressedBytes':sum(x['bytes'] for x in manifest),'archiveBytes':arc.stat().st_size,'archiveSha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'verification':'Every archive member reread and verified against original length and SHA256. No symlink duplicates.'};(out/'VERIFIED.json').write_text(json.dumps(v,indent=2)+'\n')
ref='refs/heads/review/pr449-evidence-20261105';parent=subprocess.check_output(['git','rev-parse',ref],cwd=repo,text=True).strip();env=os.environ|{'GIT_INDEX_FILE':str(stage/'index'),'GIT_WORK_TREE':str(stage)}
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,env=env,text=True).strip()
git('read-tree',parent);git('add',name);tree=git('write-tree');commit=subprocess.check_output(['git','commit-tree',tree,'-p',parent,'-m','Preserve canonical circle delivery and complete three-way outcomes'],cwd=repo,text=True).strip();git('update-ref',ref,commit,parent);print(json.dumps({'commit':commit,**v}))
