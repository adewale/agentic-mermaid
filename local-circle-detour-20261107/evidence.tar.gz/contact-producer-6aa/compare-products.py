import pathlib,json,gzip,xml.etree.ElementTree as X,math
r=pathlib.Path('/tmp/pr449-week-comparison-20261101/contact-producer-6aa');before=gzip.open(r/'profiles-before/circle230/warmup.svg.gz','rt').read();after=gzip.open(r/'local-terminal230/actual.svg.gz','rt').read()
def read(svg):
 tags=list(X.fromstring(svg).iter());edges=[t for t in tags if t.attrib.get('data-role')=='edge' and t.tag.split('}')[-1]=='polyline'];rows=[]
 for t in edges:
  pts=[list(map(float,p.split(','))) for p in t.attrib['points'].split()];rows.append({'id':t.attrib.get('data-id'),'points':pts})
 return tags,{'viewBox':tags[0].attrib['viewBox'],'wire':sum(math.dist(a,b) for e in rows for a,b in zip(e['points'],e['points'][1:])),'bends':sum(len(e['points'])-2 for e in rows),'edges':len(edges)}
a,ma=read(before);b,mb=read(after);assert len(a)==len(b);changes=[]
for i,(x,y) in enumerate(zip(a,b)):
 assert x.tag==y.tag
 if x.attrib!=y.attrib:changes.append({'index':i,'tag':x.tag.split('}')[-1],'changes':{k:[x.attrib.get(k),y.attrib.get(k)] for k in x.attrib.keys()|y.attrib.keys() if x.attrib.get(k)!=y.attrib.get(k)}})
scopea=a[0].attrib['class'];scopeb=b[0].attrib['class'];ta=[(x.tag.split('}')[-1],(x.text or '').replace(scopea,'$SCOPE')) for x in a];tb=[(x.tag.split('}')[-1],(x.text or '').replace(scopeb,'$SCOPE')) for x in b];assert ta==tb
result={'before':ma,'after':mb,'scopeNormalizedTextsAndCSSExact':True,'allStartTagsAndAttributesCompared':True,'tagCount':len(a),'changed':changes};(r/'PRODUCT-COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result)[:2400])
