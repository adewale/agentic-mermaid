from pathlib import Path
import subprocess
r=Path('/tmp/pr449-week-comparison-20261101/contact-producer-6aa');a=Path('src/layout/graph-paint-support.ts');b=Path('src/layout/passes/obstacle-routing.ts');c=Path('src/layout/label-conflicts.ts');aa=a.read_bytes();bb=b.read_bytes();cc=c.read_bytes()
s=aa.decode().replace('  type Circle =','  const stats = {charges:0,shaftQueries:0,shaftHits:0,constructed:0,twoPointConstructed:0,pointsConstructed:0}; ((globalThis as any).__pr449ContactStats ??= []).push(stats); const originalPay=pay;pay=units=>{stats.charges+=units;return originalPay(units)}\n  type Circle =',1).replace('    let routes = shafts.get(edge)','    stats.shaftQueries++\n    let routes = shafts.get(edge)',1).replace('    if (routes.has(points)) return routes.get(points)','    if(routes.has(points)){stats.shaftHits++;return routes.get(points)}',1).replace('    const written = points.map(writtenPoint), boxes:','    stats.constructed++;stats.pointsConstructed+=points.length;stats.twoPointConstructed+=Number(points.length===2)\n    const written = points.map(writtenPoint), boxes:',1)
t=bb.decode().replace('    currentEdge = edge; paintedRepair = false','    currentEdge = edge; paintedRepair = false\n    if(edge.source==="n10"&&edge.target==="n16")console.log("230 before",paintWork.remaining)',1).replace('      paintedRepair = true','      paintedRepair = true\n      if(edge.source==="n10"&&edge.target==="n16")console.log("230 enrolled",paintWork.remaining)',1).replace('    if (!route) continue // never-worse','    if(edge.source==="n10"&&edge.target==="n16")console.log("230 after",paintWork.remaining,!!route)\n    if (!route) continue // never-worse',1)
old='    return graphInkClear(nodes, edges.map(edge => edge === currentEdge ? proposed : edge), nodes, edges, groups, style!, paintWork, chargeWork)'
t=t.replace(old,'    const tracing=currentEdge.source==="n10"&&currentEdge.target==="n16"; (globalThis as any).__pr449Tracing=tracing;try{const result=graphInkClear(nodes, edges.map(edge => edge === currentEdge ? proposed : edge), nodes, edges, groups, style!, paintWork, chargeWork);if(tracing)console.log("230 proposal",result,paintWork.remaining,JSON.stringify(points));return result}finally{(globalThis as any).__pr449Tracing=false}',1)
u=cc.decode();start=u.index('export function graphInkClear(');end=u.index('\nfunction graphHeadersClear',start);chunk=u[start:end]
for line in sorted(set(i+u[:start].count('\n')+1 for i,l in enumerate(chunk.splitlines()) if 'return false' in l),reverse=True):
 pass
ls=chunk.splitlines()
for i,line in enumerate(ls):
 if 'return false' in line:
  number=u[:start].count('\n')+1+i
  ls[i]=line.replace('return false','return ((globalThis as any).__pr449Tracing && console.log("guard",'+str(number)+',budget.remaining)), false')
u=u[:start]+'\n'.join(ls)+u[end:]
try:
 a.write_text(s);b.write_text(t);c.write_text(u)
 with open(r/'counts-candidate.log','w') as log:subprocess.run(['/tmp/pr449-tools-20261106/package/bin/bun',str(r/'trace230.ts'),'candidate'],stdout=log,stderr=subprocess.STDOUT,check=True)
finally:a.write_bytes(aa);b.write_bytes(bb);c.write_bytes(cc)
print((r/'counts-candidate.log').read_text()[:5000])
