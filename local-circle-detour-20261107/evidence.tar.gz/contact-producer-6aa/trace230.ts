import{readFileSync,writeFileSync}from'node:fs'
import{parseMermaid}from'/tmp/pr449-main-integration-20261029-762/src/parser.ts'
import{layoutGraphSync}from'/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts'
const root='/tmp/pr449-week-comparison-20261101/contact-producer-6aa',job=JSON.parse(readFileSync(root+'/job230.json','utf8'))
layoutGraphSync(parseMermaid(job.source),job.options)
writeFileSync(root+'/CONTACT-COUNTS-'+process.argv[2]+'.json',JSON.stringify((globalThis as any).__pr449ContactStats,null,2)+'\n')
console.log(JSON.stringify((globalThis as any).__pr449ContactStats))
