# Canonical style-provider payload subtraction

9109d4373035cc1c18f395ac0e19dfdbba9e73fc plus5 owning loading files; Native WIP excluded. Sources and commands: MILESTONE.json.

Plain full-public closures:8/8 qualify;16/16 whole SVG+receipt products exact9109. Flow Native −19,916raw/−5,725gzip9/−4,250Br11B; ELK −19,931/−5,771/−4,336. Other observed families save5,764–5,778gzipB. Requests unchanged; JS heap lower107,712–112,320B. Timeline OUTPUT_SCOPE remains unverified.

Styled full-public closures:4/4 qualify including2matchingcontrol observations;4/4 candidate wholeproducts exact. Paper +973raw/+662gzip/+1,237BrB,+1request,+6,888Bheap. Hand-drawn +974/+662/+1,248,+1request,+11,172heap; its existingunverified proof is retained. First full-namespace provider adverse+2.6KBgzip trial remains retained.

55 sourceowners/689assertions and11 emittedowners/84assertions pass; scoped lint/diff checks pass. Actual primary canonicalcore+repo types pass (Nativeagent combinedfrozenrun; log ../remaining-proof/group-combined-typecheck-final.log). Isolatedarchive type attempt remains unqualified.

The unchanged owning asyncbudget stillfails: forest→ELK→YAML2,550,939raw /791,012gzip /630,704Br against2,430,000/761,500/618,000 caps. Allotherfailures retained. Demo/standalone not rebuilt, their existingCI failures remain open. No all-goals/capcompletion/Node-speed claim.

Actual fetched bytes are perfile offlinegzip9/Brotli11, notwire orwholepackage. Binding separate. ForcedGCJSheap is notRSS/native/WASM. Fullproducts, proofunknowns, exactmanifests andbrowserclose records retained in this folder and ../style-provider-final-styled/browser. All12browserobservationsclosed,0open.
