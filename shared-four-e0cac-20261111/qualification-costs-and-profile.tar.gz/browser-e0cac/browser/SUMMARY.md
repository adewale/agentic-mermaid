# Combined e0cac lazy-browser qualification

Candidate `e0cac4865c02a8633862e3e50008efca050b06f6`; Trident `f080278e31e4202ca89d524e4ee9e4cf3cbff038`. Retained07a,9109,PR599 andMain426 were not replayed.

66/66 fresh family/backend observations qualify, retaining132 complete public SVG/receipt products. Two affected styled observations also qualify, retaining4 more products. All68 browsers closed;0 open;0 observer/module-fetch errors.

All132 ordinary SVGs and non-certification receipt fields equal07a,9109 andPR599 exactly. All132 proofstatuses/layoutdecisions match.124 proofs pass;8 remain unverified: Timeline andXYChart support/enrolled calls onbothbackends, OUTPUT_SCOPE.25families have no recorded graph-layout decision; requestedbackend alone does not prove application.

Against9109,28/132 wholeproducts/proofvectors are exact;104 differ only in checks.operations, all lower (maximum reduction1,966). Against07a/PR599,8/132 exact; other changes also only lower operations. AgainstMain,124SVGs/non-certreceipts equal; ER/Requirement differences remain. Main proofvectors differ in all132operationcounts (128higher,4lower), fourviewportheights andeightoutputdigests; status/layoutdecision unchanged.

Every ordinary family closure andpost-GC JS heap sample is lower than07a and9109, with unchangedrequests. Versus9109, median gzip9−5,316B Native/−5,319B ELK andheap−111,700/−111,964B. VersusPR599,32/33gzip/Brotli closures shrink (median gzip−6,995B both); Agentflow remains adverse:+156B gzip/+1,074B Brotli Native,+115/+1,136 ELK, although rawbytes shrink. Every heap sample is lower thanPR599 (median−57,104/−59,144B).

Every ordinary closure andheap sample remains higher thanMain426: median gzip+36,344B both andheap+397,676B Native/+396,652B ELK. Flow is+57,679/+46,003B gzip and+9/+3requests. The Native-versus-ELK size advantage predates this change.

Affected20-product requalification isexplicit:16plainproducts alreadywithinfinal66 and4newstyledproducts. All20SVG/non-certreceipts equal9109. Paper adds2,207raw/1,117gzip/1,826BrB,+1request,+5,804Bheap. Hand-drawn adds2,208/1,118/1,805,+1request,+12,532Bheap. Paper wholeproducts differ in chargedproofwork; hand-drawn wholeproducts remainexact anditsunverified proof staysunverified. Allfullvectors andadversecosts retained.

The unchanged owning asyncbudget stillfails: forest→ELK→YAML2,552,183raw /791,467gzip /631,291Br versus2,430,000/761,500/618,000 caps (gzip deficit29,967B). Every other actualbudgetfailure remains in ../BUDGET.log. Demo/standalone were not rebuilt here; their existingCI failures remain open. No all-goals,100ms orcap-completion claim.

Actual publicWithReceiptAsync with explicitbackend/fallbacknone; same mandatoryfamily supportprobe plusenrolled source. Actual fetched modules compressed independently offlinegzip9/Brotli11;bindings separate. Notcompressedwire/wholepackage/warm-portfolio-sum. ForcedGCJSheap isnotRSS/native/WASM/leak evidence. Instrumentedbrowser clocks are notAPI timings. XML/canvas/visible-label qualification isnotcompleteauthoredmeaning; the independentfidelity lane owns that evidence.

Eachcell:requests /productrawKiB /gzip9KiB /Brotli11KiB /post-GC JSheapMiB. Controls inthistable are retained07a.

|Family|Control Native|Final Native|Control ELK|Final ELK|
|---|---|---|---|---|
|flowchart|41 / 1166.9 / 387.7 / 330.6 / 5.73|41 / 1149.7 / 382.8 / 327.2 / 5.62|31 / 2383.9 / 737.8 / 584.5 / 10.77|31 / 2366.7 / 732.9 / 581.1 / 10.67|
|sequence|15 / 691.2 / 222.2 / 185.6 / 4.87|15 / 674.0 / 217.3 / 182.1 / 4.76|15 / 691.2 / 222.2 / 185.6 / 4.87|15 / 674.0 / 217.3 / 182.1 / 4.76|
|state|37 / 1165.8 / 386.8 / 329.8 / 5.54|37 / 1148.6 / 382.0 / 326.4 / 5.43|27 / 2382.8 / 736.9 / 583.7 / 10.58|27 / 2365.6 / 732.0 / 580.3 / 10.47|
|class|36 / 958.3 / 316.6 / 267.9 / 5.12|36 / 941.1 / 311.8 / 264.6 / 5.02|23 / 2172.7 / 664.8 / 519.9 / 9.61|23 / 2155.5 / 659.9 / 516.4 / 9.50|
|er|37 / 1056.7 / 350.4 / 297.7 / 5.02|37 / 1039.5 / 345.6 / 294.3 / 4.91|25 / 2265.5 / 696.6 / 548.1 / 9.56|25 / 2248.3 / 691.7 / 544.7 / 9.45|
|timeline|11 / 633.3 / 203.7 / 168.9 / 4.23|11 / 616.1 / 198.8 / 165.4 / 4.13|11 / 633.3 / 203.7 / 168.9 / 4.24|11 / 616.1 / 198.8 / 165.4 / 4.13|
|journey|12 / 653.8 / 210.9 / 175.5 / 5.00|12 / 636.6 / 206.0 / 172.0 / 4.90|12 / 653.8 / 210.9 / 175.5 / 5.01|12 / 636.6 / 206.0 / 172.0 / 4.90|
|architecture|38 / 1146.2 / 378.6 / 322.1 / 5.23|38 / 1129.0 / 373.7 / 318.8 / 5.12|28 / 2363.2 / 728.6 / 576.0 / 10.65|28 / 2346.0 / 723.8 / 572.6 / 10.55|
|xychart|15 / 675.5 / 218.3 / 181.9 / 4.88|15 / 658.3 / 213.5 / 178.4 / 4.76|15 / 675.5 / 218.3 / 181.9 / 4.88|15 / 658.3 / 213.5 / 178.4 / 4.76|
|pie|17 / 645.6 / 210.4 / 174.9 / 4.19|17 / 628.4 / 205.5 / 171.4 / 4.09|17 / 645.6 / 210.4 / 174.9 / 4.19|17 / 628.4 / 205.5 / 171.4 / 4.09|
|quadrant|14 / 642.6 / 208.0 / 172.7 / 4.40|14 / 625.4 / 203.1 / 169.2 / 4.29|14 / 642.6 / 208.0 / 172.7 / 4.40|14 / 625.4 / 203.1 / 169.2 / 4.30|
|gantt|11 / 659.6 / 212.8 / 177.2 / 4.45|11 / 642.4 / 207.9 / 173.6 / 4.34|11 / 659.6 / 212.8 / 177.2 / 4.45|11 / 642.4 / 207.9 / 173.6 / 4.34|
|mindmap|16 / 649.1 / 212.5 / 176.7 / 4.50|16 / 631.9 / 207.6 / 173.2 / 4.39|16 / 649.1 / 212.5 / 176.7 / 4.50|16 / 631.9 / 207.6 / 173.2 / 4.40|
|gitgraph|14 / 648.0 / 210.5 / 174.9 / 4.60|14 / 630.8 / 205.6 / 171.4 / 4.49|14 / 648.0 / 210.5 / 174.9 / 4.60|14 / 630.8 / 205.6 / 171.4 / 4.49|
|radar|16 / 651.8 / 212.2 / 176.5 / 4.35|16 / 634.6 / 207.3 / 173.0 / 4.24|16 / 651.8 / 212.2 / 176.5 / 4.34|16 / 634.6 / 207.3 / 173.0 / 4.24|
|sankey|14 / 652.9 / 211.4 / 175.8 / 4.48|14 / 635.7 / 206.5 / 172.4 / 4.37|14 / 652.9 / 211.4 / 175.8 / 4.48|14 / 635.7 / 206.5 / 172.4 / 4.37|
|c4|22 / 854.9 / 278.1 / 234.3 / 5.42|22 / 837.7 / 273.3 / 230.9 / 5.29|22 / 854.9 / 278.1 / 234.3 / 5.41|22 / 837.7 / 273.3 / 230.9 / 5.30|
|packet|12 / 621.0 / 200.7 / 166.3 / 4.22|12 / 603.8 / 195.8 / 162.8 / 4.11|12 / 621.0 / 200.7 / 166.3 / 4.22|12 / 603.8 / 195.8 / 162.8 / 4.11|
|kanban|13 / 629.4 / 204.1 / 169.3 / 4.33|13 / 612.2 / 199.2 / 165.8 / 4.23|13 / 629.4 / 204.1 / 169.3 / 4.33|13 / 612.2 / 199.2 / 165.8 / 4.23|
|requirement|31 / 873.5 / 289.5 / 244.7 / 5.19|31 / 856.3 / 284.6 / 241.4 / 5.08|16 / 2064.5 / 629.5 / 489.4 / 9.74|16 / 2047.3 / 624.6 / 486.0 / 9.63|
|treemap|14 / 639.5 / 208.5 / 173.3 / 4.25|14 / 622.3 / 203.6 / 169.9 / 4.15|14 / 639.5 / 208.5 / 173.3 / 4.25|14 / 622.3 / 203.6 / 169.9 / 4.15|
|ishikawa|13 / 622.6 / 201.2 / 166.7 / 4.73|13 / 605.4 / 196.3 / 163.3 / 4.63|13 / 622.6 / 201.2 / 166.7 / 4.73|13 / 605.4 / 196.3 / 163.3 / 4.63|
|block|18 / 796.3 / 259.4 / 217.7 / 4.69|18 / 779.1 / 254.5 / 214.3 / 4.57|18 / 796.3 / 259.4 / 217.7 / 4.69|18 / 779.1 / 254.5 / 214.3 / 4.58|
|eventmodeling|11 / 629.7 / 203.2 / 168.5 / 4.86|11 / 612.5 / 198.3 / 165.0 / 4.75|11 / 629.7 / 203.2 / 168.5 / 4.86|11 / 612.5 / 198.3 / 165.0 / 4.74|
|zenuml|14 / 704.9 / 227.3 / 190.2 / 4.89|14 / 687.7 / 222.4 / 186.7 / 4.78|14 / 704.9 / 227.3 / 190.2 / 4.89|14 / 687.7 / 222.4 / 186.7 / 4.78|
|railroad|13 / 637.8 / 206.2 / 171.2 / 4.31|13 / 620.6 / 201.3 / 167.7 / 4.19|13 / 637.8 / 206.2 / 171.2 / 4.31|13 / 620.6 / 201.3 / 167.7 / 4.19|
|cynefin|13 / 625.9 / 202.5 / 167.9 / 4.57|13 / 608.7 / 197.6 / 164.4 / 4.45|13 / 625.9 / 202.5 / 167.9 / 4.57|13 / 608.7 / 197.6 / 164.4 / 4.45|
|agentflow|40 / 1296.3 / 429.2 / 367.4 / 6.12|40 / 1279.1 / 424.3 / 364.1 / 6.02|30 / 2513.3 / 779.3 / 621.3 / 11.21|30 / 2496.1 / 774.4 / 617.9 / 11.11|
|usecase|35 / 1133.0 / 375.5 / 319.5 / 5.54|35 / 1115.8 / 370.7 / 316.2 / 5.43|26 / 2350.3 / 725.8 / 573.6 / 10.52|26 / 2333.1 / 721.0 / 570.2 / 10.41|
|wardley|15 / 653.7 / 211.6 / 176.1 / 4.71|15 / 636.5 / 206.7 / 172.7 / 4.60|15 / 653.7 / 211.6 / 176.1 / 4.71|15 / 636.5 / 206.7 / 172.7 / 4.60|
|venn|12 / 634.7 / 205.9 / 171.0 / 4.17|12 / 617.5 / 201.0 / 167.5 / 4.06|12 / 634.7 / 205.9 / 171.0 / 4.17|12 / 617.5 / 201.0 / 167.5 / 4.06|
|swimlane|38 / 1174.5 / 390.6 / 333.3 / 5.61|38 / 1157.3 / 385.8 / 330.0 / 5.50|38 / 1174.5 / 390.6 / 333.3 / 5.61|38 / 1157.3 / 385.8 / 330.0 / 5.50|
|treeview|14 / 630.4 / 204.7 / 169.7 / 4.14|14 / 613.2 / 199.8 / 166.3 / 4.03|14 / 630.4 / 204.7 / 169.7 / 4.14|14 / 613.2 / 199.8 / 166.3 / 4.03|

Identity: immutablecandidate/control views checked forsamedevice/inode withfrozenbuild files;350recent07a/9109fetchedfiles and332historical599/Mainfetchedfiles rehashed againstretainedmanifest SHA256. Samebytequalificationhelper `0201ef6ba4287de67684b0ee65a3ee049be3140709c477262bf21e36c8de8901`. Additionalstyledcontrolfiles rehashed separately. CASES/sources/artifacts/metadata remain in ../IDENTITY.json andeachARTIFACT/DELIVERY.

Files: FAMILY-PAYLOAD.csv actualcandidate66 plusretained07acontrol66 clearlyseparate; NET-COMPARISON.csv all264baseline/backend/family deltas; PRODUCT-COMPARISON.json fullbefore/afterproofvectors; AFFECTED-PRODUCTS.json20-product subset/stylequalification; SUMMARY.json allunknowns/adverse ranges. RawcandidateRESULTS.json remains66freshobservations. Every publicproduct/SVG/receipt andactualfetchgraph retained.
