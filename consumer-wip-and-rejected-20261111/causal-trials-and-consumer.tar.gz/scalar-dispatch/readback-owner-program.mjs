
const descriptor = Object.getOwnPropertyDescriptor
let target, reads = 0
Object.getOwnPropertyDescriptor = function(value, key) {
  const found = descriptor(value, key)
  if (value !== target || key !== 'metadata' || !found) return found
  return new Proxy(found, { get(record, field, receiver) {
    if (field === 'value') return ++reads === 1 ? 0 : record.value
    return Reflect.get(record, field, receiver)
  } })
}
const { createOriginalNativePaintEmission } = await import('./src/scene/native-paint-emission.ts')
const marks = await import('./src/scene/marks.ts')
const { writeShapeSvg } = await import('./src/scene/svg-writer.ts')
const emission = createOriginalNativePaintEmission(400000)
const actualChild = { retained: 'Read' }
target = marks.shape({ id: 'readback', role: 'node', geometry: { kind: 'rect', x: 0, y: 0, width: 10, height: 10 }, paint: { fill: '#111' } })
Object.defineProperty(target, 'metadata', { value: actualChild, enumerable: true })
let writerSawUnclosedChild = false
const retained = emission.leaf(target, source => {
  writerSawUnclosedChild = !Object.isFrozen(source.metadata)
  return writeShapeSvg(source, undefined, emission.xml)
}, emission.xml)
console.log(JSON.stringify({ svg: retained.svg, expected: writeShapeSvg(target), conditional: retained.conditional, writerSawUnclosedChild, reads }))
