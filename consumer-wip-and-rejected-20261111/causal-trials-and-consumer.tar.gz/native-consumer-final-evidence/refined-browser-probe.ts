import {readFileSync,writeFileSync} from 'node:fs'
import {createRequire} from 'node:module'
import {join} from 'node:path'
const root=process.argv[2]??'/dev/shm/pr449-four-final-20261111/native-consumer-final',out=import.meta.dir,tag=process.argv[3]??'candidate'
const require=createRequire(root+'/package.json'),{chromium}=require('playwright')
const source=readFileSync(root+'/eval/layout-compare/fixtures/cyclic-labelled-15.mmd','utf8'),options={graphLayout:{backend:'agentic'},security:'strict',mermaidConfig:{flowchart:{nodeSpacing:-1}}}
const meta=JSON.parse(readFileSync(root+'/dist/metafile-esm.json','utf8'))
const spi=Object.entries(meta.outputs).find(([p,v]:any)=>p.includes('scene-backend-runtime-')&&v.entryPoint)?.[0]

const server=Bun.serve({hostname:'127.0.0.1',port:0,fetch(req){const url=new URL(req.url);if(url.pathname==='/favicon.ico')return new Response(null,{status:204});if(url.pathname==='/blank.html')return new Response('<!doctype html>',{headers:{'content-type':'text/html'}});return new Response(Bun.file(join(root,url.pathname)),{headers:{'content-type':'text/javascript'}})}})
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});let closed=0
try{const rows=[];for(const preload of spi?[false,true]:[false]){const page=await browser.newPage();const requests:string[]=[];page.on('request',r=>requests.push(new URL(r.url()).pathname));try{await page.goto(`http://127.0.0.1:${server.port}/blank.html`);const products=await page.evaluate(async({entry,spi,source,options,preload})=>{if(preload){const sdk=await import(spi);void sdk.DefaultBackend.conformance}const api=await import(entry);const output=[];for(let i=0;i<2;i++)output.push(await api.renderMermaidSVGWithReceiptAsync(source,options));return output},{entry:`http://127.0.0.1:${server.port}/dist/browser-lazy/index.js`,spi:`http://127.0.0.1:${server.port}/`+spi,source,options,preload});rows.push({preload,requests,products});console.log(JSON.stringify({preload,operations:products.map(p=>p.receipt.layoutCertification?.checks.operations)}))}finally{await page.close();closed++}}writeFileSync(out+'/REFINED-BROWSER-PROBE-'+tag+'.json',JSON.stringify({spi,rows},null,2))}finally{await browser.close();server.stop(true);writeFileSync(out+'/REFINED-BROWSER-CLOSED-'+tag+'.json',JSON.stringify({pagesClosed:closed,open:0}))}
