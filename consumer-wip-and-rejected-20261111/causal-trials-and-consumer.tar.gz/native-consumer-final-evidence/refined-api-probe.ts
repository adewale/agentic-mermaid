import {readFileSync,writeFileSync} from 'node:fs'
const root='/dev/shm/pr449-four-final-20261111/native-consumer-final'
const api=process.argv[2]!
const source=readFileSync(root+'/eval/layout-compare/fixtures/cyclic-labelled-15.mmd','utf8')
const options={graphLayout:{backend:'agentic' as const},security:'strict' as const,mermaidConfig:{flowchart:{nodeSpacing:-1}}}
const diagnostics:any[]=[]
const module=await import(root+(api==='sdk'?'/src/index.ts':'/src/browser-lazy.ts'))
const product=api==='sdk'?module.renderMermaidSVGWithReceipt(source,{...options,onConfigDiagnostic:(d:any)=>diagnostics.push(d)}):await module.renderMermaidSVGWithReceiptAsync(source,{...options,onConfigDiagnostic:(d:any)=>diagnostics.push(d)})
const result={api,operations:product.receipt.layoutCertification?.checks.operations,product:JSON.parse(JSON.stringify(product)),diagnostics};writeFileSync(import.meta.dir+'/refined-'+api+'.json',JSON.stringify(result));console.log(JSON.stringify({api,operations:result.operations,status:product.receipt.layoutCertification?.status}))
