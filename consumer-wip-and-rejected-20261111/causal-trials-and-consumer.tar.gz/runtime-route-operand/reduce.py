from pathlib import Path
import json,gzip,statistics,math
out=Path('/dev/shm/pr449-four-final-20261111/runtime-route-operand')
receipt=[json.loads(x) for x in (out/'receipt-performance/results.jsonl').read_text().splitlines()];svg=[json.loads(x) for x in (out/'performance/results.jsonl').read_text().splitlines()]
def stats(values,processes=None):
 a=sorted(values);v={'median':statistics.median(a),'p95':a[math.ceil(.95*len(a))-1],'range':[a[0],a[-1]],'samples':values}
 if processes is not None:v.update(medianOfProcessMedians=statistics.median(processes),processMedians=processes)
 return v
rows={};errors=[]
for target in ['control','candidate']:
 r=sorted([r for r in receipt if r['target']==target],key=lambda x:x['replica']);s=[x['result'] for x in svg if x['target']==target];raw=[];proofs=[]
 for x in r:
  data=x['data'];ph=data['rows'];lookup={v['phase']:v for v in ph}
  if any(p['status']!='returned' for p in ph):errors.append(x)
  proofs.extend(p.get('proof') for p in ph)
  raw.append({'replica':x['replica'],'importMs':data['importMs'],'coldMs':lookup['cold-render']['wallMs'],'repeatMs':[lookup['repeat'+str(i)]['wallMs'] for i in range(1,5)],'edit1Ms':lookup['edit1']['wallMs'],'editRepeatMs':[lookup['edit'+str(i)]['wallMs'] for i in range(2,5)],'peakRssMiB':max(p['peakRssKiB'] for p in ph)/1024,'heapAfterEdit4MiB':lookup['edit4']['after']['heapUsed']/1024**2,'proofs':proofs[-len(ph):]})
 row={key:stats([p[key] for p in raw]) for key in ['importMs','coldMs','edit1Ms','peakRssMiB','heapAfterEdit4MiB']}
 for key in ['repeatMs','editRepeatMs']:row[key]=stats([v for p in raw for v in p[key]],[statistics.median(p[key]) for p in raw])
 row['tracks']={k:stats([v for p in s for v in p['tracks'][k]],[statistics.median(p['tracks'][k]) for p in s]) for k in ['warm-repeat','warm-new-source','warm-label-edit']}
 row['stockStatuses']=[p['status'] for p in s];row['stockOutputBytes']=[p['outputBytes'] for p in s];row['rawReceiptProcesses']=raw;row['proofsPassed']=all(p and p['status']=='passed' and p['checks']['maxOperations']==400000 and p['checks']['maxOcclusionPairs']==100000 for p in proofs)
 rows[target]=row
pairs=[]
for rep in range(3):
 stem=lambda target:f'cache0-{target}-agentic-diagnostic_chain100-{rep}'
 for phase in ['warmup','repeat1','repeat2','repeat3','repeat4','edit1','edit2','edit3','edit4']:
  def load(target,kind):return gzip.decompress((out/'receipt-performance'/stem(target)/(phase+'.'+kind+'.gz')).read_bytes())
  a=json.loads(load('control','receipt.json'));b=json.loads(load('candidate','receipt.json'));pa=a.pop('layoutCertification');pb=b.pop('layoutCertification');wa=pa['checks'].pop('operations');wb=pb['checks'].pop('operations')
  pairs.append({'replica':rep,'phase':phase,'SVGExact':load('control','svg')==load('candidate','svg'),'nonCertificationReceiptExact':a==b,'proofExceptOperationsExact':pa==pb,'operations':[wa,wb]})
comparison={'receiptPairs':len(pairs),'wholeSVGExact':all(p['SVGExact'] for p in pairs),'nonCertificationReceiptExact':all(p['nonCertificationReceiptExact'] for p in pairs),'proofExceptOperationsExact':all(p['proofExceptOperationsExact'] for p in pairs),'allProofsPassedCapsUnchanged':all(r['proofsPassed'] for r in rows.values()),'pairs':pairs}
summary={'identity':str(out/'IDENTITY.json'),'closedWorkers':{'receipt':len(receipt),'SVG':len(svg)},'rows':rows,'comparisons':comparison,'errors':errors,'protocol':'Same existing chain100/agentic/cache0 receipt and stockSVG protocols; three fresh processes per arm, actual fullproduct consumed, no profiling/loaders. Native work delta is real removed capture, not relaxed caps. All samples and phase separation retained.'}
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'workers':summary['closedWorkers'],'comparisons':{k:v for k,v in comparison.items() if k!='pairs'},'arms':{t:{'fullRepeat':r['repeatMs']['medianOfProcessMedians'],'fullRepeatP95':r['repeatMs']['p95'],'SVGRepeat':r['tracks']['warm-repeat']['medianOfProcessMedians'],'SVGRepeatP95':r['tracks']['warm-repeat']['p95'],'cold':r['coldMs']['median'],'edit1':r['edit1Ms']['median'],'rss':r['peakRssMiB']['median'],'heapEdit4':r['heapAfterEdit4MiB']['median']} for t,r in rows.items()}},indent=2))
