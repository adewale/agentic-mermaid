import {readFileSync,writeFileSync} from 'node:fs';import {gzipSync}from'node:zlib'
const root='/dev/shm/pr449-four-final-20261111/marker-operand-candidate',primary='/tmp/pr449-main-integration-20261029-762',out=import.meta.dir,arm=process.argv[2],which=process.argv[3]
const paths=['src/layout-rubric.ts','src/layout/legacy-completion.ts','src/layout/measured-graph-producer.ts']
;(globalThis as any).counts={assess:0,edgeNodes:0,nodePairs:0,shape:0}
Bun.plugin({name:'rubric-enumeration',setup(build){build.onLoad({filter:/\/src\/(layout-rubric|layout\/(legacy-completion|measured-graph-producer))\.ts$/},args=>{
 const rel=paths.find(p=>args.path===root+'/'+p);if(!rel)return
 let s=readFileSync((arm==='candidate'?primary:root)+'/'+rel,'utf8')
 if(rel==='src/layout-rubric.ts'){
 s=s.replace('  // Built without severity, then enriched + sorted by impact at the return.','  ;(globalThis as any).counts.assess++;\n  // Built without severity, then enriched + sorted by impact at the return.')
 s=s.replace('export function segmentThroughShape(a: Point, b: Point, node: PositionedNode): boolean {','export function segmentThroughShape(a: Point, b: Point, node: PositionedNode): boolean { (globalThis as any).counts.shape++;')
 if(arm==='candidate')s=s.replace('    for (const node of candidates ?? positioned.nodes) {','    for (const node of candidates ?? positioned.nodes) { (globalThis as any).counts.edgeNodes++;').replace('  const inspectPair = (a: PositionedNode, b: PositionedNode): void => {','  const inspectPair = (a: PositionedNode, b: PositionedNode): void => { (globalThis as any).counts.nodePairs++;')
 else s=s.replace('    for (const node of positioned.nodes) {','    for (const node of positioned.nodes) { (globalThis as any).counts.edgeNodes++;').replace('      const a = positioned.nodes[i]!, b = positioned.nodes[j]!','      ;(globalThis as any).counts.nodePairs++; const a = positioned.nodes[i]!, b = positioned.nodes[j]!')
 }return{contents:s,loader:'ts'}
})}})
const cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/shared-four-fixes-20261111/task1/inplace-closure-ceiling/capacity/EXISTING-CASES.json','utf8')),c=cases.find((x:any)=>x.name===which)
if(!c)throw new Error('Unknown case '+which+' '+cases.map((x:any)=>x.name))
const api=await import(root+'/src/index.ts');const result=api.renderMermaidSVGWithReceipt(c.source,{graphLayout:{backend:'agentic',fallback:'none'}});const product=JSON.stringify(result)
writeFileSync(out+'/'+arm+'-'+which+'.json.gz',gzipSync(product));const row={arm,which,counts:(globalThis as any).counts,proof:result.receipt.layoutCertification};writeFileSync(out+'/'+arm+'-'+which+'-COUNTS.json',JSON.stringify(row,null,2));console.log(JSON.stringify(row))
