# Final9109 lazy-browser delivery

Candidate `9109d4373035cc1c18f395ac0e19dfdbba9e73fc`; retained control `07a51fc9e1c06902fdf851abc1b05b9aa838e531`; Trident `f080278e31e4202ca89d524e4ee9e4cf3cbff038`.

66/66 fresh candidate family/backend observations qualify, retaining132 full public SVG/receipt products. All66 browsers closed;0 open;0 observer/module-fetch errors. The66 control observations are retained from the earlier run and were not replayed. Earlier AE results remain separate.

All132 candidate SVGs and non-certification receipt fields equal control and PR599 exactly. All132 proof statuses and layout decisions match. Whole receipts equal8/132 because certification charges differ.124 proofs pass;8 remain unverified: Timeline and XYChart support/enrolled calls on both requested backends, each with OUTPUT_SCOPE.25 families have no recorded graph-layout decision; a requested backend label alone does not establish its application.

Against control, every family closure grows. Native median deltas: raw+1079B, gzip9+314B, Brotli11+221B; ELK:+1079/+317/+223B. All66 request counts are unchanged. Heap is mixed: Native22 lower/11 higher (median−564B, adverse maximum+8084B); ELK19 lower/1 equal/13 higher (median−716B, adverse maximum+6628B).

Against retained PR599,32/33 closures per backend shrink (median gzip9−1679B); Agentflow grows+5406B Native/+5411B ELK gzip9. Every heap sample remains higher: medians+55836B/+56840B. Against retained Main426, all closures remain larger (median gzip9+41665B both backends), and all heap samples remain higher.132/132 SVGs equal PR599;124/132 equal Main, with ER/Requirement differences retained.

Fresh realm per family with mandatory same-family support probe followed by the enrolled source; full public WithReceiptAsync return serialized and retained. Actual fetched module responses compressed separately offline at gzip9/Brotli11; binding bytes separate in CSV. Heap is forced-GC JavaScript heap, not RSS/native/WASM/leak evidence. No API-time, compressed-wire, whole-package, warm-portfolio-sum or complete-authored-meaning claim. Existing demo/async/standalone CI budget failures remain open; this observer does not replace or relax those checks.

Each cell: requests / product raw KiB / gzip9 KiB / Brotli11 KiB / post-GC JS heap MiB. Do not sum fresh-family closures as a warm portfolio.

|Family|Control Native|Final Native|Control ELK|Final ELK|
|---|---|---|---|---|
|flowchart|41 / 1166.9 / 387.7 / 330.6 / 5.73|41 / 1168.0 / 388.0 / 330.8 / 5.73|31 / 2383.9 / 737.8 / 584.5 / 10.77|31 / 2385.0 / 738.1 / 584.7 / 10.78|
|sequence|15 / 691.2 / 222.2 / 185.6 / 4.87|15 / 692.2 / 222.5 / 185.8 / 4.87|15 / 691.2 / 222.2 / 185.6 / 4.87|15 / 692.2 / 222.5 / 185.8 / 4.87|
|state|37 / 1165.8 / 386.8 / 329.8 / 5.54|37 / 1166.9 / 387.1 / 330.0 / 5.54|27 / 2382.8 / 736.9 / 583.7 / 10.58|27 / 2383.9 / 737.2 / 583.9 / 10.58|
|class|36 / 958.3 / 316.6 / 267.9 / 5.12|36 / 959.4 / 316.9 / 268.2 / 5.12|23 / 2172.7 / 664.8 / 519.9 / 9.61|23 / 2173.8 / 665.1 / 520.1 / 9.60|
|er|37 / 1056.7 / 350.4 / 297.7 / 5.02|37 / 1057.8 / 350.7 / 297.8 / 5.02|25 / 2265.5 / 696.6 / 548.1 / 9.56|25 / 2266.6 / 696.9 / 548.3 / 9.55|
|timeline|11 / 633.3 / 203.7 / 168.9 / 4.23|11 / 634.3 / 204.0 / 169.1 / 4.24|11 / 633.3 / 203.7 / 168.9 / 4.24|11 / 634.3 / 204.0 / 169.1 / 4.24|
|journey|12 / 653.8 / 210.9 / 175.5 / 5.00|12 / 654.8 / 211.2 / 175.7 / 5.01|12 / 653.8 / 210.9 / 175.5 / 5.01|12 / 654.8 / 211.2 / 175.7 / 5.01|
|architecture|38 / 1146.2 / 378.6 / 322.1 / 5.23|38 / 1147.2 / 378.8 / 322.3 / 5.23|28 / 2363.2 / 728.6 / 576.0 / 10.65|28 / 2364.2 / 729.0 / 576.2 / 10.65|
|xychart|15 / 675.5 / 218.3 / 181.9 / 4.88|15 / 676.6 / 218.7 / 182.1 / 4.86|15 / 675.5 / 218.3 / 181.9 / 4.88|15 / 676.6 / 218.7 / 182.1 / 4.86|
|pie|17 / 645.6 / 210.4 / 174.9 / 4.19|17 / 646.6 / 210.7 / 175.1 / 4.19|17 / 645.6 / 210.4 / 174.9 / 4.19|17 / 646.6 / 210.7 / 175.1 / 4.19|
|quadrant|14 / 642.6 / 208.0 / 172.7 / 4.40|14 / 643.7 / 208.4 / 173.0 / 4.39|14 / 642.6 / 208.0 / 172.7 / 4.40|14 / 643.7 / 208.4 / 173.0 / 4.39|
|gantt|11 / 659.6 / 212.8 / 177.2 / 4.45|11 / 660.7 / 213.1 / 177.4 / 4.45|11 / 659.6 / 212.8 / 177.2 / 4.45|11 / 660.7 / 213.1 / 177.4 / 4.45|
|mindmap|16 / 649.1 / 212.5 / 176.7 / 4.50|16 / 650.1 / 212.8 / 176.9 / 4.50|16 / 649.1 / 212.5 / 176.7 / 4.50|16 / 650.1 / 212.8 / 176.9 / 4.50|
|gitgraph|14 / 648.0 / 210.5 / 174.9 / 4.60|14 / 649.0 / 210.8 / 175.1 / 4.60|14 / 648.0 / 210.5 / 174.9 / 4.60|14 / 649.0 / 210.8 / 175.1 / 4.59|
|radar|16 / 651.8 / 212.2 / 176.5 / 4.35|16 / 652.9 / 212.5 / 176.7 / 4.34|16 / 651.8 / 212.2 / 176.5 / 4.34|16 / 652.9 / 212.5 / 176.7 / 4.34|
|sankey|14 / 652.9 / 211.4 / 175.8 / 4.48|14 / 653.9 / 211.7 / 176.1 / 4.48|14 / 652.9 / 211.4 / 175.8 / 4.48|14 / 653.9 / 211.7 / 176.1 / 4.48|
|c4|22 / 854.9 / 278.1 / 234.3 / 5.42|22 / 856.0 / 278.4 / 234.5 / 5.40|22 / 854.9 / 278.1 / 234.3 / 5.41|22 / 856.0 / 278.4 / 234.5 / 5.40|
|packet|12 / 621.0 / 200.7 / 166.3 / 4.22|12 / 622.0 / 201.0 / 166.5 / 4.22|12 / 621.0 / 200.7 / 166.3 / 4.22|12 / 622.0 / 201.0 / 166.5 / 4.22|
|kanban|13 / 629.4 / 204.1 / 169.3 / 4.33|13 / 630.5 / 204.4 / 169.5 / 4.33|13 / 629.4 / 204.1 / 169.3 / 4.33|13 / 630.5 / 204.4 / 169.5 / 4.33|
|requirement|31 / 873.5 / 289.5 / 244.7 / 5.19|31 / 874.5 / 289.8 / 244.9 / 5.19|16 / 2064.5 / 629.5 / 489.4 / 9.74|16 / 2065.6 / 629.8 / 489.7 / 9.75|
|treemap|14 / 639.5 / 208.5 / 173.3 / 4.25|14 / 640.5 / 208.8 / 173.5 / 4.25|14 / 639.5 / 208.5 / 173.3 / 4.25|14 / 640.5 / 208.8 / 173.5 / 4.25|
|ishikawa|13 / 622.6 / 201.2 / 166.7 / 4.73|13 / 623.6 / 201.5 / 166.9 / 4.73|13 / 622.6 / 201.2 / 166.7 / 4.73|13 / 623.6 / 201.5 / 166.9 / 4.73|
|block|18 / 796.3 / 259.4 / 217.7 / 4.69|18 / 797.3 / 259.7 / 218.0 / 4.69|18 / 796.3 / 259.4 / 217.7 / 4.69|18 / 797.3 / 259.7 / 218.0 / 4.69|
|eventmodeling|11 / 629.7 / 203.2 / 168.5 / 4.86|11 / 630.7 / 203.5 / 168.7 / 4.85|11 / 629.7 / 203.2 / 168.5 / 4.86|11 / 630.7 / 203.5 / 168.7 / 4.85|
|zenuml|14 / 704.9 / 227.3 / 190.2 / 4.89|14 / 705.9 / 227.6 / 190.5 / 4.88|14 / 704.9 / 227.3 / 190.2 / 4.89|14 / 705.9 / 227.6 / 190.5 / 4.88|
|railroad|13 / 637.8 / 206.2 / 171.2 / 4.31|13 / 638.8 / 206.5 / 171.4 / 4.31|13 / 637.8 / 206.2 / 171.2 / 4.31|13 / 638.8 / 206.5 / 171.4 / 4.31|
|cynefin|13 / 625.9 / 202.5 / 167.9 / 4.57|13 / 627.0 / 202.8 / 168.1 / 4.56|13 / 625.9 / 202.5 / 167.9 / 4.57|13 / 627.0 / 202.8 / 168.1 / 4.55|
|agentflow|40 / 1296.3 / 429.2 / 367.4 / 6.12|40 / 1297.4 / 429.5 / 367.6 / 6.13|30 / 2513.3 / 779.3 / 621.3 / 11.21|30 / 2514.4 / 779.6 / 621.5 / 11.22|
|usecase|35 / 1133.0 / 375.5 / 319.5 / 5.54|35 / 1134.0 / 375.8 / 319.7 / 5.54|26 / 2350.3 / 725.8 / 573.6 / 10.52|26 / 2351.4 / 726.1 / 573.8 / 10.52|
|wardley|15 / 653.7 / 211.6 / 176.1 / 4.71|15 / 654.7 / 211.9 / 176.3 / 4.70|15 / 653.7 / 211.6 / 176.1 / 4.71|15 / 654.7 / 211.9 / 176.3 / 4.70|
|venn|12 / 634.7 / 205.9 / 171.0 / 4.17|12 / 635.7 / 206.2 / 171.2 / 4.17|12 / 634.7 / 205.9 / 171.0 / 4.17|12 / 635.7 / 206.2 / 171.2 / 4.17|
|swimlane|38 / 1174.5 / 390.6 / 333.3 / 5.61|38 / 1175.6 / 390.9 / 333.5 / 5.61|38 / 1174.5 / 390.6 / 333.3 / 5.61|38 / 1175.6 / 390.9 / 333.5 / 5.61|
|treeview|14 / 630.4 / 204.7 / 169.7 / 4.14|14 / 631.5 / 205.0 / 170.0 / 4.14|14 / 630.4 / 204.7 / 169.7 / 4.14|14 / 631.5 / 205.0 / 170.0 / 4.14|

Each final engine view contains94 hardlinked build files sharing device/inode with the frozen build. Retained control views remain byte-identical.332 distinct historical fetched files were rehashed against retained manifests; helper SHA256 `0201ef6ba4287de67684b0ee65a3ee049be3140709c477262bf21e36c8de8901` is unchanged. Historical baselines were not rerun.

Files: FAMILY-PAYLOAD.csv includes fresh candidate and clearly labeled retained control rows; NET-COMPARISON.csv retains every raw/gzip9/Brotli11/request/heap delta against control/PR599/Main; PRODUCT-COMPARISON.json records exact product comparisons; SUMMARY.json retains full unknown proofs, issues, ranges and identities. Candidate-only RESULTS.json and all132 full products remain retained.
