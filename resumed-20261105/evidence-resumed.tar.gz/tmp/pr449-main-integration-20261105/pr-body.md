Integrate the retained PR449 Native layout and SVG-emission foundation, including the November recovery fixes, with current `main`. This preserves authored text and endpoint ink, delivers previously refused Class/ER cases, and reduces wasted space in selected Native layouts.

This **draft now targets `main`**. Merge `fa85d8123eebdbc1194298f3ae3fe17ce9711453` retains recovery head `e057d987ab8f73e84cf7d8a59b4c853dcf545249` and main `f9ec8c115de14020d3c182d5d7f2e7e70bfcdefb` as parents. The resulting scope is 168 files and includes inherited ownership/capture APIs; it is larger than the earlier 60-file recovery-only comparison. Main's 0.5.7 identity, pinned CI workflow and backend default remain intact. No release, publication or allowance increase is introduced.

Current head `99ed1d23853661966448ee9ee47c560cab910e63` fixes an introduced integration regression: a replacement ambient `Object.freeze` could alter a private copied point. Two independently authored owner controls fail before repair; all 20 relevant capture/text/depth/budget/revocation controls pass with the existing captured sealing function. This establishes snapshot custody; it is not an independent final-ink proof.

The owner resumed the campaign on 5 November, authorizing regular commits/pushes through **2026-11-08T23:59:59Z**. Continuation uses fresh leases and bounded sessions. Final-head CI and whole-repository qualification remain incomplete; this PR is not ready to merge.

## Changes and contract

Authored identities, parents, relationship occurrences, text and marker ends must survive into the final SVG and contribute their intended ink. Delivery, visible correctness and proof availability are assessed separately.

- Class caption seating restores the enrolled nested-caption cases from 6/8 to 8/8. Reusing the owned Scene and publishing the actual final coordinates allow Class128 certification in all four directions.
- ER terminal allocation and caption-prefix reuse remove the reproduced 192/207/208 delivery refusals. Owned Scene reuse lets ER208 complete certification without changing its SVG. Native isolates now use the existing 20px ER component clearance unless the author explicitly requests spacing; connected spacing remains 70px.
- Measured forest placement reduces the enrolled Native result's area by 26.98% and wire by 33.80%. Requirement terminal seats reserve painted marker pitch and normal clearance.
- Shared emission preserves formatting across hard breaks and protects inspection/ownership records from the reproduced mutations and interposed lookups. Flowchart terminal paint reuses captured geometry so wide shafts no longer absorb the enrolled hollow circles, including raw orthogonal and STEP carriers.

The [handoff](https://github.com/adewale/agentic-mermaid/blob/99ed1d23853661966448ee9ee47c560cab910e63/docs/design/system/layout-0.6-work-log.md) records revisions, retained costs, stopped causes and remaining losses. Combined conflict resolution preserves actual served-contour authority alongside main's optional hull query, private copy/provenance checks alongside scalar constructors, and whole-label detection alongside multiline formatting. An extended owner RED→GREEN covers a tagless middle line and uppercase UTF16 source ranges.

## Remaining delta from ELK

These are retained same-input measurements at the recorded pre-integration revisions. They are historical reference rows until the combined candidate is requalified; they do not establish a complete peer ranking.

| Workload | Native relative to ELK | Remaining cause or tradeoff |
| --- | --- | --- |
| Sparse256: 256 cards, one relationship | Area **+5.04%**: 3,633,619.5 vs 3,459,200. Wire 132.598 vs 214.598. | Default isolate spacing removed 51.22% of the previous Native area; the former +115.35% deficit is historical. Residual shelf packing remains. |
| Nonlinear forest | Wire **+16.89%**; area **−6.43%**. | Fixed-dock routes are already shortest. Inspect placement and terminal seating; a stopped leaf-seat trial increased area 6.88%. |
| Requirement cycle | TB/BT area **+9.53%**; LR/RL **−1.44%**. | The directional placement loss remains. |

The ER256 relationship chain still refuses in **both** backends. Sparse32 delivers its 1,500 text records and 32 contributing markers but remains unverified at the 400,000-operation cap. Middle-glyph attribution, general readability and arbitrary fonts remain unknown. The original `campaign-baseline2dadf0dbc2685c8435df541de99f3edce841450d`, Trident and pinned Mermaid12.2/Pele1.9 were unavailable after recovery; Replacement24 remains sealed.

An unshipped backfill candidate reached +0.97% area but moved N255 above N2; it was stopped to retain predictable row-major packing. The implemented deficit remains +5.04%.

## Visual evidence

Claim: the same Sparse256 input occupies less canvas because independent cards use 20px painted clearance, while the connected N0→N1 geometry remains unchanged.

PR baseline SHA: `f9ec8c115de14020d3c182d5d7f2e7e70bfcdefb` (integrated main, not the pictured comparison).
Pictured before runtime: `99723bb5dd61762fc0a4e69eace569416ad8f9e0`, immediately before the spacing fix.
Pictured after runtime: `c93e0c51f37b1d9edabd81ad6404764eb1dff7e6`.
Current PR head SHA: `99ed1d23853661966448ee9ee47c560cab910e63`. This is dated pre-integration evidence for the spacing fix, not a fresh render of the integrated head.

| Before | After | What to inspect |
| --- | --- | --- |
| <img alt="Before: Sparse256 cards have wide empty gaps across a 2542 by 2930.5 canvas" src="https://raw.githubusercontent.com/adewale/agentic-mermaid/24f5f1ab972937d687691d5282b6cec04830c5b8/recovery-20261105/sparse256/before.png" width="340"> | <img alt="After: all 256 cards occupy a denser 1831 by 1984.5 canvas, with the N0 to N1 connection preserved" src="https://raw.githubusercontent.com/adewale/agentic-mermaid/24f5f1ab972937d687691d5282b6cec04830c5b8/recovery-20261105/sparse256/after.png" width="340"> | Inspect the empty space between independent cards and the unchanged relationship at the upper left. These are original zoom-1 artifacts displayed at equal thumbnail widths; open them for native dimensions. |

This pair isolates the later spacing fix within the branch. The [source, unchanged options, SVGs, receipts, raster binding and independent comparison](https://github.com/adewale/agentic-mermaid/tree/24f5f1ab972937d687691d5282b6cec04830c5b8/recovery-20261105/sparse256) are preserved outside the source diff. The before raster was reused only after whole-SVG and entire-receipt byte equality with its earlier checkpoint; the after raster was generated during the spacing qualification. No images were edited for this PR.

Independent check: [er-layout-backends.test.ts](https://github.com/adewale/agentic-mermaid/blob/e057d987ab8f73e84cf7d8a59b4c853dcf545249/src/__tests__/er-layout-backends.test.ts) checks identities, geometry, cardinality ownership, contacts and spacing overrides. Sampled N0/N255 header and cardinality ink remains. Limitation: the image and sampled ink do not establish every glyph's attribution, readability or arbitrary-font behavior.

Reproduce with Bun 1.4.2 and locked dependencies:

```sh
bun test src/__tests__/er-layout-backends.test.ts --test-name-pattern 'relationships among .* isolated entities' --timeout 60000
bun test src/__tests__/endpoint-marker-contact.test.ts src/__tests__/curved-connector-projection.test.ts --timeout 60000
```

## Verification and costs

Combined local checks on Bun1.4.4: core typing and conflict-file lint passed at the merge; final follow-up typing is running. The broad owner runs recorded 1,386 passes/18 failures and 366 passes/5 failures. All subprocess/esbuild sandbox failures and loaded-run timeouts passed permitted isolated requalification (13/13 and 14/14). The known Sparse32 400k proof failure remains enrolled. The new private-point owner is RED before repair (ordinary control passes, mutation/substitution controls fail) and GREEN after repair (20 relevant controls). CI has not been qualified.

The following costs and earlier verification remain attached to their original runtime revisions:

- `b32489e19`: owning raw-carrier negatives failed before repair; 384 tests in eight files, core types and lint passed after it. Circle contribution changed 0→225 confined pixels in both backends. Proof remains unverified, with 102 additional operations. Getter/descriptor regressions found during development were corrected; failed drafts are retained.
- `c93e0c51f`: the default-spacing assertion failed against the old policy, then passed. The seven-file milestone passed 144 tests, core types and lint. Two Node24 source and two compiled bindings matched complete SVG/receipt bytes. Proof stays passed at 90,546→91,015 operations with unchanged caps/pairs.

The whole repository suite and final-head CI are **not qualified**. Earlier broad checks retained 973 passes and the known Sparse32 failure at their own revision. A reliable five-hotspot performance report remains unfinished; the profile did not establish descriptor-Map causation.

The [handoff cost table](https://github.com/adewale/agentic-mermaid/blob/e057d987ab8f73e84cf7d8a59b4c853dcf545249/docs/design/system/layout-0.6-work-log.md#qualification-and-costs) retains the Sparse256 cold/repeat/edit observations, separately for cache 0/1, plus RSS, heap evidence and real payload sizes. Calls consume the whole SVG and entire receipt; imports and compression are separate. These are single samples after imports/initial GC and support no causal runtime speedup or cache-benefit claim. Native gzip SVG remains larger than ELK (13,323 vs 12,762 bytes), and the spacing fix adds 6 gzip / 15 Brotli code bytes.

## Recovery and remaining risk

The [GitHub backup and restore guide](https://github.com/adewale/agentic-mermaid/blob/24f5f1ab972937d687691d5282b6cec04830c5b8/recovery-20261105/README.md) preserves current source inputs, controllers, actual products, comparative costs, stopped patches and historical evidence snapshots. Source/tests are on this PR branch; evidence is on `review/pr449-evidence-20261105`. Fresh scratch restoration recovered all 5,122 current comparison files byte for byte and retained the stopped state; that check adds no runtime coverage. [Earlier STEP visuals](https://github.com/adewale/agentic-mermaid/tree/bcc799ccc362f71d63384eaa31a879d412cd74a2/pr449-step-wide-circle) retain their original revision.

The main remaining integration risks are inherited emission/validation behavior, the known Sparse32 proof failure, and any further changes on `main`. The updated scope needs final-head CI and current-product comparison before readiness is claimed. The original recovery checkpoint and all stopped experiments remain preserved.
