import {readFileSync,writeFileSync} from 'node:fs'
import {gunzipSync} from 'node:zlib'
import {createHash} from 'node:crypto'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import {prepareResvgMarkerOrientation} from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const repo='/tmp/pr449-main-integration-20261029-762',root='/tmp/pr449-week-comparison-20261101/elk-source-head-capacity-20261109'
const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const p=repo+'/'+f.path;if(createHash('sha256').update(readFileSync(p)).digest('hex')!==f.sha256)throw Error('font mismatch');return p})
const rows=[]
for(const arm of ['before']) for(const num of ['elk','agentic','trinity']) for(let selectedIndex=0;selectedIndex<10;selectedIndex++){
 const selected=`edge:T-&gt;s${selectedIndex}#0`,peer='all other target heads'
 const path='/tmp/pr449-week-comparison-20261101/native-thin-capacity-20261109/cohort-start-after/labelled-start-LR-10-'+num+'.svg.gz'
 const svg=gunzipSync(readFileSync(path)).toString(),carriers=[...svg.matchAll(/<polyline\b[^>]*\/>/g)].map(m=>m[0])
 const a=carriers.find(t=>t.includes('data-id="'+selected+'"'))!,b=a
 if(!a||!b)throw Error('selected occurrence missing')
 const point=(t:string)=>/points="([^"]+)"/.exec(t)![1]!.trim().split(/\s+/).at(0)!.split(',').map(Number),pa=point(a),pb=point(b),zoom=3
 const strip=(t:string)=>t.replace(/ marker-start="[^"]*"/,'')
 const noHeads=carriers.reduce((s,t)=>s.replace(t,strip(t)),svg),onlySelected=noHeads.replace(strip(a),a)
 const variants=[svg,svg.replace(a,strip(a)),onlySelected,noHeads]
 const images=variants.map(s=>new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(s)),{background:'#fff',fitTo:{mode:'zoom',value:zoom},font:{fontFiles:fonts,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render())
 if(selectedIndex===0)writeFileSync(root+'/'+arm+'-'+num+'-all-heads.png',images[0]!.asPng());const pixels=images.map(i=>i.pixels)
 const roi={x0:Math.floor((Math.min(pa[0]!,pb[0]!)-12)*zoom),x1:Math.ceil((Math.max(pa[0]!,pb[0]!)+12)*zoom),y0:Math.floor((Math.min(pa[1]!,pb[1]!)-12)*zoom),y1:Math.ceil((Math.max(pa[1]!,pb[1]!)+12)*zoom)}
 let exposed=0,visible=0,attenuated=0,hidden=0;const delta=(a:Uint8Array,b:Uint8Array,k:number)=>Math.abs(a[k]!-b[k]!)+Math.abs(a[k+1]!-b[k+1]!)+Math.abs(a[k+2]!-b[k+2]!)
 for(let y=roi.y0;y<roi.y1;y++)for(let x=roi.x0;x<roi.x1;x++){const k=(y*images[0]!.width+x)*4,e=delta(pixels[2]!,pixels[3]!,k),v=delta(pixels[0]!,pixels[1]!,k);if(e>=6){exposed++;if(v>=6)visible++;if(v+6<e)attenuated++;if(v<6)hidden++}}
 rows.push({case:num,arm,selected,peer,sha256:createHash('sha256').update(svg).digest('hex'),roi,exposed,visible,attenuated,hidden,actualSelected:a,actualPeer:b})
}
writeFileSync(root+'/ALL-HEADS-INK.json',JSON.stringify({font:'manifest-verified Inter; system fonts off',zoom:3,offlineRasters:4,scope:'Each selected head contribution with/without all other target heads; actual SVG geometry, not whole-diagram readability. Coordinates/raster phase differ between layouts.',rows},null,2)+'\n')
console.log(JSON.stringify(rows.map(({actualSelected,actualPeer,...r})=>r)))
