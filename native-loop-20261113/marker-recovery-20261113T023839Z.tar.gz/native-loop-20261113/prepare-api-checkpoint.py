"""Freeze closed root/audit changes while the implementation prototype is active."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import subprocess
import tarfile

root = Path('/workspace/pr449-native-loop-20261113')
repo = '/workspace/agentic-mermaid'
base = '0ca6cd302d302feb8de3a74b640167432dea3fb2'
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
old = {}
for row in subprocess.check_output(['git', '-C', repo, 'ls-tree', '-rz', base, '--', 'native-loop-20261113/']).split(b'\0'):
    if not row: continue
    meta, name = row.split(b'\t', 1)
    old[name.decode()] = meta.split()[2].decode()
changed = []
manifest = []
for path in sorted(root.rglob('*')):
    rel = path.relative_to(root)
    if not path.is_file() or path.is_symlink(): continue
    if len(rel.parts) > 1 and rel.parts[0] != 'audit': continue
    if path.name.startswith(('checkpoint-index-', 'marker-recovery-')) or path.name == 'CHECKPOINT.json': continue
    name = 'native-loop-20261113/' + rel.as_posix()
    data = path.read_bytes()
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if old.get(name) == blob: continue
    changed.append((name, data, path.stat().st_mode & 0o777))
    manifest.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
meta = {'at': stamp, 'parent': base, 'source': subprocess.check_output(['git', '-C', repo, 'rev-parse', 'HEAD']).decode().strip(),
    'status': 'unqualified compound work; actual marker collisions retained',
    'excluded_active_work': ['implementation/', 'marker-producer-prototype/', 'budget-trace/'], 'files': manifest}
archive = root / f'marker-recovery-{stamp}.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for name, data, mode in changed:
        entry = tarfile.TarInfo(name); entry.size = len(data); entry.mode = mode
        tar.addfile(entry, io.BytesIO(data))
    data = (json.dumps(meta, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('native-loop-20261113/API-MARKER-SNAPSHOT-MANIFEST.json'); entry.size = len(data)
    tar.addfile(entry, io.BytesIO(data))
result = {'archive': str(archive), 'archiveName': archive.name, 'bytes': archive.stat().st_size,
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': len(changed), 'parent': base,
    'baseTree': subprocess.check_output(['git', '-C', repo, 'rev-parse', base + '^{tree}']).decode().strip()}
(root / 'API-CHECKPOINT-PREPARED.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
