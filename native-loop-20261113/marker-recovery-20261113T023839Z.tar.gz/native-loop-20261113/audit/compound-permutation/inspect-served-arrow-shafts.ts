// Audit-only application of existing SVG scanner and polygon overlap helper.
// Narrow fixture scope: untransformed sharp orthogonal Flowchart polylines,
// canonical filled triangle markers, explicit positive pixel carrier widths.
import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { scanSvgStartTags } from '/workspace/agentic-mermaid/src/svg-structure.ts'
import { classMarkerPiecesOverlap } from '/workspace/agentic-mermaid/src/layout/measured-marker-overlap.ts'

type Point = { x: number; y: number }
const numbers = (text: string) => (text.match(/[-+]?(?:\d*\.)?\d+(?:e[-+]?\d+)?/gi) ?? []).map(Number)
const points = (text: string): Point[] => { const n = numbers(text); return Array.from({ length: n.length / 2 }, (_, i) => ({ x: n[2 * i]!, y: n[2 * i + 1]! })) }
const polygon = (values: Point[]) => ({ kind: 'polygon' as const, points: values })
const rectangle = (x0: number, y0: number, x1: number, y1: number) => polygon([{ x: x0, y: y0 }, { x: x1, y: y0 }, { x: x1, y: y1 }, { x: x0, y: y1 }])
const intersects = (a: ReturnType<typeof polygon>, b: ReturnType<typeof polygon>) => classMarkerPiecesOverlap([a], [b])

function inspect(file: string) {
  const svg = readFileSync(file, 'utf8')
  const tags = scanSvgStartTags(svg).map(tag => ({ ...tag, attrs: Object.fromEntries(tag.attributes.map(attribute => [attribute.name, attribute.value])) }))
  if (tags.some(tag => tag.attrs.transform || tag.attrs['vector-effect'])) throw Error('Unmeasured transformed/non-scaling paint')
  const carriers = tags.filter(tag => tag.attrs['data-role'] === 'edge' && tag.attrs['data-from']).map(tag => {
    if (tag.name !== 'polyline' || tag.attrs['stroke-dasharray'] || tag.attrs.opacity || tag.attrs['stroke-opacity'] || !/^#[0-9a-f]{6}$/i.test(tag.attrs.stroke ?? '')) throw Error('Unmeasured carrier paint')
    const ps = points(tag.attrs.points ?? ''), width = Number(tag.attrs['stroke-width'])
    if (!Number.isFinite(width) || width <= 0 || ps.length < 2 || ps.some(p => !Number.isFinite(p.x) || !Number.isFinite(p.y))) throw Error('Unmeasured carrier coordinates')
    const segments = ps.slice(1).map((b, index) => {
      const a = ps[index]!
      if (a.x !== b.x && a.y !== b.y) throw Error('Unmeasured diagonal carrier')
      const half = width / 2
      // Complete conservative support includes orthogonal joins and all caps.
      const support = rectangle(Math.min(a.x, b.x) - half, Math.min(a.y, b.y) - half, Math.max(a.x, b.x) + half, Math.max(a.y, b.y) + half)
      // The butt-strip interior alone is certainly painted for a solid shaft.
      const filled = a.x === b.x ? rectangle(a.x - half, Math.min(a.y, b.y), a.x + half, Math.max(a.y, b.y)) : rectangle(Math.min(a.x, b.x), a.y - half, Math.max(a.x, b.x), a.y + half)
      return { index, a, b, support, filled }
    })
    return { tag, ps, width, segments, id: tag.attrs['data-id']! }
  })
  const checks: unknown[] = [], hits: unknown[] = [], unknown: unknown[] = []
  let pairCount = 0, markers = 0
  for (const carrier of carriers) for (const end of ['start', 'end'] as const) {
    const reference = carrier.tag.attrs['marker-' + end]
    if (!reference) continue
    const id = reference.match(/^url\(#([^()]+)\)$/)?.[1], marker = tags.find(tag => tag.name === 'marker' && tag.attrs.id === id)
    if (!marker) throw Error('Missing served marker resource')
    const m = marker.attrs, close = svg.indexOf('</marker>', marker.end), children = tags.filter(tag => tag.start > marker.end && tag.start < close)
    if (children.length !== 1 || children[0]!.name !== 'polygon' || m.viewBox || !['auto', 'auto-start-reverse'].includes(m.orient ?? '') || m.overflow && m.overflow !== 'hidden') throw Error('Unmeasured marker mapping')
    const shape = children[0]!.attrs, triangle = points(shape.points ?? ''), w = Number(m.markerWidth), h = Number(m.markerHeight), refX = Number(m.refX), refY = Number(m.refY)
    if (triangle.length !== 3 || !/^#[0-9a-f]{6}$/i.test(shape.fill ?? '') || shape.opacity || shape['fill-opacity'] || triangle.some(p => p.x < 0 || p.x > w || p.y < 0 || p.y > h)) throw Error('Unmeasured marker fill')
    const scale = m.markerUnits === 'userSpaceOnUse' ? 1 : carrier.width
    if (m.markerUnits && m.markerUnits !== 'userSpaceOnUse' && m.markerUnits !== 'strokeWidth') throw Error('Unmeasured marker units')
    const ps = end === 'start' ? carrier.ps : carrier.ps.toReversed(), at = ps[0]!, near = ps.find(p => p.x !== at.x || p.y !== at.y)!
    let dx = Math.sign(end === 'start' ? near.x - at.x : at.x - near.x), dy = Math.sign(end === 'start' ? near.y - at.y : at.y - near.y)
    if (end === 'start' && m.orient === 'auto-start-reverse') { dx = -dx; dy = -dy }
    const world = (p: Point): Point => ({ x: at.x + scale * ((p.x - refX) * dx - (p.y - refY) * dy), y: at.y + scale * ((p.x - refX) * dy + (p.y - refY) * dx) })
    const fill = polygon(triangle.map(world)), support = polygon([{ x: 0, y: 0 }, { x: w, y: 0 }, { x: w, y: h }, { x: 0, y: h }].map(world))
    markers++
    let candidates = 0, filledHits = 0, unresolved = 0
    for (const peer of carriers) {
      if (peer === carrier) continue
      for (const segment of peer.segments) {
        pairCount++
        if (!intersects(support, segment.support)) continue
        candidates++
        const detail = { markerOwner: carrier.id, end, foreignOwner: peer.id, foreignSegment: segment.index, fill: fill.points, shaft: { a: segment.a, b: segment.b, width: peer.width } }
        if (intersects(fill, segment.filled)) { filledHits++; hits.push(detail) }
        else { unresolved++; unknown.push(detail) }
      }
    }
    checks.push({ owner: carrier.id, end, candidates, filledHits, unresolved, status: filledHits ? 'filled-ink-overlap' : unresolved ? 'unverified-stroke-or-empty-envelope' : 'clear-complete-supports' })
  }
  return { file, sha256: createHash('sha256').update(svg).digest('hex'), carriers: carriers.length, markers, pairCount, checks, hits, unknown, status: hits.length ? 'filled-ink-overlap' : unknown.length ? 'unverified' : 'clear-complete-supports' }
}

const [output, ...files] = process.argv.slice(2)
if (!output || !files.length) throw Error('Usage: inspect-served-arrow-shafts.ts output.json file.svg...')
const rows = files.map(file => { try { return inspect(file) } catch (e) { return { file, status: 'unverified', error: String(e) } } })
writeFileSync(output, JSON.stringify({ scope: 'Existing SVG scanner and exact polygon helper applied to final authored fixture markup. Distinct carrier occurrences only; full marker viewport supports prove separation, actual filled triangle/solid butt-strip overlap proves geometric ink intersection. Ambiguous stroke-only candidates stay unverified. This does not certify node/label occlusion, own-carrier masking, arbitrary CSS, curves, transforms or fonts.', rows }, null, 2) + '\n')
for (const row of rows) console.log(JSON.stringify({ file: row.file, status: row.status, hits: 'hits' in row ? row.hits.length : undefined, unknown: 'unknown' in row ? row.unknown.length : undefined, error: 'error' in row ? row.error : undefined }))
