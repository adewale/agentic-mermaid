// Functional observation only; ephemeral onLoad variant matches Sol's archived
// prepared-lead experiment. Production source and pass sequencing are unchanged.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { spyOn } from 'bun:test'
const out = import.meta.dir + '/bt-prepared-lead-trace'
mkdirSync(out, { recursive: true })
const events: unknown[] = []
;(globalThis as any).__auditBtEvents = events
Bun.plugin({ name: 'audit-bt-prepared-lead-trace', setup(build) {
  build.onLoad({ filter: /\/compound-boundary-routes\.ts$/ }, args => {
    let source = readFileSync(args.path, 'utf8')
    const hash = createHash('sha256').update(source).digest('hex')
    source = source.replaceAll(', true, clearance)', ', true, Math.max(clearance, input.minimumTerminalLead ?? 0))')
      .replaceAll(', false, clearance)', ', false, Math.max(clearance, input.minimumTerminalLead ?? 0))')
      .replaceAll(', source, clearance, fractions)', ', source, Math.max(clearance, input.minimumTerminalLead ?? 0), fractions)')
    const primary = 'points = simplifyOrthogonal([...first, ...core.slice(1, -1), ...last])'
    const accepted = 'return contactsClear(candidate) ? candidate : undefined'
    const final = 'const finalPoints = points'
    const target = 'const accepted = accept(simplifyOrthogonal([...first, target.port]))'
    for (const token of [primary, accepted, final, target]) if (source.split(token).length !== 2) throw Error('Trace owner changed: ' + token)
    source = source.replace(primary, primary + '; if(index===9)(globalThis as any).__auditBtEvents.push({phase:"primary-proposal",index,points:structuredClone(points),minimumTerminalLead:input.minimumTerminalLead})')
      .replace(accepted, 'const admitted = contactsClear(candidate); if(index===9 && admitted)(globalThis as any).__auditBtEvents.push({phase:"accepted-fallback",index,points:structuredClone(candidate),stack:new Error().stack}); return admitted ? candidate : undefined')
      .replace(target, target + '; if(index===9 && accepted)(globalThis as any).__auditBtEvents.push({phase:"accepted-sparse-target-arrival",index,target:structuredClone(target),first:structuredClone(first)})')
      .replace(final, 'if(index===9)(globalThis as any).__auditBtEvents.push({phase:"final-boundary-path",index,points:structuredClone(points)}); ' + final)
    writeFileSync(out + '/SOURCE.json', JSON.stringify({ path: args.path, sha256: hash, experimentalVariant: 'prepared-lead; same three terminal-call substitutions as Sol archive; observations only elsewhere' }, null, 2) + '\n')
    return { contents: source, loader: 'ts' }
  })
} })
const boundary = await import('/workspace/agentic-mermaid/src/layout/compound-boundary-routes.ts')
const originalBoundary = boundary.routeCrossHierarchy
const boundaryRows: unknown[] = []
const boundarySpy = spyOn(boundary, 'routeCrossHierarchy').mockImplementation((...args: Parameters<typeof originalBoundary>) => {
  const before = structuredClone(args[1])
  const output = originalBoundary(...args)
  boundaryRows.push({ input: structuredClone(args[0]), before, after: structuredClone(output) })
  return output
})
const { LAYOUT_PIPELINE } = await import('/workspace/agentic-mermaid/src/layout/legacy-completion.ts')
const stages: unknown[] = []
const capture = (ctx: any) => ctx.edges.map((edge: any) => ({ source: edge.source, target: edge.target, points: edge.points.map((p: any) => ({ x: p.x, y: p.y })) }))
for (const pass of LAYOUT_PIPELINE) {
  const run = pass.run
  pass.run = ctx => { const before = capture(ctx), value = run(ctx); stages.push({ stage: pass.id, before, after: capture(ctx) }); return value }
}
const { renderMermaidSVGWithReceipt } = await import('/workspace/agentic-mermaid/src/index.ts')
const groups = ['A', 'B', 'C'], first = [4, 2, 0, 3, 1], second = [1, 3, 0, 4, 2]
const source = ['flowchart BT', ...groups.flatMap(g => ['subgraph Group' + g + '[Group ' + g + ']', ...Array.from({ length: 5 }, (_, i) => `${g}${i}[${g}${i}]`), 'end']), ...first.map((j, i) => `A${i} --> B${j}`), ...second.map((j, i) => `B${i} --> C${j}`)].join('\n')
try {
  const product = renderMermaidSVGWithReceipt(source, { graphLayout: { backend: 'agentic', fallback: 'none' } })
  const baseline = JSON.parse(readFileSync('/workspace/pr449-native-loop-20261113/compound-implementation/recursive-baseline-prepared-lead/BT-permutation.product.json', 'utf8'))
  writeFileSync(out + '/product.json', JSON.stringify(product) + '\n')
  writeFileSync(out + '/output.svg', product.svg)
  writeFileSync(out + '/BOUNDARIES.json', JSON.stringify(boundaryRows, null, 2) + '\n')
  writeFileSync(out + '/STAGES.json', JSON.stringify(stages, null, 2) + '\n')
  writeFileSync(out + '/EVENTS.json', JSON.stringify(events, null, 2) + '\n')
  const result = { closed: true, svgEqual: product.svg === baseline.svg, entireReceiptEqual: JSON.stringify(product.receipt) === JSON.stringify(baseline.receipt), boundaryCalls: boundaryRows.length, stages: stages.length, events: events.length, proof: product.receipt.layoutCertification?.status, scope: 'One functional whole product in Bun; no runtime or memory claim' }
  writeFileSync(out + '/CLOSED.json', JSON.stringify(result, null, 2) + '\n')
  console.log(JSON.stringify(result))
} finally { boundarySpy.mockRestore() }
