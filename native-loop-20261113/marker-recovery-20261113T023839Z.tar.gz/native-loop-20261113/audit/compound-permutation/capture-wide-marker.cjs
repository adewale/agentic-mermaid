const { chromium } = require('/workspace/agentic-mermaid/node_modules/playwright');
const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
  try {
    const page = await browser.newPage({ viewport: { width: 1100, height: 320 }, deviceScaleFactor: 2 });
    await page.route('**/*', route => route.abort());
    const rows = [];
    for (const mode of ['baseline', 'current']) {
      const source = path.join('/workspace/pr449-native-loop-20261113/compound-implementation', 'wide-marker-' + mode, 'LR.svg');
      const svg = fs.readFileSync(source, 'utf8');
      await page.setContent('<!doctype html><html><head><style>html,body{margin:0;padding:0}</style></head><body>' + svg + '</body></html>');
      await page.screenshot({ path: path.join(__dirname, 'wide-marker-LR-' + mode + '.png') });
      await page.screenshot({ path: path.join(__dirname, 'wide-marker-LR-' + mode + '-detail.png'), clip: { x: 630, y: 105, width: 80, height: 60 } });
      rows.push({ mode, source, sha256: createHash('sha256').update(svg).digest('hex'), observedViewBox: await page.locator('svg').evaluate(el => el.getAttribute('viewBox')), markerOverflow: await page.locator('marker').evaluateAll(elements => elements.map(el => ({ id: el.id, overflow: getComputedStyle(el).overflow }))), screenshot: 'wide-marker-LR-' + mode + '.png', detail: 'wide-marker-LR-' + mode + '-detail.png' });
    }
    fs.writeFileSync(path.join(__dirname, 'WIDE-MARKER-CHROMIUM.json'), JSON.stringify({ browser: await browser.version(), deviceScaleFactor: 2, viewport: { width: 1100, height: 320 }, externalRequests: 'blocked', rows }, null, 2) + '\n');
  } finally { await browser.close(); }
})().catch(error => { process.stderr.write(String(error.stack) + '\n'); process.exitCode = 1; });
