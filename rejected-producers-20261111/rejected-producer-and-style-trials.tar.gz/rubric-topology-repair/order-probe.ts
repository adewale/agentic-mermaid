import { parseMermaid } from '/tmp/pr449-main-integration-20261029-762/src/parser.ts'
import { measureRubricMetrics, prepareProducedRubricMeasurements } from '/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts'
import { resolveRenderStyle } from '/tmp/pr449-main-integration-20261029-762/src/styles.ts'
function run(produced:boolean){
 const graph=parseMermaid('flowchart LR\nA --> B\nA --> C'), authored=graph.edges
 let current=authored,reads=0
 Object.defineProperty(graph,'edges',{get(){return current}})
 Object.defineProperty(graph,'direction',{get(){reads++;current=[...authored,{...authored[0],source:'B',target:'C'}];return 'LR'}})
 const positioned={width:140,height:70,groups:[],nodes:[{id:'A',label:'',shape:'rectangle',x:0,y:0,width:20,height:20},{id:'B',label:'',shape:'rectangle',x:100,y:0,width:20,height:20},{id:'C',label:'',shape:'rectangle',x:100,y:40,width:20,height:20}],edges:authored.map(e=>({...e,points:[]}))}
 const style=resolveRenderStyle({}),requested=['symErr','hard'] as const
 const result=produced?prepareProducedRubricMeasurements(graph,positioned as any,style).measure(requested,new Set()):measureRubricMetrics(graph,positioned as any,requested,style)
 return {result,reads}
}
console.log(JSON.stringify({generic:run(false),produced:run(true)}))
