import {readFileSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
const root='/dev/shm/pr449-four-final-20261111/final-e0cac',primary='/tmp/pr449-main-integration-20261029-762',arm=process.argv[2]!
;(globalThis as any).shapeCalls=0
const files=['src/layout-rubric.ts','src/layout/legacy-completion.ts','src/layout/measured-graph-producer.ts']
Bun.plugin({name:'exact-rubric-overlay',setup(build){build.onLoad({filter:/\/src\/(?:layout-rubric|layout\/(?:legacy-completion|measured-graph-producer))\.ts$/},args=>{
 const rel=args.path.slice(root.length+1);if(!args.path.startsWith(root+'/')||!files.includes(rel))return
 let code=readFileSync((arm==='candidate'?primary:root)+'/'+rel,'utf8')
 if(rel==='src/layout-rubric.ts')code=code.replace('export function segmentThroughShape(a: Point, b: Point, node: PositionedNode): boolean {','export function segmentThroughShape(a: Point, b: Point, node: PositionedNode): boolean {\n (globalThis as any).shapeCalls++;')
 return{contents:code,loader:'ts'}
})}})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts'),job=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-e0cac-focused/profile-current.job.json','utf8'))
const cases=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-e0cac-focused/MEASUREMENT-CASES.json','utf8'))
const selected=cases.filter((x:any)=>x.cohort==='family'&&['flowchart','state','class','er','architecture','requirement'].includes(x.family));selected.push({id:'diagnostic:chain100',source:job.source})
const rows=[]
for(const c of selected)for(const backend of ['agentic','elk']){
 ;(globalThis as any).shapeCalls=0
 try{const product=renderMermaidSVGWithReceipt(c.source,{graphLayout:{backend,fallback:'none'}}),json=JSON.stringify(product);writeFileSync(import.meta.dir+'/'+arm+'-'+c.id.replaceAll(':','-')+'-'+backend+'.json',json);rows.push({id:c.id,backend,status:'returned',proof:product.receipt.layoutCertification?.status,shapeCalls:(globalThis as any).shapeCalls,sha256:createHash('sha256').update(json).digest('hex')})}
 catch(error:any){rows.push({id:c.id,backend,status:'error',name:error.name,code:error.code,message:error.message,shapeCalls:(globalThis as any).shapeCalls})}
}
writeFileSync(import.meta.dir+'/'+arm+'-PRODUCTS.json',JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows))
