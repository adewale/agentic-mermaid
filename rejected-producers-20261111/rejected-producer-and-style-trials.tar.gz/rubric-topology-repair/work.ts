import {readFileSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
const root='/dev/shm/pr449-four-final-20261111/final-e0cac',primary='/tmp/pr449-main-integration-20261029-762',arm=process.argv[2]!
;(globalThis as any).work={maps:0,reachability:0,overlapPairs:0,endpointApproaches:0,measure:0,placements:0}
const files=['src/layout-rubric.ts','src/layout/legacy-completion.ts','src/layout/measured-graph-producer.ts']
Bun.plugin({name:'exact-rubric-overlay',setup(build){build.onLoad({filter:/\/src\/(?:layout-rubric|layout\/(?:legacy-completion|measured-graph-producer))\.ts$/},args=>{
 const rel=args.path.slice(root.length+1);if(!args.path.startsWith(root+'/')||!files.includes(rel))return
 let code=readFileSync((arm.startsWith('candidate')?primary:root)+'/'+rel,'utf8')
 if(rel==='src/layout-rubric.ts') {
   code=code.replaceAll('graphReachability(graph.edges)', '((globalThis as any).work.reachability++, graphReachability(graph.edges))')
   for(const spelling of ['new Map(positioned.nodes.map(n => [n.id, n]))','new Map(positioned.nodes.map(node => [node.id, node]))'])code=code.replaceAll(spelling,'((globalThis as any).work.maps++, '+spelling+')')
   code=code.replace('const a = positioned.nodes[i]!, b = positioned.nodes[j]!',';(globalThis as any).work.overlapPairs++; const a = positioned.nodes[i]!, b = positioned.nodes[j]!')
   code=code.replace('invalidEndpointApproaches, PORT_EXACT','invalidEndpointApproaches as realInvalidEndpointApproaches, PORT_EXACT')
   code+='\nfunction invalidEndpointApproaches(...args: Parameters<typeof realInvalidEndpointApproaches>) { (globalThis as any).work.endpointApproaches++; return realInvalidEndpointApproaches(...args) }\n'
   code=code.replace('  const result: PassMetrics = {}','  ;(globalThis as any).work.measure++; const result: PassMetrics = {}')
   code=code.replace('    finishPlacement(): void {','    finishPlacement(): void { (globalThis as any).work.placements++;')
 }
 return{contents:code,loader:'ts'}
})}})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts'),job=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-e0cac-focused/profile-current.job.json','utf8'))
const cases=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-e0cac-focused/MEASUREMENT-CASES.json','utf8'))
const selected=[{id:'diagnostic:chain100',source:job.source}]
const rows=[]
for(const c of selected)for(const backend of ['agentic']){
 ;(globalThis as any).work={maps:0,reachability:0,overlapPairs:0,endpointApproaches:0,measure:0,placements:0}
 try{const product=renderMermaidSVGWithReceipt(c.source,{graphLayout:{backend,fallback:'none'}}),json=JSON.stringify(product);writeFileSync(import.meta.dir+'/'+arm+'-WORK-PRODUCT.json',json);rows.push({id:c.id,backend,status:'returned',proof:product.receipt.layoutCertification?.status,work:{...(globalThis as any).work},sha256:createHash('sha256').update(json).digest('hex')})}
 catch(error:any){rows.push({id:c.id,backend,status:'error',name:error.name,code:error.code,message:error.message,work:{...(globalThis as any).work}})}
}
writeFileSync(import.meta.dir+'/'+arm+'-WORK.json',JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows))
