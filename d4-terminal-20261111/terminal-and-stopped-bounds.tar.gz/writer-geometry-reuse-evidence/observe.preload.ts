import {plugin} from 'bun'
import {readFileSync} from 'node:fs'
plugin({name:'bounded-completed-geometry-consumer',setup(build){build.onLoad({filter:/chain-proof-candidate\/src\/scene\/paint-certification\.ts$/},args=>{
let s=readFileSync(args.path,'utf8').replace("import { hasWrittenCompoundProjection } from './written-geometry.ts'","import { hasWrittenCompoundProjection, writtenPolylineProjectionOf } from './written-geometry.ts'")
s=s.replace("    let servedLineContours: readonly ConnectorContourSemantics[] | undefined",`    if (node.markers.start || node.markers.end) { const counters = globalThis.__geometryReuse; counters.marked++; counters.kinds[node.route.geometry.kind] = (counters.kinds[node.route.geometry.kind] ?? 0) + 1; if (node.route.geometry.kind === 'polyline' && writtenPolylineProjectionOf(node.route.geometry)) counters.polylineMetadata++; }\n    let servedLineContours: readonly ConnectorContourSemantics[] | undefined`)
s=s.replace("      servedLineContours = connectorContourSemantics(node.route.geometry, false)","      globalThis.__geometryReuse.lineDerivations++; servedLineContours = connectorContourSemantics(node.route.geometry, false)")
s=s.replace("      const points = ownData(node.route.geometry, 'points')", "      globalThis.__geometryReuse.polylineEndpointChecks++; const points = ownData(node.route.geometry, 'points')")
s=s.replace("      const value = ownData(points as object, String(index))", "      globalThis.__geometryReuse.pointReads++; const value = ownData(points as object, String(index))")
return{loader:'ts',contents:s}
})}})
