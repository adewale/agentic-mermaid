import{readFileSync,writeFileSync}from'node:fs'
import{gzipSync}from'node:zlib'
const api=await import('../chain-proof-candidate/src/index.ts')
const cases=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-marker-paint-matched/MEASUREMENT-CASES.json','utf8'))
for(const name of ['diagnostic:chain100','diagnostic:chain300']){
 const c=cases.find(c=>c.id===name)
 globalThis.__geometryReuse={marked:0,kinds:{},polylineMetadata:0,lineDerivations:0,polylineEndpointChecks:0,pointReads:0}
 const product=api.renderMermaidSVGWithReceipt(c.source,{...c.renderOptions,graphLayout:{backend:'agentic',fallback:'none'}})
 writeFileSync(new URL(name.replace(':','-')+'.json.gz',import.meta.url),gzipSync(JSON.stringify(product)))
 console.log(JSON.stringify({case:name,counters:globalThis.__geometryReuse,proof:product.receipt.layoutCertification.status,checks:product.receipt.layoutCertification.checks}))
}
