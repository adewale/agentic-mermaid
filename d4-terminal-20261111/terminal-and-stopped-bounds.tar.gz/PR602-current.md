This PR repairs Native grouped routing and reuses checks completed by actual SVG producers. Fan100 now completes its paint proof on both Native and ELK. The latest group change improves measured warm rendering while preserving the drawings.

Native remains the replacement candidate; Trinity feature work is frozen. Defaults, versions and resource caps are unchanged.

**Draft: the warm Native100 SVG median is 95.86 ms, but one process remains 112.24 ms. Chain300 remains unknown on both engines. First-edit/tail costs and payload budgets remain open.**

Head: `d4d3f37195c69cfe09fc8976ff96073847eeb959`. Latest group comparison: `51e6cfca63c8d70180b3cff293da8f9582f5153e`. Fan proof comparison: `285427d6186453066e11245c1a9a2d4516e0e22b`. Frozen main: `4260292397d4bca7624a30c34649eb943a5f8e0c`.

## Behavior

Native uses the measured request contract and early endpoint-capacity planning. The separate grouped-delivery suite improves 10→12 on twelve replacement inputs frozen before fixes, with zero crossings; ELK delivers twelve. The original twelve sources/image were lost. The illustrated ancestor repair increases wire 5.56%.

The shared pipeline reuses completed geometry, text, group and marker work at its owning producer. Fresh C4 geometry and retained snapshots keep separate custody. Replacement producers retain their callbacks, errors and detached mutable inputs.

Fan100 no longer repeatedly compares the identity string of the same completed marker paint. Equality consumes the existing private operand bound to the actual inspection/resource/resolver; generic comparisons remain fresh. Final plain-group validation now produces one attribute roster for context and XML consumers, sharing the writer's UTF16/reference reader. Only the exact immutable own opening grants actual-write custody. Initial borrowed-field/reflection trial failures are reproduced and repaired.

First-party async browser drawing avoids unused generic Scene SPI acquisition for Native and ELK placement. SDK, strict and required Scene paths retain genuine conformance and the same admitted request/layout. Descriptor facades stay descriptor-only for SDK/Node/Zen; browser injection removes a redundant request and preserves option-getter/configuration-diagnostic ordering. No new cache, decoder or qualification framework is added.

## Results and tradeoffs

| Metric | Evidence | Limitation/cost |
| --- | --- | --- |
| Fan100 proof | Native 400,000/U→324,272/P; ELK 400,000/U→325,801/P across the two latest fixes | Same 400,000-operation/100,000-pair caps; drawings unchanged |
| Larger proof suite |8/12→10/12 passed; all 12 SVG/non-certification products exact | Chain300 both remain unknown; this is distinct from the grouped-delivery suite |
| Latest Trident 124 portable / 198 authored+Chromium ink | All 310 returned SVG/non-cert products and proof vectors except work exact 51e6; 12 same errors; every meaning/ink/quality vector unchanged | Portable110P6U, authored182P12U unchanged by the group fix; labels-only supplements remain limited |
| Native100 warm SVG | Same-build process medians 120.45/144.97/98.81→94.74/112.24/95.86 ms | One process still >100; SVG p95 144.65 ms; no reliable universal 100 ms claim |
| Native100 full response | Median 155.79→133.63 ms; cold 352.45→330.06 ms | First process 154.49→182.80 ms; full p95 186.01→224.92 ms |
| Editing/new sources | Label-edit SVG 88.03→81.82 ms | First full edit 169.02→199.80 ms; repeated edit 126.53→135.45 ms; fresh-source SVG 83.84→94.04 ms |
| Process memory | RSS 157.45→158.76 MiB; heap 42.02→43.36 MiB | Both adverse |
| Actual browser |2 closed observations/4 products exact except work; each falls 499 operations; requests unchanged | Native+641 gzip B/+437 Brotli B, ELK+635/+443; JS heap−13,584/−15,028B |
| Mixed forest→ELK→YAML |785,229→785,864 gzip B | Ceiling761,500; raw2,528,402>2,430,000; Brotli625,965>618,000 |

Timing uses matching seven-entry builds and the existing workers: three fresh processes per arm/protocol, cache off, twelve closed workers and 27 fully consumed paired products. Import, cold render, first edit and repeated edits are separate. No operation-count-to-CPU inference or uniform speedup/memory claim. The earlier Fan timing comparison has different completed proof work (unknown→passed); no equivalent-proof ratio is claimed.

Browser costs count fetched modules compressed separately at gzip9/Brotli11; forced-GC JS heap differs from process RSS. The latest change adds 635 gzip B/443 Brotli B to the mixed closure. Current CI still reports roughly 37–49KB lazy gzip growth versus main across families. Historical consumer savings and Class/ER/hand-drawn adverse costs remain in the retained reports.

Forest wire+16.89% with area−6.43%, Requirement area+9.53% and implemented Sparse256 area+5.04% remain counterexamples; the+0.97% backfill is unshipped. ER256 already passed all eight backend/direction lanes at 599; no new ER repair is claimed. Original 2dad and equivalent pinned Mermaid12.2/Pele1.9 renderers remain unavailable. Replacement24 stays sealed; automations remain off.

## Verification and unfinished work

Latest group change: 734 existing paint/writer/ownership tests pass; canonical core/repository types and scoped lint pass. Custody regressions reproduce initial trial 1P2F→repaired3P, covering borrowed fields and reflection/registry interposition. Eighteen emitted public pairs include Class/ER and styles; SVG/non-certification/proof-except-work, statuses, caps and digests remain exact.

Exact-head [CI43117973024](https://github.com/adewale/agentic-mermaid/actions/runs/43117973024) has finished **failure overall**. All three unit shards, portable/package build, installed quickstarts, Node 22/24 tarballs, dist, CLI, MCP, semantic and platform isolation pass. The browser lane also passed. Quality/payload/browser-site budgets and advisory layout failed. CI mixed gzip 785,848>761,500; demo 816,286raw/312,058gzip exceed 788,000/302,500; editor 1,355,538>1,334,500. Local and CI bytes are separate builds. No readiness claim.

[Current source, Trident, all runtime costs and browser recovery](https://github.com/adewale/agentic-mermaid/blob/3f36b7ae554a88c79ff1eae3a4af0ccd6df18eb5/group-d4d3-20261111/REPORT.md) · [Fan proof recovery and matched costs](https://github.com/adewale/agentic-mermaid/blob/b079894898ef848483600135e9bd6595336335cf/fan-51e6-20261111/REPORT.md) · [Frozen main comparison](https://github.com/adewale/agentic-mermaid/blob/4fea9394f097ca8112bcabfc3a594a5cc248d729/trident-main-20261110/REPORT.md).

Stopped trials remain unshipped and retained. Getter-backed records regressed proofs 8→4; ordinary rectangle construction removed no work. The Node consumer pilot had a mixed-build timing comparison and establishes no source-level speedup. Marker-piece reuse, isolated group comparison, a 328 raw-byte namespace ablation, marker-resource capture already reused in 299 of 299 references, and insufficient endpoint facts do not close the remaining deficits. Wrong-script-root browser results and initial unequal-build costs are disqualified for source attribution. These replays are not product progress.

## Visual evidence

Claim: the labelled ancestor entry/exit retain their authored relationships and A→B flow while removing two route crossings.

Input/fixture: `container-descendant-labelled` in [the fixed source set](https://github.com/adewale/agentic-mermaid/blob/8ec6299d2d1270c189e78c6d1ef79e1d66f3b9a9/native-blockers-checkpoint-20261110/REPLACEMENT-12.json), directionLR, nested Outer/Inner, Outer→A labelled enter, A→B, B→Outer labelled exit. Options/source are identical between arms; production SVG with Inter.

Baseline SHA: `7257faa9299a69948645a7574e185300b7841f75`.
Historical visual head SHA: `17f157fae6a6f97295ebb10f215d2c2326710b6b`.

Regenerate: extract `evidence.tar.gz`, replay the retained correctness collector, then `bun correctness-final/raster-ancestor.ts`. Resvg uses manifest-verified Inter, system fonts off,2× zoom. [Font manifest](https://github.com/adewale/agentic-mermaid/blob/8ec6299d2d1270c189e78c6d1ef79e1d66f3b9a9/native-blockers-checkpoint-20261110/RASTER-FONTS.json), [SVG/PNG/archive hashes](https://github.com/adewale/agentic-mermaid/blob/8ec6299d2d1270c189e78c6d1ef79e1d66f3b9a9/native-blockers-checkpoint-20261110/MANIFEST.json). Owning test: `ancestor-boundary-routes.test.ts`, “ancestor entry and exit preserve the inner chain without crossing”, allfour directions.

| Before | After |
| --- | --- |
| <img alt="Before: the ancestor entry descends across the exit and the inner A-to-B connection" src="https://raw.githubusercontent.com/adewale/agentic-mermaid/8ec6299d2d1270c189e78c6d1ef79e1d66f3b9a9/native-blockers-checkpoint-20261110/ancestor-before.png" width="380"> | <img alt="After: entry and exit use separate corridors and A-to-B stays directed right; wire increases 5.56 percent" src="https://raw.githubusercontent.com/adewale/agentic-mermaid/8ec6299d2d1270c189e78c6d1ef79e1d66f3b9a9/native-blockers-checkpoint-20261110/ancestor-after.png" width="380"> |

Limitation: these renders establish the enrolled fixture's crossing repair, with a wire cost. They do not recover the lost original image, prove every grouped graph correct or establish ELK replacement readiness.

