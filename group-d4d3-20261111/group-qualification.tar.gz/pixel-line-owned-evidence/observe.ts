import { plugin } from 'bun'
import { readFileSync } from 'node:fs'
plugin({name:'observe-actual-pixel-line-root',setup(build){build.onLoad({filter:/large-proof-candidate\/src\/scene\/native-paint-emission\.ts$/},args=>{
const source=readFileSync(args.path,'utf8').replace("      let captured: Leaf | undefined\n      try { captured = copy",`      if (node.kind === 'text' && node.block) { globalThis.__pixelLineRoots.total++; if (isOwnedPixelTextPart(node.block)) globalThis.__pixelLineRoots.owned++; }\n      let captured: Leaf | undefined\n      try { captured = copy`)
return{loader:'ts',contents:source}
})}})
