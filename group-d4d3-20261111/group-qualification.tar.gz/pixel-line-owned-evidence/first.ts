import {readFileSync,writeFileSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
globalThis.__pixelLineRoots={total:0,owned:0}
const api=await import('../large-proof-candidate/src/index.ts')
const source=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-e0cac-focused/profile-current.job.json','utf8')).source
const result=api.renderMermaidSVGWithReceipt(source,{graphLayout:{backend:'agentic',fallback:'none'}})
writeFileSync(new URL('FIRST-PRODUCT.json.gz',import.meta.url),gzipSync(JSON.stringify(result)))
console.log(JSON.stringify({actualLeafBlockRoots:globalThis.__pixelLineRoots,proof:result.receipt.layoutCertification.status,checks:result.receipt.layoutCertification.checks}))
