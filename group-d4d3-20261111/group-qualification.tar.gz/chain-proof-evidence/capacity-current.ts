import{readFileSync,writeFileSync}from'node:fs';import{gzipSync,gunzipSync}from'node:zlib';
const api=await import('../chain-proof-candidate/src/index.ts');
const cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/shared-four-fixes-20261111/task1/inplace-closure-ceiling/capacity/EXISTING-CASES.json','utf8'));const rows=[];
for(const c of cases)for(const backend of ['agentic','elk']){
 const control=JSON.parse(gunzipSync(readFileSync(new URL(`../large-proof-evidence/qualified-${c.name}-${backend}.json.gz`,import.meta.url))).toString());
 const candidate=api.renderMermaidSVGWithReceipt(c.source,{graphLayout:{backend,fallback:'none'}});
 writeFileSync(new URL(`qualified-group-${c.name}-${backend}.json.gz`,import.meta.url),gzipSync(JSON.stringify(candidate)));
 const omit=(value:any)=>{const{layoutCertification,...rest}=value.receipt;return rest};const row={name:c.name,backend,svgExact:control.svg===candidate.svg,noncertExact:JSON.stringify(omit(control))===JSON.stringify(omit(candidate)),before:control.receipt.layoutCertification,after:candidate.receipt.layoutCertification};rows.push(row);console.log(JSON.stringify(row));
}writeFileSync(new URL('GROUP-CAPACITY-CURRENT.json',import.meta.url),JSON.stringify(rows,null,2));
