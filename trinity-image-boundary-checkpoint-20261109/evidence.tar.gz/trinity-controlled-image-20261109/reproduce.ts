import{readFileSync,writeFileSync}from'node:fs'
import{renderMermaidSVGWithReceipt}from'/tmp/pr449-main-integration-20261029-762/src/index.ts'
const out=import.meta.dir,c=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-native-elk-df133-20261108/FIDELITY-CASES.json','utf8')).selected.find((c:any)=>c.id==='features:flowchart:controlled-image'),rows=[]
writeFileSync(out+'/CASE.json',JSON.stringify(c,null,2))
for(const backend of ['elk','agentic','trinity'])try{const p=renderMermaidSVGWithReceipt(c.source,{graphLayout:{backend:backend as 'elk',fallback:'none'},embedFontImport:false});JSON.stringify(p.receipt);writeFileSync(out+'/before-'+backend+'.svg',p.svg);writeFileSync(out+'/before-'+backend+'.receipt.json',JSON.stringify(p.receipt,null,2));rows.push({backend,status:'returned',proof:p.receipt.layoutCertification?.status,images:(p.svg.match(/<image\b/g)??[]).length})}catch(e:any){rows.push({backend,status:'error',name:e.name,error:e.message})}
writeFileSync(out+'/BEFORE.json',JSON.stringify({source:'a62cba6766f959dc6aad4709b138a5888906c9a1',rows},null,2));console.log(rows)
