# Controlled image: first-cause review

Source: `4db8570d389246bb5f1eede8c5b1899fe6cd687e`. Read-only source and existing-artifact inspection; no renders, tests, builds, profiling, decoding, network, or source edits.

**Recommendation: retain unsupported for the frozen controlled-image fidelity claim. A gate-only change can at most enable the existing explicitly warned placeholder policy. It cannot establish image delivery, decoded ink, or a valid image/caption arrangement.** This is a different boundary from the Class admission change.

## Exact refusal

`src/layout/measured-graph-producer.ts:28–31` rejects every truthy `semanticShape`. `src/parser.ts:1656–1662` turns this source's `img` into `{ shape: 'rectangle', semanticShape: 'image', image: URL }`. The existing frozen Trinity product reports exactly `only measured rectangular, rounded and State circle contacts are supported` (`trinity-class-scopes-20261109/COHORT-PRODUCTS.json`, controlled-image row). Neither Trinity solving nor physical marker admission is reached.

The frozen source (`trident-native-elk-df133-20261108/FIDELITY-CASES.json`) requests Art with an inline PNG, label `Icon`, authored `w:32`, `h:32`, `constraint:"on"`, and `Art --> Target`. Its explicit paint expectation is one image with that href; features include image decoding. This review trusts the fixture's provenance description of an opaque-red PNG but did not independently decode it.

## Actual current body and paint

This is not currently raster rendering. `src/types.ts:73–74` explicitly describes `image` as inert data never fetched. The parser's typed media projection (`parser.ts:1662–1684`) retains image/icon/form but does not project `w`, `h`, or `constraint` into body dimensions. `src/agent/flowchart-unsupported.ts:51–52` warns that static offline rendering uses a deterministic placeholder. Existing owning coverage asserts that policy (`src/__tests__/closing-the-gap.test.ts:31–47`).

`src/renderer.ts:552–575,618–629` paints the ordinary node shape, a small vector landscape placeholder, then its label. There is no SVG image in this path. The real outer body is supplied by `shapeOutline`: `image` has no semantic-outline case (`src/shape-outline.ts:418–459`), so the actual rectangle/rounded geometry branch applies (`:94–101,150–155`). This is a genuinely painted frame, not an inference that the raster's bounding box is opaque ink. `renderer.ts:637–653` supplies its actual resolved fill/stroke/stroke width. Frame contact could therefore truthfully use the existing rectangular/rounded contact model if this explicitly limited placeholder policy were admitted.

Existing Native artifact `trinity-class-scopes-20261109/products/29-features_flowchart_controlled-image-agentic.svg` confirms the distinction: Art's outer frame is 67.144 × 36.9 at (40,40); the placeholder is a 14.76 × 10.6272 outlined miniature at (66.192,46), with circle/path artwork; `Icon` is centered at (73.572,58.45), font size 13. It contains `data-image-src`, not an emitted `<image>`. This is existing output, not a new experiment. Neither a successful receipt nor this retained URL establishes decoded-image fidelity.

## Measurement gap beyond the gate

`measured-graph-producer.ts:69–74` calls `estimateNodeSize` with the label and base shape, without media demand. `layout-engine.ts:191–218,253–261` measures label plus padding/minima. `renderer.ts:595–598,618–629` independently derives placeholder size as `min(28, height*0.4)` at y+6; `renderer.ts:678–699` centers the label. There is no separate measured caption/media reservation here. Those formulas permit overlapping occupied envelopes as node/text dimensions vary. That is a demonstrated missing constraint, not a claim that bounding-box overlap proves glyph/stroke collision in the frozen artifact. Existing final proof must remain authoritative, and a receipt alone must not be promoted into independent media/caption ink evidence.

An exception only for `semanticShape === 'image'` would also leave `portFaces` false at producer line70 because that predicate rejects semantic shapes; blindly clearing the semantic identity to activate it would lose meaning. Any future placeholder-specific admission must explicitly carry the real frame's contact eligibility while retaining image identity, actual border/radius, endpoint spans, fresh final paint checks and original work caps. It also needs family-owned media/caption measurement shared with emission. Do not invent a raster contact rectangle, treat transparent pixels as paint, or substitute a plain node silently.

## Smallest defensible next decision / stop condition

For the requested frozen **actual image** case, stop the layout-only intervention. The first unmet product contract is the existing image-body/emission policy, independent of Trinity. Opening the solver gate cannot meet the fixture's paint expectation; the other backends returning placeholders does not qualify them either. Actual image support would require a separately explicit bounded body/emission contract, including dimensions, resource handling, label placement and the distinction between known painted frame contact and unknown raster alpha. This review does not propose that larger work or any increased budget.

If the owner instead explicitly targets parity with the current warned placeholder policy, scope that claim separately. The smallest credible candidate would combine a precise placeholder-frame admission with shared media/caption reservation and retained final contact/proof checks. Gate-only admission is insufficient evidence of that complete contract. Keep the controlled-image fidelity row unqualified until the expected emitted image and independent decode/paint evidence exist.
