# Trinity stage5: independent private-placement review

Read-only inspection of measured-forest extraction, private placement/work owners,
integration and existing owner additions. No source edits, tests, builds, profiles,
agents or external actions. **No remaining actionable regression found in the
reviewed slice after the contact-domain correction below.**

The placement path uses ordered subtree bands and shelf packing without producing
generic routes or routing-track scratch. Its imports do not load a routed Native
or Trinity implementation: measured-forest has type-only solver imports. The
Native routing suffix is byte-exact againstdeb1d6971; port spreading, fan-track
admission, route construction and placementOnly behavior remain on the original
routed path. There is one shared preparation implementation, not copied solvers.

Known rectangular/rounded bodies are expanded by their complete stroke width
before packing; returned logical origins are inset by half-stroke and retain
original fixed dimensions. Thus the allocated outer boxes bound their painted
outline, including singleton and reversed-direction placement. The new path does
not claim that body placement has solved endpoint, label, marker or compound
routing. Those demands explicitly decline, as do nonforest topology and remaining
ordering/scope constraints.

The shared ledger guard executes before unsupported-size decisions and rejects
already depleted work with LayoutWorkLimitError. Preparation charges remain spent
when forest detection fails, and a later attempt cannot reset them. A hard ledger
error propagates rather than becoming an unsupported fallback. The new exact
n+m/m accounting assertions document that local reservation, not a complete
allocation/operation cost model or measured speedup.

## Finding and verified resolution

Initial review found that known stroke width alone did not justify painted-bound
claims for an unknown shape: acute miter or semantic overhang can exceed a
half-stroke expansion of its logical box. The coordinator narrowed admission.
Re-read source now requires explicit rectangle/rounded-rectangle contact; unknown
contact returns unsupported. The singleton owner declares rectangle, and the
existing admission owner includes unknown-contact decline. This resolves the
reported scope/safety issue without inventing a general shape-bounds model.

This stage legitimately expands only a private placement-only forest slice under
existing product size limits. It does not complete compounds/family registration,
ship a public Trinity option, establish better ink or attribute a performance /
payload gain to architectural extraction. No additional framework or adoption
claim is justified by this source review.
