# Shared-cost causal review: Requirement public rendering

Source `01497b98ff72f5e0c30d23e1379adeb09cc2032c`, 2026-11-08. Read-only source and existing nine-call inspector-profile analysis. No tests, builds, new profiles, source changes, caches or Sparse32 probes.

**Recommendation: stop this subtraction task at the current evidence boundary. I found no small, specifically demonstrated redundant producer/consumer traversal that can safely be removed while retaining the stated contracts.** The profiles locate costs; they do not establish that those costs are duplicate work or removable CPU time.

## Native copying: expensive, but the obvious duplicated representation is already gone

Static analysis of recorded sample stacks assigns 125 of the 184 `copyInner` self samples to Requirement text leaves and 33 to connector leaves. The remaining samples include shapes, definitions, document headers and group shells. These are distinct emitted occurrences. A recursive function appearing repeatedly in one stack is not evidence of separate producer/consumer passes.

`native-paint-emission.ts:105–275` copies each occurrence before writer/validator execution, rejects accessor/unsupported custody, seals the captured receiver and preserves the generic mutable fallback. The owned prepared-text plan already reuses reflection instructions while materializing fresh receivers. Sharing the materialized receivers would change inherited getter/definition/alias observations; skipping descriptor visits for mutable inputs would weaken custody.

There was a plausible duplicate representation to inspect: `marks.text` supplies both `block` and legacy `preparedLines`. However, `marks.ts:477–489` already makes `legacyPreparedRuns` return `undefined` for ordinary owned blocks under intrinsic mapping behavior. It retains the old mapping only when caller-observable hooks require it. Proposing this optimization again would duplicate implemented work. A copied block's internal fields cannot be dropped merely because one ordinary rendering path does not read them; the writer/inspection and ambient receiver contracts still apply.

## XML: the two consumers do not check the same artifact

Recorded stacks distinguish metered `verifySvgDocumentDataPositions → xml.verify → emission.finish` from final `inspectFinalSvg → applyOutputSecurityPolicy`. The former checks the private constructed projection and occupied-DATA positions under the paint allowance; the latter scans the final public bytes and collects attribute/CSS/security findings. A successful projection check cannot replace the public security scan, and public inspection results cannot authorize the fresh metered proof.

The final-security path already combines envelope parsing and attribute-security inspection in one `verifyDocumentEnvelope` traversal (`output-security.ts:741–759`). Thus “fuse XML and security validation” is also already implemented. Passing a new retained validation authority between these boundaries would require more than subtracting a traversal, especially for raw definitions, substituted leaves, wrapper scope, CSS and malformed-input precedence. No such safe substitution is demonstrated by these samples.

## Receipt normalization: one tempting false duplicate, one real overlap without a small deletion

Of the 21 recorded `omitUndefinedObjectFields` self samples, 17 descend from deferred request-digest admission, three from appearance-digest admission, and one from options admission. The immediate `omitUndefinedObjectFields → immutableSnapshot` sequence is **not** two complete recursive copies for ordinary valid JSON: normalization freezes and privately brands its result; `immutableSnapshot` returns at its initial membership check (`render-contract.ts:769–785`). That is a source-level negative check against deleting a supposed second walk.

The shared-request and output-specific receipt constructions do overlap (`render-contract.ts:1417–1434`). Their admissions nevertheless use independent aggregate/depth budgets and differing capability/output fields; both digests are consumed by the full receipt. Replacing the second capture with existing references would need a bounded proof for the composite graph and preservation of omission, opacity, accessor/error ordering and aggregate accounting. The profile does not measure the removable fraction, and no existing sufficient admission result for that new composite was identified. A new partial-graph admission/cache mechanism would exceed the requested small subtraction.

## Decision

No implementation candidate or causal knockout is recommended from this review. Removing copying or a validation gate merely to time its absence would quantify the cost of an obligation, not prove redundant work. Existing owning suites—Native occurrence/capture validation, SVG writer/XML closure, renderer security, and render-contract/transport parity—remain relevant, but passing their ordinary witnesses would not resolve the missing authority argument. Keep the profile's elapsed sample weights separate from unprofiled backend timing and from any claimed saving. No new general framework or refactor is warranted here.
