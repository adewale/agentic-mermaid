import{readFileSync,writeFileSync}from'node:fs'
import{parseRegisteredMermaid,renderMermaidSVGWithReceipt}from'/tmp/pr449-main-integration-20261029-762/src/index.ts'
const p=import.meta.dir,cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-native-elk-df133-20261108/FIDELITY-CASES.json','utf8')).selected,rows=[]
for(const c of cases){const preludes=[]
 for(const prelude of c.prelude??[]){let svg;try{const product=renderMermaidSVGWithReceipt(prelude.source);JSON.stringify(product.receipt);svg={accepted:true,proof:product.receipt.layoutCertification?.status}}catch(e){svg={accepted:false,error:String(e)}};const parsed=parseRegisteredMermaid(prelude.source);preludes.push({expected:prelude.accept,svg,parser:{publicAccepted:parsed.ok,...(!parsed.ok?{errors:parsed.error}:{bodyKind:parsed.value.body.kind})}})}
 const parsed=parseRegisteredMermaid(c.source);rows.push({id:c.id,preludes,semanticStatus:!parsed.ok?'unavailable':['preserved','opaque'].includes(parsed.value.body.kind)?'unsupported':'accepted',bodyKind:parsed.ok?parsed.value.body.kind:undefined,scope:'Actual current public model and defaultSVG prelude acquisitions. Public acceptance of opaque/preserved source is explicitly not native semantic support.'})
}
writeFileSync(p+'/ACQUISITION-SUPPLEMENT.json',JSON.stringify(rows,null,2)+'\n')
