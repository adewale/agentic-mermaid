import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {renderMermaidSVGWithReceipt,parseRegisteredMermaid} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import {normalizeMeaning} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/fidelity/adapters.ts'
import {assessMeaning} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/fidelity/meaning.ts'
const out=import.meta.dir,prior='/tmp/pr449-week-comparison-20261101/trident-native-elk-df133-20261108',cases=JSON.parse(readFileSync(prior+'/FIDELITY-CASES.json','utf8')).selected
mkdirSync(out+'/products',{recursive:true});const rows:any[]=[],meaning:any[]=[]
for(const [index,c]of cases.entries()){
 for(const prelude of c.prelude??[]){try{renderMermaidSVGWithReceipt(prelude.source)}catch{};parseRegisteredMermaid(prelude.source)}
 const parsed=parseRegisteredMermaid(c.source)
 try{meaning.push({id:c.id,parserAccepted:parsed.ok,...(parsed.ok?{assessment:assessMeaning(c,normalizeMeaning('agentic',c.family,parsed.value.body))}:{error:parsed.error}),scope:'Actual current public parser return; unmodified Trident canonical normalizer and authored expectations, common to all layout lanes. Parser meaning is not final ink proof.'})}catch(error){meaning.push({id:c.id,parserAccepted:parsed.ok,observerError:String(error)})}
 for(const backend of ['elk','agentic','trinity']as const){
  const stem=index+'-'+c.id.replace(/[^a-zA-Z0-9_.-]/g,'_')+'-'+backend
  try{const product=renderMermaidSVGWithReceipt(c.source,{...c.renderOptions,graphLayout:{backend,fallback:'none'},embedFontImport:false});JSON.stringify(product.receipt);writeFileSync(out+'/products/'+stem+'.svg',product.svg);writeFileSync(out+'/products/'+stem+'.receipt.json',JSON.stringify(product.receipt,null,2)+'\n');rows.push({id:c.id,family:c.family,backend,stem,delivery:'returned',proof:product.receipt.layoutCertification?.status??'unavailable',receipt:product.receipt,svgBytes:Buffer.byteLength(product.svg)})}
  catch(error:any){let cause=error,code:string|undefined;for(let i=0;i<8&&cause;i++,cause=cause.cause)if(typeof cause.code==='string'){code=cause.code;break};rows.push({id:c.id,family:c.family,backend,stem,delivery:code==='GRAPH_LAYOUT_UNSUPPORTED'?'unsupported':code?.includes('LIMIT')||error?.name==='LayoutCertificationError'?'refused':'error',error:String(error),errorCode:code,proof:'unavailable'})}
 }
 writeFileSync(out+'/COHORT-PRODUCTS.json',JSON.stringify(rows,null,2)+'\n');writeFileSync(out+'/AUTHORED-MEANING.json',JSON.stringify(meaning,null,2)+'\n')
 console.log(c.id,rows.slice(-3).map(r=>[r.backend,r.delivery,r.proof]))
}
const fixture=readFileSync('/tmp/pr449-main-integration-20261029-762/eval/layout-compare/fixtures/requirement-backends.mmd','utf8'),retained=[]
for(const direction of ['TB','BT','LR','RL'])for(const backend of ['elk','agentic','trinity']as const){try{const p=renderMermaidSVGWithReceipt(fixture.replace('direction TB','direction '+direction),{graphLayout:{backend,fallback:'none'},embedFontImport:false});JSON.stringify(p.receipt);writeFileSync(out+`/${backend}-${direction}.svg`,p.svg);writeFileSync(out+`/${backend}-${direction}.receipt.json`,JSON.stringify(p.receipt,null,2)+'\n');retained.push({direction,backend,delivery:'returned',proof:p.receipt.layoutCertification?.status,selected:p.receipt.layoutDecisions})}catch(e){retained.push({direction,backend,delivery:'error',error:String(e),proof:'unavailable'})}}
writeFileSync(out+'/RETAINED-REQUIREMENT.json',JSON.stringify(retained,null,2)+'\n')
