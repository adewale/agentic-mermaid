# Public Trinity registration: independent review

Read-only inspection of the current registration diff over0604aae77. No source
edits, tests, builds, profiles, agents or external actions. **No actionable
correctness finding in the reviewed slice.**

- Backend selection calls Trinity only through its actual callback. Unmigrated
  graph families decline; only requested fallback:elk permits substitution.
  Decisions retain requested/selected backend, actual attempts/reason and
  trinity@1 identity. Default/no-option ELK and existing Native selection paths
  retain their previous control flow. New fallback diagnostics name Trinity
  without changing existing Native wording.
- TypeError, LayoutWorkLimitError and deferred dependency errors remain outside
  permitted fallback. Requirement does not opt into certification-rejection
  fallback. Its Node-size growth is published only after common solve succeeds;
  a typed decline leaves the ELK callback's measured cards untouched.
- Requirement derives endpoint supports from its actual fixed userSpaceOnUse
  marker resources and unions them with shaft width. The resource constants
  include conservative stroke extent; they do not incorrectly scale these
  fixed heads by the carrier width. Full configured corner radius remains a
  conservative bound after permitted card growth, and rendering consumes the
  returned dimensions. Card configuration is minimum sizing, not a fixed-size
  override silently enlarged by this adapter.
- Node border widths are admitted as finite positive absolute pixels. Relative,
  percentage and CSS-dependent widths decline rather than using parseFloat as
  paint authority. This is a deliberately narrow domain; rejecting other valid
  CSS spellings is capability limitation, not evidence they are malformed.
- The zero-lead change admits finite nonnegative lead, preserving malformed
  negative/nonfinite rejection. It permits an empty/plain demand without
  manufacturing marker depth; actual Requirement marker demand still supplies
  measured terminal lead and endpoint spans.
- Types, canonical schema/declaration metadata, SDK decision union and internal
  render-stage identity include Trinity. The engine-free option-contract split
  remains intact; public selection adds no new default backend.
- Browser/hosted-worker aliases send static Trinity imports to one lazy facade
  and leave its dynamic implementation import real. The facade keeps one
  implementation/pending owner, resets rejected loading, and throws the named
  deferred dependency. The public browser retry owner recognizes that name and
  replays its captured request under existing bounded retry guards. Other
  family selection does not demand the Requirement-only kernel through this
  route. Standalone remains intentionally self-contained.

Cost caveat: source/Node Requirement statically imports the Trinity implementation;
adding a backend can increase import/startup and shipped bytes even when the
caller selects Native or ELK. Browser demand isolation is not a claim that every
runtime has unchanged loading cost. The coordinator reports successful focused
owners, types/lint and actual lazy/editor builds; this reviewer did not rerun
them or infer payload/time improvement from build success.

This registration exposes only the bounded Requirement<=64nodes/128edges slice.
It is not completion of compound/family coverage, historical quality-gap closure,
across-metric superiority or adoption/default-switch evidence. Existing actual
paint/proof/cost tradeoffs and unsupported inputs remain part of its contract.
