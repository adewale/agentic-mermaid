import { layoutAgenticGraph } from '/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered.ts'
import { planAncestorBoundaryConnections, projectAncestorBoundaryPlaceholder, routeAncestorBoundaryConnection } from '/tmp/pr449-main-integration-20261029-762/src/layout/ancestor-boundary-routes.ts'
import { scoreMeasuredRouteCrossings } from '/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts'
const padding = { top:40,right:20,bottom:20,left:20 }, fail=(s:string):never=>{throw Error(s)}
for(const pairs of [20000,200000])for(const optional of [false,true]){
 const input:any={direction:'TD',padding:20,nodeSpacing:40,layerSpacing:60,edgeSpacing:8,nodes:[{id:'edge__0',width:80,height:36,parent:1}],groups:[{id:'group__0',minWidth:120,headerHeight:24,padding},{id:'nested__0',parent:0,minWidth:100,headerHeight:24,padding}],edges:[{source:1,target:0,minSpan:1,label:{width:44,height:12}},{source:0,target:1,minSpan:1,label:{width:46,height:12}},{source:1,target:0,minSpan:1},{source:1,target:2,minSpan:1,label:{width:36,height:12}}]}
 const work={pairs,arcs:65536,swaps:500000},owners=new Int32Array([1,-1,0]);let edge=-1,allocated=0
 try{
  const plan=planAncestorBoundaryConnections(input,owners,work,fail),placed=layoutAgenticGraph({...input,groups:plan.groups,edges:[]});allocated=placed.expandedVertices??0
  const reserve=(n:number)=>{if(allocated+n>32768)fail('shared expansion limit');allocated+=n}
  placed.edges=input.edges.map((_:unknown,i:number)=>projectAncestorBoundaryPlaceholder(plan,i,placed.groups!,reserve));const finished=new Set<number>()
  for(const index of plan.connections.keys()){
   edge=index;const route=routeAncestorBoundaryConnection(input,placed,owners,plan,index,{work,remainingVertices:32768-allocated,reserveVertices:reserve,fail,score:c=>scoreMeasuredRouteCrossings(c.points,index,placed.edges.map((r:any,i:number)=>({...r,style:finished.has(i)?'solid':'invisible'})),input),...(optional?{proposalPairs:128}:{})});placed.edges[index]=route;finished.add(index)
  }
  console.log(JSON.stringify({pairs,optional,result:'delivered',edge,work,allocated}))
 }catch(error){console.log(JSON.stringify({pairs,optional,result:'refused',edge,error:String(error),work,allocated}))}
}
