| copyInner | scene/native-paint-emission.ts:105 | 29.74 / 36.08 |
| assessLayoutGeometry | layout-rubric.ts:493 | 6.29 / 15.24 |
| verifyDocumentEnvelope | output-security.ts:326 | 4.59 / 10.42 |
| measureRubricMetrics | layout-rubric.ts:648 | 4.54 / 22.39 |
| copy | scene/native-paint-emission.ts:243 | 4.46 / 36.88 |
