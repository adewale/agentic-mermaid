const diag = { queries: 0, builds: 0, rejected: 0, returned: 0 }; process.on('exit', () => console.log('PEER-DIAGNOSTIC',JSON.stringify(diag)))
import type { Point, PositionedEdge } from '../types.ts'
import { labelRect } from '../shared/edge-label-geometry.ts'
import type { LabelMetricsStyle } from './route-geometry.ts'

type Box = { x0: number; y0: number; x1: number; y1: number }
export interface RoutePeerIndex {
  invalidate(edge: PositionedEdge): void
  query(points: readonly Point[], clearance: number): readonly PositionedEdge[] | undefined
}

function pointBounds(points: readonly Point[]): Box | undefined {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity
  for (const point of points) {
    if (!Number.isFinite(point.x) || !Number.isFinite(point.y)) return undefined
    x0 = Math.min(x0, point.x); y0 = Math.min(y0, point.y)
    x1 = Math.max(x1, point.x); y1 = Math.max(y1, point.y)
  }
  return points.length ? { x0, y0, x1, y1 } : undefined
}

/** One admitted synchronous route owner. A packed broad phase shares route
 * and label envelopes; exact lane/crossing predicates keep their original
 * peer order. Every route or label write invalidates the affected leaves. */
export function createRoutePeerIndex(edges: readonly PositionedEdge[], style: LabelMetricsStyle, admit: () => boolean): RoutePeerIndex {
  const prepare = () => { diag.builds++
    let capacity = 1
    while (capacity < edges.length) capacity *= 2
    const bounds = new Float64Array(8 * capacity)
    const ordinalAt = new Int32Array(2 * capacity).fill(-1), leafAt = new Int32Array(edges.length)
    const ordinals = new Map<PositionedEdge, number[]>(), uncertain = new Set<number>(), dirty = new Set<PositionedEdge>()
    const boxes = edges.map((edge, ordinal) => {
      const slots = ordinals.get(edge)
      if (slots) slots.push(ordinal)
      else ordinals.set(edge, [ordinal])
      return envelope(edge)
    })
    function envelope(edge: PositionedEdge): Box | undefined {
      const box = pointBounds(edge.points), label = labelRect(edge, style)
      if (!box) return undefined
      if (label) {
        box.x0 = Math.min(box.x0, label.x); box.y0 = Math.min(box.y0, label.y)
        box.x1 = Math.max(box.x1, label.x + label.w); box.y1 = Math.max(box.y1, label.y + label.h)
      }
      return Object.values(box).every(Number.isFinite) ? box : undefined
    }
    const write = (node: number, box?: Box): void => {
      const at = 4 * node
      bounds[at] = box?.x0 ?? Infinity; bounds[at + 1] = box?.y0 ?? Infinity
      bounds[at + 2] = box?.x1 ?? -Infinity; bounds[at + 3] = box?.y1 ?? -Infinity
    }
    const join = (node: number): void => {
      const at = 4 * node, left = 8 * node, right = left + 4
      bounds[at] = Math.min(bounds[left]!, bounds[right]!)
      bounds[at + 1] = Math.min(bounds[left + 1]!, bounds[right + 1]!)
      bounds[at + 2] = Math.max(bounds[left + 2]!, bounds[right + 2]!)
      bounds[at + 3] = Math.max(bounds[left + 3]!, bounds[right + 3]!)
    }
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity
    for (const box of boxes) if (box) {
      x0 = Math.min(x0, box.x0); y0 = Math.min(y0, box.y0)
      x1 = Math.max(x1, box.x1); y1 = Math.max(y1, box.y1)
    }
    const axis = x1 - x0 >= y1 - y0 ? 'x0' : 'y0'
    const order = edges.map((_, ordinal) => ordinal).sort((a, b) => (boxes[a]?.[axis] ?? 0) - (boxes[b]?.[axis] ?? 0) || a - b)
    for (let ordinal = 0; ordinal < capacity; ordinal++) {
      const index = order[ordinal], leaf = capacity + ordinal
      write(leaf, index === undefined ? undefined : boxes[index])
      if (index !== undefined) {
        ordinalAt[leaf] = index; leafAt[index] = leaf
        if (!boxes[index]) uncertain.add(index)
      }
    }
    for (let node = capacity - 1; node; node--) join(node)
    return { bounds, ordinalAt, uncertain, dirty, flush() {
      for (const edge of dirty) for (const ordinal of ordinals.get(edge) ?? []) {
        const box = envelope(edge), leaf = leafAt[ordinal]!
        if (box) uncertain.delete(ordinal)
        else uncertain.add(ordinal)
        write(leaf, box)
        for (let node = leaf >> 1; node; node >>= 1) join(node)
      }
      dirty.clear()
    } }
  }
  let state: ReturnType<typeof prepare> | undefined, admitted: boolean | undefined
  return {
    invalidate(edge) { state?.dirty.add(edge) },
    query(points, clearance) { diag.queries++
      if (edges.length < 32) return undefined
      const box = pointBounds(points)
      if (!box || !Number.isFinite(clearance) || clearance < 0) return undefined
      admitted ??= admit()
      if (!admitted) { diag.rejected++; return undefined }
      // Preserve distance-subtraction boundary behavior and extreme-number
      // fallback. Inflating by clearance alone can round a nearby hit away.
      const error = (Math.abs(box.x0) + Math.abs(box.y0) + Math.abs(box.x1) + Math.abs(box.y1)) * 2e-10 + 2e-9
      box.x0 -= clearance + error; box.y0 -= clearance + error
      box.x1 += clearance + error; box.y1 += clearance + error
      if (!Object.values(box).every(Number.isFinite)) return undefined
      const current = state ??= prepare()
      current.flush()
      const found = [...current.uncertain], stack = [1]
      while (stack.length) {
        const node = stack.pop()!, at = 4 * node, b = current.bounds
        if (box.x1 < b[at]! || box.y1 < b[at + 1]! || box.x0 > b[at + 2]! || box.y0 > b[at + 3]!) continue
        const ordinal = current.ordinalAt[node]!
        if (ordinal >= 0) found.push(ordinal)
        else if (2 * node < current.ordinalAt.length) stack.push(2 * node, 2 * node + 1)
      }
      found.sort((a, b) => a - b)
      diag.returned += found.length; return found.map(ordinal => edges[ordinal]!)
    },
  }
}
