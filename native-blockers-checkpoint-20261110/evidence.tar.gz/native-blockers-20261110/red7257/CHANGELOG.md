# Changelog

This changelog tracks user-facing changes for **Agentic Mermaid**, a fork of `lukilabs/beautiful-mermaid` maintained in the `adewale/agentic-mermaid` repo and published as the `agentic-mermaid` npm package. Upstream-focused PR branches keep their own minimal histories.

## Unreleased

### Added

- Insert and remove empty concurrency regions in composite states with
  `add_region` and `remove_region`. State, transition, move and floating-note
  edits can append the next region while preserving scoped notes and comments.

### Fixed

- Rebase declaration positions when grouping states after transition removal,
  and preserve inferred declaration order across edits to legacy state bodies.
- Reject region removal that cannot preserve both composite and surviving
  region directions in Mermaid source.

## 0.5.6 — 2026-11-02

### Performance

- Load the native PNG rasterizer only when PNG rendering reaches rasterization,
  avoiding its initialization for parsing, verification and SVG rendering.
- Reuse one captured request and positioned result for SVG/PNG action rendering,
  removing duplicate positioning work.

### Fixed

- Keep SVG/PNG action hit regions aligned with the drawing when render options
  have stateful getters. Isolate mutable projections from cached geometry and
  reject unsupported projections before drawing hooks run.
- Detect moved dashes in the Chromium resolved-scene CI comparer while accepting
  equivalent path encodings and symmetric dashed reversals.
- Prepare website test fixtures once per invocation instead of reusing stale
  output after repeated dirty build-config edits. Keep the editor build child's
  deadline within its existing 60-second test budget.

### Changed

- Use one agent operating guide across the CLI, installed skills and website.
  `am init-agent` includes an offline copy and pins MCP configuration to the
  installed package version.
- Enforce layout-repair dependencies and route-write restrictions while retaining
  the existing pass order, placement rules and geometry budgets.
- Use Bun 1.4.4 for CI and release/deployment builds, avoiding Bun 1.4.2's
  independently reproduced pipe-GC subprocess hang. Install a payload comparison's
  base Bun through npm so it works in browser containers without `unzip`.
- Share qualified build artifacts, select documentation checks for recognized
  Markdown changes, and verify exact npm identity before MCP registration.
  Strengthen executable-example, fresh-output and JSON-RPC checks.
- Remove redundant verification gates, unused pass metadata and historical raw
  measurement packets from the current checkout. Immutable links retain access
  to the archived evidence; maintained generated public references remain.

## 0.5.5 — 2026-10-31

### Changed

- Generate website MCP tool lists, verification wording and backend-limit
  documentation from shared authorities; repair family navigation and obsolete
  contributor commands and links.
- Add `bun run release:prepare VERSION [--date YYYY-MM-DD]` to update version
  projections and run their existing generators together. Failed generation
  restores prior file contents; preparation leaves publication explicit.
- Consolidate the release checklist, record completed 0.5.4 delivery, and
  separate the current backend contract from dated design and experiments.
- Keep directory-submission records in repository-only project documentation
  rather than shipping operational status snapshots in the npm package.

### Fixed

- Preserve distinct XY axis ticks for tiny and large finite ranges, and avoid
  overflow when projecting a range that crosses both numeric extremes.
- Treat soft hyphens and zero-width spaces as discretionary line-break hints
  in pixel and terminal text, preserving authored source positions and styles.

### Added

- Expose resolved scenes through Code Mode and agent capability discovery, with
  on-demand painted primitive declarations and typed unsupported-artwork errors.
- Add `am verify --markdown` to check Mermaid fences with physical document
  lines while keeping ordinary verification and Markdown rendering behavior.

## 0.5.4 — 2026-10-30

### Fixed

- Render 128-card Class chains with Agentic and 128-entity ER chains with either
  backend without exhausting paint certification or falling back to another
  backend. Preserve authored identities and directed relationship endpoints.
- Give independent self-loops and labelled relationships separate channels
  where they previously shared unrelated connector segments. Reserve source
  and target arrowhead clearance separately and measure the complete straight
  terminal run, including redundant waypoints. Crowded fixed ports can still
  prevent a short terminal from being extended.
- Keep Scene group inspection and emitted paint consistent for joins, open and
  closed paths, and transforms. Preserve immutable text ownership in private
  cache copies while keeping public copies independent.

### Performance

- Reuse spatial queries in ER layout and paint certification, choosing linear
  scans for small query batches and rebuilding indexes after routes move.
  Supported sparse ER diagrams with 4,096–5,000 entities complete certification
  within the existing 400,000-operation allowance; Agentic retains its
  4,096-node cap. Avoid duplicate scene capture and immutable text processing
  on large ER renders.

### Changed

- Stop opening release-to-do issues automatically when deployment skips an
  unpublished version. Keep the warning and Actions summary; verified
  deployments still close existing release-to-do issues.

- Refresh MCP directory evidence, submission requirements and dated publication
  status, including Smithery's 31 October service transition.

## 0.5.3 — 2026-10-29

Includes the 0.5.2 changes below. Its registry publication was blocked when
GitHub could not allocate a macOS arm64 runner; its source tag is retained.

### Fixed

- Keep styled arrowheads clear of connector bends in Flowchart, Architecture,
  Block, Class, Requirement, C4, Event Modeling and Gantt dependencies by
  reserving the painted marker depth plus 4 px of straight shaft through
  routing and rounding.
- Run the required macOS release build and rendering contracts on a standard
  Intel macOS 26 runner. Windows coverage, the rendering suite, build heap
  allowance and verified-artifact publication gates are unchanged.

## 0.5.2 — 2026-10-29

### Fixed

- Parse long same-line Flowchart chains without rescanning the remaining
  chain for each node's edge-ID diagnostic. Preserve the existing syntax
  warnings and source-map spans.
- Align ELK routes whose straight runs differ only by floating-point roundoff
  as they are read back, so wide Class diagrams with padded cards keep their
  card contacts instead of refusing to render, and Flowchart, State, ER and
  Requirement routes start exactly orthogonal.
- Render Class diagrams with rounded relationship corners, such as the
  `publication-figure` style, when a relationship must bypass a namespace
  header, including nested namespaces.
- Render publication-styled Flowcharts with compound long links when joined
  route sections differ only by floating-point roundoff, retaining their
  endpoint contacts and existing route-safety checks.
- Keep Flowchart relationship ends readable: clear endpoint labels and styled
  arrowheads, symmetric grouped fan-outs with safe caption seats, and distinct
  terminals for differently painted or separately captioned relationships.
- Reject shared buses that imply invisible or differently painted relationships,
  including replacements that introduce a new misleading overlap without
  increasing the overlap count.

## 0.5.1 — 2026-10-29

Includes the 0.5.0 changes below. That version's npm and MCP Registry
publication was blocked by the macOS declaration build; its GitHub source tag
is retained.

### Fixed

- Give release-platform builds a 4 GiB Node old-space limit so tsup's declaration
  worker can finish on macOS runners. The limit applies only to the build step;
  rendering smoke tests and verified-artifact publication retain their checks.

## 0.5.0 — 2026-10-28

Changes since 0.4.1, including the unpublished 0.4.2 development cycle.

### Added

- Explicit source-preserving edits for opaque Class and Flowchart diagrams
  across library, CLI, MCP and editor-worker workflows. Class supports adding
  members and removing owned whole-line members; Flowchart supports label
  overrides and owned node renames. Edits retain other source bytes and require
  complete native-model read-back; ambiguous ownership, dependencies and
  semantic changes outside the requested edit are refused atomically.

- Serve existing Markdown directly from the canonical API, warning and error
  page URLs when GET/HEAD requests prefer `text/markdown`, with page-specific
  discovery, `Content-Location` and cache-safe `Vary: Accept` headers.

- Generate the website's library reference and Markdown download from the
  canonical API documentation, with task-first examples, runtime-derived option
  defaults, source/release version information and a separate advanced reference.

- Export synchronous `renderResolvedScene` and `RESOLVED_SCENE_VERSION = 2`
  from the main entry. Resolved parts retain their Scene nodes and expose
  backend-painted paths, text runs, concrete paint, transforms and expanded
  markers without a browser. The returned SVG matches `renderMermaidSVG`;
  unsupported artwork fails with its owning part instead of being dropped.

### Performance

- Source-preserving edits avoid duplicate Flowchart parsing when authored and
  rendered parser inputs are identical, and avoid redundant Class quote-provenance
  work when the authored grammar is unchanged. Distinct text interpretations
  retain independent read-back. Local edit-kernel measurements do not establish
  an end-to-end CLI, MCP or browser speedup.
- Published Node bundles compact whitespace without rewriting syntax or renaming
  callable exports. The package keeps its existing exports, resources and lazy ELK
  boundary.
- Benchmarks retain verified packed inputs, dependency locks, complete peer
  observations and explicit cache/assertion policy. Scoped findings and remaining
  competitor gaps are in the benchmark report linked from the documentation hub.

### Known limitations

- The #363 decision record distinguishes generous reads from portable
  structured output. Quadrant text/style exports, unsupported Architecture
  IDs/icons and empty Class output retain named limitations; Class, Quadrant
  and Architecture also have accepted-source reader gaps. The decisions are
  complete, but those runtime follow-ups remain in `TODO.md`.
- These source changes do not establish publication or deployment. Default
  verbatim wrapper preservation is distinct from canonical rewriting;
  successful structural verification alone is not a general lossless-editing
  guarantee.

### Fixed

- GitGraph string exports preserve authored values through Mermaid reload;
  Class namespace admission and Kanban authored-source provenance retain their
  respective identity and text contracts. Marker certification checks the
  serialized marker paint and placement used by the shipped SVG (#572).

- Preserve Class direction-like label text in portable exports, refuse lossy
  empty Class and unrepresentable Quadrant labels, and share Ishikawa/Sankey
  header handling between direct rendering and typed reads (#548–#552).

- Canonical writes preserve empty accessibility descriptions using native
  metadata comments, protect directive-looking Kanban labels and metadata,
  and move C4 global metadata out of nested boundaries. Sequence message IDs
  that collide with keyword prefixes stay diagnosed and source-only rather
  than entering a typed body with no portable spelling.

- Resolved scenes report the input diagram's registered family. Both State
  headers return `state` instead of their shared `flowchart` rendering family.
  Resolved Scene version 2 records this metadata change; SVG artwork and part
  ownership are unchanged.

- Use one vocabulary for diagram families, source objects, Scene parts,
  resolved primitives and typed-family narrowing across reference docs,
  website guidance, CLI help and agent discovery, retaining existing API names.

- Sequence terminal output retains fragment headers and dividers inside wide
  participant boxes, including combined `box`/`alt`/note cases, in both ASCII
  and Unicode. The historical witness remains pinned in the test suite.
- Architecture layouts separate expanded aligned group frames and reconcile
  cross-group alignment after child reordering, preserving complete group contents
  and routing from the final endpoint positions.
- XY charts wrap rotated axis titles into the authored canvas height and reserve
  their complete multiline gutter, preserving fixed chart dimensions and text.

- Kanban edits retain keyword-like column and task IDs such as `kanban` and
  `kanban-board` in Mermaid-readable source, preserving labels and membership.
- Mixed labelled and unlabelled parallel edges can use a clear target-side
  corridor when a feedback loop blocks the source-side jog. Placement reserves
  the full painted label halo and retains prior routing when the label cannot
  fit the proposed lanes.
- A copied or stale `bundle` route certificate can no longer hide a hitch.
  Exemptions remain bound to the routes constructed by the shared-trunk,
  symmetric-convergence and parallel-lane producers.
- Losing cosmetic centering proposals retain the previous feasible geometry.
  Straight-route repairs retain canonical ports unless higher-priority conflicts
  improve. Four generated valid-flowchart failures now render.
- Wildcard HTTP listeners advertise a connectable loopback URL while retaining
  their configured bind address and bearer-token policy.
- Lazy browser SVG loading fetches ELK only when placement needs it, and keeps
  one admitted request across deferred dependencies. Ordinary native rendering
  avoids declaration-ledger reconciliation and full text inspection evidence;
  strict, verify, extension admission and final paint/security checks remain.
- An inexpensive Scene admission cannot bypass a later strict cross-check.
- Class layouts preserve authored `ns:` IDs, actual namespace ancestry, empty
  namespace frames and freestanding notes. Notes-only terminal output retains
  its content too.

### Maintenance

- Retire copied discovery/API inventories, the empty-divergence pin and
  exclusions-ledger hygiene gates. Keep live generated discovery, executable
  divergence behavior and shipped/external artifact integrity checks.
- Family portfolio selects four distinct inputs for all 23 native families.
  Degenerate-route failures always retain their complete diagnostic report.

### Earlier fixes

- `verify` on a source string checks the request `render` makes from that
  string, including its `%%{init}%%` and frontmatter config. It used to check
  a canonical copy that drops that config, so it measured a different layout
  (for example ignoring `flowchart.rankSpacing`) and passed sources `render`
  refuses: raw `themeCSS`, an unsafe `themeVariables.fontFamily`, or spacing
  so large the canvas exceeds its cap. These are now `RENDER_FAILED`.
- Refused config no longer makes `parseMermaid` and `verify` throw: config
  the admission refuses (a reserved key such as `__proto__`, nesting or size
  past its bounds) is a new `CONFIG_REJECTED` parse error, which `verify`
  reports as `RENDER_FAILED` with origin `config`. `verify` reports any
  non-empty source that fails to parse (a syntax error, frontmatter that is
  not valid YAML, a diagram over a work limit) as `RENDER_FAILED` with the
  parser's message, not `EMPTY_DIAGRAM`, and suppressing that finding no
  longer makes such a source verify `ok`. A work limit only the render path
  enforces (state nesting) no longer escapes `verify` as an exception.
- `verify` on a Flowchart or State diagram whose render fails (refused config
  such as raw `themeCSS`, or a layout past the canvas cap) still reports the
  findings it reads from the diagram itself (`LABEL_OVERFLOW`,
  `EDGE_MISANCHORED`, `UNKNOWN_SHAPE` and the advisory lints) beside
  `RENDER_FAILED`, so fixing the config does not surface them one at a time.
  A refused color is still the whole finding.
- A registered family whose parse hook throws no longer makes `parseMermaid`
  and `verify` throw: the throw is a `FAMILY_DESCRIPTOR_CONTRACT` parse error,
  which `verify` reports as `RENDER_FAILED` with origin `config`.
- A State transition to a state that another composite or concurrency region
  already holds (`state B { y }` then `state A { x --> y }`) draws the
  transition across to it. Each mention used to add the state to every
  composite, which the layout refused as a duplicate (`INTERNAL_ERROR`). The
  first composite to mention a state owns it; Mermaid moves it into the last,
  a difference recorded in `docs/project/divergences.md`.
- A parsed State diagram, and the source `serializeMermaid` writes for it,
  lay out as its source does. The writer put every declared state and
  composite block ahead of the transitions, so a state described or declared
  after the transitions that introduce its siblings (including one a
  `C:::hot` shorthand declares) moved in the layout, and `[*]` nodes were
  renumbered. The writer now keeps each scope's states in the order the source
  creates them, the typed body lists them in that order (it used to list
  declared states first), and a `[*]` inside composite `X` is `X_start`,
  `X_start2`, … (`X_end`, …), numbered within `X` rather than across the
  diagram. Top-level ids stay `_start`, `_start2`, ….
- A State diagram that names a state `_start` or `_end` (or `_start2`, …)
  keeps its `[*]` start and end nodes. The generated pseudostate took the
  author's id, so the start node vanished into the authored state and
  `verify` still reported `ok`; a generated id now skips any an author wrote.
- A Flowchart, State, Sequence, Class or ER diagram with a frontmatter title
  and nothing else draws its title, as every other family does and as its
  terminal output already did. Flowchart and State used to fail the render
  (`LayoutCertificationError`: the title fell outside a 0×0 canvas); Sequence,
  Class and ER drew an empty canvas without it. `verify` still reports
  `EMPTY_DIAGRAM`.
- A `theme` config value that is not a string (`%%{init: {"theme": 5}}%%`)
  no longer crashes every render and makes `verify` report `INTERNAL_ERROR`.
  Like an unknown theme name, it names no theme and the default colors apply.
- The MCP `describe` tool no longer reports success for a source that does
  not parse in its default text format. Every format returns `ok: false`
  with the parser's errors (text also keeps its prose line), as JSON and
  facts did and as `am describe` exits non-zero.
- A parsed diagram drawn from its canonical body (Flowchart, Timeline, Class,
  ER, Journey, Architecture, any source-preserved body, and extension families
  that render canonically) renders, lays out and verifies under its authored
  config wrapper (frontmatter title and config, `%%{init}%%` directives), as
  its source and its serialized output do (an edited diagram already did).
  `renderMermaidSVG(parsed)`, `layoutMermaid(parsed)` and
  `verifyMermaid(parsed)` used to drop that wrapper for a freshly parsed
  diagram, losing the title, theme and spacing the saved source would draw.
  `renderMermaidWithActions` takes its target regions from that layout, so
  under a frontmatter title they sat a title band above the targets the
  output draws, for a source string too; they now cover them.
- A state diagram that reopens a composite state (a second `state A { … }`
  block, one-line or not) draws one state A holding both blocks' states, as
  Mermaid does. Each block used to add its own container with the same id,
  which the layout engine could not resolve, so the render failed. A stays
  where its first block is, a block reopening a `--`-split composite
  continues its last region, and the first block's `direction` holds. A
  later block's label labels A, joined with any other label or description
  as one composite's are (`state_composite_description` where Mermaid
  rejects them). The readings that differ from Mermaid's are recorded in
  `docs/project/divergences.md`.
- Sankey and XYChart SVGs draw the canvas that `layoutMermaid`, `verify` and
  `renderMermaidWithActions` regions describe. The final paint check
  over-measured their ink (half a line width past the butt-capped ends of
  XYChart axis and grid lines, which end on the canvas edge; far past the ends
  of thick Sankey ribbons, and twice their width in every direction once a
  ribbon's control point had been rounded), so the SVG widened its `viewBox`
  beyond the layout's bounds (an XYChart's 700×500 became 701×500.71, a
  Sankey's 648×448 became 672×464.59 or as much as 1728×1194.67) and drew the
  whole diagram scaled down inside the same width and height. A Sankey ribbon
  thicker than its bend, which folds past the node it meets, now widens the
  canvas to hold that ink.
- A diagram whose ink touches the canvas edge only by floating-point noise
  keeps its canvas. A Journey actor legend title whose top came out at
  -3.6e-15 made the SVG floor its `viewBox` to `0 -1 409.43 373` against the
  layout's 408×372; the final paint check now treats ink within 1e-6 of the
  edge as on the canvas.
- An XYChart line series clamps a value past the axis range to the plot edge,
  as a bar already does, and keeps its value (`verify` still reports
  `VALUES_OUTSIDE_RANGE`). The line used to run off the plot, and the SVG
  widened its `viewBox` to hold it (`0 -457 1622.6 1159` for one out-of-range
  value), drawing the chart at under half size. Where the plot meets the
  canvas edge, it now leaves room for the marks centered on that edge: a line
  point's cap or dot at a linear x-axis end, the last tick there, and the end
  grid lines and ticks of a chart with no title or value labels beside them.
  Each of these widened the `viewBox` by a pixel or two. A line point's
  measurement footprint is the part of it inside the plot.
- Font families may be double-quoted, as Mermaid's own default
  `"trebuchet ms", verdana, arial, sans-serif` is: the font option,
  `fontFamily` config, theme variables, Journey font config, style-role fonts
  and Architecture group fonts accept them. A font written into a style
  attribute or stylesheet is written single-quoted; a `font-family`
  attribute escapes the quotes. A quote that does not close, a name holding
  the other quote character, and whitespace other than space and tab stay
  refused.
- Paint inspection applies enclosing group opacity to inline connector labels,
  including hidden labels, consistently with the SVG writer.

- Journey `taskFontFamily` and `titleFontFamily` config values are written
  into CSS only when they are safe font-family lists; an unsafe value (one
  that closes the rule or fetches with `url()`) is ignored with an
  `INEFFECTIVE_CONFIG` warning instead of restyling the whole diagram.
- C4 relationships between facing cards of different heights run straight.
  Ports spaced evenly along each face sat a few pixels apart, which drew a
  small dogleg on each such relationship.
- Drawings that disagreed with their certified paint now draw it: a Pie
  slice's role or semantic-slot border and its highlight emphasis, which
  stylesheet rules overrode; abstract, static and non-ASCII Class members,
  which painted in SVG's default black instead of the member ink; a Journey
  `titleFontSize` in `em`/`ex`, which drew squashed. (A Journey title's letter
  spacing is now on its `<text>` too, but its per-glyph spans already drew it.)
  Sketch styles now draw Radar areas with the translucent fill and opaque
  outline the default style draws, XYChart series lines with round caps and
  joins, and a done Gantt bar's border. Under a sketch look stacked with a dark palette
  (for example `watercolor` with `dusk`), Architecture labels, Journey task
  text and Timeline event text take the sketch's legible ink instead of a
  family stylesheet's dark ink.
- Context codecs preserve entity-derived tags, emphasis and backslash-n as
  literal text beside authored formatting in Flowchart, ER, Sequence and Class.
  Parsed aliases and labels retain their meaning through edits and reload;
  typed entity-looking strings remain literal without caller pre-escaping.
- Sequence aliases, messages and notes share prepared display text with their
  graphical and terminal projections. Physical message line breaks serialize
  as Mermaid break markup. Class members and annotations share their display
  formatter with layout and label metrics (CONS-46).
- Sequence text holding a character reference is text on every surface. The
  renderer decodes references before reading statements, so `&#35;hash` hid
  the rest of a message as a comment, `&#59;` split it and failed the render,
  and `&nbsp;`, which that decode leaves as written, split it too. The typed
  body read the undecoded source, so `A->>B: a &amp; b` became two statements
  there and `verify` reported `RENDER_FAILED`. The SVG and terminal renderers,
  the typed body and its lints now read one Sequence text: XML references
  decode to their characters, except that `#` and `;` read as `#35;` and
  `#59;`, and an HTML name such as `&nbsp;` reads as `#nbsp;`, so each draws its
  character (`&amp;nbsp;` still draws `&nbsp;`, and `R&D;`, which names no
  character, still ends its statement). Parsed diagrams and their
  serialization draw what the source draws, and serialization writes text
  Mermaid reads (`a & b`, `#35;`), escaping an `&` that would read back as a
  reference. `verify` reports `UNSUPPORTED_SYNTAX` with
  `sequence_named_reference_semicolon` where pinned Mermaid ends the statement
  at a named reference's `;`.
- Class namespace labels use the same break and formatting rules in native and
  typed rendering. ER attribute diagnostics measure rendered columns rather
  than entity spellings or grammar delimiters. C4 relationship receipts retain
  literal tags and untransformed text under graphical casing and tracking.
- Flowchart labels affected by upstream's quote preprocessor remain readable
  and receive `UNSUPPORTED_SYNTAX` with `flowchart_preprocessor_quote_rewrite`;
  canonical output uses a portable entity spelling (#372).
- State descriptions, aliases, transition labels and notes retain literal `%%`
  in text contexts. Mindmap labels, icons and class payloads retain that text
  too; actual comments still follow their grammar context. State block-note
  lines beginning with `%%` intentionally remain note content (#372).
- ER edits retain entity order and group ownership through export and reload,
  including removing the entity or relationship that first introduced them
  (#372). The old BUG-10 estimate of about 0.6% of fuzzed edits is historical,
  rather than a measurement of this candidate.
- Journey admits title, section and task labels made entirely of line breaks.
  Intentional empty Pie, Architecture, Journey and XY edits succeed when their
  emitted source renders; standalone verification still reports emptiness
  (#367).
- Canonical YAML output preserves whitespace-only scalar lines and trailing
  newlines. Frontmatter boundaries retain supported footer indentation without
  consuming block-scalar content (#367).
- Class relationship markers keep their authored endpoint through unrelated
  edits, serialization and reload (#406). Semantic facts now include marker
  ownership, both-ended marker kinds and shaft style; existing fact strings
  remain, but callers using `checkMermaid` with `exact: true` must include the
  new facts. `docs/api.md` gives a complete-set migration example.
- Class dashed diamond relationships retain their shaft style independently
  of endpoint markers. Native parsing, edits, serialization, SVG/Scene and
  terminal output support two-ended and mixed lollipop relationships, including
  escaped endpoint identities. Public relation operations accept endpoint and
  shaft metadata and refuse contradictory combinations. Exports keep required
  backticks on reserved endpoint identities, including attached notes and links,
  and write relationship label/cardinality line breaks as Mermaid markup.
  Both Code Mode SDK declarations accept parse → narrow → edit workflows;
  the full declaration exposes the new relation fields.
- Checked and declarative Class edits accept the supported `lollipop`
  relationship kind, matching direct typed mutation (#407).
- Class `add_member` and initial `add_class.members` reject LF/CRLF that
  would split a member on reload; bare CR is also rejected under the
  single-line member policy (#408). Literal backslash-n and ordinary
  single-line member text remain supported. Blank/comment-form members,
  accessibility directives and decoded line breaks are refused too; initial
  member arrays are copied so a caller cannot change the returned diagram
  through the supplied array.
- XY-chart titles wrap to the configured canvas width and reserve space above
  the plot, keeping long titles visible in vertical and horizontal charts.
  Verification names titles that cannot fit the configured title-space budget
  with `LABELS_HIDDEN`, rather than omitting them silently.
- Timeline periods whose names begin with `Timeline` retain their labels and
  events in SVG, terminal output and verified layout.
- State rendering rejects unknown statements with a named `RENDER_FAILED`
  diagnostic instead of returning a partial diagram. Explicit `state Idle`
  declarations retain isolated states in both the editable model and drawing.
  Canonical labels write `<br/>` breaks so normalized multiline text survives
  re-parsing and verification. Unmodeled statements and floating notes fail
  explicitly rather than being silently omitted. Harmless slash comments
  remain preserved; recognized legacy layout directives render known topology
  and warn that their layout behavior is not applied.
- Class edits prune empty unlabeled namespaces and refuse to erase explicit
  labels. Labeled parents retain surviving descendants in valid nested exports;
  directly authored empty namespaces remain source-preserved and non-editable.
- Two labeled edges from a decision diamond to the same rectangle render on
  separate, outline-anchored routes with readable labels.
- Flowchart and sequence `@{ … }` metadata is read as YAML, as Mermaid reads
  it: escapes such as `\t`, `\x41` and `''` work, and metadata Mermaid rejects
  (`'a}b;c'`, `\'`, unknown escapes, duplicate keys, an unquoted `^`, an empty
  sequence `@{}`) is a syntax error. Keys are case-sensitive, and a multi-line
  block is block YAML.
- `participant B@{ "alias": "Y" } as B` is labelled Y, as in Mermaid. A typed
  sequence diagram keeps `actor A@{ "type": "participant" }`, and relabelling a
  participant named by a metadata alias inside a block sticks.
- Frontmatter that is not valid YAML is rejected ("Mermaid frontmatter is not
  valid YAML: …"; CLI exit 4) instead of being ignored. Frontmatter the old
  reader dropped (a multi-line quoted value closed under its key) now applies.
- A label with an unknown tag (`A[a<c>d]`), or a Gantt, XYChart, GitGraph or
  Radar label containing `<b>`, renders instead of failing with
  `RENDER_FAILED`; unknown tags are drawn as text.
- Class notes, State block notes and Gantt section titles break at `<br>`, as
  Mermaid does.
- ASCII and Unicode output no longer shows `<b>`, `**`, `*…*` or `~~` markup in
  formatted labels, and the layout meta's `projectedText` is the text the cells
  show. A Quadrant label with `<br>` no longer breaks the terminal frame, and
  Quadrant axis labels render their formatting instead of showing tags.
- `LABEL_OVERFLOW` measures Pie, Timeline, Gantt, XYChart, GitGraph and Radar
  labels as drawn, counting `<br>` and tags as characters.
- A gitGraph with no commits verifies as `EMPTY_DIAGRAM`, like every other
  family's bare header.
- A blank diagram saved from `createMermaid` re-parses typed wherever Mermaid
  11.16 accepts the bare header. Bare `pie`, `journey` and `timeline` headers
  render the empty chart Mermaid draws instead of failing, and a titled or
  axis-only XY chart is typed and no longer reported as empty. A blank Sankey
  still fails, as in Mermaid.
- A trailing `%%` comment is ignored where Mermaid's grammar ignores it: Pie,
  XYChart, Quadrant (except titles), Radar, Architecture and GitGraph
  statements, and Gantt headers and keyword statements. When typed
  serialization drops such a comment, verify reports `COMMENT_DROPPED`.
- Source whose meaning is clear but which Mermaid 11.16 rejects is drawn, and
  `verify` reports `UNSUPPORTED_SYNTAX` on its line, naming the construct and
  the spelling Mermaid reads: a bare `classDiagram` header (what a blank
  `createMermaid('class')` saves); a `%%` comment after a class declaration, in
  a namespace or after `}`; unquoted Quadrant text Mermaid's lexer does not
  read as text; Architecture titles, icons and ids outside Mermaid's terminals;
  a trailing `%%`, or `\"`, `\`, `%` or an empty name, in ER quoted text; a
  `linkStyle` index past the links above it; `A @{…}` spacing and mixed-stroke
  text arrows (`A -- b ==> B`); a participant declared in a second `box`.
  This records the original 11.16 compatibility pass. The current 12.2 grammar
  accepts the previously rejected Architecture title punctuation. Remaining
  writer limits and source-preserved extensions are distinguished in the #363
  decision record; serialization does not repair every such extension. A
  flowchart node id holding `--` or `-.` is still rejected when its meaning is
  unclear.
- Flowchart: a `;` inside an asymmetric label (`A>x;y]`) is label text, and
  `@{` inside a quoted label no longer turns the diagram opaque.
- ER relations written without spaces (`id1||--||id2 : label`) parse and draw.
- A sequence message whose text is only a `#…#` comment (`A->>B: #a#`) draws
  an empty message instead of an empty SVG.
- A typed `add_participant` or indexed `add_message` no longer reorders
  participants when the saved source is parsed again.
- The renderer and the typed body now read participant, node and group
  creation the same way, and follow Mermaid 11.16 where the order was a
  tie-break: `activate` creates no participant; `properties` and `details`
  lines create theirs; a box does not list an actor created before it (the
  frame still draws it); `style X` creates node X where it stands, so a
  style-only node is drawn. Repeated node/entity mentions have one deterministic
  subgraph owner and are drawn once; the mention-specific tie-break and other
  decisions are documented in the #363 record.
- `examples/index.json` lists the 16 Style × Palette example cards as
  `stylePaletteExamples`; they were the only rendered cards missing.
- `am batch --help` documents `--jsonl`.
- `llms.txt` lists `am serialize` among the CLI verbs.
- Radar's emphasized outer ring draws with `stroke-width: 2.1` instead of
  `2.0999999999999996`.
- Flowchart labels read Mermaid's `#quot;` as `"`, and a `\` inside a quoted
  label is literal, as upstream has no escapes there. The serializer writes
  `"` as `#quot;`, so labels containing `"` or `\` round-trip and upstream
  reads the output.
- An apostrophe in a flowchart label no longer hides the statement separators
  after it (`A[it's];B[y]`).
- Serialized flowchart labels and subgraph titles are quoted wherever upstream
  would reject the bare form (a bracket, `|`, `"`, `@` or `;`, or a leading
  `/`, `\`, `-` or `~~~`); a rectangle labelled `/a/` no longer re-parses as a
  lean shape.
- The ASCII render's layout data projects flowchart labels with their `*` and
  `~`, as drawn.
- A later bare `participant X` or `actor X` no longer changes a sequence
  participant that already exists; as upstream Mermaid does, only a naming
  declaration (`as …` or a metadata alias) changes its label and type.
- Sequence participants that only a preserved block creates (`rect`,
  `critical`, `break`, `box`, nested blocks, a note inside a `loop`, a
  `create` line) are now part of the typed body, facts and structural counts,
  in upstream's order; the blocks stay byte-for-byte.
- `set_participant_label` on a participant no declaration names now declares
  it right after the statement that first names it, so re-parsing keeps the
  participant order.
- Compositing a translucent colour over another no longer returns channel
  values a rounding error above 255 (`#0F05` over white).
- ER entities keep their subgraph and position through serialization when the
  relation that created or placed them is removed but another relation still
  uses them; entities that must come before a subgraph's entities are declared
  before it opens.
- An ER entity that only a `style` line creates keeps its `class` through
  serialization.
- Flowchart plain labels keep `*`, `**` and `~~` as literal text, as upstream
  Mermaid does; only markdown strings (`` "`…`" ``) format them. `LABEL_OVERFLOW`
  counts those characters as drawn.
- Flowchart node, edge and subgraph labels trim leading and trailing
  whitespace, as upstream does, and typed `add_node`, `set_label`, `add_edge`
  and `add_subgraph` trim their labels the same way. Label whitespace is no
  longer preserved.
- Serialized flowcharts quote a node label or subgraph title containing `;`,
  and write a subgraph title's line break as `<br>`, so the output re-parses.
- Sequence participants that only a note names (`note left of A: …`,
  `note over A,B: …`) are now part of the typed body, facts, describe output
  and structural counts, in the order upstream Mermaid creates them.
- ER entities that only a relation declared no longer disappear from the
  serialized source when that relation is removed; the serializer declares
  them in place, inside their subgraph.
- Pie and Radar diagrams with a gapped palette theme variable (only `pie2`, or
  only `cScale1`) now render instead of failing with an internal snapshot
  error; the set slot uses the authored colour and the others keep their
  defaults, as upstream Mermaid does.
- Bounded horizontal XYChart terminal allocation by output width and kept
  target-subgraph frames disjoint from outside nodes and sibling containers.
- Preserved valid Unicode subgraph identifiers and rejected malformed explicit
  identifiers instead of silently treating them as labels.
- Canonicalized IPv6 MCP origins, recognized loopback literals, and corrected
  package-runner quickstarts to invoke the published package and `mcp` command.
- Fixed the local MCP server hanging at 100% CPU, or crashing, when a client
  sent `render_png` alongside Code Mode `execute`. Bun releases before 1.4.0
  left a `node:vm` `timeout` armed after the call returned, and it killed the
  host code that ran next. On Bun, the MCP server now requires 1.4.0 or later
  and exits with an explanation on older releases, and `execute` refuses to
  run on them. The startup PNG warm-up, which only masked the same defect, is
  removed.
- Updated React browser recipes to use the lazy browser entry, with asynchronous
  loading, cancellation, and visible error handling.

### Added

- Prepared-text reuse, certified forest layout and bounded positioned-result
  reuse are enabled by default, with startup opt-outs. Their limits and selection are
  documented in `docs/project/flagged-performance-experiments.md`.
- Added a `BELOW_READABLE_SIZE` raster-legibility warning: when `fitTo` or an
  explicit `scale` rasterizes the smallest configured text below the new
  portable `minLabelPx` floor (provisional product default 9px; `0` disables;
  CLI `--min-label-px`), receipt-bearing PNG renders carry structured evidence
  through library callbacks, CLI stderr and `--json`, local/hosted MCP
  `render_png`, and browser diagnostics. Text-only agents can now detect when
  measurable configured text falls below the selected floor; this bounded
  warning does not certify whether an image is readable.
- Added Sankey as the 16th built-in diagram family, with Mermaid-compatible
  `sankey` and `sankey-beta` CSV syntax, deterministic SVG, PNG, and ASCII
  rendering, typed agent editing, and support across the library, CLI, MCP,
  website, and full and lazy browser bundles.

### Changed
- Extension core compatibility now follows the 0.5 release line. External
  extensions declaring only `^0.4.0` must explicitly declare support for 0.5;
  the Scene contract remains version 2. Bundled descriptors bind to their
  shipped core version.
- Every built-in family's shapes, text and connectors are now written by one
  SVG writer from the typed fields paint certification reads, so a render's
  certificate describes the drawing it ships. Families no longer attach their
  own SVG strings, and family stylesheets no longer paint marks (paint is
  written on each element; hover and tooltip rules remain). SVG bytes change:
  attribute order, inline paint and omitted SVG defaults. Default-style
  rasters of the 562-input corpus are unchanged apart from Sankey link
  opacity (at most 3/255 per channel) and the anti-aliasing of the Sequence
  actor link-menu glyph. `verify` no longer compares each mark with its SVG,
  which the writer makes hold by construction.
- `verify` no longer blames the diagram for a defect in Agentic Mermaid. A
  render-path failure raised by one of the engine's own consistency checks or
  by a runtime error such as a `TypeError` is the new Tier 1 error
  `INTERNAL_ERROR`; its `defaultRender` says whether an ordinary render still
  produces output (`succeeds-unchecked`, unchecked) or throws (`fails`).
  `RENDER_FAILED` now covers faults in the source or its configuration only,
  and its new `origin` field says which. `am verify`, `am mutate` and
  `am describe` exit 4 when every error is `INTERNAL_ERROR`; a typed edit is
  accepted when its only errors are the same `INTERNAL_ERROR` defects the
  diagram already had; `am capabilities --json` lists each code's possible
  `origins`. Authored values that reach the Scene's range, extent and
  identity checks (a negative stroke width, an oversized canvas, a reused id)
  stay `RENDER_FAILED`. Invalid render options, Style inputs and theme fonts,
  and sources too long for the request receipt (with their configuration),
  are now typed refusals rather than plain runtime errors.
- The npm package no longer ships `docs/mutation-testing.md`; mutation testing
  and its CI jobs are gone. The repository no longer commits generated reports,
  receipts, upstream-corpus hashes or eval evidence, and `CLAUDE.md` records
  how contributors decide what is a bug, what to test and what to commit.
- Typed Quadrant and Architecture bodies quote titles and labels where
  Mermaid needs the quotes, so a typed edit no longer writes source Mermaid
  rejects. Typed Architecture labels are Mermaid's reading of the title
  (`["API"]` gives `API`, not `"API"`). Architecture mutations validate ids and
  icons with Mermaid's terminals and refuse a label with a backslash; Quadrant
  mutations refuse a label that needs quoting and contains `"`.
- A whole-statement `id@{ … }` for an id that is not a declared edge declares
  node `id`, as Mermaid does; it used to be dropped when it carried no node
  keys. `@{ label/icon/img }` values are written as YAML double-quoted strings.
- The lazy browser renderer detects the family from the header line alone and
  loads the source normalizer with the family. Its initial download falls from
  42.2 KB to 4.4 KB gzip. The HTML5 named-entity table (about 23 KB gzip) is
  fetched only when a diagram displays a named entity other than `#amp;`,
  `#lt;`, `#gt;`, `#quot;` or `#apos;`, so Pie's download shrinks by about
  21 KB and no family's grows by more than 1.6%.
- Internal rules that had several copies now have one: a body-utils module for
  optional fields, insert positions and label overflow; one plain-record
  check, deep-freeze and Scene walk; one set of Code Mode membrane traps; one
  XY chart layout for both orientations; one WCAG luminance and contrast
  implementation; one capability-report cache check; one SVG-hooks module per
  family shared by the sync and lazy renderers; one Mermaid entity codec, one
  YAML reader, one label display rule and one trailing-comment rule. Rendered
  output is unchanged except where an entry above says otherwise.
- Docs that list every family, MCP tool, CLI verb, render format or warning
  code are generated from the registry or marked `<!-- complete: <registry> -->`;
  a marked list that misses any member fails the doc checks, so a change that
  adds two members at once can no longer leave a list behind. A new doc check
  fails on a relative link, backticked repository path, or `bun run`/`npm run`
  script that does not exist. The MCP protocol-version lists are generated
  from the server constants, and `AGENT_NATIVE.md` and the agent-usage runbook
  now list `describe_sdk` among the hosted tools.
- Warning-code descriptions have one source, `src/agent/warning-catalog.ts`,
  and a code without a description fails typecheck. The website's per-code
  pages, the `AGENT_NATIVE.md` warning tables and the tier notes printed by
  `am --agent-instructions` are generated from it. Descriptions that
  contradicted `verify` are corrected: `RENDER_FAILED` also covers
  unrecognized headers, invalid theme colors and layout errors;
  `INEFFECTIVE_CONFIG` also covers unknown fields and invalid values;
  `LABELS_HIDDEN` covers quadrant point labels; `ROUTE_UNEXPLAINED_BEND`
  applies to flowchart and state, not class and ER; and `NODE_OVERLAP` is
  listed for every family it checks.
- Agent guidance now says one thing everywhere: write Mermaid source directly for
  a new diagram, then parse, verify, and render it; use `buildMermaid` /
  `createMermaid` when generating a diagram programmatically, and typed
  mutation for edits. `am --agent-instructions`, `llms.txt`, `am init-agent`,
  the Code Mode SDK declaration, and the skills previously disagreed.
- `am verify --help` lists the warning codes from the runtime registry, grouped
  by severity.
- Updated the `brace-expansion` development override to the first 5.x release
  patched for GHSA-rgw5-rvv9-x895.
- Updated the transitive `fast-uri` override to 3.1.7 for GHSA-qw65-cvwx-89v3
  and GHSA-58mr-gqgx-xq4g (first raised to 3.1.5 for GHSA-7p8r-x3mc-p8w7, then
  3.1.6) and pinned transitive `undici` to 7.29.1 for GHSA-rfgv-xxqx-mfg5 and
  GHSA-w293-vg96-wgc3 (first pinned to 7.29.0 for GHSA-4cwx-7wf7-3272).
- Pinned transitive `ip-address` to 10.4.0 (first pinned to 10.3.1 for
  GHSA-mwp4-54f8-5fhr).
- CI, release, and deploy now run on Bun 1.4.2 (was 1.3.13), and
  `package.json` declares `engines.bun` `>=1.4.0`. At the switch, the only
  website payload change was the editor bundle, 4,770 raw bytes smaller.
- `am capabilities --json` (and the site's `capabilities.json`) no longer
  carries the `sectionA` audit summary. Building it pulled the repository-only
  Section A report, upstream syntax manifest, and characterization index into
  the published `am` bin: `dist/am.js` shrinks from 1.35 MB to 90 KB, the
  packed tarball by 201 KB, and `am capabilities` runs about 40% faster. The
  full report stays available in the repository (`bun run section-a-report`,
  `docs/project/section-a-capability-report.md`).

## 0.4.1 — 2026-07-30

Metadata release for MCP directory listings; no rendering changes.

### Added
- Added human-readable titles to every MCP tool and published canonical directory-listing and hosted-service privacy documentation.

## 0.4.0 — 2026-07-28

### Added
- Added a hosted-MCP skill reference with exact direct-tool request shapes,
  declarative edit recovery, response acceptance rules, privacy/size fallback,
  and the distinction between MCP `tools/call` and tool arguments.
- Added a production-executable deterministic hosted-request oracle. It extracts an agent's
  `{tool, arguments}` proposal, validates the exact production tool schema, and
  executes verify, describe, mutate, build, and schema-discovery requests
  through the production core instead of scoring tool-name keywords alone.
- Added a fail-closed Codex evidence materializer that restores the complete
  final assistant message from immutable JSONL traces, preserves the harness
  artifact when necessary, and binds every trace/output to an explicit execution
  receipt before rubric grading.
- Added content-addressed raw eval evidence bundles, independently verifiable
  preparation/execution/materialization receipts, and `iteration` (three-run)
  versus `release` (five-run) completeness profiles.
- Replaced four label-only skill ablations with blind removal-based arms and
  added safe root-manifest rebasing for multi-skill ablation targets and patches.
- Added an executable skill-eval evidence gate: private holdout hydration,
  targeted evaluator sabotage across every text assertion type, exact-checkout
  task preparation with gradeable artifact paths, and a pinned repeated-run
  cohort requiring slice, all-graded-assertions, deferred semantic-judge,
  trigger-classification, latency, token, and cost reporting.
- Added a deterministic 60-example Mermaid family portfolio with an exact quota
  of four provenance-bearing inputs for each of the 15 registered built-ins,
  complementing the syntax-broad but heavily flowchart-weighted documentation
  corpus.
- Added a pinned official MCP conformance CI lane for the current `2025-11-25` initialize path and the applicable `2026-07-28` release-candidate discovery, tool-list, HTTP-header, caching, and stateless scenarios. Its strict expected-failure baseline contains only probes that require unadvertised optional methods or harness-only diagnostic tools; new failures and stale baseline entries both fail CI.
- Added a committed MCP protocol-input matrix covering required per-request metadata, header mirrors, request-id correlation, version/transport boundaries, batch rules, notification silence, and unadvertised methods. The response corpus now records those negative wire contracts explicitly.
- Expanded the skill benchmark from 31 to 39 cases, including direct hosted tool selection, schema-error recovery, hosted-size fallback, underspecified quality goals, and a repository-grounded MCP scope audit. Every case now carries domain, difficulty, trigger-type, and success-goal taxonomy, and the manifest audit reports no prompt/assertion leakage.

### Changed
- Skill evidence preparation now separates the neutral model workspace, frozen
  fixtures, and treatment skill checkout; filters unrelated skills, strips
  treatment paths from control rows, deterministically randomizes runs, and
  writes content-addressed preparation receipts over workspace bytes, full
  model stimuli, prepared tasks, fixtures, and selected treatment trees.
  Comparison fails unless the two treatment trees differ while workspace,
  fixtures, stimuli, schedule, treatment paths, and manifest remain identical.
- Skill reports now include all-graded-assertions pass rates alongside mean
  assertion fractions, count deferred semantic-judge rows separately, and use
  `imperfectPositiveRows` / `negativeBehaviorViolations` for
  answer-quality failures. False-positive and false-negative terminology is
  reserved for the autonomous trigger classifier.
- The hosted-MCP release cohort uses executor-specific model identities: the
  ChatGPT Codex profile records the accepted `gpt-5.4-mini` alias while the API
  profile retains the dated snapshot.
- The hosted workflow now gives exact production-valid state-mutation and
  class-build patterns and forbids provider-qualified or invented hosted tool
  names, closing the concrete schema guesses found by repeated model runs.
- MCP discovery and initialization now advertise a tools-only capability surface. The server no longer claims empty prompt or resource namespaces, and unadvertised `prompts/list`, `resources/list`, and `resources/templates/list` calls return Method Not Found instead of synthetic empty results.
- Protocol revision claims are now transport-exact: hosted Streamable HTTP serves `2025-03-26`, `2025-06-18`, `2025-11-25`, and the `2026-07-28` release candidate; local stdio omits batch-mandatory `2025-03-26`; and local HTTP+SSE remains `2024-11-05` only. `server/discover` and unsupported-version errors report the same exact list.
- Layout comparison reports both example-weighted and family-balanced adverse rates, so a large flowchart sample cannot hide a regression in a small family. The Mermaid documentation corpus now records its exact upstream commit, sample counts, and legacy 12-family scope instead of implying complete registry coverage.
- Recorded the owner-configured production WAF budget for the hosted MCP (`10 requests / 60 seconds / source IP`, block) and closed the route-scope promotion gate after the account owner confirmed that one dashboard rule covers both compute-capable POST paths: `/mcp` and `/.well-known/mcp`.
- Validated the deployed endpoint through the official `@modelcontextprotocol/sdk@1.29.0` client across the real Cloudflare edge: server `0.3.2` negotiated `2025-11-25` without a session, returned the exact nine-tool surface, and completed a real `render_svg` call.

### Fixed
- Fixed the hosted direct-tool eval inputs: the mutation case now supplies an
  actual source fixture, the build objective names an unambiguous class
  relationship, schema recovery requires an executable `describe_sdk` request,
  and optional read-only inspection no longer fails an otherwise safe
  clarification response.
- Fixed the hosted-request oracle so it binds exact source bytes and requested
  detail fields, proves class relationship direction/kind structurally, and
  rejects extra JSON blocks, trailing explanation, and almost-correct requests.
- Fixed the current harness integration by materializing a checkout-root runner
  manifest for harness 0.6.0, recording explicit model/reasoning execution
  provenance, and checking every compared report against the exact prepared
  task and run-output digests.
- Fixed the Codex evidence wrapper accepting an aggregate harness exit code of
  zero when every provider task had failed. It now verifies the declared
  harness package version and fails closed unless every expected task has a
  successful provider receipt, complete observations, a final agent message,
  and a non-empty output.
- Fixed evidence archives that contained run outputs but omitted the workspace,
  fixtures, and treatment trees needed to verify their causal input receipts.
  Bundle verification now recomputes those digests after extraction.
- Replaced the earlier non-causal/manual hosted summary with a generated
  five-run comparison over 160 executions. The candidate improves the tune-set
  deterministic/executable and all-graded pass rates from 55% to 100% while the
  no-skill control is unchanged; the record discloses 20 deferred semantic rows
  per variant and does not generalize the public tune-set result to the
  unexecuted private holdout.
- Fixed Codex evidence grading against 500-character normalized message
  summaries, which truncated otherwise-valid final JSON requests and created
  false failures. Grading now materializes the full final trace message first.
- Removed the repository-scope audit from the skill-lift cohort. It remains a
  useful product regression case, but comparing different repository
  implementations measures context/code changes rather than a skill treatment.
- Fixed skill paths resolving under `skill-evals/skills` instead of the shipped
  top-level `skills/`, removed public holdout/holdback answer keys, and made
  fixture outputs land under the same run directory that artifact assertions
  grade.
- Unsupported protocol-version errors are now emitted after the bounded request parse so they preserve a valid JSON-RPC request id and include the retryable supported-version list. Modern requests with missing required `_meta` fields use `-32602`; only actual header/body disagreements use `-32020`.
- Modern caching hints are emitted only for implemented cacheable list methods (`server/discover` and `tools/list`), keeping discovery, handlers, and cache metadata consistent.
- Replaced a CLI TTY-guard test that could block on the aggregate runner's inherited stdin with a bounded end-to-end subprocess using an explicitly closed pipe.
- Made guarded Cloudflare promotion survive its real production boundaries: parse the uploaded Worker version from Wrangler's structured result, pace every smoke/E2E/final MCP request under one job-wide WAF budget, and structurally decode application JSON nested inside JSON-RPC tool content before deciding whether verification passed.

### Breaking
- Advanced the external extension compatibility line to `^0.4.0`. Third-party family, style, backend, scene-role, and font extensions that declare only `^0.3.0` must be reviewed against the 0.4 contracts before updating their range; a `0.x` caret range does not include the next minor.

## 0.3.2 — 2026-07-27

### Added
- Added MCP protocol revision `2025-11-25` — the *current* revision — to the hosted endpoint's supported list. It was previously rejected with HTTP 400, so any client pinning the current revision was locked out.
- Added dual-era support for the `2026-07-28` stateless revision alongside the existing handshake-based clients: `server/discover`, per-request `_meta`, the `-32020`/`-32022` error codes, HTTP 404 for unknown modern methods, and `Mcp-Method`/`Mcp-Name` header validation.
- Added `resultType: "complete"` and the required `ttlMs`/`cacheScope` caching hints to `server/discover` and `tools/list` results on the modern path. Legacy responses are unchanged, since an absent `resultType` is how a client identifies an older server.

### Changed
- The local MCP server now reports protocol versions **per transport**. Its stdio transport advertises every revision the dispatcher implements (through `2026-07-28`); its HTTP+SSE transport advertises only `2024-11-05`, which is the revision that transport actually is. A client declaring a revision a transport does not serve is now refused with `-32022` and the list to retry from, rather than being silently served a different era.
- Transport-level rejections from the hosted endpoint (bad origin, wrong method, wrong content-type, oversized body) no longer carry a JSON-RPC error envelope. All four refuse before a JSON-RPC request is parsed, so they answer `{"error": "<reason>"}` with the HTTP status — 403, 405, 415, 413 — as the signal. The `-32000` code they used to carry came from a range the spec says receivers "MUST NOT assume any specific meaning for", so it conveyed nothing.

### Fixed
- Fixed the modern MCP boundary end to end: hosted compute-cache entries are protocol-neutral and partitioned by era/revision, stateless metadata and known capability shapes fail with correlated HTTP 400 responses, every successful modern result carries the final server identity stamp, invalid-origin preflights fail closed, and stdio retains the revision selected by `initialize` for later requests.
- Hardened the release and review gates around that protocol work: the live deploy smoke test waits for the exact workflow SHA, golden approval is bound to each golden-changing commit, browser CORS coverage is portable and skips without starting servers when Chromium is absent, source scanning removes comments lexically, and equivalent named/record Style inputs are canonical before every family hook.
- Fixed the local MCP server downgrading clients that offer a newer protocol revision. `initialize` now echoes the newest revision the client and the transport share; the reference MCP SDK client offers `2025-11-25` and was being answered `2024-11-05`.
- Fixed the hosted endpoint rejecting conforming `2026-07-28` clients that omit `io.modelcontextprotocol/clientInfo`. The spec marks that field optional — clients "**SHOULD** include [it] … unless specifically configured not to do so" — and a client configured to withhold it received HTTP 400. It is still validated when present.

## 0.3.1 — 2026-07-27

### Added
- Added the framework-neutral `agentic-mermaid/browser/lazy` ESM entry with async, per-built-in-family SVG loading, shared on-demand ELK, exact all-family parity tests, and raw/gzip/Brotli/request-count build budgets.

### Changed
- Migrated the live `/demo/` page from the classic all-family bundle to the published lazy module graph. Its Timeline renderer path drops from 895,155 to 162,026 gzip bytes while retaining the classic compatibility artifact for synchronous script-tag consumers.

### Fixed
- Kept direct Flowchart/State compatibility-parser imports independent of complete family-registry initialization after the lazy-browser split. The registry and compatibility parser now share one lightweight header authority whose generated browser detectors remain self-contained, and a fresh-process regression prevents aggregate test import order from hiding an uninstalled resolver.
- Made the Firefox/WebKit compatibility-bundle smoke contract load the shipped artifact through a real loopback `<script src>` request. This exercises the documented consumer path and avoids hanging WebKit by transferring the multi-megabyte bundle through Playwright's script-injection control channel.
- Made parsed wrapper and family-body ownership disjoint and byte-exact, including empty, CRLF, and standalone-BOM wrappers, so replacing an extension descriptor cannot duplicate leading comments, frontmatter, init directives, or blank lines. Structured built-in and extension serializers now also retain universal init config authored after the family header, while the shared envelope reads serializer output through the same directive grammar and avoids duplicating config it already owns — including when a source-preserving serializer re-indents, re-spaces, or reorders object keys in the directive it preserved. Canonical serialization folds every parseable directive into the final effective config in authored order, so partial nested overrides and whole-object replacements cannot reinstate stale values or make output non-idempotent. Mutation refreshes wrapper metadata and spans from the rebuilt artifact while retaining prior dropped-comment loss receipts, whose `line` continues to index the artifact the loss happened in.
- Made MCP Registry publication retry-safe after an ambiguous publish result. The release workflow now checks the immutable exact-version endpoint, accepts an existing version only when its publisher-owned server metadata is structurally identical to the verified artifact and the Registry's mutable official status is `active`, and fails closed on mismatches, inactive records, and malformed responses. A Registry that is unreachable or answering unexpectedly is retried over a bounded backoff before failing closed, so a transient outage cannot block an otherwise-publishable release.

## 0.3.0 — 2026-07-25

### Added
- Added a published browser bundle: `dist/browser.global.js`, a self-contained IIFE exposing the render surface on the `agenticMermaid` global, reachable as the `./browser` export and from unpkg/jsDelivr. A `<script src>` consumer no longer has to invent a bundling step. 2.85 MB raw, 873 KB gzip; the ESM entry remains the supported path for anyone who already runs a bundler, since it tree-shakes and this file cannot.
- Added [`docs/browser.md`](docs/browser.md), covering build-time pre-rendering for static sites — the recommended path, which ships no JavaScript — alongside the script-tag path, and documenting the browser support floor (roughly Chrome 97, Firefox 104, Safari 15.4, Edge 97). That floor comes from runtime APIs, not syntax, so it cannot be lowered by changing the build target.
- Added a standalone `/demo/` page rendering a diagram live from one script tag, serving the same published artifact, with browser contracts asserting it renders on first paint.

### Changed
- Documented the `THEMES` removal in [`docs/fork-differences.md`](docs/fork-differences.md). Upstream Beautiful Mermaid exports a `THEMES` map and takes that theme object directly; this fork replaced it with the Style/Palette system and had recorded the removal only in this changelog. Ported upstream snippets failed at runtime with `TypeError: Cannot read properties of undefined` and nothing searchable explained it. The upstream theme names survive as style names: `THEMES['zinc-dark']` becomes `{ style: 'zinc-dark' }`.
- Re-recorded the website payload authority on the pinned CI toolchain (Bun 1.3.13). The previous record was measured on a different toolchain, so local runs reported failures that were compression drift rather than payload growth.

### Fixed
- Fixed built-in registrations pinning `core: '^0.2.0'`. For a `0.x` package a caret range is minor-bounded, so that pin meant `<0.3.0` and any minor release made every built-in family, style, backend, scene role, and font manifest entry incompatible — the registries never finished initializing and the failure surfaced as an unrelated `ReferenceError` across the suite. The pins now track the package version and a guard test fails first when they drift.

### Breaking
- Advanced the external extension compatibility line to `^0.3.0`. Third-party family, style, backend, scene-role, and font extensions that declare only `^0.2.0` must be reviewed against the 0.3 contracts before updating their range; a `0.x` caret range does not include the next minor.

## 0.2.0 — 2026-07-23

### Added
- Added deterministic website build-fingerprint, success-only cache, and initial request-graph authorities with exact raw, gzip, and Brotli budgets for the homepage, Examples, and blank Editor routes.
- Added a reproducible Linux-pinned Inter WOFF2 subset pipeline with content-addressed public assets while preserving full-TTF Editor and SVG-export authority.
- Added stable no-JavaScript Style × Palette and rich-corpus routes plus retryable, content-addressed deferred fragments that preserve Editor/render parity and all published Examples deep links.
- Added one canonical 2,800-case degenerate-route CI gate with hard hitch, edge-through-node, certificate-consistency, corpus-closure, and execution-error checks backed by focused sabotage.

### Changed
- Consolidated Mermaid-universal `accTitle`/`accDescr` parsing at source normalization. Every registered family, including future extensions, now receives directive-free grammar lines and the same accessibility metadata automatically; extension serializers also regain that envelope on output without family-specific code. Existing renderer, structured-agent, and source-action analysis paths use the shared grammar and source-line provenance rather than family-local scanners. Class, ER, and Timeline retain their explicit failure on unclosed description blocks.
- Made build ownership explicit: `typecheck` now runs only TypeScript, website-consuming tests opt into their fixture build, and the global website preload plus the `site`/`site:check` aliases were removed. The production editor build also drops author-only HTML and inline CSS comments and ratchets its measured raw, gzip, and Brotli ceilings downward.
- Consolidated repeated agent-body indexed-ID allocation and label-overflow collection behind shared utilities.
- Reduced the release workflow to exact-SHA CI attestation, cross-platform smoke, and the unique publish boundary. Unprivileged jobs now attest CI, build once, compare a real npm tarball against a reviewed fail-closed manifest, and transfer it under a fixed filename with bound SHA-256 and SHA-512 digests; minimal job-scoped OIDC jobs require the closed regular-file set before publishing that exact artifact to npm or extracting its matching MCP metadata, without checking out or executing repository code. Npm publication is retry-safe after ambiguous remote success: an existing immutable version advances the workflow only when its registry integrity is byte-identical to the verified tarball. The verified artifact is retained for the 30-day MCP retry window, release actions and npm are immutable, and npm's bundled Sigstore tree replaces the mutable `sigstore@latest` workaround.
- Updated the `fast-uri` transitive override to 3.1.4, the first release outside the host-confusion advisory range used by MCP schema validation and mutation tooling.
- Reduced the deterministic initial Examples route from 2,426,844 to 380,391 raw bytes, from 648,659 to 66,938 gzip bytes, and from 564,048 to 53,180 Brotli bytes while retaining every registered family proof in the initial document. Homepage and blank-Editor request graphs remain unchanged.

### Breaking
- Advanced the core extension compatibility line to `^0.2.0`; extensions declaring only `^0.1.1` are rejected explicitly and must be reviewed against the current contracts before updating their range.

## 0.1.2 — 2026-07-21

### Fixed
- Updated the transitive `brace-expansion` development dependency to 5.0.7 so the high-severity dependency audit remains enforced without blocking CI on GHSA-3jxr-9vmj-r5cp. The override stays within `minimatch`'s declared compatible range and is exercised by the retained Stryker mutation lane.
- Completed the 0.1.2 version projection across package, hosted MCP registry, generated agent guidance, and compatibility tests; host-version assertions now derive from the package authority instead of embedding the previous release.
- Made installed-resource verification portable to Windows by applying `/proc/self/fd` and `/dev/fd` canonicalization only on Linux and macOS; other platforms retain the rooted post-open file-identity proof instead of probing a nonexistent `/dev/fd` path.
- Made the editor/website generator's local file URL conversion portable to Windows by using `fileURLToPath` instead of passing `/D:/...` URL pathnames to `Bun.build`.

### Changed
- Simplified the published package to compiled ESM entries and removed the internal `./capabilities` and `./resources` subpaths. The supported library entries are `agentic-mermaid`, `agentic-mermaid/agent`, and the browser/workerd-safe `agentic-mermaid/agent/core`.
- Consolidated mutation testing behind `bun run mutation-test -- <profile>`, projected editor and comparison examples from the family descriptor registry, and made website/Worker generated assets clean-build outputs instead of tracked source. Older entries below retain the command spellings that shipped at the time; use `bun run mutation-test -- routes` or `bun run mutation-test -- gantt` now.

### Added
- Implemented Section A of the rendering-contract
  program: one immutable request and appearance waist, descriptor-owned
  family/style/render-option discovery, typed connector terminals and backend
  claims, explicit product/output parity, a version-pinned Mermaid compatibility
  manifest, and versioned extension and resource contracts.
- Completed the family-elevation program across all registered families: typed mutation operations, deterministic family layout rubrics/certificates, expanded semantic facts, exhaustive configuration wire-or-warn coverage, parser/serializer conformance, and a zero-exception citizenship matrix.
- Added Flowchart v11 shape metadata and edge IDs; State notes/pseudostates/history/concurrency/paint; Sequence box/autonumber/create/destroy/standalone activation behavior; Class namespaces/generics/paint/cardinality allocation; ER bare entities/paint/ordered segments; vertical Timeline layout; Gantt dependency/critical-path overlays; XYChart legends and explicit orientation mutation; Pie wedge labels/donut/legend controls; Quadrant accessibility/style functions; deterministic side-constrained Architecture routing and offline icons; and first-class Mindmap and GitGraph families.
- Added measured bold/italic Flowchart markdown rendering and support for a bare `flowchart` header, which defaults to top-down layout while remaining source-preserved at the typed-edit boundary.
- Added a mechanically checked family-elevation ledger: all 72 original items and 18 completion packages have stable IDs, constrained statuses, ordinal work-plan correspondence, and named evidence. B01–B18 are done; final-head CI and post-fix review evidence is retained in the stable PR audit record.
- Completed the Phase 0 honesty contract with generated serializer→agent/renderer-parser properties for every family, registry-complete lossless opaque diagnostics, and a typed `StateRuntimeConfig` that wires ten faithful fields while warning on legacy, invalid, unknown, or unavailable-renderer requests.
- Added hard terminal-cell `targetWidth` rendering across library, CLI (`--target-width`), Code Mode, and hosted `render_ascii`, with typed `AsciiWidthError` diagnostics when geometry cannot fit.
- Published one all-family SVG contract: deterministic `data-id`/`data-role`, normalized relation endpoints and ARIA semantics, complete local-reference namespacing, and typed Scene identity/accessibility records.
- Added full Mindmap and GitGraph citizenship across library, CLI, Code Mode, local/hosted MCP, editor, website, docs, eval, packaging, and terminal rendering. Compatibility is pinned to Mermaid commit `f3dea58385fd5c7dd1f4e9c9c1876751ae6943cc`; all 26 Mindmap and 69 GitGraph official spec blocks are now imported, excluded, or explicitly classified in an executable revision/hash-bound oracle; generated GitGraph ids are deterministic `c<N>` values.
- Added first-class Mermaid `radar-beta` charts across SVG/PNG/ASCII/Unicode, typed mutation, Code Mode/MCP, config diagnostics, styles, docs, website samples, and executable upstream provenance. Radar supports positional/keyed curves, circle/polygon graticules, accessibility metadata, same-line whitespace statements, palette-aware areas, deterministic semantic identities, and bounded geometry configuration.
- Added focused Mindmap/GitGraph mutation lanes and exhaustive operation contracts. The latest 2026-07-10 local runs killed 400/405 Mindmap mutants (98.77%) and 294/303 GitGraph mutants (97.03%); the lanes are opt-in diagnostics without break floors or acceptance authority.
- Added official Mermaid 11.16.0 comparison fixtures and reproducible SVG/terminal contact sheets for Mindmap and GitGraph. The evidence records AlexanderGrooff/mermaid-ascii 1.4.0's exact unsupported-family result instead of fabricating equivalent output.
- Added exact executable-title evidence for every done family-elevation ledger row; CI now rejects uncited files, missing titles, duplicate IDs, empty evidence, and newly-done rows without a matching evidence entry.
- Added a pinned official Mermaid 11.16 documentation showcase for all registered families and a registry-derived exhaustive non-default Look × Palette × family compatibility gate.
- Completed the mandatory Section B public styling surface: descriptor-derived exact role records, named semantic slots, executable V1 `category` bindings, visible non-color cues, and inspect-only contrast/accent-area/mono-role constraints across SVG, PNG, and declared lossy terminal projections. Authored Mermaid paint and family semantics remain authoritative, and evidence-gated B4 BrandPack packaging remains unpromoted.
- Added `renderMermaidWithActions()` with one inert, versioned action/region sidecar across SVG, PNG, ASCII, and Unicode; exact authored source spans; family-semantic rendered regions; and expanded deterministic spacing, density, overlap, and resolved-contrast metrics across all registered families.
- Promoted the Cupertino-, Vercel-, and Cloudflare Workers-inspired research fixtures to the highest non-built-in evidence form: schema-validated public `StyleSpec` prototypes with executable family-specific fixtures, deterministic screenshots, role styles, inspect-only constraints, and semantic bindings/cues where the family exposes them. They remain documentation-only, unendorsed, and absent from built-in discovery.

### Changed
- Canonical serialization, terminal metadata, extension discovery, capability reports, quality tie-breaking, and evaluation artifacts now use locale-independent Unicode code-point ordering instead of ambient host collation.
- Semantic binding admission now derives its explicit role union from roles with executable category consumers. Permanently inert targets such as `role: "node"` are rejected consistently by TypeScript, runtime validation, JSON Schema, generated SDK declarations, and final stack resolution.
- Exact role properties, binding-family enrollment, public role types, runtime descriptors, schema, and docs now project from one role-style contract. Brand-constraint payloads likewise project from one descriptor record into TypeScript, runtime admission, JSON Schema, diagnostics, and an exhaustive evaluator map.
- Terminal flowchart/state RL output now reverses the logical grid before text drawing instead of aliasing LR, and feedback edges can no longer enter primary fan-in/fan-out bundles and overwrite node labels in a three-node 2-cycle.
- Every continuous painted text advance—including bundled, monospace, and custom faces—now receives a deterministic SVG `textLength`/`spacingAndGlyphs` projection matching the width reserved by layout across SVG and native/browser PNG. Independently positioned multiline tspans are fitted per line, nested formatting contributes inherited metrics, and explicit emitter-owned `textLength` remains authoritative.
- Section B causal evidence now pins and executes the pre-feature commit instead of following moving `origin/main`; its receipt also hashes default, rough, and hybrid SVG+PNG sentinel probes across every registered family and links the separately approved brand-inspired prototypes.
- Retired and deleted the broad scheduled mutation matrix and its sharding/oracle machinery after 26 consecutive failed or cancelled runs. The bounded incremental counter gate and five behavior-specific sabotage probes remain automatic; family lanes are opt-in diagnostics without acceptance floors.
- Removed the accidental `cupertino` built-in registration and its private-face evidence path. Cupertino now exists only as an explicitly loaded, documentation-only public `StyleSpec` prototype; no compatibility alias is retained.
- CLI, Code Mode, local/hosted MCP, editor, website, SVG, PNG, ASCII, and
  Unicode now project shared options and capabilities from canonical
  descriptors. Historical execution plans moved to the archive, copied family
  and style menus were removed, and Section B branding work has one live owner.
- Connector terminal evidence now preserves exact endpoints, routed contours,
  hit geometry, stroke fields, label visuals, marker descriptors, and every
  per-subpath marker placement behind an executable per-feature manifest.
- Local MCP `render_png` now advertises managed-file side effects accurately, accepts `fontDirs`/`loadSystemFonts`, and returns deterministic configuration and font-coverage warnings in every output mode.
- Agent evaluations, shipped-artifact fuzzing, website comparisons, fork documentation, and browser counts now cover every registered family; deployment catalogs carry the exact Git SHA and build time.
- Configuration diagnostics now use fully qualified family paths consistently across source wrappers and explicit `mermaidConfig`; duplicate warnings are deterministically ordered and deduplicated.
- Gantt calendar spans use the documented `(start, end]` exclusion boundary model and excluded-day shading is enabled by default; today markers remain caller-clocked.
- Known command-inapplicable CLI flags and value-taking flags without values now exit 2 instead of being accepted as silent no-ops.
- PNG coverage warnings now flow through local and hosted MCP renders; system-font mode reports qualified bundled-font uncertainty rather than suppressing it.
- State `nodeSpacing`, `rankSpacing`, node padding/radius/font size, composite-title size, fork dimensions, note margin, and divider margin now affect rendering. Legacy or invalid `state.*` values and unsupported renderer selections emit qualified `INEFFECTIVE_CONFIG` diagnostics through source verification, library/Code Mode callbacks, CLI SVG/PNG envelopes, and hosted SVG/ASCII/PNG tools.
- Built-in concrete palettes now normalize normal text to WCAG AA (4.5:1) and meaningful relation lines/markers to 3:1; already-compliant colors and unresolved CSS-variable palettes remain unchanged.
- Mindmap now accepts official multiline Markdown Strings, renders bold/italic spans, recognizes `layout: tidy-tree`, and fails closed on malformed reserved decorations, accessibility directives, and shape delimiters. Its bilateral layout now sizes depth columns per side and colors first-level subtrees accessibly. GitGraph now renders frontmatter titles, stabilizes equal-order lanes by source order, validates cherry-picks against full ancestry, and packs 45° commit labels/tags from measured bounds with contrast-preserving backplates and stronger branch rails.
- Editor supported-family diagnostics, characterization enrollment, and architecture documentation now derive from or are checked exactly against the runtime family registry.
- Architecture edges now use deterministic side-constrained placement and orthogonal visibility-grid routing with explicit placement/facing/obstacle certificates. State, Class, ER, and Architecture terminal output is spatial and display-cell aware; Class compact namespaces and ER ordered typed/opaque segments remain editable without stale identity references.
- **Output compatibility note:** semantic SVG identity/ARIA attributes, palette contrast normalization, corrected marker/routing geometry, and spatial terminal rendering intentionally change SVG/PNG/ASCII bytes and regenerated characterization hashes. Consumers that snapshot output bytes should review and re-pin; source parsing and deterministic repeatability remain stable.

### Removed
- Removed five stale, unreferenced website SVG snapshots and one obsolete terminal snapshot that were copied into the public deployment despite no page consuming them. The authored `.mmd` sources remain, `workflow-themeable.svg` remains generated from the current renderer, and a build contract now rejects checked-in renderer snapshots in `website/source/diagrams`.

### Fixed
- Prevented ASCII/Unicode action and label regions from absorbing matching text from neighboring nodes or edge labels, and from binding punctuation-only labels to box borders; multiline hit bounds now compare and claim display cells rather than UTF-16 offsets.
- Preserved the exact Style, Palette, seed, and render configuration when opening every Examples, homepage, comparison, and warning reproducer in the Editor. Examples and the Editor now share one render-state resolver, and browser coverage checks every distinct handoff shape for complete SVG and appearance parity.
- Restored public editor deep links after legacy hash decoding was removed. Website and checked-in links now share one bounded canonical deflate codec and current `palette` schema, with repository, generated-site, and real-browser navigation gates to catch producer/consumer drift before deployment.
- Prevented the editor’s Style and Palette dropdowns from flashing during startup. Idempotent initialization closes no longer trigger the visible closing animation; real open-to-closed transitions retain it.
- Corrected Class composition, aggregation, and lollipop marker anchors at both relationship ends in every layout direction. Diamond bodies now remain outside class surfaces and lollipops meet the boundary at their tangent in crisp and styled output.
- Closed editor share/draft insertion, decompression, and share-hash DOM XSS risks; hardened imported render configuration and StyleSpec prototype/font/CSS boundaries; externalized executable scripts; and removed `unsafe-inline` from the production CSP. Editor and hosted SVG rendering now force strict security and reject active content or external references.
- Closed unknown-family Flowchart fallthrough, connector-marker fidelity loss, and verified-resource time-of-check/time-of-use gaps. PNG/resource receipts now state whether bytes were verified, caller-supplied, system-provided, embedded, or unavailable.
- Closed connector topology now has one path-only invariant across SVG,
  sketch, bounds, hit testing, endpoint anchors, and terminal evidence. Marker
  bounds honor SVG's default `markerUnits="strokeWidth"`, use typed marker
  viewports for path geometry, and no longer diverge in rough/hybrid output.
- Enforced JSON-RPC 2.0 envelopes and notification suppression across local and hosted MCP transports. Local bearer/Origin checks now cover SSE, messages, and artifacts, and SSE sessions have a fixed upper bound.
- Rejected source-controlled Pie colors that could escape SVG attributes or styles; hardened cross-format color contrast and XML sinks.
- Fixed successful-but-lossy Journey/State/Sequence/Class/ER/Architecture/Timeline/XYChart mutations and parser round trips, including accessibility metadata, history endpoints, boxed participants, labeled and generic classes, bare/aliased ER entities, post-alignment route anchors, event text containing clock-time colons, event-less Timeline periods, and explicit vertical orientation.
- Typed paint and Mindmap decoration/metadata edits now reject line/comment delimiters that would serialize into new semantic statements; empty Mindmap icon decorations are rejected instead of being accepted and dropped; successful edits are grammar-closed and round-trip stable. The pinned GitGraph oracle also AST-expands constant-loop variants, and SVG identity tests compare exact node, group, and relation tuples rather than counts/endpoints alone.
- Fixed quoted Flowchart shape labels containing their own delimiters, Unicode/CJK Flowchart identifiers, corrupt State/Class `:::class` text, ER `:::class` phantom identities, and comma-separated ER composite keys; ER display aliases now have typed `set_entity_label` mutation.
- Fixed dense self-loop route/label collisions and reserved rank clearance so loop pills cannot cover adjacent nodes or primary-chain arrowheads; also fixed grapheme-splitting label wraps, terminal formatting leakage, ER relationship glyph fidelity, and State pseudostate visuals.
- Finished grapheme/display-cell writes and measurements in Class, ER, Sequence blocks, Flowchart subgraphs, Pie, Quadrant, XYChart, validation, and TUI metadata; ER attribute comments are visible in terminal output.
- Replaced Flowchart start-arrow reliance on `auto-start-reverse` with explicit pre-rotated geometry and balanced start/end cross-marker reference points, verified at raster pixels.
- Fixed blank ER diagrams becoming opaque after ordered-segment promotion, preserving header-only ER as a structured typed-authoring canvas while keeping opaque-only tolerated subgraphs lossless.
- Fixed label-less ER relations being silently dropped, XYChart `backgroundColor` being lost during PNG rasterization, and long Quadrant axis labels overprinting beyond their half-plot budgets.
- Replaced delimiter-concatenated Mindmap/GitGraph Scene IDs with injective semantic identities, rejected already-reachable GitGraph cherry-picks, and aligned equal-order branch lanes across SVG and terminal renderers.
- Closed the Radar audit gaps in public synthesis validation, upstream title/comment/options grammar, Style-face-aware measurement, independent frame dimensions, theme paint/typography propagation, styled-backend opacity, empty-curve ASCII output, tick geometry, and duplicate-ID stability.

### Breaking
- Removed the deprecated compatibility layer across library, agent, CLI, MCP,
  editor, Style, Scene, and SVG surfaces. Library callers must use
  `renderMermaidSVG` / `renderMermaidSVGAsync`, `renderMermaidASCII`, and
  `parseRegisteredMermaid`; `AsciiWidthError.requestedWidth` replaces
  `targetWidth`. The browser PNG raster callback no longer receives `scale`.
  Agent callers must use `FlowchartMutationOp`, required Sequence statements,
  and canonical message endpoint data instead of the removed mutation/type
  aliases and projections.
- CLI and MCP inputs now accept canonical spellings and nesting only: use
  `am render --format ascii`, batch `format: "ascii"`, layout
  `--format layout`, and `agentic-mermaid-mcp --transport http`. MCP render
  appearance belongs under canonical nested options; hosted SVG uses
  `palette`, not `theme`. Removed and unknown MCP flags now fail closed instead
  of silently starting stdio.
- Style discovery no longer exposes `THEMES`, compatibility-alias registration,
  `default`, bare `tufte`, or dormant Style aliases. Use `crisp` and the
  canonical-only `look:tufte`. Editor share links are deflate-only, accept
  `palette` only, and drafts persist in `sessionStorage` for the current tab;
  old plain-base64 links and persistent draft controls are not migrated.
- Scene contract v2 removes public crisp/raw/prelude serialization carriers and
  duplicate connector geometry/paint/marker fields. Connector marks and private
  serialization sidecars are the sole authorities. External Scene families and
  backends must declare `identity.compatibility.scene: "^2.0.0"`; v1 ranges are
  rejected before callbacks run. The render receipt, Scene validation, family
  descriptor, family conformance, and backend conformance generations were
  advanced with the incompatible schemas.
- Default SVG rendering no longer embeds font imports, an explicit empty
  `idPrefix` is invalid, registered ASCII routing requires `routeClass`, opaque
  State bodies use the canonical layout result, and unknown render failures use
  one generic diagnostic instead of transport-specific fallbacks. Consumers
  relying on historical SVG byte order, legacy ARIA/data-entity projections, or
  built-in Scene object identity must migrate to the typed canonical contracts.
- The duplicate light Tufte palette (`palette:tufte` and legacy theme `tufte`) and the ambiguous bare `tufte` Style input are removed and now fail as unknown. Use the sole light Tufte resource, `look:tufte`; the distinct `tufte-dark` palette is unchanged.
- Consumers matching `INEFFECTIVE_CONFIG.field` for family-section keys must use the qualified path (for example `journey.boxMargin` rather than `boxMargin`).
- Gantt exclusion-boundary semantics and default shading may change existing rendered calendars; CLI scripts relying on ignored known flags now fail fast with exit 2.
- The transitional `FamilyPlugin` type alias has been removed; extension hosts should import `FamilyDescriptor`, which is the canonical registration and discovery contract.
- Extension registration is now collision-safe and versioned. External families
  use `family:*` identities and complete descriptors; external Scene backends
  use `backend:*` identities, declare feature/operation capability evidence,
  and pass executable conformance at registration instead of silently replacing
  a prior implementation.
- Declarative `StyleSpec.backend` has been removed. Style data now selects only safe appearance; trusted hosts that install executable Scene backends select them through `createMermaidRenderer`, `createMermaidPNGRenderer`, or `createMermaidBrowserPNGRenderer` with a host-only `backendPolicy`.
- External Scene v1 path connectors now accept only one linear `M`/`L`/`Z`
  contour whose vertices exactly match typed points; use polyline or await a
  future curve-flattening contract instead of supplying divergent SVG and hit
  geometry. The serializer-only `MarkerSerializationOptions.markerUnits`
  override was removed; set units on the marker descriptor, the sole authority.

## 0.1.1 — 2026-07-10

### Added
- **Standards-based agent discovery and MCP Registry publishing.** Agent guidance now states when to use Agentic Mermaid and when to keep diagrams local. The website publishes `/index.md`, negotiates it from `/` with `Vary: Accept`, and advertises machine-readable resources with RFC 8288 links. The npm package ships official `server.json` metadata, exposes the registry launch path as `npx -y agentic-mermaid mcp`, and publishes each new release to the MCP Registry after npm succeeds.

## 0.1.0 — 2026-07-09

### Added
- **Journey and output-family foundation.** Journey gained deterministic geometry/paint and accessibility-aware rendering; ASCII/Unicode output became a first-class cross-family surface; PNG switched to bundled Inter metrics with DejaVu per-glyph fallback and introduced the public warning vocabulary used by verification/render tooling.
- **Validated declarative edit boundary + `mutate`/`build` hosted MCP tools.** The untyped MCP/CLI JSON boundary now shape-validates every op before the mutator (field presence, primitive type, enum membership across all 12 families), so a malformed op — e.g. `add_class {name:'Duck'}` where `id` is expected — returns a prescriptive `INVALID_OP` naming the offending field and listing the valid ones, instead of silently producing `class undefined`. One choke point (`mutateChecked`) backs every untyped path: the new hosted `mutate` (edit a `source`) and `build` (author from a `family`) tools, the Code Mode facade, and the CLI `--op`/`--ops`. All return one canonical envelope `{ ok, family, source, verify }`. Code Mode `execute` now also marshals a returned diagram (or `Result` wrapping one) to that same envelope rather than failing "non-serializable"; other unserializable returns get a prescriptive plain-data hint.
- **Blank-slate authoring on the typed path: `createMermaid(kind)` / `buildMermaid(kind, ops)`** (from direct agent feedback). `createMermaid` returns an empty structured `ValidDiagram` for any built-in family (overloads narrow the return per kind; `direction` option for flowchart/state); `buildMermaid` folds a typed mutation list over that empty diagram, with errors carrying the failing op's `opIndex`. Exposed in the library (`agentic-mermaid/agent`), the Code Mode `mermaid.*` SDK (results are trusted inputs to `mutate`/`verify`/`serialize`), and the SDK declaration. Creating a new diagram no longer requires hand-writing Mermaid source. To let empty diagrams be built up op by op, the journey/xychart "structured floor" now refuses only mutations that would *empty a non-empty* body, and the ER serializer emits label-less relations as `: ""` so they re-parse structured instead of falling back to opaque.
- **Repo-wide fast-check seed policy**: every property suite now runs at one pinned global seed via a `bun test` preload (`src/__tests__/fc-seed.preload.ts`; `AM_FC_SEED=<int>` reproduces a specific roll, `AM_FC_SEED=random` restores finder-mode randomness). Suite-scoped seed overrides save/restore the global config instead of resetting it, and two meta-gates keep the policy from silently un-landing (a preload-wiring test plus an end-of-alphabet epilogue). Landed after a 1,368-run sweep (48/24/12 seeds per suite, scaled by runtime) found zero latent seed-dependent failures. Completes the determinism policy from the 2026-07 audit, which had been applied incident-by-incident to three suites (see `docs/testing-strategy.md` §4).
- **Label-collision detection and gating (`eval/overlap-audit/`)**: an SVG-level overlap auditor (text boxes measured with the renderer's own text metrics, ownership from SVG group metadata or containment, rotation-aware, off-canvas detection) with a curated-corpus gate, deterministic 12-family fuzz generators, and a CI gate (`label-overlap-gate.test.ts`) holding the corpus at zero findings with per-family fuzz ratchets. Labels were previously unmeasured in every family.
- **Certificate completeness is now a deterministic gate**: `certificate-completeness.test.ts` pins that every edge leaves the pipeline certified (tracked corpus + shrunk repros + fixed-seed duplicate-edge sweep), and the route-contracts property suite runs at a pinned fast-check seed instead of flaking ~1 CI run in 7.
- **Scoped mutation lane for the link-rank packing repair** (`stryker.linkrank.config.json`), harvested from 49.86% to 65.07% via geometry-characterization snapshots; residual classified in `docs/mutation-testing.md`.
- **Hosted MCP on Cloudflare** (`https://agentic-mermaid.dev/mcp`): the website Worker now serves a stateless Streamable HTTP MCP endpoint (JSON-RPC over POST, no sessions/SSE) with six tools — `execute`, `render_svg`, `render_ascii`, `render_png`, `verify`, `describe`. Code Mode `execute` runs agent JavaScript in content-addressed Dynamic Worker isolates (Worker Loader binding; `globalOutbound: null`, empty env, `cpuMs` budget, `subRequests: 0`) against the same hardened `mermaid.*` facade as the local vm sandbox — semantics pinned by a differential test suite (`hosted-execute-differential.test.ts`), with two documented divergences (CPU-time vs wall-clock budgets; strict-module vs sloppy-vm implicit globals). Hosted `render_png` uses `@resvg/resvg-wasm` (pinned to the napi version) with the bundled DejaVu fonts and is documented as outside the byte-determinism contract. Eligible deterministic pure-tool results may be reused through a private Workers Cache API compute cache; JSON-RPC responses remain `cache-control: no-store`, and non-idempotent `execute` bypasses the cache. Request bodies cap at 128KB and tool inputs at 64KB, and sync-only violations are rejected before any isolate spins. Transport guards: reflective CORS with Origin validation, `MCP-Protocol-Version` validation, and a batch fan-out cap. The `mermaid.*` Code Mode facade moved to runtime-neutral modules (`src/mcp/facade.ts`, `src/mcp/harness-runtime.ts`; `src/agent/core.ts` is the pure barrel without the napi PNG dependency) shared by the vm sandbox, the isolate harness, and the hosted server core (`src/mcp/hosted-server.ts`). The local stdio/HTTP MCP server is unchanged. Also fixes ELK instantiation under Cloudflare workerd (`src/elk-instance.ts` now flips elk-worker's environment sniff by temporarily defining `document` instead of deleting the undeletable `self`).
- **Layout-certificate closure for #26/#38**: `layoutMermaid(d, { debug: true })` and `am render --format json --certificates` now expose opt-in graph route certificates plus accepted family certificates for class/ER (`orthogonal-box`), architecture (`side-anchored`), sequence (`lifeline-message`/`self-message` with real self-loop geometry), and timeline/xychart/pie/quadrant/Gantt containment layouts. Default layout JSON remains certificate-free. Route certificates now include exact ports plus additive side/slot/role assignments, and ELK `FIXED_SIDE` hints are fed only for safe primary-forward edges whose endpoints are not incident to non-primary routes or direction-override subgraphs.
- **Agent analysis and region/action sidecars**: `analyzeMermaid` / `analyzeMermaidSource` expose deterministic feedback-edge facts, source-only action records (unsafe `javascript:`/`data:`/`vbscript:` links marked unsafe, never executed), and Gantt critical-path/slack summaries. Debug layout JSON can include V1 `regions` and source-only `actions` sidecars for UI/tooling alignment; label regions now bound the label around its center rather than treating the center as a top-left corner.
- **Port ranking** (issue #26 WS3, completing the yFiles cost model): a shape side carrying exactly one line uses its canonical port — for diamonds, the exact vertex; when no straight vertex lane exists, a single proof-gated Z from the vertex into the target's port outranks a straight lane floating on the facet (lines emit from points, upgraded back to straight by the fixed-point loop when obstacles move). Sides carrying several lines spread along the facet/flat region; fan-ins still merge at the target port; sharper shapes win conflicts and the source wins ties. Verified across all four directions, bi-directional pairs, and diamond-to-diamond chains by tests and the rubric battery. An unlabeled reciprocal pair (A→B with B→A) renders as **two equal parallel lines** straddling the shared centerline at `center ± 6` (primary low, feedback high) — equal deviation gives equal lengths on diamond facets, the way dot offsets reciprocal splines symmetrically about the spine; both pair members enroll in the fixed-point repair pool even when already straight, and any straightening that won on a non-preferred lane (an *upgradeable* success) is re-proved each round so the symmetric lane wins once the partner's geometry settles. Port-only shapes (circles) keep both lines on the exact port. A blocked vertex emit now prefers a **1-bend hook** into the target's *facing* cross-side port (the box's top/bottom in horizontal flow — the IBM flowcharting-manual entry) over the 2-bend Z into the flow-side port; an available fan-in merge at the flow-side port (shared arrowhead) outranks the hook, and a stub shorter than 8px keeps the Z. **Port-lane alignment** (`alignPortLanes`): a "straight but off both midpoints" edge — floating through the sliver where two side-spans overlap because ELK's balanced placement aligned the node with neither neighbor — is now fixed at the placement stage: one endpoint node slides along the cross axis so the two midpoint ports share a lane (port-aware coordinate assignment, Rüegg et al. GD'15), making the edge straight AND port-exact with no routing trade. Slides are proof-gated (shared lane clear of intermediate nodes; sibling edges bent with a perpendicular segment to absorb the shift, labels following translated runs; no node/corridor/label-pill collisions; no group members; aligned endpoints frozen against later re-breaking). The pass covers the whole PORT_EXACT shape catalog — circles, stadiums, hexagons, cylinders, pseudostates, and diamonds slide too (for port-only shapes this converts a forced 2-bend Z into a port-to-port straight; a source diamond with a fan-out never aligns, its vertex has capacity 1; stretched perpendicular segments are proved node-free across their swept corridor) — and an explained detour whose entry lands off-port now seeks a port-exact Z, so the edge left behind by an alignment still converges at the shared entry port. Docs-corpus effect: straight edges 97→101, multi-bend routes 7→5, port-exact endpoints 76.0%→78.2%. **Active fan-in centering**: an unlabeled equal-rank peer fan-in (≥2 distinct unlabeled forward sources stacked in one layer) now snaps the hub to the exact cross-axis barycenter of its sources — correcting ELK's ~20px Brandes–Köpf placement drift — so the incoming edges converge **mirror-symmetric** at the hub's single exact port instead of the old one-straight/one-Z asymmetry. Proof-gated (no node/corridor/label-pill collision; hub not in a group, not also emitting a forward edge; ELK-gridded large fan-ins correctly out of scope). Exact symmetry (0.00px barycenter error, ≤1.5px clipping floor on curved shapes) with zero hard-metric regressions; the trade is +2 bends per fan-in. The L–V contact-sheet scenarios now demonstrate the symmetric merge across every shape. **Diamond facet-mid ports (the 8-port model)**: diamonds gain four extra designated ports at their facet midpoints (NE/SE/SW/NW, all on the outline; `diamondFacetPorts`, recognized by `portAt`, certificates widen to `AnyPort`). Three uses: a diamond fan-out of two forward edges attaches them at the NE/SE facet-mids and slides the targets onto those lanes for **port-to-port straight** edges (E; the vertical case F correctly bails when the targets are too wide to align); a diamond↔diamond reciprocal pair attaches at the nearest facing facet-mids — two parallel lines *between* the diamonds, never through them (G); and a side input below a diamond whose facing port is claimed enters the **S vertex** instead of floating on the facet (K). `shapePorts` stays four-cardinal for every shape and `portAt` is byte-identical for non-diamonds, so this is strictly additive. Heuristic tracker (`bun run track`): 6 improvements, 0 regressions, 0 hard violations across 51 examples. The canonical scenarios are pinned as a **contact sheet** (`bun run contact:sheet` renders lettered scenarios A–S from `eval/visual-rubric/scenarios.ts`; `contact-sheet.test.ts` snapshot-pins each scenario's geometry and asserts zero hard rubric metrics, making the sheet a CI visual-regression gate, now A–V). **Parallelogram shapes** `[/text/]` and `[\text\]` (Mermaid lean_right/lean_left — the ISO 5807 input/output symbol) now parse, render, serialize, and round-trip correctly (previously misparsed as trapezoid/rectangle), and the whole slanted family — parallelograms, trapezoids, the asymmetric flag — joined the PORT_EXACT catalog: exact ports at the true side midpoints (slant midpoints / flag point), flat-side attachment spans, convex-polygon clipping, exact rubric outline oracles, randomized property coverage, and contact-sheet scenarios T–V. `verifyMermaid` gains the Tier-3 `DECISION_BRANCH_UNLABELED` lint (ISO 5807 10.3.1.2 / ANSI X3.5 4.10.2: every exit of a multi-exit decision shall be labeled with its condition value).
- **Deterministic layout-quality rubric + visual testing harness** (`docs/design/system/layout-rubric.md`): `src/layout-rubric.ts` computes the literature's validated graph-drawing aesthetics from final geometry — seven HARD metrics that must always be zero (endpoints on the rendered shape outline via per-shape closed-form oracles, no diagonal segments, no unexplained bends, no hitches, no node overlaps, labels on their own route, no edge-through-node occlusion deeper than stroke width) plus reported soft metrics (crossings, bends, port-endpoint rates) — citing Purchase 1997/2002, Ware et al. 2002, Kakoulis–Tollis, and the Tamassia orthogonal tradition. `bun run rubric:visual` renders a ~120-fixture simple battery (every routing pattern × direction × shape) and a complicated set into HTML galleries with per-diagram scores and exits nonzero on violations; the same gates run in CI (`layout-rubric.test.ts`) together with fast-check property oracles that mathematically check ports, outlines, and hitches over randomized diagrams. The competitive analysis found no tool in this space gates layout quality with computable metrics (Graphviz: textual regression; Mermaid: pixel-diff; D2: goldens accepted by eye). The property oracles immediately found and forced fixes for: missing shape clipping beyond diamonds (circle/stadium/hexagon/cylinder outlines), the layer-alignment pass snapping nodes onto routed corridors (now occlusion-safe), duplicate edges collapsing onto one path, ELK's degenerate zero-net spike points, a rare 45° feedback-port join (now orthogonalized), flat-side attachment for hexagon/stadium/cylinder (yFiles overflow-candidate pattern), and two ELK internal-crash triggers (now a graceful option-degradation ladder).
- **Route contracts: principled routing without hitches** (issue #25, `docs/design/system/route-contracts.md`): the flowchart/state layout pipeline now classifies every edge by semantic role (`primary-forward`, `feedback`, `self-loop`, `container`, `cross-hierarchy`), removes duplicate/collinear route points, and collapses a primary-forward dogleg to a straight lane only when a direct-lane proof shows nothing (node, edge label, parallel-channel overlap, attachment-span limit) blocks it — diamonds re-anchor by ray-polygon intersection, labels move onto the straightened segment and count as obstacles for other lanes. Every edge carries a `RouteCertificate` (`edge.routeCertificate` on the positioned graph) recording its class, bend count, and either the straight-lane proof or the concrete blockers (`explained-detour`). Feedback edges route **around the nodes through outer channels** (`elk.layered.feedbackEdges`, the option issue #25 §10 specified) — so the forward lane of a reciprocal pair is straight directly out of ELK and a labeled retry edge renders as the classic loop with its label ON the loop (reserved space, dot's virtual-node doctrine; the earlier offset-pill placement violated the label-to-edge unambiguity criterion and is gone). The pass tightens ELK's loops (exit via the decision diamond's channel-facing facet near the vertex — its "bottom port" — instead of wrapping around the forward side), collapses *unlabeled* feedback onto a parallel straight back-arrow when provably clear, and enforces that no repair ever increases edge crossings. Diamond lanes may now attach anywhere on a facet outside a 10px vertex margin. Blocked feedback stays a `feedback-detour` with named blockers. **Semantic ports** (issue #26 WS3): every shape exposes four canonical connection points at its bbox side midpoints (`shapePorts()` — diamond vertices, rectangle side midpoints, circle/stadium/hexagon/cylinder boundary extremes are the same four points); straightening prefers port lanes (static glue) before floating attachment (dynamic glue), loops exit the diamond's exact S/N vertex and enter the target's exact side midpoint, same-target edges may merge at the shared port, port-only shapes (circles, stadiums, hexagons, cylinders, state pseudostates) join the straightenable set, and certificates record `sourcePort`/`targetPort`. Container edges run border to border: a SEPARATE-hierarchy bug that left a container-to-container edge floating in the diagram margin (caught by the new tripwire on the docs corpus) is repaired by the same proof-carrying straightener with the container rect standing in as a rectangle. The fan-out/fan-in bundler gained the first slice of the bundle contract: rebuilt trunk paths are proved clear of every non-endpoint node, and a blocked member falls out of the bundle instead of routing through a box. The MFA/login regression now renders every clear-lane edge straight in SVG/PNG; corpus comparison: 0 regressions. `verifyMermaid` gains all six Tier 2 advisory route-contract tripwires (`ROUTE_HITCH`, `ROUTE_UNEXPLAINED_BEND`, `ROUTE_LABEL_ON_SHARED_TRUNK`, `ROUTE_CONTAINER_MISANCHOR`, `ROUTE_SHAPE_MISANCHOR`, `ROUTE_STALE_AFTER_NODE_MOVE`) — zero-noise checks that fire only if a pass mutates geometry after route certification. `layoutMermaid(d, { debug: true })` attaches each edge's `RouteCertificate` to the layout JSON. ASCII placement gained longest-path layering (a fan-in target sits after its deepest parent, so skip-edge joins never make a later parent's edge run backward) and labels prefer the widest fitting segment over the crowded final approach. Scoped mutation lane: `bun run mutation-test:routes`.
- **Source-wrapper fidelity (1C) + announced comment policy (2C)**: the leading source wrapper — YAML frontmatter, `%%{init}%%`/`%%{initialize}%%` directives, `%%` comments before the header — now round-trips **byte-verbatim** through `parseMermaid → serializeMermaid` and through every mutation (`meta.wrapperSource`). Previously, `config:`-nested frontmatter was flattened to top-level keys Mermaid cannot read back (silently killing the author's `config.layout`/`config.look` intent on interop), init directives were duplicated into a synthesized frontmatter block, and leading comments were dropped. Canonical wrapper synthesis is now opt-in (`serializeMermaid(d, { wrapper: 'canonical' })`, `am format --canonical-wrapper`) and emits Mermaid's documented shape: `title`/`displayMode` top-level, everything else nested under `config:`, directives folded when their payload is represented (preserved raw when unparseable). In-body `%%` comments are still canonicalized away by structured bodies, but the loss is now *announced*: parse diffs the comments against the serialized output (`meta.droppedComments`) and verify emits the new Tier 3 `COMMENT_DROPPED` lint (count + lines) — never silent. Wrapper comments and comments in opaque bodies/segments are preserved and never warn. See the wrapper law and 2C comment policy in `docs/contributing/adding-diagram-types.md`.
- **Upstream Gantt test-suite bench + UNRESOLVABLE_SCHEDULE** (`eval/mermaid-gantt-bench/`, follow-up to the Gantt family below): the gantt tests from `mermaid-js/mermaid` (`gantt.spec.js`, `ganttDb.spec.ts`), `pgavlin/mermaid-ascii`, and `kais-radwan/ascii-mermaid` (all MIT) are vendored as 68 portable parity cases — upstream's local-time `Date` expectations normalized to UTC — plus a 9-entry exclusions manifest whose reason codes (`wall-clock-fallback`, `local-tz`, `silent-ignore-vs-named-error`, `exclude-boundary-model`) document every deliberate divergence; entries with a named `oursErrorCode` are EXECUTED by `src/__tests__/gantt-upstream-bench.test.ts`, so the divergence ledger cannot rot. The harvest confirmed `after`/`until`/forward-reference/multi-id semantics and the 16-task ordering fixture match upstream exactly, and drove three compat fixes: invalid `tickInterval` values are now ignored like Mermaid (their own docs use `1decade`; the PR #7197 guard lives in bounded tick generation), the docs corpus gained a gantt section (11 examples, gated at parse 1.00 / verify 0.80 / round-trip 1.00 — two entries verify-fail honestly: a task-less fragment and a doc example that even upstream only renders via wall-clock fallback), and verify gained the Tier-1 **`UNRESOLVABLE_SCHEDULE`** warning (error severity): a structured gantt that parses and round-trips but whose schedule cannot resolve (bad calendar date, dependency cycle, everything-excluded calendar) now flips `verify.ok` with the named `GANTT_*` reason instead of silently passing verify and then throwing at render.
- **Gantt chart family** (`gantt`, BUILD-5 / [docs/design/families/gantt.md](./docs/design/families/gantt.md)): renders Mermaid Gantt charts to SVG/PNG/ASCII/Unicode with **typed mutation from day one** (segment-preserving, the sequence/BUILD-18 pattern). The parser models `title`, `dateFormat`, `axisFormat`, `tickInterval`, `inclusiveEndDates`, `topAxis`, multiple `excludes`/`includes` lines, `weekend friday|saturday`, `weekday`, `todayMarker`, `section` lines, task tags (`active`/`done`/`crit`/`milestone`/`vert`), `after`/`until` dependency expressions, the documented duration token set (`ms s m h d w M y`, decimals), and `click … href|call` (parsed and sanitized, never executed). A pure scheduler (`src/gantt/schedule.ts`, no DOM, no wall clock, all UTC epoch math) resolves dependencies — `after` starts at the latest referenced end, `until` ends at the earliest referenced start, working durations extend over excluded days, `includes` overrides `excludes` — and reports named structured errors (`GANTT_UNKNOWN_TASK_REF`, `GANTT_DEPENDENCY_CYCLE` naming the cycle, `GANTT_DUPLICATE_TASK_ID`, `GANTT_BAD_DATE`, `GANTT_NO_START`, `GANTT_SCHEDULE_OVERFLOW`) instead of Mermaid's silent wall-clock fallbacks. The today marker draws only from a caller-supplied clock (`ganttToday` render option); `todayMarker off` always wins. `displayMode: compact` packs sections into shared lanes deterministically; `vert` markers consume no task row; tick generation is bounded (mermaid PR #7197 class). Critical path / slack / entry / sink analysis is computed over `after` edges and exposed through `describe` (never invented when dependencies are absent). The agent surface narrows via the new `asGantt` and exposes 9 mutation ops (`set_title`, `add_section`, `rename_section`, `remove_section`, `add_task`, `remove_task`, `rename_task`, `set_task_status`, `set_task_dates`) across the library, CLI (`am mutate`), and MCP Code Mode SDK, validated by canonical-line re-parse (correctness by construction); calendar directives/click/comments ride along VERBATIM as opaque-block segments, and duplicate task ids / unclosed `accDescr` blocks fall back to a lossless whole-opaque body. Ships parser/scheduler/layout unit tests, fast-check scheduler+round-trip properties, ASCII/Unicode goldens (basic, excludes, milestone+vert, compact, CJK), an SVG golden with strict-security and light/dark contrast checks, a differential test against the `mermaid-ast` oracle, a targeted Stryker config (`mutation-test:gantt`), and extends the determinism grep-lint to `src/gantt/**`. Adds the `DUPLICATE_TASK` mutation-error code and the `ganttToday` render option.
- **Pie and quadrant structured mutation — typed mutation is now the enforced default for every renderable family** (following the journey/architecture/xychart pilots): the modeled subset of `pie` (header `showData`, `title`, `"label" : value` slices) and `quadrantChart` (title, `x-axis`/`y-axis` near/far labels, `quadrant-1..4` region labels, `<Label>: [x, y]` points) now parses to a typed `PieBody`/`QuadrantBody`, narrows via the new `asPie`/`asQuadrant`, and exposes 7 mutation ops each — pie: `set_title`, `set_show_data`, `add_slice`, `remove_slice`, `rename_slice`, `set_slice_value`, `reorder_slice`; quadrant: `set_title`, `set_axis_labels`, `set_quadrant_label`, `add_point`, `remove_point`, `move_point`, `rename_point` — across the library, CLI (`am mutate`), and MCP Code Mode SDK. Quadrant numbering follows Mermaid core (1=top-right, 2=top-left, 3=bottom-left, 4=bottom-right); coordinates stay in `[0, 1]`. Canonical source re-parses 1:1 under the legacy `parsePieChart`/`parseQuadrantChart` (differential-tested). Unmodeled syntax (accTitle/accDescr, malformed pie entries, quadrant styling `classDef`/`:::`, out-of-range coords, duplicate point labels) still falls back to a lossless opaque body, and the renderer keeps surfacing its loud error. This completed the pre-Gantt promotion: **all then-registered renderable families shipped structured mutation, and a new doc-sync test (`every registered renderable family ships typed mutation`) fails CI if any registered family lacks mutate/serialize hooks, an ops declaration, or a narrower** — see `docs/contributing/adding-diagram-types.md`. Adds the `SLICE_NOT_FOUND` and `POINT_NOT_FOUND` mutation-error codes.
- **Perceptual-quality coverage for every renderable family** (QUAL-1): `layoutMermaid` now projects a real `RenderedLayout` for class, ER, journey, architecture, xychart, pie, quadrant, and gantt (joining flowchart/state/sequence/timeline), so `measureQuality`/`checkQuality` and the `verifyMermaid(...).layout` field carry truthful geometry instead of an empty layout. Each adapter (`src/agent/family-layouts.ts`) parses the diagram's canonical source via the family's own parser+layouter — the same geometry the SVG renderer draws — so opaque-but-renderable diagrams are still measured and invalid opaque diagrams degrade to an empty layout rather than throwing. Per family: class/ER nodes are entity/class boxes with relation edges; journey tasks are nodes with section-frame groups; architecture services/junctions are nodes with edges and group frames; xychart bars + line-point markers are nodes with the plot-area group; pie slices map to legend-anchored label boxes; quadrant points are nodes with quadrant-region groups; gantt tasks and milestones are nodes with section-band groups. This is a measurement-only change — rendering bytes are unchanged. The layout-compare harness gains a fixture per family and now scores an empty→measured transition as an improvement, not a faithfulness regression.
- **State diagram structured body** (BUILD-19): state diagrams now own a dedicated `StateBody` IR (`body.kind: 'state'`) instead of being projected as flowcharts. The modeled subset — simple states (`state "Label" as id`, `id : Label`), transitions `from --> to [: label]` with `[*]` start/end pseudostates (scoped per composite level), nestable composite blocks `state X { … }`, and `direction` — parses to a typed body, narrows via the new `asState`, and exposes 8 mutation ops (`add_state`, `remove_state`, `rename_state`, `set_state_label`, `add_transition`, `remove_transition`, `set_transition_label`, `make_composite`) across the library, CLI (`am mutate`), and MCP Code Mode SDK. `remove_state` cascades transitions and refuses a non-empty composite; `rename_state` rewrites transitions. Verify keeps full Tier 1 + Tier 2 geometric coverage: the body projects to a `MermaidGraph` via the legacy parser (`stateBodyToGraph`) and runs the identical flowchart `verifyGraph`. Canonical source re-parses 1:1 under the legacy renderer (differential-tested). Unmodeled syntax (`<<fork>>`/`<<choice>>`/`<<join>>`, history states, concurrency `--`, notes, `classDef`/`class`/`:::` styling, bare `stateId` lines, hyphenated composite ids) falls back to a lossless opaque body. Corpus round-trip for state jumped 5% → 100%. Adds the `STATE_NOT_FOUND`, `TRANSITION_NOT_FOUND`, and `DUPLICATE_STATE` mutation-error codes.
- **Segment-preserving structured sequence body** (BUILD-18): a sequence diagram with `Note`/`alt`/`opt`/`loop`/`par`/`critical`/`break`/`rect`/`activate`/`autonumber`/`title` no longer goes whole-body opaque. The `SequenceBody` now carries an ordered `statements: SequenceStatement[]` list (`participant`/`message` refs into the existing `participants`/`messages` arrays, plus `opaque-block` segments holding unmodeled lines VERBATIM). Such diagrams narrow via `asSequence` and keep all 5 mutation ops live: `add_message` appends after the last statement, `add_participant` inserts after the last participant declaration, and `remove_message`/`set_message_text` indexes address only TOP-LEVEL messages — messages inside an `alt`/`loop` block are part of the verbatim segment and are never touched. Block constructs are captured start→matching-`end` as one nesting-tracked opaque-block. Only un-segmentable input (a stray `end`, an unclosed block) still falls back to a lossless whole-body opaque body. The round-trip stays verbatim-lossless throughout (proven by fast-check properties and the 132-sample MermaidSeqBench + mermaid-docs corpus gates, all still 100% lossless). This ends the all-or-nothing opaque cliff for sequence; class/ER/timeline segment-preservation is follow-up work.
- **Quadrant chart family** (`quadrantChart`, BUILD-11): renders Mermaid quadrant charts to SVG/PNG/ASCII. Supports the `quadrantChart` header, optional `title`, `x-axis <left> --> <right>` / `y-axis <bottom> --> <top>` axis labels (far side optional), four `quadrant-1..quadrant-4` region labels (Mermaid numbering: 1=top-right, 2=top-left, 3=bottom-left, 4=bottom-right), and `<Label>: [x, y]` points with coordinates in `[0, 1]`. SVG draws a square plot split into four theme-tinted quadrants with points as accent circles; ASCII draws a bordered grid with a coordinate legend. Quadrant is structured-when-narrowed via `asQuadrant` (7 ops). Malformed lines — out-of-range/non-numeric coordinates, missing brackets, duplicate point labels, and unsupported styling (`classDef`, `:::`) — fall back to a lossless opaque body rather than being silently dropped.
- **XY chart structured mutation** (BUILD-16, following the BUILD-15 journey and BUILD-17 architecture pilots): the modeled subset of `xychart-beta` (bare title, named/categorical/range x-axis, named/range y-axis, and `bar`/`line` series with optional names and finite values) now parses to a typed `XyChartBody`, narrows via `asXyChart`, and exposes 8 mutation ops (`set_title`, `set_x_axis`, `set_y_axis`, `add_series`, `remove_series`, `set_series_values`, `set_series_name`, `reorder_series`) across the library, CLI (`am mutate`), and MCP Code Mode SDK. Canonical number format is `String(n)` (finite values only), proven to re-parse identically under the legacy renderer's `parseXYChart`. Unmodeled syntax (quoted text, multi-statement `;` lines, accTitle/accDescr, the `horizontal`-only/other header suffixes beyond orientation, `curve basis`) still falls back to a lossless opaque body. Adds the `SERIES_NOT_FOUND` mutation-error code.
- **Architecture structured mutation** (BUILD-17, following the BUILD-15 journey pilot): the modeled subset of `architecture-beta` (groups/services/junctions and anchored `id:SIDE arrow SIDE:id` edges) now parses to a typed `ArchitectureBody`, narrows via `asArchitecture`, and exposes 10 mutation ops (`add_service`, `remove_service`, `rename_service`, `set_service_label`, `set_service_icon`, `move_service`, `add_group`, `remove_group`, `add_edge`, `remove_edge`) across the library, CLI (`am mutate`), and MCP Code Mode SDK. `remove_service` cascades its edges; `rename_service` keeps edges anchored; `remove_group` refuses a non-empty group. Unmodeled syntax (the `{group}` boundary modifier, accTitle/accDescr, header suffixes) still falls back to a lossless opaque body.
- **Journey structured mutation** (BUILD-15, the pilot promotion from opaque-only fallback semantics): simple journeys (title/sections/`task: score: actors`) now parse to a typed `JourneyBody`, narrow via `asJourney`, and expose 10 mutation ops (`set_title`, `add_section`, `remove_section`, `set_section_label`, `add_task`, `remove_task`, `set_task_text`, `set_task_score`, `set_task_actors`, `rename_actor`) across the library, CLI (`am mutate`), and MCP Code Mode SDK. Unmodeled journey syntax (accTitle/accDescr, out-of-range scores, header suffixes) still falls back to a lossless opaque body.
- Family-plugin dispatch consolidation (BUILD-3): parse, serialize, and mutate for ALL families — including flowchart/state — now route through the `FamilyPlugin` registry; adding a structured family is one body module plus one registration. Flowchart and state register as two plugins sharing one implementation over the legacy graph body, with the serialized header bound per kind; dispatch is by diagram kind, the plugin contract gained `canonicalSource`/multi-error parse and an optional `buildSourceMap` hook. Mutation now rebuilds `canonicalSource` uniformly, so mutated sequence/flowchart/state diagrams no longer carry stale source.
- **Pie chart family** (`pie`): renders Mermaid pie charts to SVG/PNG/ASCII. Supports the `pie` header with optional `showData` and `title`, plus `"label" : value` entries (positive numbers). SVG draws clockwise slices with a theme-derived palette and a percentage legend; ASCII draws a proportional bar list. Pie is structured-when-narrowed via `asPie` (7 ops). Malformed entries fall back to a lossless opaque body rather than being silently dropped. Adds the first slice of BUILD-5; see `eval/family-usage/` for the family-usage evidence step.
- Layout before/after comparison harness (`eval/layout-compare/run.ts`): snapshots the docs corpus + targeted fixtures (SVG, ASCII, perceptual metrics) per git state and emits a side-by-side HTML report with metric deltas and a regression exit code. Geometry tests now also pin subgraph `direction` support — honored even when an inner node links outward, which Mermaid itself does not solve (mermaid-js#2509).
- **Breaking package identity**: first Agentic Mermaid release is prepared as `agentic-mermaid@0.1.0`; package imports are now `agentic-mermaid` and `agentic-mermaid/agent`, and the GitHub repo is `adewale/agentic-mermaid`.
- **Agent-native surface** (`agentic-mermaid/agent` subpath export): a typed editing API for agents and tools.
  - `parseMermaid` → sealed `ValidDiagram` IR carrying frontmatter, init directives, comments, accessibility, and the canonical source.
  - `verifyMermaid` → structured `LayoutWarning` codes in three tiers (Tier 1 structural/reliable, Tier 2 geometric/advisory, Tier 3 lint/advisory). No vision/PNG needed.
  - `mutate` → typed, family-narrowed structural edits for all twelve renderable families: flowchart/state, sequence (segment-preserving, BUILD-18), timeline, class, ER, journey, architecture, xychart, pie, quadrant, and gantt. Diagrams with unmodeled constructs use a lossless source-level/opaque body with no structured mutation exposed.
  - `serializeMermaid` / `synthesizeFromGraph` → round-trip back to canonical Mermaid source.
  - Deterministic layout JSON, verified byte-identical across processes (ELK is configured for model-order layout; there is no layout seed).
- **`am` CLI**: `render`, `preview` (strict standalone HTML + optional `--open`), `verify`, `parse`, `serialize`, `mutate` (single `--op` or batched `--ops`, verify-before-emit), `format`, `describe`, `capabilities`, `batch` (including mutate), `render-markdown`, `llms-txt`, `init-agent`, `--json`, per-command `--help`, and `--agent-instructions`.
- **Node-runnable package bins**: `am`, `agentic-mermaid`, and `agentic-mermaid-mcp` point to built `dist/*.js` entrypoints for npm/npx consumers while Bun `bin/*.ts` files remain for local development.
- **Hosted agent manifests**: the Agentic Mermaid website publishes `/llms.txt` and `/agent-instructions.md` for zero-install agent onboarding.
- **Publish hardening**: package metadata and release workflow support public npm provenance (`publishConfig.provenance`, GitHub OIDC `id-token`, build-before-publish, and trusted publishing via `npm publish`).
- **`agentic-mermaid-mcp`**: a Code Mode MCP server (one JavaScript `execute` tool, `node:vm` sandbox, typed SDK declaration) so agents compose the whole verify-before-commit loop in one round-trip.
- **`Instructions_for_agents.md`** and agent-agnostic skill bundles under `skills/`.
- See [`AGENT_NATIVE.md`](./AGENT_NATIVE.md) for the design, [`examples/agent-loop.ts`](./examples/agent-loop.ts) for a runnable walkthrough, [`examples/mcp-vs-cli-complex-diagrams.ts`](./examples/mcp-vs-cli-complex-diagrams.ts) for MCP-vs-CLI parity, and [`examples/agent-improve-auth-flow.ts`](./examples/agent-improve-auth-flow.ts) for create → assess → mutate → reassess → render.
- Live editor deployment at <https://agentic-mermaid.dev/editor>.
- Editor examples palette with presets for every supported diagram family: flowchart, state, architecture, sequence, class, ER, timeline, journey, xychart, pie, quadrant, and gantt.
- Style + Palette SVG styling via named looks, palette stacks, custom public JSON style records, and deterministic `seed` values.
- Style + Palette showcase samples in the live examples surface.
- Fork documentation describing differences from upstream in [`docs/fork-differences.md`](./docs/fork-differences.md).
- Historical product/design context documents ([`docs/project/product.md`](https://github.com/adewale/agentic-mermaid/blob/8516976c679dccf758e68d47e7969c9b58ed3cb7/docs/project/product.md), [`docs/project/design.md`](https://github.com/adewale/agentic-mermaid/blob/8516976c679dccf758e68d47e7969c9b58ed3cb7/docs/project/design.md)) for future design-system aligned work.
- Homepage sample search and category filters for browsing the full showcase.
- Mobile editor pane switching for Code, Config, Preview, and Examples.
- **Package-surface property fuzzing** (`src/__tests__/property-cli-surface-fuzz.test.ts`, `property-mcp-surface-fuzz.test.ts`): fast-check now drives the agent-facing package entry points that previously had only example-based coverage — the CLI argv parser (`parseArgs`, total-shape + verbatim-flag invariants), the `am batch` line handler (`runBatchLine`) and markdown-block renderer, and the MCP JSON-RPC router (`handleRequest`) plus the Code-Mode `execute` sandbox (`executeInSandbox`). The contract under test: a malformed request or hostile code yields a structured error / `{ok:false}` result, never an unhandled crash that would take down the stdio/HTTP server. These are crash-freedom/contract guards that would catch a future regression, complementing the engine-level parser fuzzing in `property-crash-freedom.test.ts`.
- **Shipped-artifact differential fuzz** (`e2e/dist-artifact-fuzz.e2e.test.ts`): builds `dist/` and drives the bundled `dist/agent.js` under **plain Node** against fast-check-generated diagrams, checking it against the source build for (1) crash parity across all 12 families — the artifact throws iff the source does — and (2) byte-identical layout JSON / SVG / ASCII on flowcharts, plus a PNG crash-freedom smoke through the resvg native addon. This is the first coverage of the actual npm consumer path (bundled, under Node), catching tsup tree-shaking / external-resolution / ESM-interop breakage that source-level (`src/`, under Bun) tests cannot see; it runs in the CI e2e lane.
- **Consumer-path fuzz** (`e2e/tarball-consumer-fuzz.e2e.test.ts`): closes the last artifact gap by fuzzing what actually ships — `npm pack` → install the tarball into a clean project → drive the installed package and its bins under **plain Node** with generated input. Three arms over one install: the installed library resolves both entry points via the exports map and renders identically to source (crash parity + flowchart byte-equality + PNG crash-freedom); `am batch --jsonl` emits one result per line with no stream-abort on hostile lines and ASCII matching source, and one-shot `am render` across formats plus a not-found file return valid exit codes without crashing; and the `agentic-mermaid-mcp` bin answers generated JSON-RPC over stdio with well-formed responses and no server crash. This validates files[] completeness, exports resolution, bin linking, and native-dependency install end-to-end; it runs in the CI e2e lane.

### Changed
- **0.1.0 release prep**: README, Getting started, and the generated website install card now make `npm install agentic-mermaid` the primary path; source-checkout instructions remain for repository development and pre-publish previews can still force source-install copy with `SITE_NPM_STATUS=source` or `SITE_NPM_PUBLISHED=0`.
- **`LABEL_OVERFLOW` now measures the rendered label, not raw source chars** (from direct agent feedback: the cap counted `<br/>` tags and `&#160;` entities toward the 40-char limit, flagging legitimately-fine multi-line labels). The cap now applies to the longest *displayed* line — XML entities decode to one character, `<br>`/`\n` split lines, and formatting tags (`<b>`, `<i>`, …) are stripped — mirroring what the SVG renderer draws. `charCount` in the warning payload reports the rendered length. Applies to every family and to the opaque-body label extractors.
- The local HTTP MCP startup line now names the plain-JSON `/rpc` endpoint alongside `/sse`, and `docs/mcp-http-transport.md` spells out which endpoints reply with SSE framing vs. plain `application/json` (from direct agent feedback: a script POSTing to the SSE session flow had to strip `data:` framing by hand).
- The website MCP and security pages now carry an explicit privacy note: hosted tool calls send diagram source/code to the server; eligible pure-tool results may be reused by a private server-side compute cache while HTTP responses remain `no-store`; local library/CLI/stdio need no network.
- BUILD-20 now has a checked cross-family upstream parser/DB harvest under `eval/mermaid-upstream-suite-bench/` with a pinned Mermaid revision (`a2d9686451df7c4644a3eeca20535bbd4c5776b0`), repeatable `harvest:upstream` and `harvest:upstream:refresh-check` commands, exact structural assertions, BUILD-20 ownership on local compatibility exclusions, and a family-by-family manifest accounting for all 1,170 considered upstream parser/DB blocks: 658 imported source blocks, 512 documented exclusions, and 0 deferred blocks. The executable gate covers 648 cases including the existing 68-case Gantt companion bench, and `ratchet.json` fails CI if imported coverage drops or local-gap budgets grow.
- **Breaking (unreleased agent surface, BUILD-19): flowchart ops no longer apply to state diagrams.** `asFlowchart` now returns `null` on a state diagram (its body kind is `'state'`, not `'flowchart'`); narrow with `asState` and use the state-shaped ops instead. The CLI `MUTATION_OPS_BY_FAMILY.state` list changed from the 6 flowchart ops to the 8 new state ops, and `mutateAny` narrows `asState` before `asFlowchart`. Every agent surface that said "state shares the flowchart body / narrow via asFlowchart" is updated to the new truth.
- SVG appearance customization now uses Style + Palette render options; removed flat render style aliases are intentionally ignored.
- Showcase and editor docs now point users to live examples and presets.
- Fork docs and deploy script now treat GitHub Pages as the fork-owned site and avoid the upstream-owned Craft/Cloudflare deployment target.
- Live editor now starts blank by default, uses salmon as the default theme, uses a larger grouped Examples palette, and includes Copy SVG alongside Save SVG/PNG export.
- Homepage deployment now builds the full sample gallery, defaults to salmon, and removes text that implied Craft affiliation.
- Editor example presets now preserve the currently selected theme instead of forcing Default or Solarized Light.
- Live editor now offers a persistent Examples sidebar and a blank-state “Load an example” CTA.
- Editor controls, empty state, sidebar, and dropdowns received polish for concentric radii, tactile press states, smoother icon transitions, tabular numbers, and cleaner text wrapping.
- Homepage and editor typography now use Atkinson Hyperlegible for a more distinctive, readable UI face.
- Homepage rendering yields between sample batches to keep the page responsive while the full gallery renders.
- Editor empty state now includes quick starter chips for Flowchart, Sequence, and Style + Palette examples.
- Example rows now include compact diagram-family glyphs for faster scanning.
- Agent-facing Code Mode examples are executable JavaScript snippets and the stored eval now checks ordered verify inspection before serialization.
- Every built-in renderable family is structured-when-narrowed in the agent surface; source-level-only editing is reserved for opaque fallback bodies with unmodeled syntax.
- Agent guidance now distinguishes new-diagram source authoring from existing-diagram structured mutation; Code Mode is positioned as a structured-edit channel rather than mandatory diagram creation.
- `am capabilities --json` now reports `families[].editPolicy` (`structured-when-narrowed` or `source-level-only`) in addition to `mutationOps`, so agents can route edits without trial-and-error.
- Quality docs now explicitly state that Agentic Mermaid is not Mermaid visual parity: `verify.ok` is structural, while layout quality needs metrics, geometry assertions, screenshots, or rendered artifacts.
- Agent-usage evals now include a committed failure corpus of captured bad-agent paths and curated executable regressions for markdown-only answers, regenerated Mermaid, CLI advice, serialize-without-verify, ignored verify results, and opaque mutation attempts.
- `agentic-mermaid-mcp` now supports HTTP/SSE transport (`--transport http`) in addition to stdio, with managed PNG file/URL artifacts for clients that should not receive large base64 payloads.
- ASCII core hardening (audit follow-up): the widest-segment fallback in `edge-routing.ts` label placement now breaks width ties on a deterministic secondary key (start x, then y) instead of relying on `Array.prototype.sort` stability, so label placement is reproducible across JS engines; verified byte-identical on the layout-compare corpus (261/261 unchanged). (The two index-ordered sorts need no tie-break — segment indexes are unique, a fact the first mutation-testing run proved.) The two confusable subgraph field pairs on `AsciiEdge` (`fromSubgraph`/`toSubgraph` for attachment-point selection vs `attachFromSubgraph`/`attachToSubgraph` for container-border clipping) now carry doc comments naming their consumers, and the fan-in exclusion (self-loops, 2-cycles) and trunk-sharing skip logic in `grid.ts` carry "why" comments with upstream issue references. New `ascii-layout-gaps.test.ts` pins nested subgraph containers, multi-level direction overrides, and unlabeled fan-out trunk sharing. Mutation testing is now scoped to the ASCII core (`docs/mutation-testing.md`).
- **Release gate parity**: `publish.yml` now reproduces CI's deterministic gate (tests, `tsc`, `hero:check`, `website:check`, golden-drift, incremental mutation) before it builds and publishes, and pins `bun-version: 1.3.13` to match `ci.yml`. A tagged release can no longer publish a commit that would fail CI, and no longer runs on the `latest` Bun that `ci.yml` documents as flaky. (The browser/CLI e2e lane still runs on `main` via `ci.yml`.)
- **npm metadata hygiene**: `bugs.url` now points at the issue tracker (`…/issues`) instead of duplicating the repo root, and `repository.url` / `bin` paths are in npm's canonical form (`npm pkg fix`) so `npm publish` no longer emits auto-correct warnings.
- **Publish-status consistency**: until `agentic-mermaid` is actually on npm, `README.md` and `docs/getting-started.md` now say "not yet published; install from source" — matching the test-enforced website copy — instead of instructing `npm install agentic-mermaid`. A new `docs/contributing/releasing.md` documents the GitHub-Release → provenance-publish flow and the one-step "published" flip at release time.
- **npm OIDC trusted publishing**: `publish.yml` now publishes via OpenID Connect — a short-lived id-token, **no `NPM_TOKEN` secret** — instead of a long-lived token, and provenance is generated automatically (the `--provenance` flag is dropped). Node is bumped `20`→`22` with an explicit `npm install -g npm@latest` (trusted publishing needs Node ≥ 22.14 / npm ≥ 11.5.1; Node 20 is also EOL as of 2026-04-30). `docs/contributing/releasing.md` now documents the one-time npmjs.com trusted-publisher setup, the public-repo requirement for provenance, the three-way repo match, and locking the package to "require 2FA / disallow tokens" after first publish. Rationale: npm made trusted publishing GA (2025-07) and revoked classic tokens (2025-12); granular tokens now expire in ≤ 90 days, so the token flow was operationally fragile.
- **`exports` types-first + `./package.json` export**: reordered both conditional blocks to `types, bun, import, default` so `types` precedes the JS conditions (publint `EXPORTS_TYPES_SHOULD_BE_FIRST` was an **error**; `publint` now passes clean), and added `"./package.json": "./package.json"` so tooling can read the manifest through the sealed exports map. No runtime change — Bun still resolves `bun`→`src`, Node `import`→`dist`.
- **Release gate now fuzzes the shipped artifact**: `publish.yml` runs the dist-artifact + tarball-consumer e2e fuzz before `npm publish`, so a release commit that changed `files[]`/`exports`/`bin` is validated end-to-end (pack → install → drive under Node) — closing the gap where those tests ran only in the per-PR CI e2e lane, not the release path.
- **Privileged-workflow supply-chain hardening**: `oven-sh/setup-bun` in `publish.yml` is pinned to a commit SHA (was the mutable `v1` tag) so a retagged/compromised action can't ride the publish credentials; the e2e job's `timeout-minutes` was raised 30→45 to cover the added artifact-fuzz budgets.
- **Review-driven test + doc hardening**: the tarball-consumer ASCII differential now asserts the render succeeded and emitted `ascii` **unconditionally** (it previously skipped — and passed vacuously — if the field vanished), and its mixed-op batch draws ops in one `fc.sample` (an in-loop `fc.sample(arb, 1)` re-seeded to the same pick each call, so only one op was ever exercised). `releasing.md`'s "published flip" now points at `website/build.ts` (which reads `SITE_NPM_STATUS`) rather than `pages.yml` (which never did); removed a dead `npmChecked` var; README notes the package is ESM-only and that `am …` examples need `bun run bin/am.ts …` from a source checkout.

### Fixed
- **Variable-length-link shoves no longer leave node overlaps or blocked routes** (#81): `honorLinkRankDistance` pushes ahead whatever its shove lands on (restoring ELK's no-overlap guarantee) and rebuilds blocked feedback/dogleg reconnect routes through free channels. The 18-signature degenerate fuzz class collapsed to zero (deep fuzz: `edgeThroughNode` 39→0, `nodeOverlaps` 71→0, `hitches` 18→7); the clean corpus is byte-identical.
- **Post-freeze repairs re-certify the edges they re-route** (#83): the shared-trunk label lane, `reanchorOffOutlineEndpoints`, and `rerouteEdgesThroughNodes` previously shipped `routeCertificate === undefined` after rewriting a route.
- **Edge labels no longer stack on parallel/reciprocal edges** (flowchart, state): a new freeze-safe `separateEdgeLabelPills` pass slides colliding label pills along their own routes (with rubric-tolerance lateral offsets for tight reciprocal lanes).
- **Quadrant point labels are collision-aware and canvas-clamped** (layout-computed candidates right/left/below/above; the audit's worst family at 89% of fuzzed charts affected, now 32% with only dense-cluster residuals).
- **XY chart x-axis tick labels thin deterministically and clamp to the canvas** instead of garbling into each other (28% of fuzzed charts → 0%).
- **Gantt compact mode places task labels beside their own bars** instead of printing shared-row labels on top of each other.
- **ER and architecture relationship/edge labels collision-separate along their routes** (ER 15%→2%, architecture 37%→6% of fuzzed diagrams; the architecture service/group containment residual is tracked in #90).
- **Multiline `@{ ... }` node metadata warns like the single-line form** (`UNSUPPORTED_SYNTAX`, issue #44 first slice) instead of verifying silently.
- **Mixed fan-in/fan-out hub centering** (issue #61): a non-terminal hub that both receives from a peer group and fans out to another peer group is now centered with BOTH sides in view rather than by whichever centering pass writes last. `centerPeerBarycenters` processes each hub once over all of its eligible peer-barycenter constraints in deterministic id order, dropping the side that a later pass re-spreads around the hub (a 2–3 peer terminal fan-out, which `applySymmetricFanoutEmissions` follows the hub with) so the anchored side wins. When both incoming and outgoing groups are anchored and their barycenters disagree, the hub sits at their midpoint — the minimax-optimal one-node placement, which halves the worst peer offset. Across the `TD`/`BT`/`LR`/`RL` × `n,m ∈ 2..6` probe this cuts mixed cases above 0.75px from 46 to 36 and the worst `peerBarycenterDelta` from 8.0px to the documented ~4px midpoint floor (small fan-outs now resolve to ≤0.75px on both sides). Ratcheted by `layout-symmetry.test.ts`; single-sided fan-in/fan-out centering and route contracts are unchanged.
- ASCII renderer: labelled top-down fan-outs (e.g. `Src -->|left*| Left`, `Src -->|center*| Center`, `Src -->|right*| Right` from one source) now share a single trunk that forks with `┬` tee junctions, and each label sits on its own vertical drop segment — instead of one sibling taking an L-shaped detour with its label stranded on a horizontal run (`─center*─`) and stray corners (upstream lukilabs#111, PR #113). Driven by deterministic FIFO tie-breaking in the A* pathfinder plus label placement that prefers the per-sibling vertical drop in TD; unlabelled fan-outs were already handled by edge-bundling. Pinned by `td_fanout_labeled` golden and charset-independent invariants in `ascii-fanout-trunk-labeled.test.ts`; the LR box-start repro stays byte-identical.
- ASCII renderer: an edge whose endpoint is a subgraph id (e.g. `Start --> Pipeline` where `Pipeline` is a subgraph) no longer renders a phantom duplicate node box. The edge now attaches to the subgraph container — the visible terminal is clipped to the container's border with the arrowhead drawn on the border — matching the SVG/ELK hierarchical-port behavior and Mermaid's handling of the #2509 case. Edge semantics are preserved (no rerouting to an arbitrary inner member node).
- ASCII box-start connectors (`├ ┤ ┬ ┴`) now sit flush on the source node's border instead of floating in whitespace when a sibling edge's label widens the grid column (upstream lukilabs#112 class); the gap is filled with style-matching line characters.
- ASCII fan-in layouts: roots feeding the same target are grouped contiguously and each fan-in target aligns under its own root group (upstream lukilabs#69), so trunk rows of different groups no longer collide into ambiguous `┼` crossings. Self-loops and 2-cycle toggles are excluded so state-machine layouts are unaffected.
- ER cardinality tokens now match Mermaid's lexer on both sides (`||`, `|o`, `o|`, `}o`, `o{`, `}|`, `|{`): left-side `}o` (used by the mermaid-docs corpus as `}o..o{`) previously failed the sort-based normalization and the whole relationship — including its entities — was silently dropped, rendering an empty diagram. Non-Mermaid forms (`{o`, `o}`, `|}`, `{|`) now raise a clear parse error instead of rendering. The render-path parser and the agent ER body parser now agree.
- Showcase and editor theme switching no longer flashes the previous theme's diagram background (white, when leaving a light theme): existing SVG CSS variables are patched instantly, switching back to Default restores each sample's captured original style, and rapid theme switches can no longer interleave stale re-renders.
- TypeScript CI failures in journey style padding and optional node corner-radius resolution.
- Editor export actions are disabled until a diagram exists and parser errors now include recovery-oriented copy.
- Editor menus, sidebar, and theme controls now close with Escape and expose stronger ARIA/focus states.
- Removed layout-property sidebar animation in favor of opacity/transform-based motion.
- CLI/docs drift for `am describe`: the command now emits prose or AX-tree JSON and is covered by e2e tests.
- Feedback-loop flowcharts now preserve the primary source order more reliably instead of ranking decision nodes before their predecessors.
- Acyclic fan-in/fan-out flowcharts now use source-aware model ordering so declared-direction edges do not accidentally route backward; layout-quality heuristics cover direction progress, edge-vs-node collisions, self-loop clearance, and feedback-process cleanliness.
- Tier 3 lint warnings now flag `DUPLICATE_EDGE` and `UNREACHABLE_NODE` in flowchart/state verification without changing `verify.ok`.

## Fork baseline before this changelog

This fork already included broader rendering parity work, additional diagram families, GitHub Pages publishing, fork audit notes, and lessons learned. See [`docs/project/lessons-learned.md`](./docs/project/lessons-learned.md) and git history for pre-changelog detail.
