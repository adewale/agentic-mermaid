# Fonts in custom styles

A custom style chooses a font family; the environment that renders the
diagram supplies the actual face. The public `StyleSpec` deliberately keeps
those responsibilities separate:

```json
{
  "$schema": "https://agentic-mermaid.dev/schemas/style-spec.schema.json",
  "name": "acme-report",
  "font": "'Acme Sans', Inter, system-ui",
  "colors": {
    "bg": "#fffdf8",
    "fg": "#171512",
    "accent": "#1d4ed8"
  },
  "stroke": "crisp"
}
```

`font` is a CSS family name or family stack. It does not load a file, register
a browser `FontFace`, or tell the PNG rasterizer where to find one. This keeps
the same style usable across SVG and PNG while each output surface resolves
fonts in its own way.

For the rest of the Style model — inline specs, registration, stacking, and
validation — see [Authoring styles](./style-authoring.md).

## Quick recipe

Save the JSON above as `acme-report.style.json`. For an SVG that declares the
family without making an external font request:

```bash
am render diagram.mmd \
  --format svg \
  --style acme-report.style.json \
  --security strict \
  --output diagram.svg
```

For a PNG, point the local rasterizer at a directory containing the matching
font faces:

```bash
am render diagram.mmd \
  --format png \
  --style acme-report.style.json \
  --font-dirs ./fonts \
  --output diagram.png
```

The same workflow through the library is:

```ts
import { readFileSync, writeFileSync } from 'node:fs'
import {
  renderMermaidPNG,
  renderMermaidSVG,
  validateStyleSpec,
} from 'agentic-mermaid/agent'

const source = readFileSync('diagram.mmd', 'utf8')
const style = JSON.parse(readFileSync('acme-report.style.json', 'utf8'))
const problems = validateStyleSpec(style)
if (problems.length) throw new Error(problems.join('\n'))

const svg = renderMermaidSVG(source, {
  style,
  security: 'strict',
})
writeFileSync('diagram.svg', svg)

const png = renderMermaidPNG(source, {
  style,
  fontDirs: ['./fonts'],
})
writeFileSync('diagram.png', png)
```

## Which font value wins

For `renderMermaidSVG`, font selection follows this precedence, from strongest
to weakest:

1. The render call's explicit `font` option.
2. Mermaid `fontFamily` configuration.
3. Mermaid `themeVariables.fontFamily` configuration.
4. The resolved Style stack's `font` field.
5. The default, Inter.

`renderMermaidPNG` accepts the same shared `font` option and precedence as SVG.
`fontDirs` makes faces available to the rasterizer but does not choose the
family.

Within a Style stack, later entries win. For example, `[style, 'dracula']`
keeps the inline/file-loaded Style's font because `dracula` is a palette-only
Style; a later Style that defines `font` would replace it. A file's `name`
field does not register it automatically — give it a canonical `look:` or
`palette:` name and call `registerStyle(style)` before using that identity in a
library stack.

`validateStyleSpec` checks that `font` is a string. It cannot prove that the
family is installed, present under `fontDirs`, or available to a browser.

## Default occupied text bounds

Layout advances and glyph outlines are different measurements. Normal bundled
Inter at weights 400, 500, 600 and 700 has a conservative outline envelope for
Latin letters and spaces, derived from the pinned faces' substitution, kerning
and outline bounds. Native and Scene use the actual written position, baseline,
font size and fitted length with that envelope. It can expand the final SVG
viewport to retain overhanging ink without changing layout advances or ports.

The envelope applies only when the captured or admitted document selects Inter;
reusing a block under Caveat does not force Inter or borrow its envelope. It is
separate from a host's shaped-ink measurement. Punctuation, Unicode, synthetic
italic, other faces, arbitrary CSS font overrides and custom width-only profiles
keep their existing limits. This does not establish complete glyph visibility
for every font or extend the paint certificate beyond its stated scope.

## Trusted font measurement profiles

For the pinned Inter resources shipped with the package, graphical callers can
select a built-in partial profile without supplying executable callbacks:

```ts
const svg = renderMermaidSVG(source, { fontMetrics: 'bundled-inter' })
```

It uses natural advances and pair corrections for printable ASCII, normal
Inter at weights 400, 500, 600 and 700. Other families, weights, italic runs,
monospace and non-ASCII runs keep deterministic estimates and fallback shaping
protection. Pair corrections approximate default shaping; this is not a full
contextual shaping engine. Receipts identify
`agentic-mermaid:bundled-inter-ascii@1.0.0`.

This option does not load fonts. Make the matching faces available to the
browser or rasterizer as described above. The lazy browser entry downloads
the metrics only when selected. The default remains `fontMetrics: 'estimate'`.
Retain that default for general use. Opt into `bundled-inter` when closer
matching to the pinned Inter faces matters, after comparing your diagrams:
more accurate advances can change diagram dimensions and viewport fit. The
profile adds shipped bytes and can add layout work; it is not a general
performance or compactness improvement.

Do not combine `bundled-inter` with a host `textMeasurement` callback: choose
one measurement authority. Positioned-layout caches recognize the immutable
built-in profile and include its versioned identity in their key. Host callback
profiles retain their conservative cache bypass. Include warm calls as well as
first use when evaluating costs.

By default, graphical layout uses deterministic Inter-compatible width
estimates and fits SVG advances to that geometry. To lay out using your own
font metrics, bind an explicit profile to a trusted renderer:

```ts
import { createMermaidRenderer, type TextMeasurementProfile } from 'agentic-mermaid'

const textMeasurement: TextMeasurementProfile = {
  id: 'acme:bundled-fonts',
  version: '1.0.0',
  measure: input => fontEngine.width(input), // your preloaded font/shaping engine
}
const renderer = createMermaidRenderer({ textMeasurement })
const { svg, receipt } = renderer.renderMermaidSVGWithReceipt(source, {
  font: 'Acme Sans',
})
```

The synchronous callback receives displayed text, the selected font family,
size in pixels, weight, style (`normal` or `italic`), and a `monospace` flag.
Monospace runs name JetBrains Mono, matching the graphical renderer's code-font
preference. Return the natural horizontal advance before letter spacing:
wrapping and tracking are applied by the library. Widths must be finite,
non-negative, and at most 1,000,000 pixels. Line heights retain the existing
prepared-text rules. The profile is used throughout family layout and SVG
emission; it does not change terminal cell measurement.

A profile may also provide `measureInk(input)`, returning
`{ advance, bounds: { x0, y0, x1, y1 } }`. The bounds describe the actual shaped
glyph ink relative to the alphabetic baseline origin, in pixels, with positive
`y` downward. `advance` is that shaping engine's natural advance; it is distinct
from the allocation returned by `measure`. The library applies the actual
serialized SVG position, baseline and `textLength / advance` horizontal fitting
to the ink bounds. Allocation widths, wrapping and the emitted glyphs remain
unchanged. Return `undefined` when ink is unmeasured, or `{ advance, bounds: null }`
for a run that paints no ink. Advances must be finite and between zero and
1,000,000; nonempty ink needs a positive advance. Bound coordinates must be
finite, ordered and within ±1,000,000 pixels. An invalid or unbounded fitted
projection fails before returning output.

This optional authority currently covers prepared proportional ASCII fitted
runs, including independent bold/italic fragments and tracking. Every line in
the block must have supported ink metrics. Native non-ASCII shaping, decorations,
monospace blocks, external spans and typography overrides retain their existing
geometry without acquiring shaped-ink authority. Omitting the callback preserves
the width-only behavior. The callback must describe the same resolved fonts and
shaping used by the SVG/PNG consumer; estimated or fallback widths cannot supply
an ink envelope. This does not make the consumer load those fonts.

A complete shaped block retains the execution-selected family even when its
preparation omitted `fontFamily`. The SVG writer emits that explicit override,
so reusing the block under another document cannot silently substitute the new
root's font while keeping the old ink bounds. Width-only, default and unsupported
blocks retain their existing inherited-font behavior.

Pass the same profile to `createMermaidPNGRenderer` or
`createMermaidBrowserPNGRenderer` to share graphical geometry and receipt
identity across outputs. The fonts must also be available to the rasterizer
through its normal font-loading mechanism. A measurement profile does not
load or embed font files.

Keep a profile's metrics and font resources stable for its `id` and `version`.
Change the version when its width metrics, ink metrics or fonts change. For reproducible output,
measure from pinned font resources and a fixed shaping implementation. A host
may explicitly choose browser measurement after fonts load, but that remains
host-dependent; the library never selects Canvas implicitly. Profile fields
and callback references, including the optional `measureInk` slot, are read once
at renderer construction. Returned ink fields are copied and cached per complete
font input within the request, while mutable
state closed over by the callback remains the host's responsibility.

The selected identity appears as `receipt.textMeasurement` and in the
graphical execution decision; a custom identity participates in request
digests. Callbacks stay outside serialized options, Mermaid/Style config,
CLI/MCP data, and receipts. Omitting `textMeasurement` retains the deterministic
default (`agentic-mermaid:inter-estimate`, version `4.0.0`, exported as
`DEFAULT_TEXT_MEASUREMENT_PROFILE`) and leaves receipt shape unchanged.

## Resolution by output surface

| Surface | Where the face comes from | Custom-font control |
|---|---|---|
| SVG library/CLI | Browser, viewing application, or host-page CSS | `font`, `embedFontImport`, `security` |
| PNG library/CLI | Bundled faces, `fontDirs`, optionally OS fonts | `font`, `fontDirs`, `loadSystemFonts` / `--system-fonts` |
| Live editor | Faces available to the editor page and browser | Font picker; no `fontDirs` |
| Local MCP `render_png` | Bundled faces, `fontDirs`, optionally OS fonts | `fontDirs`, `loadSystemFonts` |
| Hosted MCP `render_png` | Faces bundled into the Worker | No filesystem font input; use local MCP/library/CLI for custom directories |
| ASCII, Unicode, JSON layout | Terminal/layout output has no font face | Style fonts do not apply |

### SVG

SVG output always declares the selected family through the root `--font` CSS
custom property and a `font-family` rule. The SVG renderer does not read
`fontDirs`.

By default, SVG output makes no font requests. Google Fonts imports are opt-in
via `embedFontImport: true`: a single plain family name such as `Acme Sans`
then produces a Google Fonts `@import`, and class and ER diagrams can also
import JetBrains Mono for their monospace labels. `security: 'strict'` omits
all of those requests even when `embedFontImport` is set, while keeping the
family declaration:

```ts
const svg = renderMermaidSVG(source, {
  style: { font: 'Acme Sans' },
  embedFontImport: true,
})
```

CSS variable references and family stacks are declared as-is and do not
produce an import for the selected family:

```ts
renderMermaidSVG(source, {
  style: { font: "'Acme Sans', Inter, system-ui" },
})

renderMermaidSVG(source, {
  font: 'var(--brand-font, Inter)',
})
```

With `embedFontImport: true`, the class/ER JetBrains Mono import still applies
to these renders unless strict security is enabled.

If the selected family is unavailable when the SVG is viewed, normal CSS
fallback applies. A family stack makes that fallback explicit.

Raw SVG declares the family through `var(--font, ...)`. Some static SVG
rasterizers, including resvg and librsvg, do not resolve CSS custom properties.
Use `renderMermaidPNG` for Agentic Mermaid's built-in workaround, or resolve
the font variable to a concrete `font-family` before feeding raw SVG to another
static rasterizer.

### Host-page and browser fonts

An inline SVG can use a face registered by its host document. A stylesheet can
map an installed face:

```css
@font-face {
  font-family: "Acme Sans";
  src: local("Acme Sans Regular"), local("AcmeSans-Regular");
  font-weight: 400;
}
```

Browser applications can also register bytes selected by the user:

```ts
const face = new FontFace('Acme Sans', await file.arrayBuffer(), {
  weight: '400',
})
await face.load()
document.fonts.add(face)
await document.fonts.load('400 14px "Acme Sans"')
```

Register one `FontFace` or `@font-face` rule per required weight, or accept the
browser's synthesized/fallback face for weights that are missing.

Register the face in the same document that displays the SVG, and wait for it
before displaying or raster-capturing the result. A raw SVG export still only
declares the family; it does not serialize a dynamically registered `FontFace`.
The public live editor can use faces already available to its page/browser,
but it has no filesystem `fontDirs` option or arbitrary font-file input.

### PNG

`renderMermaidPNG` renders offline with `@resvg/resvg-js`. It loads:

1. The bundled Inter faces used by the text-metrics model.
2. DejaVu Sans as a per-glyph fallback for symbols Inter lacks.
3. The bundled faces referenced by built-in Styles: Caveat, EB Garamond,
   Architects Daughter, and Share Tech Mono.
4. Any directories supplied through `fontDirs`.
5. OS-installed fonts only when `loadSystemFonts: true` is requested.

The CLI equivalents are `--font-dirs <dir[,dir...]>` and `--system-fonts`.
Prefer a dedicated `fontDirs` directory when reproducible output matters.
System-font loading makes the result depend on the machine's installed faces.

The family stored inside the font file must match the intended family token in
the Style's `font` value — normally the first family in its stack. Supply the
weights the diagram uses; Agentic Mermaid commonly emits 400, 500, 600, and
700. If an unbundled requested family cannot be resolved, PNG rasterization
uses Inter, with DejaVu available for per-glyph fallback.

## Diagnostics and layout limits

`PNG_FONT_COVERAGE` warns when no loaded face contains a character, such as a
CJK or emoji code point. It is a glyph-coverage check, not a family-presence
check. If `Acme Sans` is missing but Inter covers every Latin character, the
render can fall back without a coverage warning. Confirm custom-family output
visually or with a font-specific render fixture.

By default, diagram geometry uses the deterministic proportional measurement
contract recorded in `TEXT_MEASUREMENT_CONTRACT`; it never reads ambient
system-font state. A trusted measurement profile can explicitly replace those
widths as described above. Prepared ASCII text receives SVG `textLength`
with `lengthAdjust="spacingAndGlyphs"`, because loading a font resource does not
calibrate its metrics to the layout estimator. Plain lines are fitted as a
whole. Mixed formatting retains each style run's position and width; tracked
text retains each grapheme's allocation. The fitted span carries its own weight,
style and decorations so native and browser PNG can consume the same secured
SVG without relying on nested-span fitting behavior. Unusually wide or narrow
glyphs may be horizontally fitted rather than changing deterministic layout.

Non-ASCII text keeps native shaping for joining scripts and combining clusters.
Its conservative measured band does not prove exact glyph pixels for arbitrary
installed fonts or host CSS. Final certificates state their native Scene scope;
they are not post-raster glyph checks. Test long and formatted labels across
target families and output formats for visual quality.

## Troubleshooting

**The custom family is not visible in PNG.** Check the font's internal family
name, include the directory through `fontDirs`, supply the required weights,
and make sure Mermaid `fontFamily` configuration in the source is not
overriding the Style.

**The SVG requests a font from the network.** The render opted in with
`embedFontImport: true`; drop that option or render with `security: 'strict'`.

**The SVG looks different in another viewer.** The other environment did not
resolve the same family or selected a different fallback. Use a deliberate
family stack and make the required face available to that viewer.

**PNG warns about CJK or emoji.** Add a face covering those code points through
`fontDirs`, or opt into `loadSystemFonts` when machine-dependent output is
acceptable.

## Related documentation

- [Authoring styles](./style-authoring.md) — Style fields, stacks, registration,
  validation, and the quality rubric.
- [Custom style cookbook](./custom-style-cookbook.md) — complete JSON examples
  and screenshots.
- [API reference](./api.md) — `RenderOptions` and `PngOptions`.
- [Security posture](../SECURITY.md) — strict SVG and external-reference
  guarantees.
- [PNG determinism](./quality.md#png-determinism) — bundled fonts and the
  reproducibility tradeoff of system fonts.
- [Bundled font inventory](../assets/fonts/FONT-LICENSES.md) — the faces shipped
  with the package.
