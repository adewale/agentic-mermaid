# Gantt support specification

Status: shipped as-built contract and evidence record. This document records
implemented Gantt semantics, the completed rollout sequence, and unscheduled
research candidates. Root `TODO.md` is the sole authority for active work.

## Scope

Agentic Mermaid should render Mermaid-compatible `gantt` diagrams to SVG, PNG, ASCII, Unicode text, and layout JSON without breaking the agent safety contract:

- existing Mermaid Gantt source should parse or fail with a named, structured error;
- source that parses but uses syntax outside the first render subset should round-trip byte-for-byte through the agent API;
- renderers must be deterministic unless the caller explicitly supplies a clock value;
- unsupported Mermaid proposals must be called out rather than approximated.

The first implementation ships **typed mutation via `asGantt`**, using the segment-preserving structured body pattern established for sequence diagrams (`src/agent/sequence-body.ts`): typed ops cover the modeled statements (title, sections, tasks), while calendar directives, comments, click/link statements, and markers ride along verbatim as opaque segments — never dropped, never requiring a full-fidelity IR. Typed mutation is the enforced default for every registered family (`every registered renderable family ships typed mutation (default-by-default enforcement)` in `src/__tests__/agent-doc-sync.test.ts`; see `docs/contributing/adding-diagram-types.md` §7), so a source-level-only registration does not pass CI.

## Evidence base

### Mermaid core discussions

Mermaid core has the syntax authority. The current docs and grammar define the accepted language:

- [Mermaid Gantt syntax docs](https://mermaid.js.org/syntax/gantt.html)
- [`gantt.md` docs source](https://github.com/mermaid-js/mermaid/blob/develop/packages/mermaid/src/docs/syntax/gantt.md)
- [`gantt.jison` grammar](https://github.com/mermaid-js/mermaid/blob/develop/packages/mermaid/src/diagrams/gantt/parser/gantt.jison)
- Gantt implementation directory: [`packages/mermaid/src/diagrams/gantt`](https://github.com/mermaid-js/mermaid/tree/develop/packages/mermaid/src/diagrams/gantt)

Recurring user pressure in Mermaid core:

| Theme | Discussions | Requirement pulled into this spec |
|---|---|---|
| Task dependency math | [#818](https://github.com/mermaid-js/mermaid/issues/818), [#7407](https://github.com/mermaid-js/mermaid/issues/7407), [#7714](https://github.com/mermaid-js/mermaid/issues/7714), [PR #5224](https://github.com/mermaid-js/mermaid/pull/5224), [PR #6376](https://github.com/mermaid-js/mermaid/pull/6376), [PR #7409](https://github.com/mermaid-js/mermaid/pull/7409) | Parse `after` and `until` as first-class dependency expressions. Resolve them in a scheduler layer, not inside the renderer. |
| Calendars, weekends, excludes | [#2424](https://github.com/mermaid-js/mermaid/issues/2424), [#5867](https://github.com/mermaid-js/mermaid/issues/5867), [#6884](https://github.com/mermaid-js/mermaid/issues/6884), [#7062](https://github.com/mermaid-js/mermaid/issues/7062), [#6421](https://github.com/mermaid-js/mermaid/issues/6421), [PR #5358](https://github.com/mermaid-js/mermaid/pull/5358), [PR #6734](https://github.com/mermaid-js/mermaid/pull/6734), [PR #7038](https://github.com/mermaid-js/mermaid/pull/7038), [PR #7772](https://github.com/mermaid-js/mermaid/pull/7772) | Calendar rules are semantic input. Multiple `excludes`/`includes`, `weekend`, and `weekday` must be parsed before durations are resolved. |
| Working-day hours | [#4060](https://github.com/mermaid-js/mermaid/issues/4060), [PR #7733](https://github.com/mermaid-js/mermaid/pull/7733), closed attempts [PR #5403](https://github.com/mermaid-js/mermaid/pull/5403) and [PR #6149](https://github.com/mermaid-js/mermaid/pull/6149) | Do not invent work-hour syntax. Support only after Mermaid core stabilizes it. Keep the calendar engine injectable enough to add it later. |
| Layout/readability | [#3794](https://github.com/mermaid-js/mermaid/issues/3794), [#5140](https://github.com/mermaid-js/mermaid/issues/5140), [#7602](https://github.com/mermaid-js/mermaid/issues/7602), [#7603](https://github.com/mermaid-js/mermaid/issues/7603), [#6260](https://github.com/mermaid-js/mermaid/issues/6260), [PR #7284](https://github.com/mermaid-js/mermaid/pull/7284) | Labels, ticks, compact rows, top axis, and `vert` markers need explicit layout tests. `vert` markers must not allocate a task row. |
| Styling and theme scaling | [#3020](https://github.com/mermaid-js/mermaid/issues/3020), [#5915](https://github.com/mermaid-js/mermaid/issues/5915), [#7471](https://github.com/mermaid-js/mermaid/issues/7471), [#5710](https://github.com/mermaid-js/mermaid/issues/5710), [PR #7432](https://github.com/mermaid-js/mermaid/pull/7432), [PR #7456](https://github.com/mermaid-js/mermaid/pull/7456), [PR #7498](https://github.com/mermaid-js/mermaid/pull/7498), [PR #7537](https://github.com/mermaid-js/mermaid/pull/7537) | Bar colors, task text contrast, and font-size scaling are part of renderer behavior. Resolved Style typography must resize rows and bars, not only text. |
| Syntax/documentation drift | [#2848](https://github.com/mermaid-js/mermaid/issues/2848), [#5655](https://github.com/mermaid-js/mermaid/issues/5655), [PR #5194](https://github.com/mermaid-js/mermaid/pull/5194), [PR #5192](https://github.com/mermaid-js/mermaid/pull/5192), [PR #7443](https://github.com/mermaid-js/mermaid/pull/7443), [PR #5095](https://github.com/mermaid-js/mermaid/pull/5095) | Treat docs examples as fixtures. Document duration tokens. Allow `#` and `;` where Mermaid now allows them. |
| Interactivity and security | [#771](https://github.com/mermaid-js/mermaid/issues/771), [#2152](https://github.com/mermaid-js/mermaid/issues/2152), [#2077](https://github.com/mermaid-js/mermaid/issues/2077) | Parse click/link lines. Never execute callbacks. Sanitize links under the existing strict-security model. |

### Beautiful Mermaid and Agentic Mermaid forks

- [`lukilabs/beautiful-mermaid#59`](https://github.com/lukilabs/beautiful-mermaid/issues/59) requests “All Mermaid v11 diagrams” and includes a concrete Gantt sample with `interactive: true`.
- [`lukilabs/beautiful-mermaid` `phase1-charts`](https://github.com/lukilabs/beautiful-mermaid/tree/phase1-charts) contains branch-only Gantt code (paths on that upstream branch): `src/gantt/parser.ts`, `src/gantt/layout.ts`, `src/gantt/renderer.ts`, `src/ascii/gantt.ts`, and `src/__tests__/gantt.test.ts`. It is useful prior art, but it predates Agentic Mermaid’s current source normalization, strict-security pass, agent surface, golden fixtures, and deterministic-output requirements.
- Agentic Mermaid implemented Gantt on the family-descriptor, structured-or-opaque, quality-adapter, and registry contracts established by earlier work. Historical sequencing is preserved in Git history and the PR #149 archive.

### Mermaid ASCII and terminal-renderer forks

- `AlexanderGrooff/mermaid-ascii` has no native Gantt support found in upstream issues, PRs, or code.
- [`pgavlin/mermaid-ascii`](https://github.com/pgavlin/mermaid-ascii) adds Gantt in Go under `pkg/gantt/`. Its README claims support for 22 diagram types and lists `gantt`; the implementation renders fixed-width horizontal bars, section headers, date markers, status glyphs, `after`, and durations.
- [`Chronostasys/mermaid-ascii`](https://github.com/Chronostasys/mermaid-ascii) inherits the pgavlin Gantt code and layers CJK/Unicode alignment fixes elsewhere.
- [`kais-radwan/ascii-mermaid`](https://github.com/kais-radwan/ascii-mermaid) and [`razor-ai/ascii-mermaid`](https://github.com/razor-ai/ascii-mermaid) implement a TypeScript Gantt ASCII renderer for Neovim virtual text. They support sections, bars, `after`, `done`/`active`/`crit`/`milestone`, and tests. They parse `excludes` but do not apply it to date arithmetic.

These terminal renderers converge on the same useful display shape: a left label column, section rows, a fixed-width timeline plot, and status-specific glyphs. Agentic Mermaid should keep that shape but use the current ASCII infrastructure: Unicode-width handling, `useAscii`, color modes, golden fixtures, and deterministic wrapping.

### Libraries already in this repo

`mermaid-ast@0.8.2` exposes `parseGantt`, `GanttAST`, and `renderGantt`. It models title, `dateFormat`, `axisFormat`, `tickInterval`, `inclusiveEndDates`, `topAxis`, `excludes`, `includes`, `todayMarker`, `weekday`, `weekend`, sections, tasks, click events, and accessibility. It is not a layout engine and keeps task data shallow, but it is a useful compatibility oracle and source-preservation aid.

## Compatibility target

Target Mermaid Gantt syntax as documented on Mermaid `develop` on 2026-06-11. Host renderers such as GitHub, GitLab, Obsidian, and Markdown plugins pin different Mermaid versions; Agentic Mermaid should not claim host parity. It should claim a pinned Mermaid-core syntax target; Gantt syntax support is exposed in `am capabilities --json`.

The renderer must accept Mermaid source wrappers already supported by Agentic Mermaid:

- YAML frontmatter;
- `%%{init: ...}%%` and `%%{initialize: ...}%%` directives;
- Mermaid comments before the header;
- `accTitle:` and `accDescr:` inline or block directives.

A trailing `%% comment` ends a header or keyword statement (`dateFormat`, `axisFormat`, `excludes`, …), as in Mermaid. On a task line Mermaid folds it into the task data; see BUG-34 in [#363](https://github.com/adewale/agentic-mermaid/issues/363).

## First-release syntax matrix

Legend: “parse” means recognized and preserved by the family parser. “render” means it affects SVG/ASCII output in the first Gantt release. “preserve” means source-level round-trip keeps the text even when the renderer ignores the semantic effect.

| Syntax / behavior | First release | Notes |
|---|---|---|
| `gantt` header | parse + render | Add `gantt` to registered `FamilyId` detection, CLI/MCP capabilities, docs, gallery, and editor examples. |
| `title ...` | parse + render | Also included in label extraction and accessibility summary. |
| `accTitle`, `accDescr` | parse + render | Use existing SVG accessibility injection. Do not duplicate family-owned ARIA. |
| `dateFormat ...` | parse + render | Required for date parsing. Default is `YYYY-MM-DD`; test the docs claim behind [#5655](https://github.com/mermaid-js/mermaid/issues/5655). |
| `axisFormat ...` | parse + render | SVG and ASCII may format differently when terminal space is constrained; both must use the same resolved tick instants. |
| `tickInterval ...` | parse + render, bounded | Must validate interval count before generating ticks. Regression source: [PR #7197](https://github.com/mermaid-js/mermaid/pull/7197). |
| `inclusiveEndDates` | parse + render | Apply at scheduling boundary, not by stretching bars in renderer code. |
| `topAxis` | parse + render in SVG; parse + preserve in ASCII | SVG should draw top axis. ASCII may choose a single top/bottom axis according to width, but must document the choice. |
| `excludes ...` | parse + render | Support multiple lines per [PR #7772](https://github.com/mermaid-js/mermaid/pull/7772). Accept weekdays, `weekends`, and explicit dates. Do not support date ranges until Mermaid core does. Excluded days shade the plot by default (see [Excluded-day shading and the boundary model](#excluded-day-shading-and-the-boundary-model)). |
| `includes ...` | parse + render | Multiple lines. Includes override excludes for explicitly listed dates. |
| `weekend friday|saturday` | parse + render | Mirrors [PR #5358](https://github.com/mermaid-js/mermaid/pull/5358). |
| `weekday <day>` | parse + render for weekly tick alignment | Do not let tick alignment affect task duration. |
| `todayMarker ...` / `todayMarker off` | parse + render only with supplied clock | Agentic Mermaid must not read wall-clock time by default. Draw the marker only when the caller passes `ganttToday` (library/MCP) or `am render --gantt-today <DATE>` (CLI); `off` always disables it. The directive's style payload applies to the today line: `stroke`, `stroke-width`, `opacity`, and `stroke-dasharray` are sanitized (quadrant `COLOR_RE` value policy — no quotes/semicolons/colons can reach the style attribute) and wired; any other property in the payload is named by verify's Tier-3 `INEFFECTIVE_CONFIG` lint as `todayMarker.<prop>` (src/gantt/today-marker.ts is the single wire/sanitize table). |
| `section ...` | parse + render | Section labels get their own row/band. Multiline HTML section labels are preserved; first release may render them as plain text with `<br>` normalized to a line break only if the renderer can size the row. See [#7602](https://github.com/mermaid-js/mermaid/issues/7602). |
| Task row: `Label : metadata` | parse + render | Preserve label text exactly enough for round-trip; render plain text after sanitization. In the SVG label column, labels wider than the `GANTT_LABEL_WRAP_BUDGET` (220px) wrap via the shared `src/shared/label-wrap.ts` machinery (the journey extraction — no fourth wrap fork); row height becomes label-aware; labels at or under the budget render byte-identically. Section headers wrap into the same budget. Compact mode is exempt (its task labels sit beside bars in the plot, not in the column). |
| Task ids | parse + render | IDs are used by `after`, `until`, and `click`. Duplicate IDs are a structured parse error. |
| Status tags `done`, `active`, `crit` | parse + render | SVG classes and ASCII glyphs must distinguish states. Text contrast is tested in light/dark themes. Milestones carry the same status classes (`gantt-milestone-done` / `-active` / `-crit`) mirroring the bar convention; the done/active rules are emitted only when such milestones exist so other charts stay byte-identical. |
| `milestone` | parse + render | Render as diamond/marker, zero-width task. |
| `vert` marker | parse + render | Render vertical marker without consuming a task row, per [PR #7284](https://github.com/mermaid-js/mermaid/pull/7284). |
| `after <id...>` | parse + render | Multiple IDs resolve to the latest referenced end date, matching Mermaid docs. Unknown IDs are structured errors, not silent fallbacks. |
| `until <date|id...>` | parse + render | Match Mermaid’s current semantics with differential fixtures. Duration + `until` backward scheduling is accepted only after Mermaid core merges stable syntax; track [#7407](https://github.com/mermaid-js/mermaid/issues/7407), [#7714](https://github.com/mermaid-js/mermaid/issues/7714), [PR #7409](https://github.com/mermaid-js/mermaid/pull/7409). |
| Duration tokens | parse + render | Support the documented Mermaid token set from [PR #7443](https://github.com/mermaid-js/mermaid/pull/7443): `ms`, `s`, `m`, `h`, `d`, `w`, `M`, `y`, including decimals where Mermaid accepts them. Invalid duration tokens are parse errors; see [#6586](https://github.com/mermaid-js/mermaid/issues/6586). |
| `click <id> href ...` | parse + sanitized render | Strict mode strips unsafe external refs as today. Loose mode may emit safe links if the existing renderer policy allows it. |
| `click <id> call ...` | parse + preserve only | Never execute JavaScript callbacks in Agentic Mermaid. No callback output in strict mode. |
| Frontmatter `config.gantt` / top-level Gantt config | parse + render where supported | `displayMode`, `barHeight`, `topAxis`, `axisFormat`, and `tickInterval` are wired (`resolveGanttFrontmatterConfig` in `src/gantt/parser.ts`). The other documented keys are accepted but inert and named by `INEFFECTIVE_CONFIG`; the list is the gantt descriptor's `config.noopKeys` in `src/agent/families.ts`. The `todayMarker` *directive* is wired separately (row above). |
| `displayMode: compact` | parse + SVG render; ASCII best effort | Compact layout uses deterministic interval packing inside each section. It must not overlap labels, bars, or ticks. See [#7603](https://github.com/mermaid-js/mermaid/issues/7603). |
| Comments and `#`/`;` in titles/task text | parse + preserve + render text | Mermaid changed parser behavior in [PR #5095](https://github.com/mermaid-js/mermaid/pull/5095). Fixtures must cover this. |

## Not supported in the first release

These are deliberate boundaries, not hidden gaps:

- **No typed ops for directives, click events, markers, or comments.** `asGantt` exposes ops on sections and tasks only (`set_title`, `add_section`/`rename_section`/`remove_section`/`move_section`, `add_task` with an optional insert `index`, `remove_task`/`rename_task`/`move_task`, `set_task_status`, `set_task_flags`, `set_task_dates`, `set_task_id`). `dateFormat`, `excludes`/`includes`, `weekend`/`weekday`, `todayMarker`, `click`, and comment lines are preserved verbatim as opaque segments and are edited at the source level. Promoting any of them to typed ops is future work gated on the scheduler being able to re-resolve them. The ordering and identity ops carry two prescriptive contracts:
  1. **Source order IS scheduling semantics.** A task with an implicit start (end only, no start expression) begins when the previous task in flat source order ends — across section boundaries. `move_task` and `move_section` therefore REJECT, with the fix named in the error, any move that would change an implicit-start task's predecessor, instead of silently rescheduling it; the caller materializes an explicit start first (`set_task_dates` with the resolved date from `describe`/`analyze`, or an `after` dependency) and retries. `add_task` with an insert `index` is the deliberate exception: inserting into a chain re-chains the follower onto the new task, which is the point of a mid-chain insert and is visible in the source diff.
  2. **`set_task_id` keeps references coherent by construction.** A rename REWRITES every structured `after`/`until` reference to the old id, so the dependency graph never dangles. It REJECTS while the id is referenced from opaque segments (click lines, unmodeled task lines) because typed ops never rewrite opaque source — those lines are edited at the source level first. `taskId: null` (clearing the id) REJECTS while ANY reference exists, listing the referents, because there is nothing to retarget them to.
- **No JavaScript callback execution.** `click id call fn(args)` is parsed and preserved; it is not executed or emitted as executable script.
- **No non-Mermaid proposed syntax.** This excludes date ranges in `excludes` ([#2424](https://github.com/mermaid-js/mermaid/issues/2424)), custom task states ([#3539](https://github.com/mermaid-js/mermaid/issues/3539)), relative symbolic dates such as `m1` ([#2850](https://github.com/mermaid-js/mermaid/issues/2850)), dynamic `now` / `getdate` task values ([#3532](https://github.com/mermaid-js/mermaid/issues/3532)), and vertical Gantt charts ([#6773](https://github.com/mermaid-js/mermaid/issues/6773)).
- **No dependency-arrow syntax.** Users have asked for arrows in [#7300](https://github.com/mermaid-js/mermaid/issues/7300) and vertical dependency lines in [#3290](https://github.com/mermaid-js/mermaid/issues/3290). The visual overlay shipped as an opt-in RENDER OPTION — see [Dependency arrows and critical-path overlay](#dependency-arrows-and-critical-path-overlay-render-option) below — and Mermaid source stays untouched: no new syntax, and default output is byte-identical to a renderer without the feature.
- **No WBS/subtask syntax.** Subtasks and work-breakdown hierarchies are requested in [#3295](https://github.com/mermaid-js/mermaid/issues/3295) and [#6449](https://github.com/mermaid-js/mermaid/issues/6449). Do not invent syntax.
- **No work-hour calendar syntax until Mermaid stabilizes it.** Track [#4060](https://github.com/mermaid-js/mermaid/issues/4060) and [PR #7733](https://github.com/mermaid-js/mermaid/pull/7733).
- **No BC/inverted time axis in first release.** Track [#4437](https://github.com/mermaid-js/mermaid/issues/4437).
- **No host-specific fallback behavior.** If GitHub’s pinned Mermaid version lacks a feature, Agentic Mermaid may still support it if the pinned syntax target does.

## Dependency arrows and critical-path overlay (render option)

Shipped (family-elevation-plan §Gantt item 1): the dependency visuals requested upstream in [#7300](https://github.com/mermaid-js/mermaid/issues/7300), [#3290](https://github.com/mermaid-js/mermaid/issues/3290), and [#818](https://github.com/mermaid-js/mermaid/issues/818) are render options on the SVG path, sourced entirely from the scheduler's existing dependency graph and `GanttScheduleAnalysis` — never new Mermaid syntax:

```ts
render(source, { gantt: { dependencyArrows: true, criticalPath: true } })
```

- **`dependencyArrows`** (default `false`) draws one deterministic orthogonal elbow connector per `after`/`until` reference, from the predecessor bar's end to the successor bar's start (`after` edges point ref → task; `until` edges point task → referenced start). Routing lives in `src/gantt/layout.ts` (`GanttLayoutResult.dependencies`), never in the renderer: horizontal runs travel in row gutters (bar-free by construction) or as short stubs beside the two anchored bars; vertical runs cross a row band only at an x proven clear of every bar interior, jogging inside the preceding gutter — the corridor just left of the plot (`plot.x - GANTT_DEP_STUB`, inside the label column's `labelGap` margin, so labels stay clear in standard mode) is always available. Milestones anchor at the diamond's bounding box/tips. Connectors are quieter than bars (the journey curve's restraint), carry `data-from`/`data-to` task identity, and terminate in arrowheads whose marker ids are content-hashed (the journey id-namespacing pattern) and respond to `idPrefix`.
- **`criticalPath`** (default `false`) applies a stronger theme-aware stroke (`gantt-bar-critical-path`) to the bars and milestones on `GanttScheduleAnalysis.criticalPathTaskIds`, and — combined with `dependencyArrows` — emphasizes the binding connectors along the path (`gantt-dep-arrow-crit`: an `after` edge between two critical tasks where the successor starts exactly at the predecessor's end). Never a hard-coded red (the Google-Charts lesson from the research doc), and never inferred: no `after` dependencies means no analysis and no emphasis.

Hard gates, honoring [`gantt-research.md`](./gantt-research.md)'s caveat that dependency arrows ship only with overlap tests (`src/__tests__/gantt-dependency-overlay.test.ts`, including a fast-check property over generated schedules):

1. connector endpoints touch exactly their two bars;
2. connectors never overlap any bar's interior rect — a route that would is unrepresentable in the output (the router validates the final polyline and skips the connector rather than draw a violation);
3. with the options off (the default), SVG output is byte-identical to previous releases — the representative golden and an explicit options-off equality test pin this.

Known limits: in `displayMode: compact`, task labels sit beside bars inside the plot, and connectors may cross those labels (never bars). `vert` tasks render as markers, not bars, so edges touching them draw no connector. ASCII output carries no dependency notation — the line grid has no opt-in channel and an always-on annotation would change every existing golden; the per-task date gutter plus `describe`'s dependency facts remain the terminal story.

## Excluded-day shading and the boundary model

Shipped 2026-07 (family-elevation-plan §Gantt items 2 and 6):

**Shading is default-on** (upstream parity: mermaid draws `exclude-range`
rects unconditionally, and the absence of shading read as a bug — upstream
#6421/#7062/#314). Correctness by construction: the bands derive from the
SAME `schedule.isExcludedDay` predicate the duration walk uses — one
calendar, two consumers — never a second calendar implementation. Bands
merge consecutive excluded days, clip to the visible range, appear only on
date-only charts with `excludes` (time-bearing `dateFormat`s and
exclude-free charts are byte-identical to previous releases, including
their CSS block), and always paint BEFORE grid lines and bars (z-order
invariant, gated in `src/__tests__/gantt-excluded-shading.test.ts`).

**The exclude-boundary divergence is RESOLVED by adopting upstream's
model.** `src/gantt/schedule.ts` now mirrors mermaid's `fixTaskDates` walk
exactly: excluded days are counted in `(start, end]` — the cursor starts
one day after the task start, so a task starting on an excluded day gets
that day free — and the `endTime`/`renderEndTime` split is mirrored as
`ScheduledGanttTask.end` (chain end: where `after` successors and
implicit-start followers begin) vs `.renderEnd` (drawn-bar end: trailing
excluded days extend the chain but never stretch the bar; always within
`[start, end]`). Bars, milestones, ASCII tracks, and the date gutter draw
`renderEnd`; dependency chaining, critical-path analysis, and `describe`
use `end`. The axis range covers drawn extents, not phantom trailing
exclusions. The former `exclude-boundary-model` ledger entries
(`eval/mermaid-gantt-bench/exclusions.json` e3/e4) are now executed parity
cases (`db-weekends-mega`, `db-exclude-all-but-friday` in `cases.json`),
pinning all seven chain instants of upstream's "should ignore weekends"
spec; `src/__tests__/gantt-exclusion-boundary.test.ts` pins the
`renderEnd` split.

Evidence: `gantt-completion-before.png` / `gantt-completion-after.png`
(source `gantt-completion-demo.mmd`) — weekend shading, the styled today
marker, a wrapped 65-char label, and status-styled milestones in one chart.

## Architecture

Gantt shipped as a five-stage family pipeline. The stage notes below record
the design as built and point at the files that now own each stage.

### 1. Routing and family registration

As shipped:

- `src/agent/families.ts`: the `gantt` metadata row (headers, `asGantt`, config contract).
- `src/agent/families-builtin.ts`: agent hooks over `src/agent/gantt-body.ts` (`parseGanttBody`, `renderGantt`, `mutateGantt`, `verifyGantt`).
- `src/render-family-hooks.ts`: SVG (`src/gantt/pipeline.ts`, `src/gantt/renderer.ts`) and ASCII/Unicode (`src/ascii/gantt.ts`) render hooks.
- `src/agent/family-layouts.ts`: `projectGanttPositioned` projects Gantt geometry for `measureQuality`, `checkQuality`, `verify.layout`, and layout-compare.
- Capability docs (MCP, CLI, `Instructions_for_agents.md`, `llms.txt`, skills) stay synced through the doc-sync tests.

The `FamilyDescriptor` registers with `mutate` and `serialize` hooks from the start (the enforcement test fails CI otherwise): detect, label extraction, and a segment-preserving structured body whose serialization re-emits opaque segments verbatim. Unmodeled or unparseable bodies fall back whole-opaque, preserving source byte-for-byte.

### 2. Syntax parser

Shipped as `src/gantt/parser.ts` and `src/gantt/types.ts`.

The parser should produce two related values:

- `GanttAst`: source-faithful syntax representation with raw text spans for directives, sections, tasks, markers, click events, and unknown-but-preserved lines where Mermaid accepts them.
- `GanttSemanticModel`: normalized values needed for scheduling and rendering: task IDs, status tags, dependency expressions, date/duration expressions, calendar directives, display options, accessibility text.

Use `mermaid-ast` as an oracle, not as the only implementation boundary. It can help detect syntax drift and preserve source, but Agentic Mermaid still needs its own resolver, validation, layout, SVG, ASCII, and security behavior.

Parser rules:

- never silently drop a line;
- duplicate task IDs are errors;
- references to unknown task IDs are errors in render mode;
- invalid dates/durations are errors with line/column where possible;
- labels are text, not HTML execution targets;
- task labels may contain words such as `gantt`, `section`, `title`, `#`, and `;` when Mermaid grammar allows them.

### 3. Calendar and dependency resolver

Shipped as `src/gantt/schedule.ts`.

Do not let renderers compute dates. Renderers receive resolved task intervals and markers.

Core types:

```ts
interface GanttCalendar {
  dateFormat: string
  inclusiveEndDates: boolean
  excludes: CalendarExclusion[]
  includes: CalendarInclusion[]
  weekendStart: 'friday' | 'saturday'
  weekStart: 'sunday' | 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday'
}

interface GanttClock {
  today?: PlainDateLike
}
```

The resolver should avoid JavaScript wall-clock APIs. Use date-only values for date-only diagrams and explicit time values for time-bearing diagrams. This avoids DST and timezone bugs like [#7026](https://github.com/mermaid-js/mermaid/issues/7026). If a future implementation uses `Date`, the zone must be fixed and tested.

Scheduling rules:

- source order remains the tie-breaker;
- `after id1 id2` starts after the latest resolved end among references;
- `until id` ends at the referenced task’s start;
- fixed end dates are respected unless a calendar directive says working-duration tasks should extend over excluded dates;
- `includes` overrides `excludes` for explicit dates;
- the resolver enforces a bounded tick count and bounded scheduling iteration count;
- any cycle in dependency expressions returns a structured error naming the cycle.

### 4. SVG layout and renderer

Shipped as:

- `src/gantt/layout.ts`
- `src/gantt/renderer.ts` (status colors live in its `ganttPalette`; no separate colors module was needed)

The `phase1-charts` branch is a starting point for the visual shape: left section/task columns, plot area, row lines, grid lines, bars, milestones, and optional hover overlays. Port the idea, not the code wholesale.

SVG requirements:

- deterministic output for the same source/options;
- no default wall-clock `todayMarker`;
- stable IDs namespaced through the existing `idPrefix` pass;
- strict security removes executable callbacks, unsafe hrefs, scripts, images, and external refs;
- Style + Palette rendering routes Gantt marks through the internal style face:
  task labels, bars, grid lines, markers, and section bands should respond to named styles and palette stacks;
- status classes: `gantt-bar`, `gantt-bar-done`, `gantt-bar-active`, `gantt-bar-crit`, `gantt-milestone`, `gantt-milestone-done`, `gantt-milestone-active`, `gantt-milestone-crit`, `gantt-vert-marker`, `gantt-excluded-band`;
- text contrast tests for status bars in light and dark themes;
- `displayMode: compact` uses deterministic interval packing and has a fixture where dense rows would overlap under naive spacing.

### 5. ASCII and Unicode renderer

Shipped as `src/ascii/gantt.ts` on the shared Agentic Mermaid ASCII infrastructure.

The terminal shape should combine the pgavlin and kais-radwan patterns:

```text
                    Project Plan
  Planning
    Requirements  ███████──────────────  01-01 → 01-14
    Design        ───────████████──────  01-15 → 02-04
  Development
    Backend       ─────────────████████  02-05 → 03-06
              ─────────────────────────
              Jan 1      Jan 15     Feb 1
```

ASCII/Unicode requirements:

- respect `useAscii`;
- preserve CJK/emoji display width when sizing the label column;
- use deterministic axis ticks from the same layout model as SVG;
- distinguish `done`, `active`, `crit`, `milestone`, and `vert` with glyphs that degrade in 7-bit ASCII;
- keep labels outside bars by default; terminal bars should not hide task names;
- support `maxWidth` by shrinking plot width before truncating labels;
- produce golden files under `src/__tests__/testdata/{ascii,unicode}/`.

## Verification and accessibility

Gantt verification should start source-level and structural:

- `EMPTY_DIAGRAM`: no renderable tasks or markers;
- `LABEL_OVERFLOW`: title, section names, task labels, axis labels, marker labels;
- `EDGE_MISANCHORED`: dependency/click reference points at an unknown task ID;
- `OFF_CANVAS`: resolved bars or markers outside plot bounds;
- `GROUP_BREACH`: section-owned rows outside the section band;
- `DUPLICATE_EDGE` is not relevant: dependency connectors are an opt-in render overlay (see [Dependency arrows](#dependency-arrows-and-critical-path-overlay-render-option)), not layout edges;
- `UNREACHABLE_NODE` is not relevant to Gantt.

`describeMermaid(..., {format:'json'})` should expose an AX tree with:

- chart title and date range;
- sections as groups;
- tasks with label, status, start, end, duration, dependencies;
- milestones and vertical markers;
- entry tasks with no dependencies;
- sinks/tasks that no later task depends on.

This AX tree is the non-visual fallback for terminal users and agent review.

## Testing strategy

Use the `testing-best-practices` approach: public contracts first, real parser/layout objects over mocks, golden fixtures for complex text/SVG output, property tests for scheduler invariants, and targeted mutation runs for the date resolver.

### Test tiers

| Tier | Files | Required coverage |
|---|---|---|
| Parser unit tests | `src/__tests__/gantt-parser.test.ts` | Mermaid docs examples; malformed headers; duplicate IDs; task labels with `#`, `;`, `gantt`; click/href/call; multiple excludes/includes; unsupported proposed syntax errors. |
| Scheduler property tests | `src/__tests__/property-gantt-schedule.test.ts` | No crashes for generated valid task DAGs; `after` starts after refs; cycle detection; excludes extend working-duration tasks but never shrink them; includes override excludes; tick generation bounded. |
| Layout tests | `src/__tests__/gantt-layout.test.ts` | Bars stay in plot area; labels stay in label column; compact rows do not overlap; `vert` consumes no row; `topAxis` geometry. |
| SVG integration/snapshots | `src/__tests__/gantt-svg-snapshot.test.ts` | Deterministic SVG; accessibility IDs; strict security; status classes; theme contrast; supplied-clock today marker. |
| ASCII/Unicode golden tests | existing `ascii.test.ts` fixture flow | Basic project, sections, dependencies, excludes, milestone, vert marker, compact dense chart, CJK labels, 7-bit ASCII. |
| Agent surface tests | `src/__tests__/agent-gantt.test.ts` | `parseRegisteredMermaid` detects `kind:'gantt'`; serialize preserves opaque segments verbatim and is serialize-idempotent for structured bodies; `capabilities` reports structured mutation with the `asGantt` op list; each op round-trips through `am mutate`; fast-check round-trip property; label overflow works. |
| Corpus/differential tests | Mermaid docs corpus + `mermaid-ast`/Mermaid-core oracle | Docs examples parse; supported examples render; parse/render decisions match the pinned compatibility target. |
| E2E/editor tests | browser/editor suite | Gallery/editor can load a Gantt example, export SVG/PNG, and show ASCII. |

### Golden fixture policy

Use the existing promote/check workflow from `scripts/update-ascii-goldens.ts`:

- add the Mermaid source and expected output in the same fixture file;
- regenerate with `bun run goldens:ascii`;
- review the diff before commit;
- gate with `bun test src/__tests__/ascii.test.ts`.

Snapshot/golden files must not contain wall-clock dates. Fixtures that test `todayMarker` pass an explicit date through render options.

### Property invariants

Scheduler properties should use finite generated DAGs, not arbitrary line strings only:

- every resolved task has finite start/end;
- non-milestone tasks have positive visual width after layout;
- a task with `after refs` starts at or after the latest referenced end;
- a task with fixed duration has the same working-duration count after excludes/includes are applied;
- adding an excluded non-working day inside a working-duration task cannot make the task end earlier;
- changing `axisFormat` cannot change task geometry;
- increasing font size changes row metrics but not resolved dates;
- generated tick count stays under a fixed cap.

## Historical rollout sequence (completed)

This is the order in which the shipped surface was assembled, not a current
implementation plan:

1. **Gantt detection and agent surface.** Landed the `gantt` kind, descriptor
   registration with mutate/serialize hooks, label extraction, docs, tests, and
   a segment-preserving body parser.
2. **Parser + scheduler with docs fixtures.** Landed the syntax parser,
   deterministic resolver, and compatibility fixtures.
3. **ASCII renderer + goldens.** Landed terminal output and reviewable goldens.
4. **SVG renderer + PNG path.** Landed role styling, accessibility,
   strict-security handling, status classes, and snapshots.
5. **Quality/layout adapter.** Landed the Gantt layout projection (now
   `projectGanttPositioned` in `src/agent/family-layouts.ts`) and
   layout-compare fixtures.
6. **Editor/showcase/docs.** Landed the examples and product-surface coverage.
7. **Release notes and capability sync.** Landed capability documentation and
   registry/doc-sync coverage.

## Candidate improvements retained as evidence

The wider literature and commercial-product survey lives in
[`gantt-research.md`](./gantt-research.md). The points below are design evidence
and compatibility boundaries, not scheduled follow-up work. Any implementation
requires a stable owner in root `TODO.md`.

- Scheduling purity remains an as-built constraint: `src/gantt/schedule.ts` owns
  date, dependency, calendar, critical-path, and slack computation without
  DOM/SVG/canvas or ambient wall-clock calls.
- Additional analysis such as critical path, slack, schedule range, dependency
  cycles, and entry/sink tasks is candidate product evidence for `describe`,
  `verify`, optional overlays, or editor UI; it is not scheduled here.
- Resource, baseline, owner, workload, and uncertainty syntax remains outside
  the compatibility contract because Mermaid does not define portable source
  syntax for it.
- Overview/detail, zoom/filter, top-axis, compact-layout, bounded-tick, and
  stable-region work remains candidate large-schedule evidence.

The retained architectural direction is a clean internal dependency/calendar
model rather than new syntax; any expansion of `describe`, overlays, row
compaction, or editor details must first be promoted to root `TODO.md`.

## Empty plans

A syntactically valid plan with no tasks renders an explicit `No tasks scheduled` state in SVG and terminal output. Authored titles and section labels remain visible; no date ticks or task bars are invented. Verification retains its `EMPTY_DIAGRAM` diagnostic. The scheduler's zero extent is an empty sentinel, and layouts do not display it as a calendar date. Raw `themeCSS` remains rejected by strict security; use the declarative Style interface for supported appearance changes.
