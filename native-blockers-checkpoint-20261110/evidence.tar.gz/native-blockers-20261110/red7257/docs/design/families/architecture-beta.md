# Architecture Diagrams (`architecture-beta`) Design Notes

## Overview

Architecture support follows the same parse -> layout -> render split used by the other specialized diagram families, while intentionally reusing the shared graph layout engine for node and group placement.

Current scope covers:

- `group`, `service`, and `junction`
- side-anchored edges (`L`, `R`, `T`, `B`)
- compact or spaced edges (`api:R-->L:db` and `api:R --> L:db`), retaining
  side and `{group}` boundary semantics through canonical writing
- `{group}` boundary routing for services inside groups
- visible `title ...` header furniture, including title-only diagrams
- `align row|column` directives (upstream v11.16.0) — parsed, modeled,
  round-tripped losslessly, and honored as placement constraints
- multi-line labels via `<br>` / `\n`, and quoted physical lines that retain
  internal indentation and blank rows through parsing, typed edits and export
- SVG, PNG, and ASCII output (PNG via the shared SVG rasterization pipeline)

## Pipeline

### Parse

`src/architecture/parser.ts` builds a typed architecture model from Mermaid source and then converts it into the shared `MermaidGraph` shape for placement. The parser keeps Mermaid-oriented field names (`group`, `service`, `junction`, boundary anchors) and validates boundary edges up front so unsupported forms fail clearly.

### Layout

`src/architecture/layout.ts` starts from deterministic layered placement and then solves Architecture-specific constraints before geometry freezes:

- side declarations constrain the lowest-common-container sibling units; connected components move together and legal contradictory constraints remain renderable with `placement: 'conflicted'`;
- services and junctions expose the authored `L`/`R`/`T`/`B` anchors, including group-boundary endpoints;
- deterministic visibility-grid Dijkstra routing avoids every foreign service, junction, and group interior while minimizing length, then bends, with stable tie-breaking;
- each route carries a certificate separating placement from route validity: `placement`, `sourceFacesTarget`, `targetFacesSource`, and `obstacleFree`;
- group bounds and edge-label midpoints are recomputed from the final constrained geometry.

### Render

`src/architecture/renderer.ts` renders architecture-specific SVG primitives rather than generic flowchart boxes:

- visible diagram-title header furniture with an accessible-name fallback
- framed groups with header bands
- service cards with accent rails
- junction rings
- architecture-specific arrow markers and semantic `data-*` hooks
- native handcrafted icon paths plus the bounded offline curated registry in `src/architecture/icons.ts`; unknown names use an escaped fallback badge

## Align directives (upstream v11.16.0)

Upstream PR #7708 added `align row|column <id> <id> ...`: the listed
services/junctions share a row (same y) or column (same x), fed to fcose as
relative-placement constraints. The shipped contract here (plan §Architecture
item 2, option (b)):

- **One shape parser** — `src/architecture/align.ts` owns the directive's
  grammar (axis keyword, ≥2 members, no duplicate members) and canonical
  serialization. Both the strict render parser (`src/architecture/parser.ts`)
  and the structured agent body parser (`src/agent/architecture-body.ts`)
  consume it, so the surfaces cannot drift.
- **Upstream-parity validation** — members must be already-declared services
  or junctions (never groups); malformed directives are rejected by the render
  parser exactly where upstream rejects them. In the agent surface a malformed
  directive falls back to a lossless opaque body and verify reports the render
  failure.
- **Lossless round-trip** — alignments are modeled on `ArchitectureBody`
  (`alignments`), serialized after edges (declaration-before-use by
  construction), and survive serialize→re-parse byte-stably. `rename_service`
  rewrites members; `remove_service` drops the member and dissolves any
  directive left with fewer than two members (the edge-cascade idiom).
- **Deterministic geometry constraint** — after layered placement establishes
  stable source order, `src/architecture/layout.ts` gives row members one
  center-y or column members one center-x and packs them on the free axis with
  configured node spacing. This happens before group bounds and edge routes
  freeze, so containment and side anchors reflect the aligned geometry. Verify
  no longer emits `architecture_align`; geometry tests pin shared centers and
  sibling non-overlap.

Overlapping directives compose through complete fixed-axis components. Member
order remains in the source model for round-tripping; alignment itself requests
one shared center coordinate, not additional before/after constraints on the
free axis. Whole-component gap repair keeps every member visible without
breaking an intersecting row or column. Requests that force two distinct items
to share both centers fail explicitly instead of silently losing an alignment.

Backend selection includes the complete Architecture family geometry and its
final alignment/header admission. Only an explicitly requested ELK fallback can
replace a known Native candidate refusal; unexpected provider defects propagate.
The terminal adapter preserves the same fixed-axis components within half a cell
of integer-box parity. If text or marker clearance requires more room, bounded
spacing reprojection happens before its single paint/certification pass. Existing
width, allocation, certification and output limits still apply.

## Runtime config (wire-or-warn, plan §Architecture item 3 / X7)

`src/architecture/config.ts` wires the documented `architecture.*` keys; the
lint list is registry-owned (below):

| Key | Status | Mapping |
|---|---|---|
| `padding`, `iconSize`, `fontSize` | wired | visual metrics (pre-existing) |
| `nodeSeparation` | wired | same-layer sibling spacing in px (`RenderOptions.nodeSpacing` fallback — the class/er `nodeSpacing` pass-through idiom; explicit RenderOptions win) |
| `idealEdgeLengthMultiplier` | wired | layer gap scaled around upstream's `1.5` default: `round(56 × m / 1.5)` — upstream defines it as ideal same-group edge length, and the layer gap is the deterministic edge length between connected ranks |
| <!-- BEGIN GENERATED: noop-keys:architecture -->`edgeElasticity`, `numIter`, `randomize`, `seed`<!-- END GENERATED: noop-keys:architecture --> | lint | fcose force-simulation knobs with no meaning in a deterministic layout; each present key is named by verify's Tier-3 `INEFFECTIVE_CONFIG` (the architecture descriptor's `config.noopKeys` in `src/agent/families.ts`) |

`resolveArchitectureRenderOptions()` folds the wired keys into RenderOptions
and is consumed by BOTH the SVG render hook and verify's layout adapter
(`src/agent/family-layouts.ts`), so `verify.layout` stays truthful under
config. The typed section shape is `ArchitectureRuntimeConfig` in
`src/mermaid-source.ts`.

Consumed Architecture theme colors use the shared color-admission boundary:
`clusterBkg` (group fill and derived header color), `clusterBorder` (group
stroke), and `secondaryColor` (service fill only when `mainBkg` is absent).
Malformed authored values fail by name with `INVALID_THEME_COLOR` before SVG,
PNG, ASCII, CLI or MCP output. `clusterBkg:none` is invalid because the header
derives a `color-mix()` from it; `clusterBorder:none` and the direct
`secondaryColor:none` fill are allowed. Architecture also refuses `none` for
the shared `background`, `mainBkg`, `primaryColor`, `nodeBkg`, `lineColor`,
`defaultLinkColor`, and `arrowheadColor` channels: each can feed a derived
`color-mix()` paint when it is the selected source key for its channel and no
explicit render color overrides that channel.
Shadowed fallbacks may still use `none`; for example, `defaultLinkColor:none`
is ignored when `lineColor` is set. Shared border keys remain direct strokes
and may use `none`.

The same derived-paint rule applies to selected explicit Architecture render
colors: `bg`, `surface`, `line`, and `accent` cannot be `none` (including case
and surrounding-whitespace variants) when they feed `color-mix()` paints.
Resolved visual overrides can shadow a fallback: a concrete
`architecture.visual.edgeStroke` shadows `line` and `accent`, while a concrete
group surface or header can make `surface` a direct paint only. A selected
`edgeStroke:none` or `groupSurface:none` is refused when it feeds a mix.
The same resolved precedence applies to theme-variable fallbacks, including
`lineColor`, `arrowheadColor`, `nodeBkg`, and `clusterBkg`; an unused fallback
does not produce a false color error.
Direct `border:none` remains available. The rule is Architecture-only and
produces `INVALID_RENDER_COLOR` through graphical, terminal, CLI, and MCP
routes before output.

## Completed elevation contracts

- **Typed editing:** services, junctions, groups, group labels, accessibility,
  ordinary and `{group}` endpoints, moves, and in-place edge updates are all
  structured. Moving a service referenced by a group-boundary edge is refused
  unless the caller explicitly updates that boundary, so preserved semantics
  cannot become stale silently.
- **Offline icons:** `src/architecture/icons.ts` resolves curated MDI paths
  without network, filesystem, dynamic import, or raw SVG. Inputs are bounded
  by `ARCHITECTURE_ICON_LIMITS` (`maxIcons: 32`, `maxNameBytes: 128`,
  `maxPathBytes: 4096`), paths-only, sanitized, deterministic, and attributed
  in `THIRD_PARTY_NOTICES.md`. Native icon bytes remain unchanged.
- **Spatial terminal output:** `src/ascii/architecture.ts` projects services,
  junctions, nested groups, side/boundary routes, and labels onto a
  grapheme/display-cell canvas. Unicode and 7-bit modes share topology and
  honor the hard `targetWidth` contract.

Executable gates: `architecture-layout.test.ts`,
`architecture-integration.test.ts`, `agent-architecture.test.ts`,
`architecture-icons.test.ts`, and `architecture-ascii.test.ts`.

## Compatibility Notes

- A service may use a literal STRING icon: `service api "API" [Backend]`.
  `iconText` stores that text separately from the label and an icon-pack name.
  STRING escapes survive parsing and serialization; SVG/PNG paint literal
  escaped text with its full measured footprint, and terminal output retains
  it above the label. `add_service` accepts `iconText`, and
  `set_service_icon_text {id, text}` changes or clears it. Setting a named icon
  replaces text; authoring both forms together is refused. The pinned grammar
  permits text icons on services only.

- Both `architecture-beta` (Mermaid's current public header) and `architecture` are accepted — the family descriptor's `headers` in `src/agent/families.ts` and `parseArchitectureDiagram()` agree; structured serialization emits `architecture-beta`.
- Ids, icons and unquoted titles follow Mermaid's lexer terminals: an unquoted title allows only ASCII letters, digits, `_` and spaces, an icon only word characters, `-` and `:`, and an id may contain `-` only in the middle. Anything else (`[Public<br/>API]`, `[Edge-Layer]`, `[Café]`) must be quoted, and an unquoted form is rejected, as in Mermaid. The typed body stores Mermaid's reading of a title (`["API"]` is `API`) and writes it quoted when needed.
- Leading Mermaid comments (`%% ...`), YAML frontmatter, and Mermaid init directives before the header are stripped by the public SVG/PNG/ASCII/agent entrypoints before they call `parseArchitectureDiagram()`.
- The public architecture renderers interpret the merged wrapper config for a focused subset of Mermaid semantics:
  `theme`, `themeVariables`, `fontFamily`, `fontSize`, and `architecture.padding` / `architecture.iconSize` / `architecture.fontSize` /
  `architecture.nodeSeparation` / `architecture.idealEdgeLengthMultiplier` (see the wire-or-warn table above).
- `parseArchitectureDiagram()` expects preprocessed `architecture` / `architecture-beta` body lines; wrapper config is intentionally handled outside the parser because the parser returns only the diagram model.
