# GitGraph

## Contract

GitGraph is a first-class replayed-history family. `src/gitgraph/parser.ts` executes `commit`, `branch`, `checkout`/`switch`, `merge`, and `cherry-pick` statements in source order, so branch heads and parent relations are validated rather than merely tokenized. Repeated authored commit IDs retain separate, collision-free occurrence identities. The later occurrence stores its authored spelling in `sourceId`; rendering and canonical writing retain that label. Explicit duplicate merge IDs remain invalid.

A cherry-pick's source edge records which commit was copied; it does not make
that commit an ancestor of the receiving branch. The same merge can therefore
be picked relative to different immediate parents, as in the pinned Mermaid
test. Picking an actual ancestor inherited by the branch remains refused.

The imported upstream-spec corpus retains Mermaid commit `f3dea58385fd5c7dd1f4e9c9c1876751ae6943cc`; the current syntax target is recorded separately in [`upstream-mermaid-policy.json`](../../project/upstream-mermaid-policy.json). The checked oracle accounts for all 69 direct blocks in upstream `gitGraph.spec.ts`: portable/error blocks execute and five config-accessor blocks are source-inexpressible. Its historical repeated-cherry-pick divergence now passes; the current test checks both parent selections instead of freezing the old refusal. Duplicate commit declarations retain every occurrence. Unlike upstream random generated ids, omitted ids are deterministic `c<N>` values. The source-file hash, cases, and historical divergence rationale live in `eval/mermaid-upstream-suite-bench/mindmap-gitgraph-f3dea583.json`. The harvest added legacy `commit "message"`, multiline `accDescr`, and pinned mixed explicit/implicit branch-order compatibility. Current documentation parity additionally covers frontmatter titles, positive explicit branch orders, stable source-order tiebreaks, merge-parent cherry-picks, and 45° commit labels.

## Visual evidence

**Why:** at baseline commit `c7e33247`, `gitGraph` was not a registered family,
so the reproducible render command below failed instead of producing an
artifact. The after image is generated from [`gitgraph-demo.mmd`](./gitgraph-demo.mmd):

```bash
bun run bin/am.ts render docs/design/families/gitgraph-demo.mmd \
  --format png --output docs/design/families/gitgraph-after.png
```

![GitGraph rendered with branch and merge topology](./gitgraph-after.png)

The same authored fixture also renders in official Mermaid 11.16.0 and both Agentic output engines:

![GitGraph renderer comparison: official Mermaid, Agentic SVG, and Agentic Unicode](./gitgraph-renderer-comparison.png)

Regenerate the pinned upstream SVG, terminal text, and comparison sheet with:

```bash
bun run scripts/pr-assets/mindmap-gitgraph-comparison.ts
```

**What to inspect:** the separate release title; stable main/develop/release lanes; source-ordered ties; all eight replay-ordered commits; the merge's two parents; the cherry-pick's original and source parents; NORMAL/HIGHLIGHT/REVERSE marks; tags; rotated SVG labels; and semantic preservation under the 100-cell terminal bound. Pixel identity is not expected because the renderers use different layout and style engines. There is intentionally no fabricated “before” picture: the causal before
state was a named unsupported-family failure. Reproduce it in an isolated
baseline worktree (do not run this over the feature checkout):

```bash
git worktree add --detach /tmp/am-before c7e33247b7f152ada47000db3cd514c04cbcc00e
(cd /tmp/am-before && bun install --frozen-lockfile && \
  printf 'gitGraph\n  commit id:"base"\n' | bun run bin/am.ts render - \
    --format png --output /tmp/gitgraph-before.png)
git worktree remove --force /tmp/am-before
```

Expected result: exit 2 with `PARSE_FAILED` / `UNKNOWN_HEADER: Unrecognized
header: "gitGraph"`; no PNG is produced.

## Rendering and layout

`src/gitgraph/layout.ts` gives each branch a stable lane, places commits in replay order (or deterministic generation levels under `parallelCommits`), expands chronological slots from measured label/tag bounds, and materializes every first-parent, merge-parent, and cherry-pick relation. `src/gitgraph/renderer.ts` lowers colored branch rails, branch-tinted commit marks, relation polylines, commit types, contrast backplates, tag badges, and labels through Scene IR. Commit groups expose source-facing `data-id`; relations expose typed `data-from`/`data-to`. `src/ascii/gitgraph.ts` draws spatial branch rails and merge topology before painting commit marks so routes cannot erase identities.

Wired `gitGraph` config fields are `showBranches`, `showCommitLabel`, `mainBranchName`, `mainBranchOrder`, `parallelCommits`, and `rotateCommitLabel`. `mainBranchOrder` and authored `branch ... order:` values must be positive/zero as documented (`mainBranchOrder` may be zero; authored branch order must be positive). Unknown fields and invalid documented values produce named `INEFFECTIVE_CONFIG` diagnostics and have no effect. Frontmatter `title` is rendered as visible title text, independently of `accTitle`/`accDescr`.

## Real-content corpus

The popularity-weighted follow-up corpus adds seven scenarios derived from Mermaid docs/specs and issue/PR demand, with terminal priorities informed by Mermaid ASCII #74 and distribution/layout priorities from the highest-star Mermaid and Beautiful Mermaid forks: Gitflow release/hotfix, long labels/tags in TB, twelve ordered lanes, merge cherry-pick backports, Unicode/unusual branches in BT, transit-domain transfer, and CI/CD promotion.

![GitGraph real-content gallery](./gitgraph-content-gallery.png)

Sources, fork weights, structural expectations, and fixtures live in [`eval/mindmap-gitgraph-content-corpus`](../../../eval/mindmap-gitgraph-content-corpus/). `mindmap-gitgraph-content-corpus.test.ts` proves replay counts, branch/parent geometry, custom-main wrapper config, deterministic safe SVG, truthful public layout, and hard-width terminal output.

The historical/domain research behind these choices is recorded in [`gitgraph-research.md`](./gitgraph-research.md): commit DAG semantics and `git log --graph` are the foundation; metro maps are an official Mermaid analogy, not an origin claim.

## Typed editing

Use `asGitGraph`. Replay operations append commits, create/checkout branches, merge, and cherry-pick. Property operations set commit message/type/tags, rename a non-main branch, and edit accessibility title/description. Invalid replay state is rejected with a typed mutation error; history is never silently repaired. Cherry-pick validation walks the current head's complete ancestry: a commit inherited through branch creation or merge cannot be picked again. Parent relations are deduplicated, and length-prefixed/JSON-tuple semantic IDs remain injective even when authored IDs contain `->`, `:shape`, or `:label`. Semantic merge commits always retain `type: 'MERGE'`; an authored visual `type:` override is held separately as `customType`, and synthetic merge labels are not serialized as authored `msg:` text.

## Verification

`verifyMermaid` checks commit-label overflow, parent anchoring, and the real projected layout. The focused citizenship suite proves stable replay/serialization, deterministic generated ids, repeated-label occurrence preservation, duplicate merge-ID and invalid-state rejection, parent cardinality, branch-lane geometry, typed mutation, SVG identity/accessibility/security, terminal topology, and property-generated linear histories.

See `src/__tests__/mindmap-gitgraph-citizenship.test.ts`, grammar and identity in `src/__tests__/mindmap-gitgraph-grammar.test.ts`, and the exhaustive operation/replay contract in `src/__tests__/gitgraph-agent-ops.test.ts`. The recorded AlexanderGrooff/mermaid-ascii **1.4.0** fixture comparison exited 1 with `unsupported graph type 'gitGraph'`; this is a historical version-pinned result, not a current-latest replay. Its coverage request is [issue #74](https://github.com/AlexanderGrooff/mermaid-ascii/issues/74); no equivalent output is fabricated. See the [comparison's scope](../../comparison.md#mindmapgitgraph-and-the-terminal-ecosystem).

Repeated labels use public occurrence IDs for typed edits. Source references resolve to the latest preceding authored occurrence. A new cherry-pick targeting an earlier shadowed occurrence returns a prescriptive `INVALID_OP`: pinned source cannot express that selection unambiguously. Existing parent links remain attached to their resolved occurrence IDs.
