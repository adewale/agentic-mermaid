# Class Diagram — Design Notes

## Overview

The class family follows the standard parse → layout → render pipeline:
`src/class/parser.ts` → `src/class/layout.ts` (ELK layered) →
`src/class/renderer.ts` (SceneGraph lowering + DefaultBackend). The agent
surface owns a separate structured body (`src/agent/class-body.ts`) with the
structured-or-opaque contract: any line the body parser does not model makes
the whole body a lossless opaque round-trip.

Supported today:

- classes with the 3-compartment box (header / attributes / methods),
  annotations (`<<interface>>`), display labels (`class X["Label"]`,
  `class X as "Label"`), separate-decl members (`X : +member`)
- the six UML relation kinds plus plain solid/dashed links, cardinalities,
  and relation labels
- **namespaces** (repo #118; upstream #7618) — rendered and structured, see
  below
- **`direction TB|BT|LR|RL`** — wired to layout (plan §Class 4)
- accessibility directives (`accTitle` / `accDescr`)
- SVG, PNG, and spatial ASCII/Unicode output, including nested namespace frames

## Annotation fidelity (issue #248)

The official `class Shape <<interface>>`, `<<interface>> Shape`, and
`class Shape { <<interface>> }` / multiline-body forms share one annotation
grammar between the native and agent parsers. The native class node owns the
annotation and renders it in the header; the agent stores it as an annotation
member and serializes a canonical class body, preserving class identity and
unrelated relations through mutation. The pinned parser also accepts the
no-space `class Shape<<interface>>` / `<<interface>>Shape` spellings and an
inline annotation after a bracket label. A separate annotation requires the
class to have already been introduced; annotation names use Mermaid's
word-token grammar for inline/separate placement. Class-body annotations are
broader and preserve their interior text, including whitespace, punctuation,
and an empty annotation. Unsupported forms produce a diagnostic rather than a
plausible partial diagram.
An annotation after a quoted bracket label, generic, or backtick class ID is
recognized outside that declaration content. Angle-bearing generic labels and
backtick IDs still hit the existing Scene validation boundary even without an
annotation; verification reports `RENDER_FAILED` until the broader #260 work.

Pinned Mermaid also permits multiple annotations on one class. The
current native class model has one annotation slot, so that case is explicitly
diagnosed instead of rendering only the last annotation. Its agent body stays
opaque and source-preserved, while separate executable inline and
standalone-annotation cases prove native behavior. Broader Class
statement/event consolidation remains
tracked by #260.

## Markerless relationship fidelity (issue #248)

Pinned Mermaid treats `A -- B` and `A .. B` as distinct solid and dashed
links with no endpoint marker. Both create endpoint classes, including when
spaces around the operator are omitted. The native and agent parsers now share
that distinction as `link-solid` / `link-dashed` with `markerAt: none`;
serialization, mutation, SVG/Scene, and terminal output preserve the line
style without adding an arrowhead. Cardinalities and relation labels survive
on bare dashed links. Trailing `%%` before a label stays inert; after `:` it
belongs to the label, matching Mermaid. A
bounded scanner locates the operator and comment boundary outside backtick IDs,
generic parameters, and quoted cardinalities.

Where a `%%` comment may appear follows Mermaid's class lexer, through one
rule both parsers share (`classCommentStart` and `classStatement` in
`src/class/parser.ts`). The comment consumes its line break, so Mermaid accepts
a trailing comment only on the diagram's last statement; after `class …`, on or
inside a namespace, and after a closing `}` it is rejected outright, and ours
rejects the same sources. A bare `classDiagram` header with no statement is
rejected too, as in Mermaid; `accTitle`, `accDescr` and `direction` count as
statements.

The bare-link parser rejects Mermaid-reserved unescaped endpoint tokens (`o`,
relation keywords, and dollar-bearing IDs) instead of manufacturing native
edges. Malformed bare labels and incomplete links now fail loudly rather than
leaving a plausible partial diagram. Upstream-valid whitespace-only labels
(`A .. B : `) and numeric-entity labels (`a&#58;b`) still cross a shared
source-normalization seam: trimming or entity decoding erases the distinction
needed by the native parser. They remain source-preserved and diagnosed, not
counted as native, pending the broader #260 parser/identity work. Hyphenated,
dotted, and Unicode endpoint IDs also remain in that broader scope.

Marked one-way arrows now also retain backtick IDs with spaces through a
bounded shared relationship scanner. This closes the previously silent
`\`class A\` --> B` identity loss across native render, agent, serialization,
and mutation. The scanner recognizes compact arrows and does not confuse
arrow bytes inside escaped IDs or quoted cardinalities with an operator.
Upstream-reserved endpoint spellings (for example unescaped `o` and escaped
`\`note\``) remain rejected rather than producing a plausible edge.
Escaped IDs containing `~` remain diagnosed because Mermaid treats them as
generic references with a different stable identity. Two-ended and lollipop
links now share the bounded relationship scanner, including escaped endpoint
IDs and cardinalities. Their shaft style is stored independently of endpoint
marker kinds, so `o..*` and `()..()` retain their dashed shafts through
structured edits, SVG/Scene and terminal output. Mixed lollipop markers such as
`()-->` and `<--()` retain both authored endpoint identities. One-ended
lollipops create independent interface occurrences with collision-safe public
identities. Repeated labels do not share an occurrence, and an ordinary class
with the same spelling remains separate. Generic interface spelling is retained
through canonical writing. Use `add_interface` with `class`, `label` and optional
`side`, `relationLabel` and `lineStyle` to create one explicitly. `add_relation`
rejects operations that would silently turn an ordinary endpoint into an
interface; parsed interface occurrences remain editable and removable.

Class relation facts include effective marker ownership, both endpoint kinds
when present, and `line solid` / `line dashed`. Public `add_relation` operations
can author those properties explicitly and reject combinations that would
change meaning on reload. Member authoring refuses comment-form/blank text,
accessibility directives and decoded line breaks; the source reader still
handles comments as source metadata. Initial member arrays are copied so later caller changes do not
alter the returned diagram. See `docs/api.md` for the complete-fact migration.

Unescaped word-like Class names may contain hyphens, dots and Unicode letters
or digits. Declarations, relationships, members and typed edits retain the same
identity; canonical writing quotes a name when the statement requires it.
Escaped names containing `~` still require generic-identity work and remain
source-preserved rather than exposing a partial editable model. This does not
claim support for every token combination Mermaid's Class lexer can assemble.

## Safe link hover text (issue #248)

Pinned Mermaid accepts both `link A "https://example.com" "Docs"` and
`click A href "https://example.com" "Docs"`. The shared Class link grammar
now preserves the optional tooltip with the safe URL. Structured agent state,
serialization, mutation, the renderer-neutral action sidecar, and a native SVG
`<title>` on the linked class keep the same text. The URL remains inert metadata;
this does not enable callbacks or external fetches. Tooltip text is XML-escaped
before SVG emission. Malformed trailing text after a safe link fails loudly.
This slice covers links to declared classes, in the official documented order:
declare the class before its interaction. Control characters in hover text are
rejected rather than emitted into XML or trusted action metadata.
The Class renderer and action sidecar retain the authored interaction line
through the shared entity-decoding seam, so an entity-encoded quotation mark
inside a tooltip (including one beside `%%`) remains text, while a raw quoted
navigation target is still diagnosed.

Mermaid also accepts an optional navigation target such as `_self`. Our inert
action model does not represent that target, so such a statement remains
source-preserved in the agent and diagnosed by native rendering. The executed
receipt keeps the official Interaction section's aggregate claim `diagnosed`;
it does not promote callbacks or targeted navigation to native support.

## `:::` class shorthand evidence (2026-07)

**Why:** `Account:::highlight` decorates `Account`; the suffix is not an
inline class member. The fixture is
[`class-style-shorthand-demo.mmd`](./class-style-shorthand-demo.mmd).

| Before (`7f5102a9`) | After |
|---|---|
| ![A phantom style-suffix member](./class-style-shorthand-before.png) | ![Stable class identity without a phantom member](./class-style-shorthand-after.png) |

**What to inspect:** the before box contains a spurious `::highlight` member;
the after box preserves one `Account` identity and an empty member compartment.
The renderer and structured agent surface now share parser-owned style
properties: `classDef`, `class`/`cssClass`, `:::`, and inline `style` resolve to
one identity-safe paint model. Typed `define_class`, `set_css_class`, and
`set_class_style` operations round-trip that model.

## Namespaces (2026-07 elevation)

Upstream contract (verified against mermaid.js.org/syntax/classDiagram.html
and the upstream parser suite): `namespace X { class A }`, syntactic nesting
(`namespace A { namespace B { … } }`), dot notation (`namespace A.B.C`
auto-creates `A` and `A.B` as parents; blocks with a shared prefix share the
parent chain), and display labels `namespace X["Label"]` (v11.15+).

One grammar, two consumers (C1): `parseNamespaceHeader` in
`src/class/parser.ts` is the single namespace-opener grammar; the render
parser and the agent body parser both consume it, so membership cannot drift
between surfaces. Membership is single-claim: a class belongs to the first
namespace block that declares it.

### Layout

Namespaces lay out as ELK compound nodes — the flowchart-subgraph pattern:

- member classes are children of their namespace compound; nested namespaces
  are child compounds; `elk.hierarchyHandling: INCLUDE_CHILDREN` is enabled
  only when namespaces exist, so namespace-free diagrams keep byte-identical
  output;
- each compound reserves a header band via top padding, so members clear the
  label by construction;
- relationships are hosted on the lowest-common-ancestor compound and
  extraction adds the host's absolute offset back (the exact
  `extractEdgesRecursively` convention from `src/layout-engine.ts`);
- the direction→ELK mapping is `directionToElk`, imported from
  `src/layout-engine.ts` — no parallel copy.

`PositionedClassDiagram.namespaces` is a flattened parent-first list with
absolute coordinates; the renderer draws each as rect + header band + label
(`<g class="namespace" data-id data-label data-parent-id>`), behind
relationship lines and class boxes.

### Verification

`family-layouts.ts` projects namespaces as `RenderedLayout.groups` with their
member class ids, which arms:

- verify's `GROUP_BREACH` (groupContainment now on for class), and
- the family rubric's group-containment and group-tiling axes.

Invariant gates live in `src/__tests__/class-namespace.test.ts` (every class
box inside its namespace box; nested boxes inside parents; members clear the
header band) and judge any golden regeneration.

### Agent body

`ClassNode.namespace` is a dot-joined path; `ClassBody.namespaces` is the
declared-path registry (first-seen order, optional labels). Serialization
canonicalizes to dot-path blocks (`namespace A.B { … }`) — the exact
production the render parser accepts; parents implied by descendants are
skipped unless they carry a label or are childless declarations. The
serializer→render-parser conformance suite
(`src/__tests__/class-serializer-conformance.test.ts`, P3) proves membership
survives serialize → render-parse after every succeeding op.

Ops: `add_class` gained an optional `namespace` field;
`set_class_namespace {class, namespace|null}` moves a class between
namespaces (declared on demand; null = top level). `describe` and `facts`
expose membership (`class X in namespace P.A`).

## Direction and spacing

`direction TB|BT|LR|RL` (shared grammar in
`src/shared/direction-statement.ts`) is parsed into `ClassDiagram.direction`
and mapped through `directionToElk`. Default stays TB. RenderOptions
`nodeSpacing`/`layerSpacing` thread into `elk.spacing.nodeNode` /
`elk.layered.spacing.nodeNodeBetweenLayers` (defaults 40/60 unchanged).

The agent body does NOT model `direction` (a `direction` line keeps the body
opaque); rendering honors it regardless because layout reads the render
parser's model.

## Config (wire-or-warn, P4)

The typed `class` frontmatter section (`ClassRuntimeConfig` in
`src/mermaid-source.ts`):

- **Wired**: `nodeSpacing`, `rankSpacing` → RenderOptions
  `nodeSpacing`/`layerSpacing` (explicit RenderOptions win), plus
  `hierarchicalNamespaces` → nested compounds (`true`) or compact sibling
  frames (`false`), via
  `resolveClassRenderOptions` in `src/class/layout.ts`, applied on both the
  render path (`render-family-hooks.ts`) and the verify layout path
  (`family-layouts.ts`).
- **Lint** (`INEFFECTIVE_CONFIG`, Tier-3): <!-- BEGIN GENERATED: noop-keys:class -->`arrowMarkerAbsolute`, `defaultRenderer`, `diagramPadding`, `dividerMargin`, `hideEmptyMembersBox`, `htmlLabels`, `look`, `padding`, `textHeight`, `theme`, `titleTopMargin`<!-- END GENERATED: noop-keys:class --> —
  the lint reads the class descriptor's `config.noopKeys` in
  `src/agent/families.ts`.

## Generic classes (repo #118)

`class Box~T~`, generic-bearing relationship endpoints, namespace-contained
variants, notes, and separate member declarations normalize to one stable bare
identity (`Box`) plus `ClassNode.generic` (`T`). The renderer displays
`Box<T>`; canonical serialization emits the upstream `~T~` declaration and
bare relationship endpoints. `add_class.generic` and `set_class_generic`
provide typed authoring/editing without forcing an opaque fallback.

## Styling, compact namespaces, and cardinalities

`ClassName:::style` is consumed before inline-member parsing, including `$` and
backtick identities, so decoration cannot mint a phantom class. The shared
`src/shared/style-props.ts` grammar models `classDef`, `class`/`cssClass`,
shorthand, and inline paint on both parser surfaces; classDef paint resolves
before Scene/SVG/terminal rendering and inline properties win. Repeated `:::`
and `cssClass` assignments retain their names in source order: each definition
contributes paint, and later assignments override overlapping properties. The
typed `set_css_class` edit replaces the assigned names.

Single-line namespace forms (`namespace X { class A; class B }`) expand through
one parser-owned statement grammar. `hierarchicalNamespaces: false` is wired:
nested compounds become compact sibling frames rather than merely producing a
warning. Terminal output draws grapheme-aware nested namespace frames with
explicit containment gates.

Cardinality labels are allocated in `src/class/layout.ts`, not offset ad hoc in
the renderer. The dense `c5-stress` property rejects cardinality/cardinality
and cardinality/node overlap before SVG lowering. These residual contracts are
pinned by `class-residual-elevation.test.ts`, `class-ascii-namespaces.test.ts`,
and `class-er-edge-quality.test.ts`.
