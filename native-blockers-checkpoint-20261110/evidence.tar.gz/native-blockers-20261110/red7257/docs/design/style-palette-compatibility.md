# Style + Palette compatibility

Compatibility is owned by the registry-derived portfolio in
`src/__tests__/render-conformance-plan.test.ts`, not by a copied family roster
or the former 4,500-row docs-example Cartesian product.

The executable plan provides three complementary proofs:

1. **Pure bounded exhaustion:** every registered non-default Look × Palette
   stack is resolved as data. All palette channels and precedence rules are
   checked without paying for a family render.
2. **Variable-strength real rendering:** the core SVG plan covers every valid
   pair across family, Look, Palette, security, background polarity and
   complexity stratum. It exhausts Look × Palette × background polarity and
   raises strength for family × backend × complexity, palette-sensitive Scene
   role signatures, external-reference syntax and contact-sheet witnesses.
3. **Mixed output projection:** a separate plan crosses every family with
   backend, complexity and SVG/PNG/ASCII/Unicode, including every-family
   text/Unicode stress through every output.

Every registered family contributes six mandatory sources:

- minimal registry example;
- representative generated source;
- structurally dense generated source;
- multilingual/combining/emoji text stress;
- family-risk syntax;
- highest-complexity structured source discovered in the eval corpus.

Adding a `DiagramKind` cannot compile until its conformance profile exists.
Runtime exact-set checks enforce family/profile closure. The independent tuple
verifier remains a helper, but the historical fake/removed-family sabotage
suite was removed; its old plan is not proof of a current CI assertion.

The former family × Look × Palette matrix proved every named triple for one
simple SVG source. The replacement intentionally does **not** retain that exact
triple claim. Instead it proves every family/Look, family/Palette and
Look/Palette pair; exhausts the pure stack and Look/Palette/background
contracts; and exercises six complexity strata. The retained render tests check
semantic/finite/security behavior and selected byte determinism. Historical
fault-sensitivity results do not establish today's assertion coverage.

The styled-output suite separately pins a normalised SVG golden for every
built-in family, each paired with one non-default Look so every Look is covered
(`src/__tests__/testdata/styled/`), renders every Look over the layout fixture
corpus, verifies deterministic seed behavior, exercises
default/rough/hybrid backends, and tests user-color precedence. Exact bytes
remain focused rather than becoming the interaction planner's oracle.

Run:

```bash
bun test src/__tests__/render-conformance-plan.test.ts
bun test src/__tests__/styled-output.test.ts --timeout 30000
```

Human sense-making is separate from machine conformance:

- the [historical portfolio migration](../project/archive/complexity-aware-test-portfolio-plan.md) records the Cynefin rationale and original review protocol, not current release gates;
- the portfolio contact-sheet probe and its review record are no longer published.

This is a compatibility and interaction contract, not a universal aesthetic
claim. Contact sheets, native-size human review, production smoke and external
consumer evidence remain independent oracles.
