# What Makes a Layout Ugly

This document states the working definition of an *ugly* diagram layout that
this project has converged on, and maps each defect to a detector. It is the
specification for `eval/ugly-detector/` (which audits **rendered** output —
SVG, PNG, ASCII, and Unicode — not just the internal geometry the rubric checks).

## The one-line definition

> **A layout is ugly when an edge's geometry isn't forced by the node
> positions** — when it bends, floats, splays, crosses, or breaks symmetry in
> a way a clearer alternative would avoid for the *same* layout. Every bend,
> offset, and asymmetry should be the cheapest one the node positions allow,
> or it shouldn't be there. Ugliness is **unexplained geometry**.

## The defects (and how we detect them)

Grouped by the layer they live in. The first group are **hard** — they must
never appear in a finished render. The second are **soft** — present in good
layouts only when forced, and ranked below.

### Hard defects (a finished render must have zero)

| Defect | What it looks like | Detector |
|---|---|---|
| **Diagonal segment** | an edge segment that is neither horizontal nor vertical, in an orthogonal drawing | segment with `|dx| > ε` AND `|dy| > ε` |
| **Edge through a node** | an edge crossing a node's interior (occlusion) | segment intersects a non-endpoint node's body deeper than stroke width |
| **Floating endpoint** | an edge ending at an arbitrary point on the outline, not a designated connection point | endpoint not within tolerance of the shape's outline / a designated port |
| **Node overlap** | two node bodies overlapping | bbox/footprint intersection |
| **Hitch / dogleg** | a short perpendicular jog on a run whose lane is clear | a segment much shorter than its collinear neighbours, perpendicular, with a clear straight alternative |
| **Label off its route** | a label pill sitting away from the edge it names | label centroid far from its edge's polyline |

The rendered hitch detector tests the two existing lanes and their midpoint.
It requires valid endpoint attachment, orthogonal joins, clearance from node
bodies, foreign label halos and occupied parallel lanes, and no added proper
crossings. A short jog forced by a parallel relation's label is not a proven
hitch. This conservative local search does not establish globally minimal bends.

### Soft ranking (good layouts minimize these, in this priority order)

This historical ranking is superseded by the current policy in
[quality.md](../../quality.md#layout-priorities-and-their-limits), which places
crossings ahead of continuity and distinguishes outline attachment from preferred
canonical ports. The older ranking explains earlier implementation choices:

1. **Straightness / continuity** — fewest bends; a multi-edge path reads as a
   line. (Beats everything below.)
2. **Designated-port attachment** — endpoints sit on a *named*, deterministic
   connection point, not a target-determined float. **Subtlety we encode:**
   straightness normally beats port-exactness (the strict-ports experiment was
   measured and rejected), *except* when a designated port is reachable
   **without costing a bend** — then take it. The diamond 8-port model exists
   precisely to make E/F/G/K port-exact *and* straight/symmetric at once.
3. **Symmetry / balance** — where the structure is symmetric (peer fan-ins,
   reciprocal pairs), the drawing should be too: a centered hub, two equal
   parallel lines, no peer privileged over another.
4. **Fewest bends and crossings** — after the above.

### Specific ugly shapes we have named

- **Cramming at a sharp point** — two lines crowded onto a vertex when they
  could be spread (the ±6 reciprocal-on-a-diamond-tip, before facet-mids).
- **Pinch-then-splay / hourglass** — edges converging to a narrow pair of ports
  then fanning back out to wider targets (the rejected F facet-mid+bend).
- **A line through a shape's body** — routing the short way *through* a node
  instead of around it (the rejected G facet-mid prototype).
- **Asymmetry where symmetry is natural** — a fan-in hub stuck at the top of
  its sources, or a reciprocal pair of unequal lengths.

## Why detect from rendered output (not just geometry)

The `assessLayout` rubric (`src/layout-rubric.ts`) checks the flowchart
`PositionedGraph`. The ugly-detector combines the **rendered artifact** — the
SVG/PNG/ASCII/Unicode a consumer actually sees — with every family's canonical
`RenderedLayout` admission. The latter proves finite bounds and paths for
families whose SVG vocabulary is not parsed by the deeper flowchart markup
adapter. Together they:

1. catches rendering bugs where clean geometry renders wrong;
2. works on *any* diagram, including external SVGs and golden fixtures not
   produced by our layout pass;
3. validates the ASCII pipeline, which is a separate renderer that never sees
   the `RouteCertificate` contracts.

The formats degrade in fidelity: **SVG** supplies the deepest markup analysis
where typed node/edge marks are recoverable, while the receipt separately counts
that markup coverage and all-family `RenderedLayout` structural admission.
**PNG** is a faithful raster of the SVG, so its extra check is a coarse
pixel-orthogonality sanity pass. **ASCII and Unicode** are separately rendered
display-cell grids; their conservative detector samples mapped label bands, not
every blank interior cell, and uses an exact authored-cell mask so punctuation
cannot hide route ink elsewhere in the region.

## Running the audit

```
bun run audit:ugly                # render every enrolled source to SVG/PNG/ASCII/Unicode
bun run audit:ugly -- --verbose   # also list soft findings
bun run audit:ugly -- --json      # machine-readable report
```

The runner (`eval/ugly-detector/audit.ts`) renders every enrolled quality
source — the contact-sheet scenarios, heuristic-tracker examples, site
samples, every authored `eval/**/*.mmd` (including the real-content
Mindmap/GitGraph corpus and layout-compare fixtures), and ASCII/Unicode golden
fixture sources — to graphical output plus both terminal modes and runs the
detectors. Eval Mermaid files are discovered recursively rather than listed by
hand. Golden tests,
the updater, and this audit share one strict fixture parser, so
`paddingX`/`paddingY` lines cannot become fake Mermaid headers and a missing
final separator fails closed. It exits non-zero for any **hard** finding or
render/corpus error and runs in the CI quality job.
`src/__tests__/ugly-detector.test.ts` runs the detector over real renderer
output (clean flows, CJK Gantt label regions).

Current diagram, format, and adapter totals are deliberately not copied into
this prose: `bun run audit:ugly -- --json` is the live receipt. Its `coverage`
record distinguishes all-family renderer-layout admission from deeper SVG
markup admission. A passing gate means every enrolled source rendered in all
four formats, every family produced structural evidence, and there were zero hard
findings or render/corpus errors; soft findings remain reported for review.

Historical note: an earlier audit found one real hard defect — a
cross-hierarchy edge into a nested subgraph missing the containing subgraph's
offset. That is now fixed by hosting cross-hierarchy edges at their lowest
common compound and by treating subgraph IDs as container endpoints; the
regressions live in `src/__tests__/subgraph-direction.test.ts`.

Two findings the audit initially raised were **detector** false positives, now
fixed and regression-tested: a cylinder's footprint must union its cap ellipses
(not just the body rect), and a sub-pixel endpoint jog within the curved-shape
clip floor (~1.5px) is not a visible dogleg.
