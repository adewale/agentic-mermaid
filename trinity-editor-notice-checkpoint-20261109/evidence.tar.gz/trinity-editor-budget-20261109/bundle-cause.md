# Standalone editor budget: bounded causal review

Reviewed source at docs head `7834513e894fadf61da913c699b3a94ed6f104d4` (runtime `4db8570d389246bb5f1eede8c5b1899fe6cd687e`) and existing matched Bun 1.4.4 artifacts. No builds, renders, tests, profiles, network, or source edits. Existing gzip/Brotli payloads were decoded only to inspect their already-built contents.

**One demonstrated bounded candidate: deduplicate exact complete license texts across the codec and worker notice producers. The actual outer notice block repeats Apache-2.0.txt (11,358 bytes) and Brotli-MIT.txt (1,337 bytes) twice each. Retain one complete copy of each plus all package/version/copyright/modification attribution. This is 12,695 duplicated raw bytes, not evidence of 8,194 recoverable gzip bytes. No candidate demonstrated here is known to close the cap.**

## What actually accounts for the measured delivery

`trinity-class-scopes-20261109/editor-build/after-metafile.json` records 1,342,694 gzip bytes versus the original 1,334,500 cap. Its standalone worker is 5,023,664 decoded bytes, Brotli-packed to 1,180,650 bytes, then embedded as base64. The main-thread facade is 296,056 bytes after compression/minification. The complete HTML is 2,124,144 uncompressed bytes.

`scripts/site/editor.ts:260–298,347–352` builds the worker once, packs it, separately builds the engine-free facade, and embeds that payload once. `src/browser-standalone.ts:8–38` captures and decodes it once into an immutable Blob, removes the encoded DOM payload, and reuses the Blob for worker attempts. `src/browser-standalone-payload.ts:14–43` preserves bounded decoding and both byte-length/CRC checks. These are separate necessary stages, not a second shipped renderer.

The largest worker owner is `elk.bundled.js` (1,499,579 pre-SWC contribution); it supplies the retained ELK backend/fallback. The pinned Mermaid configuration program contributes 223,214 bytes and is called by canonical wrapper validation/export (`src/agent/wrapper-portability.ts:1–3,33–54`), reachable through the worker's mutation feature. Backend conformance contributes 24,330 bytes and remains live through built-in paint-backend first-use admission (`src/scene/backend.ts:245–269,458–479`). None is demonstrated dead under the required feature/fallback contract.

## Concrete duplicated owner and boundaries

- **Decoder dictionary:** the facade's apparent 164,036-byte dictionary module is already specialized to the exact private worker stream (`scripts/build/standalone-worker-payload.ts:25–49,144–155`). Unread bytes are zeroed at original offsets and complete decoded bytes are rechecked. Its raw module size does not represent recoverable gzip payload. Further format/decoder changes would be a new hypothesis, not subtraction of an identified duplicate.
- **Actual outer notice duplication:** `scripts/site/editor.ts` concatenates `standaloneCodecNotices()` with `standaloneWorkerNotices(...)`. The former explicitly includes Apache-2.0 and Brotli-MIT; the latter adds every maintained LICENSES file. Its Set deduplicates only inside the latter function. Exact full-text counts against the existing HTML confirm both complete texts occur twice. The smallest defensible change is one shared exact-text notice collector across these two producers, before escaping/concatenation; keep every distinct package header, copyright and modification statement and one complete copy of every distinct license text. Do not remove license obligations or use fuzzy/substring deduplication. Existing decoded worker itself has only five block-comment candidates totalling 181 bytes, none over 100 bytes; subtracting worker comments is not a credible recovery.
- **Family example/editor catalogs:** standalone projection already disables `familyEditorMetadata` (`scripts/site/editor.ts:223`; false when no hosted runtime directory). `standalone-family-metadata-projection.test.ts` protects this existing projection. The main UI retains its required example/style/family catalog.
- **Shared facade/worker modules:** style registry, option contracts, XML/security and related validators occur in both separate realms, but have live synchronous facade consumers (`src/browser-editor-adapter.ts:10–16,42–70`) and worker consumers. Removing the facade copy or relocating work into the worker would change API/control flow and require a new design; it is not established dead-code removal. The worker-side checks must not be removed on the assumption that the facade already validated input.

The previous community-port artifact was 1,342,154 gzip bytes: the new artifact is +540 gzip despite the decoded worker being 34 bytes smaller (packed worker +212 bytes; facade unchanged). This directly cautions against converting raw module deltas into recoverable compressed bytes. Metafile contributions are pre-SWC, pre-Brotli and cannot establish an 8,194-byte saving.

## Smallest falsifiable intervention

Unify only the exact complete notice-text deduplication across the two current notice producers. The owning checks must retain every required license text and package/modification attribution in the final standalone HTML, including the decoder adaptations; preserve escaped script safety. Then measure the same complete-file Bun 1.4.4 gzip artifact. No runtime/decoder/backend change is required. Stop if the complete-file saving is negligible or the attribution cannot remain intact.

I did not implement, recompress a modified artifact, or measure this candidate. Gzip may already exploit the repeats, so the 12,695 raw-byte duplication must not be represented as enough to close the 8,194-byte gzip deficit. Preserve the cap and report the remainder. Beyond this notice-only candidate, inspection did not demonstrate removable required runtime payload; speculative minifier flags, conformance/config deletion, and moving required bytes outside the measured file remain unjustified.

## Authorized offline ceiling result (supersedes the unmeasured status above)

Ran only `notice-ceiling.ts` against the retained Class HTML with the pinned Bun 1.4.4 executable. Its zlib identity exactly matches the canonical collector: `12731092979c6d07f42da27da673a9f6c7b13586`. Settings match `editor-build/compress.ts`: node:zlib gzip level 9 and Brotli quality 11, with no other compression changes. Baseline sizes reproduce exactly.

| Existing-artifact diagnostic | Raw bytes | Gzip 9 | Brotli 11 |
| --- | ---: | ---: | ---: |
| Before | 2,124,144 | 1,342,694 | 1,282,743 |
| Remove second exact complete Apache/Brotli-MIT bodies | 2,111,449 | 1,338,454 | 1,281,945 |
| Saving | 12,695 | 4,240 | 798 |

**This cannot close the 8,194-byte gzip deficit: 3,954 bytes remain above the original 1,334,500 cap.** It is a partial diagnostic ceiling, not a shipping legal presentation, implementation result, or acceptance pass. No broader compression flags are proposed.

Only the second exact complete copies inside the existing outer notice block were removed. One complete copy of each remains; surrounding package headers and other attributions were preserved verbatim. Original artifact bytes were verified unchanged. Distinct before/after HTML, gzip and Brotli files are retained beside the script. `NOTICE-CEILING.json` records all six artifact SHA256 values, script SHA256, original gzip SHA256 and runtime identity. Original gzip SHA256: `3247a6aa268710b4ecff7d301180ed159647ee958b63d4157ecfc09cc390f0d4`; diagnostic after HTML SHA256: `cfd3a265ad20e0df11ea6aa82537992aa2a2e4717de118ea94ffaa678fb38eca`. Recompressed baseline gzip has the same canonical size but a different compressed-byte digest from the retained input; hashes identify each file separately rather than asserting compressed-byte identity.
