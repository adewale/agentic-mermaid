import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { gunzipSync, gzipSync, brotliCompressSync, constants } from 'node:zlib';

if (process.versions.bun !== '1.4.4') throw new Error('Requires the matched Bun 1.4.4 runtime');
const dir = import.meta.dir;
const source = '/tmp/pr449-week-comparison-20261101/trinity-class-scopes-20261109/editor-build/after-production.html.gz';
const repo = '/tmp/pr449-main-integration-20261029-762';
const originalCompressed = readFileSync(source);
const before = gunzipSync(originalCompressed);
const html = before.toString('utf8');
if (!Buffer.from(html, 'utf8').equals(before)) throw new Error('HTML did not round-trip as UTF-8');
const open = '<script type="text/plain" id="editor-codec-notices">';
const start = html.indexOf(open) + open.length;
if (start < open.length) throw new Error('Missing notice block');
const end = html.indexOf('</script>', start);
if (end < start) throw new Error('Missing notice block end');
let notices = html.slice(start, end);
const removed: Array<{ file: string; bytes: number; secondOffsetInOriginalNotice: number }> = [];
const originalNotices = notices;
for (const file of ['Apache-2.0.txt', 'Brotli-MIT.txt']) {
  const body = readFileSync(`${repo}/LICENSES/${file}`, 'utf8').replace(/<\//g, '<\\/');
  const matches = notices.split(body).length - 1;
  if (matches !== 2) throw new Error(`${file}: expected exactly two complete copies, got ${matches}`);
  const first = notices.indexOf(body), second = notices.indexOf(body, first + body.length);
  const oldFirst = originalNotices.indexOf(body), oldSecond = originalNotices.indexOf(body, oldFirst + body.length);
  notices = notices.slice(0, second) + notices.slice(second + body.length);
  if (notices.split(body).length - 1 !== 1) throw new Error('Did not retain one complete copy');
  removed.push({ file, bytes: Buffer.byteLength(body), secondOffsetInOriginalNotice: oldSecond });
}
const after = Buffer.from(html.slice(0, start) + notices + html.slice(end));
const sha256 = (data: Uint8Array) => createHash('sha256').update(data).digest('hex');
const write = (name: string, data: Uint8Array | string) => writeFileSync(`${dir}/${name}`, data, { flag: 'wx' });
const rows = [];
for (const [name, data] of [['notice-ceiling-before', before], ['notice-ceiling-after', after]] as const) {
  const gzip = gzipSync(data, { level: 9 });
  const br = brotliCompressSync(data, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } });
  write(`${name}.html`, data); write(`${name}.html.gz`, gzip); write(`${name}.html.br`, br);
  rows.push({ name, raw: data.length, gzip9: gzip.length, brotli11: br.length,
    sha256: { raw: sha256(data), gzip9: sha256(gzip), brotli11: sha256(br) } });
}
if (!readFileSync(source).equals(originalCompressed)) throw new Error('Original artifact changed');
if (rows[0]!.gzip9 !== 1342694 || rows[0]!.brotli11 !== 1282743) throw new Error('Canonical baseline differs');
const result = {
  scope: 'Offline diagnostic ceiling only; not a shipping legal presentation or acceptance gate',
  runtime: process.versions.bun, zlib: process.versions.zlib,
  original: { path: source, sha256: sha256(originalCompressed), unchanged: true },
  scriptSha256: sha256(readFileSync(import.meta.path)), removed, rows,
  savings: { raw: rows[0]!.raw - rows[1]!.raw, gzip9: rows[0]!.gzip9 - rows[1]!.gzip9, brotli11: rows[0]!.brotli11 - rows[1]!.brotli11 },
  originalGzipLimit: 1334500, remainingGzipExcess: rows[1]!.gzip9 - 1334500,
};
write('NOTICE-CEILING.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
