import{readFileSync,writeFileSync}from'node:fs'
import{createHash}from'node:crypto'
import{gunzipSync,gzipSync,brotliCompressSync,constants}from'node:zlib'
const p=import.meta.dir,rows=[]
for(const [phase,stage]of[['before','trinity-class-scopes-20261109'],['after','trinity-editor-budget-20261109']]){
 const raw=gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/'+stage+'/editor-build/after-production.html.gz'))
 const values={gzip9:gzipSync(raw,{level:9}),brotli11:brotliCompressSync(raw,{params:{[constants.BROTLI_PARAM_QUALITY]:11}})}
 rows.push({phase,raw:raw.length,compressed:Object.fromEntries(Object.entries(values).map(([kind,bytes])=>{const file=phase+'.canonical.'+(kind==='gzip9'?'gz':'br');writeFileSync(p+'/'+file,bytes);return[kind,{file,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')}]}))})
}
writeFileSync(p+'/CANONICAL-FILES.json',JSON.stringify({runtime:process.versions.bun,zlib:process.versions.zlib,scope:'Actual complete HTML compressed withmatchingBun gzip9/Brotli11; retained bytes, no wire/startup claim.',rows},null,2)+'\n');console.log(rows)
