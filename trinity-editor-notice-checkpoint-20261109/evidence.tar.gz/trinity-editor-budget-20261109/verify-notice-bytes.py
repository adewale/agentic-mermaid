from pathlib import Path
import gzip,json,re,hashlib
root=Path('/tmp/pr449-week-comparison-20261101');out=root/'trinity-editor-budget-20261109';before=gzip.decompress((root/'trinity-class-scopes-20261109/editor-build/after-production.html.gz').read_bytes());after=gzip.decompress((out/'editor-build/after-production.html.gz').read_bytes());pattern=rb'(<script type="text/plain" id="editor-codec-notices">)([\s\S]*?)(</script>)'
a=re.search(pattern,before);b=re.search(pattern,after);assert a and b
outside=lambda data,m:data[:m.start(2)]+data[m.end(2):]
sha=lambda x:hashlib.sha256(x).hexdigest();same=outside(before,a)==outside(after,b);assert same,'Runtime/HTML outside notice content changed'
oldNotice=a[2].decode('utf8');newNotice=b[2].decode('utf8');oldLines={s for s in oldNotice.splitlines() if s.strip()};newLines=set(newNotice.splitlines());missing=sorted(oldLines-newLines);assert not missing,'Attribution lines missing'
licenses=[];repo=Path('/tmp/pr449-main-integration-20261029-762')
for file in [repo/'LICENSE',repo/'THIRD_PARTY_NOTICES.md',*sorted((repo/'LICENSES').iterdir())]:
 if not file.is_file():continue
 text=file.read_bytes().decode('utf8').replace('</','<\\/');old=oldNotice.count(text);new=newNotice.count(text)
 if old:assert new>=1,file
 licenses.append({'path':str(file.relative_to(repo)),'beforeCompleteTextCount':old,'afterCompleteTextCount':new,'sha256':sha(text.encode())})
for name in ['Apache-2.0.txt','Brotli-MIT.txt']:
 row=next(r for r in licenses if r['path']=='LICENSES/'+name);assert row['beforeCompleteTextCount']==2 and row['afterCompleteTextCount']==1,row
scripts=[]
for key in ['editor-runtime','editor-worker-payload']:
 pat=rb'<script[^>]*id="'+key.encode()+rb'"[^>]*>([\s\S]*?)</script>';x=re.search(pat,before);y=re.search(pat,after);assert x and y and x[1]==y[1];scripts.append({'id':key,'bytes':len(y[1]),'sha256':sha(y[1]),'byteExact':True})
result={'scope':'Actual built complete HTML before/after. Only inert notice contents differ; no runtime/layout/decoder byte change. All original distinct nonblank notice lines and every previously emitted complete maintained license retained. Canonical compression measured separately with matchingBun.', 'outsideNoticeByteExact':same,'outsideNoticeSha256':sha(outside(after,b)),'beforeNoticeBytes':len(a[2]),'afterNoticeBytes':len(b[2]),'allOriginalDistinctNonblankNoticeLinesRetained':not missing,'retainedDistinctLines':len(oldLines),'licenses':licenses,'scripts':scripts,'beforeHTMLSha256':sha(before),'afterHTMLSha256':sha(after)}
(out/'ACTUAL-BYTE-QUALIFICATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['licenses']},indent=2))
