from pathlib import Path
r=Path('/dev/shm/pr449-four-final-20261111/served-route-reuse-candidate')
p=r/'src/scene/native-paint-emission.ts';s=p.read_text();s=s.replace('textPaint?: SvgTextPaintWrite; conditional: boolean } {','textPaint?: SvgTextPaintWrite; geometryPaint?: true; conditional: boolean } {')
needle="      if (!pay(48)) return { ...retained, conditional: true }"
assert needle in s
s=s.replace(needle,"""      // The recorder already produces the reduced Native paint source. Give
      // it this exact write instead of first copying every complete mark slot
      // onto another SceneNode merely to replace its route. The actual route
      // allocation and its readonly value checks remain funded here.
      if (closeLeaves && directGeometry && captured.kind === 'connector' && served.kind === 'polyline') {
        const projection = readSvgGeometryProjection(xml, xmlWrite, captured, geometry)
        if (!projection || !pay(96)) return { ...retained, conditional: true }
        return { ...retained, geometryPaint: true, conditional: projection.collapsed }
      }
"""+needle)
p.write_text(s)
p=r/'src/scene/native-drawing.ts';s=p.read_text();s=s.replace("readonly textPaint?: SvgTextPaintWrite; readonly conditional", "readonly textPaint?: SvgTextPaintWrite; readonly geometryPaint?: true; readonly conditional")
s=s.replace("import { writeNativeGroupOpening, type SvgTextPaintWrite, type SvgXmlWrite }", "import { writeNativeGroupOpening, type SvgTextPaintWrite, type SvgXmlWrite, type SvgXmlCapture }")
s=s.replace("=> boolean | SvgTextPaintWrite, documentFont?: string)", "=> boolean | SvgTextPaintWrite, documentFont?: string, geometryCapture?: SvgXmlCapture)")
s=s.replace("actualPaint, fragment.svg)", "actualPaint, fragment.svg, fragment.geometryPaint ? geometryCapture : undefined, fragment.geometryPaint ? fragment.xmlWrite : undefined)")
s=s.replace("textPaint: captured.textPaint, conditional:", "textPaint: captured.textPaint, geometryPaint: captured.geometryPaint, conditional:")
# inspectPaint is called once at completion.
print('inspectPaint calls',[x.strip() for x in s.splitlines() if 'inspectPaint(' in x])
s=s.replace("emission.observe, emittedHeader?.colors.font)","emission.observe, emittedHeader?.colors.font, xml)")
s=s.replace("emission.observe, header.colors.font)","emission.observe, header.colors.font, xml)")
p.write_text(s)
p=r/'src/scene/inspection.ts';s=p.read_text();s=s.replace("import { readSvgTextPaintWrite, type SvgTextPaintWrite }", "import { readSvgTextPaintWrite, readSvgGeometryWrite, readSvgGeometryProjection, type SvgTextPaintWrite, type SvgXmlWrite, type SvgXmlCapture }")
s=s.replace("const textPaintFreeze = Object.freeze, textPaintDefine = Object.defineProperty", "const textPaintFreeze = Object.freeze, textPaintDefine = Object.defineProperty\nconst routeDescriptor = Object.getOwnPropertyDescriptor, routeOwn = Object.hasOwn, routeExtensible = Object.isExtensible")
s=s.replace("paintWrite?: SvgTextPaintWrite, svg = '') {", "paintWrite?: SvgTextPaintWrite, svg = '', geometryCapture?: SvgXmlCapture, geometryWrite?: SvgXmlWrite) {")
s=s.replace("      recorder.leaf(node, key, parentMatrix, ancestors, conditional, groupOpacity, owner, undefined, false, parentMatrix === undefined, actual, actual ? paintWrite : undefined)","""      let actualRoute: ConnectorMark['route'] | undefined
      if (geometryCapture && geometryWrite && node.kind === 'connector' && !node.transform && !node.route.closed && node.markers.mid.length === 0) {
        const geometry = readSvgGeometryWrite(geometryCapture, geometryWrite, node, node.route.geometry)
        const projection = readSvgGeometryProjection(geometryCapture, geometryWrite, node, node.route.geometry)
        if (geometry?.kind === 'polyline' && projection) {
          const contours = projection.contours, startTangent = contours[0]?.startTangent, endTangent = contours.at(-1)?.endTangent
          const input = { ...node.route, geometry, contours, startTangent, endTangent }, sealed = textPaintFreeze(input)
          // A foreign freeze return or altered actual operands cannot acquire
          // the receipt's geometry authority through this private request.
          const slot = (name: string, value: unknown): boolean => {
            const field = routeDescriptor(input, name)
            return !!field && routeOwn(field, 'value') && field.value === value && field.writable === false && field.configurable === false
          }
          if (sealed === input && !routeExtensible(input) && slot('geometry', geometry) && slot('contours', contours)
            && slot('closed', false) && slot('startTangent', startTangent) && slot('endTangent', endTangent)) actualRoute = input
        }
      }
      recorder.leaf(node, key, parentMatrix, ancestors, conditional || !!geometryCapture && !actualRoute, groupOpacity, owner, undefined, false, parentMatrix === undefined, actual, actual ? paintWrite : undefined, actualRoute)""")
s=s.replace("freeze = textPaintFreeze): NativePaintSource", "freeze = textPaintFreeze, actualRoute?: ConnectorMark['route']): NativePaintSource")
s=s.replace("endpoints: node.endpoints, route: node.route, stroke:", "endpoints: node.endpoints, route: actualRoute ?? node.route, stroke:")
s=s.replace("actualPaintWrite?: SvgTextPaintWrite): void", "actualPaintWrite?: SvgTextPaintWrite, actualRoute?: ConnectorMark['route']): void")
s=s.replace("nativePaintSource(node, actualTextPaint, freeze)", "nativePaintSource(node, actualTextPaint, freeze, actualRoute)")
s=s.replace("nodePaintBounds(node, parentTransform, documentFont, actualTextPaint)", "nodePaintBounds(node, parentTransform, documentFont, actualTextPaint, actualRoute)")
p.write_text(s)
p=r/'src/scene/bounds.ts';s=p.read_text();s=s.replace("function connectorPaintBounds(node: ConnectorMark, transform?: SceneTransform)", "function connectorPaintBounds(node: ConnectorMark, transform?: SceneTransform, actualRoute?: ConnectorMark['route'])")
start=s.index('function connectorPaintBounds(');end=s.index('/** Conservative painted bounds',start)
section=s[start:end].replace('node.route.geometry', '(actualRoute ?? node.route).geometry').replace('connectorStrokeHasJoins(node.route)', 'connectorStrokeHasJoins(actualRoute ?? node.route)').replace('node.route.closed', '(actualRoute ?? node.route).closed')
s=s[:start]+section+s[end:]
s=s.replace("actualTextPaint?: MarkPaint): AxisAlignedBox | undefined {\n  return paintBounds(node, parentTransform, documentFont, actualTextPaint)", "actualTextPaint?: MarkPaint, actualRoute?: ConnectorMark['route']): AxisAlignedBox | undefined {\n  return paintBounds(node, parentTransform, documentFont, actualTextPaint, actualRoute)")
s=s.replace("function paintBounds(node: SceneNode, parentTransform?: SceneTransform, documentFont?: string, actualTextPaint?: MarkPaint)", "function paintBounds(node: SceneNode, parentTransform?: SceneTransform, documentFont?: string, actualTextPaint?: MarkPaint, actualRoute?: ConnectorMark['route'])")
s=s.replace("return connectorPaintBounds(node, transform)", "return connectorPaintBounds(node, transform, actualRoute)")
p.write_text(s)
