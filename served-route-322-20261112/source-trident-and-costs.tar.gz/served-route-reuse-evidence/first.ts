import assert from 'node:assert/strict'
import {readFileSync,writeFileSync}from'node:fs'
import {gzipSync}from'node:zlib'
const control=await import('../rectangle-write-reuse-candidate/src/index.ts'),candidate=await import('../served-route-reuse-candidate/src/index.ts')
const cases=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-marker-paint-matched/MEASUREMENT-CASES.json','utf8'));cases.unshift({id:'tiny',source:'flowchart TD\n A --> B'})
for(const id of ['tiny','diagnostic:chain100','diagnostic:chain300']){
 const c=cases.find(c=>c.id===id),opts={...c.renderOptions,graphLayout:{backend:'agentic',fallback:'none'}}
 let a,b,error
 try{a=control.renderMermaidSVGWithReceipt(c.source,opts);b=candidate.renderMermaidSVGWithReceipt(c.source,opts)}catch(e){error={name:e.name,message:e.message,diagnostics:e.diagnostics}}
 writeFileSync(new URL(id.replace(':','-')+'.json.gz',import.meta.url),gzipSync(JSON.stringify({control:a,candidate:b,error})))
 const noncert=p=>{const r=structuredClone(p);if(r)delete r.receipt.layoutCertification;return r}
 console.log(JSON.stringify({case:id,error,svgExact:a?.svg===b?.svg,noncertExact:JSON.stringify(noncert(a))===JSON.stringify(noncert(b)),control:a?.receipt.layoutCertification,candidate:b?.receipt.layoutCertification}))
 if(error||a.svg!==b.svg||JSON.stringify(noncert(a))!==JSON.stringify(noncert(b)))process.exitCode=1
}
