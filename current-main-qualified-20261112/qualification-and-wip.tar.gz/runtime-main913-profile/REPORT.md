# Merged7f4 capture profile

Actual frozen source: `7f4a0c166892fc15c0fee5b0fd1dc60c9e500154`. Two existing worker jobs, each ten fully consumed warm public WithReceipt calls, cache0, 200us V8 sampling. Import and cold rows are separate. These sampled elapsed weights are causal ceilings, not unprofiled latency or expected speedup. Inclusive ancestors overlap and must not be summed. Full global ranking (including inspector, GC and unknown/generated frames), raw generated locations and actual source-map mappings remain in SUMMARY.json and raw profiles.

## chain100

| Source frame | Self total / per-render ms | Inclusive total / per-render ms |
|---|---:|---:|
| ../src/scene/native-paint-emission.ts:228 | 172.245 / 17.225 | 214.352 / 21.435 |
| ../src/layout-rubric.ts:496 | 55.425 / 5.542 | 119.523 / 11.952 |
| ../src/scene/native-paint-emission.ts:410 | 43.208 / 4.321 | 222.469 / 22.247 |
| ../src/layout-rubric.ts:656 | 38.432 / 3.843 | 177.696 / 17.770 |
| ../src/scene/scene-validation-core.ts:783 | 38.376 / 3.838 | 128.715 / 12.872 |

Inspector post: 402.835ms total; GC: 38.281ms total, both separate from application self. Import 268.958ms, cold row 390.079ms are instrumented observations, not benchmark comparisons.
Actual proof: passed, 238786 operations; labels 100, markers 99, conditional 0.

## chain300

| Source frame | Self total / per-render ms | Inclusive total / per-render ms |
|---|---:|---:|
| ../src/scene/native-paint-emission.ts:228 | 326.411 / 32.641 | 432.162 / 43.216 |
| ../src/layout-rubric.ts:496 | 301.359 / 30.136 | 497.328 / 49.733 |
| ../src/scene/native-paint-emission.ts:410 | 103.980 / 10.398 | 451.446 / 45.145 |
| ../src/scene/scene-validation-core.ts:783 | 101.345 / 10.135 | 293.101 / 29.310 |
| ../src/layout-rubric.ts:656 | 95.376 / 9.538 | 648.711 / 64.871 |

Inspector post: 403.839ms total; GC: 107.958ms total, both separate from application self. Import 275.695ms, cold row 676.571ms are instrumented observations, not benchmark comparisons.
Actual proof: unverified, 400000 operations; labels 300, markers 0, conditional 586.

## Matching intervention and bounded value

| Owning frame | Matching case and permitted subtraction | Bound / disposition |
|---|---|---|
| native-paint-emission.ts:228 copyInner; :410 copy | Data-oriented producer reuse: retain actual completed geometry/text operands and eliminate a whole repeated capture pass; generic SDK/mutable/getter custody remains. | Native10017.225ms self in copyInner and22.247ms inclusive in copy are ceilings, not additive or achievable savings. A proposed change must identify the actual field/subtree work it removes before a value clock. No new cache or generic schema recipe. |
| scene-validation-core.ts:783 validateNode | Completed semantic input reuse only if mandatory bounds/CSS/reference/aggregate budgets still execute with the same observations. | Native1003.838ms self/12.872ms inclusive. Direct semantic reads are not duplicated descriptor scans; blanket validator removal is invalid. |
| layout-rubric.ts:496 and :656 | Candidate enumeration/data locality. | Prior spatial/rubric variants were adverse and withdrawn. The current profile does not revive them. No new variant proposed. |

The current Chain300 proof spends its allowance before marker inspections (0 markers;586 conditional primitives). Marker-local geometry reuse has a measured0.522ms capture-side ceiling on Chain300 and cannot explain/close this deficit; no further resource co-product expansion follows that stopped bound.

## Existing caches and retained state

- Layout-result retention is disabled by `AGENTIC_MERMAID_ELK_CACHE=0`. The separately retained14-call observation found positioned-layout bypass (`elk-cache-disabled`) and Native drawing misses for first/repeat/new-source/edit. It predates7f4 and is labeled accordingly; no fresh merged cache-hit claim is made. Repeated-source timing variation is not established as cache-hit copying.
- Native `textPlans`, native-paint-emission.ts:180/410: per-emission retained reflection instructions, materializing required fresh receiver graphs on generic capture. Does not remove distinct-label work.
- XML `names`/`attributes`/`texts` maps, svg-writer.ts:128: per-capture lexical reuse. Cached bytes never establish actual-write custody.
- Measured marker `footprints`, measured-graph-producer.ts:167: structural reservation reuse; no demonstrated replacement speedup.
- Route marker execution/peer snapshots, route-marker-clearance.ts:267–288: guarded pass-local reuse, not persistent rendering results.
- Paint `strokeAlpha`, `pathContours`, `occurrenceBounds`, `actualShaftParts`, paint-certification.ts:1708–1713: proof-local scratch indexes, not later-output certification.
- `connectorLabelBlocks`, bounds.ts:438: prepared block retention by label descriptor; mutable/getter semantics remain independently guarded.
- `renderedCertificates`, paint-certification.ts:52: returned RenderedLayout API state; not a cache qualifying fresh/edited drawings.
- Captured leaf, XML write, group, polyline, text ownership and completed resource registries establish private custody/transaction state. Their presence does not justify removing authority checks.
- Render-option `validationRootSchema`, render-option-contract.ts:385/405: merged7f4 still retains the full frozen public schema projection. Payload candidate factors canonical StyleSpec/transitive JSON fragments separately; that is not yet this measured artifact.

No sequential awaits exist in these synchronous hotspots. Pointer packing, a wholesale SoA rewrite, new caches, a raised cap or waived semantic checks are not supported by this profile. All previous adverse trials remain retained. Native100 reliable under100ms and both Chain300 proofs remain unresolved.
