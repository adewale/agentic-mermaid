import {build} from '/tmp/pr449-main-integration-20261029-762/node_modules/tsup/dist/index.js';
import cfg from '/dev/shm/pr449-four-final-20261111/main913-browser-facade-fix/tsup.browser-lazy.config.ts';
await build({...cfg,dts:false,config:false});
