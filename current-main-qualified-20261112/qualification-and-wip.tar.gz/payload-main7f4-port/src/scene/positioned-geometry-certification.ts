import type { FamilyLayoutResult } from '../agent/families.ts'
import type { PaintLayoutCertification } from './paint-certification.ts'

/** The receipt's layout certificate also records geometry drawn uncertified. */
export function withGeometryCertification(certification: PaintLayoutCertification, layout: FamilyLayoutResult): PaintLayoutCertification {
  return layout.uncertifiedLayout ? Object.freeze({ ...certification, geometry: layout.uncertifiedLayout }) : certification
}

