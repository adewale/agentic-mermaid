import { withGeometryCertification } from './positioned-geometry-certification.ts'
import { hasRetainedPositionedScene, positionedScenePaintCertification } from './positioned-scene.ts'
export { retainedPositionedScene, actualPositionedSceneWriteEligible, beginPositionedBackendEmission, finishPositionedBackendEmission } from './positioned-scene.ts'
import { isOwnedFamily } from '../experimental/owned-family.ts'
import { assertBackendConformance, isBuiltinDefaultBackend } from './backend.ts'
import { nativeDrawingOf, originalNativeDrawingOf, preferSceneDrawing, type DrawingProducer } from './drawing.ts'
import { drawNative, drawOriginalPositionedNative, type NativeDrawing } from './native-drawing.ts'
import type { FamilyLayoutResult } from '../agent/families.ts'
import type { ResolvedRenderRequest } from '../render-contract.ts'
import { resolvedFamilyRenderContextOf, resolvedRenderExecutionPlanOf } from '../render-contract.ts'
import { positionedForNativeProducer, retainedFamilyProjection } from '../positioning.ts'
import { withTextMeasurementExecution } from '../text-measurement-profile.ts'
import { sceneAssertionsEnabled } from './assertions.ts'
import { certifyNativePaint, type PaintLayoutCertification } from './paint-certification.ts'
import { observeCache, observeFallback } from '../performance-observations.ts'
import { cachedNativeDrawing, retainNativeDrawing, type RetainedNativeDrawing } from '../experimental/position-cache.ts'

type RenderableNativeDrawing = Pick<NativeDrawing, 'svg' | 'preparedText'>
type PositionedNative = { producer: DrawingProducer } & (
  { phase: 'captured'; drawing: NativeDrawing; evidence: NativeDrawing }
  | { phase: 'certified'; drawing: RenderableNativeDrawing; certification: PaintLayoutCertification }
)
const positionedWeakGet = WeakMap.prototype.get, positionedApply = Reflect.apply
const native = new WeakMap<FamilyLayoutResult, WeakMap<ResolvedRenderRequest, PositionedNative>>()
// Above this conservative native custody capacity, retain one immutable Scene
// before drawing. This avoids spending the paint allowance on an abandoned
// native capture; both adapters certify under the same unchanged limits.
const ER_NATIVE_PAINT_NODE_CAPACITY = 256

/** Native crisp work has no Scene document/group tree. Strong evidence and
 * alternate backends deliberately retain the extension-facing Scene adapter. */
export function retainedNativeDrawing(request: ResolvedRenderRequest, layout: FamilyLayoutResult): RenderableNativeDrawing | undefined {
  const plan = resolvedRenderExecutionPlanOf(request)
  // A completed async fallback selected the Scene consumer for this operand.
  // A later producer change cannot replace its proof with a new Native write.
  if (plan.consumer?.kind === 'scene-backend') return undefined
  // Once ER lowered a Scene, later observers cannot switch its actual operand.
  if (preferSceneDrawing(plan.family.id) && !native.get(layout)?.has(request) && hasRetainedPositionedScene(layout, request)) return undefined
  let bypass = sceneAssertionsEnabled(request) ? 'scene-assertions' : plan.family.id.startsWith('family:') ? 'external-family'
    : plan.consumer?.kind !== 'native-drawing' && plan.backend && !isBuiltinDefaultBackend(plan.backend.backend) ? 'alternate-backend'
      : !(plan.mode === 'layout' ? request.appearance.inferredBackend === 'default' : plan.mode === 'scene' && (plan.consumer?.kind === 'native-drawing' || plan.backend?.inputName === 'default')) ? 'unsupported-mode' : undefined
  if (!bypass && plan.family.id === 'er' && (retainedFamilyProjection(layout)?.nodes.length ?? 0) > ER_NATIVE_PAINT_NODE_CAPACITY) bypass = 'paint-proof-capacity'
  let producer = bypass ? undefined : nativeDrawingOf(plan.family.lowerScene)
  if (!bypass && preferSceneDrawing(plan.family.id) && producer && producer === originalNativeDrawingOf(plan.family.lowerScene)) bypass = 'owned-scene-geometry'
  if (!producer) bypass ??= 'no-native-producer'
  if (bypass) {
    observeCache('native-drawing', 'bypass', bypass)
    observeFallback('native-drawing', bypass)
    if (bypass !== 'owned-scene-geometry' || nativeDrawingOf(plan.family.lowerScene) === producer) return undefined
    // An observer installed a different producer before either capture began.
    producer = nativeDrawingOf(plan.family.lowerScene)
  }
  let requests = native.get(layout)
  if (!requests) { requests = new WeakMap(); native.set(layout, requests) }
  const prior = requests.get(request)
  if (prior) {
    observeCache('native-drawing', 'hit')
    if (prior.producer === nativeDrawingOf(plan.family.lowerScene)) return prior.drawing
    observeCache('native-drawing', 'bypass', 'changed-producer')
    requests.delete(request)
  }
  // The Scene SPI proves its broad backend contract. A selected Native
  // consumer instead proves the actual requested XML/paint write below.
  if (plan.backend) assertBackendConformance(plan.backend.conformance, plan.backend.inputName)
  // Positioning's ownership proof must still hold after layout observers run.
  // A changed producer executes on its detached graph and cannot publish a
  // drawing under the original producer's private cache entry.
  producer = nativeDrawingOf(plan.family.lowerScene)
  const cached = cachedNativeDrawing(request, layout, producer === originalNativeDrawingOf(plan.family.lowerScene))
  if (cached) {
    observeCache('native-drawing', 'hit', undefined, 'positioned-owner')
    const cachedProducer = producer
    if (cachedProducer && cachedProducer === nativeDrawingOf(plan.family.lowerScene) && cachedProducer === originalNativeDrawingOf(plan.family.lowerScene)) {
      requests.set(request, { phase: 'certified', drawing: cached, producer: cachedProducer, certification: cached.certification })
      return cached
    }
    // An observation callback changed the producer after the lookup. Revoke
    // this operation's proof and construct from the producer now installed.
    observeCache('native-drawing', 'bypass', 'changed-producer')
    cachedNativeDrawing(request, layout, false)
    producer = nativeDrawingOf(plan.family.lowerScene)
  }
  observeCache('native-drawing', 'miss')
  producer = nativeDrawingOf(plan.family.lowerScene)
  if (!producer) {
    observeCache('native-drawing', 'bypass', 'no-native-producer')
    observeFallback('native-drawing', 'no-native-producer')
    return undefined
  }
  const drawingProducer = producer
  const colors = request.output === 'png' && request.appearance.colors.embedFontImport !== false
    ? { ...request.appearance.colors, embedFontImport: false } : request.appearance.colors
  const drawing = withTextMeasurementExecution(plan.textMeasurement, () => drawOriginalPositionedNative(request, layout, drawingProducer) ?? drawNative(drawingProducer,
    { positioned: positionedForNativeProducer(layout, drawingProducer), colors, resolved: resolvedFamilyRenderContextOf(request) }, plan.family.id, request.appearance.styled ? request.appearance.style : undefined))
  requests.set(request, { phase: 'captured', drawing, producer: drawingProducer, evidence: drawing })
  return drawing
}


export function positionedPaintCertification(request: ResolvedRenderRequest, layout: FamilyLayoutResult): PaintLayoutCertification {
  const existing = native.get(layout)?.get(request)
  const drawing = existing?.drawing ?? retainedNativeDrawing(request, layout)
  if (drawing) {
    const requests = native.get(layout)!
    const entry = requests.get(request)!
    observeCache('paint-certification', entry.phase === 'certified' ? 'hit' : 'miss', undefined, 'native')
    if (entry.phase === 'certified') return entry.certification
    const evidence = entry.evidence
    const certification = withGeometryCertification(certifyNativePaint(evidence.header, evidence.paint, retainedFamilyProjection(layout), { outputSupported: !request.appearance.colors.shadow }), layout)
    const retained: RetainedNativeDrawing = Object.freeze({ svg: drawing.svg, preparedText: drawing.preparedText, certification })
    if (positionedApply(positionedWeakGet, requests, [request]) === entry) {
      requests.set(request, { phase: 'certified', drawing: retained, producer: entry.producer, certification })
    }
    const lower = resolvedRenderExecutionPlanOf(request).family.lowerScene
    if (entry.producer === nativeDrawingOf(lower) && entry.producer === originalNativeDrawingOf(lower)) retainNativeDrawing(request, layout, retained)
    else {
      observeCache('native-drawing', 'store-skipped', 'changed-producer')
      cachedNativeDrawing(request, layout, false)
    }
    return certification
  }
  return positionedScenePaintCertification(request, layout)
}
