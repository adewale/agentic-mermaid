/** The serializer owns its actual observer, capture and receipt transaction. */
export { createSceneWriteCapture, beginSceneWriteInspection, sceneBackendWriteObserver, type SceneWriteReceipt, type SceneWriteWork } from './serialization.ts'
