import { withGeometryCertification } from './positioned-geometry-certification.ts'
import { isOwnedFamily } from '../experimental/owned-family.ts'
import { finalizeOwnedScene } from './owned-data.ts'
import { createSceneWriteCapture, type SceneWriteReceipt } from './scene-write-capture.ts'
import { MAX_OCCLUSION_OPERATIONS } from './native-paint-emission.ts'
import { isBuiltinDefaultBackend, isOriginalEnrolledDefaultBackend, getBackendDescriptor } from './backend.ts'
import { isOriginalSceneLowering } from './drawing.ts'
import type { FamilyLayoutResult } from '../agent/families.ts'
import type { ResolvedRenderRequest } from '../render-contract.ts'
import { resolvedFamilyRenderContextOf, resolvedRenderExecutionPlanOf } from '../render-contract.ts'
import { positionedForSceneLowering, retainedFamilyProjection } from '../positioning.ts'
import { withTextMeasurementExecution } from '../text-measurement-profile.ts'
import { admitFamilyScene } from './admission.ts'
import { sceneAssertionsEnabled } from './assertions.ts'
import { withDeferredTerminalProjections } from './deferred-terminal-projection.ts'
import type { SceneDoc } from './ir.ts'
import { type PaintLayoutCertification } from './paint-certification.ts'
import { certifyScenePaint } from './scene-paint-certification.ts'
import { observeCache } from '../performance-observations.ts'

// One owner for admitted Scene transactions. The async source consumer acquires
// this module with the genuine SPI; synchronous SDK consumers import it eagerly.
interface PositionedScene { scene: SceneDoc; crossChecks: boolean; writes?: SceneWriteReceipt; pendingWrites?: ReturnType<typeof createSceneWriteCapture>; certification?: PaintLayoutCertification }
const positionedWeakGet = WeakMap.prototype.get, positionedApply = Reflect.apply
const retained = new WeakMap<FamilyLayoutResult, WeakMap<ResolvedRenderRequest, PositionedScene>>()
export function hasRetainedPositionedScene(layout: FamilyLayoutResult, request: ResolvedRenderRequest): boolean {
  return retained.get(layout)?.has(request) ?? false
}

/** Resolve the transaction kind before the first Scene consumer. Verification
 * can inspect/certify before rendering; it must retain that same open receipt. */
export function actualPositionedSceneWriteEligible(request: ResolvedRenderRequest): boolean {
  const plan = resolvedRenderExecutionPlanOf(request)
  return plan.mode === 'scene' && !plan.family.id.startsWith('family:') && !!plan.backend
    && isBuiltinDefaultBackend(plan.backend.backend) && isOriginalEnrolledDefaultBackend(plan.backend.backend)
}

/** Lower once from the actual positioned artifact, shared by SVG, layout,
 * verification and receipt consumers. No source parse or layout is repeated. */
export function retainedPositionedScene(request: ResolvedRenderRequest, layout: FamilyLayoutResult): SceneDoc {
  let requests = retained.get(layout)
  if (!requests) { requests = new WeakMap(); retained.set(layout, requests) }
  const prior = requests.get(request)
  if (prior) {
    observeCache('positioned-scene', 'hit')
    if (sceneAssertionsEnabled(request) && !prior.crossChecks) {
      admitFamilyScene(resolvedRenderExecutionPlanOf(request).family, prior.scene, true)
      prior.crossChecks = true
    }
    return prior.scene
  }
  observeCache('positioned-scene', 'miss')
  const plan = resolvedRenderExecutionPlanOf(request)
  if (!plan.family.lowerScene) throw new Error(`Resolved ${request.output} family has no Scene lowering`)
  const colors = request.output === 'png' && request.appearance.colors.embedFontImport !== false
    ? { ...request.appearance.colors, embedFontImport: false } : request.appearance.colors
  const actualBackendWrite = actualPositionedSceneWriteEligible(request)
  const assertions = sceneAssertionsEnabled(request)
  const writer = plan.backend ?? (plan.mode === 'layout' && request.appearance.inferredBackend === 'default' ? getBackendDescriptor('default') : undefined)
  const writes = !plan.family.id.startsWith('family:') && writer && isBuiltinDefaultBackend(writer.backend) && isOriginalEnrolledDefaultBackend(writer.backend)
    ? createSceneWriteCapture(MAX_OCCLUSION_OPERATIONS, { fractionalCircleOutput: !request.appearance.styled && !request.appearance.colors.shadow, pageUnderlay: request.appearance.styled }, actualBackendWrite) : undefined
  const lower = () => {
    const scene = plan.family.lowerScene!({ positioned: positionedForSceneLowering(layout), colors, resolved: resolvedFamilyRenderContextOf(request) })
    // Actual-write proof requires its own defensive snapshot provenance.
    return !writes && isOwnedFamily(plan.family) && isOriginalSceneLowering(plan.family.lowerScene) ? finalizeOwnedScene(scene) : scene
  }
  const scene = withTextMeasurementExecution(plan.textMeasurement, () => admitFamilyScene(plan.family,
    !assertions && !plan.family.id.startsWith('family:') ? withDeferredTerminalProjections(lower) : lower(), assertions, writes?.observe))
  requests.set(request, { scene, crossChecks: assertions, ...(actualBackendWrite && writes ? { pendingWrites: writes, writes: writes.prepare(scene) } : { writes: writes?.finish(scene) }) })
  return scene
}

export function beginPositionedBackendEmission(request: ResolvedRenderRequest, layout: FamilyLayoutResult, context: object, proof: PaintLayoutCertification): boolean {
  const requests = positionedApply(positionedWeakGet, retained, [layout]) as WeakMap<ResolvedRenderRequest, PositionedScene> | undefined
  const entry = requests && positionedApply(positionedWeakGet, requests, [request]) as PositionedScene | undefined
  if (!entry?.pendingWrites) return false
  if (proof !== entry.certification) throw new Error('Scene proof belongs to a different positioned transaction')
  entry.pendingWrites.beginBackendEmission(entry.scene, context, proof)
  return true
}
export function finishPositionedBackendEmission(request: ResolvedRenderRequest, layout: FamilyLayoutResult, result: { kind: 'complete'; proof: PaintLayoutCertification } | { kind: 'abort' }): PaintLayoutCertification | undefined {
  const requests = positionedApply(positionedWeakGet, retained, [layout]) as WeakMap<ResolvedRenderRequest, PositionedScene> | undefined
  const entry = requests && positionedApply(positionedWeakGet, requests, [request]) as PositionedScene | undefined
  if (!entry?.pendingWrites) return undefined
  if (result.kind === 'abort') entry.pendingWrites.abortBackendEmission()
  else entry.certification = entry.pendingWrites.finishActual(result.proof)
  entry.pendingWrites = undefined
  return entry.certification
}

export function positionedScenePaintCertification(request: ResolvedRenderRequest, layout: FamilyLayoutResult): PaintLayoutCertification {
  const scene = retainedPositionedScene(request, layout)
  const entry = retained.get(layout)!.get(request)!
  observeCache('paint-certification', entry.certification ? 'hit' : 'miss', undefined, 'scene')
  if (entry.certification) return entry.certification
  const plan = resolvedRenderExecutionPlanOf(request)
  const supported = !request.appearance.colors.shadow && (plan.mode === 'layout' ? request.appearance.inferredBackend === 'default' : plan.mode === 'scene' && (plan.consumer?.kind === 'native-drawing' || plan.backend?.inputName === 'default'))
  const writer = plan.backend ?? (plan.mode === 'layout' && request.appearance.inferredBackend === 'default' ? getBackendDescriptor('default') : undefined)
  const written = supported && writer && isBuiltinDefaultBackend(writer.backend) && isOriginalEnrolledDefaultBackend(writer.backend)
  return entry.certification = withGeometryCertification(certifyScenePaint(scene, retainedFamilyProjection(layout), { outputSupported: supported, sceneWriteReceipt: written ? entry.writes : undefined }), layout)
}
