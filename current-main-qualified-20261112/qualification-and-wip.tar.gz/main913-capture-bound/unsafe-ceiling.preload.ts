import {plugin} from 'bun';import {readFileSync}from'node:fs'
plugin({name:'UNSAFE-connector-capture-meter-ceiling-NOT-production',setup(build){build.onLoad({filter:/main913-integration\/src\/scene\/native-paint-emission\.ts$/},args=>{
let s=readFileSync(args.path,'utf8')
s=s.replace('  const pay = work.pay',`  let unsafeSuppressConnectorCapture = false\n  const pay = (count = 1): boolean => { if (unsafeSuppressConnectorCapture) { (globalThis as any).__unsafeSuppressedConnectorCapture += count; return true } return work.pay(count) }`)
s=s.replace("      try { captured = copy(node, 0, new Set(), 'leaf', closeLeaves) as Leaf } catch { /* Strict mutable fallback. */ }", "      unsafeSuppressConnectorCapture = closeLeaves && node.kind === 'connector'\n      try { captured = copy(node, 0, new Set(), 'leaf', closeLeaves) as Leaf } catch { /* Strict mutable fallback. */ } finally { unsafeSuppressConnectorCapture = false }")
return{loader:'ts',contents:s}
})}})
