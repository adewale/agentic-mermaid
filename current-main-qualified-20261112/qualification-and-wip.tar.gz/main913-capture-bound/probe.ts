import {readFileSync,writeFileSync} from 'node:fs';import{gunzipSync}from'node:zlib';import{createHash}from'node:crypto'
const root='/dev/shm/pr449-four-final-20261111';(globalThis as any).__captureBound={fields:{},leaves:{}}
const job=JSON.parse(readFileSync(root+'/runtime-main913-profile/chain300.job.json','utf8'))
const api=await import(root+'/main913-integration/src/index.ts'),product=api.renderMermaidSVGWithReceipt(job.source,job.options)
const baselineSVG=gunzipSync(readFileSync(root+'/runtime-main913-profile/chain300/warmup.svg.gz')).toString()
const baselineReceipt=JSON.parse(gunzipSync(readFileSync(root+'/runtime-main913-profile/chain300/warmup.receipt.json.gz')).toString())
const out={scope:'Actual original400k ledger; top-level field child capture paid work only; excludes root property/key visits, CPU and total allocation claims. One full sourcepublic Chain300 result. No source/runtime edits.',source:'7f4a0c166892fc15c0fee5b0fd1dc60c9e500154',...((globalThis as any).__captureBound),svgExactBuiltControl:product.svg===baselineSVG,receiptExactBuiltControl:JSON.stringify(product.receipt)===JSON.stringify(baselineReceipt),digest:createHash('sha256').update(product.svg).digest('hex'),proof:product.receipt.layoutCertification}
writeFileSync(root+'/main913-capture-bound/RESULT.json',JSON.stringify(out,null,2))
console.log(JSON.stringify({...out,fields:Object.entries(out.fields).sort((a:any,b:any)=>b[1].operations-a[1].operations).slice(0,16)},null,2))
