import {plugin} from 'bun';import {readFileSync}from'node:fs'
plugin({name:'UNSAFE-connector-capture-meter-ceiling-NOT-production',setup(build){build.onLoad({filter:/main913-integration\/src\/scene\/native-paint-emission\.ts$/},args=>{
let s=readFileSync(args.path,'utf8')
s=s.replace('  const pay = work.pay',`  let unsafeSuppressConnectorCapture = false\n  const pay = (count = 1): boolean => { if (unsafeSuppressConnectorCapture) { (globalThis as any).__unsafeSuppressedConnectorCapture += count; return true } return work.pay(count) }`)
s=s.replace("      try { captured = copy(node, 0, new Set(), 'leaf', closeLeaves) as Leaf } catch { /* Strict mutable fallback. */ }", "      unsafeSuppressConnectorCapture = closeLeaves && node.kind === 'connector'\n      try { captured = copy(node, 0, new Set(), 'leaf', closeLeaves) as Leaf } catch { /* Strict mutable fallback. */ } finally { unsafeSuppressConnectorCapture = false }")
s=s.replace("      // An issued inspection cannot be resealed", "      ;(globalThis as any).__unsafeStages.finishStart = { operations: work.operations(), exhausted: work.exhausted() };\n      // An issued inspection cannot be resealed")
s=s.replace("      const checkedContext = emissionContext.finish(header)", "      ;(globalThis as any).__unsafeStages.beforeContext = { operations: work.operations(), exhausted: work.exhausted() }; const checkedContext = emissionContext.finish(header); (globalThis as any).__unsafeStages.afterContext = { operations: work.operations(), exhausted: work.exhausted() }")
s=s.replace("      if (hasMarkedConnector) {\n        const verified", "      if (hasMarkedConnector) { (globalThis as any).__unsafeStages.beforeXML = { operations: work.operations(), exhausted: work.exhausted() };\n        const verified")
s=s.replace("        if (!verified) uncertain = true", "        if (!verified) uncertain = true; (globalThis as any).__unsafeStages.afterXML = { operations: work.operations(), exhausted: work.exhausted(), verified }")
return{loader:'ts',contents:s}
})}})
