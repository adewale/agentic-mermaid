import{plugin}from'bun';import{readFileSync}from'node:fs'
plugin({name:'UNSAFE-whole-three-stage-sufficiency-NOT-production',setup(build){build.onLoad({filter:/main913-integration\/src\/scene\/(?:native-paint-emission|svg-writer)\.ts$/},args=>{
let s=readFileSync(args.path,'utf8')
if(args.path.endsWith('svg-writer.ts')){
 s=s.replace('  const pay = (count = 1): boolean => {',`  const pay = (count = 1): boolean => {\n    const scope = (globalThis as any).__unsafeConsumerScope; if (scope) { (globalThis as any).__unsafeConsumerSuppressed[scope] += count; return true }`)
}else{
 s=s.replace('  const pay = work.pay',`  let unsafeSuppressConnectorCapture = false\n  const pay = (count = 1): boolean => { if (unsafeSuppressConnectorCapture) { (globalThis as any).__unsafeSuppressedConnectorCapture += count; return true } return work.pay(count) }`)
 s=s.replace("      try { captured = copy(node, 0, new Set(), 'leaf', closeLeaves) as Leaf } catch { /* Strict mutable fallback. */ }", "      unsafeSuppressConnectorCapture = closeLeaves && node.kind === 'connector'\n      try { captured = copy(node, 0, new Set(), 'leaf', closeLeaves) as Leaf } catch { /* Strict mutable fallback. */ } finally { unsafeSuppressConnectorCapture = false }")
 s=s.replace('      const checkedContext = emissionContext.finish(header)',`      const checkedContext = (() => { (globalThis as any).__unsafeConsumerScope = 'context'; try { return emissionContext.finish(header) } finally { (globalThis as any).__unsafeConsumerScope = undefined } })()`)
 s=s.replace("        const verified = typeof output === 'string' ? verifySvgDocumentEnvelope(output, pay) : xml.verify(output)",`        const verified = (() => { (globalThis as any).__unsafeConsumerScope = 'xml'; try { return typeof output === 'string' ? verifySvgDocumentEnvelope(output, pay) : xml.verify(output) } finally { (globalThis as any).__unsafeConsumerScope = undefined } })()`)
}
return{loader:'ts',contents:s}
})}})
