import {plugin} from 'bun'; import {readFileSync} from 'node:fs'
plugin({name:'existing-capture-field-bound',setup(build){build.onLoad({filter:/main913-integration\/src\/scene\/native-paint-emission\.ts$/},args=>{
let s=readFileSync(args.path,'utf8')
s=s.replace('      let copied: unknown\n', '      const fieldBefore = work.operations()\n      let copied: unknown\n')
s=s.replace('      if (planSlots) {\n        if (!pay(2))',`      if (context === 'leaf') { const keyName = String(kind) + '.' + key; const rows = (globalThis as any).__captureBound.fields; const row = rows[keyName] ??= {calls:0, operations:0}; row.calls++; row.operations += work.operations()-fieldBefore }\n      if (planSlots) {\n        if (!pay(2))`)
s=s.replace('      let captured: Leaf | undefined\n      try { captured = copy', '      const copyBefore = work.operations()\n      let captured: Leaf | undefined\n      try { captured = copy')
s=s.replace('      if (!captured) return { node, paintNode: node, ...serialize(node), conditional: true }', `      { const rows = (globalThis as any).__captureBound.leaves; const row = rows[node.kind] ??= {calls:0, operations:0, complete:0}; row.calls++; row.operations += work.operations()-copyBefore; row.complete += !!captured }\n      if (!captured) return { node, paintNode: node, ...serialize(node), conditional: true }`)
return{loader:'ts',contents:s}
})}})
