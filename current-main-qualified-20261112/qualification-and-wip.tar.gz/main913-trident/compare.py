from pathlib import Path
import gzip,json,copy,re
r=Path(__file__).parent;old=r.parent/'served-route-trident'
read=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def strip(receipt):
 x=copy.deepcopy(receipt);x.get('layoutCertification',{}).get('checks',{}).pop('operations',None);return x
result={'base':'322d0ef560722d77512a085c2607de37c895bd81','candidateCommit':'7f4a0c166892fc15c0fee5b0fd1dc60c9e500154','portable':{},'authored':{},'proofChanges':[]}
for lane in ['portable','authored']:
 path='PILOT.json.gz'if lane=='portable'else'fidelity/RESULTS.json.gz';xs=read(old/path);ys=read(r/path);s={'rows':0,'returned':0,'svgExact':0,'noncertExact':0,'proofExceptOperationsExact':0,'sameErrors':0,'meaningInkQualityExact':0,'proofCounts':{},'mismatches':[]}
 for x,y in zip(xs,ys,strict=True):
  key=[y['id'],y['backend']];assert key==[x['id'],x['backend']];s['rows']+=1
  if lane=='portable':
   accepted=y['delivery']=='returned';sameDelivery=x['delivery']==y['delivery'];status=y.get('proof');a=x;b=y
  else:accepted=y['rendered']['accepted'];sameDelivery=x['rendered']['accepted']==accepted;status=y.get('rendered',{}).get('receipt',{}).get('layoutCertification',{}).get('status');a=x['rendered'];b=y['rendered']
  s['proofCounts'][str(status)]=s['proofCounts'].get(str(status),0)+1
  if not sameDelivery:s['mismatches'].append([key,'delivery']);continue
  if not accepted:
   if a==b:s['sameErrors']+=1
   else:s['mismatches'].append([key,'error'])
   continue
  s['returned']+=1
  if lane=='portable':
   stem='candidate-'+y['backend']+'-'+re.sub('[^a-z0-9_.-]','_',y['id'],flags=re.I)
   svgx=gzip.decompress((old/'pilot'/(stem+'.svg.gz')).read_bytes());svgy=gzip.decompress((r/'pilot'/(stem+'.svg.gz')).read_bytes());a=read(old/'pilot'/(stem+'.receipt.json.gz'));b=read(r/'pilot'/(stem+'.receipt.json.gz'))
   if x['qualification']!=y['qualification']:s['mismatches'].append([key,'qualification'])
  else:
   svgx=a['svg'];svgy=b['svg'];a=a['receipt'];b=b['receipt']
   if all(x.get(k)==y.get(k)for k in ['preludes','acquired','meaning','paint','quantitative','quality','expectationDepth']):s['meaningInkQualityExact']+=1
   else:s['mismatches'].append([key,'meaningInkQuality'])
  if svgx==svgy:s['svgExact']+=1
  else:s['mismatches'].append([key,'svg'])
  ax=copy.deepcopy(a);by=copy.deepcopy(b);ca=ax.pop('layoutCertification',None);cb=by.pop('layoutCertification',None)
  if ax==by:s['noncertExact']+=1
  else:s['mismatches'].append([key,'noncert'])
  if strip(a)==strip(b):s['proofExceptOperationsExact']+=1
  else:s['mismatches'].append([key,'proof']);result['proofChanges'].append({'lane':lane,'key':key,'before':ca,'after':cb})
 result[lane]=s
result['browserClosed']=json.loads((r/'fidelity/CLOSED.json').read_text());(r/'COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='proofChanges'},indent=2))
