from pathlib import Path
import json,gzip,statistics,collections
p=Path(__file__).parent
runs=[dict(r,kind='image') for r in json.load(open(p/'COST-RUNS.json'))['runs']]+[dict(r,kind='control',backend='elk',cache='0') for r in json.load(open(p/'CONTROL-RUNS.json'))]
groups={};refs={};outcomes=collections.Counter();rows=[];exact=True
for run in runs:
 x=json.loads(gzip.decompress((p/run['directory']/'RESULT.json.gz').read_bytes())); key=run['kind']+':'+run.get('arm',run['backend'])+':'+run['cache']; groups.setdefault(key,[]).append(x)
 for r in x['rows']:
  outcomes[(r['status'],(r.get('proof')or{}).get('status'))]+=1
  stem='warmup' if r['phase']=='cold-render' else r['phase']; prod=tuple(gzip.decompress((p/run['directory']/(stem+s+'.gz')).read_bytes()) for s in ['.svg','.receipt.json'])
  scope=(run['kind'],run['backend'],'edited' if stem.startswith('edit') else 'original');refs.setdefault(scope,prod);exact &= refs[scope]==prod
 rows.append({'run':run,'rows':x['rows'],'importMs':x['importMs']})
metrics={}
for key,values in groups.items():
 metrics[key]={}
 for phase in ['cold-render','repeat1','repeat2','edit','edit2']:
  rr=[next(r for r in x['rows'] if r['phase']==phase) for x in values];v={}
  for metric in ['wallMs','cpuMs','peakRssKiB']:
   a=[r[metric] for r in rr];v[metric]={'median':statistics.median(a),'range':[min(a),max(a)],'all':a}
  for metric in ['heapUsed','rss']:
   a=[r['after'][metric] for r in rr];v[metric]={'median':statistics.median(a),'range':[min(a),max(a)]}
  metrics[key][phase]=v
report={'sourceParent':'c0099d8cebe2d88b31199ec8d67210b349ae558a','calls':sum(outcomes.values()),'outcomes':[{'delivery':a,'proof':b,'count':n}for(a,b),n in outcomes.items()],'allWholeProductsExactWithinCasesAndAcrossControls':exact,'metrics':metrics,'runs':rows,'scope':'60 current image calls U plus40 equal-work old/current ELK LR controls P.2freshreplicas/imagecell,4/armcontrol. Imports separate. No old-placeholder/refusal ratios; Ntoo smallforgeneral/p95winner. Memory includes harness/imports/retained products; RSSlifetime. Existinglayoutcache0/1 onlyswitch; no newcache.'}
(p/'COST-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n');(p/'ALL-COST-RUNS.json').write_text(json.dumps({'runs':runs},indent=2)+'\n')
print(report['outcomes'],'exact',exact)
for phase in ['cold-render','repeat2','edit','edit2']:
 print(phase,{k:{m:round(v[phase][m]['median'],2) for m in ['wallMs','cpuMs','peakRssKiB']}for k,v in metrics.items()})
