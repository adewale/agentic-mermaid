# Typed raster Scene implementation handoff

Implemented in the shared working tree; no commit or push. Root owns family/parser/layout/renderer/security integration. All source changes below are Scene-core only; tests are the explicitly assigned owning surface.

Contract: distinct `ImageMark` with self-contained PNG href, x/y/width/height, contain/stretch fit, ordinary identity/owner/hooks/transform. Canonical writer validates the actual emitted resource and viewport, emits SVG image bytes and preserves fresh capture. Image pixels are never represented as vector Geometry or measured/opaque paint. `nodeWorldBounds` exposes viewport only for document containment; `nodePaintBounds` remains absent, inspection explicitly reports `raster-paint-unavailable`, and final paint remains unverified. No new caches, fetches, decoder, cap, defaults or versions.

Files changed:
- `src/scene/ir.ts`, `marks.ts`, `drawing.ts`, `native-drawing.ts`: typed mark/factory/native enrollment.
- `svg-writer.ts`, `serialization.ts`: actual image writing and typed serialization/capture.
- `inspection.ts`, `bounds.ts`: explicit unknown raster paint, separate viewport bounds.
- `scene-validation-core.ts`, `scene-validation.ts`: closed internal raster admission and viewport validation; external declarative builder remains unsupported.
- `roles.ts`, `rough-backend.ts`: applicable image roles and crisp passthrough for rough/hybrid.
- `capabilities.ts`, `backend-conformance.ts`: optional built-in raster geometry/resource/identity claims with independent attribute witnesses. No raster paint claim and no new global host-registration requirement.
- `fidelity.ts`: href/viewport/fit correspondence.
- `src/__tests__/scene-inline-image.test.ts`: image bytes, mutable/getter fields, per-occurrence alias custody, defs/vector isolation, unknown proof, URI refusal, styled passthrough and viewport separation.
- `src/__tests__/scene-fidelity.test.ts`: existing emitted-element classifier handles image separately.
- `src/__tests__/backend-capability-conformance.test.ts`: existing host backend without image claims still registers and renders image-free input.

Evidence:
- `scene-image-red.log`: actual missing marks.image failure before implementation. Initial wrong inspection import was corrected before this retained red.
- `scene-image-focused.log`: first native-factory test caught validator fallthrough into connector fields; fixed with image-branch return. This was an implementation defect, not the baseline image loss.
- `scene-host-compat-red.log`: demonstrated newly introduced global-essential image requirement rejected old host registration; corrected by optional built-in-only claims.
- `scene-final-focused.log`:22P/0F,357 assertions (12 image owners +10 backend capability owners).
- `scene-nearby-owners.log`:124P/1F before final family enrollment; only failure was public image test's undeclared Flowchart icon/image primitive. Native validation and SVG writer owners passed. Root owns family enrollment and12-cell public owner; removed duplicate public test from my file afterward.
- `scene-image-fidelity.log`:20P/0F,2059 assertions.
- `scene-typecheck-2.log`: core tsc exit0 before final optional-capability compatibility adjustment; root owns combined final typecheck.
- `scene-final-lint.log`:18 changed files lint clean; git diff --check clean.

The first implementation added image to global ESSENTIAL capability cells; independent review correctly identified the compatibility regression. That is fixed and protected red→green. Image-specific backend request admission is root's render-contract surface: old host backends must remain usable on image-free requests and must not silently consume actual raster requests without explicit claims.

Remaining intentional limits: no raster decoding/alpha proof, external Scene declarative image construction, remote fetch or intrinsic-size discovery. Styled raster bytes stay crisp; image pixel availability is not established by passing the writer/backend tests. Root's independent final decode/visible-pixel evidence owns actual product fidelity.
