import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { Resvg } from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import { HOSTED_FONT_RESOURCES } from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import { inlineFontVarForRaster } from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import { prepareResvgMarkerOrientation } from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'

const repo = '/tmp/pr449-main-integration-20261029-762', root = import.meta.dir, zoom = 4
const fonts = HOSTED_FONT_RESOURCES.filter(font => font.family === 'Inter').map(font => {
  const file = repo + '/' + font.path
  if (createHash('sha256').update(readFileSync(file)).digest('hex') !== font.sha256) throw Error('font mismatch')
  return file
})
for (const variant of ['before','after-second']) for (const direction of ['LR','TB']) for (const backend of ['elk','agentic','trinity']) {
 if (variant === 'before' && backend === 'trinity') continue
 const svg = readFileSync(`${root}/${variant}/products/${backend}-${direction}.svg`, 'utf8')
 const image = new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(svg)), { background: '#fff', fitTo: { mode: 'zoom', value: 3 }, font: { fontFiles: fonts, fontDirs: [], loadSystemFonts: false, defaultFontFamily: 'Inter' } }).render()
 writeFileSync(`${root}/${variant}/${backend}-${direction}.png`, image.asPng())
 let red=0; const pixels=image.pixels
 for(let i=0;i<pixels.length;i+=4)if(pixels[i]>245&&pixels[i+1]<10&&pixels[i+2]<10&&pixels[i+3]>245)red++
 console.log(JSON.stringify({variant,backend,direction,width:image.width,height:image.height,redPixels:red,zoom:3}))
}
