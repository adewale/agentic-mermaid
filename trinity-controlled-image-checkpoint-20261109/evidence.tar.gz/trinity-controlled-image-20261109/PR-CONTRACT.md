## What changes

**Draft; retain ELK.** Head `c0099d8cebe2d88b31199ec8d67210b349ae558a`, base `e7cb05baa7f68154942a9ce9c6e9aaaee163dc94`. This PR repairs shared SVG ownership/measurement, improves selected Native workloads and adds opt-in Trinity. Defaults, versions and original limits are unchanged. Omitted Flowchart layout retains the forest fast path already in main. ELK retirement remains unqualified.

- Bind proof to actual SVG writes and occurrence ownership, preserving mutable/getter/CSS/definitions isolation and cumulative budgets.
- Reuse ER measurements/finalization: Native and ELK deliver ER256 in four directions at the original400k geometry cap; formerly refused BT/RL use385344 Native/371874 ELK operations. Refusal gets no speed ratio.
- Repair Native endpoint capacity, invisible constraints' phantom paint demand, shortening clearance, component packing and forests. Historical forest wire700.04→397.71 versus ELK396.47; area226466→165356 versus176727. Sparse256's implemented historical area gap is+5.04%; the+0.97% backfill is unshipped. [Dated scope](https://github.com/adewale/agentic-mermaid/blob/fb8258f17fadf2996e15aa4c82a0973b1cefae4f/rebase-c366-reconsider-20261107/README.md).
- Give canonical sharp-shaft Requirement the same physical demand across all three solvers, including ELK ports/growth. Crowded containment circles move7.67/10.77→20px apart versus11px needed; a selected pair's hidden pixels180→0. [Actual ink and adverse costs](https://github.com/adewale/agentic-mermaid/blob/91400dc282c7717ffa9bf658c83351969dc679de/trinity-common-requirement-checkpoint-20261109/README.md). Flat-root Trinity contact projection changes Requirement TB18→6bends, wire1072.96→507.03; compound locals retain centered contacts. [Three-way evidence](https://github.com/adewale/agentic-mermaid/blob/004cc22d0c46d053a708a95d5a6cf92f5ada74d5/trinity-root-ports-checkpoint-20261109/CURRENT-THREE-WAY.md).
- Add explicit measured placement/routed results and real opt-in Trinity. Supported scope: rectangular/rounded Flowchart/State scopes, fixed State circles, canonical Class scopes with notes/members/cardinalities, flat ER/Requirement and single-container Architecture forests. Routed admission remains64subjects/128edges; the existing placement slice is separate. Unsupported domains decline unless fallback is requested; exhaustion stays hard.
- Reuse canonical facets and joined-stroke support for decision diamonds. Flat fan/inlet/feedback add12 directional returned/P products from refusals; enclosed/nested workflows add8. Compound diamond requests require EVERY edge to join sibling leaves without boundary artwork, keeping them outside the box-only boundary router. Loops, marked multiport faces and any lifted edge remain unsupported. [Closed-scope coverage and costs](https://github.com/adewale/agentic-mermaid/blob/9f3f7c5e155a33d44d4e7c75434cc774429a4cef/trinity-compound-diamond-checkpoint-20261109/README.md).
- Preserve original containment in the shared fanout proposal transaction. ELK's raw geometry is correct, but our symmetry pass moved R2.1545px outside its frame and caused four-attempt TB/BT refusals. Reusing existing snapshots, containment predicate and rollback restores those two directions before route/label publication. Valid nested proposals and main-axis growth still work. No sideways frame enlargement, weaker clipping/certification or new cache.

Current material delivery contract under implementation: retain positive image w/h and constraint metadata in the typed Flowchart model/serializer; for self-contained PNG data URIs with explicit viewport dimensions, one family-owned layout reserves the picture, caption and actual painted frame. Emit a distinct typed raster mark through native/default/styled drawing paths. Raster coverage remains explicitly unmeasured/unverified; finite viewport bounds cannot grant pixel proof. Admit this framed PNG contact to Trinity only after the shared producer owns its geometry. Existing remote/unsupported media stays inert, with no fetch, decoder, new cache, cap/default/version change or broad reference-policy relaxation. Actual finalSVG href/dimensions, red source pixels, caption separation, identities/contacts, strict reference policy and getter/mutable/definition isolation are the falsifiers. Measure complete equal-consumer costs and actual payload growth before reporting the milestone; this contract is not a readiness gate.

## Correctness and delivery

| Frozen30 inputs | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| Returned / proof-passed |28|28|27|
| Shared invalid-option errors |2|2|2|
| Unsupported controlled image |0|0|1|

Native/ELK return an image placeholder whose actual-image criterion fails. Proof-passed is not complete visible correctness. The retained613-criterion authored-meaning/finalSVG ledger is ELK575passed/6unsupported/29blocked/3failed, Native576/6/28/3, Trinity564/19/28/2; all19 Trinity unsupported criteria belong to that one image input. Parser/prelude credit is separate from selected-solver delivery.

Fresh90-cell qualification retains83 byte-exact whole SVGs/entire receipts, six errors and one Trinity image refusal. The new supplements do not change that denominator. All66 previously returned contained/nested SVG/receipt/layout artifacts remain exact. Public owners inspect authored identities/endpoints/labels and actual written frame/body bounds; sampled canonical PNGs retain headers, labels and visible heads. Rough/hybrid and workload-wide readability remain unqualified. [Current raw results and recovery](https://github.com/adewale/agentic-mermaid/blob/5520235500263602ded1024df60f6ffd217ec227/trinity-fanout-containment-checkpoint-20261109/README.md).

## Current contained-decision TB comparison

Same authored input and original label edit, explicit backend/fallback:none; complete SVG+entire receipts serialized. All60 current timed calls return/P. Two fresh Node24 replicas/cell; source imports, GC, compression and artifact writes are separate. First-target rows are not complete cold startup. No ratio uses ELK's prior refusal.

| Metric | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| Area |159632.56|148833.31|146774.84|
| Written shaft wire / bends / crossings |545.49 /4/0|456.51 /4/0|444.24 /6/0|
| First target cache0 wall ms; import separate |440.70|218.60|282.54|
| Repeat2 cache0 wall / CPU ms |62.30 /115.00|34.70 /66.42|35.48 /89.12|
| Original label edit cache0 wall ms |58.53|28.94|23.68|
| Repeat2 cache1 wall ms |11.62|8.40|7.30|
| Original label edit cache1 wall ms |75.97|42.81|38.06|
| API-return heap cache0repeat2 MiB |53.12–53.23|40.77–40.83|39.13–39.46|
| Lifetime RSS cache0repeat2 MiB |178.35–186.04|171.55–185.96|182.86–184.08|
| Complete response gzip9 / Brotli11 |2857 /2445|2864 /2451|2864 /2455|

Native wins the sampled uncached repeat/cold and edit2 comparisons against Trinity; Trinity retains two extra bends. Ranges overlap. Memory includes harness/imports/retained products, not isolated solver peak or settled retention. Cache0/1 is the existing layout-cache switch; other derived caches remain live and Trinity's kernel has no own cache. No general speed/p95/memory superiority follows.

Forty before/candidate ELK LR control calls retain exact products; edit CPU106.19→106.79ms is adverse. All100 timed serialized lengths match actual gzip9/Brotli11 streams and decode exactly, eight unique products. [All samples, memory, cache observations and exclusions](https://github.com/adewale/agentic-mermaid/blob/5520235500263602ded1024df60f6ffd217ec227/trinity-fanout-containment-checkpoint-20261109/README.md). [Earlier full frozen30 cost report](https://github.com/adewale/agentic-mermaid/blob/86869bd66c21f73db5c33928c242ed7a9b50186b/trinity-frozen-cost-checkpoint-20261109/README.md), source3f2, retains360processes/1248attempts and adverse cached Flowchart/Architecture costs; this narrower case does not replace it.

## Distribution cost

Actual original13-input lazy-browser product union, all three lanes/P. Product bytes exclude the separately retained binding:

| Metric | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| gzip9 bytes |858356|486533|479820|
| Brotli11 bytes |688758|417134|411067|
| Requests including binding |43|49|50|
| Shared-containment gzip / Brotli delta |+24 /+6|+24 /+6|+24 /+6|

Requests are unchanged by this fix. The earlier flat-diamond feature added two requests per lane; closed-scope coverage added112 Trinity gzip bytes. These are fetched module bytes compressed offline, not compressed-wire/startup or total-package measurements. Exact9ec CI standalone gzip1335329 exceeds original1334500 by829 while its render/verify contract passes. Website demo313916gzip exceeds302500. No fresh standalone build here and no raised budget.

## Visual evidence

Baseline SHA: `39135ac82c67d2783e8211ccdb73714e372a4919`.
Current SHA: `c0099d8cebe2d88b31199ec8d67210b349ae558a`. Before, ELK TB/BT refuse and emit no public SVG. The image is actual repaired ELK TB output with manifest-verified Inter and system fonts off; it is not a render of a rejected proposal.

```mermaid
flowchart TB
subgraph Stage[Choose a path]
Q{Decision} -->|left| L[Left]
Q -->|middle| M[Middle]
Q -.->|right| R[Right]
end
```

![Repaired ELK TB frame and complete decision workflow](https://raw.githubusercontent.com/adewale/agentic-mermaid/5520235500263602ded1024df60f6ffd217ec227/trinity-fanout-containment-checkpoint-20261109/repaired-ELK-TB.png)

[Repaired ELK BT](https://raw.githubusercontent.com/adewale/agentic-mermaid/5520235500263602ded1024df60f6ffd217ec227/trinity-fanout-containment-checkpoint-20261109/repaired-ELK-BT.png), [Native TB](https://raw.githubusercontent.com/adewale/agentic-mermaid/5520235500263602ded1024df60f6ffd217ec227/trinity-fanout-containment-checkpoint-20261109/Native-TB.png), [Trinity TB](https://raw.githubusercontent.com/adewale/agentic-mermaid/5520235500263602ded1024df60f6ffd217ec227/trinity-fanout-containment-checkpoint-20261109/Trinity-TB.png), SVGs, receipts, layouts and prior failures are in the [verified checkpoint](https://github.com/adewale/agentic-mermaid/blob/5520235500263602ded1024df60f6ffd217ec227/trinity-fanout-containment-checkpoint-20261109/README.md).

## Verification and remaining losses

Run `bun test src/__tests__/fanout-symmetry.test.ts --timeout 30000`. The new public owner is2P/2F before the fix; four fitting nested-growth controls pass before/after. Current393 owning checks across5files, core/repository types and lint pass. Independent review finds no blocker in snapshot ownership, nested containment, reverse axes or rollback publication. Full suite runs in CI.

[Exact-head CI42622039576](https://github.com/adewale/agentic-mermaid/actions/runs/42622039576) is running; Ruff/pinning pass. [Previous39135ac82 CI](https://github.com/adewale/agentic-mermaid/actions/runs/42615901490) completed/failure: unit shard1, quality, payload, browser-site budget and advisory jobs failed. Unit shards2/3 passed. This PR is not ready.

Remaining: Native compound TB arc/BT no-corridor refusals; Trinity compound TB29 versus ELK13 crossings; controlled images; Sparse32 emitted-proof exhaustion at400k; Native TB/BT marker/halo loss; historical crossing276; adverse cached costs and distribution budgets. The pending-stub, global projection, single source-permutation, cardinal-only boundary, Native late-gap and full-halo producer trials remain stopped/unshipped. Full-halo producer reuse introduced three P→U transitions and head loss0→13, so it is not replayed. Original2dad baseline/equivalent pinned Pele runtime remain unavailable. Replacement24 stays sealed; adoption and retirement are deferred.

[Dated five-hotspot profile and cache inventory](https://github.com/adewale/agentic-mermaid/blob/c0099d8cebe2d88b31199ec8d67210b349ae558a/docs/design/system/layout-0.6-performance-review.md); [prior scalar/heap reuse and mixed costs](https://github.com/adewale/agentic-mermaid/blob/77aa38c73ad6e4846bd7dffdfa95bf56366ff8c0/trinity-lazy-priority-checkpoint-20261109/README.md).
