import json,gzip,collections,re,xml.etree.ElementTree as ET
from pathlib import Path
p=Path('/tmp/pr449-week-comparison-20261101/native-elk-d8c8-comparison');root=Path('/tmp/pr449-week-comparison-20261101/er256-dda69')
a=json.load(gzip.open(root/'agentic-after.json.gz'))['samples'];b=json.load(gzip.open(root/'elk-after.json.gz'))['samples'];assert len(a)==len(b)==874
stats={};cont=collections.Counter();losses={};cohort={}
metrics={'area':lambda s:s['metrics']['routeGeometry']['area'],'wire':lambda s:s['metrics']['routeGeometry']['length'],'bends':lambda s:s['metrics']['routeGeometry']['bends'],'crossings':lambda s:s['metrics']['edgeCrossings'],'labelConflicts':lambda s:s['metrics']['labelConflicts']['total'],'parallelOverlaps':lambda s:s['metrics']['routeOverlaps']['parallel'],'opposingOverlaps':lambda s:s['metrics']['routeOverlaps']['opposing']}
for key,get in metrics.items():
 count=collections.Counter();bad=[]
 for x,y in zip(a,b):
  assert x['id']==y['id'] and x['source']==y['source'];u,v=get(x),get(y);result='Native lower' if u<v else 'equal' if u==v else 'ELK lower';count[result]+=1
  if u>v:bad.append({'id':x['id'],'native':u,'elk':v})
 stats[key]=dict(count);losses[key]=bad
for x,y in zip(a,b):
 n=x['svgReceipt']['layoutCertification']['status'];e=y['svgReceipt']['layoutCertification']['status'];cont[f'{n}/{e}']+=1
for label,select in [('authored corpus234',lambda s:s['id'].startswith('corpus/') or s['id'].startswith('fixture/')),('generated640',lambda s:s['id'].startswith('generated-'))]:
 rows=[(x,y)for x,y in zip(a,b)if select(x)];cohort[label]={'count':len(rows),'vectors':{}}
 for key,get in metrics.items():
  c=collections.Counter('Native lower'if get(x)<get(y)else'equal'if get(x)==get(y)else'ELK lower'for x,y in rows);cohort[label]['vectors'][key]=dict(c)
# Independent literal declarations and relation occurrences for the existing simple generator grammar.
# This deliberately does not reuse the production Mermaid parser or expected values from layout.
meaning=[];unsupported=[]
for x,y in zip(a,b):
 if not x['id'].startswith('generated-'):continue
 nodes=[];edges=[];accepted=True
 for line in x['source'].splitlines()[1:]:
  m=re.fullmatch(r'(n\d+) -->\|([^|]*)\| (n\d+)',line)
  plain=re.fullmatch(r'(n\d+) --> (n\d+)',line)
  definition=re.fullmatch(r'(n\d+)(\[\[|\[\(|\(\(|\[|\{|\()(Node [0-9-]+)(\]\]|\)\]|\)\)|\]|\}|\))',line)
  if m:edges.append((m[1],m[3],m[2]))
  elif plain:edges.append((plain[1],plain[2],''))
  elif definition:nodes.append((definition[1],definition[3]))
  else:accepted=False;unsupported.append({'id':x['id'],'line':line});break
 if not accepted:continue
 for backend,s in [('Native',x),('ELK',y)]:
  doc=ET.fromstring(s['svg']);elements=list(doc.iter());nodeEls=[z for z in elements if z.tag.endswith('}g') and z.attrib.get('class')=='node'];edgeEls=[z for z in elements if z.attrib.get('data-relationship')=='flowchart-edge'];labelEls=[z for z in elements if z.attrib.get('class')=='edge-label']
  actualNodes=[(z.attrib.get('data-id'),' '.join(''.join(t.itertext())for t in z.iter()if t.tag.endswith('}text')))for z in nodeEls]
  actualEdges=[(z.attrib.get('data-from'),z.attrib.get('data-to'),z.attrib.get('data-direction'),z.attrib.get('data-arrow-start'),z.attrib.get('data-arrow-end'))for z in edgeEls]
  expectedEdges=[(u,v,'forward','false','true')for u,v,l in edges]
  actualLabels=[(z.attrib.get('data-from'),z.attrib.get('data-to'),' '.join(''.join(t.itertext())for t in z.iter()if t.tag.endswith('}text')))for z in labelEls]
  expectedLabels=[(u,v,l)for u,v,l in edges if l]
  ids=[z.attrib['id']for z in elements if 'id'in z.attrib];edgeIds=[z.attrib.get('data-id')for z in edgeEls]
  checks={'nodeIdentityAndOwnedText':actualNodes==nodes,'orderedDirectedOccurrences':actualEdges==expectedEdges,'captionOwnersAndActualText':actualLabels==expectedLabels,'uniqueResourceIds':len(ids)==len(set(ids)),'uniqueRelationIds':len(edgeIds)==len(set(edgeIds))}
  meaning.append({'id':x['id'],'backend':backend,'nodeCount':len(nodes),'relationshipCount':len(edges),'captionCount':len(expectedLabels),'checks':checks,'passed':all(checks.values())})
result={'source':'d8c8ac879793a586b4b741c178b89d7900bd27ed','fixedPairs':874,'delivery':{'Native':sum(s['ok']for s in a),'ELK':sum(s['ok']for s in b)},'proofContingency':dict(cont),'qualityVectors':stats,'cohorts':cohort,'meaning':{'cases':len(meaning),'passed':sum(s['passed']for s in meaning),'unsupported':unsupported,'failed':[s for s in meaning if not s['passed']],'coverage':'Literal generated declarations, actual SVG-owned text and directed/parallel occurrence carriers; not pixel visibility proof.234 mixed corpus cases are not assigned independent meaning success by this audit.'},'limitations':['640generated/234mixed cases are not a representative workload weighting','Proof passed is not an independent visible correctness verdict','Named ER256 BT/RL refusals and Sparse32 proofcap remain outside874delivery roster','Original2dad/Trident/pinned Mermaid/Pele unavailable; Replacement24 sealed']}
(p/'CORRECTNESS.json').write_text(json.dumps(result,indent=2)+'\n');(p/'MEANING.json').write_text(json.dumps(meaning,indent=2)+'\n');(p/'ELK-ADVANTAGES.json').write_text(json.dumps(losses,indent=2)+'\n');print(json.dumps(result,indent=2)[:6500])
