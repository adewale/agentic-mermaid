from pathlib import Path
import json,gzip,statistics,collections
p=Path('/tmp/pr449-week-comparison-20261101/native-elk-d8c8-comparison');plan=json.load(open(p/'PLAN.json'));missing=[];processes=[];rows=[]
for run in plan['runs']:
 f=Path(run['out'])/'RESULT.json.gz'
 if not f.exists():missing.append(run['name']);continue
 s=json.load(gzip.open(f));job=s['job'];assert job==json.load(open(run['job']));processes.append(s)
 for r in s['rows']:rows.append(dict(r,case=job['case'],backend=job['backend'],cache=int(s['cache']),replicate=job['replicate'],importMs=s['importMs']))
def stats(values):
 if not values:return None
 return {'n':len(values),'median':statistics.median(values),'min':min(values),'max':max(values)}
summary=[]
for case in plan['cases']:
 for cache in [0,1]:
  for backend in ['agentic','elk']:
   matched=[r for r in rows if r['case']==case and r['cache']==cache and r['backend']==backend];cells={}
   for phase,select in [('cold-render',lambda r:r['phase']=='cold-render'),('repeats',lambda r:r['phase'].startswith('repeat')),('edit',lambda r:r['phase']=='edit1'),('edited-repeat',lambda r:r['phase']=='edit2')]:
    group=[r for r in matched if select(r)];good=[r for r in group if r['status']=='returned'];proof=collections.Counter(r.get('proof',{}).get('status','none')for r in group);perprocess=[]
    for rep in range(4):
     values=[r['wallMs']for r in good if r['replicate']==rep]
     if values:perprocess.append({'replicate':rep,'medianMs':statistics.median(values)})
    cells[phase]={'attempts':len(group),'returned':len(good),'proof':dict(proof),'wallMs':stats([r['wallMs']for r in good]),'cpuMs':stats([r['cpuMs']for r in good]),'heapUsedAfterMiB':stats([r['after']['heapUsed']/1048576 for r in good]),'rssAfterMiB':stats([r['after']['rss']/1048576 for r in good]),'processPeakRSSMiB':stats([r['peakRssKiB']/1024 for r in good]),'perProcessMedians':perprocess,'failures':[{'phase':r['phase'],'replicate':r['replicate'],'failure':r.get('failure')}for r in group if r['status']!='returned']}
   ps=[s for s in processes if s['job']['case']==case and int(s['cache'])==cache and s['job']['backend']==backend];events=collections.Counter((e['owner'],e['outcome'])for s in ps for e in s.get('cacheAudit',{}).get('events',[]));summary.append({'case':case,'cache':cache,'backend':backend,'cells':cells,'importMs':stats([s['importMs']for s in ps]),'cacheAudit':[{'owner':k[0],'outcome':k[1],'count':v}for k,v in events.items()],'repeatSVGExact':all(r.get('wholeSvgExactWarmup')is True for r in matched if r['phase'].startswith('repeat')and r['status']=='returned'),'repeatReceiptExact':all(r.get('entireReceiptExactWarmup')is True for r in matched if r['phase'].startswith('repeat')and r['status']=='returned'),'editChanged':all(r.get('editChanged')is True for r in matched if r['phase'].startswith('edit')and r['status']=='returned')})
comparisons=[]
for case in plan['cases']:
 for cache in [0,1]:
  n=next(s for s in summary if s['case']==case and s['cache']==cache and s['backend']=='agentic');e=next(s for s in summary if s['case']==case and s['cache']==cache and s['backend']=='elk')
  for phase in ['cold-render','repeats','edit','edited-repeat']:
   nc=n['cells'][phase];ec=e['cells'][phase];expected=16 if phase=='repeats'else 4
   comparable=nc['returned']==ec['returned']==expected and nc['proof']==ec['proof']=={'passed':expected}
   nm=nc['wallMs']['median']if nc['wallMs']else None;em=ec['wallMs']['median']if ec['wallMs']else None
   pairs=[{'replicate':a['replicate'],'NativeMs':a['medianMs'],'ELKMs':b['medianMs']}for a in nc['perProcessMedians']for b in ec['perProcessMedians']if a['replicate']==b['replicate']]
   comparisons.append({'case':case,'cache':cache,'phase':phase,'NativeMs':nm,'ELKMs':em,'completePassedPairs':comparable,'NativeOverELK':nm/em if comparable and em else None,'pairedProcessMedians':pairs,'NativeLowerPairs':sum(a['NativeMs']<a['ELKMs']for a in pairs),'pairCount':len(pairs),'qualification':'Comparable ratio requires complete returned products and passed proofs in both cells; all other timings retained descriptively. Four fresh processes per arm; repeated values are within-process samples.'})
result={'source':'d8c8ac879793a586b4b741c178b89d7900bd27ed','processes':len(processes),'missingProcesses':missing,'timedCalls':len(rows),'returned':sum(r['status']=='returned'for r in rows),'postTimedUntimedAudits':len(processes),'summary':summary,'comparisons':comparisons,'scope':'Node24source API. Source imports separate; first render after imports.96sequential fresh processes with alternating order, four/arm/cache/case. Four same-source repeats, one edit, one edited repeat after first call. Sampling and timed observers off; full SVG+entire receipt serialized. ExplicitGC/compression/artifact writes outside timed calls. PeakRSS includes source import/harness/compression and retained first product; not package/browser memory. No representative-workload aggregate speedup.'}
(p/'PERFORMANCE.json').write_text(json.dumps(result,indent=2)+'\n');print('processes',len(processes),'missing',len(missing),'timed',len(rows),'returned',result['returned'])
for cache in [0,1]:
 print('CACHE',cache)
 for case in plan['cases']:
  cs=[r for r in comparisons if r['case']==case and r['cache']==cache and r['phase']in['cold-render','repeats','edit']]
  print(case,[(r['phase'],round(r['NativeMs'],1)if r['NativeMs']else None,round(r['ELKMs'],1)if r['ELKMs']else None,round(r['NativeOverELK'],2)if r['NativeOverELK']else None,str(r['NativeLowerPairs'])+'/'+str(r['pairCount']))for r in cs])
