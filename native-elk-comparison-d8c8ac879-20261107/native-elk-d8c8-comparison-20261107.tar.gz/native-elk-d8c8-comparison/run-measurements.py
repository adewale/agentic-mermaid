from pathlib import Path
import subprocess,os,json,time,gzip
p=Path('/tmp/pr449-week-comparison-20261101/native-elk-d8c8-comparison');plan=json.load(open(p/'PLAN.json'))['runs'];results=[]
for i,job in enumerate(plan):
 out=Path(job['out']);artifact=out/'RESULT.json.gz';log=p/(job['name']+'.log')
 if artifact.exists():
  previous=json.load(gzip.open(artifact));expected=json.load(open(job['job']));assert previous['job']==expected;results.append({'name':job['name'],'status':'existing-completed-pilot','processExit':0});print(i+1,'/',len(plan),job['name'],'retained completed pilot',flush=True);continue
 env=os.environ.copy();env['AGENTIC_MERMAID_ELK_CACHE']=str(job['cache']);start=time.monotonic()
 try:
  with open(log,'wb') as f:r=subprocess.run(['node','--expose-gc',str(p/'measure.mjs'),str(out),job['job']],cwd='/tmp/pr449-main-integration-20261029-762',env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
  row={'name':job['name'],'processExit':r.returncode,'totalProcessWallSec':time.monotonic()-start,'artifactAvailable':artifact.exists()}
 except subprocess.TimeoutExpired:row={'name':job['name'],'status':'harness-timeout120s','totalProcessWallSec':time.monotonic()-start,'artifactAvailable':artifact.exists()}
 results.append(row);(p/'PROCESS-OUTCOMES.json').write_text(json.dumps(results,indent=2)+'\n');print(i+1,'/',len(plan),job['name'],row,flush=True)
(p/'PROCESS-OUTCOMES.json').write_text(json.dumps(results,indent=2)+'\n')
