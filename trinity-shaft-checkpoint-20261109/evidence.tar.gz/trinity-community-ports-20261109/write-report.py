import json,pathlib,collections
out=pathlib.Path(__file__).parent
p=json.load(open(out/'PERFORMANCE.json'));m=json.load(open(out/'SVG-METRICS.json'));b=json.load(open(out/'browser/DELIVERY-COMPARISON.json'));v=json.load(open(out/'VISUAL-INK.json'))
text='''# Labelled compound routes: cause, recovery and costs

Runtime **e928a1847ef773058f62e36122780a81fcd928f7**; source/report head **96d10ff95**. Baseline **680d01bc579fd4d1ef2b92bceb29fe4f54eb03b9**. Supplemental input: first Mermaid block from Pele PR97 (closed/unmerged), six authored leaves, two groups and eight labelled edges. Exact source/options/edit in `community-ports-*-job.json`; this is not a Pele runtime comparison or a change to the frozen30 denominator. Deadline9 November2026,20:00UTC. Automations remain off; bounded execution only.

## What changed

Trinity refused the LR input at the cumulative visibility-expansion limit. Baseline capture identifies third-edge search spending12,844→31,215 expansion units before self-contact refusal and a successful direct fallback. Direct-first and a prefix-preserving index2 search subtraction both still refuse the eighth edge. The latter saves18,371 units yet ends with ample physical capacity. Neither diagnostic ships.

A rejection capture then finds57 complete eighth-edge candidates rejected by the unchanged measured contact predicate; every candidate conflicts with committed edge5 (`a2→b3`). Candidate terminal leads and retained labels were valid. These are existing-predicate diagnostics, not independent ink qualification or geometric-impossibility proof.

The shared boundary router had retained temporary ancestor-border bends as well as the actual label shaft. Keep the measured label-bearing segment, and reconnect actual descendants to it through existing bounded routing. Preserve original escape offsets when a shaft endpoint coincides with a quotient border. Charge every scanned segment against the same work ledger. No cache, limit, default, version or acceptance gate changes.

## Delivery, meaning and final ink

Four direction owners: baseline4F, candidate4P. All four Trinity sources return/proof-pass, retain six leaf identities, group membership, eight authored endpoint/label occurrences and deterministic full products. ELK returns all four; Native returns LR/RL and refuses TB/BT. All ten returned SVGs pass the unmodified Tridentf080 paint and quantitative observers, with no failed/unavailable observer checks. That finite observation does not qualify every workload or replace authored meaning with a certificate.

Frozen delivery stays ELK28/Native28/Trinity26 of30, two shared input errors and two Trinity unsupported inputs retained. All39 affected frozen cohort SVGs/outcomes remain exact: validation, not new delivery progress. Native compound replay33/34 exact. The changed flattened Class namespace case keeps area220248, wire640→618 and bends12→6, passed proof and before/after actual Trident ink without failed checks. Initial anchor regression was reproduced and repaired; its failure capture remains.

213 primary/kernel/cache owners pass. Nearby owners211 pass; the added Class guard initially used incomplete member-text expectations, then passes after including the written visibility prefix. Core/repository types, lint, actual editor/lazy builds pass. Sandbox Chromium/esbuild child-pipe failures and their scoped outside-sandbox retries remain in logs. Independent read-only review found the missing scan charge, then no remaining blocker after that and the anchor repair.

## Actual SVG quality

Widths, wire, bends, crossings and overlaps are read from the actual returned SVG using existing helpers. Proper crossings are visible/countable, not automatically correctness failures. Adverse quality remains, particularly TB Trinity29 crossings versus ELK13.

| Direction | Backend | Area | Wire | Bends | Crossings | Parallel / opposing overlaps |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
'''
for r in m:text+=f"|{r['id']}|{r['backend']}|{r['area']:.2f}|{r['wire']:.2f}|{r['bends']}|{r['crossings']}|{r['parallelOverlaps']} / {r['opposingOverlaps']}|\n"
text+='''
Native TB/BT failures are explicit in `DIRECTIONS.json`; missing SVGs have no invented quality zeros. Images are actual browser screenshots, not a universal readability result.

## Equivalent complete-product costs

Twelve serial fresh Node24 processes: three backends ×two cache settings ×two process replicas; cold, repeat1/2 and edit1/2 separately,60 attempts. **52 returned/proof-passed; eight Native edited attempts refused** at expansion capacity. Full SVG and entire receipt serialized. Imports, explicit GC, compression and artifact writes outside render windows; sampling and observers off. Cache0 still allows existing derived caches. Two replicas of one input establish no general ratio, percentile, throughput or memory superiority.

Native error timings are refused-work costs, not comparable completed edits. The collector's raw `editChanged` boolean can be true when a product is missing; the corrected summary requires returned products and records those edit comparison cells as unavailable. No acquisition was rerun to conceal the failures.

| Cache | Backend | Cold / repeat2 / edit2 wall median ms | Process CPU median ms | Edit outcome |
| --- | --- | --- | --- | --- |
'''
for r in p['rows']:
 keys=['cold-render','repeat2','edit2'];wall='/'.join(f"{r['phases'][k]['wallMs']['median']:.2f}" for k in keys);cpu='/'.join(f"{r['phases'][k]['cpuMs']['median']:.2f}" for k in keys);status='refused; timing is unequal work' if r['backend']=='agentic' else 'returned/proof-passed'
 text+=f"|{r['cache']}|{r['backend']}|{wall}|{cpu}|{status}|\n"
text+='''
Returned originals repeat exactly in all lanes. ELK/Trinity edits change the SVG and repeat exactly; Native edits remain unavailable. Cache1 edit wall favors ELK41.99ms versus Trinity49.91ms. Process CPU includes all threads and can exceed wall time.

| Cache | Backend | Process peak RSS KiB range | Heap-used-after snapshots MB range |
| --- | --- | ---: | ---: |
'''
for r in p['rows']:
 vals=r['phases'].values();lo=min(v['peakRssKiB']['range'][0] for v in vals);hi=max(v['peakRssKiB']['range'][1] for v in vals);hl=min(v['heapUsedAfter']['range'][0] for v in vals)/1e6;hh=max(v['heapUsedAfter']['range'][1] for v in vals)/1e6;text+=f"|{r['cache']}|{r['backend']}|{lo}–{hi}|{hl:.2f}–{hh:.2f}|\n"
text+='''
RSS includes harness/imports and retained artifacts. Snapshots are not heap peaks, allocation rate, settled retention or leak results. Native ranges include its refused edit work.

Actual original SVG+entire receipt JSON, Node24 gzip9/Brotli11:

| Backend | Raw / gzip9 / Brotli11 bytes |
| --- | ---: |
'''
for r in p['rows']:
 if r['cache']=='0':
  w=r['wholeProduct'][0];text+=f"|{r['backend']}|{w['raw']} / {w['gzip9']} / {w['brotli11']}|\n"
text+='''
## Actual lazy delivery and editor cost

Same12 family/feature inputs as the prior milestone, fully consumed SVG+receipt browser binding. All three lanes pass. Served raw files, with Node24 gzip9/Brotli11 compression after observation; not compressed network transfer or startup latency. Wrapper bytes remain separately reported in `browser/DELIVERY-COMPARISON.json`.

| Backend | Product raw / gzip9 / Brotli11 bytes | Requests including binding |
| --- | ---: | ---: |
'''
for r in b:
 w=r['product'];text+=f"|{r['backend']}|{w['raw']} / {w['gzip9']} / {w['brotli11']}|{r['requests']}|\n"
text+='''
Matched Bun1.4.4 editor gzip1342789→1342154 (−635), Brotli1282069→1281810 (−259). The original1334500 gzip ceiling still fails7654. Different build products/compressors can have different deltas; no cache/default/version/cap change.

## Profile and next intervention

The pristine before profile retains nine attempts, self/inclusive source mapping, long-gap sensitivity and failed Trinity work. See `docs/design/system/layout-0.6-performance-review.md` for the five measured frames and existing cache inventory. Hot heap/state pages use Maps over typed SoA storage; a bounded flat page-reference directory is one possible later measured subtraction, not five separate rewrites. No speedup estimate is invented and no such optimization ships. A refused profile cannot justify a completed-render speed ratio.

Next work must address a demonstrated remaining workload or quality loss. Frozen Class namespace/cardinality/note and controlled image remain unsupported; broad capacity, adverse crossings, memory behavior, original editor/lazy/website budgets and exact-head CI readiness remain unresolved. Retain ELK; Replacement24 stays sealed. Original2dad/pinnedPele runtime comparisons remain unavailable. Do not replay the stopped strategy-order tests as progress.

## Reproduction and recovery

Use the existing Bun1.4.4 at `/tmp/pr449-tools-20261106/package/bin/bun` from the worktree. `qualify.ts` reproduces all direction products; `observe.ts` invokes the existing Trident paint observers on actual SVG. `capture.py`, `trial.py`, `label-shaft.py`, `rejections.py` and `contact-attribution.ts` retain causal diagnostic overlays outside source. Index-specific/strategy-order overlays do not ship. `run-cost.py` uses the existing source-runtime collector; `summarize-cost.mjs` preserves errors. Browser artifacts/scripts and actual byte manifests are retained.

No new qualification framework or source-tree fingerprint. The evidence archive verifies member bytes and contains the raw profiles/products, logs, failures, scripts and source-pinned research pointers. Source/runtime milestone pushed to existing PR602; no new PR/issues or external comments/messages.
'''
(out/'README.md').write_text(text)
