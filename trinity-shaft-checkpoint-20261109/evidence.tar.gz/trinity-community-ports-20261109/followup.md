# Follow-up: strategy-order hypothesis is insufficient

Read-only analysis of completed `trace-before.jsonl`, `trace-direct-first.jsonl`, `trace-skip-third.jsonl` and the two diagnostic cold-render error records. No new renderer/profile/build runs or source changes.

**Stop strategy-order tuning as the proposed recovery for this witness.** Both diagnostics reach the last edge and still refuse `cross-hierarchy route has no bounded clear corridor`. The targeted diagnostic rules out the broad trial's changed first-two routes as the sole explanation.

| First captured invocation | Outcome | Expansion evidence |
|---|---|---|
| Baseline | Refuses visibility expansion at edge index 5 | Third edge's primary consumes 12,844 → 31,215, then declines for self-contact. |
| Broad direct-first | Refuses clear corridor at edge index 7 | Enters last edge at 2,652; last logged reservation completes at 4,717. |
| Skip only index 2 primary | Refuses clear corridor at edge index 7 | Enters last edge at 14,910; last logged reservation completes at 16,975. |

The index-2 bypass is a nonshipping causal ceiling, not an acceptable index-specific policy. It avoids **18,371** primary expansion units while preserving the prefix through the third edge's entry. The third edge's `direct-after.points` is exactly equal to the baseline's ten-point direct result. At index 3, expansion is 12,879 instead of 31,250, confirming that the removal saves real earlier allocation rather than resetting accounting.

This is useful attribution: wasted primary allocation masked a later geometry/candidate-domain failure. It is not sufficient delivery improvement. The targeted trial still fails with substantial physical expansion, pair and arc capacity remaining (final reported pairs 421,970; arcs 34,889). The primary virtual envelope remains a separate eligibility restriction: at index 3, `primaryVirtual=18,328` plus grid virtual size 14,850 exceeds 32,768 even though actual expansion is only 12,879. Do not conflate this envelope with allocated vertices or remove it to make the diagnostic pass.

## Remaining causal boundary

The remaining refusal is for `a2 → b4` (edge index 7), after earlier routes have committed. It does **not** prove geometric impossibility: the bounded source/target/guided/late terminal search can fail because its domain or acceptance constraints miss a route. Conversely, the generic final reason does not identify which contact, retained-label corridor or terminal lead rejects proposals. Neither trace currently supplies that rejection attribution.

No smaller production intervention is justified from these outcomes. In particular, do not generalize an index-2 bypass, selectively forgive its expansion, change counts to live memory, or enlarge late terminal search. The next useful bounded observation, if the coordinator continues, is the first decisive rejection for index 7 under the prefix-preserving diagnostic: identify its actual terminal pair/path, blocker or retained-label condition, and whether rejection occurs before a complete candidate exists. That would distinguish an upstream quotient/port-placement problem from a search-domain omission. Only then choose one geometry intervention.

Pele's constrained border-port alignment remains relevant background, but these diagnostics do not establish that applying it would produce an admissible final route. The original cap, physical metadata, exact contact predicates, labels and independent ink obligations remain unchanged. Both diagnostics are failures, not shipping improvements or qualified performance comparisons.
