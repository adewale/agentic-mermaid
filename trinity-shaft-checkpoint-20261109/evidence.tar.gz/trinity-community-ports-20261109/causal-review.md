# Community port witness: bounded causal review

Source `680d01bc579fd4d1ef2b92bceb29fe4f54eb03b9`; read-only review, 2026-11-09. No renderer, profiler, build, source changes or new framework. Evidence is `trinity-compound-20261109/COMMUNITY-PORT-PROBE.json`: six leaves, two groups, eight labelled cross-group edges; Trinity refuses at the visibility-expansion limit. Native/ELK return with passed public proof, but their ink is not independently qualified here.

**One candidate for the coordinator's capture-gated trial: try the existing fully validated paired direct-corridor proposal before allocating the small-graph primary visibility grid. Do not change placement, terminal supports, labels, candidate inventory or limits.** This is a falsifiable strategy-order hypothesis, not a demonstrated fix.

## First resource-consuming stage implicated by source

The adapter delegates genuine local solves through `trinity-compound.ts:27–52`; `trinity.ts:297` returns `expandedVertices: widths.length`, including private vertices. `agentic-compound-core.ts:99–101` sums those counts across scopes, then calls the shared boundary router at line 133. None of these counts may be replaced by leaf counts or reset before boundary routing.

`routeCrossHierarchy` starts from that accumulated count (`compound-boundary-routes.ts:681–689`). With two groups/eight lifted edges, the small-graph primary is eligible (`676–679, 801`). Its cheap-direct preflight is reserved for `leafCount > 64` (`804–808`), so this six-leaf witness proceeds directly to the lazy Cartesian grid (`810–818`). Grid coordinate sets include node/frame/label/peer-route obstacle coordinates, terminal ports/stubs and quotient anchors. Its virtual envelope is `3 * xs.length * ys.length`; actual point/state/heap pages reserve expansion separately (`compound-lazy-visibility.ts:18–23, 45–66, 99–120`).

The final exception string does **not** reveal whether the decisive failure was the primary virtual-envelope gate, physical page allocation, or a later sparse/endpoint allocation. The existing JSON does not identify a failing edge or reservation amount. Treat that attribution as unknown until capture. Earlier attempted allocations still consume the shared ledger even when a later strategy handles the same edge.

## Exact intervention boundary and counterfactual

Reuse the existing labelled two-sided direct proposal, not the weaker independent endpoint paths from the large-graph preflight. Its whole-path `accept` at `compound-boundary-routes.ts:844–869` checks terminal identity/outward normal/lead, retained label-on-shaft and measured peer contacts. `finish` at `871–883` assembles both endpoint corridors with the unchanged quotient core. In the physical-metadata branch the existing labelled invocation is deferred in `legacyDirect` (`885–911`), reached at `1064` after the primary and sparse preparation.

The trial would make that same bounded paired proposal eligible before `createLazyVisibilityGrid`, retaining the same label core, measured acceptance and final contact checks. Spend its existing probe allowance once; do not run it again with a fresh reserve after failure. Preserve all pair/arc/expansion charging, later fallbacks and peer publication. Selecting a different valid route can change later geometry, so output equality is not presumed.

Counterfactual: if one or more early lifted edges have an admissible short paired corridor, choosing it first can avoid primary pages and subsequent sparse setup, leaving capacity for the remaining edges. If those corridors are genuinely blocked, merely moving their bounded tests earlier provides no capacity benefit and may consume extra pairs before the old strategy succeeds.

The fixture's eight edges cross **both** groups. The specialized retained-label proposal at `1056–1061` requires `!crossingSource && crossingTarget`, so simply promoting that one-sided proposal is not applicable.

## Required capture and stop conditions

Before any intervention, capture per lifted edge: original descendant IDs, quotient ports/core/label, source/target terminal sets; incoming `expanded`, `primaryVirtual`, pair/arc balances; virtual grid size; actual reservations and exact failing caller; and whether the existing paired direct attempt accepts or rejects. Keep local solver expanded counts separate from visibility allocations.

Proceed only if this shows material primary/search allocation preceding a direct candidate that could have been accepted at the same earlier geometry, or a bounded counterfactual establishes that candidate. **Stop this hypothesis** if no early paired corridor is admissible, primary virtual rejection consumed no relevant physical capacity and the same sparse allocation still fails, or the direct-first result needs weaker terminal/label/contact checks. Also stop on new routing refusals or loss of authored identities, label association, frame containment or independent final ink. Do not raise 32,768 or erase failed-attempt work.

## What Pele contributes—and what it does not prove

Pinned Pele `3a2f075ee0c3d914f0fad3545fc0f193693975ac` calls `alignPorts` in `src/layout/layered.ts:549`. Its implementation at `1020–1045` aligns border ports to actual neighboring endpoint offsets only when the entire border rank can move without passing/meeting neighboring ports. This supports the narrow lesson to exploit a demonstrated clear terminal corridor before general routing, while retaining port-order/spacing constraints. It does not prove this witness has such a corridor under our paint contract.

Trinity already includes endpoint offsets in coordinate alignment (`trinity.ts:216–245`); “add port-aware alignment” is therefore too broad and partly redundant. The lifted quotient does lose descendant-specific port semantics, but changing that model is a larger placement intervention than this first bounded trial and is not established by the refusal alone. PR97's closed/unmerged discussion supplies the witness; the pinned implementation independently supplies the alignment mechanism. Neither is a qualified Pele-versus-Trinity benchmark. Native's sparser physical metadata is not a valid reason to weaken Trinity's obligations.
