import pathlib,json
out=pathlib.Path('/tmp/pr449-week-comparison-20261101/trinity-community-ports-20261109')
s=(out/'compound-boundary-routes.capture.ts').read_text().replace('trace-before.jsonl','trace-direct-first.jsonl')
s=s.replace('if (!directOnly) try {','if (!directOnly && !(widthProof !== undefined && edge.label && crossingSource && crossingTarget)) try {')
needle='        if (!points) try {\n          const sparseTerminals'
assert s.count(needle)==1
s=s.replace(needle,"        if (legacyDirect) { diagnostic('early-direct-before',{index,expanded,work,probes}); legacyDirect(); legacyDirect = undefined; diagnostic('early-direct-after',{index,expanded,work,probes,points}) }\n"+needle)
p=out/'compound-boundary-routes.direct-first.ts';p.write_text(s)
j=json.load(open(out/'capture-job.json'));j['moduleOverrides']={next(iter(j['moduleOverrides'])):str(p)}
(out/'direct-first-job.json').write_text(json.dumps(j))
