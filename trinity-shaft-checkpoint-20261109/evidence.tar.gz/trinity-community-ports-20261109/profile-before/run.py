import pathlib,os,subprocess,json
p=pathlib.Path(__file__).parent;records=[]
for i,case in enumerate(['community-ports']):
 backends=['elk','agentic','trinity'];backends=backends[i%3:]+backends[:i%3]
 for backend in backends:
  name=case+'-'+backend
  with (p/(name+'.log')).open('w') as log:r=subprocess.run(['node','--expose-gc',str(p/'worker.mjs'),str(p/name),str(p/(name+'-job.json'))],env={**os.environ,'AGENTIC_MERMAID_ELK_CACHE':'0'},stdout=log,stderr=subprocess.STDOUT)
  records.append({'case':case,'backend':backend,'exit':r.returncode});print(records[-1],flush=True)
  if r.returncode:raise SystemExit(r.returncode)
(p/'RUNS.json').write_text(json.dumps({'runtime':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runs':records,'scope':'Current runtime; one community case, three backends, two profiled repeats and edit;9 profiled API attempts, including retained Trinity refusals; successful calls consume SVG+entire receipt, separate from all unprofiled timing/browser/build work. One unprofiled warmup attempt per fresh process, including failures. Refused and completed timings are not comparable work. Layout-cache flagoff; derived caches remain. Cold-render cause not isolated by this steady profile.'},indent=2)+'\n')
