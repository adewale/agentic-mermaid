from pathlib import Path
import json,gzip
out=Path('/tmp/pr449-week-comparison-20261101/trinity-community-ports-20261109')
for before,p in [(True,out.parent/'outcome-plan-a195-20261107/agentic-after.json.gz'),(False,out/'agentic-compound-final.json.gz')]:
 x=json.loads(gzip.decompress(p.read_bytes()));r=next(r for r in x['samples'] if r['id']=='corpus/class/19');(out/'products'/('class-before.svg' if before else 'class-after.svg')).write_text(r['svg'])
s=(out/'observe.ts').read_text();a=s.index('const out=');b=s.index('\nconst fonts=',a)
s=s[:a]+'''const out=import.meta.dir,root='/tmp/pr449-main-integration-20261029-762',products=['before','after'].map(direction=>({direction,backend:'agentic',status:'returned',stem:'class-'+direction,source:JSON.parse(readFileSync(out+'/class-job.json','utf8')).source})),rows:any[]=[]
const expected={labels:['Developer','Designer','CEO','oversees','writeCode()','createMockup()','makeDecisions()'],nodes:['Developer','Designer','CEO'].map(id=>({id,label:id})),edges:['Developer','Designer'].map(target=>({source:'CEO',target,label:'oversees',directed:true})),groups:[{id:'Company.Engineering.Backend',label:'Company.Engineering.Backend',members:['Developer']},{id:'Company.Engineering.Frontend',label:'Company.Engineering.Frontend',members:['Designer']},{id:'Company',label:'Company',members:['CEO']}]}'''+s[b:]
s=s.replace("family:'flowchart'","family:'class'").replace("facts:{direction:r.direction}","facts:{direction:'TB'}").replace('VISUAL-INK.json','CLASS-INK.json').replace('VISUAL-BROWSER.json','CLASS-BROWSER.json')
(out/'observe-class.ts').write_text(s)
