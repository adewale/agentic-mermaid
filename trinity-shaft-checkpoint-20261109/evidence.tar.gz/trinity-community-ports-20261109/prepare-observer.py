from pathlib import Path
out=Path('/tmp/pr449-week-comparison-20261101/trinity-community-ports-20261109');prior=out.parent/'trinity-compound-20261109'
s=(prior/'visual-compound.ts').read_text()
a=s.index('const out=');b=s.index('\nconst fonts=',a)
s=s[:a]+'''const out=import.meta.dir,root='/tmp/pr449-main-integration-20261029-762',products=JSON.parse(readFileSync(out+'/DIRECTIONS.json','utf8')),rows:any[]=[]
const expected={labels:['A','B','a1','a2','b1\\ntwo\\nthree','b2\\ntwo\\nthree','b3\\ntwo\\nthree','b4\\ntwo\\nthree\\nfour','label'],nodes:[{id:'a1',label:'a1'},{id:'a2',label:'a2'},...['b1','b2','b3','b4'].map(id=>({id,label:id+'\\ntwo\\nthree'+(id==='b4'?'\\nfour':'')}))],edges:['b1','b2','b3','b4'].flatMap(target=>['a1','a2'].map(source=>({source,target,label:'label',directed:true}))),groups:[{id:'A',label:'A',members:['a1','a2']},{id:'B',label:'B',members:['b1','b2','b3','b4']}]}'''+s[b:]
a=s.index('for(const r of products.filter');b=s.index('let paint,quantitative,observerError',a)
s=s[:a]+"for(const r of products){const c={family:'flowchart',expected:{...expected,facts:{direction:r.direction}},source:r.source,paint:undefined};"+s[b:]
s=s.replace("r.delivery==='returned'","r.status==='returned'").replace("r.backend+'-nested-'+r.family+'.png'","r.stem+'.png'").replace('id:r.id,family:r.family,backend:r.backend,delivery:r.delivery','direction:r.direction,family:c.family,backend:r.backend,delivery:r.status').replace('console.log(r.id,r.backend,r.delivery','console.log(r.direction,r.backend,r.status')
(out/'observe.ts').write_text(s)
