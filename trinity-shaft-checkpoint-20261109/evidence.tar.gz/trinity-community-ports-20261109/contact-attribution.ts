import {readFileSync,writeFileSync} from 'node:fs'
import {scoreMeasuredRouteProposalCrossings} from '/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts'
const dir='/tmp/pr449-week-comparison-20261101/trinity-community-ports-20261109'
const rows=readFileSync(dir+'/trace-rejections.jsonl','utf8').trim().split('\n').map(x=>JSON.parse(x))
const input=rows.find(r=>r.event==='input').data.input
const result=rows.filter(r=>r.event==='accept-reject'&&r.data.reason==='contact').map(({data},ordinal)=>({ordinal,candidate:data.candidate,blockedBy:data.routes.flatMap((peer,j)=>j===7||peer.style==='invisible'?[]:scoreMeasuredRouteProposalCrossings(data.candidate,7,data.routes.map((r,k)=>({...r,style:k===j?r.style:'invisible'})),input)===undefined?[j]:[])}))
writeFileSync(dir+'/CONTACT-ATTRIBUTION.json',JSON.stringify({scope:'Offline diagnostic only. Existing measured contact predicate, each peer isolated; no public render or independent ink qualification. Original full predicate already rejected all57 candidates.',inputEdge:input.edges[7],result},null,2))
console.log(JSON.stringify({attempts:result.length,blockedBy:result.reduce((a,r)=>{for(const j of r.blockedBy)a[j]=(a[j]??0)+1;return a},{}),first:result[0]},null,2))
