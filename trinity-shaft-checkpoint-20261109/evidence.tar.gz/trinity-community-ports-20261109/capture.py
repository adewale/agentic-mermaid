import pathlib,json
root=pathlib.Path('/tmp/pr449-main-integration-20261029-762')
out=pathlib.Path('/tmp/pr449-week-comparison-20261101/trinity-community-ports-20261109')
p=root/'src/layout/compound-boundary-routes.ts'
s=p.read_text()
s="import { appendFileSync as diagnosticAppend } from 'node:fs'\nlet diagnosticCaptured = false\n"+s
needle="  const leafCount = input.nodes.length, frames = placed.groups!, groups = input.groups!"
assert s.count(needle)==1
s=s.replace(needle,"""  const diagnosticActive = !diagnosticCaptured; diagnosticCaptured = true
  const diagnostic = (event: string, data: unknown) => { if (diagnosticActive) diagnosticAppend('/tmp/pr449-week-comparison-20261101/trinity-community-ports-20261109/trace-before.jsonl', JSON.stringify({event,data})+'\\n') }
  const diagnosticFail = fail
  fail = reason => { diagnostic('fail',{reason,work,stack:new Error().stack}); return diagnosticFail(reason) }
  diagnostic('input',{input,placed,owners:[...owners],lifted:[...lifted],directions,work,expansionLimit})
"""+needle)
s=s.replace("    if (expanded + amount > expansionLimit) fail(","    diagnostic('reserve',{amount,expanded,expansionLimit,work,stack:new Error().stack})\n    if (expanded + amount > expansionLimit) fail(")
s=s.replace("      const edge = input.edges[index]!, raw = placed.edges[index]!","      diagnostic('edge',{index,paddingAttempt,expanded,primaryVirtual,work})\n      const edge = input.edges[index]!, raw = placed.edges[index]!")
s=s.replace("      let points: Point[] | undefined\n      let rejected", "      diagnostic('geometry',{index,start,end,core,sources,targets,bounds,quotient,label:raw.labelPosition})\n      let points: Point[] | undefined\n      let rejected")
s=s.replace("          // Preserve the old primary's eligibility.","          diagnostic('grid',{index,expanded,remaining,primaryVirtual,virtualVertices:grid.virtualVertices,work})\n          // Preserve the old primary's eligibility.")
s=s.replace("        decline = error.reason\n        points = undefined", "        diagnostic('primary-decline',{index,expanded,primaryVirtual,reason:error.reason,work})\n        decline = error.reason\n        points = undefined")
s=s.replace("            if(!points&&legacyDirect)legacyDirect()", "            if(!points&&legacyDirect){diagnostic('direct-before',{index,expanded,work,probes});legacyDirect();diagnostic('direct-after',{index,expanded,work,probes,points})}")
copy=out/'compound-boundary-routes.capture.ts';copy.write_text(s)
j=json.load(open(out/'profile-before/community-ports-trinity-job.json'));j.update(profile=False,observers=False,phases=['repeat1','repeat2','edit','edit2'],moduleOverrides={str(p):str(copy)})
(out/'capture-job.json').write_text(json.dumps(j))
