import pathlib,json
out=pathlib.Path('/tmp/pr449-week-comparison-20261101/trinity-community-ports-20261109')
s=(out/'compound-boundary-routes.skip-third.ts').read_text().replace('trace-skip-third.jsonl','trace-rejections.jsonl')
a=s.index('        const accept = (path: Point[]): Point[] | undefined => {');b=s.index('\n        if (rejected)',a)
part=s[a:b]
part=part.replace('          const candidate =',"          if(index===7) diagnostic('accept-attempt',{path})\n          const candidate =",1)
part=part.replace('if (candidate.length < 2) return',"if (candidate.length < 2) { if(index===7)diagnostic('accept-reject',{reason:'length'}); return }")
part=part.replace('if (endpoint.x !== port.x || endpoint.y !== port.y || !onSegment(stub, endpoint, next)) return',"if (endpoint.x !== port.x || endpoint.y !== port.y || !onSegment(stub, endpoint, next)) { if(index===7)diagnostic('accept-reject',{reason:'terminal-lead',source,candidate,path}); return }")
part=part.replace('if (endpoint.x < box.x - 1e-7 || endpoint.x > box.x + box.width + 1e-7 || endpoint.y < box.y - 1e-7 || endpoint.y > box.y + box.height + 1e-7) return',"if (endpoint.x < box.x - 1e-7 || endpoint.x > box.x + box.width + 1e-7 || endpoint.y < box.y - 1e-7 || endpoint.y > box.y + box.height + 1e-7) { if(index===7)diagnostic('accept-reject',{reason:'terminal-box',source,candidate}); return }")
part=part.replace('if (!outward) return',"if (!outward) { if(index===7)diagnostic('accept-reject',{reason:'outward',source,candidate}); return }")
part=part.replace('if (edge.label && !candidate.some((point, cursor) => cursor > 0 && onSegment(raw.labelPosition!, candidate[cursor - 1]!, point))) return',"if (edge.label && !candidate.some((point, cursor) => cursor > 0 && onSegment(raw.labelPosition!, candidate[cursor - 1]!, point))) { if(index===7)diagnostic('accept-reject',{reason:'label-corridor',candidate}); return }")
part=part.replace('return contactsClear(candidate) ? candidate : undefined',"const clear=contactsClear(candidate); if(index===7)diagnostic(clear?'accept-pass':'accept-reject',{reason:'contact',candidate,routes}); return clear ? candidate : undefined")
s=s[:a]+part+s[b:]
s=s.replace('              if (!hasEligibleRoot(roots)) {',"              const eligible = hasEligibleRoot(roots); if(index===7)diagnostic('source-roots',{eligible,roots,interiorChannels});\n              if (!eligible) {")
s=s.replace('const ordinarySource = (first: Point[]): boolean => { sourcePaths.push(first);',"const ordinarySource = (first: Point[]): boolean => { if(index===7)diagnostic('source-path',{first}); sourcePaths.push(first);")
s=s.replace('              const join = (last: Point[]): boolean => {',"              const join = (last: Point[]): boolean => { if(index===7)diagnostic('target-path',{first,last});")
s=s.replace("diagnostic('fail',{reason,work,stack:new Error().stack})","diagnostic('fail',{reason,work,placed,stack:new Error().stack})")
p=out/'compound-boundary-routes.rejections.ts';p.write_text(s)
j=json.load(open(out/'capture-job.json'));j['moduleOverrides']={next(iter(j['moduleOverrides'])):str(p)};(out/'rejections-job.json').write_text(json.dumps(j))
