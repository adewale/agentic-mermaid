import pathlib,json
out=pathlib.Path('/tmp/pr449-week-comparison-20261101/trinity-community-ports-20261109')
s=(out/'compound-boundary-routes.capture.ts').read_text().replace('trace-before.jsonl','trace-label-shaft.jsonl')
s=s.replace('      const start = crossingSource ?', '      let start = crossingSource ?').replace('      const end = crossingTarget ?', '      let end = crossingTarget ?').replace('      const core = [start, ...quotient.slice(1, -1), end]', '''      let core = [start, ...quotient.slice(1, -1), end]
      let labelShaftOnly=false
      if(widthProof!==undefined && edge.label && crossingSource && crossingTarget){
        const cursor=quotient.findIndex((point,i)=>i>0 && onSegment(raw.labelPosition!,quotient[i-1]!,point))
        if(cursor>0){start=quotient[cursor-1]!;end=quotient[cursor]!;core=[start,end];labelShaftOnly=true}
      }''')
s=s.replace('        // A pending quotient still terminates', '        if(labelShaftOnly){routeStart=start;routeEnd=end;routeCore=core}\n        // A pending quotient still terminates')
p=out/'compound-boundary-routes.label-shaft.ts';p.write_text(s)
j=json.load(open(out/'capture-job.json'));j['moduleOverrides']={next(iter(j['moduleOverrides'])):str(p)};(out/'label-shaft-job.json').write_text(json.dumps(j))
