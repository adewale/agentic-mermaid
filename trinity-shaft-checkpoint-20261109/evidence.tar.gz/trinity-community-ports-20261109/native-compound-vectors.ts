import {readFileSync,writeFileSync} from 'node:fs'
import {gzipSync,gunzipSync} from 'node:zlib'
import {snapshotSample} from '/tmp/pr449-main-integration-20261029-762/eval/layout-compare/run.ts'
const root='/tmp/pr449-week-comparison-20261101',p=process.argv[2]??root+'/ranked-losses-ce15';
const backend=process.argv[3]??'agentic';
const old=JSON.parse(gunzipSync(readFileSync(root+'/outcome-plan-a195-20261107/'+backend+'-after.json.gz')).toString());
const cohorts=JSON.parse(readFileSync(root+'/compare-rebase-433b/PAIRED-CURRENT.json','utf8')).cohorts;
let offset=0;const rows=[];
for(const cohort of cohorts){for(let i=0;i<cohort.count;i++){
 const before=old.samples[offset+i]; if (!/subgraph|namespace|architecture-beta/.test(before.source)) continue; const after=snapshotSample(before,`lc${i}-`,{graphLayout:{backend}},{includeAscii:before.ascii!==undefined});
 rows.push(after);
 if(!after.ok||after.svgReceipt?.layoutCertification?.status!==before.svgReceipt?.layoutCertification?.status)console.log('outcome',before.id,before.ok,after.ok,before.svgReceipt?.layoutCertification?.status,after.svgReceipt?.layoutCertification?.status,after.error);
 if(rows.length%100===0)console.log('completed',rows.length);
}offset+=cohort.count}
writeFileSync(p+'/'+backend+'-compound-final.json.gz',gzipSync(JSON.stringify({...old,label:'Trinity compound growth consumer qualification after21194248b',dirty:true,samples:rows}),{level:9}));
const summary=rows.map((s:any)=>{const prior=old.samples.find((x:any)=>x.id===s.id);return{id:s.id,before:prior.metrics?.routeGeometry,after:s.metrics?.routeGeometry,beforeProof:prior.svgReceipt?.layoutCertification?.status,afterProof:s.svgReceipt?.layoutCertification?.status,beforeOk:prior.ok,afterOk:s.ok,svgExact:s.svg===prior.svg,metrics:s.metrics,failures:s.failures}});
writeFileSync(p+'/'+backend+'-COMPOUND-FINAL.json',JSON.stringify(summary,null,2));console.log('saved',rows.length)
