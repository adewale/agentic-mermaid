/** Qualify at existing constructor freeze sites, bottom-up. Unknown mutable
 * fields and accessors cannot become authority through a shallow freeze. */
const immutableSet = WeakSet, immutableApply = Reflect.apply
const immutableHas = WeakSet.prototype.has, immutableAdd = WeakSet.prototype.add
const immutableFreeze = Object.freeze, immutableFrozen = Object.isFrozen, immutableKeys = Reflect.ownKeys
const immutableDescriptor = Object.getOwnPropertyDescriptor, immutableOwn = Object.hasOwn
const immutableMapGet = WeakMap.prototype.get, immutableMapSet = WeakMap.prototype.set
const immutableDefine = Object.defineProperty, immutablePrototype = Object.getPrototypeOf, immutableArray = Array.isArray
const immutableSetPrototype = Object.setPrototypeOf
const immutableObjectPrototype = Object.prototype, immutableArrayPrototype = Array.prototype

export type ImmutablePartCopy = (value: object, depth: number, pay: (count: number) => boolean,
  reserve: (source: object, count: number) => boolean, transfer: (source: object, target: object) => void) => object | undefined

export function createImmutableParts(known: (value: object) => boolean = () => false, knownOwned: (value: object) => boolean = () => false,
  copyKnown?: ImmutablePartCopy, knownBytes: (value: object) => number = () => 0) {
  const parts = new immutableSet<object>(), ownedParts = new immutableSet<object>()
  interface CopyPlan { keys: readonly PropertyKey[]; descriptors: readonly PropertyDescriptor[]; array: boolean; prototype: object | null; bytes: number; setupCost: number }
  const plans = new WeakMap<object, CopyPlan>()
  const containerBytes = new WeakMap<object, number>()
  const planOf = (value: object): CopyPlan | undefined => immutableApply(immutableMapGet, plans, [value])
  const retainedBytes = (value: object): number => planOf(value)?.bytes ?? immutableApply(immutableMapGet, containerBytes, [value]) ?? knownBytes(value)
  const retain = (value: object, keys: PropertyKey[], descriptors: PropertyDescriptor[], bytes: number, setupCost: number): void => {
    immutableApply(immutableMapSet, plans, [value, { keys, descriptors, array: immutableArray(value), prototype: immutablePrototype(value), bytes, setupCost }])
  }
  const has = (value: object): boolean => immutableApply(immutableHas, parts, [value]) || known(value)
  const hasOwned = (value: object): boolean => immutableApply(immutableHas, ownedParts, [value]) || knownOwned(value)
  const qualify = <T extends object>(value: T, allocationOwned: boolean): Readonly<T> => {
    Object.freeze(value)
    // A caller can interpose the freeze operation. Reuse needs the actual
    // sealed data, rather than the operation's name or its returned value.
    if (!immutableFrozen(value)) return value
    let owned = allocationOwned
    const keys = immutableKeys(value)
    let childBytes = 0, setupCost = 4 + keys.length
    // The required qualification already produced these descriptors. Retain
    // them only for constructor-owned data; capture pays their added retention
    // on first use and still constructs a fresh receiver per occurrence.
    const descriptors: PropertyDescriptor[] | undefined = allocationOwned ? [] : undefined
    for (let index = 0; index < keys.length; index++) {
      const descriptor = immutableDescriptor(value, keys[index]!)
      if (!descriptor || !immutableOwn(descriptor, 'value')) return value
      if (descriptors) immutableDefine(descriptors, index, { __proto__: null, value: descriptor, enumerable: true, writable: false, configurable: false } as PropertyDescriptor)
      const child = descriptor.value
      if (child && typeof child === 'object') { childBytes += retainedBytes(child); setupCost += 4 }
      const scalar = child === null || typeof child !== 'object' && typeof child !== 'function'
      if (owned && !scalar && !hasOwned(child)) owned = false
      if (!scalar && !has(child)) return value
    }
    immutableApply(immutableAdd, parts, [value])
    if (owned) {
      immutableApply(immutableAdd, ownedParts, [value])
      retain(value, keys, descriptors!, 64 + keys.length * 96 + childBytes, setupCost)
    } else immutableApply(immutableMapSet, containerBytes, [value, 32 + childBytes])
    return value
  }
  const freeze = <T extends object>(value: T): Readonly<T> => qualify(value, false)
  // Only call at a known local allocation. Caller-dispatched map results and
  // other supplied objects may use freeze, but cannot mint this provenance.
  const freezeOwned = <T extends object>(value: T): Readonly<T> => qualify(value, true)
  // Locally allocated scalar spans need no recursive field qualification. The
  // captured freeze keeps an interposed public constructor from seeing or
  // substituting this private allocation.
  const sourceSpan = (text: string, sourceStart: number, sourceEnd: number) => {
    if (typeof text !== 'string' || typeof sourceStart !== 'number' || typeof sourceEnd !== 'number') throw new TypeError('Source spans require scalar text and offsets')
    const span = immutableFreeze({ text, sourceStart, sourceEnd })
    if (immutableFrozen(span)) {
      immutableApply(immutableAdd, parts, [span])
      immutableApply(immutableAdd, ownedParts, [span])
      const keys = ['text', 'sourceStart', 'sourceEnd']
      const descriptors: PropertyDescriptor[] = []
      for (let i = 0; i < keys.length; i++) immutableDefine(descriptors, i, {
        __proto__: null, value: immutableDescriptor(span, keys[i]!)!, enumerable: true, writable: false, configurable: false,
      } as PropertyDescriptor)
      retain(span, keys, descriptors, 64 + keys.length * 96, 6 + 3 * keys.length)
    }
    return span
  }
  const copyOwned: ImmutablePartCopy = (value, depth, pay, reserve, transfer) => {
    const plan = planOf(value)
    if (!plan) return copyKnown?.(value, depth, pay, reserve, transfer)
    if (depth > 64 || plan.prototype !== immutableObjectPrototype && plan.prototype !== immutableArrayPrototype && plan.prototype !== null
      || !pay(4 + plan.keys.length) || !reserve(value, plan.setupCost)) return undefined
    // The caller excludes callback-bearing helpers for this complete subtree.
    // Build private own data with no inherited setters, then restore the same
    // ordinary receiver prototype/flags before it can reach a consumer.
    const result: Record<string, unknown> | unknown[] = plan.array ? immutableSetPrototype([], null) : { __proto__: null }
    let length: unknown
    for (let i = 0; i < plan.keys.length; i++) {
      const key = plan.keys[i]!
      if (typeof key !== 'string') continue
      const descriptor = plan.descriptors[i]!
      if (plan.array && key === 'length') { length = descriptor.value; continue }
      if (depth + 1 > 64 || !pay(1)) return undefined
      const source = descriptor.value
      const kind = typeof source
      if (source !== null && kind !== 'undefined' && kind !== 'boolean' && kind !== 'number' && kind !== 'string' && kind !== 'object') return undefined
      const child = source && typeof source === 'object' ? copyOwned(source, depth + 1, pay, reserve, transfer) : source
      if (source && typeof source === 'object' && child === undefined) return undefined
      if (descriptor.enumerable) (result as Record<string, unknown>)[key] = child
      else immutableDefine(result, key, { __proto__: null, value: child, enumerable: false } as PropertyDescriptor)
    }
    if (plan.array) {
      if (!pay(1)) return undefined
      ;(result as unknown[]).length = length as number
    }
    immutableSetPrototype(result, plan.array ? immutableArrayPrototype : immutableObjectPrototype)
    immutableFreeze(result)
    transfer(value, result)
    return result
  }
  return { has, freeze, hasOwned, freezeOwned, sourceSpan, copyOwned, retainedBytes }
}
