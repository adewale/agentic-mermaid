import {build} from 'tsup'
import c from '/tmp/pr449-main-integration-20261029-762/tsup.browser-lazy.config.ts'
const plugins=c.esbuildPlugins!.map(p=>p.name!=='lazy-browser-dependencies'?p:{...p,setup(b:any){const proxy=Object.create(b);proxy.onLoad=(o:any,cb:any)=>{const filter=o.filter.source;if(filter.includes('browser-lazy\\/families')||filter.includes('builtin-backends|layout\\/agentic-producer-core'))return;b.onLoad(o,cb)};p.setup(proxy)}})
await build({...c,config:false,esbuildPlugins:plugins,outDir:'/tmp/pr449-week-comparison-20261101/lazy-closure-0c162-20261108/no-forced-union',dts:false,clean:false})
