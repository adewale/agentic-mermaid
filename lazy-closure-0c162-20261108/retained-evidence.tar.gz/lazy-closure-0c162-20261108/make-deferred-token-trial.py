from pathlib import Path
import json
p=Path('/tmp/pr449-week-comparison-20261101/lazy-closure-0c162-20261108');s=(p/'svg-writer-before.ts').read_text();start=s.index('  check(): boolean {\n',s.index('class XmlLeafWrite'));end=s.index('\n}\n\nconst projectXmlTextPaint',start)
method='''  check(): boolean {
    if (!this.valid || !this.#state.pay(1)) return false
    let attributes: Set<string> | undefined, fixed = 0
    const fixedBit = (name: string): number => {
      switch (name) {
        case 'x': return 1
        case 'y': return 2
        case 'dy': return 4
        case 'textLength': return 8
        case 'data-prepared-text': return 16
        case 'lengthAdjust': return 32
        case 'data-font-metrics': return 64
        case 'fill': return 128
        case 'font-size': return 256
        case 'text-anchor': return 512
        case 'font-family': return 1024
        case 'xml:space': return 2048
        default: return 0
      }
    }
    for (let i = 0; i < this.#events!.length; i++) {
      const event = this.#events![i]!
      if (!this.#state.pay(2)) return false
      if (event[0] === 'element') {
        fixed = 0
        attributes?.clear()
        const name = event[1]
        if (name !== 'rect' && name !== 'circle' && name !== 'ellipse' && name !== 'line' && name !== 'polygon' && name !== 'polyline' && name !== 'path' && name !== 'text') return false
      } else if (event[0] === 'attribute') {
        const bit = fixedBit(event[1])
        if ((bit ? (fixed & bit) !== 0 : attributes?.has(event[1])) || !bit && !this.#state.name(event[1]) || !this.#state.literal(event[2], true)) return false
        if (bit) fixed |= bit
        else (attributes ??= new Set<string>()).add(event[1])
      } else if (event[0] === 'prepared') {
        if (!this.#state.prepared() || !this.#state.pay(1) || (fixed & 127) !== 0) return false
        fixed |= 127
        if (!this.#state.literal(event[1], true) || !this.#state.literal(event[2], true) || !this.#state.literal(event[3], true)
          || !this.#state.literal(event[4], true) || !this.#state.literal(event[5], false)) return false
      } else if (!this.#state.literal(event[1], false)) return false
    }
    return true
  }'''
(p/'svg-writer-deferred-token.ts').write_text(s[:start]+method+s[end:]);job={'case':'Sparse32-1500-labels','backend':'native-drawing','source':'0c162+outside-source deferred XML name tokens','edit':'same fixture; not an edit measurement','moduleOverrides':{'/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts':str(p/'svg-writer-deferred-token.ts')}};(p/'sparse-deferred-token.json').write_text(json.dumps(job)+'\n')
