/** Constructor operands, scoped to one original Native drawing. Public mark
 * constructors never enter this program. A record is reusable only when its
 * actual fresh allocation has completed an own-data closure over primitives
 * and previously completed constructor children. */
export interface ConstructedMarkOperands {
  own<T extends object>(value: T): T
  retain(value: object, depth: number, pay: (count?: number) => boolean): 'absent' | 'retained' | 'exhausted'
}
const operandMap = WeakMap, operandApply = Reflect.apply
const operandGet = WeakMap.prototype.get, operandSet = WeakMap.prototype.set
const operandKeys = Reflect.ownKeys, operandDescriptor = Object.getOwnPropertyDescriptor
const operandOwn = Object.hasOwn, operandPrototype = Object.getPrototypeOf
const operandFreeze = Object.freeze, operandExtensible = Object.isExtensible, operandArray = Array.isArray
const operandIssuer = { __proto__: null }
interface OperandChild { readonly value: ConstructedOperand; next: OperandChild | undefined }
interface OperandSlot { readonly key: PropertyKey; readonly value: unknown; next: OperandSlot | undefined }
class ConstructedOperand {
  readonly #value: object
  readonly #keys: number
  readonly #children: OperandChild | undefined
  readonly #height: number
  constructor(issuer: object, value: object, keys: number, children: OperandChild | undefined, height: number) {
    if (issuer !== operandIssuer) throw new TypeError('Constructed operand requires its allocation')
    this.#value = value; this.#keys = keys; this.#children = children; this.#height = height
  }
  static bound(value: unknown, source: object): value is ConstructedOperand { return !!value && typeof value === 'object' && #value in value && value.#value === source }
  static height(value: ConstructedOperand): number { return value.#height }
  static pay(value: ConstructedOperand, depth: number, work: (count?: number) => boolean): boolean {
    if (depth + value.#height > 64 || !work() || !work(value.#keys) || !work(value.#keys)) return false
    for (let child = value.#children; child; child = child.next) if (!chargeConstructedOperand(child.value, depth + 1, work)) return false
    return true
  }
}
const boundConstructedOperand = ConstructedOperand.bound, constructedOperandHeight = ConstructedOperand.height
const chargeConstructedOperand = ConstructedOperand.pay

export function createConstructedMarkOperands(maximumSlots: number): ConstructedMarkOperands {
  const completed = new operandMap<object, ConstructedOperand>()
  let slots = 0
  const read = (value: object): ConstructedOperand | undefined => {
    const fact = operandApply(operandGet, completed, [value])
    return boundConstructedOperand(fact, value) ? fact : undefined
  }
  return {
    own<T extends object>(value: T): T {
      if (read(value)) return value
      const prototype = operandPrototype(value)
      if (prototype !== Object.prototype && prototype !== null && prototype !== Array.prototype) return value
      const keys = operandKeys(value)
      if (keys.length > 64 || slots + keys.length + 1 > maximumSlots) return value
      slots += keys.length + 1
      let children: OperandChild | undefined, lastChild: OperandChild | undefined
      let captured: OperandSlot | undefined, lastSlot: OperandSlot | undefined
      let height = 0
      const array = operandArray(value)
      for (let index = 0; index < keys.length; index++) {
        if (typeof keys[index] !== 'string') return value
        const descriptor = operandDescriptor(value, keys[index]!)
        if (!descriptor || !operandOwn(descriptor, 'value')) return value
        const child = descriptor.value
        if ((!array || keys[index] !== 'length') && height < 1) height = 1
        const slot: OperandSlot = { key: keys[index]!, value: child, next: undefined }
        if (lastSlot) lastSlot.next = slot; else captured = slot
        lastSlot = slot
        if (child !== null && typeof child === 'object') {
          const fact = read(child)
          if (!fact) return value
          const entry: OperandChild = { value: fact, next: undefined }
          if (lastChild) lastChild.next = entry; else children = entry
          lastChild = entry
          height = Math.max(height, 1 + constructedOperandHeight(fact))
        } else if (typeof child === 'function' || typeof child === 'symbol' || typeof child === 'bigint') return value
      }
      if (height > 64 || operandFreeze(value) !== value || operandExtensible(value)) return value
      // A sealing hook cannot turn an accessor or a mutable slot into custody.
      const closedKeys = operandKeys(value)
      if (closedKeys.length !== keys.length) return value
      let slot = captured
      for (let index = 0; index < keys.length; index++, slot = slot?.next) {
        if (!slot || closedKeys[index] !== slot.key) return value
        const descriptor = operandDescriptor(value, keys[index]!)
        if (!descriptor || !operandOwn(descriptor, 'value') || descriptor.value !== slot.value || descriptor.writable || descriptor.configurable) return value
        const child = descriptor.value
        if (child !== null && typeof child === 'object' && !read(child)) return value
        if (typeof child === 'function' || typeof child === 'symbol' || typeof child === 'bigint') return value
      }
      operandApply(operandSet, completed, [value, new ConstructedOperand(operandIssuer, value, keys.length, children, height)])
      return value
    },
    retain(value, depth, pay) {
      const fact = read(value)
      return !fact ? 'absent' : chargeConstructedOperand(fact, depth, pay) ? 'retained' : 'exhausted'
    },
  }
}
