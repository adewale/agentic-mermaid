import{J as t,L as r}from"./chunk-FOHRCTWX.js";function a(e,n){t(e);r(e,n);return e}export{a};
//# sourceMappingURL=chunk-C5BQ2A4K.js.map