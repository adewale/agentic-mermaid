import {readFileSync} from 'node:fs'
process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS='0';process.env.AGENTIC_MERMAID_ELK_CACHE='0'
const {renderMermaidSVGWithReceipt}=await import('/dev/shm/pr449-four-final-20261111/finish-geometry-943/src/index.ts')
const cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-main-20261110/MEASUREMENT-CASES.json','utf8'));const item=cases.find((c:any)=>c.id==='diagnostic:chain100');const result=renderMermaidSVGWithReceipt(item.source,{graphLayout:{backend:'agentic',fallback:'none'}});console.log(JSON.stringify({proof:result.receipt.layoutCertification?.status,bytes:result.svg.length}))
