import {readFileSync} from 'node:fs'
Bun.plugin({name:'metadata-slots',setup(build){build.onLoad({filter:/\/src\/scene\/native-paint-emission\.ts$/},args=>{
let code=readFileSync(args.path,'utf8').replace('const work = createNativeXmlWork(maxOperations)',`const shapes:Record<string,number>={};const work = createNativeXmlWork(maxOperations)`)
code=code.replace('const deferredProjection = deferredTerminalProjectionInput(value)',`if(close && context===undefined){const key=keys.join(',');shapes[key]=(shapes[key]??0)+1}const deferredProjection = deferredTerminalProjectionInput(value)`)
code=code.replace('const checked = new Map<string, CheckedMarkerResource>()',`console.error(JSON.stringify({phase:'metadata-shapes',shapes}));const checked = new Map<string, CheckedMarkerResource>()`)
return{contents:code,loader:'ts'}
})}})
