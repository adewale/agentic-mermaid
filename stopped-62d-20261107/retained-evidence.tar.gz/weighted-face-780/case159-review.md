# generated-cyclic159 RL: actual introduced shaft/card contact

Independent read-only classification of saved `case159-before.svg` and
`case159-after.svg`, with their matching JSON. Both standalone SVG files equal
the corresponding JSON `svg` strings. No new render, source change or raster
was used.

**Classification: actual painted contact, not merely a conservative envelope
warning.** The weighted probe moves one horizontal suffix closer to an
unchanged foreign subroutine card. It also saves a small amount of wire. The
proof downgrade alone is not the basis of this conclusion.

## Written geometry

`edge:n5->n1#0` is a solid 1px polyline with no fill, opacity override, dash or
curve. Its before points are:

```
965.376,186.308 946.001,186.308 946.001,167.158 700.285,167.158
```

Its after points are:

```
965.376,186.308 946.001,186.308 946.001,169.533 700.285,169.533
```

The final suffix therefore crosses the whole x extent of foreign `n7` in both
products, with its y center moved down 2.375px. The unchanged `node-shape:n7`
is explicitly written as a sharp rectangle:

```
x=797.334 y=169.858 width=104.194 height=36.9
fill=#f9f9f9 stroke=#949495 stroke-width=0.75 rx=0 ry=0
```

Its right edge is x901.528. The two additional subroutine lines are at x805.334
and x893.528 from y169.858 through y206.758, also 0.75px wide. These are actual
opaque painted resources; no rounded empty-corner explanation applies.

Before: shaft bottom = 167.158 + 0.5 = **167.658**. The card's top outline
begins at 169.858 − 0.375 = **169.483**. Thus the minimum vertical painted gap
along the common horizontal span is **+1.825px**.

After: shaft occupies y[169.033,170.033]. Card fill starts at y169.858, giving
**0.175px of shaft/fill penetration** over the card's horizontal interior.
The top outline occupies y[169.483,170.233], giving **0.55px of shared painted
vertical support** throughout the straight top border. Away from the corner
joins, these are simple overlapping axis-aligned painted strips. Even ignoring
all rectangle-corner join assumptions, their overlap over the interior
x(797.709,901.153) is positive. This establishes the contact directly.

SVG document order places the edge before the node shape (element indexes32
and90 in a depth-first traversal). The later opaque node outline/fill covers
the lower portion of the shaft along this span. On the straight top-border
interior, 0.55px of the original 1px shaft is covered, leaving 0.45px above the
outline. The shaft is therefore partly attenuated along the card, rather than
fully severed by the card body. This is a real thin contact; perceived severity
or a raster reading loss is not established without a raster.

The endpoint marker is the unchanged stock 8×5 end arrow with a 0.75px round
outline at n1, far left of n7. It is not the resource causing this contact.
Authored edge identity/direction and the source node are preserved. The target
is still the right boundary of n1 at x700.285; its y changes from167.158 to
169.533. No new connection to n7 is authored or marked.

## Preserved value and costs

All11 node records and logical bounds are exactly equal between JSON products.
All27 edge IDs, source/target pairs, labels and label positions are preserved.
Nine edge paths change; eight do not account for the named contact. The canvas
is unchanged at **1678.512×329.705**, area553413.79896px². Metrics retain8 edge
crossings,51 bends, zero label conflicts, and zero parallel/opposing overlaps.

Total written polyline Manhattan wire falls **8985.863950 → 8975.374664px**:
**−10.489286px (about−0.117%)**. The named edge alone saves2.375px by shortening
its vertical segment. Raw SVG length remains25627bytes; Python level9 gzip with
mtime0 is3198→3199bytes (that comparison includes the changed scope digest).
These are bounded product observations, not a claim of global route quality.

The useful selected head repairs and aggregate48 U→P transitions reported by
the coordinator must be evaluated alongside this introduced actual contact;
those transitions alone are not48 proven visible gains. Conversely, this one
P→U is not an automatic rejection gate. The concrete tradeoff here is a thin,
long shaft/card contact versus a small wire reduction with unchanged bodies,
area, bends and reported crossings. Keeping unchanged bodies did not preserve
foreign-card clearance.

## Product identity

- Before SHA256: `e59366930af7f71a3aa6b747ce1679ef9b68cd5d81da5afc5dbaa8652003bd2c`
- After SHA256: `5597317d0759ec6bdbf4a41dfbd3085fa50dd06e407743883e4cf975854a5151`

This review establishes written vector contact and custody, not a particular
responsible pipeline stage. The source remains780; these are the saved isolated
prototype products, not shipped behavior.
