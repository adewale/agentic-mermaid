import fs from 'node:fs';
import path from 'node:path';


import {pathToFileURL,fileURLToPath} from 'node:url';
import {registerHooks,stripTypeScriptTypes} from 'node:module';
import {gzipSync,brotliCompressSync} from 'node:zlib';
const out=process.argv[2],job=JSON.parse(fs.readFileSync(process.argv[3],'utf8')),root=job.root;
fs.mkdirSync(out,{recursive:true});
const maps={};
registerHooks({
 resolve(specifier,context,next){
  if(specifier.startsWith('.')&&(context.parentURL?.startsWith(pathToFileURL(root+'/').href)||context.parentURL?.includes('/node_modules/roughjs/bin/'))){
   const p=new URL(specifier,context.parentURL);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.ts'))return next(p.href+'.ts',context);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.js'))return next(p.href+'.js',context);
  }
  if(specifier.startsWith('roughjs/bin/')&&!path.extname(specifier))return next(specifier+'.js',context);
  return next(specifier,context);
 },
 load(url,context,next){
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.json'))return{format:'json',shortCircuit:true,source:fs.readFileSync(fileURLToPath(url),'utf8')};
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.ts')){
   const original=fs.readFileSync(job.moduleOverrides?.[fileURLToPath(url)] ?? fileURLToPath(url),'utf8');
   const source=stripTypeScriptTypes(url.endsWith('/eval/layout-compare/run.ts') ? original.replaceAll('import.meta.dir', JSON.stringify(root+'/eval/layout-compare')) : original,{mode:'transform',sourceMap:true,sourceUrl:url});
   const m=source.match(/sourceMappingURL=data:application\/json;base64,([^\s]+)/);
   if(m)maps[url]=JSON.parse(Buffer.from(m[1],'base64').toString());
   return{format:'module',shortCircuit:true,source};
  }
  return next(url,context);
 }
});
const {snapshotSample}=await import(pathToFileURL(root+'/eval/layout-compare/run.ts'));
const baseline=JSON.parse(fs.readFileSync(job.baseline,'utf8'));const samples=[];
for(let i=0;i<baseline.samples.length;i++){
 const v=baseline.samples[i];samples.push(snapshotSample({id:v.id,family:v.family,source:v.source},'lc'+i+'-',baseline.renderOptions,{includeAscii:!baseline.population}));
 if(i%32===31){fs.writeFileSync(out+'/progress.json',JSON.stringify({completed:i+1,total:baseline.samples.length}));console.log(i+1,baseline.samples.length);}
}
fs.writeFileSync(out+'/snapshot.json',JSON.stringify({...baseline,label:'weighted-face-isolated',rev:'780b5+isolated-marker-supports',dirty:true,samples}));console.log('completed',samples.length);
