# Unequal endpoint-support packing: independent scope review

Reviewed source `780b5f1b04ac7ac5db35cdd442d98df652daf17d`, read-only. No
builds, tests, renders, network actions or source edits were performed. This is
a review of a proposed causal probe, not evidence that it fixes public output.

## Plausible owning boundary

The proposal has a direct causal opportunity at
`src/layout/agentic-layered-core.ts:687–752`: each oriented face already has its
actual, neighbor-ordered edge occurrences. The roomy branch reserves at least
8px pitch; its dense fallback ignores endpoint paint and proportionally places
centers at `width*(index+1)/(count+1)`. Unequal support packing can change that
fallback without increasing node bodies or modifying whole-route admission.
Keeping the old roomy branch and the separate loop-attachment branch is the
smallest boundary. Do not use authored incoming/outgoing counts to infer the
face after private reversal.

The reported seven-support sums 30.75, 35.5 and 21.25 are below a 36.9px *bare*
face. They do not fit the old roomy interval in the first two cases: its margin
is 6.15px at this height, leaving 24.6px. Thus this proposal deliberately uses
more of the already available dense face; it does not preserve an 8px margin
or 8px inter-port pitch. That is geometrically plausible for a sharp rectangle
if each support lies inside the face and consecutive painted intervals have
positive separation. Do not describe small support separation as established
readability improvement.

For ordered supports `s[i]`, a falsifiable fit condition is finite
`sum(s) + required positive gaps <= crossSize`, with each center at least
`s[i]/2` from the corresponding edge of the face and neighbor centers separated
by at least `(s[i]+s[i+1])/2 + gap`. A sum-of-widths comparison alone is
insufficient: exact-fit/touching, rounding and zero-support neighbors still
matter. A coordinate-magnitude serialization allowance must fit inside the
slack rather than silently enlarging the face. Keep the old fallback when it
does not fit. A conservative bound can reject a potentially paint-clear case;
that is different from inventing capacity.

## Measurement, ownership and reversal pitfalls

1. `agentic-producer-core.ts:248–292` already queries the renderer's cardinal
   marker resources, but its `MarkerRoom.span` is the maximum over *both*
   endpoints. Unequal start/end resources must be measured separately. Use
   `max(endpoint marker cross support, this edge's shaft width)`, not both added
   together and not the graph's maximum shaft width. The built-in arrow/circle/
   cross resources are cross-symmetric (`graph-connectors.ts:175–221`); if this
   symmetry cannot be established for a resource, half of its bounding width
   need not bound each side of the route center. Unknown is not zero.
2. The producer's fixed-width measurement passes a normalized inline width
   because those heads use `userSpaceOnUse`; default heads scale with effective
   shaft width. Retain that distinction and the per-style footprint identity.
   Color-only variants cannot enlarge this support. Unresolved CSS widths,
   placement-only preparation or unavailable marker bounds must leave the
   affected face on its old fallback, not give it known zero demand.
3. The layered core does not know node shapes. Broadly providing endpoint spans
   would enable the branch on circles, semantic shapes and frame placeholders.
   A rectangular-face claim should be enabled only for producer-authorized
   rectangle/subroutine endpoints; a missing value can carry ineligibility.
   A compound edge lifted from a leaf to a group is not the same physical face
   (`agentic-compound-core.ts:94–98`), so do not blindly reuse the leaf support
   as frame-capacity authority.
4. Three private endpoint-reversal sites require swapping source/target
   supports: `agentic-layered-core.ts:175–176`, `:276–277`, and
   `cycle-layout-search.ts:43–47`. The latter also permutes edge order and node
   order. Flat endpoint arrays must follow those permutations; merely spreading
   the graph object preserves the wrong array order. Swapping geometry alone
   is insufficient. BT/RL world-coordinate reversal is separate: it changes
   physical orientation, not which authored endpoint owns a marker.
5. Loop expansion is not a simple reversal. At
   `agentic-layered-core.ts:218–223`, the original target becomes a private
   helper and a new returning edge is added with the authored node as source.
   The authored target support belongs on that synthetic returning *source*;
   blindly copying the original endpoint pair puts it on the helper. Preserve
   `loopPorts` minimum separation and old capacity refusal. Disabling weighted
   packing wherever loop pairs exist is a smaller safe initial scope than
   changing the loop constraint solver.
6. Invisible edges still receive distinct ports and affect sorted peer order.
   They can have zero painted support, but they cannot disappear from the
   ordered incidence list. Exact-fit packing with adjacent zero supports can
   violate the existing distinct-port contract. Duplicate edges likewise own
   separate occurrences even when source, target and style match.
7. Capture the two endpoint values once into solver-owned finite, nonnegative
   numeric storage; validate lengths/indices before use. No host array or
   mutable caller record should be borrowed through cache output. The existing
   geometry JSON key must include any new measured inputs, including which
   endpoint is absent; otherwise changing support can alias old geometry.
   The current cache already structured-clones returned geometry.
8. Precharge endpoint storage, copied/permuted scratch, per-face summation and
   the additional positioning scan through the existing ledgers before
   allocation/work. A linear scan is bounded but is not free. A preparation
   charge alone does not account copies introduced in cycle/loop transforms.
   Do not reset work on recursive placement or cache-warm requests.

## Disproofs and value evidence

The strongest initial falsifier is actual selected output, not an internal
packing success: measure the named heads' written resources and cardinal rays
in the final public SVG. The shortener preserves endpoint positions/rays
(`shorten-measured-routes.ts:22,73–74`), but complete marker finalization,
cycle selection and shared routing still own the final result. A probe that
packs one arm safely but selects another arm with touching heads has not closed
the loss. Candidate selection changes can expose other contacts, as prior
stopped trials demonstrated.

A compact independent owner can include unequal start/end markers across a
forced reversal and its reverse direction, a duplicate edge, an invisible
constraint and an oversized/no-fit control. Assert final actual endpoint
support separation and authored endpoint identities; also assert unchanged
node bodies and old fallback output for no-fit/ineligible faces. A fixture
whose endpoint resources are all equal cannot expose a lost support swap.
A helper-only pass or proof-warning transition cannot replace the public
201/241 and current17 bindings.

The proposed benefit is avoiding the body growth of stopped4db9 while repairing
known head contacts. Its cost can still include changed ports, bends, wire,
carrier crossings, label routes, candidate choice and payload. Keep the old
five stopped counterexamples and named controls in the comparison; unchanged
bodies alone do not prove unchanged canvas or routes. No broad improvement or
acceptance claim follows from this read-only plausibility review.
