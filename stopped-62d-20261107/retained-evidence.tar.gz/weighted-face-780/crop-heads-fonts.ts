import {readFileSync,writeFileSync} from 'node:fs'
import {gunzipSync} from 'node:zlib'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {prepareResvgMarkerOrientation} from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const r='/tmp/pr449-week-comparison-20261101/weighted-face-780',data=JSON.parse(readFileSync(r+'/INK.json','utf8'))
for(const row of data.rows){
 const b=row.roi,z=data.zoom,x=b.x0/z,y=b.y0/z,w=(b.x1-b.x0)/z,h=(b.y1-b.y0)/z
 let svg=gunzipSync(readFileSync(r+'/ink-'+row.arm+row.case+'/actual.svg.gz')).toString()
 svg=svg.replace(/<svg\b[^>]*>/,tag=>tag.replace(/\bwidth="[^"]*"/,`width="${w}"`).replace(/\bheight="[^"]*"/,`height="${h}"`).replace(/\bviewBox="[^"]*"/,`viewBox="${x} ${y} ${w} ${h}"`))
 writeFileSync(r+'/'+row.arm+row.case+'-head.png',new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(svg)),{background:'#fff',fitTo:{mode:'zoom',value:12},font:{loadSystemFonts:false,fontDirs:[],fontFiles:HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>'/tmp/pr449-main-integration-20261029-762/'+f.path)}}).render().asPng())
}
