import {readFileSync,writeFileSync} from 'node:fs'
import {gunzipSync} from 'node:zlib'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {prepareResvgMarkerOrientation} from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const r='/tmp/pr449-week-comparison-20261101/weighted-face-780',data=JSON.parse(readFileSync(r+'/INK.json','utf8'))
for(const row of data.rows){
 const b=row.roi,z=data.zoom,x=b.x0/z,y=b.y0/z,w=(b.x1-b.x0)/z,h=(b.y1-b.y0)/z
 let svg=gunzipSync(readFileSync(r+'/ink-'+row.arm+row.case+'/actual.svg.gz')).toString()
 svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">`+svg.replace('<svg ',`<svg x="${-x}" y="${-y}" `)+'</svg>'
 writeFileSync(r+'/'+row.arm+row.case+'-head.png',new Resvg(prepareResvgMarkerOrientation(svg),{background:'#fff',fitTo:{mode:'zoom',value:12},font:{loadSystemFonts:false,fontDirs:[]}}).render().asPng())
}
