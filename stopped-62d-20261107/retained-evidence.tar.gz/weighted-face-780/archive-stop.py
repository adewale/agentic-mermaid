import pathlib,hashlib,json,tarfile,shutil,subprocess,os
repo=pathlib.Path('/tmp/pr449-main-integration-20261029-762');stage=pathlib.Path('/tmp/pr449-evidence-stage-stop-20261107');name='stopped-62d-20261107';out=stage/name;out.mkdir(parents=True,exist_ok=True)
roots=[pathlib.Path('/tmp/pr449-week-comparison-20261101/weighted-face-780'),pathlib.Path('/tmp/pr449-week-comparison-20261101/qualify-780-20261107')];manifest=[]
with tarfile.open(out/'retained-evidence.tar.gz','w:gz',compresslevel=6) as tar:
 for root in roots:
  for p in sorted(root.rglob('*')):
   if p.is_symlink():continue
   if not p.is_file():continue
   rel=str(pathlib.Path(root.name)/p.relative_to(root));data=p.read_bytes();manifest.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});tar.add(p,arcname=rel,recursive=False)
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'retained-evidence.tar.gz','r:gz') as tar:
 members={m.name:m for m in tar.getmembers() if m.isfile()};assert len(members)==len(manifest)
 for rec in manifest:
  data=tar.extractfile(members[rec['path']]).read();assert len(data)==rec['bytes'] and hashlib.sha256(data).hexdigest()==rec['sha256']
r=roots[0]
for file in ['STOP-REVIEW.md','PROFILE-FIRST.md','FULL-COMPARISON.json','INK.json','INK152.json','INK230.json','PAYLOAD.json','FINAL-BINDING.json','SHA-INK-BINDING.json','joint-final-review.md','before201.png','after201.png','before241.png','after241.png','CI-62d-AT-STOP.json']:
 shutil.copy2(r/file,out/('README.md' if file=='STOP-REVIEW.md' else file))
arc=out/'retained-evidence.tar.gz';verified={'files':len(manifest),'uncompressedBytes':sum(x['bytes'] for x in manifest),'archiveBytes':arc.stat().st_size,'archiveSha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'verification':'Every archive member reread and verified against original byte length/SHA256. All failed probes retained; symlinks are not duplicated.'};(out/'VERIFIED.json').write_text(json.dumps(verified,indent=2)+'\n')
ref='refs/heads/review/pr449-evidence-20261105';parent=subprocess.check_output(['git','rev-parse',ref],cwd=repo,text=True).strip();env=os.environ|{'GIT_INDEX_FILE':str(stage/'index'),'GIT_WORK_TREE':str(stage)}
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,env=env,text=True).strip()
git('read-tree',parent);git('add',name);tree=git('write-tree');commit=subprocess.check_output(['git','commit-tree',tree,'-p',parent,'-m','Preserve stopped campaign checkpoint and adverse outcomes at62d521fbc'],cwd=repo,text=True).strip();git('update-ref',ref,commit,parent);(r/'EVIDENCE-COMMIT.txt').write_text(commit+'\n');print(json.dumps({'commit':commit,**verified}))
