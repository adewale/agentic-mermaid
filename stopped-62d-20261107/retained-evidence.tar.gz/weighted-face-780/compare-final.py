import json,pathlib,hashlib,math
r=pathlib.Path(__file__).parent
rows=[];totals={};metrics=('edgeCrossings','labelLegibility','whitespaceBalance','labelEdgeProximity','minimumNodeSpacing','elementDensity','minimumTextContrast','aspectRatio')
for backend,folder in [('agentic','full-joint'),('elk','elk-qualified')]:
 t={'enrolled':0,'changedSvg':0,'deliveryTransitions':0,'proofTransitions':{},'changedLayout':0,'changedGeometry':0,'changedLayoutProof':0,'changedSvgReceipt':0,'proofOperationDeltas':[],'adverse':{},'favorable':{}}
 for path in json.load(open(r/'cohorts.json')):
  rel=pathlib.Path(path).parent.relative_to(r/'enrolled');base=json.load(open(r/'enrolled'/rel/(backend+'.json')));new=json.load(open(r/folder/rel/'snapshot.json'));assert base['renderOptions']==new['renderOptions'];assert len(base['samples'])==len(new['samples'])
  for b,a in zip(base['samples'],new['samples']):
   assert all(b[k]==a[k] for k in ['id','family','source']);t['enrolled']+=1
   bp=b.get('metrics',{}).get('paintCertification',{}).get('status','not-returned');ap=a.get('metrics',{}).get('paintCertification',{}).get('status','not-returned')
   if bp!=ap:t['proofTransitions'][bp+'→'+ap]=t['proofTransitions'].get(bp+'→'+ap,0)+1
   delivery=b['ok']!=a['ok'];t['deliveryTransitions']+=delivery
   svg=b.get('svg')!=a.get('svg');layout=b.get('layout')!=a.get('layout');t['changedSvg']+=svg;t['changedLayout']+=layout
   t['changedGeometry']+= {k:v for k,v in b.get('layout',{}).items() if k!='paintCertification'} != {k:v for k,v in a.get('layout',{}).items() if k!='paintCertification'}
   t['changedLayoutProof']+=b.get('layout',{}).get('paintCertification')!=a.get('layout',{}).get('paintCertification')
   t['changedSvgReceipt']+=b.get('svgReceipt')!=a.get('svgReceipt')
   bo=b.get('metrics',{}).get('paintCertification',{}).get('checks',{}).get('operations');ao=a.get('metrics',{}).get('paintCertification',{}).get('checks',{}).get('operations')
   if isinstance(bo,int) and isinstance(ao,int) and bo!=ao:t['proofOperationDeltas'].append({'id':b['id'],'cohort':str(rel),'before':bo,'after':ao,'delta':ao-bo})
   if not(svg or delivery or bp!=ap):continue
   row={'backend':backend,'cohort':str(rel),'id':b['id'],'delivery':[b['ok'],a['ok']],'proof':[bp,ap],'svgSha256':[hashlib.sha256(x.get('svg','').encode()).hexdigest() for x in [b,a]],'layoutChanged':layout,'metricsBefore':b.get('metrics'),'metricsAfter':a.get('metrics'),'qualityDelta':{}}
   for key in ['area','length','bends']:
    old=b.get('metrics',{}).get('routeGeometry',{}).get(key);val=a.get('metrics',{}).get('routeGeometry',{}).get(key)
    if isinstance(old,(int,float)) and isinstance(val,(int,float)) and val!=old:
     row['qualityDelta'][key]={'before':old,'after':val,'absolute':val-old,'percent':100*(val/old-1) if old else None}
     typ='adverse' if val>old else 'favorable';t[typ][key]=t[typ].get(key,0)+1
   for key in metrics:
    old=b.get('metrics',{}).get(key);val=a.get('metrics',{}).get(key)
    if old!=val:row['qualityDelta'][key]={'before':old,'after':val}
   rows.append(row)
 totals[backend]=t
out={'baseline':'780b5f1b04ac7ac5db35cdd442d98df652daf17d','scope':'All literal enrolled inputs/options, full SVG/receipts retained alongside. Proof transitions are not visible-repair counts. Favorable/adverse lower area, length and bends are quality vectors, not correctness gates.','totals':totals,'changed':rows}
(r/'FULL-COMPARISON.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(totals,indent=2))
