from pathlib import Path
import json
repo=Path('/tmp/pr449-main-integration-20261029-762');r=Path(__file__).parent
paths=['src/layout/agentic-producer-core.ts','src/layout/agentic-layered-core.ts','src/layout/cycle-layout-search.ts']
for name in paths:(r/(Path(name).name+'.before')).write_bytes((repo/name).read_bytes())
s=(repo/paths[0]).read_text();s=s.replace("const nodes: MeasuredGraph['nodes'][number][] = [...graph.nodes].map(([id, node]) => {", "pay(0, graph.nodes.size + 1)\n    const portFaces = new Uint8Array(graph.nodes.size)\n    const nodes: MeasuredGraph['nodes'][number][] = [...graph.nodes].map(([id, node], index) => {\n      portFaces[index] = Number(!groups.length && !placementOnly && !options.stateVisual && !node.semanticShape && (node.shape === 'rectangle' || node.shape === 'subroutine'))")
s=s.replace('type MarkerRoom = { start: number; end: number; span: number;', 'type MarkerRoom = { start: number; end: number; startSpan: number; endSpan: number; span: number;')
s=s.replace('let start = 0, end = 0, span = 0, boundaryInset', 'let start = 0, end = 0, startSpan = 0, endSpan = 0, span = 0, boundaryInset')
s=s.replace("if (marker.position === 'start') start = Math.max(start, depth)\n            else if (marker.position === 'end') end = Math.max(end, depth)", "if (marker.position === 'start') { start = Math.max(start, depth); startSpan = Math.max(startSpan, 2 * Math.max(Math.abs(box.y0), Math.abs(box.y1))) }\n            else if (marker.position === 'end') { end = Math.max(end, depth); endSpan = Math.max(endSpan, 2 * Math.max(Math.abs(box.y0), Math.abs(box.y1))) }")
s=s.replace('pay(0, 7)\n          footprint = { start, end, span,', 'pay(0, 9)\n          footprint = { start, end, startSpan, endSpan, span,')
s=s.replace("return { source, target, minSpan: edge.length ?? 1,", "pay(0, 2)\n      const endpointSpans = shaft !== undefined && source !== target ? {\n        ...(portFaces[source] ? { sourcePortSpan: Math.max(shaft, footprint?.startSpan ?? 0) } : {}),\n        ...(portFaces[target] ? { targetPortSpan: Math.max(shaft, footprint?.endSpan ?? 0) } : {}),\n      } : {}\n      return { source, target, ...endpointSpans, minSpan: edge.length ?? 1,")
(r/'agentic-producer-core.ts').write_text(s)
s=(repo/paths[1]).read_text();s=s.replace('minSpan: number; short?: true;', 'minSpan: number; sourcePortSpan?: number; targetPortSpan?: number; short?: true;')
s=s.replace('let hasLoops = false, hasShortEdges = false', 'let sourcePortSpans: Float64Array | undefined, targetPortSpans: Float64Array | undefined\n  let hasLoops = false, hasShortEdges = false')
key="    if (edge.short !== undefined && edge.short !== true) throw new TypeError('Invalid measured short-edge preference')"
assert key in s
s=s.replace(key,key+"\n    const sourceSpan = edge.sourcePortSpan, targetSpan = edge.targetPortSpan\n    if (sourceSpan !== undefined || targetSpan !== undefined) {\n      if (sourceSpan !== undefined && !finiteSize(sourceSpan, true) || targetSpan !== undefined && !finiteSize(targetSpan, true)) throw new TypeError('Invalid measured endpoint port span')\n      if (!sourcePortSpans) {\n        routingWork.arcs -= 2 * edges.length; routingWork.pairs -= 2 * edges.length\n        if (routingWork.arcs < 0 || routingWork.pairs < 0) unsupported('agentic endpoint port-span work limit')\n        sourcePortSpans = new Float64Array(edges.length); targetPortSpans = new Float64Array(edges.length)\n      }\n      sourcePortSpans[index] = sourceSpan ?? 0; targetPortSpans![index] = targetSpan ?? 0\n    }")
s=s.replace('{ ...edge, source: edge.target, target: edge.source }', '{ ...edge, source: edge.target, target: edge.source, sourcePortSpan: edge.targetPortSpan, targetPortSpan: edge.sourcePortSpan }')
key='      for (let index = 0; index < peers.length; index++) {\n        const position = cross[nodeIndex]! - width / 2 + width * (index + 1) / (peers.length + 1)'
assert key in s
s=s.replace(key,"""      const spans = source ? sourcePortSpans : targetPortSpans
      if (!pairs?.length && nodes[nodeIndex]!.minimumPortSpacing === undefined && spans && peers.length > 1) {
        routingWork.pairs -= 4 * peers.length
        if (routingWork.pairs < 0) unsupported('agentic endpoint port-span work limit')
        let used = 0, known = true
        for (const edge of peers) { const span = spans[edge]!; used += span; known &&= span > 0 }
        const gap = (width - used) / (peers.length + 1)
        if (known && gap > 1e-6) {
          let cursor = cross[nodeIndex]! - width / 2 + gap
          for (const edge of peers) {
            const span = spans[edge]!
            ;(source ? sourcePort : targetPort)[edge] = cursor + span / 2
            cursor += span + gap
          }
          return
        }
      }
"""+key)
(r/'agentic-layered-core.ts').write_text(s)
s=(repo/paths[2]).read_text();s=s.replace('return { ...edge, source: indices[source]!, target: indices[target]! }', 'return { ...edge, source: indices[source]!, target: indices[target]!, ...(reversed[original] ? { sourcePortSpan: edge.targetPortSpan, targetPortSpan: edge.sourcePortSpan } : {}) }');(r/'cycle-layout-search.ts').write_text(s)
loader=Path('/tmp/pr449-week-comparison-20261101/marker-capacity-6edd/capture-paired-control.mjs').read_text();loader=loader.replace("job.producerOverride && url.endsWith('/src/layout/agentic-producer-core.ts') ? job.producerOverride : fileURLToPath(url)","job.moduleOverrides?.[fileURLToPath(url)] ?? fileURLToPath(url)");(r/'capture-probe.mjs').write_text(loader)
(r/'overrides.json').write_text(json.dumps({str(repo/name):str(r/Path(name).name) for name in paths},indent=2)+'\n')
print('Isolated producer/core/cycle overrides prepared; production source unchanged.')
