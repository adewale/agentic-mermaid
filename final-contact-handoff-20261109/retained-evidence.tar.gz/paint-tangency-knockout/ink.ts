import {readFileSync,writeFileSync} from 'node:fs'
import {gunzipSync} from 'node:zlib'
import {createHash} from 'node:crypto'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import {prepareResvgMarkerOrientation} from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const repo='/tmp/pr449-main-integration-20261029-762',root='/tmp/pr449-week-comparison-20261101/mixed-circle-contact-20261109/paint-tangency-knockout'
const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const p=repo+'/'+f.path;if(createHash('sha256').update(readFileSync(p)).digest('hex')!==f.sha256)throw Error('font mismatch');return p})
const rows=[]
for(const backend of [process.argv[2]!]){
 const arm=process.argv[3]??'before';
 const svg=gunzipSync(readFileSync(root+'/'+arm+'/'+backend+'.svg.gz')).toString();
 const selected='edge:s'+(process.argv[4]??'5')+'-&gt;T#0',a=[...svg.matchAll(/<polyline\b[^>]*\/>/g)].map(m=>m[0]).find(t=>t.includes('data-id="'+selected+'"'))!;
 const halo=[...svg.matchAll(/<rect\b[^>]*\/>/g)].map(m=>m[0]).find(t=>t.includes('data-id="node-shape:T"'))!;
 const tip=/points="([^"]+)"/.exec(a)![1]!.split(/\s+/).at(-1)!.split(',').map(Number),zoom=3;
 const noHead=a.replace(/ marker-end="[^"]*"/,''),noHalo='';
 const variants=[svg,svg.replace(a,noHead),svg.replace(halo,noHalo),svg.replace(a,noHead).replace(halo,noHalo)];
 const images=variants.map(s=>new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(s)),{background:'#fff',fitTo:{mode:'zoom',value:zoom},font:{fontFiles:fonts,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render());
 writeFileSync(root+'/'+arm+'-'+backend+'-s'+(process.argv[4]??'5')+'.png',images[0]!.asPng());const pixels=images.map(i=>i.pixels);
 const roi={x0:Math.floor((tip[0]!-12)*zoom),x1:Math.ceil((tip[0]!+12)*zoom),y0:Math.floor((tip[1]!-12)*zoom),y1:Math.ceil((tip[1]!+12)*zoom)};
 let exposed=0,visible=0,attenuated=0,hidden=0;const delta=(a:Uint8Array,b:Uint8Array,k:number)=>Math.abs(a[k]!-b[k]!)+Math.abs(a[k+1]!-b[k+1]!)+Math.abs(a[k+2]!-b[k+2]!);
 for(let y=roi.y0;y<roi.y1;y++)for(let x=roi.x0;x<roi.x1;x++){const k=(y*images[0]!.width+x)*4,e=delta(pixels[2]!,pixels[3]!,k),v=delta(pixels[0]!,pixels[1]!,k);if(e>=6){exposed++;if(v>=6)visible++;if(v+6<e)attenuated++;if(v<6)hidden++}}
 rows.push({arm,backend,selected,foreignBody:'node-shape:T',sha256:createHash('sha256').update(svg).digest('hex'),roi,exposed,visible,attenuated,hidden,actualSelected:a,actualHalo:halo});console.log(arm,backend,{exposed,visible,hidden,attenuated});
}
writeFileSync(root+'/INK-'+(process.argv[3]??'before')+'-'+process.argv[2]+'-s'+(process.argv[4]??'5')+'.json',JSON.stringify({font:'manifest-verified Inter; system fonts off',zoom:3,offlineRasters:4,scope:'Selected endpoint marker contribution with/without target body fill and stroke, actual completeSVG rasters; not whole-diagram readability or glyph fidelity',rows},null,2)+'\n');
