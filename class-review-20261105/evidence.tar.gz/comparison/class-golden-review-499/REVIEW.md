Class9 geometry review: f9ec8c115 main →49945278 current.

18 public SVG calls, all returnedP; no rasters/builds/golden writes. Exact default options{} and authored sources retained. All nine main canonical records match the committed goldens.

Independent actual-SVG checks preserve50class boxes +Protocol interface, their names/members, namespace hierarchy/containment,31ordered relations and29captions, cardinalities, stereotypes and notes. All61ordinary rectangular endpoint normals pass per arm; the marker-painted interface endpoint remains outside this test. All marker resource bytes remain exact.

The served caption is11px, occupied row14.3px and stroke halo3px (1.5px each side). New layout allocation17.3px matches that; old hardcoded+6 allocated20.3px. Nine geometry changes are intentional if root accepts this paint-aware spacing contract.

|Sample|Actual canvas before →after|Wire delta|Turns|
|---|---|---:|---|
|corpus/class/10|787.926×576.2 → 787.926×570.2|-24.0|0/0|
|corpus/class/11|498.894×318.1 → 498.894×315.1|-9.0|0/0|
|corpus/class/17|489.6×527.1 → 489.6×524.1|-6.0|10/10|
|corpus/class/18|456.0×495.1 → 456.0×492.1|-6.0|10/10|
|corpus/class/19|425.6×495.7 → 425.6×492.7|-6.0|10/10|
|corpus/class/20|480.0×318.1 → 480.0×315.1|-3.0|0/0|
|corpus/class/25|486.89×297.8 → 486.89×297.8|0.0|2/2|
|fixture/class-backends.mmd|864.992×263.2 → 864.992×260.2|-15.0|10/10|
|fixture/class-compound-backends.mmd|836.97×880.5 → 836.97×871.5|-12.0|0/0|

Student→IdCard actual shaft and all bodies/canvas are unchanged. carries center y63.3→69.3; rides218.5→217. carries prepared occupied+halo bottom77.95 remains6px clear of its shaft paint. No extra lost/reassigned caption is observed.

No actual glyph/head ink or recognizability claim: these are whole-SVG, authored correspondence, resource and geometric contact observations. Exact per-field canonical changes and raw products are retained in REVIEW.json/SUMMARY.json; no committed golden updated.
