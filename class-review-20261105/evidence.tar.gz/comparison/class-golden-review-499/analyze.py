# Offline source-authored review of the18 retained public SVG products; no rendering.
import json,gzip,pathlib,xml.etree.ElementTree as E,math,re,collections
p=pathlib.Path('/tmp/pr449-week-comparison-20261101/class-golden-review-499'); ns={'s':'http://www.w3.org/2000/svg'}
# Literal author contracts, independent of the production parser/layout.
authors={
'corpus/class/10':{'classes':{'class'+c:[] for c in 'ABCDEFGHIJKLMNOP'},'relations':[['classA','classB','inheritance','to','Inheritance'],['classC','classD','composition','to','Composition'],['classE','classF','aggregation','to','Aggregation'],['classG','classH','association','to','Association'],['classI','classJ','link-solid','none','Link(Solid)'],['classK','classL','dependency','to','Dependency'],['classM','classN','realization','to','Realization'],['classO','classP','link-dashed','none','Link(Dashed)']]},
'corpus/class/11':{'classes':{x:[] for x in ['classA','classB','classC','classD','classE','classF']},'relations':[['classA','classB','inheritance','from','implements'],['classC','classD','composition','from','composition'],['classE','classF','aggregation','from','aggregation']]},
'corpus/class/17':{'classes':{'Developer':['+writeCode()'],'Designer':['+createMockup()'],'TechLead':['+planSprint()']},'parents':{'Developer':'Company.Engineering.Backend','Designer':'Company.Engineering.Frontend','TechLead':'Company.Engineering'},'groups':[['Company',None,'Company'],['Company.Engineering','Company','Engineering'],['Company.Engineering.Backend','Company.Engineering','Backend'],['Company.Engineering.Frontend','Company.Engineering','Frontend']],'relations':[['TechLead','Developer','association','to','leads'],['TechLead','Designer','association','to','leads']]},
'corpus/class/18':{'classes':{'UserService':['+login()','+logout()'],'Repository':['+find()','+save()'],'Gateway':['+route()']},'parents':{'UserService':'Platform.Auth','Repository':'Platform.Data','Gateway':'Platform'},'groups':[['Platform',None,'Platform'],['Platform.Auth','Platform','Auth'],['Platform.Data','Platform','Data']],'relations':[['Gateway','UserService','association','to','delegates'],['Gateway','Repository','association','to','delegates']]},
'corpus/class/19':{'classes':{'Developer':['+writeCode()'],'Designer':['+createMockup()'],'CEO':['+makeDecisions()']},'parents':{'Developer':'Company.Engineering.Backend','Designer':'Company.Engineering.Frontend','CEO':'Company'},'groups':[['Company',None,'Company'],['Company.Engineering.Backend',None,'Company.Engineering.Backend'],['Company.Engineering.Frontend',None,'Company.Engineering.Frontend']],'relations':[['CEO','Developer','association','to','oversees'],['CEO','Designer','association','to','oversees']]},
'corpus/class/20':{'classes':{x:[] for x in ['Customer','Ticket','Student','Course','Galaxy','Star']},'relations':[['Customer','Ticket','association','to',None],['Student','Course','association','to',None],['Galaxy','Star','association','to','Contains']],'cardinalities':[['1','*'],['1','1..*'],[None,'many']]},
'corpus/class/25':{'classes':{'Student':['-idCard:IdCard'],'IdCard':['-id:int','-name:string'],'Bike':['-id:int','-name:string']},'relations':[['Student','IdCard','aggregation','to','carries'],['Student','Bike','aggregation','to','rides']],'cardinalities':[['1','1'],['1','1']]},
'fixture/class-backends.mmd':{'classes':{'Account':['+Stringname','+Stringfind(Stringkey)'],'Audit':['+intid'],'Repository':['+save(Accountvalue)']},'relations':[['Account','Audit','association','to','records'],['Account','Audit','dependency','to','reviews'],['Audit','Account','association','to','belongs'],['Account','Account','association','to','delegates'],['Repository','Account','aggregation','from','stores']],'cardinalities':[['1','many'],[None,None],[None,None],[None,None],[None,None]],'stereotype':['Account','<<entity>>'],'notes':[['Repository','Retain prepared note text']]},
'fixture/class-compound-backends.mmd':{'classes':{'class-namespace:Platform':['+Stringid','+fetch()'],'Store':['+Stringstate','+save()'],'User':['+UUIDid'],'Account':['+UUIDowner'],'Event':['+Stringaction'],'Record':['+Stringkey'],'Outside':[]},'interface':['interface0','Protocol'],'parents':{'class-namespace:Platform':'Platform','Store':'Platform','User':'Platform.Domain','Account':'Platform.Domain','Event':'Audit','Record':'Audit'},'groups':[['Platform',None,'Platform & API'],['Platform.Domain','Platform','Domain records'],['Audit',None,'Audit history']],'relations':[['class-namespace:Platform','Store','association','to','delegates'],['User','Account','aggregation','from','owns'],['Event','Record','association','to','logs'],['Outside','interface0','lollipop','to','uses']],'cardinalities':[[None,None],['1','many'],['1','many'],[None,None]],'notes':[['Store','Retain scoped note']]},
}
(p/'AUTHORED.json').write_text(json.dumps(authors,indent=2)+'\n')
def read(phase,id,name):return gzip.decompress((p/phase/id.replace('/','__')/name).read_bytes())
def text(e):return ''.join(e.itertext())
def clean(s):return re.sub(r'\s+','',s)
def f(e,key):return float(e.get(key))
def rect(e):return [f(e,'x'),f(e,'y'),f(e,'width'),f(e,'height')]
def contains(a,b):return a[0]<=b[0]+1e-7 and a[1]<=b[1]+1e-7 and a[0]+a[2]+1e-7>=b[0]+b[2] and a[1]+a[3]+1e-7>=b[1]+b[3]
def diffs(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):
  out=[]
  for k in dict.fromkeys([*a,*b]):
   if k not in a or k not in b:out.append({'path':path+'/'+k,'before':a.get(k),'after':b.get(k)})
   else:out.extend(diffs(a[k],b[k],path+'/'+k))
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'before':a,'after':b}]
  return sum((diffs(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [{'path':path,'before':a,'after':b}]
def projection(layout):
 d=json.loads(json.dumps(layout))
 for n in d['nodes']:
  for k in ['labelBounds','labelContainer','labelVisibility','dataPosition']:n.pop(k,None)
 for e in d['edges']:
  e.pop('visibility',None)
  if e.get('label'):e['label'].pop('bounds',None)
 return d
report={'publicSvgCalls':18,'rasters':0,'options':{},'scope':'Default source runtime products, no browser/raster/universal ink claim. Source-authored checks precede geometry review.','samples':[],'errors':[]}
for id,expected in authors.items():
 item={'id':id,'arms':{}}
 for phase in ['before','after']:
  svg=read(phase,id,'actual.svg.gz'); root=E.fromstring(svg); result=json.loads(read(phase,id,'RESULT.json.gz')); layout=json.loads(read(phase,id,'layout.json.gz'))['layout']; receipt=json.loads(read(phase,id,'receipt.json.gz'))
  errors=[]
  nodes=[e for e in root.iter() if e.get('class')=='class-node']; groupNodes=[e for e in root.iter() if e.get('class')=='namespace']; rel=[e for e in root.iter() if e.get('class')=='class-relationship']; classes={e.get('data-id'):e for e in nodes}; boxes={k:rect(next(e for e in node if e.tag.endswith('}rect'))) for k,node in classes.items()}; frames={g.get('data-id'):rect(next(e for e in g if e.tag.endswith('}rect'))) for g in groupNodes}
  if set(classes)!=set(expected['classes']):errors.append({'classIDs':list(classes),'expected':list(expected['classes'])})
  for ident,members in expected['classes'].items():
   g=classes.get(ident)
   if g is None:continue
   owntext=[text(t) for t in g.iter('{'+ns['s']+'}text')];actualMembers=[clean(text(t)) for t in g.iter('{'+ns['s']+'}text') if t.get('data-role')=='member']
   if ident not in owntext:errors.append({'missingOwnedName':ident})
   if actualMembers!=[clean(m) for m in members]:errors.append({'memberOwner':ident,'expected':members,'actual':actualMembers})
  groups=[[g.get('data-id'),g.get('data-parent-id'),g.get('data-label')] for g in groupNodes]
  if groups!=expected.get('groups',[]):errors.append({'groups':groups,'expected':expected.get('groups',[])})
  for ident,parent in expected.get('parents',{}).items():
   if not contains(frames[parent],boxes[ident]):errors.append({'physicalMembershipFailed':[ident,parent]})
  if 'interface' in expected:
   g=next((e for e in root.iter() if e.get('class')=='class-interface'),None)
   if g is None or [g.get('data-id'),g.get('data-label')]!=expected['interface'] or expected['interface'][1] not in [text(t) for t in g.iter('{'+ns['s']+'}text')]:errors.append({'interface':'missing/substituted'})
  if 'stereotype'in expected:
   ident,value=expected['stereotype']
   if value not in [text(t) for t in classes[ident].iter('{'+ns['s']+'}text')]:errors.append({'stereotype':'missing'})
  notes=[[g.get('data-for'),'\n'.join(text(t) for t in g.iter('{'+ns['s']+'}text'))] for g in root.iter() if g.get('class')=='class-note']
  if notes!=expected.get('notes',[]):errors.append({'notes':notes,'expected':expected.get('notes',[])})
  relations=[[e.get(k) for k in ['data-from','data-to','data-type','data-marker-at','data-label']] for e in rel]
  if relations!=expected['relations']:errors.append({'relationships':relations,'expected':expected['relations']})
  cards=[[e.get('data-from-cardinality'),e.get('data-to-cardinality')] for e in rel]
  if cards!=expected.get('cardinalities',[[None,None] for e in rel]):errors.append({'cardinalities':cards})
  alltexts=[text(t) for t in root.iter('{'+ns['s']+'}text')]; labels=collections.Counter(x[4] for x in expected['relations'] if x[4])
  for label,count in labels.items():
   if alltexts.count(label)!=count:errors.append({'captionOccurrences':label,'expected':count,'actual':alltexts.count(label)})
  resources={};ids=collections.Counter(e.get('id') for e in root.iter() if e.get('id')); contacts=[];unknown=[];wire=0;turns=0
  for i,e in enumerate(rel):
   points=[list(map(float,v.split(','))) for v in e.get('points').split()];compact=[v for j,v in enumerate(points) if j==0 or v!=points[j-1]]
   wire+=sum(math.dist(a,b) for a,b in zip(compact,compact[1:]));turns+=sum((b[0]-a[0])*(c[1]-b[1])!=(b[1]-a[1])*(c[0]-b[0]) for a,b,c in zip(compact,compact[1:],compact[2:]))
   for ident,point,adj in [(e.get('data-from'),compact[0],compact[1]),(e.get('data-to'),compact[-1],compact[-2])]:
    if ident not in boxes:unknown.append({'edge':i,'endpoint':ident,'reason':'Interface is painted by marker; no ordinary card rectangle authority.'});continue
    x,y,w,h=boxes[ident];px,py=point;dx,dy=adj[0]-px,adj[1]-py;eps=1e-6
    ok=(abs(px-x)<eps and dx<0 and abs(dy)<eps and y-eps<=py<=y+h+eps)or(abs(px-x-w)<eps and dx>0 and abs(dy)<eps and y-eps<=py<=y+h+eps)or(abs(py-y)<eps and dy<0 and abs(dx)<eps and x-eps<=px<=x+w+eps)or(abs(py-y-h)<eps and dy>0 and abs(dx)<eps and x-eps<=px<=x+w+eps)
    contacts.append({'edge':i,'endpoint':ident,'point':point,'normalOutward':ok})
   for key in ['marker-start','marker-end']:
    ref=e.get(key)
    if ref:
     resourceid=re.fullmatch(r'url\(#([^)]*)\)',ref).group(1);resource=next((x for x in root.iter() if x.tag.endswith('}marker') and x.get('id')==resourceid),None)
     if ids[resourceid]!=1 or resource is None:errors.append({'missingUniqueMarkerResource':resourceid})
     resources[resourceid]=E.tostring(resource,encoding='unicode') if resource is not None else None
  if not all(x['normalOutward'] for x in contacts):errors.append({'nonNormalContacts':[x for x in contacts if not x['normalOutward']]})
  item['arms'][phase]={'revision':result['revision'],'source':result['source'],'options':result['options'],'svgBytes':len(svg),'proofStatus':receipt.get('layoutCertification',{}).get('status'),'proofOperations':receipt.get('layoutCertification',{}).get('checks',{}).get('operations'),'proofIssues':receipt.get('layoutCertification',{}).get('issues'),'authorChecks':{'passed':not errors,'errors':errors,'classes':len(classes),'relations':len(rel),'captions':sum(labels.values()),'groups':groups,'namesMembersAndNotesChecked':True,'physicalMembershipChecked':len(expected.get('parents',{}))},'actualViewport':[float(root.get('width')),float(root.get('height'))],'shaftWire':wire,'turns':turns,'normalRectangleContacts':contacts,'contactUnknowns':unknown,'resources':resources,'layout':layout,'canonicalGeometry':projection(layout)}
  if errors:report['errors'].append({'id':id,'phase':phase,'errors':errors})
 before=item['arms']['before'];after=item['arms']['after']; assert before['source']==after['source'];assert before['options']==after['options']=={}
 item['wholeSvgBytesExact']=read('before',id,'actual.svg.gz')==read('after',id,'actual.svg.gz');item['entireReceiptBytesExact']=read('before',id,'receipt.json.gz')==read('after',id,'receipt.json.gz');item['geometryDifferences']=diffs(before['canonicalGeometry'],after['canonicalGeometry']);item['markerResourceBytesExact']=before['resources']==after['resources'];item['sourceAndOptionsExact']=True
 item['actualCaptionTextPrograms']={}
 for phase in ['before','after']:
  r=E.fromstring(read(phase,id,'actual.svg.gz'));item['actualCaptionTextPrograms'][phase]=[{'text':text(t),'attributes':dict(t.attrib),'lineOccupiedHeight':float(t.get('font-size'))*1.3,'haloWidth':float(t.get('stroke-width','0')),'occupiedPlusHaloHeight':float(t.get('font-size'))*1.3+float(t.get('stroke-width','0'))} for t in r.findall('s:text',ns) if text(t)in labels and t.get('data-role')!='cardinality']
 report['samples'].append(item)
(p/'REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'errors':report['errors'],'samples':[{'id':s['id'],'authorMeaning':[s['arms'][a]['authorChecks']['passed']for a in ['before','after']],'proof':[s['arms'][a]['proofStatus']for a in ['before','after']],'viewport':[s['arms'][a]['actualViewport']for a in ['before','after']],'wire':[s['arms'][a]['shaftWire']for a in ['before','after']],'turns':[s['arms'][a]['turns']for a in ['before','after']],'geometryChangedFields':len(s['geometryDifferences']),'resourcesExact':s['markerResourceBytesExact'],'normalContacts':[len(s['arms'][a]['normalRectangleContacts'])for a in ['before','after']]}for s in report['samples']]},indent=2))
