import {readFileSync,writeFileSync} from 'node:fs'
import {gunzipSync} from 'node:zlib'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js'
const root='/tmp/pr449-week-comparison-20261101/class-golden-review-499',fonts=['Regular','Medium','SemiBold','Bold'].map(name=>'/tmp/pr449-main-integration-20261029-762/assets/fonts/Inter-'+name+'.ttf')
const rows=[]
for(const arm of ['before','after']){
 const svg=gunzipSync(readFileSync(root+'/'+arm+'/corpus__class__25/actual.svg.gz')).toString()
 const texts=[...svg.matchAll(/<text\b[^>]*>[\s\S]*?<\/text>/g)].filter(m=>m[0].replace(/<[^>]*>/g,'').trim()==='carries')
 if(texts.length!==1)throw Error('Exactly one actual carries text required')
 const m=texts[0]!,without=svg.slice(0,m.index)+svg.slice(m.index!+m[0].length)
 const render=(source:string)=>{const image=new Resvg(source,{background:'#fff',fitTo:{mode:'zoom',value:1},font:{loadSystemFonts:false,fontFiles:fonts,defaultFontFamily:'Inter'}}).render();return {png:image.asPng(),data:image.pixels,width:image.width,height:image.height}}
 const full=render(svg),control=render(without)
 writeFileSync(root+'/'+arm+'-class25.png',full.png);writeFileSync(root+'/'+arm+'-class25-without-carries.png',control.png)
 const a=full,b=control;if(a.width!==b.width||a.height!==b.height)throw Error('Unexpected control dimensions')
 let darker=0,changed=0,x0=a.width,y0=a.height,x1=-1,y1=-1
 for(let y=0;y<a.height;y++)for(let x=0;x<a.width;x++){
  const at=(y*a.width+x)*4;let same=true;for(let c=0;c<4;c++)if(a.data[at+c]!==b.data[at+c])same=false
  if(!same){changed++;x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y)}
  const light=(v:Uint8Array)=>v[at]!+v[at+1]!+v[at+2]!
  if(light(a.data)<light(b.data))darker++
 }
 rows.push({arm,width:a.width,height:a.height,changed,darker,deltaBounds:[x0,y0,x1,y1]})
}
writeFileSync(root+'/CLASS25-INK.json',JSON.stringify({publicRenderCalls:0,offlineRasterCalls:4,scope:'Actual saved default SVG, Inter four bundled weights, zoom1; remove only complete carries text element, all other source bytes unchanged. No universal font/readability/head-ink claim.',rows},null,2)+'\n');console.log(JSON.stringify(rows))
