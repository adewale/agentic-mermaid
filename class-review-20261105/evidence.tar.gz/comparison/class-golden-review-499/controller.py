import subprocess,pathlib,json,time
p=pathlib.Path('/tmp/pr449-week-comparison-20261101/class-golden-review-499'); ids=['corpus/class/10','corpus/class/11','corpus/class/17','corpus/class/18','corpus/class/19','corpus/class/20','corpus/class/25','fixture/class-backends.mmd','fixture/class-compound-backends.mmd'];out=[]
for phase in ['before','after']:
 for id in ids:
  name=phase+'-'+id.replace('/','__');cmd=['/tmp/pr449-campaign-bin/bun',str(p/'capture.ts'),phase,id]
  import os
  env={**os.environ,'PR449_CLASS_GOLDEN_GO':'18'}
  t=time.time()
  with (p/(name+'.log')).open('w') as stdout,(p/(name+'.stderr')).open('w') as stderr:
   try:r=subprocess.run(cmd,env=env,stdout=stdout,stderr=stderr,timeout=90);entry={'phase':phase,'id':id,'exitCode':r.returncode,'wallSeconds':time.time()-t}
   except subprocess.TimeoutExpired:entry={'phase':phase,'id':id,'timedOut':True,'wallSeconds':time.time()-t}
  out.append(entry);(p/'CAPTURE-STATUS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(entry),flush=True)
  if entry.get('exitCode')!=0:raise SystemExit('Stopped on unexpected capture transport failure; no automatic retry.')
