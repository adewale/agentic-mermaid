# Private flat XML event storage — rejected

Base31f368fa9eec6128751340f32d969f9bebf87316. Production31 unprofiled split measured5.71ms semantic admission and13.86ms XMLgeneration perchain100 response; this justified one event-storage probe, not an expected13.86ms saving.

The candidate replaced private per-event tuples and paint replacement tuples with one null-prototype scalar buffer. Sixslots/event; kind and fixed-name mask packed intooneinteger; paint-presence storedseparately. This is padded flat AoS, notSoA. Most former events were2–3slots andprepared6slots rare, so reducedobjectcount also expandsprimitive-slotspan. No newcache/ownershipissuer; eventsequence/literalchecks/workcharges/caps unchanged. Finalhelper is runtime-private#event.

Final166writer+Native owners pass/1365assertions; lint passes. Both initialTS-private and finalruntime-private Node probes preserve27wholeSVGs AND27entirereceipts each, includingexactlogicalwork. These are unchanged-output validations, not correctnesscoveragegains.

Finalmatching seven-entry/maps Node stockrepeat processmedians171.90/161.92/177.82ms control versus160.04/171.64/172.14ms candidate. Labellededit94.52/116.19/115.95 versus122.71/145.70/129.60ms isadverse. Freshsource also mixed/adverse. Fullrepeat pooledmedians215.35→202.15ms areanobservation, notcausal13msgain; firsteditmixed. Target100ms notmet. No performance ratio.

FinalRSS125.28→124.63MiB, heap29.19→28.86MiB, transientheap9.88→9.54MiB; initialTS-private RSS125.05→126.07MiB wasadverse. Keepbothdistributions; smallfinalresourceimprovements do not establishcausalallocationbenefit or repaystock/editcosts. Browserpayloadunmeasured, noCI/sourceadoption.

Decision: stopthisrepresentation; do not tune furtherpadding/storagevariants. ExactbothNodebuilds, rawtimings/resources/products, sourcepatch/fullsource/SHAmanifest retained. Restoretrackedsource to31 onlyafterbyteidenticalbackupverification. ExistingPRsource remains31; no performancecompletionclaim.
