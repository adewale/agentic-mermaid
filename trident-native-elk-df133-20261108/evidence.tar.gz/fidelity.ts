import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {join} from 'node:path'
import {createHash} from 'node:crypto'
import {createRequire} from 'node:module'
import {assertMermaidOracle} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/mermaid-oracle.ts'
import {artifactIdentity,resolveArtifact,harnessIdentity} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/artifacts.ts'
import {createMeaningAdapter} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/fidelity/adapters.ts'
import {assessMeaning} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/fidelity/meaning.ts'
import {inspectFidelityPaint,plannedPaintCriteria} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/fidelity/paint.ts'
import {inspectQuantitativePaint,plannedQuantitativeCriteria} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/fidelity/paint-values.ts'
const root='/tmp/pr449-trident-df133-reference-20261108',out=import.meta.dir
process.env.MERMAID_REFERENCE_DIR='/tmp/pr449-main-integration-20261029-762';assertMermaidOracle()
const require=createRequire(root+'/package.json'),{chromium}=require('playwright'),api=await import(root+'/dist/index.js')
const artifact=resolveArtifact('adewale/agentic-mermaid',root,'agentic','node','dist/index.js')
writeFileSync(join(out,'IDENTITY-FINAL.json'),JSON.stringify({source:'df133c69480e71d230a0e9256b1103cc5068bd22',artifact:artifactIdentity(artifact),harness:harnessIdentity(join(out,'kit')),scope:'Canonical Node index+agent-core+providers; not complete release tarball. All later performance uses this frozen artifact.'},null,2)+'\n')
const adapter=await createMeaningAdapter({tool:'agentic',packageRoot:root})
const cases=JSON.parse(readFileSync(join(out,'FIDELITY-CASES.json'),'utf8')).selected
const directory=join(out,'fidelity');mkdirSync(directory,{recursive:true});mkdirSync(join(directory,'svg'),{recursive:true});mkdirSync(join(directory,'screenshots'),{recursive:true})
writeFileSync(join(directory,'CRITERIA-PLAN.json'),JSON.stringify(cases.map((c:any)=>({id:c.id,family:c.family,expected:c.expected,paint:plannedPaintCriteria(c),quantitative:plannedQuantitativeCriteria(c)})),null,2)+'\n')
const fontRows=[['Inter-Regular.ttf','400','1b08e7fc267a5c7e1d614100f604b83e7e8a0be241f0f288faa2b3ac93a683ba'],['Inter-Medium.ttf','500','8c883f63b2c4157d997319f2c8bc6995ed4357ef371940d31ca159004a4aae63'],['Inter-SemiBold.ttf','600','e7a1aaf7eda9f2fad4131725fa556265ec75ca7b2d756260173a040363e8d4f7'],['Inter-Bold.ttf','700','b37284b5701b6b168dfc770aa1a4ac492106422fd3ba76bc7641e37434e8019c']].map(([file,weight,sha256])=>{const b=readFileSync(join(root,'assets/fonts',file!));if(createHash('sha256').update(b).digest('hex')!==sha256)throw Error('Font mismatch');return {file,weight,sha256,data:b.toString('base64')}})
writeFileSync(join(directory,'FONTS.json'),JSON.stringify(fontRows.map(({data,...x})=>x),null,2)+'\n')
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']})
const context=await browser.newContext({viewport:{width:1400,height:1000},serviceWorkers:'block'}),page=await context.newPage()
const blockedRequests:string[]=[];await context.route('**/*',(route:any)=>route.request().url().startsWith('data:')?route.continue():(blockedRequests.push(route.request().url()),route.abort()))
await page.goto('about:blank');await page.evaluate(async faces=>{const all=[];for(const f of faces){const face=new FontFace('Inter',`url(data:font/ttf;base64,${f.data})`,{weight:f.weight});await face.load();all.push(face)};(globalThis as any).__ownedFonts=all},fontRows)
const rows:any[]=[]
try{
 for(let index=0;index<cases.length;index++){
  const c=cases[index]
  for(const backend of index%2?['elk','agentic']:['agentic','elk']){
   const stem=index+'-'+c.id.replace(/[^a-zA-Z0-9_.-]/g,'_')+'-'+backend
   let acquired:any,meaning:any,rendered:any,paint:any,quantitative:any,preludes:any[]=[]
   try{
    for(const prelude of c.prelude??[]){try{api.renderMermaidSVG(prelude.source);preludes.push({accepted:true,expected:prelude.accept})}catch(e){preludes.push({accepted:false,expected:prelude.accept,error:String(e)})};await adapter.parse(prelude.source,c.family)}
    acquired=await adapter.parse(c.source,c.family);meaning=assessMeaning(c,acquired.meaning)
    try{const product=api.renderMermaidSVGWithReceipt(c.source,{...c.renderOptions,graphLayout:{backend,fallback:'none'}});rendered={accepted:true,svg:product.svg,receipt:product.receipt};writeFileSync(join(directory,'svg',stem+'.svg'),product.svg)}catch(e){rendered={accepted:false,error:String(e),name:(e as any).name}}
    if(rendered.accepted){
     await page.setContent(rendered.svg,{waitUntil:'domcontentloaded',timeout:30000});await page.evaluate(()=>{document.body.style.margin='0';document.body.style.background='#fff';for(const face of (globalThis as any).__ownedFonts??[])document.fonts.add(face)})
     paint=await page.evaluate(inspectFidelityPaint,{family:c.family,expected:c.expected,paint:c.paint});quantitative=await page.evaluate(inspectQuantitativePaint,{family:c.family,expected:c.expected,source:c.source,nodes:paint.nodes})
     if(paint.checks.some((x:any)=>x.status==='failed')||quantitative.some((x:any)=>x.status==='failed'))await page.screenshot({path:join(directory,'screenshots',stem+'.png'),fullPage:false})
    }
   }catch(e){rendered??={accepted:false};rendered.observerError=String(e)}
   const row={id:c.id,family:c.family,backend,preludes,acquired,meaning,rendered,paint,quantitative,scope:'Unmodified Trident meaning adapter and Chromium paint/quantitative observers on actual public Node SVG; not browser renderer execution. Font metrics/clipping/full feature-combination and observer-unavailable criteria remain explicit.'};rows.push(row);writeFileSync(join(directory,stem+'.json'),JSON.stringify(row,null,2)+'\n');writeFileSync(join(directory,'RESULTS.json'),JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify({completed:rows.length,total:cases.length*2,id:c.id,backend,returned:rendered?.accepted,meaningPassed:meaning?.passed,meaningComplete:meaning?.complete,paintFailed:paint?.checks.filter((x:any)=>x.status==='failed').map((x:any)=>x.criterion),observerError:rendered?.observerError}))
  }
 }
 writeFileSync(join(directory,'BROWSER.json'),JSON.stringify({version:browser.version(),blockedRequests,fonts:'Four manifest-verified Inter faces; other families/fallbacks unqualified.',scope:'Screenshots are1400x1000 viewport crops of failed observer cases, not whole-diagram qualification.'},null,2)+'\n')
}finally{await browser.close()}
writeFileSync(join(out,'FIDELITY-COMPLETED.json'),JSON.stringify({rows:rows.length,scope:'30 fixed graph-related expanded Trident authored cases,60backend products. Every refusal/failure/unavailable retained.'},null,2)+'\n')
