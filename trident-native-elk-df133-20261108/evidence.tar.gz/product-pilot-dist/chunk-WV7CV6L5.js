import{I as t,K as r}from"./chunk-5LNHV6WC.js";function a(e,n){t(e);r(e,n);return e}export{a};
//# sourceMappingURL=chunk-WV7CV6L5.js.map