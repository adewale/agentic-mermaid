import {readFileSync,writeFileSync} from 'node:fs'
import {artifactIdentity,harnessIdentity} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/artifacts.ts'
const before=JSON.parse(readFileSync(import.meta.dir+'/IDENTITY-FINAL.json','utf8'))
const after={artifact:artifactIdentity(before.artifact.artifact),harness:harnessIdentity(import.meta.dir+'/kit')}
const result={artifactExact:JSON.stringify(before.artifact)===JSON.stringify(after.artifact),harnessExact:JSON.stringify(before.harness)===JSON.stringify(after.harness)}
writeFileSync(import.meta.dir+'/POST-RUN-IDENTITY.json',JSON.stringify(result,null,2)+'\n')
if(!result.artifactExact||!result.harnessExact)throw Error('Identity changed')
console.log(JSON.stringify(result))
