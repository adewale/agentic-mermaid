import {readFileSync,writeFileSync,mkdirSync,appendFileSync} from 'node:fs'
import {join} from 'node:path'
import {createHash} from 'node:crypto'
import {assertMermaidOracle,assertOracleAgrees} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/mermaid-oracle.ts'
import {resolveArtifact,artifactIdentity,harnessIdentity} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/artifacts.ts'
import {environmentIdentity} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/environment.ts'
import {runSerialJob} from './kit/execution.mjs'
const out=import.meta.dir, root='/tmp/pr449-trident-df133-reference-20261108'
process.env.MERMAID_REFERENCE_DIR='/tmp/pr449-main-integration-20261029-762'
process.env.AGENTIC_MERMAID_ELK_CACHE='0'
const oracle=assertMermaidOracle(), cases=JSON.parse(readFileSync(join(out,'CASES.json'),'utf8'))
const verdicts=await assertOracleAgrees(oracle,cases.all.flatMap((c:any)=>[{id:c.id,source:c.source,accept:c.expected.accept},...(c.prelude??[]).map((p:any,i:number)=>({id:c.id+'#prelude'+i,source:p.source,accept:p.accept})),...(c.edit?[{id:c.id+'#edit',source:c.edit.source,accept:c.edit.expected.accept}]:[])]))
writeFileSync(join(out,'ORACLE-AGREEMENT.json'),JSON.stringify({oracle,verdicts},null,2)+'\n')
const artifact=resolveArtifact('adewale/agentic-mermaid',root,'agentic','node','dist/index.js')
writeFileSync(join(out,'IDENTITY.json'),JSON.stringify({source:'df133c69480e71d230a0e9256b1103cc5068bd22',trident:'f080278e31e4202ca89d524e4ee9e4cf3cbff038',artifact:artifactIdentity(artifact),harness:harnessIdentity(join(out,'kit')),environment:environmentIdentity('node'),oracle,scope:'Canonical Node library/runtime-provider build in clean exact Git worktree. No IIFE/lazy/PNG/CLI build; not a full published tarball. Unchanged compiled Trident worker/execution/qualification. Public SVG-only protocol, not SVG+receipt API.'},null,2)+'\n')
const directory=join(out,'pilot');mkdirSync(directory,{recursive:true});mkdirSync(join(directory,'svg'),{recursive:true});mkdirSync(join(directory,'failures'),{recursive:true})
function selected(c:any,backend:string){return {...c,renderOptions:{...c.renderOptions,graphLayout:{backend,fallback:'none'}},...(c.edit?{edit:{...c.edit,renderOptions:{...(c.edit.renderOptions??c.renderOptions),graphLayout:{backend,fallback:'none'}}}}:{})}}
let completed=0
for(let index=0;index<cases.selected.length;index++){
 const c=cases.selected[index], backends=index%2?['elk','agentic']:['agentic','elk']
 for(const backend of backends){
  const stem=c.id.replaceAll(':','_')+'-'+backend
  const job={artifact,testCase:selected(c,backend),mode:'warm',samples:1,minSampleMs:0,workerTimeoutMs:60000,round:1,replica:'B',sample:0,fullEvidence:true,svgFile:join(directory,'svg',stem+'.svg'),diagnosticFile:join(directory,'failures',stem+'.json')}
  writeFileSync(join(directory,stem+'.job.json'),JSON.stringify(job,null,2)+'\n')
  try{const result=await runSerialJob(job,'node');writeFileSync(join(directory,stem+'.result.json'),JSON.stringify(result,null,2)+'\n');appendFileSync(join(directory,'results.jsonl'),JSON.stringify({backend,cache:0,job,result})+'\n');console.log(JSON.stringify({completed:++completed,total:cases.selected.length*2,case:c.id,backend,status:result.status,semanticComplete:result.qualification?.semanticComplete,failures:result.qualification?.checks.filter((x:any)=>x.status==='failed').map((x:any)=>x.name)}))}
  catch(error){appendFileSync(join(directory,'results.jsonl'),JSON.stringify({backend,cache:0,job,lifecycleError:String(error)})+'\n');console.log(JSON.stringify({completed:++completed,case:c.id,backend,lifecycleError:String(error)}))}
 }
}
writeFileSync(join(out,'PILOT-COMPLETED.json'),JSON.stringify({completed,scope:'Qualification pilot; one sample/track; not calibrated performance or a representative-workload verdict.'},null,2)+'\n')
