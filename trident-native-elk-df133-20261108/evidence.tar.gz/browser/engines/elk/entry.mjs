import * as api from './browser-lazy/index.js';
import {declaredRenderer} from './declared-adapter.mjs';
export async function createRenderer(){return declaredRenderer(api,{"export":"renderMermaidSVGAsync","options":{"graphLayout":{"backend":"elk","fallback":"none"}}},'svg')}
globalThis.unifiedMermaid={createRenderer};
