import {readFileSync,writeFileSync,mkdirSync,appendFileSync,existsSync} from 'node:fs'
import {join} from 'node:path'
import {createHash} from 'node:crypto'
import {assertMermaidOracle} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/mermaid-oracle.ts'
import {environmentIdentity} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/environment.ts'
import {runSerialJob,runFirstUseBatch} from './kit/execution.mjs'
const out=import.meta.dir
if(!existsSync(join(out,'FIDELITY-COMPLETED.json')))throw Error('Finish and close browser fidelity before timing')
process.env.MERMAID_REFERENCE_DIR='/tmp/pr449-main-integration-20261029-762';assertMermaidOracle()
const artifact=JSON.parse(readFileSync(join(out,'IDENTITY-FINAL.json'),'utf8')).artifact.artifact,cases=JSON.parse(readFileSync(join(out,'CASES.json'),'utf8')).selected
const observer=join(out,'gnu-time/usr/bin/time'),directory=join(out,'performance');mkdirSync(directory,{recursive:true});for(const sub of ['jobs','results','failures','svg'])mkdirSync(join(directory,sub),{recursive:true})
writeFileSync(join(directory,'ENVIRONMENT.json'),JSON.stringify({environment:environmentIdentity('node'),observer:{path:observer,sha256:createHash('sha256').update(readFileSync(observer)).digest('hex')},cacheRegimes:[0,1],plan:JSON.parse(readFileSync(join(out,'PERFORMANCE-PLAN.json'),'utf8'))},null,2)+'\n')
function selected(c:any,backend:string){return {...c,renderOptions:{...c.renderOptions,graphLayout:{backend,fallback:'none'}},...(c.edit?{edit:{...c.edit,renderOptions:{...(c.edit.renderOptions??c.renderOptions),graphLayout:{backend,fallback:'none'}}}}:{})}}
let completed=0,errors=0
function jobFor(c:any,backend:string,cache:number,mode:string,replica:string){const stem=`cache${cache}-${backend}-${c.id.replaceAll(':','_')}-${mode}-${replica}`;const job={artifact,testCase:selected(c,backend),mode,samples:7,minSampleMs:2,workerTimeoutMs:120000,round:1,replica,sample:0,fullEvidence:mode==='warm'&&replica==='B',diagnosticFile:join(directory,'failures',stem+'.json'),...(mode==='warm'&&replica==='B'?{svgFile:join(directory,'svg',stem+'.svg')}:{})};writeFileSync(join(directory,'jobs',stem+'.json'),JSON.stringify(job,null,2)+'\n');return {stem,job}}
function retain(result:any,meta:any){writeFileSync(join(directory,'results',meta.stem+'.json'),JSON.stringify(result,null,2)+'\n');appendFileSync(join(directory,'results.jsonl'),JSON.stringify({backend:meta.backend,cache:meta.cache,stem:meta.stem,result})+'\n');completed++;if(completed%24===0)console.log(JSON.stringify({completed,errors,mode:result.mode,case:result.caseId,backend:meta.backend,cache:meta.cache,status:result.status}))}
async function serial(c:any,backend:string,cache:number,mode:string,replica:string){const meta={...jobFor(c,backend,cache,mode,replica),backend,cache};try{const result=await runSerialJob(meta.job,'node',['memory','baseline','retention'].includes(mode)?observer:undefined);retain(result,meta)}catch(e){errors++;appendFileSync(join(directory,'lifecycle-errors.jsonl'),JSON.stringify({backend,cache,job:meta.job,error:String(e)})+'\n');console.log(JSON.stringify({errors,case:c.id,backend,cache,mode,error:String(e)}))}}
for(const cache of [0,1]){
 process.env.AGENTIC_MERMAID_ELK_CACHE=String(cache)
 for(const mode of ['warm','cold','resources']){
  for(let index=0;index<cases.length;index++){
   const c=cases[index],backends=(index+cache+(mode==='cold'?1:0))%2?['elk','agentic']:['agentic','elk'],base=['A0','A1','B'],offset=index%3,replicas=[...base.slice(offset),...base.slice(0,offset)]
   for(const backend of backends){
    if(mode==='cold'){
     const metas=replicas.map(replica=>({...jobFor(c,backend,cache,'cold',replica),backend,cache}))
     try{await runFirstUseBatch(metas.map(m=>m.job),'node',3,(result:any)=>{const m=metas.find(m=>m.job.replica===result.replica)!;retain(result,m)})}catch(e){errors++;appendFileSync(join(directory,'lifecycle-errors.jsonl'),JSON.stringify({backend,cache,case:c.id,mode,error:String(e)})+'\n');console.log(JSON.stringify({errors,case:c.id,backend,cache,mode,error:String(e)}))}
    }else for(const replica of replicas){if(mode==='warm')await serial(c,backend,cache,'warm',replica);else for(const resourceMode of replica==='A1'?['memory','baseline']:['baseline','memory'])await serial(c,backend,cache,resourceMode,replica)}
   }
  }
  console.log(JSON.stringify({phaseCompleted:mode,cache,completed,errors}))
 }
 const retention=cases.find((c:any)=>c.id==='scaling:flowchart:8');for(const backend of cache?['elk','agentic']:['agentic','elk'])await serial(retention,backend,cache,'retention','B')
}
writeFileSync(join(out,'PERFORMANCE-COMPLETED.json'),JSON.stringify({completed,errors,scope:'Exploratory unchanged Trident SVG-only worker protocol: one round,7warm samples,3fresh processes per cell/mode. Below full calibration requirements. No qualified general speed ratio.'},null,2)+'\n')
console.log(JSON.stringify({finished:true,completed,errors}))
