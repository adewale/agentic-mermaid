import {readFileSync} from 'node:fs'
Bun.plugin({name:'capture-duplicates',setup(build){build.onLoad({filter:/\/src\/scene\/native-paint-emission\.ts$/},args=>{
let code=readFileSync(args.path,'utf8')
code=code.replace('const work = createNativeXmlWork(maxOperations)',`const visits=new WeakMap<object,Set<string>>(),counts:Record<string,{visits:number,duplicate:number,keys:number,duplicateKeys:number}>={}; const work = createNativeXmlWork(maxOperations)`)
code=code.replace('const deferredProjection = deferredTerminalProjectionInput(value)',`if(close){const label=context??'other'; const row=counts[label]??= {visits:0,duplicate:0,keys:0,duplicateKeys:0};row.visits++;row.keys+=keys.length;let contexts=visits.get(value);if(!contexts){contexts=new Set();visits.set(value,contexts)}if(contexts.has(label)){row.duplicate++;row.duplicateKeys+=keys.length}contexts.add(label)}
const deferredProjection = deferredTerminalProjectionInput(value)`)
code=code.replace('const checked = new Map<string, CheckedMarkerResource>()',`console.error(JSON.stringify({phase:'capture-duplicates',counts,operations:work.operations(),exhausted:work.exhausted()}));const checked = new Map<string, CheckedMarkerResource>()`)
return {contents:code,loader:'ts'}
})}})
