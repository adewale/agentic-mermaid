import {readFileSync} from 'node:fs'
import {parseMermaid} from '/dev/shm/pr449-four-final-20261111/finish-remaining-fc4/src/parser.ts'
import {layoutGraphSync} from '/dev/shm/pr449-four-final-20261111/finish-remaining-fc4/src/layout-engine.ts'
import {measureRubricMetrics} from '/dev/shm/pr449-four-final-20261111/finish-remaining-fc4/src/layout-rubric.ts'
import {canRetainRouteMarkerPeers} from '/dev/shm/pr449-four-final-20261111/finish-remaining-fc4/src/route-contracts.ts'
import {resolveRenderStyle} from '/dev/shm/pr449-four-final-20261111/finish-remaining-fc4/src/styles.ts'
const cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-main-20261110/MEASUREMENT-CASES.json','utf8'))
for(const id of ['diagnostic:chain100','diagnostic:chain300']){
 const graph=parseMermaid(cases.find((c:any)=>c.id===id).source),style=resolveRenderStyle({}),positioned=layoutGraphSync(graph,{graphLayout:{backend:'agentic',fallback:'none'}} as any)
 const reference=measureRubricMetrics(graph,positioned,['hard'],style)
 const rows=[]
 for(const enabled of [false,true,false,true]){const start=performance.now();for(let i=0;i<20;i++){const result=measureRubricMetrics(graph,positioned,['hard'],style,new Set(),enabled);if(JSON.stringify(result)!==JSON.stringify(reference))throw Error('result changed')} rows.push({enabled,msPerCheck:(performance.now()-start)/20})}
 console.log(JSON.stringify({id,admission:canRetainRouteMarkerPeers(positioned,style),rows}))
}
