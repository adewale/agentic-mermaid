import { build } from '/tmp/pr449-main-integration-20261029-762/node_modules/tsup/dist/index.js';
import config from '/dev/shm/pr449-four-final-20261111/finish-remaining-fc4/tsup.browser-lazy.config.ts';
await build({...config, esbuildPlugins:config.esbuildPlugins.filter(p=>p.name!=='compact-browser-modules'),outDir:'/dev/shm/pr449-four-final-20261111/finish-minify-input',dts:false,config:false});
