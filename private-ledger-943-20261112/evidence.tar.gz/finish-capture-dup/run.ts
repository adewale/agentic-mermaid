import {readFileSync} from 'node:fs'
process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS='0';process.env.AGENTIC_MERMAID_ELK_CACHE='0'
const {renderMermaidSVGWithReceipt}=await import('/dev/shm/pr449-four-final-20261111/finish-remaining-fc4/src/index.ts')
const cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-main-20261110/MEASUREMENT-CASES.json','utf8'))
for(const id of ['diagnostic:chain100','diagnostic:chain300']){console.error(JSON.stringify({id}));const result=renderMermaidSVGWithReceipt(cases.find((c:any)=>c.id===id).source,{graphLayout:{backend:'agentic',fallback:'none'}}); console.log(JSON.stringify({id,proof:result.receipt.layoutCertification}))}
