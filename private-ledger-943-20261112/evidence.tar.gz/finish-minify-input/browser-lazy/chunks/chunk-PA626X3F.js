function a(i){let n=i.familyBody.split(/\r?\n/),r=n.findIndex(t=>t.trim()===i.familyLines[0]);return[n[r]?.trim()??i.familyLines[0]??"",...n.slice(r+1)]}export{a};
