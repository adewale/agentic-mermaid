import{ta as h,ua as m,va as d}from"./chunk-7YT2AGNZ.js";function w(o,a,t,e,n,g){let i=e.font??"Inter",r=h(e);return{family:a,width:t.width,height:t.height,colors:e,transparent:n,parts:[o.documentOpen({id:"prelude",width:t.width,height:t.height,colors:e,transparent:n,font:i,hasMonoFont:!1},`${d(t.width,t.height,e,n)}
${m(i,!1,e.shadow,e.embedFontImport)}${r?`
<defs>${r}</defs>`:""}`),...g,o.documentClose()]}}export{w as a};
