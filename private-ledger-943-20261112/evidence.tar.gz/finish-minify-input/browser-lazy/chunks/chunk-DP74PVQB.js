import{n as t,o as e}from"./chunk-WYYFV4OW.js";import{b as a}from"./chunk-WHWGUZB6.js";function p(r){return e(r,a)}function S(r,o){return t(p,r,o)}export{p as a,S as b};
