var r=Object.hasOwn;function n(e){if(r(e,"contactDiamond")&&e.contactDiamond!==void 0&&e.contact!=="diamond")throw new TypeError("Diamond support requires a diamond contact")}export{n as a};
