import {readFileSync,writeFileSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
const root=process.argv[2]!,out=process.argv[3]!
const {snapshotSample}=await import(root+'/eval/layout-compare/run.ts')
const jobs=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/rebase-c366-reconsider-20261107/CURRENT-MAIN-PAIR-JOBS.json','utf8'))
const rows=[]
for(const job of jobs) for(const backend of ['agentic','elk'] as const) {
 const sample=snapshotSample(job,'review-',{graphLayout:{backend,fallback:'none'}},{includeAscii:false});rows.push({backend,...sample});
 console.log(JSON.stringify({id:job.id,backend,ok:sample.ok,proof:sample.svgReceipt?.layoutCertification?.status,route:sample.metrics?.routeGeometry,error:sample.error}))
}
writeFileSync(out,gzipSync(JSON.stringify({root,source:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),runtime:process.versions,scope:'Two named same-input checks using existing collector; no timing ratio; final SVG and public layout/proof retained',rows}),{level:9}))
