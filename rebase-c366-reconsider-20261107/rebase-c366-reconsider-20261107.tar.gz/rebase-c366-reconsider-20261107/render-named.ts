import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';import{createHash}from'node:crypto';import{Resvg}from'/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js';import{HOSTED_FONT_RESOURCES}from'/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts';import{inlineFontVarForRaster}from'/tmp/pr449-main-integration-20261029-762/src/theme.ts';import{prepareResvgMarkerOrientation}from'/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts';
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/rebase-c366-reconsider-20261107';const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const p=root+'/'+f.path;if(createHash('sha256').update(readFileSync(p)).digest('hex')!==f.sha256)throw Error('font mismatch');return p});const rows=[];
for(const variant of ['main','pr']) {
const doc=JSON.parse(gunzipSync(readFileSync(out+'/'+variant+'-named.json.gz')).toString());
for(const sample of doc.rows.filter((r:any)=>r.backend==='agentic')) {
 const name=sample.id+'-'+variant,svg=sample.svg;writeFileSync(out+'/'+name+'.svg',svg);
 const picture=new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(svg)),{background:'#fff',fitTo:{mode:'zoom',value:2},font:{fontFiles:fonts,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render().asPng();
 writeFileSync(out+'/'+name+'.png',picture);rows.push({name,source:doc.source,svgSHA256:createHash('sha256').update(svg).digest('hex'),font:'manifest-verified Inter; system fonts disabled',zoom:2,claim:'Actual final public SVG; named geometry comparison only, not whole-corpus ink qualification.'})
}}
writeFileSync(out+'/VISUALS.json',JSON.stringify(rows,null,2));console.log(rows)
