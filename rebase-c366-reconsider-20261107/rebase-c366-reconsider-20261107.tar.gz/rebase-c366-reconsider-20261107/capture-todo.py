import sys
from pathlib import Path
Path('/tmp/pr449-week-comparison-20261101/rebase-c366-reconsider-20261107/rebase-todo.txt').write_bytes(Path(sys.argv[1]).read_bytes())
raise SystemExit(1)
