This PR repairs selected layout delivery and visible SVG losses while preserving the PR449 ownership and capture foundation. The latest change makes 256-entity ER chains deliver in LR and TB through both Native and ELK, within the existing work cap. **The PR remains draft; general ELK replacement and a runtime speedup are not established.**

Head: `d8c8ac879793a586b4b741c178b89d7900bd27ed`. Integrated main: `9fb35b8bf8dc654a19612de3cc6a50144d68b0a7`. Backend defaults, versions and original caps are unchanged.

## Latest repair: shared ER256 delivery

With `fallback: 'none'`, the same chain of 256 entities and 255 labelled `||--o{` relationships previously refused at the 400,000 geometry allowance. Native and ELK now return complete SVGs with passed final proofs in LR and TB. Each contains all 256 authored identities, 255 ordered relationships, 255 caption occurrences and 510 cardinality carriers. **BT and RL still refuse.**

The shared ER finalizer already has a fixed-body/header spatial index. It now reuses that index for raw-segment/body and painted-shaft/body checks, preserving the exact interior and incident-border predicates. The index builder also reuses a parent's sorted order while a child keeps the same immutable axis and tie rule. Neither change alone is sufficient. Together, Native LR finishes the diagnostic geometry ledger at 397,206; its separate final paint proof uses 341,240 operations. No collision check or allowance is removed.

[Results, reproduction, profiles and recovery archive](https://github.com/adewale/agentic-mermaid/blob/027ce160ee147e9a7aea032219298b5b215fe3f7/er256-d8c8ac879-20261107/README.md). [Independent source review](https://github.com/adewale/agentic-mermaid/blob/027ce160ee147e9a7aea032219298b5b215fe3f7/er256-d8c8ac879-20261107/independent-review.md).

## Other retained improvements

The preceding ranked pass reduced Class area losses against ELK from 13 to 11 across 40 cases. Nine drawings shrink; Class2 projected area changes 85,680→65,400 against ELK's 61,400.

For the selected variable-height forest, actual Native TB wire falls 436.8572→397.7072 against ELK's 396.4697: the gap falls from 10.19% to 0.31%, while Native retains its 6.43% smaller canvas. BT/LR/RL routes also shorten. Complete components use bounded packing proposals; local projections retain their external-contact arrangement, and the shared consumer preserves Native's measured boxes.

Earlier selected main-relative comparisons establish ER208 delivery, Native Sparse256 and Requirement compaction, and actual selected shaft/head paint repairs. The PR also releases completed construction evidence, makes write completion/abort and proof identity explicit, publishes route/label facts together, and repairs reentrant publication and worker-payload lifetime. Those historical comparisons are linked with their revisions; they are not a new final-head main benchmark.

[Prior ranked results and visuals](https://github.com/adewale/agentic-mermaid/blob/8b0160535aa2818f9454ab4aee013dfd6bceb360/ranked-losses-13143a343-20261107/README.md). [Earlier paint and ownership work](https://github.com/adewale/agentic-mermaid/tree/ecfc69324aabf41fa39dca4e831f6cce08c42169/stopped-62d-20261107). [Lifetime and write cleanup](https://github.com/adewale/agentic-mermaid/tree/a67cfe19edeef8bd29bf617192e97050d53d53d2/invariant-plan-433b-20261107).

## Verification and costs

Four existing backend/direction owner cases fail on the original runtime and pass after restoring this repair: [4 RED](https://github.com/adewale/agentic-mermaid/blob/027ce160ee147e9a7aea032219298b5b215fe3f7/er256-d8c8ac879-20261107/final-chain-red.log) → [4 GREEN, 48 assertions](https://github.com/adewale/agentic-mermaid/blob/027ce160ee147e9a7aea032219298b5b215fe3f7/er256-d8c8ac879-20261107/final-chain-restored-green.log). Reproduce with:

```sh
bun test src/__tests__/er-layout-backends.test.ts --timeout 30000 --test-name-pattern '256-entity chain'
```

Fresh qualification covers 874 Native and 874 ELK cases. All 1,748 SVGs, layout geometry and route vectors match preceding controls exactly; delivery and proof statuses remain unchanged. Work counts decrease. Twenty-seven other spacing/proximity diagnostics have floating-point differences no larger than 7.11e-15, retained in the summaries. An additional 180 mixed-axis/tie/reversed index cases preserve tree ordering and 2,880 strict queries.

Broad owners: 918 pass, the retained Sparse32 proof-cap failure, and one sandbox stdin error whose isolated retry passes. Final affected ER owners: 104 pass; expanded chain matrix: four pass. Core types and canonical lint pass. The actual rebuilt standalone passes both browser checks and 505 assertions. Pinned jsdom26.1.0 was restored under /tmp for existing tests; lockfiles are unchanged.

Complete standalone HTML, same Bun1.4.4 compression, before→after:

| Measure | Bytes |
| --- | ---: |
| Raw | 2,205,439→2,204,863 (−576) |
| Gzip9 | 1,324,974→1,324,640 (−334) |
| Brotli11 | 1,258,458→1,258,659 (+201) |

The original standalone ceiling remains. Earlier lazy-payload/Brotli costs remain in the linked reports. No CPU/RSS saving follows from comparing an ER256 refusal with a fully delivered product. [Five measured self/inclusive hotspots and cache context](https://github.com/adewale/agentic-mermaid/blob/027ce160ee147e9a7aea032219298b5b215fe3f7/er256-d8c8ac879-20261107/PROFILE-FIRST.md).

[Exact-head CI42398164647](https://github.com/adewale/agentic-mermaid/actions/runs/42398164647) completed with failure. The PR remains draft and is not ready to merge.

## Remaining losses and stopped proposals

ER256 BT/RL, Sparse32 proof availability and other unverified drawings remain. Crossing276 retains six crossings against ELK's four; its global search trial introduced 39 attenuated shaft pixels elsewhere and was withdrawn. Sparse256's shipped area gap is +5.04%; the +1.34% prototype grows height 31.04% and gzip size, and the historical +0.97% backfill candidate remains unshipped. A new reversed-sort shortcut still refuses BT and is stopped.

Geometry vectors and certificates do not establish every visible output. Original baseline2dad, Trident and pinned Mermaid12.2/Pele1.9 remain unavailable. Replacement24 stays sealed. Automated campaign/deadline reporting remain disabled; this was one bounded manual run.

## Visual evidence

Baseline SHA: `dda69ef2287da0ad569d334f0b200cc186de8c05`.
Current head SHA: `d8c8ac879793a586b4b741c178b89d7900bd27ed`.

Before: ER256 refused, so there is no before SVG; the failed owner output is linked above. After: these are middle viewport crops of the actual final LR SVGs, rasterized with manifest-verified Inter and system fonts disabled. Inspect N126→N127→N128, the caption pills and cardinality glyphs. Beginning/end crops and complete SVGs are in the evidence. Selected crops do not qualify whole-diagram readability.

![Native ER256 after: middle cards, captions and cardinality glyphs](https://raw.githubusercontent.com/adewale/agentic-mermaid/027ce160ee147e9a7aea032219298b5b215fe3f7/er256-d8c8ac879-20261107/agentic-middle.png)

![ELK ER256 after: the same authored middle relationships](https://raw.githubusercontent.com/adewale/agentic-mermaid/027ce160ee147e9a7aea032219298b5b215fe3f7/er256-d8c8ac879-20261107/elk-middle.png)


## Native/ELK comparison at this head

[Correctness comparison](https://github.com/adewale/agentic-mermaid/blob/8ccaf0655cfb596809400dd97600caacf9eb2c89/native-elk-comparison-d8c8ac879-20261107/CORRECTNESS.md) separates delivery, independent actual-SVG meaning/shape/resource checks, proof availability and layout vectors. [Performance comparison and raw recovery data](https://github.com/adewale/agentic-mermaid/blob/8ccaf0655cfb596809400dd97600caacf9eb2c89/native-elk-comparison-d8c8ac879-20261107/PERFORMANCE.md) cover 96 fresh Node processes and 672 complete calls, with first-render/import/repeat/cache/edit, CPU/heap/RSS and actual compressed products kept separate. Native wins uncached repeat medians in five of six measured cases; cached results are mixed. Both lanes use this PR's shared pipeline. Source code is unchanged by the comparison.

