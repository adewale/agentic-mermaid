import { chromium } from '/tmp/pr449-main-integration-20261029-762/node_modules/playwright/index.mjs'
const launch = chromium.launch.bind(chromium)
chromium.launch = options => launch({ ...options, executablePath: '/usr/bin/chromium', args: [...(options?.args ?? []), '--no-sandbox'] })
