import { readFileSync, writeFileSync } from 'node:fs'
import { gunzipSync } from 'node:zlib'
import { layoutMermaid, parseRegisteredMermaid } from '/tmp/pr449-main-integration-20261029-762/src/agent/index.ts'
const before=JSON.parse(gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/er256-dda69/elk-after.json.gz')).toString())
const source=before.samples.find((s:any)=>s.id==='corpus/state/14').source
writeFileSync('/tmp/pr449-week-comparison-20261101/rebase-c366-reconsider-20261107/state14-actual.json',JSON.stringify({ok:true,layout:layoutMermaid(parseRegisteredMermaid(source).value)},null,2))
