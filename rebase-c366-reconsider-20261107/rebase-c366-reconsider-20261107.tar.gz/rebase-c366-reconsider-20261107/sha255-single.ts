import {readFileSync,writeFileSync} from 'node:fs'
import {generatedFlowchartSamples} from '/tmp/pr449-main-integration-20261029-762/eval/layout-compare/generated.ts'
import {snapshotSample} from '/tmp/pr449-main-integration-20261029-762/eval/layout-compare/run.ts'
const p='/tmp/pr449-week-comparison-20261101/rebase-c366-reconsider-20261107'
const recorded=readFileSync(p+'/sha255-source.mmd','utf8'),generated=generatedFlowchartSamples({start:255,count:1},'sha256-counter-v1')[0]!
const result=snapshotSample({...generated,source:recorded},'lc63-',{graphLayout:{backend:'agentic'}},{includeAscii:false})
writeFileSync(p+'/sha255-single.json',JSON.stringify(result))
console.log(JSON.stringify({sameSource:recorded===generated.source,proof:result.svgReceipt?.layoutCertification?.status,checks:result.svgReceipt?.layoutCertification?.checks,sourceGenerated:generated.source.slice(0,70)}))
