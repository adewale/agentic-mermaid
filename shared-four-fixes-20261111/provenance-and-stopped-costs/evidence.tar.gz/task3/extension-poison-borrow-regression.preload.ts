import {readFileSync} from 'node:fs'
// Diagnostic restoration of the historical eligibility defect: replacement
// producers may borrow the original retained geometry. No production edit.
Bun.plugin({name:'historical-producer-borrow-regression',setup(build){build.onLoad({filter:/\/src\/positioning\.ts$/},args=>({loader:'ts',contents:readFileSync(args.path,'utf8').replace('&& !!producer && producer === originalNativeDrawingOf(plan.family.lowerScene) && !sceneAssertionsEnabled(request)', '&& !!producer && !sceneAssertionsEnabled(request)')}))}})
