import {readFileSync} from 'node:fs'
Bun.plugin({name:'proof-ledger-phases',setup(build){
 build.onLoad({filter:/\/src\/scene\/(native-paint-emission|paint-certification)\.ts$/},args=>{
  let code=readFileSync(args.path,'utf8')
  if(args.path.endsWith('paint-certification.ts')) code=code.replace('const sceneWriteWork = scenePathEmissionWorkOf(inspection)',`const sceneWriteWork = scenePathEmissionWorkOf(inspection)
console.error(JSON.stringify({phase:'proof-entry',primitives:inspection.primitives.length,emission:emissionWork&&{operations:emissionWork.operations,exhausted:emissionWork.exhausted,uncertain:emissionWork.uncertain},scene:sceneWriteWork&&{operations:sceneWriteWork.operations,exhausted:sceneWriteWork.exhausted,uncertain:sceneWriteWork.uncertain}}))`)
  else {
   code=code.replace('const checked = new Map<string, CheckedMarkerResource>()',`console.error(JSON.stringify({phase:'capture',operations:work.operations(),exhausted:work.exhausted()}))
const checked = new Map<string, CheckedMarkerResource>()`)
   code=code.replace('const checkedContext = emissionContext.finish(header)',`console.error(JSON.stringify({phase:'resources',operations:work.operations(),exhausted:work.exhausted()}))
const checkedContext = emissionContext.finish(header)
console.error(JSON.stringify({phase:'context',operations:work.operations(),exhausted:work.exhausted()}))`)
   code=code.replace('if (!verified) uncertain = true',`console.error(JSON.stringify({phase:'xml',operations:work.operations(),exhausted:work.exhausted(),verified}))
if (!verified) uncertain = true`)
  }
  return {contents:code,loader:'ts'}
 })
}})
