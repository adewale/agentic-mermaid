import * as marks from '/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts'
import {certifyScenePaint} from '/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts'
for (const padding of [399965,399966,399967,399968,399969,399970,399971,399972,399973]) {
 const edge=marks.connector({id:'related-route',role:'edge',lineStyle:'solid',geometry:{kind:'path',d:`M5 30${' '.repeat(padding)}L95 30`,points:[{x:5,y:30},{x:95,y:30}]},paint:{stroke:'#111'},endpoints:{from:'A',to:'B'}})
 const card=marks.shape({id:'card',role:'node',owner:{id:'A',role:'node'},geometry:{kind:'rect',x:10,y:10,width:80,height:60},paint:{fill:'#fff'}})
 const proof=certifyScenePaint({family:'flowchart',width:100,height:80,transparent:false,colors:{bg:'#fff',fg:'#111'},parts:[edge,card]})
 console.log(JSON.stringify({padding,operations:proof.checks.operations,pairs:proof.checks.occlusionPairs,issues:proof.issues}))
}
