import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
for(const count of [129,130,131,132]){
 const source=['stateDiagram-v2',...Array.from({length:count-1},(_,i)=>`N${i} --> N${i+1}`)].join('\n')
 const product=renderMermaidSVGWithReceipt(source,{graphLayout:{backend:'agentic',fallback:'none'}})
 console.log(JSON.stringify({count,proof:product.receipt.layoutCertification}))
}
