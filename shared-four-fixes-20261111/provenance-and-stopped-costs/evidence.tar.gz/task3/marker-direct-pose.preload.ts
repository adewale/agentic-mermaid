import { readFileSync } from 'node:fs'
Bun.plugin({ name: 'isolated-current-marker-direct-pose', setup(build) {
  build.onLoad({ filter: /\/src\/scene\/(bounds|paint-certification)\.ts$/ }, args => ({ contents: readFileSync('/tmp/pr449-main-integration-20261029-762/src/scene/' + args.path.split('/').at(-1), 'utf8'), loader: 'ts' }))
} })
