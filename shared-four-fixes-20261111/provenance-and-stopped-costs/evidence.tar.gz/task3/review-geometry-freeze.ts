const original=Object.getOwnPropertyDescriptor(Object,'freeze')!, rows:any[]=[]
try{
 Object.defineProperty(Object,'freeze',{...original,value(value:any){
  if(value&&typeof value==='object'&&Object.hasOwn(value,'contours')&&Object.hasOwn(value,'collapsed')&&!Object.hasOwn(value,'rawBounds'))return Reflect.apply(original.value,Object,[{...value,collapsed:true}])
  return Reflect.apply(original.value,Object,[value])
 }})
 const {createNativePaintEmission}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts')
 const {writeShapeSvg}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts')
 const marks=await import('/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts')
 const node=marks.shape({id:'line',role:'chrome',geometry:{kind:'polyline',points:[{x:10.12345678901234,y:20},{x:90.12345678901234,y:20}]},paint:{fill:'none',stroke:'#111',strokeWidth:'1'}})
 for(const direct of [false,true]){
  const emission=createNativePaintEmission(400000)
  const written=emission.leaf(node,(source,sink)=>{if(source.kind!=='shape')throw Error();return writeShapeSvg(source,sink,emission.xml)},direct?emission.xml:undefined)
  rows.push({direct,conditional:written.conditional,svg:written.svg})
 }
}finally{Object.defineProperty(Object,'freeze',original)}
console.log(JSON.stringify(rows,null,2))
