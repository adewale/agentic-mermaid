
    import assert from 'node:assert/strict'
    import { renderMermaidSVGWithReceipt } from './src/index.ts'
    import { getFamily } from './src/agent/families.ts'
    import { sceneLowering, nativeDrawingOf, inheritNativeDrawing } from './src/scene/drawing.ts'
    import { withRenderStageObserver } from './src/render-stages.ts'
    const options = { embedFontImport: false }
    const cases = [
      { kind: 'sequence', source: id => 'sequenceDiagram\nProducer' + id + 'A->>Producer' + id + 'B: isolated',
        coordinate: positioned => positioned.messages[0].points[0] },
      { kind: 'class', source: id => 'classDiagram\nProducer' + id + 'A --> Producer' + id + 'B',
        coordinate: positioned => positioned.classes[0] },
      { kind: 'er', source: id => 'erDiagram\nProducer' + id + 'A ||--o{ Producer' + id + 'B : isolated',
        coordinate: positioned => positioned.entities[0] },
      { kind: 'packet', source: id => 'packet\n0-7: "isolated ' + id + '"',
        coordinate: positioned => positioned.fields[0] },
    ]
    for (const entry of cases) {
      const original = getFamily(entry.kind), lower = original.lowerScene
      const producer = nativeDrawingOf(lower), originalSource = sceneLowering(producer)
      for (const late of [false, true]) for (const warm of [0, 1, 3]) {
        const source = entry.source(late + String(warm))
        const expectedOriginal = renderMermaidSVGWithReceipt(source, options)
        for (let index = 0; index < warm; index++) assert.deepEqual(renderMermaidSVGWithReceipt(source, options), expectedOriginal)
        // Class/ER's original Scene path and a replaced Native producer have
        // distinct actual-write proof work and served viewport rounding.
        // Keep a full product control for each path and exact SVG parity.
        const delegated = sceneLowering((factory, context) => producer(factory, context))
        inheritNativeDrawing(delegated, lower)
        let expectedNative
        try { expectedNative = renderMermaidSVGWithReceipt(source, options) }
        finally { inheritNativeDrawing(originalSource, lower) }
        assert.equal(expectedNative.svg, expectedOriginal.svg)
        let captured, calls = 0
        const custom = sceneLowering((factory, context) => {
          calls++
          captured = context.positioned
          return producer(factory, context)
        })
        if (!late) inheritNativeDrawing(custom, lower)
        try {
          const actual = withRenderStageObserver(sample => {
            if (late && sample.stage === 'layout') inheritNativeDrawing(custom, lower)
          }, () => renderMermaidSVGWithReceipt(source, options))
          assert.deepEqual(actual, expectedNative)
        }
        finally { inheritNativeDrawing(originalSource, lower) }
        assert.equal(calls, 1)
        assert.equal(nativeDrawingOf(lower), producer)
        const reads = []
        Object.defineProperty(entry.coordinate(captured), 'x', { enumerable: true, get() {
          reads.push('escaped coordinate')
          throw new Error('escaped caller geometry')
        } })
        let restored
        assert.doesNotThrow(() => { restored = renderMermaidSVGWithReceipt(source, options) })
        assert.deepEqual(restored, expectedOriginal)
        const { layoutMermaidWithReceipt } = await import('./src/agent/index.ts')
        assert.equal(layoutMermaidWithReceipt(source, options).layout.kind, entry.kind)
        assert.deepEqual(reads, [])
      }
    }
  