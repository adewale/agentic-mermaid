import { readFileSync } from 'node:fs'
const stats = { emitted: 0, prepared: 0, equal: 0, different: [] as unknown[] }
let emitted: unknown
;(globalThis as any)[Symbol.for('pr449.marker.region.equivalence')] = (owner: string, region: unknown) => {
  if (owner === 'emitted') { emitted = region; stats.emitted++ }
  if (owner === 'prepared') {
    stats.prepared++
    if (JSON.stringify(emitted) === JSON.stringify(region)) stats.equal++
    else if (stats.different.length < 3) stats.different.push({ emitted, prepared: region })
  }
}
process.on('beforeExit', () => console.error(JSON.stringify({ diagnostic: 'MARKER-REGION-EQUIVALENCE-NO-REUSE', stats })))
Bun.plugin({ name: 'marker-region-equivalence', setup(build) {
  build.onLoad({ filter: /\/src\/scene\/paint-certification\.ts$/ }, args => {
    let code = readFileSync(args.path, 'utf8')
    code = code.replace("  if (!work() || !emitted?.bounds || !raw.bounds) return undefined", "  ;(globalThis as any)[Symbol.for('pr449.marker.region.equivalence')]('emitted', emitted)\n  if (!work() || !emitted?.bounds || !raw.bounds) return undefined")
    code = code.replace('  const hull = region?.hull', "  ;(globalThis as any)[Symbol.for('pr449.marker.region.equivalence')]('prepared', region)\n  const hull = region?.hull")
    return { contents: code, loader: 'ts' }
  })
} })
