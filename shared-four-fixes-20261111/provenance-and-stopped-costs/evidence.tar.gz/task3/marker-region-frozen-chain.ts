import { readFileSync } from 'node:fs'
process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS='0'
process.env.AGENTIC_MERMAID_ELK_CACHE='0'
const {renderMermaidSVGWithReceipt}=await import('/tmp/pr449-four-candidate-621-20261111/src/index.ts')
const cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-main-20261110/MEASUREMENT-CASES.json','utf8'))
const result=renderMermaidSVGWithReceipt(cases.find((c:any)=>c.id==='diagnostic:chain100').source,{graphLayout:{backend:'agentic',fallback:'none'}})
console.log(JSON.stringify(result.receipt.layoutCertification))
