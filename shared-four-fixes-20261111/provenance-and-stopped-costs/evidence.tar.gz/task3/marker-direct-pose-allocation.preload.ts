import { readFileSync } from 'node:fs'
const counts = { emitted: 0, prepare: 0, other: 0 }
;(globalThis as any)[Symbol.for('pr449.marker.proof.record.counts')] = counts
process.on('beforeExit', () => console.error(JSON.stringify({ diagnostic: 'SYNTHETIC-PROOF-RECORD-CALL-COUNT-NO-RUNTIME-CLAIM', counts })))
Bun.plugin({ name: 'proof-record-call-count', setup(build) {
  build.onLoad({ filter: /\/src\/scene\/(bounds|paint-certification)\.ts$/ }, args => {
    let code = readFileSync(process.env.AM_DIRECT_POSE === '1' ? '/tmp/pr449-main-integration-20261029-762/src/scene/' + args.path.split('/').at(-1) : args.path, 'utf8')
    if (args.path.endsWith('paint-certification.ts')) code = code.replace('const proofRecord = <T extends object>(fields: T): T => Object.assign(Object.create(null), fields)', `const proofRecord = <T extends object>(fields: T): T => {
      const stack = new Error().stack ?? ''; const counts = (globalThis as any)[Symbol.for('pr449.marker.proof.record.counts')]; counts[stack.includes('emittedEndpointMarker') ? 'emitted' : stack.includes('prepareMarkerPolygonInk') ? 'prepare' : 'other']++
      return Object.assign(Object.create(null), fields)
    }`)
    return { contents: code, loader: 'ts' }
  })
} })
