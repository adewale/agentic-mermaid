const original=Object.getOwnPropertyDescriptor(Object,'freeze')!, rows:any[]=[]
try{
 Object.defineProperty(Object,'freeze',{...original,value(value:any){
  if(value&&typeof value==='object'&&Object.hasOwn(value,'contours')&&Object.hasOwn(value,'collapsed')&&!Object.hasOwn(value,'rawBounds'))return Reflect.apply(original.value,Object,[{...value,collapsed:false}])
  return Reflect.apply(original.value,Object,[value])
 }})
 const {createNativePaintEmission}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts')
 const {writeShapeSvg}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts')
 const marks=await import('/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts')
 const node=marks.shape({id:'line',role:'chrome',geometry:{kind:'polyline',points:[{x:10.00000000000001,y:20},{x:10.00000000000002,y:20}]},paint:{fill:'none',stroke:'#111',strokeWidth:'1'}})
 for(const direct of [false,true]){
  const emission=createNativePaintEmission(400000)
  const written=emission.leaf(node,(source,sink)=>{if(source.kind!=='shape')throw Error();return writeShapeSvg(source,sink,emission.xml)},direct?emission.xml:undefined)
  rows.push({direct,conditional:written.conditional,svg:written.svg})
 }
 const {drawNative}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts')
 const {certifyNativePaint}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts')
 const colors={bg:'#fff',fg:'#111'},width=200,height=100
 const drawing=drawNative(factory=>({family:'flowchart',width,height,colors,transparent:false,parts:[factory.documentOpen({id:'root',width,height,colors,transparent:false,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="200" height="100">'),factory.shape({id:'line',role:'chrome',geometry:{kind:'polyline',points:[{x:10.00000000000001,y:20},{x:10.00000000000002,y:20}]},paint:{fill:'none',stroke:'#111',strokeWidth:'1'}}),factory.documentClose()]}),{positioned:{width,height},colors,resolved:{renderOptions:{}}} as any,'flowchart')
 rows.push({svg:drawing.svg,proof:certifyNativePaint(drawing.header,drawing.paint)})
}finally{Object.defineProperty(Object,'freeze',original)}
console.log(JSON.stringify(rows,null,2))
