import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import {writeFileSync} from 'node:fs'
const source=['stateDiagram-v2',...Array.from({length:127},(_,i)=>`N${i} --> N${i+1}`)].join('\n')
for(const backend of ['agentic','elk'] as const){
const product=renderMermaidSVGWithReceipt(source,{graphLayout:{backend,fallback:'none'}})
writeFileSync(`/tmp/pr449-week-comparison-20261101/shared-four-fixes-20261111/task3/state128-${backend}-${process.argv[2]??'before'}.json`,JSON.stringify(product))
console.log(JSON.stringify({backend,...product.receipt.layoutCertification}))
}
