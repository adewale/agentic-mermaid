import {preparePixelText} from '/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts'
import * as marks from '/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts'
import {createNativePaintEmission,MAX_OCCLUSION_OPERATIONS} from '/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts'
import {writeTextSvg,writeNativeTextSvg} from '/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts'
import {drawNative} from '/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts'
import {certifyNativePaint} from '/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts'
const block=preparePixelText('Read',{fontSize:18,fontWeight:400})
const node=marks.text({id:'label',role:'label',text:'Read',block,x:20,y:40,fontSize:18,anchor:'start',paint:{fill:'#111'}})
const map=Object.getOwnPropertyDescriptor(Array.prototype,'map')!, trace:any[]=[]
let projected:any,complete:any,drawing:any
try {
 Object.defineProperty(Array.prototype,'map',{...map,value(callback:any,thisArg:any){
  const run=Object.getOwnPropertyDescriptor(this,'0')?.value
  const affected=run && typeof run==='object' && Object.getOwnPropertyDescriptor(run,'text')?.value==='Read' && typeof Object.getOwnPropertyDescriptor(run,'bold')?.value==='boolean'
  const result=Reflect.apply(map.value,this,[callback,thisArg])
  if(!affected)return result
  const clusters=Object.hasOwn(run,'clusters');trace.push({clusters})
  return clusters?result:Reflect.apply(map.value,result,[(value:any)=>typeof value==='string'?value.replaceAll('Read','Lost'):value])
 }})
 const full=createNativePaintEmission(MAX_OCCLUSION_OPERATIONS)
 complete=full.leaf(node,(source:any,sink:any)=>writeTextSvg(source,full.xml,sink))
 const paint=createNativePaintEmission(MAX_OCCLUSION_OPERATIONS)
 projected=paint.paintLeaf(node,(source:any,sink:any)=>writeNativeTextSvg(source,paint.xml,sink))
 const width=300,height=100,colors={bg:'#fff',fg:'#111'}
 drawing=drawNative(factory=>({family:'flowchart',width,height,colors,transparent:false,parts:[factory.documentOpen({id:'root',width,height,colors,transparent:false,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="100">'),factory.text({id:'label',role:'label',text:'Read',block,x:20,y:40,fontSize:18,anchor:'start',paint:{fill:'#111'}}),factory.documentClose()]}),{positioned:{width,height},colors,resolved:{renderOptions:{}}} as any,'flowchart')
} finally{Object.defineProperty(Array.prototype,'map',map)}
console.log(JSON.stringify({originalRunHasClusters:Object.hasOwn(block.lineBlocks[0]!.runs[0]!,'clusters'),complete:complete.svg,projected:projected.svg,actualDrawing:drawing.svg,proof:certifyNativePaint(drawing.header,drawing.paint),trace},null,2))
