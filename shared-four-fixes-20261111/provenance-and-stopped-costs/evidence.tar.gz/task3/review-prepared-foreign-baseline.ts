import {preparePixelText} from '/tmp/pr449-bench-pr-599b-20261110/src/shared/prepared-text.ts'
import * as marks from '/tmp/pr449-bench-pr-599b-20261110/src/scene/marks.ts'
import {createNativePaintEmission,MAX_OCCLUSION_OPERATIONS} from '/tmp/pr449-bench-pr-599b-20261110/src/scene/native-paint-emission.ts'
import {writeTextSvg} from '/tmp/pr449-bench-pr-599b-20261110/src/scene/svg-writer.ts'
import {drawNative} from '/tmp/pr449-bench-pr-599b-20261110/src/scene/native-drawing.ts'
const block=preparePixelText('Read',{fontSize:18,fontWeight:400})
const node=marks.text({id:'label',role:'label',text:'Read',block,x:20,y:40,fontSize:18,anchor:'start',paint:{fill:'#111'}})
const original=Object.getOwnPropertyDescriptor(Object,'preventExtensions')!, trace:any[]=[]
const results:any={}
try{
 Object.defineProperty(Object,'preventExtensions',{...original,value(value:any){
  const source=Object.getOwnPropertyDescriptor(value,'source')?.value
  if(source==='Read'&&Object.hasOwn(value,'display')){
   const lines=Object.hasOwn(value,'lines');trace.push({lines})
   if(!lines)return undefined
  }
  return Reflect.apply(original.value,Object,[value])
 }})
 for(const context of ['leaf'] as const){
  const e=createNativePaintEmission(MAX_OCCLUSION_OPERATIONS)
  try{results[context]=(e[context] as any)(node,(source:any,sink:any)=>writeTextSvg(source,e.xml,sink)).svg}
  catch(error:any){results[context]={name:error.name,message:error.message}}
 }
 const width=300,height=100,colors={bg:'#fff',fg:'#111'}
 try {results.actualDrawing=drawNative(factory=>({family:'flowchart',width,height,colors,transparent:false,parts:[factory.documentOpen({id:'root',width,height,colors,transparent:false,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="100">'),factory.text({id:'label',role:'label',text:'Read',block,x:20,y:40,fontSize:18,anchor:'start',paint:{fill:'#111'}}),factory.documentClose()]}),{positioned:{width,height},colors,resolved:{renderOptions:{}}} as any,'flowchart').svg} catch(error:any){results.actualDrawing={name:error.name,message:error.message}}
}finally{Object.defineProperty(Object,'preventExtensions',original)}
console.log(JSON.stringify({results,trace},null,2))
