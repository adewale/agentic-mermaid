import { readFileSync } from 'node:fs'
Error.stackTraceLimit = 40
const totals: Record<string, { calls: number; work: number }> = {}
;(globalThis as any)[Symbol.for('pr449.marker.geometry.cost')] = totals
process.on('beforeExit', () => console.error(JSON.stringify({ diagnostic: 'MARKER-GEOMETRY-CALL-ATTRIBUTION-NO-TIMING-CLAIM', totals })))
Bun.plugin({ name: 'marker-geometry-cost', setup(build) {
  build.onLoad({ filter: /\/src\/scene\/(bounds|paint-certification)\.ts$/ }, args => {
    let code = readFileSync(args.path, 'utf8')
    if (args.path.endsWith('bounds.ts')) {
      for (const name of ['markerBoundsAt', 'connectorMarkerPaintRegions']) {
        const start = code.indexOf(`function ${name}(`)
        const body = code.indexOf(name === 'markerBoundsAt' ? '\n  if (!marker || !anchor)' : '\n  const geometry = node.route.geometry, endpoints', start)
        if (start < 0 || body < 3) throw Error('Missing owner ' + name)
        const test = name === 'markerBoundsAt' ? 'if (marker && anchor)' : ''
        code = code.slice(0, body) + `\n ${test} { const stack = new Error().stack ?? ''; const owner = stack.includes('prepareMarkerPolygonInk') ? 'prepare' : stack.includes('emittedEndpointMarker') ? 'emitted' : stack.includes('certifyScenePaint') || stack.includes('certifyNativePaint') || stack.includes('certifyPaint') ? 'proof' : stack.includes('connectorPaintBounds') ? 'recorder' : 'other'; const rows = (globalThis as any)[Symbol.for('pr449.marker.geometry.cost')]; const row = rows['${name}:' + owner] ??= {calls:0,work:0}; row.calls++; }\n` + code.slice(body)
      }
    } else {
      for (const name of ['emittedEndpointMarker', 'prepareMarkerPolygonInk']) {
        const start = code.indexOf(`function ${name}(`), body = code.indexOf(name === 'emittedEndpointMarker' ? '\n  const { position, anchor } = raw' : '\n  const pay = ', start)
        if (start < 0 || body < 3) throw Error('Missing owner ' + name)
        code = code.slice(0, body) + `\n const rows = (globalThis as any)[Symbol.for('pr449.marker.geometry.cost')]; const row = rows['${name}'] ??= {calls:0,work:0}; row.calls++; const originalWork = work; work = () => { row.work++; return originalWork() };\n` + code.slice(body)
      }
    }
    return { contents: code, loader: 'ts' }
  })
} })
