import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS = '0'
process.env.AGENTIC_MERMAID_ELK_CACHE = '0'
const { renderMermaidSVGWithReceipt } = await import('/tmp/pr449-four-candidate-621-20261111/src/index.ts')
const cases = JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-main-20261110/MEASUREMENT-CASES.json', 'utf8'))
const source = cases.find((c: any) => c.id === 'diagnostic:chain100').source
const times: number[] = []
let expected = ''
let lastProduct: any
for (let i = 0; i < 14; i++) {
  const start = performance.now()
  const product = renderMermaidSVGWithReceipt(source, { graphLayout: { backend: 'agentic', fallback: 'none' } })
  const elapsed = performance.now() - start
  const whole = JSON.stringify(product)
  lastProduct = product
  if (expected && expected !== whole) throw new Error('Whole public product changed between calls')
  expected = whole
  if (i >= 4) times.push(elapsed)
}
console.log(JSON.stringify({ diagnostic: 'BOUNDED-SOURCE-RUNTIME-NOT-QUALIFICATION', skippedDuplicateRegion: process.env.AM_SKIP_REGION === '1', wholeProductSha256: createHash('sha256').update(expected).digest('hex'), svgSha256: createHash('sha256').update(lastProduct.svg).digest('hex'), proof: lastProduct.receipt.layoutCertification, times, median: times.toSorted((a,b)=>a-b)[Math.floor(times.length / 2)] }))
