import { readFileSync } from 'node:fs'
Bun.plugin({ name: 'UNSAFE-marker-region-runtime-bound-NOT-production', setup(build) {
  build.onLoad({ filter: /\/src\/scene\/paint-certification\.ts$/ }, args => {
    let code = readFileSync(args.path, 'utf8')
    code = 'let __diagnosticLastEmittedRegion: any\n' + code
    code = code.replace("  if (!work() || !emitted?.bounds || !raw.bounds) return undefined", "  __diagnosticLastEmittedRegion = emitted\n  if (!work() || !emitted?.bounds || !raw.bounds) return undefined")
    code = code.replace('      const emitted = semantic && exactWorld && knownMapping ?', '      __diagnosticLastEmittedRegion = undefined\n      const emitted = semantic && exactWorld && knownMapping ?')
    code = code.replace('  const region = connectorMarkerPaintRegions(proofRecord({ route: proofRecord({ ...node.route, geometry: line,', '  const region = __diagnosticLastEmittedRegion ?? connectorMarkerPaintRegions(proofRecord({ route: proofRecord({ ...node.route, geometry: line,')
    return { contents: code, loader: 'ts' }
  })
} })
