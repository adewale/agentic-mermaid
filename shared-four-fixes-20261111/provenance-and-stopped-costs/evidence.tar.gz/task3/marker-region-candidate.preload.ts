import { readFileSync } from 'node:fs'
Bun.plugin({ name: 'isolated-marker-region-candidate', setup(build) {
  build.onLoad({ filter: /\/src\/scene\/paint-certification\.ts$/ }, () => ({ contents: readFileSync('/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts', 'utf8'), loader: 'ts' }))
} })
