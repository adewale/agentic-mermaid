import {parseMermaid} from '/tmp/pr449-main-integration-20261029-762/src/parser.ts'
import {layoutGraphSync} from '/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts'
import {lowerGraphDrawing,lowerGraphScene} from '/tmp/pr449-main-integration-20261029-762/src/renderer.ts'
import {drawNative} from '/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts'
import {paintPrimitiveSource,inspectScenePaintGeometry} from '/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts'
import {certifyNativePaint} from '/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts'
const source=['stateDiagram-v2',...Array.from({length:Number(process.env.COUNT??3)-1},(_,i)=>`N${i} --> N${i+1}`)].join('\n')
const positioned=layoutGraphSync(parseMermaid(source),{graphLayout:{backend:'agentic'}}),colors={bg:'#fff',fg:'#111'},context={positioned,colors,resolved:{renderOptions:{}}}
const native=drawNative(lowerGraphDrawing,context,'state')
console.log(JSON.stringify({primitives:native.paint.primitives.filter(p=>p.id.includes('N0')||p.id.includes('N1')).map(p=>({id:p.id,owner:p.owner,ancestors:p.ancestors,source:paintPrimitiveSource(p)})),proof:certifyNativePaint(native.header,native.paint)},null,2))
