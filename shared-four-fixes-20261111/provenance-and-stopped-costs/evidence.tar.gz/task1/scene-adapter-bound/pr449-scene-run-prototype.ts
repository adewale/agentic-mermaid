import{renderMermaidSVGWithReceipt}from'/tmp/pr449-main-integration-20261029-762/src/index.ts'
process.env.AGENTIC_MERMAID_ELK_CACHE='0';process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS='0'
const original=Object.getOwnPropertyDescriptor(Array.prototype,'map')!;let nullRuns=0,ordinaryRuns=0
Object.defineProperty(Array.prototype,'map',{...original,value(...args:unknown[]){
 const run=Object.getOwnPropertyDescriptor(this,'0')?.value,result=Reflect.apply(original.value,this,args)
 if(run&&Object.getOwnPropertyDescriptor(run,'text')?.value==='Read'&&typeof Object.getOwnPropertyDescriptor(run,'bold')?.value==='boolean'){
  if(Object.getPrototypeOf(run)===null){nullRuns++;return Reflect.apply(original.value,result,[(value:unknown)=>typeof value==='string'?value.replaceAll('Read','Lost'):value])}
  ordinaryRuns++
 }
 return result
}})
try{const result=renderMermaidSVGWithReceipt('flowchart TB\nA[Read]',{graphLayout:{backend:'agentic',fallback:'none'}});console.log(JSON.stringify({nullRuns,ordinaryRuns,svg:result.svg,proof:result.receipt.layoutCertification}))}finally{Object.defineProperty(Array.prototype,'map',original)}
