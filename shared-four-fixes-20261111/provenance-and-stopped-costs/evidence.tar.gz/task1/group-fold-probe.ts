import{captureNativeGroupParse,validatePlainNativeGroup}from'/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts'
import{createNativeXmlWork,writeShapeSvg}from'/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts'
import*as marks from'/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts'
const open='<g class="node" data-id="n0" data-label="Node 0" data-shape="rectangle" data-role="node">';const work=createNativeXmlWork(400000),capture=work.capture(),parsed=captureNativeGroupParse({id:'g',open,close:'</g>',join:'\n'},work.pay)
console.log({parsed:!!parsed,valid:validatePlainNativeGroup(parsed,open,()=>true,work.pay)})
const shape=marks.shape({id:'n',role:'node',geometry:{kind:'rect',x:0,y:0,width:10,height:10},paint:{fill:'#111'}})
const group=capture.group([capture.raw(open),writeShapeSvg(shape,undefined,capture),capture.raw('</g>')],parsed,'\n');const whole=capture.join([capture.raw('<svg xmlns="http://www.w3.org/2000/svg">'),group,capture.raw('</svg>')],'\n');console.log({verify:capture.verify(whole),ops:work.operations(),svg:whole.svg})
