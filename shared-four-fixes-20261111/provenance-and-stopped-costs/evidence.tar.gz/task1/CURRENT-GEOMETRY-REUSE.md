# Current actual-write geometry / group candidate (not completion)

This supersedes the earlier task1 REPORT as a current-source statement. The earlier private text-block projection was rejected and fully reverted because interposed map/seal observers saw partial receiver graphs; its Sparse pass is historical only. Safe XML 70ae649f7 remains the shipped baseline. No further commit was made by this agent.

The current uncommitted candidate has seven runtime files: group-emission.ts, emission-context.ts (Task3); svg-writer.ts, native-paint-emission.ts, native-drawing.ts, bounds.ts, written-geometry.ts (Task1). The owning writer tests are scene-svg-writer.test.ts. Root's paint-capacity assertions and work log are separate ownership.

Current producer subtraction:

- Final captured plain group parsing retains private primitive rows. Context and closed XML composition consume the exact node/open-bound parse without allocating a second ordinary token roster; generic/nonplain consumers retain full materialization. Original early admission/getter/exhaustion guards remain.
- Native actual writes consume geometry from the existing actual XML-write registry through an issuer-protected ActualGeometryWrite. Complete caller node/text/geometry receiver graphs remain intact. Generic leaf/public sink behavior remains unchanged; foreign/raw/mismatched writes cannot acquire actual geometry custody.
- Private Native polyline projection derives actual served points/contours, omitting source-only raw conservative derivative objects. Generic public projections keep all raw data. Private actual contour/collapse state never reaches ambient freeze as a partial object and is consumed from the same actual write handle.
- Native scalar point serialization preserves original source-coordinate read/coercion order, then uses current scalar formatting and appends numeric operands directly. It removes the combined points-string rewrite/token parser. No-normalization finite-number input directly appends its inherent numeric ASCII; generic/public sinks keep the old path. Source-only raw operands and failed/foreign projection records never supply proof authority.

Actual safety findings retained and fixed:

- Discoverable ParsedNativeGroup constructor forged xmlns=urn:not-svg and gave false XML pass in the draft. A private issuer is now mandatory; owning test rejects forgery and actual bad namespace composition.
- Passing shortened derivative {contours,collapsed} to ambient pre-import freeze permitted collapsed=false forgery and an actual false proof. ActualPolylineProjection is now an issuer-protected private class in the existing registry; Native consumes private actual-write projection rather than generic metadata fallback.
- Private point/tangent/contour/geometry seals reject foreign returns or changed/nonreadonly actual values. Four pre-import seal-hook owning controls retain actual collapsed SVG as unverified.
- First scalar version introduced a 50,000-point integer-polyline budget regression. It is retained in scalar-producer-focused.log and fixed: unchanged numeric buffers use no projection reservation. No cap increase was made.

Capacity observations (fully consumed source API; unchanged chain SVG digest a94d1220d549c9cf): current scalar/no-normalization run capture235267, resources277144, context292588, XML343841, XML verified=true, emission uncertain=false. Full proof remains CHECK_BUDGET at400000 after99markers and814pairs. A clearly-labelled UNSAFE diagnostic that starts downstream proof at0 reports57602 required units and passed paint, so combined current work is401443, 1443 above the fixed400000 cap. This diagnostic is not a production waiver or a passing result.

All-six earlier-stage table is in geometry-six-stages.log and remains adverse: all six Native public cases unverified; flow128 and sequence128 exhaust XML, state128 reached XML397046 then proof cap; chain300 exhausts capture. The state apparent unrelated-source-card warning occurred only near ledger exhaustion and Task3 is checking it. Native100<100ms has not been demonstrated. Root's third built diagnostic is mixed/adverse, including very slow cold300; no speedup claim applies.

Latest checks: focused writer/native-validation/prepared231P/1747 assertions before adding three more seal modes; writer after all seal modes56P/638 assertions. Purposeful -0, tiny, huge, large, and rounding-tie whole-SVG parity eight cases pass. Exact Sparse3 plus font owner: zero-marker controls and font owner pass;32-marker case remains CHECK_BUDGET (25markers complete in the earlier current candidate). Coretypes last passed before final source corrections; final run in progress. Owned runtime/test lint and diffcheck pass.

Frozen snapshots: scalar-producer-frozen is the earlier pre-scalar candidate; third-diagnostic-source captures the source actually used for the third built diagnostic before integer correction. Neither should be relabelled as the later integer-corrected source. All failed trials and exact raw logs remain.
