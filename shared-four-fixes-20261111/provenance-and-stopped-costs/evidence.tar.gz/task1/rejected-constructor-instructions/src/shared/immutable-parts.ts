/** Constructor instructions replace the existing ownership entry. They retain
 * exact local shapes, never descriptor/key rosters or mutable source values. */
declare const immutableCopyPlan: unique symbol
export interface ImmutableCopyPlan { readonly [immutableCopyPlan]: true }
const shapeKeys = [
  ['text', 'sourceStart', 'sourceEnd'],
  ['text', 'bold', 'italic', 'underline', 'strikethrough', 'sourceStart', 'sourceEnd', 'clusters'],
  ['source', 'display', 'lines', 'lineStarts'],
  ['source', 'display', 'lines', 'lineStarts', 'transform'],
  ['runs', 'text', 'width', 'baseline', 'originX'],
  ['runs', 'text', 'width', 'baseline', 'originX', 'ink'],
  ['unit', 'prepared', 'text', 'lines', 'lineBlocks', 'breaks', 'width', 'height', 'lineHeight', 'fontSize', 'fontWeight', 'letterSpacing', 'monospace', 'safeFont'],
  ['unit', 'prepared', 'text', 'lines', 'lineBlocks', 'breaks', 'width', 'height', 'lineHeight', 'fontSize', 'fontWeight', 'letterSpacing', 'monospace', 'safeFont', 'fontFamily'],
] as const
const copyIssuer = { __proto__: null }
declare const copyArrayOrigin: unique symbol
interface CopyArrayOrigin { readonly [copyArrayOrigin]: true }
class LocalArrayOrigin implements CopyArrayOrigin {
  declare readonly [copyArrayOrigin]: true
  readonly #source: object
  constructor(issuer: object, source: object) { if (issuer !== copyIssuer) throw new TypeError('Array origin requires its local constructor'); this.#source = source }
  static matches(value: unknown, source: object): boolean { return !!value && typeof value === 'object' && #source in value && value.#source === source }
}
const matchesArrayOrigin = LocalArrayOrigin.matches
class OwnedCopyPlan implements ImmutableCopyPlan {
  declare readonly [immutableCopyPlan]: true
  readonly #source: object
  readonly #owned: boolean
  readonly #arrayOrigin: boolean
  readonly #shape: number
  readonly #length: number
  readonly #height: number
  constructor(issuer: object, source: object, owned: boolean, arrayOrigin: boolean, shape = -1, length = 0, height = 0) {
    if (issuer !== copyIssuer) throw new TypeError('Copy instructions require their actual constructor')
    this.#source = source; this.#owned = owned; this.#arrayOrigin = arrayOrigin; this.#shape = shape; this.#length = length; this.#height = height
  }
  static owned(value: unknown, source: object): boolean { return !!value && typeof value === 'object' && #source in value && value.#source === source && value.#owned }
  static origin(value: unknown, source: object): boolean { return !!value && typeof value === 'object' && #source in value && value.#source === source && value.#arrayOrigin }
  static matches(value: unknown, source: object): value is ImmutableCopyPlan { return !!value && typeof value === 'object' && #source in value && value.#source === source && value.#shape >= 0 }
  static height(value: ImmutableCopyPlan): number { return (value as OwnedCopyPlan).#height }
  static consume<T>(value: ImmutableCopyPlan, source: object, consume: (array: boolean, length: number, height: number, visit: (field: (key: string, value: unknown) => void) => void) => T): T | undefined {
    if (!value || typeof value !== 'object' || !(#source in value) || value.#source !== source || value.#shape < 0) return undefined
    const plan = value as OwnedCopyPlan, array = plan.#shape === shapeKeys.length
    return consume(array, plan.#length, plan.#height, field => {
      if (array) for (let index = 0; index < plan.#length; index++) field(`${index}`, (source as readonly unknown[])[index])
      else {
        const keys = shapeKeys[plan.#shape]!
        for (let index = 0; index < keys.length; index++) { const key = keys[index]!; field(key, (source as Record<string, unknown>)[key]) }
      }
    })
  }
}
const ownedCopy = OwnedCopyPlan.owned, arrayCopyOrigin = OwnedCopyPlan.origin, matchesCopy = OwnedCopyPlan.matches, copyHeight = OwnedCopyPlan.height, consumeCopy = OwnedCopyPlan.consume
export function consumeImmutableCopyPlan<T>(plan: ImmutableCopyPlan, source: object, consume: Parameters<typeof OwnedCopyPlan.consume<T>>[2]): T | undefined { return consumeCopy(plan, source, consume) }

const immutableSet = WeakSet, immutableMap = WeakMap, immutableApply = Reflect.apply
const immutableHas = WeakSet.prototype.has, immutableAdd = WeakSet.prototype.add
const immutableGet = WeakMap.prototype.get, immutablePut = WeakMap.prototype.set, immutableDelete = WeakMap.prototype.delete
const immutableFreeze = Object.freeze, immutableFrozen = Object.isFrozen, immutableKeys = Reflect.ownKeys
const immutableDescriptor = Object.getOwnPropertyDescriptor, immutableOwn = Object.hasOwn, immutablePrototype = Object.getPrototypeOf
const objectPrototype = Object.prototype, arrayPrototype = Array.prototype
function arrayIndex(key: string): number {
  if (!key.length || key.length > 10 || key.length > 1 && key[0] === '0') return -1
  let index = 0
  for (let at = 0; at < key.length; at++) {
    const digit = key[at]!
    const value = digit === '0' ? 0 : digit === '1' ? 1 : digit === '2' ? 2 : digit === '3' ? 3 : digit === '4' ? 4 : digit === '5' ? 5 : digit === '6' ? 6 : digit === '7' ? 7 : digit === '8' ? 8 : digit === '9' ? 9 : -1
    if (value < 0) return -1
    index = index * 10 + value
  }
  return index
}

export function createImmutableParts(known: (value: object) => boolean = () => false, knownOwned: (value: object) => boolean = () => false, knownCopy: (value: object) => ImmutableCopyPlan | undefined = () => undefined) {
  const parts = new immutableSet<object>(), ownedParts = new immutableMap<object, OwnedCopyPlan>()
  const record = (value: object): OwnedCopyPlan | undefined => immutableApply(immutableGet, ownedParts, [value])
  const has = (value: object): boolean => immutableApply(immutableHas, parts, [value]) || known(value)
  const hasOwned = (value: object): boolean => ownedCopy(record(value), value) || knownOwned(value)
  const copyPlan = (value: object): ImmutableCopyPlan | undefined => { const plan = record(value); return matchesCopy(plan, value) ? plan : knownCopy(value) }
  const localCopyArray = (value: readonly unknown[]): CopyArrayOrigin => new LocalArrayOrigin(copyIssuer, value)
  const qualify = <T extends object>(value: T, allocationOwned: boolean, copyOwned = false, array = false, alreadyFrozen = false, origin?: CopyArrayOrigin): Readonly<T> => {
    if (!alreadyFrozen) Object.freeze(value)
    const prior = record(value)
    const fail = (): T => { if (arrayCopyOrigin(prior, value) && !ownedCopy(prior, value)) immutableApply(immutableDelete, ownedParts, [value]); return value }
    if (!immutableFrozen(value)) return fail()
    let owned = allocationOwned, copy = copyOwned && (!array || matchesArrayOrigin(origin, value)), height = 0, length = -1, strings = 0, mask = (1 << shapeKeys.length) - 1
    if (copy) { const prototype = immutablePrototype(value); if (array ? prototype !== arrayPrototype : prototype !== objectPrototype && prototype !== null) copy = false }
    const keys = immutableKeys(value)
    for (let index = 0; index < keys.length; index++) {
      const key = keys[index]!, descriptor = immutableDescriptor(value, key)
      if (!descriptor || !immutableOwn(descriptor, 'value')) return fail()
      const child = descriptor.value, scalar = child === null || typeof child !== 'object' && typeof child !== 'function'
      if (owned && !scalar && !hasOwned(child)) owned = false
      if (!scalar && !has(child)) return fail()
      if (copy && typeof key === 'string') {
        const nested = !scalar ? copyPlan(child) : undefined
        if (descriptor.writable || descriptor.configurable || typeof child === 'symbol' || typeof child === 'bigint' || typeof child === 'function' || !scalar && !nested) copy = false
        if (array && key === 'length') {
          if (typeof child !== 'number' || child < 0 || child > 0xffff_ffff || child % 1 || descriptor.enumerable) copy = false
          else length = child
          continue
        }
        if (!descriptor.enumerable) copy = false
        if (array) { if (arrayIndex(key) !== strings) copy = false }
        else for (let shape = 0; shape < shapeKeys.length; shape++) if (strings >= shapeKeys[shape]!.length || shapeKeys[shape]![strings] !== key) mask &= ~(1 << shape)
        strings++
        height = Math.max(height, 1 + (nested ? copyHeight(nested) : 0))
      }
    }
    immutableApply(immutableAdd, parts, [value])
    if (owned) {
      let shape = -1
      if (copy && array && strings === length) shape = shapeKeys.length
      else if (copy) for (let index = 0; index < shapeKeys.length; index++) if (mask & (1 << index) && shapeKeys[index]!.length === strings) { shape = index; break }
      immutableApply(immutablePut, ownedParts, [value, shape >= 0 ? new OwnedCopyPlan(copyIssuer, value, true, array, shape, length, height) : ownedCopy(prior, value) ? prior : new OwnedCopyPlan(copyIssuer, value, true, false)])
    }
    return value
  }
  const freeze = <T extends object>(value: T): Readonly<T> => qualify(value, false)
  const freezeOwned = <T extends object>(value: T): Readonly<T> => qualify(value, true)
  const freezeCopyOwned = <T extends object>(value: T): Readonly<T> => qualify(value, true, true)
  const freezeCopyArray = <T extends readonly unknown[]>(value: T, origin: CopyArrayOrigin | undefined): Readonly<T> => qualify(value, true, true, true, false, origin)
  const sourceSpan = (text: string, sourceStart: number, sourceEnd: number) => {
    if (typeof text !== 'string' || typeof sourceStart !== 'number' || typeof sourceEnd !== 'number') throw new TypeError('Source spans require scalar text and offsets')
    const input = { text, sourceStart, sourceEnd }, span = immutableFreeze(input)
    if (immutableFrozen(span)) {
      immutableApply(immutableAdd, parts, [span])
      immutableApply(immutablePut, ownedParts, [span, new OwnedCopyPlan(copyIssuer, span, true, false)])
      if (span === input) qualify(span, true, true, false, true)
    }
    return span
  }
  return { has, freeze, hasOwned, freezeOwned, freezeCopyOwned, localCopyArray, freezeCopyArray, copyPlan, sourceSpan }
}
