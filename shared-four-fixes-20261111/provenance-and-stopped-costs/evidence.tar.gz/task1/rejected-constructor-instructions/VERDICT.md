# Rejected constructor instruction candidate

Stopped after matched full-product actual built cache0 A/B. Chain100 control217.5→candidate268.4ms adverse+23.4%; fan285.4→263.0;300436.8→425.6, firstedit462.3→547.4 adverse+18.4%.81SVGsexact; proofdiff onlyoperations/issues;300stillU. RSSroughlyflat;300heap+~2MB. SourceSpan gained a new own-key/descriptor qualification pass outside the emission counter, so the8.5k counter decrease was not a complete producer-work bound and supports no capacity claim.

All four runtime files restored byteexact621d596088be5a08e03656eaacb3a52c934bac33. Source, fullpatch, focused234P log and first100/300 stage logs retained. No private instruction/schema/accounting variant continues.
