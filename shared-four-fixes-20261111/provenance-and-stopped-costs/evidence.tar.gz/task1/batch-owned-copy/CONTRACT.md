# Bounded owned-copy batching experiment

Private actual Native captures only; public snapshots and public leaf capture remain per-field. Original source names, descriptor reads and child traversal order remain. Fresh full ordinary receiver graphs, readonly fields, readonly array length, brand transfer and preventExtensions remain. The extra bulk descriptor walk is charged: chain100391880 operations versus621380960, same output digest/99markers/P. Sparse all3canonicalowners P.

Producer repair: a foreign Object.freeze return no longer gains local-allocation ownership; public returned value is preserved. Mapped fragment-array results use nonowned freeze. The exact frozen-Proxy source-order counterexample now emits identical R/P with0traps both with and without batch.

Internal Object.defineProperty monkeypatch rewriting clone assignments differs under batching (Lost/P versus authoredR/P); root explicitly permits private helper call-pattern changes. This is not used as a stale-proof negative or a native-authenticity guard. Actual caller input/coercion observations, full receiver shapes and exact current SVG authority remain required.

No performance or capacity completion claim. Constructor-instruction branch was rejected separately; batching has no schema, new cache, registry, source snapshot sharing or meter waiver. Runtime value pending root matched built public API probe.

Final domain correction: arrays never batch (no extra Array.isArray invocation). Original array-length write retained. This protects borrowed runs arrays inserted by an interposed push. breaks.forEach retains its dispatch but receives nonowned freeze callback. Three actual Native source-order owners span/break/runs pass (11asserts); readonly foreign runs array deliberately remains nonbatched even if prior producer-owned flag is true. Chain100389000P with frozen621 proof override, all99markers/sameSVG. No combined Task3 geometry result claimed.
