const define=Object.getOwnPropertyDescriptor(Object,'defineProperty')!,names=Object.getOwnPropertyDescriptor(Object,'getOwnPropertyNames')!,each=Object.getOwnPropertyDescriptor(Array.prototype,'forEach')!
let span:object|undefined,active=false,defined=false,traps=0
Object.defineProperty(Array.prototype,'forEach',{...each,value(callback:unknown,...args:unknown[]){
 if(this[0]?.kind==='wrap'&&Object.hasOwn(this[0],'sourceOffset')){span=new Proxy(this[0],{getOwnPropertyDescriptor(target,key){if(active&&key==='kind')defined=false;if(active&&key==='sourceOffset'&&!defined){traps++;throw Error('source observed before prior destination write')}return Reflect.getOwnPropertyDescriptor(target,key)}});this[0]=span}
 return Reflect.apply(each.value,this,[callback,...args])
}})
const {preparePixelText,isOwnedPixelTextPart}=await import('/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts')
const {drawNative}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts')
const {certifyNativePaint}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts')
const block=preparePixelText('RR',{fontSize:18,fontWeight:400,maxWidth:15}),owned=isOwnedPixelTextPart(span!),frozen=Object.isFrozen(span)
Reflect.apply(define.value,Object,[Object,'defineProperty',{...define,value(target:object,key:PropertyKey,descriptor:PropertyDescriptor){if(key==='kind'&&descriptor.value==='wrap')defined=true;return Reflect.apply(define.value,Object,[target,key,descriptor])}}])
Reflect.apply(define.value,Object,[Object,'getOwnPropertyNames',{...names,value(value:object){if(value===span)active=true;return Reflect.apply(names.value,Object,[value])}}])
const colors={bg:'#fff',fg:'#111'},width=300,height=100
const drawing=drawNative(factory=>({family:'flowchart',width,height,colors,transparent:false,parts:[factory.documentOpen({id:'root',width,height,colors,transparent:false,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="100">'),factory.text({id:'label',role:'label',text:block.text,block,x:20,y:40,fontSize:18,anchor:'start',paint:{fill:'#111'}}),factory.documentClose()]}),{positioned:{width,height},colors,resolved:{renderOptions:{}}} as any,'flowchart')
const proof=certifyNativePaint(drawing.header,drawing.paint)
console.log(JSON.stringify({owned,frozen,traps,svg:drawing.svg,proof:proof.status,coverage:proof.coverage,issues:proof.issues}))
