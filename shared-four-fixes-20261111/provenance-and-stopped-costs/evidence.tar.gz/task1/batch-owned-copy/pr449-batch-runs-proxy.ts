const define=Object.getOwnPropertyDescriptor(Object,'defineProperty')!,names=Object.getOwnPropertyDescriptor(Object,'getOwnPropertyNames')!,push=Object.getOwnPropertyDescriptor(Array.prototype,'push')!
let span:object|undefined,active=false,defined=false,traps=0
Object.defineProperty(Array.prototype,'push',{...push,value(...args:unknown[]){
 const item:any=args[0]
 if(args.length===1&&Array.isArray(item)&&!Object.isFrozen(item)&&item.length===1&&item[0]?.text==='R'&&typeof item[0]?.bold==='boolean'&&new Error().stack?.includes('preparePixelText')){
  span=new Proxy(item,{getOwnPropertyDescriptor(target,key){if(active&&key==='0')defined=false;if(active&&key==='length'&&!defined){traps++;throw Error('source observed before prior destination write')}return Reflect.getOwnPropertyDescriptor(target,key)}})
  return Reflect.apply(push.value,this,[span])
 }
 return Reflect.apply(push.value,this,args)
}})
const {preparePixelText,isOwnedPixelTextPart}=await import('/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts')
const {drawNative}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts')
const {certifyNativePaint}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts')
const block=preparePixelText('R',{fontSize:18,fontWeight:400}),owned=isOwnedPixelTextPart(span!),frozen=Object.isFrozen(span)
Reflect.apply(define.value,Object,[Object,'defineProperty',{...define,value(target:object,key:PropertyKey,descriptor:PropertyDescriptor){if(key==='0'&&descriptor.value?.text==='R')defined=true;return Reflect.apply(define.value,Object,[target,key,descriptor])}}])
Reflect.apply(define.value,Object,[Object,'getOwnPropertyNames',{...names,value(value:object){if(value===span)active=true;return Reflect.apply(names.value,Object,[value])}}])
const colors={bg:'#fff',fg:'#111'},width=300,height=100
const drawing=drawNative(factory=>({family:'flowchart',width,height,colors,transparent:false,parts:[factory.documentOpen({id:'root',width,height,colors,transparent:false,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="100">'),factory.text({id:'label',role:'label',text:'R',block,x:20,y:40,fontSize:18,anchor:'start',paint:{fill:'#111'}}),factory.documentClose()]}),{positioned:{width,height},colors,resolved:{renderOptions:{}}} as any,'flowchart')
const proof=certifyNativePaint(drawing.header,drawing.paint)
console.log(JSON.stringify({owned,frozen,traps,svg:drawing.svg,proof:proof.status,coverage:proof.coverage,issues:proof.issues}))
