const define=Object.getOwnPropertyDescriptor(Object,'defineProperty')!
let changed=0
Reflect.apply(define.value,Object,[Object,'defineProperty',{...define,value(target:object,key:PropertyKey,descriptor:PropertyDescriptor){
  if(key==='text'&&descriptor.value==='R'&&Reflect.ownKeys(target).length===0){changed++;descriptor={...descriptor,value:'Lost'}}
  return Reflect.apply(define.value,Object,[target,key,descriptor])
}}])
const {preparePixelText,isOwnedPixelTextPart}=await import('/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts')
const {drawNative}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts')
const {certifyNativePaint}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts')
const block=preparePixelText('R',{fontSize:18,fontWeight:400}),owned=isOwnedPixelTextPart(block.lineBlocks[0]!.runs[0]!),frozen=Object.isFrozen(block)
const colors={bg:'#fff',fg:'#111'},width=300,height=100
const drawing=drawNative(factory=>({family:'flowchart',width,height,colors,transparent:false,parts:[factory.documentOpen({id:'root',width,height,colors,transparent:false,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="100">'),factory.text({id:'label',role:'label',text:'R',block,x:20,y:40,fontSize:18,anchor:'start',paint:{fill:'#111'}}),factory.documentClose()]}),{positioned:{width,height},colors,resolved:{renderOptions:{}}} as any,'flowchart')
const proof=certifyNativePaint(drawing.header,drawing.paint)
console.log(JSON.stringify({owned,frozen,changed,svg:drawing.svg,proof:proof.status,coverage:proof.coverage,issues:proof.issues}))
