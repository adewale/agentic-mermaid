const freeze=Object.getOwnPropertyDescriptor(Object,'freeze')!,define=Object.getOwnPropertyDescriptor(Object,'defineProperty')!,names=Object.getOwnPropertyDescriptor(Object,'getOwnPropertyNames')!
let span:object|undefined,active=false,defined=false,traps=0
Object.defineProperty(Object,'freeze',{...freeze,value(value:any){const closed=Reflect.apply(freeze.value,Object,[value]);if(value&&value.text==='R'&&Object.hasOwn(value,'sourceStart')&&Object.hasOwn(value,'sourceEnd')&&!Object.hasOwn(value,'bold')){const proxy=new Proxy(closed,{getOwnPropertyDescriptor(target,key){if(active&&key==='text')defined=false;if(active&&key==='sourceStart'&&!defined){traps++;throw Error('source descriptor observed before prior destination definition')}return Reflect.getOwnPropertyDescriptor(target,key)}});span=proxy;return proxy}return closed}})
const {preparePixelText,isOwnedPixelTextPart}=await import('/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts')
const {drawNative}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts')
const {certifyNativePaint}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts')
const block=preparePixelText('R',{fontSize:18,fontWeight:400}),owned=isOwnedPixelTextPart(span!),frozen=Object.isFrozen(span)
Reflect.apply(define.value,Object,[Object,'defineProperty',{...define,value(target:object,key:PropertyKey,descriptor:PropertyDescriptor){if(key==='text'&&descriptor.value==='R')defined=true;return Reflect.apply(define.value,Object,[target,key,descriptor])}}])
Reflect.apply(define.value,Object,[Object,'getOwnPropertyNames',{...names,value(value:object){if(value===span)active=true;return Reflect.apply(names.value,Object,[value])}}])
const colors={bg:'#fff',fg:'#111'},width=300,height=100
const drawing=drawNative(factory=>({family:'flowchart',width,height,colors,transparent:false,parts:[factory.documentOpen({id:'root',width,height,colors,transparent:false,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="100">'),factory.text({id:'label',role:'label',text:'R',block,x:20,y:40,fontSize:18,anchor:'start',paint:{fill:'#111'}}),factory.documentClose()]}),{positioned:{width,height},colors,resolved:{renderOptions:{}}} as any,'flowchart')
const proof=certifyNativePaint(drawing.header,drawing.paint)
console.log(JSON.stringify({owned,frozen,traps,svg:drawing.svg,proof:proof.status,coverage:proof.coverage,issues:proof.issues}))
