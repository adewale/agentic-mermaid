# Task4 shared browser provider subtraction

Equal frozen source snapshots including in-flight Native edits; only Task4 provider files reverted in control. Not the final combined candidate.

4 of the existing 33 enrolled families; same mandatory same-family support probe plus enrolled case; Native/ELK fallback none; full public prod WithReceipt APIs. Actual fetched local response bytes compressed offline per module gzip9/Brotli11, binding separate. No wire, portfolio sum, package, or API-speed claim.

Observable contract: the async public API returns exactly the same whole SVG and fully consumed receipt, including configuration interpretation, errors, option observations, and safety evidence. Node/IIFE/editor-worker synchronous consumers still use the original pinned merge program. Ordinary source rendering no longer imports its unused config keys/merge program; configured source obtains that exact program with the existing YAML provider. No new cache, compiler/compression/default/version/cap setting was added.

16/16 stock Trident observations qualified; 32 complete public products compare exactly; all 16 browsers closed.

| Backend | Family | Requests before/after | Raw delta B | gzip9 delta B | Brotli11 delta B | Heap before/after B |
|---|---|---:|---:|---:|---:|---:|
|agentic|flowchart|[41, 41]|-22575|-6918|-5441|[5933840, 5932748]|
|agentic|sequence|[15, 15]|-22605|-6931|-5494|[5030748, 5033748]|
|agentic|timeline|[11, 11]|-22590|-6925|-5508|[4394788, 4393696]|
|agentic|sankey|[14, 14]|-22595|-6931|-5514|[4661980, 4660776]|
|elk|flowchart|[31, 31]|-22590|-6926|-5470|[11258148, 11266660]|
|elk|sequence|[15, 15]|-22605|-6931|-5494|[5034152, 5033160]|
|elk|timeline|[11, 11]|-22590|-6925|-5508|[4394140, 4393732]|
|elk|sankey|[14, 14]|-22595|-6931|-5514|[4661300, 4660264]|

Configuration probe: 18/18 fresh-realm target/input results match the frozen synchronous public WithReceipt response/error and warm repeat. Frontmatter, init, wrap, direct mermaidConfig, multi-init remapping, Unicode/XML/lone surrogate, malformed frontmatter, and generous init are exercised. Direct option proxy/getter reads remain 2 on both targets. Request/byte adverses above are retained.

Verification: source/browser owners 89P/1418 assertions; exact owning browser tests 9P/92 assertions against frozen candidate (no IIFE/website rebuild); core typecheck and scoped lint pass. Worker configuration owner result is retained separately. The owning browser helper now builds only the lazy target for this test group.

Artifacts: `browser/RESULTS.json`, per-lane `DELIVERY.json`, fully serialized gzipped products, module manifests and unchanged qualification helper; `CONFIG-PARITY.json`; build/owner/type/lint logs. `task4-tracked.patch` plus untracked `src/shared/mermaid-config-merge.ts` identify the production/test changes.

Remaining limits:
- Remaining shared proof/security growth is not eliminated.
- Wrap-only source now demands YAML provider: +1 request, +100280 raw/+31406 gzip9/+28390 Brotli11 bytes.
- Already-YAML configuration paths: same requests, +172 raw/+158 gzip9/+586 Brotli11 bytes in the examined Sequence inputs.
- Forced-GC JS heap is mixed; ELK Flow +8512 bytes and Native Sequence +3000 bytes are adverse. No runtime timing claim.
- Root owns final full-33-family actual-closure metrics and combined candidate qualification.
