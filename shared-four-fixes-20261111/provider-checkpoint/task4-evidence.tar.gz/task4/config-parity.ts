import {readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
import {createHash} from 'node:crypto'
import {gzipSync,brotliCompressSync,constants} from 'node:zlib'
import {createRequire} from 'node:module'
const out=import.meta.dir
const require=createRequire('/workspace/agentic-mermaid/package.json')
const {chromium}=require('playwright')
const cases=[
 {id:'ordinary',source:'sequenceDiagram\nAlice->>Bob: Ready'},
 {id:'frontmatter',source:'---\nconfig:\n  sequence:\n    actorMargin: 75\ntitle: Configured\n---\nsequenceDiagram\nAlice->>Bob: Ready'},
 {id:'init',source:'%%{init: {"sequence":{"actorMargin":75}}}%%\nsequenceDiagram\nAlice->>Bob: Ready'},
 {id:'wrap',source:'%%{wrap}%%\nsequenceDiagram\nAlice->>Bob: Ready'},
 {id:'direct-options',source:'sequenceDiagram\nAlice->>Bob: Ready',config:{sequence:{actorMargin:75}}},
 {id:'multi-init-remap',source:'%%{init: {"config":{"actorMargin":75}}}%%\n%%{init: {"sequence":{"wrap":true}}}%%\nsequenceDiagram\nAlice->>Bob: Ready'},
 {id:'unicode-and-xml',source:'%%{init: {"sequence":{"actorMargin":75}}}%%\nsequenceDiagram\nAlice->>Bob: 😀 &amp; <tag>\nBob-->>Alice: \ud800'},
 {id:'malformed-frontmatter',source:'---\ntitle: [unclosed\n---\nsequenceDiagram\nAlice->>Bob: Ready'},
 {id:'generous-init',source:'%%{init: {sequence: {actorMargin: 75}}}%%\nsequenceDiagram\nAlice->>Bob: Ready'},
]
const reference=[]
for(const c of cases){
 const child=Bun.spawn(['/tmp/pr449-tools-20261106/package/bin/bun','--eval',`import { renderMermaidSVGWithReceipt } from ${JSON.stringify(out+'/candidate/src/index.ts')};const c=JSON.parse(await Bun.stdin.text());try {const diagnostics=[];const product=renderMermaidSVGWithReceipt(c.source,{security:'strict',embedFontImport:false,...(c.config?{mermaidConfig:c.config}:{}),onConfigDiagnostic:x=>diagnostics.push(x)});console.log(JSON.stringify({product,diagnostics}));}catch(error){console.log(JSON.stringify({error:String(error)}));}`],{stdin:'pipe',stdout:'pipe',stderr:'pipe',env:{...process.env,AGENTIC_MERMAID_SCENE_ASSERTIONS:'0'}})
 child.stdin.write(JSON.stringify(c));child.stdin.end(); const stdout=await new Response(child.stdout).text(),stderr=await new Response(child.stderr).text(); if(await child.exited!==0)throw Error(stderr);reference.push(JSON.parse(stdout))
}
const server=Bun.serve({port:0,hostname:'127.0.0.1',fetch(req){const p=new URL(req.url).pathname;if(p==='/')return new Response('<!doctype html><html><body></body></html>',{headers:{'content-type':'text/html'}});const file=Bun.file(join(out,p));return new Response(file,{headers:{'content-type':'application/javascript'}})}})
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});const rows=[]
try{for(const target of ['control','candidate'])for(let index=0;index<cases.length;index++){
 const c=cases[index]!,page=await browser.newPage(),requests=new Set<string>()
 await page.route('**/*',async route=>new URL(route.request().url()).hostname==='127.0.0.1'?route.continue():route.abort())
 page.on('response',(response:any)=>{const p=new URL(response.url()).pathname;if(p.endsWith('.js'))requests.add(p)})
 try{
  await page.goto('http://127.0.0.1:'+server.port+'/')
  const result=await page.evaluate(async({url,c}:any)=>{const api=await import(url);const diagnostics:any[]=[];let reads=0;const nested=c.config?new Proxy(c.config,{get(target,key,receiver){reads++;return Reflect.get(target,key,receiver)}}):undefined;const options:any={security:'strict',embedFontImport:false,onConfigDiagnostic:(x:any)=>diagnostics.push(x)};if(nested)Object.defineProperty(options,'mermaidConfig',{enumerable:true,get(){reads++;return nested}});try{const product=await api.renderMermaidSVGWithReceiptAsync(c.source,options);const first=JSON.parse(JSON.stringify(product));const firstReads=reads;const repeated=await api.renderMermaidSVGWithReceiptAsync(c.source,{security:'strict',embedFontImport:false,...(c.config?{mermaidConfig:c.config}:{})});return {product:first,repeated:JSON.parse(JSON.stringify(repeated)),diagnostics,reads:firstReads}}catch(error){return{error:String(error),reads}}},{url:'http://127.0.0.1:'+server.port+'/'+target+'/dist/browser-lazy/index.js',c})
  const expected=reference[index],actual='error'in result?{error:result.error}:{product:result.product,diagnostics:result.diagnostics};const pass=JSON.stringify(actual)===JSON.stringify(expected)&&('error'in result||JSON.stringify(result.product)===JSON.stringify(result.repeated));if(!pass)throw Error(target+':'+c.id+' mismatch\n'+JSON.stringify({actual,expected}))
  const files=[...requests].sort().map(path=>{const b=readFileSync(join(out,path));return{path,sha256:createHash('sha256').update(b).digest('hex'),raw:b.length,gzip9:gzipSync(b,{level:9}).length,brotli11:brotliCompressSync(b,{params:{[constants.BROTLI_PARAM_QUALITY]:11}}).length}})
  rows.push({target,id:c.id,pass,reads:result.reads,status:'error'in result?'error':'returned',files,requests:files.length,product:result.product,error:result.error,totals:files.reduce((s,f)=>({raw:s.raw+f.raw,gzip9:s.gzip9+f.gzip9,brotli11:s.brotli11+f.brotli11}),{raw:0,gzip9:0,brotli11:0})});console.log(JSON.stringify({target,id:c.id,pass,reads:result.reads,requests:files.length,totals:rows.at(-1)!.totals}))
 }finally{await page.close()}
}}finally{await browser.close();server.stop(true);writeFileSync(join(out,'CONFIG-PARITY.json'),JSON.stringify({reference:'frozen candidate synchronous public SVG WithReceipt',scope:'Fresh realm per target/input; full public products and warm repeat fully serialized; actual product JS requests only, raw local bytes compressed offline gzip9/Brotli11. No timing/heap claim.',rows},null,2))}
