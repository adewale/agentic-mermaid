import {writeFileSync} from 'node:fs'
import {preprocessMermaidSource as original} from '../control/src/mermaid-source.ts'
import {preprocessMermaidSource as final} from '../candidate-guarded/src/mermaid-source.ts'
const body='sequenceDiagram\nAlice->>Bob: Wrapped'
const sources=[
 ['plain-wrap','%%{wrap}%%\n'+body],
 ['CRLF','%%{wrap}%%\r\n'+body.replaceAll('\n','\r\n')],
 ['repeated','%%{wrap}%%\n%%{wrap}%%\n'+body],
 ['spaced','%%{ wrap }%%\n'+body],
 ['adjacent','%%{wrap}%%%%{wrap}%%'+body],
 ['inline','sequenceDiagram\n%%{wrap}%%Alice->>Bob: Wrapped'],
 ['empty-frontmatter','---\n---\n%%{wrap}%%\n'+body],
 ['mixed-init','%%{wrap}%%\n%%{init: {"sequence":{"actorMargin":75}}}%%\n'+body],
 ['mixed-frontmatter','---\nconfig:\n  sequence:\n    actorMargin: 75\n---\n%%{wrap}%%\n'+body],
 ['arg-null','%%{wrap: null}%%\n'+body],
 ['arg-false','%%{wrap: false}%%\n'+body],
 ['arg-map','%%{wrap: {"sequence":{"actorMargin":75}}}%%\n'+body],
 ['arg-empty','%%{wrap: }%%\n'+body],
 ['mixed-case','%%{Wrap}%%\n'+body],
] as const
const rows=[]
for(const[id,source]of sources)for(const base of [{},{sequence:{actorMargin:85}}]){
 const a=original(source,structuredClone(base)),b=final(source,structuredClone(base))
 if(JSON.stringify(a)!==JSON.stringify(b))throw Error('Canonical mismatch '+id+' '+JSON.stringify({base,a,b}))
 b.frontmatter.wrap=false
 const fresh=final(source,structuredClone(base))
 if(JSON.stringify(fresh)!==JSON.stringify(a))throw Error('Mutable configuration sharing '+id)
 rows.push({id,source,base,canonicalFrontmatter:a.frontmatter,exact:true,fresh:true})
}
writeFileSync(import.meta.dir+'/WRAP-CANONICAL.json',JSON.stringify({comparison:'Original frozen control canonical pinned merge vs final wrap-only branch, original complete preprocess results compared before mutation; fresh frontmatter rechecked after caller mutation.',rows},null,2)+'\n')
console.log(rows.length+' original-canonical source comparisons exact and mutable frontmatter independent')
