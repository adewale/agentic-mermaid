from pathlib import Path
import json,gzip,csv,collections,statistics,hashlib
out=Path(__file__).resolve().parent
oldroot=Path('/tmp/pr449-week-comparison-20261101/trident-main-20261110/browser')
rows=json.loads((out/'RESULTS.json').read_text());old=json.loads((oldroot/'RESULTS.json').read_text());identity=json.loads((out.parent/'IDENTITY.json').read_text());closed=json.loads((out/'CLOSED.json').read_text())
assert len(rows)==66 and len({(x['backend'],x['family']) for x in rows})==66
assert closed['browserOpened']==closed['browserClosed']==66 and closed['openBrowsers']==0
assert all(x['status']=='passed' and len(x['publicProducts'])==2 and not x['observerErrors'] for x in rows)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(oldroot/'RESULTS.json')==identity['baseline']['browserResultsSha256']
for row in rows:
 assert not any(f.get('error') for f in row['fetched'])
 for key in ['raw','gzip9','brotli11']:
  assert sum(f[key] for f in row['fetched'] if f['kind']=='actual product module')==row['product'][key]
  assert sum(f[key] for f in row['fetched'] if f['kind']!='actual product module')==row['adapter'][key]
comparisons=[];pairs={};proofs=[]
for row in rows:
 for p in row['publicProducts']:
  proof=p.get('proof',{})
  if proof.get('status')!='passed':proofs.append({'backend':row['backend'],'family':row['family'],'role':p['role'],'status':proof.get('status','absent'),'issues':proof.get('issues',[]),'limitations':proof.get('limitations',[])})
 for target in ['main','pr']:
  ref=next(x for x in old if (x['target'],x['backend'],x['family'])==(target,row['backend'],row['family']))
  comparisons.append({'baseline':'Main426' if target=='main' else 'PR599','backend':row['backend'],'family':row['family'],'baselineRequests':ref['requests'],'candidateRequests':row['requests'],'requestDelta':row['requests']-ref['requests'],**{prefix+key[0].upper()+key[1:]:value[key] for prefix,value in [('baseline',ref['product']),('candidate',row['product']),('delta',{k:row['product'][k]-ref['product'][k] for k in row['product']})] for key in ['raw','gzip9','brotli11']},'baselineJsHeapBytes':ref['heap']['metrics']['jsHeapUsedBytes'],'candidateJsHeapBytes':row['heap']['metrics']['jsHeapUsedBytes'],'deltaJsHeapBytes':row['heap']['metrics']['jsHeapUsedBytes']-ref['heap']['metrics']['jsHeapUsedBytes']})
  counter=pairs.setdefault(target,collections.Counter())
  for call in [1,2]:
   a=json.loads(gzip.decompress((oldroot/(target+'-'+row['backend'])/row['family']/f'call{call}.product.json.gz').read_bytes()))
   b=json.loads(gzip.decompress((out/('pr-'+row['backend'])/row['family']/f'call{call}.product.json.gz').read_bytes()))
   counter['products']+=1
   for k,v in [('wholeExact',a==b),('svgExact',a['svg']==b['svg']),('receiptExact',a['receipt']==b['receipt']),('proofStatusSame',a['receipt'].get('layoutCertification',{}).get('status')==b['receipt'].get('layoutCertification',{}).get('status')),('layoutDecisionsSame',a['receipt'].get('layoutDecisions')==b['receipt'].get('layoutDecisions'))]:counter[k]+=bool(v)
with (out/'NET-COMPARISON.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(comparisons[0]));w.writeheader();w.writerows(comparisons)
payload=[]
for row in rows:
 p=row['publicProducts'][1];proof=p.get('proof',{});decisions=p.get('layoutDecisions',[])
 payload.append({'target':'621d596088be5a08e03656eaacb3a52c934bac33','backend':row['backend'],'family':row['family'],'status':row['status'],'requests':row['requests'],'productRequests':sum(f['kind']=='actual product module' for f in row['fetched']),'productRaw':row['product']['raw'],'productGzip9':row['product']['gzip9'],'productBrotli11':row['product']['brotli11'],'bindingRaw':row['adapter']['raw'],'bindingGzip9':row['adapter']['gzip9'],'bindingBrotli11':row['adapter']['brotli11'],'jsHeapUsedBytes':row['heap']['metrics']['jsHeapUsedBytes'],'publicReceiptStatus':p['status'],'receiptProof':proof.get('status','absent'),'receiptIssues':json.dumps(proof.get('issues',[]),separators=(',',':')),'layoutSelected':';'.join(d.get('selected','absent') for d in decisions),'layoutApplicability':'observed decision' if decisions else 'no recorded graph choice'})
with (out/'FAMILY-PAYLOAD.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(payload[0]));w.writeheader();w.writerows(payload)
summary={'source':identity['sources']['pr'],'trident':identity['trident'],'observations':66,'families':33,'fullPublicProducts':132,'qualificationStatuses':dict(collections.Counter(x['status'] for x in rows)),'proofStatusesAllProducts':dict(collections.Counter(p.get('proof',{}).get('status','absent') for x in rows for p in x['publicProducts'])),'unknownProofs':proofs,'wholeProductComparisons':{k:dict(v) for k,v in pairs.items()},'closureDeltas':{},'artifacts':{},'closed':closed,'baselineResultsSha256':sha(oldroot/'RESULTS.json'),'casesSha256':identity['cases']['sha256'],'actualCandidateResultsSha256':sha(out/'RESULTS.json'),'scope':'Fresh realm per family/backend; mandatory same-family support probe plus enrolled case; actual public WithReceiptAsync product fully serialized/retained. Observed fetched-module response bytes compressed offline separately at gzip9/Brotli11; bindings separately retained. No wire, whole-package, warm-portfolio sum, API timing, complete-authored-meaning or all-four-goals claim.'}
for backend in ['agentic','elk']:
 artifact=json.loads((out/('pr-'+backend+'-ARTIFACT.json')).read_text())
 summary['artifacts'][backend]={'browserArtifactSha256':artifact['peer']['browser']['artifactSha256'],'entrySha256':next(f['sha256'] for f in artifact['peer']['browser']['files'] if f['path'].endswith('/browser-lazy/index.js')),'qualificationHelper':artifact['peer']['browser']['qualificationHelper']}
 for baseline in ['Main426','PR599']:
  group=[x for x in comparisons if x['baseline']==baseline and x['backend']==backend]
  stats={}
  for field in ['Raw','Gzip9','Brotli11','JsHeapBytes']:
   vals=[x['delta'+field] for x in group];stats[field]={'min':min(vals),'median':statistics.median(vals),'max':max(vals),'lower':sum(x<0 for x in vals),'higher':sum(x>0 for x in vals),'same':sum(x==0 for x in vals)}
  stats['requests']=dict(collections.Counter(x['requestDelta'] for x in group));summary['closureDeltas'][baseline+'-'+backend]=stats
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['# Actual lazy-browser delivery at frozen621','',f"Source `{summary['source']}`; Trident `{summary['trident']}`.66/66 family/arm observations qualify,132 complete public SVG/receipt products retained,66 browsers closed and0 left open. No observer or module-fetch errors.",'',summary['scope'],'','All132SVGs equal PR599. Whole responses/receipts equal8/132; all132 paint-proof statuses and layout decisions are unchanged.124proofs pass;8remain unverified: Timeline and XYChart, both support/enrolled calls on both requested backend arms, with OUTPUT_SCOPE. Qualification is XML/canvas/visible-label evidence, not complete authored meaning. No actual graph-layout decision is recorded for25families; requested backend labels alone do not prove backend application.','','Each cell is **requests / product raw KiB / gzip9 KiB / Brotli11 KiB / post-GC JS heap MiB**. Request counts include the separately measured bindings, matching the retained baseline method. These fresh-realm closures must not be summed as a warm portfolio.','','|Family|Main Native|Main ELK|PR599 Native|PR599 ELK|621 Native|621 ELK|','|---|---|---|---|---|---|---|']
def cell(x):
 p=x['product'];return f"{x['requests']} / {p['raw']/1024:.1f} / {p['gzip9']/1024:.1f} / {p['brotli11']/1024:.1f} / {x['heap']['metrics']['jsHeapUsedBytes']/1048576:.2f}"
for family in [x['family'] for x in rows if x['backend']=='agentic']:
 cells=[cell(next(x for x in old if (x['target'],x['backend'],x['family'])==(t,b,family))) for t in ['main','pr'] for b in ['agentic','elk']]
 cells += [cell(next(x for x in rows if (x['backend'],x['family'])==(b,family))) for b in ['agentic','elk']]
 lines.append('|'+family+'|'+'|'.join(cells)+'|')
lines+=['','Against PR599,32/33 family closures per arm shrink around6.55KB raw/2.07KB gzip/1.48KB Brotli. Agentflow grows: Native+16239raw/+5038gzip/+4487Brotli; ELK+16249/+5038/+4555. All request counts are unchanged. This net combined result includes the later safety/producer code; it is smaller than the isolated provider saving.','','Against Main426,all33closures on both arms remain larger: median+126991raw/+41277gzip/+31680Brotli bytes. Flowchart remains+62582gzip Native/+50947gzip ELK and+9/+3requests. Existing Native-versus-ELK byte advantage predates this change.','','Heap is adverse against PR599 in all33families on both arms: median+55092B Native/+58628B ELK. Forced-GC JavaScript heap excludes native/WASM/process memory; no leak or runtime-speed inference is made. Browser observer transport sits inside clocks, so collected raw timing samples are not API cost evidence.','','Against Main,124/132SVGs are equal; ER and Requirement support/enrolled SVGs differ on both arms. All132proof statuses/layout decisions remain the same. The separate authored/actual-ink qualification owns their meaning.','','Identity: unchanged artifactIdentity(resolveArtifact) ran on an explicit compiled package view with121 actual frozen-dist hardlinks; every file byte,entry and installed dependency closure was checked before rebinding runtime identity to frozen621. No fake Git marker or source-primary rendering. The identity view is compiled inventory, not npm payload. CASES and retained baseline results hashes are checked and retained in IDENTITY.json; actual browser manifests/helper identities are in each ARTIFACT.json and DELIVERY.json.','','Files: FAMILY-PAYLOAD.csv actual66product closures;NET-COMPARISON.csv all132baseline/arm/family deltas;SUMMARY.json includes all unknown proofs, hash identities and adverse ranges;per-lane fully serialized products, receipts and fetched-module manifests remain retained. Main426/PR599 were not replayed.']
(out/'SUMMARY.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'source':summary['source'],'observations':66,'products':132,'proofs':summary['proofStatusesAllProducts'],'artifacts':summary['artifacts'],'actualCandidateResultsSha256':summary['actualCandidateResultsSha256']}))
