# Actual lazy-browser delivery at frozen621

Source `621d596088be5a08e03656eaacb3a52c934bac33`; Trident `f080278e31e4202ca89d524e4ee9e4cf3cbff038`.66/66 family/arm observations qualify,132 complete public SVG/receipt products retained,66 browsers closed and0 left open. No observer or module-fetch errors.

Fresh realm per family/backend; mandatory same-family support probe plus enrolled case; actual public WithReceiptAsync product fully serialized/retained. Observed fetched-module response bytes compressed offline separately at gzip9/Brotli11; bindings separately retained. No wire, whole-package, warm-portfolio sum, API timing, complete-authored-meaning or all-four-goals claim.

All132SVGs equal PR599. Whole responses/receipts equal8/132; all132 paint-proof statuses and layout decisions are unchanged.124proofs pass;8remain unverified: Timeline and XYChart, both support/enrolled calls on both requested backend arms, with OUTPUT_SCOPE. Qualification is XML/canvas/visible-label evidence, not complete authored meaning. No actual graph-layout decision is recorded for25families; requested backend labels alone do not prove backend application.

Each cell is **requests / product raw KiB / gzip9 KiB / Brotli11 KiB / post-GC JS heap MiB**. Request counts include the separately measured bindings, matching the retained baseline method. These fresh-realm closures must not be summed as a warm portfolio.

|Family|Main Native|Main ELK|PR599 Native|PR599 ELK|621 Native|621 ELK|
|---|---|---|---|---|---|---|
|flowchart|32 / 984.9 / 326.5 / 280.3 / 5.15|28 / 2230.5 / 688.0 / 544.9 / 10.22|41 / 1173.1 / 389.6 / 332.1 / 5.65|31 / 2390.1 / 739.7 / 585.9 / 10.70|41 / 1166.7 / 387.6 / 330.6 / 5.73|31 / 2383.7 / 737.7 / 584.4 / 10.77|
|sequence|16 / 567.0 / 181.8 / 154.7 / 4.17|16 / 567.0 / 181.8 / 154.7 / 4.17|15 / 697.4 / 224.1 / 187.0 / 4.80|15 / 697.4 / 224.1 / 187.0 / 4.79|15 / 691.0 / 222.1 / 185.5 / 4.87|15 / 691.0 / 222.1 / 185.5 / 4.87|
|state|28 / 984.0 / 325.6 / 279.5 / 4.87|24 / 2229.6 / 687.1 / 544.1 / 9.97|37 / 1172.1 / 388.7 / 331.4 / 5.46|27 / 2389.0 / 738.8 / 585.1 / 10.50|37 / 1165.7 / 386.7 / 329.8 / 5.54|27 / 2382.7 / 736.8 / 583.6 / 10.58|
|class|25 / 781.1 / 255.5 / 218.0 / 4.67|22 / 2044.7 / 622.9 / 487.7 / 9.24|36 / 964.6 / 318.6 / 269.5 / 5.11|23 / 2178.9 / 666.7 / 521.3 / 9.59|36 / 958.1 / 316.5 / 268.0 / 5.12|23 / 2172.5 / 664.7 / 519.8 / 9.61|
|er|26 / 862.4 / 284.0 / 243.2 / 4.56|22 / 2108.0 / 645.4 / 507.8 / 9.18|37 / 1062.9 / 352.3 / 299.2 / 5.00|25 / 2271.7 / 698.6 / 549.5 / 9.54|37 / 1056.5 / 350.3 / 297.7 / 5.02|25 / 2265.3 / 696.6 / 548.0 / 9.55|
|timeline|12 / 509.1 / 163.3 / 138.0 / 3.78|12 / 509.1 / 163.3 / 138.0 / 3.78|11 / 639.5 / 205.7 / 170.3 / 4.19|11 / 639.5 / 205.7 / 170.3 / 4.19|11 / 633.1 / 203.6 / 168.9 / 4.24|11 / 633.1 / 203.6 / 168.9 / 4.23|
|journey|13 / 529.6 / 170.6 / 144.5 / 4.29|13 / 529.6 / 170.6 / 144.5 / 4.29|12 / 660.0 / 212.9 / 176.9 / 4.94|12 / 660.0 / 212.9 / 176.9 / 4.94|12 / 653.6 / 210.9 / 175.5 / 5.01|12 / 653.6 / 210.9 / 175.5 / 5.01|
|architecture|29 / 964.1 / 317.3 / 271.7 / 4.61|25 / 2209.7 / 678.8 / 536.3 / 10.07|38 / 1152.4 / 380.5 / 323.6 / 5.14|28 / 2369.4 / 730.6 / 577.4 / 10.56|38 / 1146.0 / 378.5 / 322.1 / 5.23|28 / 2363.0 / 728.6 / 575.9 / 10.65|
|xychart|16 / 551.4 / 178.0 / 150.9 / 4.32|16 / 551.4 / 178.0 / 150.9 / 4.32|15 / 681.8 / 220.3 / 183.3 / 4.82|15 / 681.8 / 220.3 / 183.3 / 4.82|15 / 675.4 / 218.3 / 181.9 / 4.87|15 / 675.4 / 218.3 / 181.9 / 4.87|
|pie|18 / 521.4 / 170.1 / 144.0 / 3.82|18 / 521.4 / 170.1 / 144.0 / 3.82|17 / 651.8 / 212.4 / 176.3 / 4.16|17 / 651.8 / 212.4 / 176.3 / 4.16|17 / 645.4 / 210.4 / 174.9 / 4.19|17 / 645.4 / 210.4 / 174.9 / 4.19|
|quadrant|15 / 518.4 / 167.7 / 141.8 / 3.97|15 / 518.4 / 167.7 / 141.8 / 3.97|14 / 648.8 / 210.0 / 174.2 / 4.36|14 / 648.8 / 210.0 / 174.2 / 4.36|14 / 642.4 / 208.0 / 172.7 / 4.40|14 / 642.4 / 208.0 / 172.7 / 4.40|
|gantt|12 / 535.5 / 172.5 / 146.2 / 4.02|12 / 535.5 / 172.5 / 146.2 / 4.02|11 / 665.9 / 214.8 / 178.5 / 4.41|11 / 665.9 / 214.8 / 178.5 / 4.41|11 / 659.5 / 212.8 / 177.2 / 4.45|11 / 659.5 / 212.8 / 177.2 / 4.44|
|mindmap|17 / 524.9 / 172.1 / 145.8 / 4.04|17 / 524.9 / 172.1 / 145.8 / 4.04|16 / 655.3 / 214.4 / 178.1 / 4.46|16 / 655.3 / 214.4 / 178.1 / 4.46|16 / 648.9 / 212.4 / 176.7 / 4.50|16 / 648.9 / 212.4 / 176.7 / 4.50|
|gitgraph|15 / 523.8 / 170.1 / 144.0 / 4.16|15 / 523.8 / 170.1 / 144.0 / 4.16|14 / 654.2 / 212.4 / 176.3 / 4.53|14 / 654.2 / 212.4 / 176.3 / 4.53|14 / 647.8 / 210.4 / 174.9 / 4.60|14 / 647.8 / 210.4 / 174.9 / 4.60|
|radar|17 / 527.6 / 171.8 / 145.6 / 3.95|17 / 527.6 / 171.8 / 145.6 / 3.95|16 / 658.1 / 214.2 / 178.0 / 4.31|16 / 658.1 / 214.2 / 178.0 / 4.31|16 / 651.7 / 212.1 / 176.5 / 4.34|16 / 651.7 / 212.1 / 176.5 / 4.34|
|sankey|14 / 521.2 / 169.3 / 143.3 / 4.06|14 / 521.2 / 169.3 / 143.3 / 4.06|14 / 659.1 / 213.3 / 177.3 / 4.44|14 / 659.1 / 213.3 / 177.3 / 4.44|14 / 652.7 / 211.3 / 175.8 / 4.48|14 / 652.7 / 211.3 / 175.8 / 4.48|
|c4|20 / 702.7 / 228.8 / 195.5 / 4.83|20 / 702.7 / 228.8 / 195.5 / 4.83|22 / 861.1 / 280.1 / 235.7 / 5.33|22 / 861.1 / 280.1 / 235.7 / 5.33|22 / 854.8 / 278.1 / 234.3 / 5.41|22 / 854.8 / 278.1 / 234.3 / 5.41|
|packet|13 / 496.8 / 160.3 / 135.3 / 3.75|13 / 496.8 / 160.3 / 135.3 / 3.75|12 / 627.2 / 202.7 / 167.7 / 4.18|12 / 627.2 / 202.7 / 167.7 / 4.18|12 / 620.8 / 200.7 / 166.3 / 4.22|12 / 620.8 / 200.7 / 166.3 / 4.22|
|kanban|14 / 505.2 / 163.7 / 138.4 / 3.86|14 / 505.2 / 163.7 / 138.4 / 3.86|13 / 635.6 / 206.1 / 170.7 / 4.28|13 / 635.6 / 206.1 / 170.7 / 4.28|13 / 629.2 / 204.0 / 169.3 / 4.33|13 / 629.2 / 204.0 / 169.3 / 4.33|
|requirement|20 / 690.4 / 226.6 / 193.1 / 4.45|14 / 1930.5 / 585.7 / 455.6 / 9.05|31 / 879.7 / 291.4 / 246.3 / 5.11|16 / 2070.7 / 631.4 / 490.9 / 9.66|31 / 873.3 / 289.4 / 244.8 / 5.19|16 / 2064.3 / 629.4 / 489.4 / 9.74|
|treemap|15 / 515.3 / 168.1 / 142.4 / 3.79|15 / 515.3 / 168.1 / 142.4 / 3.79|14 / 645.7 / 210.4 / 174.7 / 4.21|14 / 645.7 / 210.4 / 174.7 / 4.21|14 / 639.3 / 208.4 / 173.3 / 4.25|14 / 639.3 / 208.4 / 173.3 / 4.25|
|ishikawa|14 / 498.4 / 160.8 / 135.8 / 4.02|14 / 498.4 / 160.8 / 135.8 / 4.02|13 / 628.8 / 203.1 / 168.1 / 4.65|13 / 628.8 / 203.1 / 168.1 / 4.64|13 / 622.4 / 201.1 / 166.7 / 4.73|13 / 622.4 / 201.1 / 166.7 / 4.73|
|block|17 / 646.6 / 211.0 / 179.9 / 4.10|17 / 646.6 / 211.0 / 179.9 / 4.10|18 / 802.5 / 261.3 / 219.1 / 4.61|18 / 802.5 / 261.3 / 219.1 / 4.61|18 / 796.1 / 259.3 / 217.7 / 4.70|18 / 796.1 / 259.3 / 217.7 / 4.69|
|eventmodeling|12 / 505.5 / 162.8 / 137.6 / 4.17|12 / 505.5 / 162.8 / 137.6 / 4.17|11 / 635.9 / 205.1 / 169.9 / 4.78|11 / 635.9 / 205.1 / 169.9 / 4.78|11 / 629.5 / 203.1 / 168.5 / 4.85|11 / 629.5 / 203.1 / 168.5 / 4.86|
|zenuml|15 / 580.7 / 186.9 / 159.3 / 4.18|15 / 580.7 / 186.9 / 159.3 / 4.18|14 / 711.1 / 229.2 / 191.6 / 4.81|14 / 711.1 / 229.2 / 191.6 / 4.81|14 / 704.7 / 227.2 / 190.2 / 4.89|14 / 704.7 / 227.2 / 190.2 / 4.89|
|railroad|14 / 513.6 / 165.8 / 140.2 / 3.85|14 / 513.6 / 165.8 / 140.2 / 3.85|13 / 644.0 / 208.1 / 172.6 / 4.26|13 / 644.0 / 208.1 / 172.6 / 4.26|13 / 637.6 / 206.1 / 171.2 / 4.31|13 / 637.6 / 206.1 / 171.2 / 4.31|
|cynefin|14 / 501.7 / 162.1 / 136.9 / 4.07|14 / 501.7 / 162.1 / 136.9 / 4.07|13 / 632.1 / 204.4 / 169.3 / 4.51|13 / 632.1 / 204.4 / 169.3 / 4.50|13 / 625.7 / 202.4 / 167.8 / 4.56|13 / 625.7 / 202.4 / 167.8 / 4.57|
|agentflow|31 / 1092.1 / 361.0 / 311.2 / 5.38|27 / 2337.7 / 722.5 / 575.8 / 10.53|40 / 1280.3 / 424.2 / 363.0 / 6.04|30 / 2497.3 / 774.3 / 616.8 / 11.13|40 / 1296.2 / 429.1 / 367.4 / 6.12|30 / 2513.1 / 779.2 / 621.2 / 11.21|
|usecase|26 / 951.9 / 314.6 / 269.4 / 4.85|23 / 2197.8 / 676.3 / 534.2 / 9.89|35 / 1139.2 / 377.4 / 321.1 / 5.45|26 / 2356.5 / 727.8 / 575.0 / 10.43|35 / 1132.8 / 375.4 / 319.5 / 5.54|26 / 2350.1 / 725.7 / 573.5 / 10.52|
|wardley|15 / 529.3 / 171.0 / 144.9 / 4.14|15 / 529.3 / 171.0 / 144.9 / 4.14|15 / 659.9 / 213.6 / 177.6 / 4.65|15 / 659.9 / 213.6 / 177.6 / 4.65|15 / 653.5 / 211.6 / 176.1 / 4.71|15 / 653.5 / 211.6 / 176.1 / 4.71|
|venn|13 / 510.5 / 165.5 / 140.0 / 3.73|13 / 510.5 / 165.5 / 140.0 / 3.73|12 / 640.9 / 207.9 / 172.4 / 4.12|12 / 640.9 / 207.9 / 172.4 / 4.12|12 / 634.5 / 205.9 / 171.0 / 4.17|12 / 634.5 / 205.9 / 171.0 / 4.17|
|swimlane|29 / 991.7 / 329.1 / 282.7 / 4.90|29 / 991.7 / 329.1 / 282.7 / 4.89|38 / 1180.8 / 392.6 / 334.9 / 5.53|38 / 1180.8 / 392.6 / 334.9 / 5.53|38 / 1174.4 / 390.6 / 333.3 / 5.61|38 / 1174.4 / 390.6 / 333.3 / 5.61|
|treeview|15 / 506.2 / 164.3 / 138.8 / 3.71|15 / 506.2 / 164.3 / 138.8 / 3.71|14 / 636.6 / 206.6 / 171.2 / 4.10|14 / 636.6 / 206.6 / 171.2 / 4.10|14 / 630.2 / 204.6 / 169.7 / 4.14|14 / 630.2 / 204.6 / 169.7 / 4.14|

Against PR599,32/33 family closures per arm shrink around6.55KB raw/2.07KB gzip/1.48KB Brotli. Agentflow grows: Native+16239raw/+5038gzip/+4487Brotli; ELK+16249/+5038/+4555. All request counts are unchanged. This net combined result includes the later safety/producer code; it is smaller than the isolated provider saving.

Against Main426,all33closures on both arms remain larger: median+126991raw/+41277gzip/+31680Brotli bytes. Flowchart remains+62582gzip Native/+50947gzip ELK and+9/+3requests. Existing Native-versus-ELK byte advantage predates this change.

Heap is adverse against PR599 in all33families on both arms: median+55092B Native/+58628B ELK. Forced-GC JavaScript heap excludes native/WASM/process memory; no leak or runtime-speed inference is made. Browser observer transport sits inside clocks, so collected raw timing samples are not API cost evidence.

Against Main,124/132SVGs are equal; ER and Requirement support/enrolled SVGs differ on both arms. All132proof statuses/layout decisions remain the same. The separate authored/actual-ink qualification owns their meaning.

Identity: unchanged artifactIdentity(resolveArtifact) ran on an explicit compiled package view with121 actual frozen-dist hardlinks; every file byte,entry and installed dependency closure was checked before rebinding runtime identity to frozen621. No fake Git marker or source-primary rendering. The identity view is compiled inventory, not npm payload. CASES and retained baseline results hashes are checked and retained in IDENTITY.json; actual browser manifests/helper identities are in each ARTIFACT.json and DELIVERY.json.

Files: FAMILY-PAYLOAD.csv actual66product closures;NET-COMPARISON.csv all132baseline/arm/family deltas;SUMMARY.json includes all unknown proofs, hash identities and adverse ranges;per-lane fully serialized products, receipts and fetched-module manifests remain retained. Main426/PR599 were not replayed.
