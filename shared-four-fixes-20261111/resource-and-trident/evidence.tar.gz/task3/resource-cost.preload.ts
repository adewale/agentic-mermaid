import {readFileSync} from 'node:fs'
const totals:Record<string,{calls:number;costs:number[]}>={}
const probeKey=Symbol.for('pr449.resource.cost.probe')
;(globalThis as any)[probeKey]=totals
process.on('beforeExit',()=>console.error(JSON.stringify({diagnostic:'RESOURCE-ONLY-COST-ATTRIBUTION',unsafeProofOnly:process.env.AM_RESOURCE_PROOF_ONLY==='1',totals:Object.fromEntries(Object.entries(totals).map(([name,row])=>[name,{calls:row.calls,total:row.costs.reduce((a,b)=>a+b,0),first:row.costs[0],costs:row.costs}]))})))
Bun.plugin({name:'resource-cost-only',setup(build){build.onLoad({filter:/\/src\/scene\/paint-certification\.ts$/},args=>{
 let code=readFileSync(args.path,'utf8')
 if(process.env.AM_RESOURCE_PROOF_ONLY==='1') code=code.replace('operations = (emissionWork?.operations ?? 0) + (sceneWriteWork?.operations ?? 0)','operations = 0')
 for(const name of ['markerPaintIdentity','markerMayHaveOpaqueFill','stablePathMarker']){
  const start=code.indexOf(`function ${name}(`),body=code.indexOf(' {\n',start)+3
  if(start<0||body<3)throw Error('Missing diagnostic owner '+name)
  code=code.slice(0,body)+`\n const __stats = (globalThis as any)[Symbol.for('pr449.resource.cost.probe')]; const __row = __stats['${name}'] ??= {calls:0,costs:[]}; const __index=__row.calls++; __row.costs[__index]=0; const __work=work; work=()=>{__row.costs[__index]++;return __work()};\n`+code.slice(body)
 }
 return {contents:code,loader:'ts'}
})}})
