import {readFileSync} from 'node:fs'
const {renderMermaidSVGWithReceipt}=await import('/tmp/pr449-main-integration-20261029-762/src/index.ts')
const cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-main-20261110/MEASUREMENT-CASES.json','utf8'))
const source=cases.find((c:any)=>c.id==='diagnostic:chain100').source
const result=renderMermaidSVGWithReceipt(source,{graphLayout:{backend:'agentic',fallback:'none'}})
console.log(JSON.stringify({diagnostic:'completed downstream cost, not delivery qualification',proof:result.receipt.layoutCertification}))
