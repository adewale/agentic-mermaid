/**
 * Tests for the SVG renderer.
 *
 * Uses hand-crafted PositionedGraph data to test SVG output without
 * depending on the layout engine.
 */
import { describe, it, expect } from 'bun:test'
import { renderSvg as renderSvgWithContext } from '../renderer.ts'
import type { DiagramColors } from '../theme.ts'
import type { PositionedGraph, PositionedNode, PositionedEdge, PositionedGroup, RenderOptions } from '../types.ts'

function renderSvg(
  positioned: PositionedGraph,
  colors: DiagramColors,
  font = 'Inter',
  transparent = false,
  options: RenderOptions = {},
): string {
  return renderSvgWithContext({
    positioned,
    colors: { ...colors, font },
    resolved: { renderOptions: { ...options, transparent } },
  })
}

/** Minimal positioned graph for testing */
function makeGraph(overrides: Partial<PositionedGraph> = {}): PositionedGraph {
  return {
    width: 400,
    height: 300,
    nodes: [],
    edges: [],
    groups: [],
    ...overrides,
  }
}

/** Helper to build a positioned node */
function makeNode(overrides: Partial<PositionedNode> = {}): PositionedNode {
  return {
    id: 'A',
    label: 'Test',
    shape: 'rectangle',
    x: 100,
    y: 100,
    width: 80,
    height: 40,
    ...overrides,
  }
}

/** Helper to build a positioned edge with arrow defaults */
function makeEdge(overrides: Partial<PositionedEdge> = {}): PositionedEdge {
  return {
    source: 'A',
    target: 'B',
    style: 'solid',
    hasArrowStart: false,
    hasArrowEnd: true,
    points: [{ x: 100, y: 120 }, { x: 100, y: 200 }],
    ...overrides,
  }
}

/** Default light colors — CSS custom properties handle actual styling */
const lightColors: DiagramColors = { bg: '#FFFFFF', fg: '#27272A' }
const darkColors: DiagramColors = { bg: '#18181B', fg: '#FAFAFA' }

// ============================================================================
// SVG structure
// ============================================================================

describe('renderSvg – SVG structure', () => {
  it('produces a valid SVG root element', () => {
    const svg = renderSvg(makeGraph(), lightColors)
    expect(svg).toContain('<svg xmlns="http://www.w3.org/2000/svg"')
    expect(svg).toContain('viewBox="0 0 400 300"')
    expect(svg).toContain('width="400"')
    expect(svg).toContain('height="300"')
    expect(svg).toContain('</svg>')
  })

  it('includes <defs> with arrow markers', () => {
    const svg = renderSvg(makeGraph(), lightColors)
    expect(svg).toContain('<defs>')
    expect(svg).toContain('<marker id="arrowhead"')
    expect(svg).toContain('<marker id="arrowhead-start"')
    expect(svg).toContain('</defs>')
  })

  it('does not embed a Google Fonts import by default', () => {
    const svg = renderSvg(makeGraph(), lightColors, 'Inter')
    expect(svg).not.toContain('fonts.googleapis.com')
    expect(svg).toContain('--font:Inter')
  })

  it('uses custom font name when specified', () => {
    const svg = renderSvg(makeGraph(), lightColors, 'Roboto Mono')
    expect(svg).toContain('--font:Roboto Mono')
    expect(svg).toContain("'Roboto Mono'")
  })

  it('sets CSS color variables in inline style', () => {
    const light = renderSvg(makeGraph(), lightColors)
    expect(light).toContain('--bg:#FFFFFF')
    expect(light).toContain('--fg:#27272A')

    const dark = renderSvg(makeGraph(), darkColors)
    expect(dark).toContain('--bg:#18181B')
    expect(dark).toContain('--fg:#FAFAFA')
  })
})

// ============================================================================
// Original node shapes
// ============================================================================

describe('renderSvg – node shapes', () => {
  it('renders rectangle with rx=0', () => {
    const graph = makeGraph({ nodes: [makeNode({ shape: 'rectangle' })] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('rx="0" ry="0"')
  })

  it('renders rounded rectangle with rx=6', () => {
    const graph = makeGraph({ nodes: [makeNode({ shape: 'rounded' })] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('rx="6" ry="6"')
  })

  it('renders stadium with rx=height/2', () => {
    const node = makeNode({ shape: 'stadium', height: 40 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('rx="20" ry="20"')
  })

  it('renders circle with <circle> element', () => {
    const node = makeNode({ shape: 'circle', width: 60, height: 60 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('<circle')
    expect(svg).toContain('r="30"')
  })

  it('renders diamond with <polygon>', () => {
    const node = makeNode({ shape: 'diamond', width: 80, height: 80 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('<polygon')
    expect(svg).toContain('points="140,100 180,140 140,180 100,140"')
  })

  it('strips invalid CSS identifier characters from node class names', () => {
    // Parse and typed ops refuse such names (renderer-css-classes.test.ts); a
    // positioned graph built directly still cannot inject into the attribute.
    const graph = makeGraph({ nodes: [makeNode({ classNames: ['my.class', 'a/b', 'x"y', '.'] })] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('class="node myclass ab xy"')
  })

  it('renders node labels as <text> elements', () => {
    const graph = makeGraph({ nodes: [makeNode({ label: 'My Node' })] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('>My Node</text>')
  })
})

// ============================================================================
// New Batch 1 shapes
// ============================================================================

describe('renderSvg – new shapes (Batch 1)', () => {
  it('renders subroutine with outer rect and inset vertical lines', () => {
    const node = makeNode({ shape: 'subroutine', width: 100, height: 40 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    // Outer rect
    expect(svg).toContain('<rect x="100" y="100" width="100" height="40"')
    // Left inset line at x=108 (100+8)
    expect(svg).toContain('x1="108"')
    // Right inset line at x=192 (100+100-8)
    expect(svg).toContain('x1="192"')
    expect(svg).toContain('<line')
  })

  it('renders double circle with two <circle> elements', () => {
    const node = makeNode({ shape: 'doublecircle', width: 80, height: 80 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    const circleMatches = svg.match(/<circle/g) ?? []
    expect(circleMatches.length).toBe(2)
    // Outer radius: min(80,80)/2 = 40, inner = 35
    expect(svg).toContain('r="40"')
    expect(svg).toContain('r="35"')
  })

  it('renders hexagon with 6-point <polygon>', () => {
    const node = makeNode({ shape: 'hexagon', width: 100, height: 40 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    // Select the node's own polygon: the first `points=` in the document is the
    // arrowhead marker in <defs>, whose "0 0, 8 2.5, 0 5" also splits into 6 tokens.
    const nodePolygon = svg.match(/<polygon points="([^"]+)"[^>]*data-id="node-shape:A"/)
    // Flat sides inset by h/4 = 10; the pointed vertices sit at mid-height (y = 100 + 40/2).
    expect(nodePolygon?.[1]).toBe('110,100 190,100 200,120 190,140 110,140 100,120')
  })
})

// ============================================================================
// New Batch 2 shapes
// ============================================================================

describe('renderSvg – new shapes (Batch 2)', () => {
  it('renders cylinder with ellipses and body rect', () => {
    const node = makeNode({ shape: 'cylinder', width: 80, height: 50 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    // Should contain ellipses for top and bottom caps
    const ellipseMatches = svg.match(/<ellipse/g) ?? []
    expect(ellipseMatches.length).toBe(2)
    // Body rect
    expect(svg).toContain('<rect')
  })

  it('renders asymmetric / flag with 5-point <polygon>', () => {
    const node = makeNode({ shape: 'asymmetric', width: 100, height: 40 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    const polygon = [...svg.matchAll(/<polygon\b[^>]*>/g)].find(match => match[0].includes('data-id="node-shape:A"'))?.[0]
    expect(polygon).toBeDefined()
    expect(polygon!.match(/\bpoints="([^"]+)"/)?.[1]).toBe('112,100 200,100 200,140 112,140 100,120')
  })

  it('renders trapezoid with 4-point <polygon>', () => {
    const node = makeNode({ shape: 'trapezoid', width: 100, height: 40 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    const polygon = [...svg.matchAll(/<polygon\b[^>]*>/g)].find(match => match[0].includes('data-id="node-shape:A"'))?.[0]
    expect(polygon).toBeDefined()
    expect(polygon!.match(/\bpoints="([^"]+)"/)?.[1]).toBe('115,100 185,100 200,140 100,140')
  })

  it('renders trapezoid-alt with 4-point <polygon>', () => {
    const node = makeNode({ shape: 'trapezoid-alt', width: 100, height: 40 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    const polygon = [...svg.matchAll(/<polygon\b[^>]*>/g)].find(match => match[0].includes('data-id="node-shape:A"'))?.[0]
    expect(polygon).toBeDefined()
    expect(polygon!.match(/\bpoints="([^"]+)"/)?.[1]).toBe('100,100 200,100 185,140 115,140')
  })
})

// ============================================================================
// Batch 3: State diagram pseudostates
// ============================================================================

describe('renderSvg – state pseudostates', () => {
  it('renders state-start as a filled circle', () => {
    const node = makeNode({ shape: 'state-start', label: '', width: 28, height: 28 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('<circle')
    expect(svg).toContain('fill="var(--_text)"')
    expect(svg).toContain('stroke="none"')
  })

  it('renders state-end as bullseye (two circles)', () => {
    const node = makeNode({ shape: 'state-end', label: '', width: 28, height: 28 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    const circleMatches = svg.match(/<circle/g) ?? []
    expect(circleMatches.length).toBe(2)
    // Outer is stroked, inner is filled
    expect(svg).toContain('fill="none"')
    expect(svg).toContain('fill="var(--_text)"')
  })
})

// ============================================================================
// Edge rendering
// ============================================================================

describe('renderSvg – edges', () => {
  it('renders a solid edge as <polyline> with end arrow', () => {
    const edge = makeEdge({ style: 'solid', hasArrowEnd: true })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('<polyline')
    expect(svg).toContain('points="100,120 100,200"')
    expect(svg).toContain('marker-end="url(#arrowhead)"')
  })

  it('renders dotted edges with stroke-dasharray', () => {
    const edge = makeEdge({ style: 'dotted' })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('stroke-dasharray="4 4"')
  })

  it('renders thick edges with doubled stroke width', () => {
    const edge = makeEdge({ style: 'thick' })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    // Base connector stroke is 1px, thick is doubled to 2px.
    expect(svg).toContain('stroke-width="2"')
  })

  it('does not add dasharray to solid edges', () => {
    const edge = makeEdge({ style: 'solid' })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).not.toContain('dasharray')
  })

  it('skips edges with fewer than 2 points', () => {
    const edge = makeEdge({ points: [{ x: 0, y: 0 }] })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).not.toContain('<polyline')
  })

  it('renders no-arrow edge without marker-end', () => {
    const edge = makeEdge({ hasArrowEnd: false, hasArrowStart: false })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('<polyline')
    expect(svg).not.toContain('marker-end')
    expect(svg).not.toContain('marker-start')
  })

  it('renders bidirectional edge with both markers', () => {
    const edge = makeEdge({ hasArrowStart: true, hasArrowEnd: true })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('marker-end="url(#arrowhead)"')
    expect(svg).toContain('marker-start="url(#arrowhead-start)"')
  })

  it('renders circle and cross endpoint marker families only when needed', () => {
    const graph = makeGraph({
      edges: [
        makeEdge({ hasArrowStart: true, hasArrowEnd: true, startMarker: 'circle', endMarker: 'cross' }),
      ],
    })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('<marker id="circlehead"')
    expect(svg).toContain('<marker id="crosshead"')
    expect(svg).toContain('marker-start="url(#circlehead-start)"')
    expect(svg).toContain('marker-end="url(#crosshead)"')
    expect(svg).toContain('data-marker-start="circle"')
    expect(svg).toContain('data-marker-end="cross"')
  })

  it('uses custom-stroke circle/cross marker defs when linkStyle changes edge color', () => {
    const graph = makeGraph({
      edges: [makeEdge({ hasArrowEnd: true, endMarker: 'circle', inlineStyle: { stroke: '#ff0000' } })],
    })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('<marker id="circlehead-23ff0000"')
    expect(svg).toContain('marker-end="url(#circlehead-23ff0000)"')
    expect(svg).toContain('stroke="#ff0000"')
  })

  it('does not emit circle/cross marker defs for ordinary arrows', () => {
    const svg = renderSvg(makeGraph({ edges: [makeEdge()] }), lightColors)
    expect(svg).not.toContain('<marker id="circlehead"')
    expect(svg).not.toContain('<marker id="crosshead"')
  })

  it.each([0, 6])('keeps heterogeneous edge identities, labels and markers isolated at bend radius %s', bendRadius => {
    const rows: { edge: Partial<PositionedEdge>; identity: string; start?: string; end?: string; label?: string }[] = [
      { edge: { hasArrowEnd: false }, identity: 'edge:A-&gt;B#0' },
      { edge: { id: 'named', hasArrowEnd: false }, identity: 'named' },
      { edge: { label: '雪 & first', hasArrowEnd: false }, identity: 'edge:A-&gt;B#2', label: '雪 &amp; first' },
      { edge: { hasArrowStart: true, hasArrowEnd: false }, identity: 'edge:A-&gt;B#3', start: 'arrowhead-start' },
      { edge: {}, identity: 'edge:A-&gt;B#4', end: 'arrowhead' },
      { edge: { id: 'both', label: 'both', hasArrowStart: true }, identity: 'both', start: 'arrowhead-start', end: 'arrowhead', label: 'both' },
      { edge: { id: 'decorated', label: 'private', hasArrowStart: true, classNames: ['hot!'], curve: 'basis', animate: true, animation: 'fast' }, identity: 'decorated', start: 'arrowhead-start', end: 'arrowhead', label: 'private' },
      { edge: { id: 'other', label: 'Ω < second', hasArrowStart: true, startMarker: 'circle', endMarker: 'cross', style: 'dotted', inlineStyle: { stroke: '#ff0000', 'stroke-width': '3px' } }, identity: 'other', start: 'circlehead-start-23ff0000-fixed', end: 'crosshead-23ff0000-fixed', label: 'Ω &lt; second' },
      { edge: { hasArrowEnd: false, animate: false, classNames: ['!'] }, identity: 'edge:A-&gt;B#8' },
    ]
    const svg = renderSvgWithContext({
      positioned: makeGraph({ height: 1200, edges: rows.map(({ edge }, index) => makeEdge({
        ...edge,
        points: [{ x: 20, y: 40 + index * 100 }, { x: 180, y: 40 + index * 100 }, { x: 180, y: 80 + index * 100 }],
        labelPosition: { x: 100, y: 20 + index * 100 },
      })) }),
      colors: lightColors,
      resolved: { renderOptions: {}, styleFace: { edge: { bendRadius } } },
    })
    const lines = [...svg.matchAll(/<(?:polyline|path)\b[^>]*class="edge(?: hot)?"[^>]*>/g)].map(match => match[0])
    expect(lines).toHaveLength(rows.length)
    for (const [index, row] of rows.entries()) {
      const line = lines[index]!
      expect(line).toContain(`data-id="${row.identity}"`)
      expect(line).toContain('data-from="A" data-to="B"')
      expect(line).toContain(`data-arrow-start="${!!row.start}" data-arrow-end="${!!row.end}"`)
      for (const [position, marker] of [['start', row.start], ['end', row.end]] as const) {
        if (marker) {
          expect(line).toContain(`marker-${position}="url(#${marker})"`)
          const shape = position === 'start' ? row.edge.startMarker ?? 'arrow' : row.edge.endMarker ?? 'arrow'
          expect(line).toContain(`data-marker-${position}="${shape}"`)
        } else expect(line).not.toContain(`marker-${position}=`)
      }
      if (row.label) expect(line).toContain(`data-label="${row.label}"`)
      else expect(line).not.toContain('data-label=')
      expect(line).toStartWith(`<${bendRadius || index === 6 ? 'path' : 'polyline'} `)
      if (index !== 6) {
        expect(line).not.toContain('data-curve=')
        expect(line).not.toContain('data-animate=')
        expect(line).not.toContain(' hot')
      }
    }
    expect(lines[6]).toContain('data-curve="basis" data-animate="true" data-animation="fast"')
    expect(lines[7]).toContain('data-style="dotted"')
    expect(lines[7]).toContain('stroke="#ff0000" stroke-width="3px" stroke-dasharray="4 4"')
    expect(lines[8]).toContain('data-style="solid"')
    expect(lines[8]).not.toContain('stroke-dasharray=')
    expect(svg).toMatch(/>雪 &amp; first<\/(?:text|tspan)>/)
    expect(svg).toMatch(/>Ω &lt; second<\/(?:text|tspan)>/)
  })
})

// ============================================================================
// Edge labels
// ============================================================================

describe('renderSvg – edge labels', () => {
  it('uses a finite label midpoint for a zero-length route with repeated points', () => {
    const edge = makeEdge({ label: 'Stay', points: [{ x: 100, y: 120 }, { x: 100, y: 120 }] })
    const svg = renderSvg(makeGraph({ edges: [edge] }), lightColors)
    expect(svg).toContain('x="100" y="120"')
    expect(svg).toContain('>Stay</text>')
    expect(svg).not.toMatch(/NaN|Infinity/)
  })

  it('renders edge label with background pill', () => {
    const edge = makeEdge({ label: 'Yes' })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('>Yes</text>')
    expect(svg).toContain('rx="2" ry="2"')
    expect(svg).toContain('class="edge-label-halo"')
    expect(svg.indexOf('class="edge-label-halo"')).toBeLessThan(svg.indexOf('>Yes</text>'))
  })

  it('does not render label elements for edges without labels', () => {
    const edge = makeEdge({ label: undefined })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    const textMatches = svg.match(/<text[^>]*>.*?<\/text>/g) ?? []
    expect(textMatches).toHaveLength(0)
  })

  it('uses labelPosition when provided instead of edge midpoint', () => {
    // Edge midpoint would be at (100, 160) given these points.
    // labelPosition overrides to (50, 80) — verify the SVG uses that coordinate.
    const edge = makeEdge({
      label: 'Go',
      points: [{ x: 100, y: 120 }, { x: 100, y: 200 }],
      labelPosition: { x: 50, y: 80 },
    })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)

    // The label text should be centered at the labelPosition (x=50, y=80)
    expect(svg).toContain('x="50" y="80"')
    // The midpoint y=160 should NOT appear in any label-related element
    expect(svg).not.toContain('y="160"')
  })
})

// ============================================================================
// Group rendering (subgraphs)
// ============================================================================

describe('renderSvg – groups', () => {
  it('renders group with outer rectangle and header band', () => {
    const group: PositionedGroup = {
      id: 'sg1', label: 'Backend',
      x: 20, y: 20, width: 200, height: 150, children: [],
    }
    const graph = makeGraph({ groups: [group] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('<rect x="20" y="20" width="200" height="150"')
    expect(svg).toContain('<path d="M20,20 H220 V48 H20 Z" fill="var(--_group-hdr)"')
    expect(svg).toContain('>Backend</text>')
  })

  it('renders nested groups recursively', () => {
    const inner: PositionedGroup = {
      id: 'inner', label: 'Inner',
      x: 40, y: 60, width: 120, height: 80, children: [],
    }
    const outer: PositionedGroup = {
      id: 'outer', label: 'Outer',
      x: 20, y: 20, width: 200, height: 150, children: [inner],
    }
    const graph = makeGraph({ groups: [outer] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('>Outer</text>')
    expect(svg).toContain('>Inner</text>')
  })
})

// ============================================================================
// Inline style support
// ============================================================================

describe('renderSvg – inline styles', () => {
  it('applies inline fill override', () => {
    const node = makeNode({ inlineStyle: { fill: '#ff0000' } })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('fill="#ff0000"')
  })

  it('applies inline stroke override', () => {
    const node = makeNode({ inlineStyle: { stroke: '#00ff00' } })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('stroke="#00ff00"')
  })

  it('applies inline text color override', () => {
    const node = makeNode({ inlineStyle: { color: '#0000ff' } })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('fill="#0000ff"')
  })

  it('auto-selects readable text for concrete custom fills without explicit color', () => {
    const lightFill = renderSvg(makeGraph({ nodes: [makeNode({ inlineStyle: { fill: '#FFFACD' } })] }), darkColors)
    expect(lightFill).toContain('fill="#000000"')

    const darkFill = renderSvg(makeGraph({ nodes: [makeNode({ inlineStyle: { fill: 'rgb(20, 20, 30)' } })] }), lightColors)
    expect(darkFill).toContain('fill="#FFFFFF"')
  })

  it('does not auto-contrast unresolved CSS variable fills', () => {
    const node = makeNode({ inlineStyle: { fill: 'var(--custom-fill)' } })
    const svg = renderSvg(makeGraph({ nodes: [node] }), darkColors)
    expect(svg).toContain('fill="var(--_text)"')
  })

  it('falls back to theme when no inline style', () => {
    const node = makeNode()
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('fill="var(--_node-fill)"')
  })
})

// ============================================================================
// XML escaping
// ============================================================================

describe('renderSvg – XML escaping', () => {
  it('escapes special characters in node labels', () => {
    const node = makeNode({ label: '<script> & "quotes" \'apos\'' })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('&lt;script&gt;')
    expect(svg).toContain('&amp;')
    expect(svg).toContain('&quot;quotes&quot;')
    expect(svg).toContain('&#39;apos&#39;')
  })

  it('escapes special characters in edge labels', () => {
    const edge = makeEdge({ label: 'A & B > C' })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('A &amp; B &gt; C')
  })

  it('escapes special characters in group labels', () => {
    const group: PositionedGroup = {
      id: 'g1', label: 'A < B',
      x: 0, y: 0, width: 100, height: 100, children: [],
    }
    const graph = makeGraph({ groups: [group] })
    const svg = renderSvg(graph, lightColors)
    expect(svg).toContain('A &lt; B')
  })
})

// ============================================================================
// Security: inline style injection prevention
// ============================================================================

describe('renderSvg – inline style XSS prevention', () => {
  it('rejects attribute injection in inline style fill', () => {
    const node = makeNode({ inlineStyle: { fill: 'red" onmouseover="alert(1)' } })
    const graph = makeGraph({ nodes: [node] })
    expect(() => renderSvg(graph, lightColors)).toThrow(/safe non-fetching CSS paint/)
  })

  it('rejects element injection in inline style fill', () => {
    const node = makeNode({ inlineStyle: { fill: 'red"/><svg onload="alert(1)"><rect fill="x' } })
    const graph = makeGraph({ nodes: [node] })
    expect(() => renderSvg(graph, lightColors)).toThrow(/safe non-fetching CSS paint/)
  })

  it('rejects injection in inline style stroke', () => {
    const node = makeNode({ inlineStyle: { stroke: 'blue" onclick="alert(1)' } })
    const graph = makeGraph({ nodes: [node] })
    expect(() => renderSvg(graph, lightColors)).toThrow(/safe non-fetching CSS paint/)
  })

  it('rejects injection in inline style stroke-width', () => {
    const node = makeNode({ inlineStyle: { 'stroke-width': '2" onmouseover="alert(1)' } })
    const graph = makeGraph({ nodes: [node] })
    expect(() => renderSvg(graph, lightColors)).toThrow(/finite number or safe numeric custom-property reference/)
  })

  it('rejects injection in inline style color', () => {
    const node = makeNode({ inlineStyle: { color: 'green" onfocus="alert(1)' } })
    const graph = makeGraph({ nodes: [node] })
    expect(() => renderSvg(graph, lightColors)).toThrow(/safe non-fetching CSS paint/)
  })
})

// ============================================================================
// Theme application
// ============================================================================

describe('renderSvg – CSS variable theming', () => {
  it('uses CSS variables for styling (light colors)', () => {
    const node = makeNode()
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    // SVG uses CSS custom property references, not hardcoded colors
    expect(svg).toContain('var(--_node-fill)')
    expect(svg).toContain('var(--_node-stroke)')
    expect(svg).toContain('var(--_text)')
  })

  it('uses same CSS variables with dark colors', () => {
    const node = makeNode()
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, darkColors)
    // Same CSS variable structure — colors differ via --bg/--fg on the SVG tag
    expect(svg).toContain('var(--_node-fill)')
    expect(svg).toContain('var(--_node-stroke)')
    expect(svg).toContain('var(--_text)')
    expect(svg).toContain('--bg:#18181B')
  })

  it('arrow marker uses CSS variable for fill', () => {
    const svg = renderSvg(makeGraph(), lightColors)
    expect(svg).toContain('fill="var(--_arrow)"')
  })
})

// ============================================================================
// Sad paths / degenerate inputs
// ============================================================================

describe('renderSvg – sad paths / degenerate inputs', () => {
  it('empty node/edge arrays produce valid SVG (no crash)', () => {
    const graph = makeGraph({ nodes: [], edges: [], groups: [] })
    const svg = renderSvg(graph, lightColors)
    // Must still be a well-formed SVG document
    expect(svg).toContain('<svg xmlns="http://www.w3.org/2000/svg"')
    expect(svg).toContain('</svg>')
    // No node, edge, or group elements should be present
    expect(svg).not.toContain('<polyline')
    expect(svg).not.toContain('class="node"')
    expect(svg).not.toContain('class="subgraph"')
  })

  it('edges referencing nonexistent nodes render with orphan IDs', () => {
    const edge = makeEdge({
      source: 'MISSING_SRC',
      target: 'MISSING_TGT',
      points: [{ x: 10, y: 20 }, { x: 30, y: 40 }],
    })
    const graph = makeGraph({ nodes: [], edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    // Edge should still render as a polyline — renderer doesn't validate references
    expect(svg).toContain('<polyline')
    expect(svg).toContain('data-from="MISSING_SRC"')
    expect(svg).toContain('data-to="MISSING_TGT"')
    // No node elements since we gave none
    expect(svg).not.toContain('class="node"')
  })

  it('zero-dimension nodes (width: 0, height: 0) produce valid SVG', () => {
    const node = makeNode({ width: 0, height: 0 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    // Must still produce a complete SVG document
    expect(svg).toContain('<svg xmlns="http://www.w3.org/2000/svg"')
    expect(svg).toContain('</svg>')
    // Node wrapper should exist with the degenerate dimensions
    expect(svg).toContain('class="node"')
    expect(svg).toContain('width="0"')
    expect(svg).toContain('height="0"')
  })

  it('nodes with very long labels (1000+ chars) render without truncation', () => {
    const longLabel = 'A'.repeat(1200)
    const node = makeNode({ label: longLabel })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    // The full label must appear in the SVG (no truncation)
    expect(svg).toContain(longLabel)
    // Node wrapper must have the label in data-label attribute
    expect(svg).toContain(`data-label="${longLabel}"`)
    // The SVG must still be well-formed
    expect(svg).toContain('</svg>')
  })

  it('edges with empty points array (0 points) are skipped', () => {
    const edge = makeEdge({ points: [] })
    const graph = makeGraph({ edges: [edge] })
    const svg = renderSvg(graph, lightColors)
    // renderEdge returns '' for < 2 points, so no polyline
    expect(svg).not.toContain('<polyline')
    // Edge label should also not render since edge has no label by default
    expect(svg).not.toContain('class="edge-label"')
    // SVG document must still be valid
    expect(svg).toContain('</svg>')
  })

  it('groups with zero dimensions produce valid SVG', () => {
    const group: PositionedGroup = {
      id: 'zero', label: 'Empty',
      x: 50, y: 50, width: 0, height: 0, children: [],
    }
    const graph = makeGraph({ groups: [group] })
    const svg = renderSvg(graph, lightColors)
    // Group should still render
    expect(svg).toContain('class="subgraph"')
    expect(svg).toContain('data-id="zero"')
    expect(svg).toContain('>Empty</text>')
    // Degenerate rect dimensions should appear
    expect(svg).toContain('width="0" height="0"')
  })

  it('nodes with negative coordinates render at those positions', () => {
    const node = makeNode({ x: -100, y: -50, width: 80, height: 40 })
    const graph = makeGraph({ nodes: [node] })
    const svg = renderSvg(graph, lightColors)
    // The negative coordinates must appear in the SVG element attributes
    expect(svg).toContain('x="-100"')
    expect(svg).toContain('y="-50"')
    // Node wrapper must still exist
    expect(svg).toContain('class="node"')
    // The SVG must still close properly
    expect(svg).toContain('</svg>')
  })
})
