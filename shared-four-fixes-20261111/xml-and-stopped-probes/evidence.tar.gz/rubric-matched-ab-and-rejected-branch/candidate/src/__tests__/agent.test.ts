// Core agent surface: parse, serialize, mutate (flowchart + sequence),
// verify, round-trip, sequence fidelity fallback, synthesizeFromGraph, Finite.

import { describe, expect, test } from 'bun:test'
import fc from 'fast-check'
import { fcParameters } from './helpers/fc-parameters.ts'
import { mutate, mutatePreservingSource } from '../agent/mutate.ts'
import { parseMermaid as parseNativeFlowchart } from '../parser.ts'
import { normalizeMermaidSource, normalizeMermaidRenderSource } from '../mermaid-source.ts'
import { renderMermaidSVG, renderMermaidASCII } from '../index.ts'
import { parseRegisteredMermaid as parseMermaid } from '../agent/parse.ts'
import { serializeMermaid, synthesizeFromGraph } from '../agent/serialize.ts'
import type { FlowchartMutationOp, FlowchartValidDiagram, SequenceValidDiagram } from '../agent/types.ts'
import { asFlowchart, asSequence, asState, toFinite, WARNING_TIER } from '../agent/types.ts'
import { graphGeometryWarnings, verifyMermaid } from '../agent/verify.ts'
import { positionFamilyArtifact } from '../agent/family-layouts.ts'
import type { PositionedGraph } from '../types.ts'

function parse(src: string) {
  const r = parseMermaid(src)
  if (!r.ok) throw new Error('parse: ' + JSON.stringify(r.error))
  return r.value
}
function flowchart(src: string): FlowchartValidDiagram {
  const f = asFlowchart(parse(src))
  if (!f) throw new Error('not flowchart')
  return f
}
function sequence(src: string): SequenceValidDiagram {
  const s = asSequence(parse(src))
  if (!s) throw new Error('not sequence')
  return s
}

describe('explicit source-preserving Flowchart labels', () => {
  const style = 'classDef exClass background:#bbb,border:1px s:::colid red;'
  const retained = `graph TD\n   \n      A[ h ] -- hello --> B[" test "]:::exClass & C --> D;\n      ${style}`
  test('edits a native node while retaining the exact unsupported classDef and original bytes', () => {
    const diagram = parse(retained)
    expect(diagram.body.kind).toBe('opaque')
    expect(mutate(diagram, { kind: 'set_label', target: 'A', label: 'Changed' }).ok).toBe(false)
    const edited = mutatePreservingSource(diagram, { kind: 'set_label', target: 'A', label: 'Changed' })
    expect(edited.ok).toBe(true)
    if (!edited.ok) throw new Error(edited.error.message)
    expect(edited.value.source.startsWith(retained)).toBe(true)
    expect(edited.value.source).toContain(style)
    expect(edited.value.diagram.body.kind).toBe('opaque')
    expect(edited.value.diagram.source.spans?.preserved.source.end.offset).toBe(edited.value.source.length)
    expect(verifyMermaid(edited.value.diagram).warnings).toContainEqual(expect.objectContaining({ code: 'UNSUPPORTED_SYNTAX', syntax: 'flowchart_style_value' }))
    const graph = parseNativeFlowchart(normalizeMermaidSource(edited.value.source).familyBody)
    expect(graph.nodes.get('A')?.label).toBe('Changed')
    expect(graph.classDefs.get('exClass')).toEqual({ background: '#bbb', border: '1px s:::colid red' })
    const svg = renderMermaidSVG(edited.value.diagram, { embedFontImport: false })
    const paintedText = [...svg.matchAll(/<text\b[^>]*>(.*?)<\/text>/gs)].map(match => match[1]!.replace(/<[^>]*>/g, ''))
    expect(paintedText).toContain('Changed')
    expect(paintedText).not.toContain('h')
    expect(paintedText).toContain('hello')
    const ascii = renderMermaidASCII(edited.value.diagram, { colorMode: 'none' })
    expect(ascii).toContain('Changed')
    expect(ascii).toContain('hello')
    expect(ascii).toContain('test')
  })
  test('retains both complete native graph frames through nested shape, style and link label edits', () => {
    const source = ['---', 'title: Keep wrapper', '---', 'flowchart LR', 'subgraph S[Group]', '  A{Old}:::exClass --> B@{ shape: delay, label: Wait }', 'end', 'style A color:red', 'linkStyle 0 stroke:blue', 'click A href "https://example.com"', style, ''].join('\r\n')
    let diagram = parse(source), previous = source
    for (const label of ['Changed', 'Second']) {
      const result = mutatePreservingSource(diagram, { kind: 'set_label', target: 'A', label })
      if (!result.ok) throw new Error(result.error.message)
      expect(result.value.source.startsWith(previous)).toBe(true)
      expect(result.value.source.slice(0, source.length)).toBe(source)
      expect(result.value.source).toContain(style + '\r\n')
      expect(result.value.diagram.meta.wrapperSource).toBe('---\r\ntitle: Keep wrapper\r\n---\r\n')
      for (const normalize of [normalizeMermaidSource, normalizeMermaidRenderSource]) {
        const before = parseNativeFlowchart(normalize(previous).familyBody)
        const after = parseNativeFlowchart(normalize(result.value.source).familyBody)
        expect(after.nodes.get('A')).toEqual({ ...before.nodes.get('A')!, label })
        expect(after.nodes.get('A')?.shape).toBe('diamond')
        expect(after.nodes.get('A')?.href).toBe('https://example.com')
        expect(after.subgraphs[0]?.nodeIds).toEqual(['A', 'B'])
        expect(after.nodes.get('B')).toMatchObject({ shape: 'rounded', semanticShape: 'delay', authoredShape: 'delay' })
        after.nodes.set('A', before.nodes.get('A')!)
        expect(after).toEqual(before)
      }
      diagram = result.value.diagram
      previous = result.value.source
    }
  })
  test('returns exact bytes for no-op labels and refuses edge or unsupported operations atomically', () => {
    const diagram = parse(retained)
    const noop = mutatePreservingSource(diagram, { kind: 'set_label', target: 'A', label: ' h ' })
    if (!noop.ok) throw new Error(noop.error.message)
    expect(noop.value.source).toBe(retained)
    expect(noop.value.diagram.body).toEqual(diagram.body)
    for (const op of [
      { kind: 'set_label', target: 'A->B', label: 'Edge edit' },
      { kind: 'set_label', target: 'Missing', label: 'Missing node' },
      { kind: 'add_edge', from: 'A', to: 'C' },
      { kind: 'define_class', name: 'other', style: 'fill:red' },
      { kind: 'unknown_operation' },
      { kind: 'set_label', target: 'A', label: 123 },
      { kind: 'set_label', target: 'A', label: '`**literal**`' },
    ]) {
      expect(mutatePreservingSource(diagram, op).ok).toBe(false)
      expect(diagram.body).toEqual(noop.value.diagram.body)
      if (diagram.body.kind !== 'opaque') throw new Error('Expected retained opaque body')
      expect((diagram.meta.wrapperSource ?? '') + diagram.body.source).toBe(retained)
    }
  })
  test('writes directive-looking label payloads as text without changing universal metadata or connectivity', () => {
    const diagram = parse(retained), label = '%%{init: {"theme":"dark"}}%%\nZ-->Q; A@{shape:circle}'
    const result = mutatePreservingSource(diagram, { kind: 'set_label', target: 'A', label })
    if (!result.ok) throw new Error(result.error.message)
    expect(result.value.source.startsWith(retained)).toBe(true)
    expect(result.value.diagram.meta).toEqual(diagram.meta)
    for (const normalize of [normalizeMermaidSource, normalizeMermaidRenderSource]) {
      const before = parseNativeFlowchart(normalize(retained).familyBody), after = parseNativeFlowchart(normalize(result.value.source).familyBody)
      expect(after.nodes.get('A')).toEqual({ ...before.nodes.get('A')!, label })
      after.nodes.set('A', before.nodes.get('A')!)
      expect(after).toEqual(before)
    }
  })
  test('does not treat equality in only the authored interpretation as a source no-op', () => {
    const source = `flowchart LR\nA["A&amp; B"]-->B\n${style}`, diagram = parse(source)
    const result = mutatePreservingSource(diagram, { kind: 'set_label', target: 'A', label: 'A&amp; B' })
    expect(result.ok).toBe(false)
    if (diagram.body.kind !== 'opaque') throw new Error('Expected retained opaque body')
    expect(diagram.body.source).toBe(source)
  })
  test.each(['R&amp;D', '&#65;', 'keep &quot;quote&quot;'])('checks newly divergent render text when editing previously identical source views: %s', label => {
    const source = `flowchart TD\nA[Old] --> B\n${style}`, diagram = parse(source), unchanged = JSON.stringify(diagram)
    expect(normalizeMermaidSource(source).familyBody).toBe(normalizeMermaidRenderSource(source).familyBody)
    expect(mutatePreservingSource(diagram, { kind: 'set_label', target: 'A', label }).ok).toBe(false)
    expect(JSON.stringify(diagram)).toBe(unchanged)
  })
  test('retains distinct authored and rendered text on another node through repeated source edits', () => {
    const source = `flowchart TD\nA[Old] --> B["R&amp;D"]\n${style}`
    let diagram = parse(source)
    for (const label of ['Reviewed', 'Second']) {
      const result = mutatePreservingSource(diagram, { kind: 'set_label', target: 'A', label })
      if (!result.ok) throw new Error(result.error.message)
      expect(result.value.source.startsWith(source)).toBe(true)
      const authored = parseNativeFlowchart(normalizeMermaidSource(result.value.source).familyBody)
      const rendered = parseNativeFlowchart(normalizeMermaidRenderSource(result.value.source).familyBody)
      expect(authored.nodes.get('A')?.label).toBe(label)
      expect(rendered.nodes.get('A')?.label).toBe(label)
      expect(authored.nodes.get('B')?.label).toBe('R&amp;D')
      expect(rendered.nodes.get('B')?.label).toBe('R&D')
      diagram = result.value.diagram
    }
  })

  test('renames owned node references while preserving source text, node order, labels and dependent edge/group identities', () => {
    const source = `---\ntitle: Keep A\n---\nflowchart LR\naccTitle: A stays text\n%% A stays a comment\nsubgraph S[Group A]\nA[Label A] -->|Edge A| B:::exClass\nC --> A\nA --> A\nend\n${style}`
    const original = parse(source)
    const renamed = mutatePreservingSource(original, { kind: 'rename_node', from: 'A', to: 'Start' })
    if (!renamed.ok) throw new Error(renamed.error.message)
    expect(renamed.value.source).toBe(source.replace('A[Label A]', 'Start[Label A]').replace('C --> A', 'C --> Start').replace('A --> A', 'Start --> Start'))
    for (const normalize of [normalizeMermaidSource, normalizeMermaidRenderSource]) {
      const before = parseNativeFlowchart(normalize(source).familyBody), after = parseNativeFlowchart(normalize(renamed.value.source).familyBody)
      const rename = (id: string) => id === 'A' ? 'Start' : id
      expect([...after.nodes.keys()]).toEqual([...before.nodes.keys()].map(rename))
      expect(after.nodes.get('Start')).toEqual({ ...before.nodes.get('A')!, id: 'Start' })
      expect(after.edges).toEqual(before.edges.map(edge => ({ ...edge, source: rename(edge.source), target: rename(edge.target) })))
      expect(after.subgraphs[0]?.nodeIds).toEqual(before.subgraphs[0]!.nodeIds.map(rename))
      expect(after.classDefs).toEqual(before.classDefs)
    }
    const noop = mutatePreservingSource(renamed.value.diagram, { kind: 'rename_node', from: 'Start', to: 'Start' })
    if (!noop.ok) throw new Error(noop.error.message)
    expect(noop.value.source).toBe(renamed.value.source)
    expect(renderMermaidSVG(renamed.value.diagram)).toBe(renderMermaidSVG(renamed.value.source))
    expect(renderMermaidASCII(renamed.value.diagram)).toBe(renderMermaidASCII(renamed.value.source))
  })

  test.each(['style A fill:red', 'class A hot', 'click A callback', 'click A href "https://example.com"', 'subgraph A[Group]\nC\nend'])('refuses node rename while reference ownership is unsupported: %s', extra => {
    const source = `flowchart LR\nA[Label] --> B\n${extra}\n${style}`, original = parse(source), unchanged = JSON.stringify(original)
    expect(mutatePreservingSource(original, { kind: 'rename_node', from: 'A', to: 'Start' }).ok).toBe(false)
    expect(JSON.stringify(original)).toBe(unchanged)
  })
  test.each(['o', 'x'])('renames the node %s without rewriting an arrow marker with the same spelling', id => {
    const source = `flowchart LR\nA o--x B\n${id}[Keep ${id}]\n${id} --> A\n${style}`, original = parse(source)
    const renamed = mutatePreservingSource(original, { kind: 'rename_node', from: id, to: 'Port' })
    if (!renamed.ok) throw new Error(renamed.error.message)
    expect(renamed.value.source).toBe(source.replace(`\n${id}[Keep ${id}]`, `\nPort[Keep ${id}]`).replace(`\n${id} --> A`, '\nPort --> A'))
    expect(parseNativeFlowchart(normalizeMermaidRenderSource(renamed.value.source).familyBody).nodes.get('Port')?.label).toBe(`Keep ${id}`)
  })
  test('refuses rename collisions and structural ID injection without changing the retained input', () => {
    const original = parse(retained), unchanged = JSON.stringify(original)
    for (const [from, to] of [['Missing', 'Start'], ['A', 'B'], ['A', 'end'], ['A', 'Start\nX-->Z'], ['A', 'Start["Injected"]']]) expect(mutatePreservingSource(original, { kind: 'rename_node', from, to }).ok).toBe(false)
    expect(JSON.stringify(original)).toBe(unchanged)
  })
})
describe('parseRegisteredMermaid', () => {
  test('flowchart', () => {
    expect(parse('flowchart TD\n  A --> B').body.kind).toBe('flowchart')
  })
  test('frontmatter into meta', () => {
    expect(parse('---\ntitle: T\n---\nflowchart TD\n  A --> B').meta.frontmatter?.title).toBe('T')
  })
  test('init directive captured', () => {
    expect(parse('%%{init: {"theme":"forest"}}%%\nflowchart TD\n  A --> B').meta.initDirectives[0]!.parsed.theme).toBe('forest')
  })
  test('accTitle/accDescr', () => {
    const d = parse('flowchart TD\n  accTitle: T\n  accDescr: D\n  A --> B')
    expect(d.meta.accessibility.title).toBe('T')
    expect(d.meta.accessibility.descr).toBe('D')
  })
  test('empty source errors', () => {
    expect(parseMermaid('').ok).toBe(false)
  })
  test('unknown headers use the open preserved-family envelope', () => {
    const r = parseMermaid('notADiagram\n X')
    expect(r).toMatchObject({
      ok: true,
      value: {
        kind: 'family:unknown',
        body: { kind: 'preserved', diagnostic: { code: 'UNKNOWN_HEADER' } },
      },
    })
  })
  test('mutable families are structured (xychart promoted by BUILD-16)', () => {
    for (const [s, k] of [
      ['classDiagram\n  A <|-- B', 'class'],
      ['erDiagram\n  A ||--o{ B : x', 'er'],
      ['timeline\n  2020 : A', 'timeline'],
      ['journey\n  title T\n  section S\n    Wake: 3: Me', 'journey'],
      ['architecture-beta\n  service g(server)[g]', 'architecture'],
      ['xychart-beta\n  bar [1,2,3]', 'xychart'],
    ] as const) {
      const d = parse(s)
      expect(d.kind).toBe(k)
      expect(d.body.kind).toBe(k)
    }
  })
})

describe('sequence parsing — structured', () => {
  test('simple messages → structured body', () => {
    const d = parse('sequenceDiagram\n  Alice->>Bob: Hi\n  Bob-->>Alice: Hello')
    expect(d.body.kind).toBe('sequence')
    if (d.body.kind !== 'sequence') return
    expect(d.body.participants.map(p => p.id)).toEqual(['Alice', 'Bob'])
    expect(d.body.messages.map(m => m.style)).toEqual(['sync', 'reply'])
  })
  test('participant/actor + alias', () => {
    const d = parse('sequenceDiagram\n  participant A as Alice\n  actor B as Bob\n  A->>B: Hi')
    if (d.body.kind !== 'sequence') throw new Error('expected sequence')
    expect(d.body.participants[0]).toEqual({ id: 'A', label: 'Alice', kind: 'participant' })
    expect(d.body.participants[1]).toEqual({ id: 'B', label: 'Bob', kind: 'actor' })
  })
  test('semicolon-packed sequence statements are structured', () => {
    const d = parse('sequenceDiagram;Alice->Bob: Hello Bob, how are you?;Note right of Bob: Bob thinks;Bob-->Alice: I am good thanks!;')
    expect(d.body.kind).toBe('sequence')
    if (d.body.kind !== 'sequence') return
    expect(d.body.messages.map(m => m.text)).toEqual(['Hello Bob, how are you?', 'I am good thanks!'])
    expect(d.body.statements?.some(st => st.kind === 'opaque-block')).toBe(true)
    expect(verifyMermaid(d).ok).toBe(true)
  })
})

// BUILD-18 headline: a sequence with a block construct (alt) is now structured
// (segment-preserving), add_message works, and the alt block survives verbatim
// in its original position after serialize.
describe('BUILD-18 segment-preserving sequence body (headline)', () => {
  const SRC = ['sequenceDiagram', '  A->>B: ping', '  alt success', '    B-->>A: ok', '  else failure', '    B-->>A: nope', '  end', '  A->>B: bye'].join('\n')

  test('alt block → typed fragment while top-level message addressing remains stable', () => {
    const d = parse(SRC)
    const s = asSequence(d)
    expect(s).not.toBeNull()
    if (!s) return
    // The top-level array remains backward-compatible; fragment messages have
    // their own typed addressing and participate in read-back/verify.
    expect(s.body.messages.map(m => m.text)).toEqual(['ping', 'bye'])
    const fragment = s.body.statements?.find(st => st.kind === 'fragment')
    expect(fragment?.kind).toBe('fragment')
    if (fragment?.kind === 'fragment') expect(fragment.fragment.branches.flatMap(branch => branch.messages.map(message => message.text))).toEqual(['ok', 'nope'])
  })

  test('add_message appends after the alt block and serialize keeps the block verbatim in position', () => {
    const s = sequence(SRC)
    const r = mutate(s, { kind: 'add_message', from: 'A', to: 'B', text: 'again' })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    const out = serializeMermaid(r.value)
    // The alt block lines survive verbatim, in order, with their indentation.
    expect(out).toContain('  alt success\n    B-->>A: ok\n  else failure\n    B-->>A: nope\n  end')
    // The new message lands after the last statement (after `A->>B: bye`).
    const lines = out.trimEnd().split('\n')
    expect(lines[lines.length - 1]).toBe('  A->>B: again')
  })

  test('round-trip is verbatim-lossless: every original non-blank line survives in order', () => {
    const d = parse(SRC)
    const out = serializeMermaid(d).trimEnd()
    const origLines = SRC.split('\n').map(l => l.replace(/\s+$/, ''))
    const outLines = out.split('\n')
    // Structured lines canonicalize whitespace; opaque lines stay verbatim.
    // The block (alt…end) is opaque, so those lines match byte-for-byte.
    expect(outLines).toEqual(origLines)
  })
})

describe('BUILD-18 segment-preserving sequence — fast-check properties', () => {
  // Generators: structured message lines and opaque block segments, interleaved.
  const idArb = fc.constantFrom('A', 'B', 'C', 'D')
  const textArb = fc.stringMatching(/^[a-z][a-z ]{0,12}[a-z]$/)
  const structuredMsg = fc.tuple(idArb, idArb, textArb).map(([f, t, x]) => `  ${f}->>${t}: ${x}`)
  const noteLine = fc.tuple(idArb, textArb).map(([a, x]) => `  Note over ${a}: ${x}`)
  const altBlock = fc.tuple(textArb, structuredMsg, textArb, structuredMsg).map(([a, m1, b, m2]) => `  alt ${a}\n  ${m1}\n  else ${b}\n  ${m2}\n  end`)
  const loopBlock = fc.tuple(textArb, structuredMsg).map(([a, m]) => `  loop ${a}\n  ${m}\n  end`)
  const opaqueSeg = fc.oneof(noteLine, altBlock, loopBlock)
  const segmentArb = fc.oneof(structuredMsg, opaqueSeg)
  const bodyArb = fc.array(segmentArb, { minLength: 1, maxLength: 8 }).map(segs => 'sequenceDiagram\n' + segs.join('\n'))

  // Property 1: parse → serialize reproduces ALL original non-blank lines in
  // order. Whitespace is canonicalized only on structured lines; opaque lines
  // stay verbatim. We compare on trimmed line content (structured lines keep a
  // two-space indent, opaque lines keep their original text) to assert order
  // and content survive.
  test('property: interleaved structured + opaque lines round-trip in order', () => {
    fc.assert(
      fc.property(bodyArb, src => {
        // Every generated body segments; sequence() throws on the opaque fallback.
        const d = sequence(src)
        const out = serializeMermaid(d).trimEnd()
        const origNonBlank = src
          .split('\n')
          .map(l => l.trim())
          .filter(Boolean)
        const outNonBlank = out
          .split('\n')
          .map(l => l.trim())
          .filter(Boolean)
        expect(outNonBlank).toEqual(origNonBlank)
        // Idempotent: re-parse → same serialize.
        expect(serializeMermaid(parse(out))).toBe(serializeMermaid(d))
      }),
      fcParameters({ numRuns: 200 }),
    )
  })

  // Property 2: remove_message(k) deletes exactly the k-th top-level message
  // line and leaves every other statement (typed alt/loop fragments and opaque
  // notes) in place byte-for-byte. Every generated body has at least one
  // top-level message and at least one block, so no run is vacuous.
  test('property: remove_message removes exactly one top-level message and preserves every block', () => {
    const blockArb = fc.oneof(noteLine, altBlock, loopBlock)
    const segArb = fc.oneof(structuredMsg.map(text => ({ text, message: true })), blockArb.map(text => ({ text, message: false })))
    const caseArb = fc.record({
      before: fc.array(segArb, { maxLength: 3 }),
      message: structuredMsg,
      block: blockArb,
      blockFirst: fc.boolean(),
      after: fc.array(segArb, { maxLength: 3 }),
      pick: fc.nat(),
    })
    const nonBlank = (text: string) => text.split('\n').map(l => l.trim()).filter(Boolean)
    fc.assert(
      fc.property(caseArb, c => {
        const message = { text: c.message, message: true }
        const block = { text: c.block, message: false }
        const segs = [...c.before, ...(c.blockFirst ? [block, message] : [message, block]), ...c.after]
        const s = sequence('sequenceDiagram\n' + segs.map(x => x.text).join('\n'))
        const messages = segs.filter(x => x.message)
        expect(s.body.messages.length).toBe(messages.length)
        const removed = messages[c.pick % messages.length]!
        const r = mutate(s, { kind: 'remove_message', index: c.pick % messages.length })
        if (!r.ok) throw new Error('remove_message: ' + JSON.stringify(r.error))
        const expected = nonBlank(['sequenceDiagram', ...segs.filter(x => x !== removed).map(x => x.text)].join('\n'))
        expect(nonBlank(serializeMermaid(r.value))).toEqual(expected)
      }),
      fcParameters({ numRuns: 200 }),
    )
  })

  // Property 3 (the old AGENT_NATIVE whole-opaque property, restated):
  // "segments-or-opaque, always lossless" — for ANY sequence source, parse
  // either segments (structured) or falls back to opaque, and in BOTH cases the
  // round-trip is stable and every original non-blank line survives.
  test('property: segments-or-opaque, always lossless', () => {
    const anyLine = fc.oneof(structuredMsg, opaqueSeg, fc.constant('  end'), fc.constant('  activate A'))
    const anyBody = fc.array(anyLine, { minLength: 1, maxLength: 8 }).map(segs => 'sequenceDiagram\n' + segs.join('\n'))
    fc.assert(
      fc.property(anyBody, src => {
        const d = parse(src)
        // Either structured-with-segments OR opaque fallback — never an error.
        expect(d.body.kind === 'sequence' || d.body.kind === 'opaque').toBe(true)
        const out = serializeMermaid(d).trimEnd()
        const origNonBlank = src
          .split('\n')
          .map(l => l.trim())
          .filter(Boolean)
        const outNonBlank = out
          .split('\n')
          .map(l => l.trim())
          .filter(Boolean)
        expect(outNonBlank).toEqual(origNonBlank)
        // Round-trip stable.
        expect(serializeMermaid(parse(out))).toBe(serializeMermaid(d))
      }),
      fcParameters({ numRuns: 300 }),
    )
  })
})

describe('BUILD-18 sequence segmentation — sad paths', () => {
  test('stray end without an open block → whole-body opaque fallback (lossless)', () => {
    const src = 'sequenceDiagram\n  A->>B: hi\n  end'
    const d = parse(src)
    expect(d.body.kind).toBe('opaque')
    expect(asSequence(d)).toBeNull()
    expect(serializeMermaid(d).trimEnd()).toBe(src)
  })

  test('block without a closing end → whole-body opaque fallback (lossless)', () => {
    const src = 'sequenceDiagram\n  alt ok\n    A->>B: yes'
    const d = parse(src)
    expect(d.body.kind).toBe('opaque')
    expect(asSequence(d)).toBeNull()
    expect(serializeMermaid(d).trimEnd()).toBe(src)
  })

  test('nested alt-in-loop is one opaque block; top-level messages stay structured', () => {
    const src = ['sequenceDiagram', '  A->>B: start', '  loop retry', '    alt ok', '      B-->>A: yes', '    else no', '      B-->>A: no', '    end', '  end', '  A->>B: done'].join('\n')
    const s = sequence(src)
    expect(s.body.messages.map(m => m.text)).toEqual(['start', 'done'])
    const opaque = (s.body.statements ?? []).filter(st => st.kind === 'opaque-block')
    expect(opaque.length).toBe(1)
    expect(serializeMermaid(s).trimEnd()).toBe(src)
  })

  test('message inside a typed fragment creates participants for valid read-back', () => {
    const src = 'sequenceDiagram\n  A->>B: hi\n  alt ok\n    Z->>Q: secret\n  end'
    const s = sequence(src)
    const ids = s.body.participants.map(p => p.id)
    expect(ids).toContain('A')
    expect(ids).toContain('B')
    expect(ids).toContain('Z')
    expect(ids).toContain('Q')
  })

  test('autonumber interleaving stays verbatim and messages remain addressable', () => {
    const src = 'sequenceDiagram\n  autonumber\n  A->>B: one\n  Note over A: mid\n  A->>B: two'
    const s = sequence(src)
    expect(s.body.messages.map(m => m.text)).toEqual(['one', 'two'])
    const out = serializeMermaid(s).trimEnd()
    expect(out).toContain('  autonumber')
    expect(out).toContain('  Note over A: mid')
    expect(out.split('\n').map(l => l.trim())).toEqual(src.split('\n').map(l => l.trim()))
  })
})

describe('sequence segment-preserving fidelity (BUILD-18 — was the v4 opaque cliff)', () => {
  // These constructs used to force the WHOLE body opaque (asSequence null).
  // BUILD-18 flips that: they parse structured-with-segments (asSequence
  // non-null, mutation offered) AND stay verbatim-lossless — the heart of v4
  // survives, now without losing the structured ops.
  const COMPLEX = [
    'sequenceDiagram\n  Alice->>Bob: Hi\n  Note over Alice: thinking',
    'sequenceDiagram\n  alt success\n    A->>B: ok\n  else failure\n    A->>B: no\n  end',
    'sequenceDiagram\n  loop every minute\n    A->>B: poll\n  end',
    'sequenceDiagram\n  activate Bob\n  A->>B: x\n  deactivate Bob',
    'sequenceDiagram\n  autonumber\n  A->>B: x',
  ]
  for (const src of COMPLEX) {
    test(`now structured-with-segments, still lossless: ${src.split('\n')[1]!.trim()}`, () => {
      const d = parse(src)
      expect(d.kind).toBe('sequence')
      expect(d.body.kind).toBe('sequence') // structured, not opaque
      expect(asSequence(d)).not.toBeNull() // mutation now offered
      // Verbatim-lossless: every original non-blank line survives, in order.
      const out = serializeMermaid(d).trimEnd()
      expect(out.split('\n')).toEqual(src.split('\n').map(l => l.replace(/\s+$/, '')))
      // And the round-trip is stable (idempotent re-parse → same serialize).
      const d2 = parse(out)
      expect(serializeMermaid(d2)).toBe(serializeMermaid(d))
    })
  }
})

describe('flowchart mutate — six ops', () => {
  test('add_node', () => {
    const r = mutate(flowchart('flowchart TD\n  A --> B'), { kind: 'add_node', id: 'C', label: 'Cache' })
    expect(r).toMatchObject({ ok: true })
    if (r.ok) expect(r.value.body.graph.nodes.get('C')).toMatchObject({ id: 'C', label: 'Cache' })
  })
  test('add_node duplicate rejected', () => {
    const r = mutate(flowchart('flowchart TD\n  A --> B'), { kind: 'add_node', id: 'A', label: 'X' })
    expect(!r.ok && r.error.code).toBe('DUPLICATE_NODE')
  })
  test('remove_node cascades', () => {
    const r = mutate(flowchart('flowchart TD\n  A --> B\n  B --> C'), { kind: 'remove_node', id: 'B' })
    expect(r.ok && r.value.body.graph.edges.length).toBe(0)
  })
  test('rename_node updates edges', () => {
    const r = mutate(flowchart('flowchart TD\n  A --> B'), { kind: 'rename_node', from: 'B', to: 'M' })
    expect(r.ok && r.value.body.graph.edges[0]!.target).toBe('M')
  })
  test('set_label node', () => {
    const r = mutate(flowchart('flowchart TD\n  A --> B'), { kind: 'set_label', target: 'A', label: 'Alpha' })
    expect(r.ok && r.value.body.graph.nodes.get('A')!.label).toBe('Alpha')
  })
  test('add_edge implicit nodes', () => {
    const r = mutate(flowchart('flowchart TD\n  A --> B'), { kind: 'add_edge', from: 'C', to: 'D' })
    expect(r).toMatchObject({ ok: true })
    if (r.ok) expect([...r.value.body.graph.nodes.keys()]).toEqual(expect.arrayContaining(['C', 'D']))
  })
  test('remove_edge', () => {
    const r = mutate(flowchart('flowchart TD\n  A --> B\n  B --> C'), { kind: 'remove_edge', id: 'A->B' })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    expect(r.value.body.graph.edges.map(edge => [edge.source, edge.target])).toEqual([['B', 'C']])
  })
  test('edge and node removals remap numeric linkStyle targets to surviving edge indices', () => {
    const source = 'flowchart TD\n  A --> B\n  B --> C\n  C --> D\n  linkStyle 0 stroke:#111\n  linkStyle 1 stroke:#f00\n  linkStyle 2 stroke:#0f0\n  linkStyle default stroke:#888'
    const edgeRemoval = mutate(flowchart(source), { kind: 'remove_edge', id: 'A->B' })
    expect(edgeRemoval.ok).toBe(true)
    if (edgeRemoval.ok) {
      expect(edgeRemoval.value.body.graph.edges.map(edge => `${edge.source}->${edge.target}`)).toEqual(['B->C', 'C->D'])
      expect([...edgeRemoval.value.body.graph.linkStyles.entries()]).toEqual([
        [0, { stroke: '#f00' }],
        [1, { stroke: '#0f0' }],
        ['default', { stroke: '#888' }],
      ])
    }

    const nodeRemoval = mutate(flowchart(source), { kind: 'remove_node', id: 'B' })
    expect(nodeRemoval.ok).toBe(true)
    if (nodeRemoval.ok) {
      expect(nodeRemoval.value.body.graph.edges.map(edge => `${edge.source}->${edge.target}`)).toEqual(['C->D'])
      expect([...nodeRemoval.value.body.graph.linkStyles.entries()]).toEqual([
        [0, { stroke: '#0f0' }],
        ['default', { stroke: '#888' }],
      ])
    }
  })
  test('remove_edge missing id', () => {
    const r = mutate(flowchart('flowchart TD\n  A --> B'), { kind: 'remove_edge', id: 'Z->Y' })
    expect(!r.ok && r.error.code).toBe('EDGE_NOT_FOUND')
  })
  test('input not mutated', () => {
    const f = flowchart('flowchart TD\n  A --> B')
    const before = [...f.body.graph.nodes.keys()].sort()
    const edited = mutate(f, { kind: 'add_node', id: 'C', label: 'C' })
    expect(edited.ok).toBe(true)
    if (!edited.ok) return
    expect(edited.value.body.graph.nodes.get('C')).toMatchObject({ id: 'C', label: 'C' })
    expect([...f.body.graph.nodes.keys()].sort()).toEqual(before)
  })
})

describe('sequence mutate — five ops', () => {
  test('add_participant', () => {
    const r = mutate(sequence('sequenceDiagram\n  A->>B: Hi'), { kind: 'add_participant', id: 'C', label: 'Charlie' })
    expect(r).toMatchObject({ ok: true })
    if (r.ok) expect(r.value.body.participants).toContainEqual(expect.objectContaining({ id: 'C', label: 'Charlie' }))
  })
  test('add_participant duplicate', () => {
    const r = mutate(sequence('sequenceDiagram\n  A->>B: Hi'), { kind: 'add_participant', id: 'A' })
    expect(!r.ok && r.error.code).toBe('DUPLICATE_PARTICIPANT')
  })
  test('remove_participant cascades to messages', () => {
    const r = mutate(sequence('sequenceDiagram\n  A->>B: Hi\n  B-->>A: Hello\n  A->>C: Bye'), { kind: 'remove_participant', id: 'B' })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    expect(r.value.body.participants.some(p => p.id === 'B')).toBe(false)
    expect(r.value.body.messages.length).toBe(1)
  })
  test('add_message implicit participants', () => {
    const r = mutate(sequence('sequenceDiagram\n  A->>B: Hi'), { kind: 'add_message', from: 'C', to: 'D', text: 'New' })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    expect(r.value.body.participants.map(p => p.id)).toEqual(expect.arrayContaining(['C', 'D']))
    expect(r.value.body.messages).toContainEqual(expect.objectContaining({ from: 'C', to: 'D', text: 'New' }))
  })
  test('remove_message by index', () => {
    const r = mutate(sequence('sequenceDiagram\n  A->>B: First\n  B-->>A: Second'), { kind: 'remove_message', index: 0 })
    expect(r.ok && r.value.body.messages[0]!.text).toBe('Second')
  })
  test('set_message_text', () => {
    const r = mutate(sequence('sequenceDiagram\n  A->>B: Hi'), { kind: 'set_message_text', index: 0, text: 'Yo' })
    expect(r.ok && r.value.body.messages[0]!.text).toBe('Yo')
  })
  test('index out of bounds', () => {
    const r = mutate(sequence('sequenceDiagram\n  A->>B: Hi'), { kind: 'remove_message', index: 9 })
    expect(!r.ok && r.error.code).toBe('MESSAGE_NOT_FOUND')
  })
})

describe('opaque-fallback round-trip (journey/xychart/architecture promoted by BUILD-15/16/17)', () => {
  // Universal accessibility is modeled centrally; a genuinely unmodeled
  // family token still stays on the source-level/opaque path.
  const cases = [['xychart', 'xychart-beta\n  curve basis\n  x-axis [Jan, Feb]\n  bar [1, 2]']] as const

  for (const [family, src] of cases) {
    test(`${family}: unmodeled syntax parses as opaque/source-level and round-trips`, () => {
      const d = parse(src)
      expect(d.kind).toBe(family)
      expect(d.body.kind).toBe('opaque')
      expect(serializeMermaid(d).trimEnd()).toBe(src)
      const verification = verifyMermaid(d)
      expect(verification.ok).toBe(false)
      expect(verification.warnings.map(warning => warning.code)).toContain('UNSUPPORTED_SYNTAX')
      expect(verification.warnings.map(warning => warning.code)).toContain('RENDER_FAILED')
    })
  }

  test('clean xychart is structured after BUILD-16', () => {
    const d = parse('xychart-beta\n  title Sales\n  x-axis [Jan, Feb]\n  bar [1, 2]')
    expect(d.kind).toBe('xychart')
    expect(d.body.kind).toBe('xychart')
  })

  test('journey header suffix is preserved rather than normalized away', () => {
    const src = 'journey EXTRA\n  Alpha: 3: Me'
    const d = parse(src)
    expect(d.kind).toBe('journey')
    expect(d.body.kind).toBe('opaque')
    expect(serializeMermaid(d).trimEnd()).toBe(src)
  })

  test('xychart one-line semicolon source is not treated as empty', () => {
    const d = parse('xychart-beta; title Short; curve basis')
    expect(d.body.kind).toBe('opaque')
    expect(verifyMermaid(d).warnings.map(w => w.code)).not.toContain('EMPTY_DIAGRAM')
  })

  test('xychart unknown trailing tokens are preserved', () => {
    const src = 'xychart-beta horizontal EXTRA\n  bar [1, 2]'
    const d = parse(src)
    expect(d.kind).toBe('xychart')
    expect(d.body.kind).toBe('opaque')
    expect(serializeMermaid(d)).toContain('EXTRA')
  })
})

describe('round-trip stability', () => {
  const corpus = [
    'flowchart TD\n  A --> B',
    'flowchart LR\n  A[Alpha] --> B[Beta]',
    'flowchart TD\n  A{D} --> B[Yes]\n  A --> C[No]',
    'flowchart TD\n  A((S)) --> B[Step]\n  B --> C((E))',
    '---\ntitle: T\n---\nflowchart TD\n  A --> B',
    'sequenceDiagram\n  Alice->>Bob: Hi\n  Bob-->>Alice: Hello',
    'sequenceDiagram\n  participant A as Alice\n  A->>B: Hi',
    // REGRESSION: subgraphs must round-trip (members were lost when edges were
    // emitted before the subgraph block).
    'flowchart TD\n  subgraph G\n    A --> B\n  end\n  B --> C',
    'flowchart TD\n  subgraph G\n    A[Start] --> B{D}\n  end\n  B --> C',
    'flowchart LR\n  subgraph Outer\n    subgraph Inner\n      X --> Y\n    end\n  end\n  Y --> Z',
  ]
  for (const src of corpus) {
    test(`stable: ${src.split('\n')[0]} ${src.includes('subgraph') ? '(subgraph)' : ''}...`, () => {
      const d = parse(src)
      const s1 = serializeMermaid(d)
      const d2 = parse(s1)
      expect(serializeMermaid(d2)).toBe(s1)
    })
  }
  test('subgraph membership survives round-trip', () => {
    const d = parse('flowchart TD\n  subgraph G\n    A --> B\n  end\n  B --> C')
    const d2 = parse(serializeMermaid(d))
    if (d2.body.kind !== 'flowchart') throw new Error('x')
    expect(d2.body.graph.subgraphs[0]!.nodeIds.sort()).toEqual(['A', 'B'])
  })
  test('typed mutations trim boundary whitespace in labels, as parsing does', () => {
    // Upstream's flowchart DB trims labels, so `C[" c "]` parses to "c"; a
    // typed edit stores what its serialized source re-parses to, and an edge
    // label that trims to nothing is no label.
    const labels = (d: FlowchartValidDiagram) => ({
      nodes: [...d.body.graph.nodes.values()].map(node => node.label),
      edges: d.body.graph.edges.map(edge => edge.label),
      subgraphs: d.body.graph.subgraphs.map(subgraph => subgraph.label),
    })
    expect(labels(flowchart('flowchart TD\n  subgraph G [" g "]\n    C[" c "]\n  end\n  A -->|" a "| A\n  A -->|" "| B')))
      .toEqual({ nodes: ['c', 'A', 'B'], edges: ['a', undefined], subgraphs: ['g'] })
    const ops: FlowchartMutationOp[] = [
      { kind: 'add_node', id: 'C', label: ' c ' },
      { kind: 'add_edge', from: 'A', to: 'A', label: ' a ' },
      { kind: 'add_edge', from: 'A', to: 'B', label: '  ' },
      { kind: 'add_subgraph', id: 'G', label: ' g ', members: ['C'] },
    ]
    let changed = flowchart('flowchart TD\n  A --> B')
    for (const op of ops) {
      const result = mutate(changed, op)
      if (!result.ok) throw new Error(result.error.message)
      changed = result.value
    }
    expect(labels(changed)).toEqual({ nodes: ['A', 'B', 'c'], edges: [undefined, 'a', undefined], subgraphs: ['g'] })
    const source = serializeMermaid(changed)
    expect(source).toContain('  subgraph G[g]\n    C[c]\n')
    expect(source).toContain('  A -->|a| A\n  A --> B\n')
    const reparsed = flowchart(source)
    expect(labels(reparsed)).toEqual({ nodes: ['c', 'A', 'B'], edges: [undefined, 'a', undefined], subgraphs: ['g'] })
    expect(serializeMermaid(reparsed)).toBe(source)
  })
  test('property: flowchart mutation commands preserve a shadow model and stay parseable', () => {
    type Model = {
      nodes: Map<string, string>
      edges: Array<{ from: string; to: string; label: string | undefined }>
    }
    type Real = { diagram: FlowchartValidDiagram }
    type Action =
      | { kind: 'add_node'; id: string; label: string }
      | { kind: 'rename_node'; from: string; to: string }
      | { kind: 'remove_node'; id: string }
      | { kind: 'set_label'; id: string; label: string }
      | { kind: 'add_edge'; from: string; to: string; label?: string }
      | { kind: 'remove_edge'; from: string; to: string }

    const assertConforms = (model: Model, real: Real) => {
      const graph = real.diagram.body.graph
      expect([...graph.nodes].map(([id, node]) => [id, node.label])).toEqual([...model.nodes])
      expect(graph.edges.map(edge => ({ from: edge.source, to: edge.target, label: edge.label })))
        .toEqual(model.edges)

      const source = serializeMermaid(real.diagram)
      const reparsed = parseMermaid(source)
      expect(reparsed.ok).toBe(true)
      if (reparsed.ok) expect(serializeMermaid(reparsed.value)).toBe(source)
    }

    class MutationCommand implements fc.Command<Model, Real> {
      constructor(private readonly action: Action) {}

      check(model: Readonly<Model>): boolean {
        const action = this.action
        switch (action.kind) {
          case 'add_node': return !model.nodes.has(action.id)
          case 'rename_node': return model.nodes.has(action.from) && !model.nodes.has(action.to)
          case 'remove_node':
          case 'set_label': return model.nodes.has(action.id)
          case 'add_edge': return true
          case 'remove_edge': return model.edges.some(edge => edge.from === action.from && edge.to === action.to)
        }
      }

      run(model: Model, real: Real): void {
        const action = this.action
        const op: FlowchartMutationOp = action.kind === 'remove_edge'
          ? { kind: 'remove_edge', id: `${action.from}->${action.to}` }
          : action.kind === 'set_label'
            ? { kind: 'set_label', target: action.id, label: action.label }
            : action
        const result = mutate(real.diagram, op)
        expect(result.ok).toBe(true)
        if (!result.ok) return
        real.diagram = result.value

        switch (action.kind) {
          // Labels are stored trimmed, as parsing them would (see above).
          case 'add_node':
            model.nodes.set(action.id, action.label.trim())
            break
          case 'rename_node': {
            const oldLabel = model.nodes.get(action.from)!
            model.nodes.delete(action.from)
            model.nodes.set(action.to, oldLabel === action.from ? action.to : oldLabel)
            for (const edge of model.edges) {
              if (edge.from === action.from) edge.from = action.to
              if (edge.to === action.from) edge.to = action.to
            }
            break
          }
          case 'remove_node':
            model.nodes.delete(action.id)
            model.edges = model.edges.filter(edge => edge.from !== action.id && edge.to !== action.id)
            break
          case 'set_label':
            model.nodes.set(action.id, action.label.trim())
            break
          case 'add_edge':
            if (!model.nodes.has(action.from)) model.nodes.set(action.from, action.from)
            if (!model.nodes.has(action.to)) model.nodes.set(action.to, action.to)
            model.edges.push({ from: action.from, to: action.to, label: action.label?.trim() || undefined })
            break
          case 'remove_edge': {
            const index = model.edges.findIndex(edge => edge.from === action.from && edge.to === action.to)
            model.edges.splice(index, 1)
            break
          }
        }
        assertConforms(model, real)
      }

      toString(): string {
        return JSON.stringify(this.action)
      }
    }

    const ids = fc.constantFrom('A', 'B', 'C', 'D', 'E', 'F')
    const labels = fc.array(fc.constantFrom(...'abc XYZ09'), { minLength: 1, maxLength: 8 }).map(parts => parts.join(''))
    const commandArbs = [
      fc.tuple(ids, labels).map(([id, label]) => new MutationCommand({ kind: 'add_node', id, label })),
      fc.tuple(ids, ids).map(([from, to]) => new MutationCommand({ kind: 'rename_node', from, to })),
      ids.map(id => new MutationCommand({ kind: 'remove_node', id })),
      fc.tuple(ids, labels).map(([id, label]) => new MutationCommand({ kind: 'set_label', id, label })),
      fc.tuple(ids, ids, fc.option(labels, { nil: undefined })).map(([from, to, label]) => new MutationCommand({ kind: 'add_edge', from, to, label })),
      fc.tuple(ids, ids).map(([from, to]) => new MutationCommand({ kind: 'remove_edge', from, to })),
    ]

    fc.assert(
      fc.property(
        fc.commands(commandArbs, { maxCommands: 30 }),
        commands => {
          fc.modelRun(() => ({
            model: {
              nodes: new Map([['A', 'A'], ['B', 'B']]),
              edges: [{ from: 'A', to: 'B', label: undefined }],
            },
            real: { diagram: flowchart('flowchart TD\n  A --> B') },
          }), commands)
        },
      ),
      fcParameters({ numRuns: 100 }),
    )
  })
})

describe('synthesizeFromGraph', () => {
  test('flowchart payload round-trips without canonicalSource', () => {
    const d = parse('flowchart TD\n  A[Alpha] --> B[Beta]')
    if (d.body.kind !== 'flowchart') throw new Error('x')
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      meta: d.meta,
      body: {
        kind: 'flowchart',
        graph: {
          direction: d.body.graph.direction,
          nodes: Object.fromEntries(d.body.graph.nodes),
          edges: d.body.graph.edges,
          subgraphs: d.body.graph.subgraphs,
        },
      },
    })
    expect(r.ok && r.value.canonicalSource.includes('A[Alpha] --> B[Beta]')).toBe(true)
  })
  test('sequence payload', () => {
    const r = synthesizeFromGraph({
      kind: 'sequence',
      body: {
        kind: 'sequence',
        participants: [
          { id: 'A', label: 'A', kind: 'participant' },
          { id: 'B', label: 'B', kind: 'participant' },
        ],
        messages: [{ from: 'A', to: 'B', text: 'Hi', style: 'sync' }],
        statements: [
          { kind: 'participant', ref: 0 },
          { kind: 'participant', ref: 1 },
          { kind: 'message', ref: 0 },
        ],
      },
    })
    expect(r.ok && r.value.canonicalSource.includes('A->>B: Hi')).toBe(true)
  })

  test('synthesizeFromGraph: nodes can be array-of-tuples too', () => {
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: [
            ['A', { id: 'A', label: 'A', shape: 'rectangle' }],
            ['B', { id: 'B', label: 'B', shape: 'rectangle' }],
          ],
          edges: [{ source: 'A', target: 'B', style: 'solid', hasArrowStart: false, hasArrowEnd: true }],
        },
      },
    })
    expect(r.ok && r.value.canonicalSource.includes('A --> B')).toBe(true)
  })

  test('synthesizeFromGraph: missing edges defaults to []', () => {
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { A: { id: 'A', label: 'A', shape: 'rectangle' } },
        } as never,
      },
    })
    expect(r.ok).toBe(true)
    if (!r.ok || r.value.body.kind !== 'flowchart') throw new Error('Expected Flowchart')
    expect([...r.value.body.graph.nodes.keys()]).toEqual(['A'])
    expect(r.value.body.graph.edges).toEqual([])
  })

  test('synthesizeFromGraph: invalid body.kind returns error', () => {
    const r = synthesizeFromGraph({ kind: 'flowchart', body: { kind: 'unknown' } } as never)
    expect(r.ok).toBe(false)
  })

  test('synthesizeFromGraph: cyclic subgraph does not stack-overflow', () => {
    const a: { id: string; children: unknown[] } = { id: 'a', children: [] }
    a.children.push(a)
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { N: { id: 'N', label: 'N', shape: 'rectangle' } },
          edges: [],
          subgraphs: [a] as never,
        },
      },
    })
    expect(r.ok).toBe(true)
  })

  test('synthesizeFromGraph: null subgraph elements are skipped (no TypeError)', () => {
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { N: { id: 'N', label: 'N', shape: 'rectangle' } },
          edges: [],
          subgraphs: [null, undefined, { id: 'G', label: 'G', nodeIds: ['N'] }] as never,
        },
      },
    })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    if (r.value.body.kind !== 'flowchart') throw new Error('x')
    expect(r.value.body.graph.subgraphs).toHaveLength(1)
    expect(r.value.body.graph.subgraphs[0]!.id).toBe('G')
  })

  test('synthesizeFromGraph: non-tuple Array entries are ignored (no "not an entry object")', () => {
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { N: { id: 'N', label: 'N', shape: 'rectangle' } },
          edges: [],
          classDefs: ['foo', 'bar'] as never, // not [k,v] tuples
          nodeStyles: [['ok', { fill: '#000' }], 'bad', null] as never,
        },
      },
    })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    if (r.value.body.kind !== 'flowchart') throw new Error('x')
    expect(r.value.body.graph.classDefs.size).toBe(0)
    expect(r.value.body.graph.nodeStyles.size).toBe(1)
  })

  test('synthesizeFromGraph: non-numeric / fractional linkStyle keys are silently dropped (not NaN)', () => {
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { A: { id: 'A', label: 'A', shape: 'rectangle' }, B: { id: 'B', label: 'B', shape: 'rectangle' } },
          edges: [{ source: 'A', target: 'B', style: 'solid', hasArrowStart: false, hasArrowEnd: true }],
          linkStyles: { abc: { stroke: 'red' }, '1.5': { stroke: 'blue' }, '0': { stroke: 'green' }, default: { stroke: 'gray' } } as never,
        },
      },
    })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    if (r.value.body.kind !== 'flowchart') throw new Error('x')
    const keys = [...r.value.body.graph.linkStyles.keys()]
    expect(keys.sort()).toEqual([0, 'default'] as never)
    expect(keys.some(k => typeof k === 'number' && Number.isNaN(k))).toBe(false)
  })

  test('synthesizeFromGraph: Map with non-string keys is coerced (lookup-by-string works)', () => {
    const m = new Map([[0, { fill: '#0f0' }] as [number, Record<string, string>]])
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { A: { id: 'A', label: 'A', shape: 'rectangle' } },
          edges: [],
          nodeStyles: m as never,
        },
      },
    })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    if (r.value.body.kind !== 'flowchart') throw new Error('x')
    // Lookup by string '0' should succeed even though the input Map used number 0.
    expect(r.value.body.graph.nodeStyles.get('0')).toEqual({ fill: '#0f0' })
  })

  test('synthesizeFromGraph: null/undefined style maps default to empty (no throw)', () => {
    // Kills the `input && typeof input === 'object'` short-circuit mutants:
    // if mutated to `||`, Object.entries(null) would throw.
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { A: { id: 'A', label: 'A', shape: 'rectangle' } },
          edges: [],
          classDefs: null as never,
          classAssignments: undefined as never,
          nodeStyles: 'not-an-object' as never,
          linkStyles: 42 as never,
        },
      },
    })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    if (r.value.body.kind !== 'flowchart') throw new Error('x')
    expect(r.value.body.graph.classDefs.size).toBe(0)
    expect(r.value.body.graph.classAssignments.size).toBe(0)
    expect(r.value.body.graph.nodeStyles.size).toBe(0)
    expect(r.value.body.graph.linkStyles.size).toBe(0)
  })

  test('synthesizeFromGraph: subgraphs as non-array becomes empty', () => {
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { A: { id: 'A', label: 'A', shape: 'rectangle' } },
          edges: [],
          subgraphs: null as never,
        },
      },
    })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    if (r.value.body.kind !== 'flowchart') throw new Error('x')
    expect(r.value.body.graph.subgraphs).toEqual([])
  })

  test('synthesizeFromGraph: subgraph with explicit label/nodeIds undefined → defaults', () => {
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { A: { id: 'A', label: 'A', shape: 'rectangle' } },
          edges: [],
          subgraphs: [{ id: 'G' } as never],
        },
      },
    })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    if (r.value.body.kind !== 'flowchart') throw new Error('x')
    expect(r.value.body.graph.subgraphs[0]!.label).toBe('G')
    expect(r.value.body.graph.subgraphs[0]!.nodeIds).toEqual([])
  })

  test('synthesizeFromGraph: style maps accept Map, Array and object wire representations', () => {
    // Plain object with numeric + 'default' keys
    const r1 = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { A: { id: 'A', label: 'A', shape: 'rectangle' }, B: { id: 'B', label: 'B', shape: 'rectangle' } },
          edges: [{ source: 'A', target: 'B', style: 'solid', hasArrowStart: false, hasArrowEnd: true }],
          linkStyles: { '0': { stroke: '#f00' }, default: { stroke: '#888' } },
        },
      },
    })
    expect(r1.ok && r1.value.canonicalSource.includes('linkStyle 0 stroke:#f00')).toBe(true)
    expect(r1.ok && r1.value.canonicalSource.includes('linkStyle default stroke:#888')).toBe(true)
    // Array-of-tuples
    const r2 = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { A: { id: 'A', label: 'A', shape: 'rectangle' }, B: { id: 'B', label: 'B', shape: 'rectangle' } },
          edges: [{ source: 'A', target: 'B', style: 'solid', hasArrowStart: false, hasArrowEnd: true }],
          nodeStyles: [['A', { fill: '#0f0' }]] as never,
        },
      },
    })
    expect(r2.ok && r2.value.canonicalSource.includes('style A fill:#0f0')).toBe(true)
    // Pre-built Map
    const r3 = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { A: { id: 'A', label: 'A', shape: 'rectangle' } },
          edges: [],
          classDefs: new Map([['hot', { fill: '#f00' }]]) as never,
        },
      },
    })
    expect(r3.ok && r3.value.canonicalSource.includes('classDef hot fill:#f00')).toBe(true)
  })

  test('REGRESSION: subgraph payload missing children (SDK shape) does not crash mutate/verify', () => {
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      body: {
        kind: 'flowchart',
        graph: {
          direction: 'TD',
          nodes: { A: { id: 'A', label: 'A', shape: 'rectangle' } },
          edges: [],
          // SDK-declared subgraph shape omits `children` — must be normalized.
          subgraphs: [{ id: 'G', label: 'G', nodeIds: ['A'] }] as never,
        },
      },
    })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    const f = asFlowchart(r.value)!
    expect(mutate(f, { kind: 'add_node', id: 'Z', label: 'Z' }).ok).toBe(true) // no crash
    expect(() => verifyMermaid(r.value)).not.toThrow()
  })

  test('REGRESSION: synthesizeFromGraph preserves styling maps', () => {
    const d = parse('flowchart TD\n  A --> B\n  classDef hot fill:#f00\n  class A hot\n  style B stroke:#0f0\n  linkStyle 0 stroke:#00f')
    if (d.body.kind !== 'flowchart') throw new Error('x')
    const g = d.body.graph
    const r = synthesizeFromGraph({
      kind: 'flowchart',
      meta: d.meta,
      body: {
        kind: 'flowchart',
        graph: {
          direction: g.direction,
          nodes: Object.fromEntries(g.nodes),
          edges: g.edges,
          subgraphs: g.subgraphs,
          classDefs: Object.fromEntries(g.classDefs),
          classAssignments: Object.fromEntries(g.classAssignments),
          nodeStyles: Object.fromEntries(g.nodeStyles),
          linkStyles: Object.fromEntries([...g.linkStyles].map(([k, v]) => [String(k), v])),
        },
      },
    })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    const out = r.value.canonicalSource
    expect(out).toContain('classDef hot fill:#f00')
    expect(out).toContain('class A hot')
    expect(out).toContain('style B stroke:#0f0')
    expect(out).toContain('linkStyle 0 stroke:#00f')
  })
})

describe('flowchart geometry tripwires (graphGeometryWarnings, the pass verify runs)', () => {
  // ELK never places a node off-canvas, on another node or outside its
  // subgraph, so on real layouts these stay silent; doctored layouts prove
  // each check can fire (a validator nothing can trigger is dead code).
  const d = parse('flowchart LR\n  A --> B\n  subgraph S\n    C\n  end\n  B --> C')
  if (d.body.kind !== 'flowchart') throw new Error('expected a flowchart body')
  const graph = d.body.graph
  const positioned = positionFamilyArtifact(d)!.positioned as PositionedGraph
  const node = (id: string) => positioned.nodes.find(n => n.id === id)!
  const moved = (id: string, box: Partial<PositionedGraph['nodes'][number]>): PositionedGraph =>
    ({ ...positioned, nodes: positioned.nodes.map(n => (n.id === id ? { ...n, ...box } : n)) })

  test('the real layout raises none', () => {
    expect(graphGeometryWarnings(positioned, graph)).toEqual([])
  })

  test('a node at negative x and y raises OFF_CANVAS on each axis', () => {
    expect(graphGeometryWarnings(moved('A', { x: -20, y: -20 }), graph)).toEqual([
      { code: 'OFF_CANVAS', target: 'A', axis: 'x' },
      { code: 'OFF_CANVAS', target: 'A', axis: 'y' },
    ])
  })

  test('a node laid on another raises NODE_OVERLAP with the shared area', () => {
    const a = node('A')
    expect(graphGeometryWarnings(moved('B', { x: a.x, y: a.y, width: a.width, height: a.height }), graph)).toEqual([
      { code: 'NODE_OVERLAP', a: 'A', b: 'B', areaPx: Math.round(a.width * a.height) },
    ])
  })

  test('a member outside its subgraph raises GROUP_BREACH', () => {
    const a = node('A')
    expect(graphGeometryWarnings(moved('C', { x: a.x, y: a.y + a.height + 400 }), graph))
      .toContainEqual({ code: 'GROUP_BREACH', group: 'S', member: 'C' })
  })
})

describe('verify', () => {
  test('clean flowchart ok', () => {
    expect(verifyMermaid('flowchart TD\n  A --> B').ok).toBe(true)
  })
  test('EMPTY_DIAGRAM', () => {
    const r = verifyMermaid('')
    expect(r.ok).toBe(false)
    expect(r.warnings.some(w => w.code === 'EMPTY_DIAGRAM')).toBe(true)
  })
  test('LABEL_OVERFLOW rendered-line count, reliable', () => {
    const r = verifyMermaid(`flowchart TD\n  A[${'X'.repeat(60)}] --> B`)
    expect(r.warnings).toContainEqual(expect.objectContaining({ code: 'LABEL_OVERFLOW', charCount: 60, limit: 40 }))
  })
  test('LABEL_OVERFLOW ignores <br/> markup: cap applies per rendered line', () => {
    // 60 source chars, but rendered as two 27-char lines — no warning.
    const r = verifyMermaid(`flowchart TD\n  A[${'X'.repeat(27)}<br/>${'Y'.repeat(27)}] --> B`)
    expect(r.warnings.some(w => w.code === 'LABEL_OVERFLOW')).toBe(false)
  })
  test('LABEL_OVERFLOW counts numeric entities as one rendered char', () => {
    // 10 words joined by &#160; — 75 source chars, 21 rendered chars.
    const label = Array.from({ length: 11 }, () => 'w').join('&#160;')
    const r = verifyMermaid(`flowchart TD\n  A[${label}] --> B`)
    expect(r.warnings.some(w => w.code === 'LABEL_OVERFLOW')).toBe(false)
  })
  test('LABEL_OVERFLOW still fires when one rendered line exceeds the cap', () => {
    const r = verifyMermaid(`flowchart TD\n  A[short<br/>${'X'.repeat(45)}] --> B`)
    expect(r.warnings).toContainEqual(expect.objectContaining({ code: 'LABEL_OVERFLOW', charCount: 45, limit: 40 }))
  })
  test('LABEL_OVERFLOW custom cap', () => {
    expect(verifyMermaid('flowchart TD\n  A[longish] --> B', { labelCharCap: 3 }).warnings.some(w => w.code === 'LABEL_OVERFLOW')).toBe(true)
  })
  test('no LABEL_OVERFLOW for short labels', () => {
    expect(verifyMermaid('flowchart TD\n  A --> B').warnings.some(w => w.code === 'LABEL_OVERFLOW')).toBe(false)
  })
  test('sequence verify EDGE_MISANCHORED impossible via parse (implicit declare); via long text LABEL_OVERFLOW fires', () => {
    expect(verifyMermaid(`sequenceDiagram\n  A->>B: ${'x'.repeat(60)}`).warnings.some(w => w.code === 'LABEL_OVERFLOW')).toBe(true)
  })
  test('suppress filter drops only the named codes', () => {
    const src = 'flowchart TD\n  A --> B\n  A --> B\n  C --> D\n  D --> C'
    const codes = (opts: Parameters<typeof verifyMermaid>[1]) => verifyMermaid(src, opts).warnings.map(w => w.code)
    expect(codes({})).toEqual(['DUPLICATE_EDGE', 'UNREACHABLE_NODE', 'UNREACHABLE_NODE'])
    expect(codes({ suppress: ['DUPLICATE_EDGE'] })).toEqual(['UNREACHABLE_NODE', 'UNREACHABLE_NODE'])
    expect(codes({ suppress: ['DUPLICATE_EDGE', 'UNREACHABLE_NODE'] })).toEqual([])
  })
  test('finite coordinates only', () => {
    const layout = verifyMermaid('flowchart TD\n  A --> B\n  B --> C').layout
    expect(layout.nodes.map(node => node.id).sort()).toEqual(['A', 'B', 'C'])
    expect(layout.edges).toHaveLength(2)
    const coordinates = [layout.bounds.w, layout.bounds.h, ...layout.nodes.flatMap(node => [node.x, node.y, node.w, node.h]), ...layout.edges.flatMap(edge => edge.path.flat())]
    for (const coordinate of coordinates) expect(Number.isFinite(coordinate)).toBe(true)
  })
  test('no seed field on layout', () => {
    expect('seed' in verifyMermaid('flowchart TD\n  A --> B').layout).toBe(false)
  })
  test('Tier 3 lint: duplicate edges are advisory warnings', () => {
    const r = verifyMermaid('flowchart TD\n  A --> B\n  A --> B')
    const dup = r.warnings.find(w => w.code === 'DUPLICATE_EDGE')
    expect(r.ok).toBe(true)
    expect(dup).toMatchObject({ code: 'DUPLICATE_EDGE', from: 'A', to: 'B' })
  })
  test('Tier 3 lint: nodes unreachable from entry roots are advisory warnings', () => {
    const r = verifyMermaid('flowchart TD\n  A --> B\n  C --> D\n  D --> C')
    expect(r.ok).toBe(true)
    expect(
      r.warnings
        .filter(w => w.code === 'UNREACHABLE_NODE')
        .map(w => w.node)
        .sort(),
    ).toEqual(['C', 'D'])
  })
})

describe('warning vocabulary', () => {
  test('LABEL_OVERFLOW is Tier 1', () => {
    expect(WARNING_TIER.LABEL_OVERFLOW).toBe('structural')
  })
  test('DUPLICATE_EDGE, UNREACHABLE_NODE, DECISION_BRANCH_UNLABELED, COMMENT_DROPPED, UNSUPPORTED_SYNTAX, and LOW_CONTRAST are Tier 3 lint', () => {
    expect(WARNING_TIER.DUPLICATE_EDGE).toBe('lint')
    expect(WARNING_TIER.UNREACHABLE_NODE).toBe('lint')
    expect(WARNING_TIER.DECISION_BRANCH_UNLABELED).toBe('lint')
    expect(WARNING_TIER.COMMENT_DROPPED).toBe('lint')
    expect(WARNING_TIER.UNSUPPORTED_SYNTAX).toBe('lint')
    expect(WARNING_TIER.LOW_CONTRAST).toBe('lint')
  })
})

describe('toFinite', () => {
  test('accepts finite', () => {
    expect(toFinite(3.14)).toBe(3.14 as never)
  })
  test('throws on NaN with informative message', () => {
    expect(() => toFinite(NaN)).toThrow(/expected a finite number, got NaN/)
  })
  test('throws on Infinity with informative message', () => {
    expect(() => toFinite(Infinity)).toThrow(/expected a finite number, got Infinity/)
  })
})

describe('asFlowchart / asSequence return null on the wrong family', () => {
  // An always-true conditional once went unnoticed
  // because tests went through `parse(...).body.kind` not through asFlowchart
  // on a non-flowchart input. These tests exercise the negative branch.
  test('asFlowchart returns null for sequence body', () => {
    expect(asFlowchart(parse('sequenceDiagram\n  A->>B: Hi'))).toBeNull()
  })
  test('asFlowchart returns null for structured Class body', () => {
    expect(asFlowchart(parse('classDiagram\n  A <|-- B'))).toBeNull()
  })
  test('asSequence returns null for flowchart body', () => {
    expect(asSequence(parse('flowchart TD\n  A --> B'))).toBeNull()
  })
  test('asSequence non-null for sequence with notes (BUILD-18: now structured-with-segments)', () => {
    expect(asSequence(parse('sequenceDiagram\n  A->>B: Hi\n  Note over A: thinking'))).not.toBeNull()
  })
  test('asSequence returns null for UN-segmentable sequence (unbalanced end → opaque fallback)', () => {
    // A stray `end` with no open block can't be cleanly segmented, so the
    // whole body stays opaque (the lossless v4 fallback) and asSequence is null.
    expect(asSequence(parse('sequenceDiagram\n  A->>B: Hi\n  end'))).toBeNull()
  })
})

describe('state diagrams narrow via asState (BUILD-19 contract)', () => {
  // BUILD-19: state owns a dedicated StateBody (no longer the flowchart body).
  // kind stays 'state'; body.kind is now 'state' and asState is the narrowing
  // path. asFlowchart MUST return null on a state diagram (the breaking flip).
  // Pin both halves so a regression to the flowchart projection is caught.
  const STATE_SRC = 'stateDiagram-v2\n  [*] --> Idle\n  Idle --> Running'

  test('parse keeps kind state with a dedicated state body; asFlowchart returns null', () => {
    const d = parse(STATE_SRC)
    expect(d.kind).toBe('state')
    expect(d.body.kind).toBe('state')
    expect(asFlowchart(d)).toBeNull()
  })

  test('asState narrows state and state-shaped ops mutate it', () => {
    const s = asState(parse(STATE_SRC))
    expect(s).not.toBeNull()
    const mutated = mutate(s!, { kind: 'add_transition', from: 'Running', to: '[*]' })
    expect(mutated.ok).toBe(true)
    if (!mutated.ok) return
    const verify = verifyMermaid(mutated.value)
    expect(verify.ok).toBe(true)
    const out = serializeMermaid(mutated.value)
    expect(out.startsWith('stateDiagram-v2')).toBe(true)
    expect(out).toContain('Running --> [*]')
    // Registry dispatch is by diagram kind: the rebuilt canonicalSource must
    // carry the state header and never go stale.
    expect(mutated.value.canonicalSource.startsWith('stateDiagram-v2')).toBe(true)
    expect(mutated.value.canonicalSource).toContain('Running --> [*]')
  })
})
