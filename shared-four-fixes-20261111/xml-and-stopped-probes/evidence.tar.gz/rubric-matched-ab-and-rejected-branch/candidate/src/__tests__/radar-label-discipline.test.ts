import { describe, expect, test } from 'bun:test'
import { parseRadarChart } from '../radar/parser.ts'
import { layoutRadarChart, RADAR_METRICS, RADAR_LABEL_METRICS } from '../radar/layout.ts'
import { guardLabelInk } from '../radar/renderer.ts'
import type { PositionedRadarAxis, PositionedRadarChart } from '../radar/types.ts'
import { measureTextWidth } from '../text-metrics.ts'
import { contrastRatio, wcagCssContrastRatio } from '../shared/color-math.ts'
import { renderMermaidSVG, verifyMermaid } from '../agent/index.ts'

// ============================================================================
// The reverse-flow label disciplines applied to radar (see
// docs/design/system/cross-family-aesthetics.md): budget wrap-compression (R4),
// radial clearance + pairwise de-collision (R1), leader lines (R2), knockout
// tick boxes (R5), WCAG-AA ink (R6), wrapped legend rows (R3), and grow-the-
// canvas containment. Each test is a geometry/structure invariant that fails
// when the corresponding fix is reverted.
// ============================================================================

const lines = (src: string): string[] => src.split('\n').map(l => l.trim()).filter(Boolean)
const layout = (src: string, visual = {}): PositionedRadarChart =>
  layoutRadarChart(parseRadarChart(lines(src)), {}, visual)

const LINE_H = RADAR_METRICS.axisFontSize * 1.3
const FONT = RADAR_METRICS.axisFontSize

test('fractional legend decorations preserve absolute row and text origins', () => {
  const source = '---\nconfig:\n  radar:\n    marginTop: 3.3\n    marginBottom: 11.1\n  themeVariables:\n    radar:\n      legendFontSize: 12\n      legendBoxSize: 31.01\n---\nradar-beta\ntitle First Title\naxis a["One"], b["Two"], c["Three"]\ncurve first["First legend with multiple words and wide 界"]{1,2,3}\ncurve second["Second\nThird"]{2,3,1}\ncurve third["Other"]{3,1,2}\nmax 5'
  const svg = renderMermaidSVG(source, { style: { roles: { node: { fontSize: 12, letterSpacing: 0.3 }, group: { fontSize: 12.1 } } } })
  const texts = [...svg.matchAll(/<text\b[^>]*\bclass="radar-legend-text"[^>]*>/g)]
  const swatches = [...svg.matchAll(/<rect\b[^>]*\bclass="radar-legend-swatch"[^>]*>/g)]
  expect(texts).toHaveLength(3)
  expect(swatches).toHaveLength(3)
  // These baseline coordinates challenge the half-cent rounding boundary,
  // independently of the new allocator's computed expectations.
  expect(texts[1]![0].match(/\by="([^"]*)"/)?.[1]).toBe('181.37')
  expect(swatches[2]![0].match(/\by="([^"]*)"/)?.[1]).toBe('205.97')
})
interface Box { left: number; right: number; top: number; bottom: number }
function axisBox(a: PositionedRadarAxis): Box {
  const w = a.labelWidth
  const h = a.lines.length * LINE_H
  const left = a.anchor === 'start' ? a.labelX : a.anchor === 'end' ? a.labelX - w : a.labelX - w / 2
  return { left, right: left + w, top: a.labelY - h / 2, bottom: a.labelY + h / 2 }
}
function overlaps(A: Box, B: Box, tol = 0.5): boolean {
  return A.left < B.right - tol && B.left < A.right - tol && A.top < B.bottom - tol && B.top < A.bottom - tol
}

/** Every overlapping pair among `boxes`, as `{ pair: [i, j] }`, so a failure
 *  names the colliding labels instead of reporting a bare `false`. */
function overlappingPairs(boxes: readonly Box[]): Array<{ pair: [number, number] }> {
  const out: Array<{ pair: [number, number] }> = []
  for (let i = 0; i < boxes.length; i++) {
    for (let j = i + 1; j < boxes.length; j++) if (overlaps(boxes[i]!, boxes[j]!)) out.push({ pair: [i, j] })
  }
  return out
}
function tickBox(t: PositionedRadarChart['tickLabels'][number]): Box {
  return { left: t.x - t.w / 2, right: t.x + t.w / 2, top: t.y - t.h / 2, bottom: t.y + t.h / 2 }
}

// A dataset whose bottom axis reaches the outer ring and whose labels are long.
const DEMO = `radar-beta
  title Model capability profile
  axis speed["Speed"], acc["Operational cost efficiency"], ctx["Context-window utilisation"]
  axis safety["Safety and alignment robustness"], lat["Latency"], tp["Throughput per dollar"]
  curve a["Model A, frontier release 2026"]{4, 3, 2, 4, 3, 5}
  curve b["Model B"]{3, 5, 4, 3, 5, 3}
  curve c["Model C baseline"]{2, 4, 3, 5, 4, 2}
  max 5`

// Twenty-four tight axes — naive placement overlaps (measured: 4 collisions);
// only the pairwise de-collision pass separates them.
const DENSE = `radar-beta
${Array.from({ length: 24 }, (_v, i) => `  axis a${i}["Metric ${i}"]`).join('\n')}
  curve x{${Array.from({ length: 24 }, () => '3').join(', ')}}
  max 5`

describe('radar label discipline — reverse-flow lessons', () => {
  test('R5 — admitted ring labels have disjoint knockout boxes painted before text', () => {
    const chart = layout(DEMO, { tickLabels: true })
    expect(chart.tickLabels.length).toBe(5)
    for (const t of chart.tickLabels) {
      expect(t.w).toBeGreaterThan(0)
      expect(t.h).toBeGreaterThan(0)
    }
    const svg = renderMermaidSVG(`---\nconfig:\n  radar:\n    tickLabels: true\n---\n${DEMO}`)
    expect((svg.match(/class="radar-tick-box"/g) ?? []).length).toBe(5)
    expect(svg.lastIndexOf('class="radar-tick-box"')).toBeLessThan(svg.indexOf('class="radar-tick-label"'))

    const dense = layout('radar-beta\n axis a, b, c, d\n curve x{1,2,3,4}\n ticks 64\n max 64', { tickLabels: true })
    expect(dense.tickLabels.length).toBeLessThan(64)
    expect(dense.tickLabels.at(-1)?.text).toBe('64')
    expect(overlappingPairs(dense.tickLabels.map(tickBox))).toEqual([])
  })

  test('R6 — derived label ink is contrast-guarded without repainting authored color', () => {
    const guarded = guardLabelInk('#9a9a9a', '#ffffff', '#111111')
    expect(guarded).not.toBe('#9a9a9a')
    expect(contrastRatio(guarded, '#ffffff')!).toBeGreaterThanOrEqual(4.5)
    // An already-AA color is preserved; uncertainty and translucent low
    // contrast are never treated as proof of AA.
    expect(guardLabelInk('#111111', '#ffffff', '#000000')).toBe('#111111')
    expect(guardLabelInk('var(--_text)', '#ffffff', '#000000')).toBe('#000000')
    const alphaGuarded = guardLabelInk('rgba(0,0,0,0.1)', '#ffffff', '#111111')
    expect(wcagCssContrastRatio(alphaGuarded, '#ffffff')!).toBeGreaterThanOrEqual(4.5)

    const svg = renderMermaidSVG(DEMO)
    const defaultInk = svg.match(/class="radar-axis-label"[^>]* fill="([^"]+)"/)?.[1]
    expect(defaultInk).toBeDefined()
    expect(defaultInk).not.toBe('var(--_line)')
    expect(wcagCssContrastRatio(defaultInk!, '#ffffff')!).toBeGreaterThanOrEqual(4.5)

    const authored = `---
config:
  themeVariables:
    radar:
      axisColor: "#dddddd"
---
${DEMO}`
    const authoredSvg = renderMermaidSVG(authored)
    expect(authoredSvg).toMatch(/class="radar-axis-label"[^>]* fill="#dddddd"/)
    expect(verifyMermaid(authored).warnings).toContainEqual(expect.objectContaining({
      code: 'LOW_CONTRAST',
      field: 'themeVariables.radar.axisColor',
      foreground: '#dddddd',
      background: '#FFFFFF',
      minimum: 4.5,
    }))
    // A transparent SVG has no final page paint: the host backdrop is unknown,
    // so verification must not claim a contrast ratio against the fallback bg.
    expect(verifyMermaid(authored, { renderOptions: { transparent: true } }).warnings)
      .not.toContainEqual(expect.objectContaining({ code: 'LOW_CONTRAST' }))
  })

  test('R4 — long axis labels wrap to a width budget (and stay within the cap)', () => {
    const chart = layout(DEMO)
    const acc = chart.axes.find(a => a.id === 'acc')!
    expect(acc.lines.length).toBeGreaterThanOrEqual(2)
    for (const a of chart.axes) {
      for (const line of a.lines) {
        expect(measureTextWidth(line, FONT, 500)).toBeLessThanOrEqual(RADAR_LABEL_METRICS.axisLabelMaxWidth + 0.5)
      }
    }
  })

  test('R4 — hard-wrapped tokens retain every authored grapheme and accessible label', () => {
    const authored = 'OperationalCostEfficiency'
    const source = `radar-beta\n axis a["${authored}"], b, c, d\n curve x{1,2,3,4}\n max 5`
    const axis = layout(source).axes[0]!
    const reconstructed = axis.lines
      .map((line, index) => index < axis.lines.length - 1 && line.endsWith('-') ? line.slice(0, -1) : line)
      .join('')
    expect(reconstructed).toBe(authored)
    expect(axis.label).toBe(authored)
    expect(renderMermaidSVG(source)).toContain(`aria-label="${authored}"`)
  })

  test('R1 (clearance) — the straight-down axis label clears the outer ring + dot', () => {
    const chart = layout(DEMO)
    const bottom = chart.axes[3]! // n=6, index 3 → 180° (bottom); curve c reaches max here
    const box = axisBox(bottom)
    // Nearest label edge sits at least a dot-radius below the outer ring.
    expect(box.top - chart.cy).toBeGreaterThanOrEqual(chart.radius + RADAR_METRICS.dotRadius)
  })

  test('R1 (de-collision) — no two axis-label boxes overlap, including the maximum axis count', () => {
    const maxAxes = `radar-beta\n${Array.from({ length: 256 }, (_v, i) => ` axis a${i}["Metric ${i}"]`).join('\n')}\n max 5`
    for (const [name, chart] of [['DEMO', layout(DEMO)], ['DENSE', layout(DENSE)], ['256 axes', layout(maxAxes)]] as const) {
      expect({ chart: name, overlapping: overlappingPairs(chart.axes.map(axisBox)) }).toEqual({ chart: name, overlapping: [] })
    }
  })

  test('R2 — relocated labels get a leader line with finite endpoints', () => {
    const chart = layout(DEMO)
    const leaders = chart.axes.filter(a => a.leader)
    expect(leaders.length).toBeGreaterThan(0)
    for (const a of leaders) {
      const l = a.leader!
      for (const v of [l.x1, l.y1, l.x2, l.y2]) expect(Number.isFinite(v)).toBe(true)
    }
    const svg = renderMermaidSVG(DEMO)
    expect(svg).toContain('class="radar-leader"')
  })

  test('R5 — tick knockout boxes use the exact resolved style weight', () => {
    const source = `---
config:
  radar:
    tickLabels: true
---
radar-beta
  axis a, b, c, d
  curve x{1,2,3,4}
  max 5`
    const svg = renderMermaidSVG(source, { style: 'accessible-high-contrast' })
    const boxes = [...svg.matchAll(/class="radar-tick-box"[^>]*\swidth="([^"]+)"/g)]
    const labels = [...svg.matchAll(/class="radar-tick-label"[^>]*font-size="([^"]+)" font-weight="([^"]+)"[^>]*>([^<]+)<\/text>/g)]
    const endpointBox = boxes.at(-1)
    const endpointLabel = labels.at(-1)
    expect(endpointLabel?.[3]).toBe('5')
    expect(endpointLabel?.[2]).toBe('700')
    const expectedWidth = measureTextWidth('5', Number(endpointLabel?.[1]), Number(endpointLabel?.[2]))
      + RADAR_LABEL_METRICS.tickBoxPadX * 2
    expect(Number(endpointBox?.[1])).toBe(Math.round(expectedWidth * 100) / 100)
  })

  test('R3 — legend labels wrap and rows are reserved without overlap', () => {
    const chart = layout(DEMO)
    const longItem = chart.legend.find(i => i.label.startsWith('Model A'))!
    expect(longItem.lines.length).toBeGreaterThanOrEqual(2)
    // Rows are laid out top-to-bottom; the union of the swatch and measured
    // multi-line text box never overlaps the following row.
    const sorted = [...chart.legend].sort((a, b) => a.y - b.y)
    const rowBox = (item: typeof sorted[number]): Box => {
      const textHeight = item.lines.length * chart.typography.legendFontSize * 1.2
      return {
        left: Math.min(item.x, item.textX),
        right: Math.max(item.x + item.swatchSize, item.textX),
        top: Math.min(item.y, item.textY - textHeight / 2),
        bottom: Math.max(item.y + item.swatchSize, item.textY + textHeight / 2),
      }
    }
    const adjacentOverlaps = sorted.slice(1).flatMap((item, i) => overlaps(rowBox(sorted[i]!), rowBox(item)) ? [{ pair: [i, i + 1] }] : [])
    expect(adjacentOverlaps).toEqual([])
  })

  test('grow-the-canvas — every axis-label box stays inside the canvas bounds', () => {
    for (const chart of [layout(DEMO), layout(DENSE)]) {
      for (const a of chart.axes) {
        const b = axisBox(a)
        expect(b.left).toBeGreaterThanOrEqual(-0.5)
        expect(b.top).toBeGreaterThanOrEqual(-0.5)
        expect(b.right).toBeLessThanOrEqual(chart.width + 0.5)
        expect(b.bottom).toBeLessThanOrEqual(chart.height + 0.5)
      }
    }
  })

  test('determinism — identical input yields byte-identical geometry', () => {
    expect(JSON.stringify(layout(DEMO, { tickLabels: true })))
      .toBe(JSON.stringify(layout(DEMO, { tickLabels: true })))
  })
})
