// Loop 7 bug 3.5: pathfinder determinism regression guard.
//
// The plan called for a 10-run byte-identity check on a fixture with multiple
// parallel edges. Probing the current code revealed the pathfinder IS already
// deterministic across 10 runs (probably because the A* priority queue uses
// stable index-based tie-breaks and the Set/Map iteration order in V8/Bun is
// insertion-ordered). The fix is therefore documented as a regression guard
// rather than a behaviour change — if anyone introduces a tie-break that
// depends on iteration of an unordered structure or on Math.random / Date.now,
// this test will catch it.

import { describe, expect, it } from 'bun:test'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { renderMermaidASCII } from '../ascii/index.ts'

const CORPUS_PATH = join(import.meta.dir, '..', '..', 'eval', 'mermaid-docs-corpus', 'corpus.json')

interface CorpusEntry {
  family: string
  source: string
  origin: string
  index: number
}

function loadCorpus(): CorpusEntry[] {
  return existsSync(CORPUS_PATH) ? JSON.parse(readFileSync(CORPUS_PATH, 'utf8')) : []
}

const EXPECTED_CORPUS_RENDERED = 270
const EXPECTED_CORPUS_ASCII_ERRORS = [
  // architecture:syntax/architecture.md:1–3 rendered as of the align
  // acceptance (upstream v11.16.0 align directives parse and render).
  // Gantt index 6 now renders an explicit empty template. Index 10 ends a task with an
  // inline `%% not yet official` comment that even upstream only renders via
  // wall-clock fallback (GANTT_BAD_DATE) — see eval/mermaid-gantt-bench e9.
  'gantt:syntax/gantt.md:10',
  // timeline:syntax/timeline.md:5 rendered as of the upstream-parity fixes
  // (direction tokens after the timeline header are accepted and ignored).
]

function corpusKey(entry: CorpusEntry): string {
  return `${entry.family}:${entry.origin}:${entry.index}`
}

function asciiOutcome(source: string): { ok: true; hash: string; length: number } | { ok: false; error: string } {
  try {
    const out = renderMermaidASCII(source)
    return { ok: true, hash: createHash('sha256').update(out).digest('hex'), length: out.length }
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) }
  }
}

const FIXTURES: Array<{ name: string; src: string }> = [
  {
    name: 'fan-out fan-in (parallel edges)',
    src: `graph LR
  A --> B
  A --> C
  A --> D
  B --> E
  C --> E
  D --> E
  A --> E
`,
  },
  {
    name: 'cross-pattern routing (forces tie-break choices)',
    src: `graph TD
  A --> C
  A --> D
  B --> C
  B --> D
`,
  },
  {
    name: 'self-and-bidirectional edges',
    src: `graph LR
  A --> B
  B --> A
  A --> C
  C --> A
`,
  },
]

describe('ASCII full-corpus determinism', () => {
  // One test per family keeps each unit of work well inside the per-test
  // budget when the suite runs with `--parallel` on a shared runner, while the
  // corpus-wide inventory below still pins the rendered/error totals.
  const corpus = loadCorpus()
  const families = [...new Set(corpus.map(entry => entry.family))].sort()

  it('the corpus inventory is complete and internally consistent', () => {
    expect(corpus.length).toBeGreaterThan(200)
    expect(corpus.length - EXPECTED_CORPUS_ASCII_ERRORS.length).toBe(EXPECTED_CORPUS_RENDERED)
    const keys = new Set(corpus.map(corpusKey))
    for (const key of EXPECTED_CORPUS_ASCII_ERRORS) expect(keys.has(key), key).toBe(true)
  })

  for (const family of families) {
    it(`${family}: every mermaid-js docs corpus entry has a stable ASCII outcome across repeated runs`, () => {
      const unstable: Array<{ origin: string; index: number; outcomes: ReturnType<typeof asciiOutcome>[] }> = []
      const errors: string[] = []
      for (const entry of corpus.filter(candidate => candidate.family === family)) {
        const outcomes = [asciiOutcome(entry.source), asciiOutcome(entry.source), asciiOutcome(entry.source)]
        if (!outcomes.every(o => o.ok)) errors.push(corpusKey(entry))
        if (new Set(outcomes.map(o => JSON.stringify(o))).size !== 1) {
          unstable.push({ origin: entry.origin, index: entry.index, outcomes })
        }
      }
      expect(errors.sort()).toEqual(EXPECTED_CORPUS_ASCII_ERRORS.filter(key => key.startsWith(`${family}:`)))
      expect(unstable).toEqual([])
    })
  }
})

describe('ASCII pathfinder determinism', () => {
  for (const fx of FIXTURES) {
    it(`renders ${fx.name} byte-identically across 10 runs`, () => {
      const hashes = new Set<string>()
      for (let i = 0; i < 10; i++) {
        const out = renderMermaidASCII(fx.src, { useAscii: false })
        hashes.add(createHash('sha256').update(out).digest('hex'))
      }
      expect(hashes.size).toBe(1)
    })
  }

  it('ASCII mode also stays deterministic', () => {
    const src = FIXTURES[0]!.src
    const hashes = new Set<string>()
    for (let i = 0; i < 10; i++) {
      const out = renderMermaidASCII(src, { useAscii: true })
      hashes.add(createHash('sha256').update(out).digest('hex'))
    }
    expect(hashes.size).toBe(1)
  })
})
