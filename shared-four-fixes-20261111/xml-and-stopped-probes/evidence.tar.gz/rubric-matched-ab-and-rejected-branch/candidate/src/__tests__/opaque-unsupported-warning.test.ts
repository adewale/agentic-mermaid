// Systemic silent-opaque signal: a non-empty opaque body means the structured
// parser met syntax it does not model and preserved the diagram verbatim, so
// the `as*` narrower returns null and typed mutation is unavailable. Before
// this, only flowchart and quadrant announced that; the other ten families
// fell opaque silently. verify.ts now emits a generic UNSUPPORTED_SYNTAX
// (`<family>_opaque`) for any non-empty opaque body that isn't already flagged
// by a more specific warning.

import { describe, expect, test } from 'bun:test'
import { parseRegisteredMermaid as parseMermaid, renderMermaidSVG, serializeMermaid, verifyMermaid } from '../agent/index.ts'
import { WARNING_SEVERITY, WARNING_TIER } from '../agent/types.ts'

// Each source is valid-enough to parse but uses a construct the structured
// parser does not model, so it lands on the opaque path.
const OPAQUE_BY_FAMILY: Record<string, string> = {
  class: 'classDiagram\n  class `"Box`', // leading quote cannot be written as a portable Class identity
  xychart: 'xychart-beta\n  curve basis\n  bar [1, 2, 3]', // unmodeled curve directive
  pie: 'pie\n  Dogs : 40\n  Cats : 30', // unquoted labels (Mermaid requires quotes)
  sequence: 'sequenceDiagram\n  A->>B: hi\n  end', // unmatched block terminator
  timeline: 'timeline EXTRA\n  2026 : Event', // diagnosed unsupported header suffix
  journey: 'journey EXTRA\n  Wake: 3: Me', // unmodeled header suffix
  architecture: 'architecture-beta\n  title First\n  title Second\n  service api(server)[API]',
  gantt: 'gantt LR\n  Task :t1, 2026-01-01, 1d', // unmodeled header suffix
  radar: 'radar-beta\n  axis a, b, c\n  curve x{1,2,3}\n  frobnicate every axis', // unmodeled statement
  sankey: 'sankey-beta\n  A,B,10\n  B,A,2', // cycle: rejected by the layered layout, preserved losslessly
}

// These fixtures are valid Mermaid syntax that the public renderer supports;
// XYChart's unknown statement is preserved opaquely but now fails rendering.
// The remaining fixtures deliberately exercise malformed/header-tolerance
// preservation and therefore are not required to render as their loose family.
const RENDERABLE_OPAQUE_FAMILIES = new Set(['class', 'architecture'])

describe('opaque bodies announce UNSUPPORTED_SYNTAX instead of falling silent', () => {
  for (const [family, source] of Object.entries(OPAQUE_BY_FAMILY)) {
    test(`${family}: unmodeled syntax → opaque body carries a <family>_opaque warning`, () => {
      const p = parseMermaid(source)
      expect(p.ok).toBe(true)
      if (!p.ok) return
      expect(p.value.body.kind).toBe('opaque')

      // Opaque is a lossless source-preservation contract, not merely a body
      // tag. Serialization may add the canonical terminal newline, but cannot
      // change any authored token; reparsing must stay opaque and idempotent.
      const canonical = serializeMermaid(p.value)
      expect(canonical).toBe(source + '\n')
      const reparsed = parseMermaid(canonical)
      expect(reparsed.ok).toBe(true)
      if (!reparsed.ok) return
      expect(reparsed.value.body.kind).toBe('opaque')
      expect(serializeMermaid(reparsed.value)).toBe(canonical)
      if (RENDERABLE_OPAQUE_FAMILIES.has(family)) {
        expect(() => renderMermaidSVG(canonical)).not.toThrow()
      } else if (family === 'xychart') {
        expect(() => renderMermaidSVG(canonical)).toThrow('Unrecognized XYChart line: "curve basis"')
      }

      const v = verifyMermaid(p.value)
      const unsupported = v.warnings.filter(w => w.code === 'UNSUPPORTED_SYNTAX')
      expect(unsupported.length).toBeGreaterThanOrEqual(1)
      const syntax = family === 'class' ? 'class_id' : family === 'timeline' ? 'timeline_header_direction' : family === 'sequence' ? 'sequence_block_boundary' : `${family}_opaque`
      expect(unsupported.some(w => 'syntax' in w && w.syntax === syntax)).toBe(true)
      if (family === 'xychart' || family === 'sequence') {
        expect(v.ok).toBe(false)
        expect(v.warnings.map(warning => warning.code)).toContain('RENDER_FAILED')
      }
    })
  }

  test('promoted State/ER constructs remain structured instead of satisfying a stale opaque expectation', () => {
    for (const source of ['stateDiagram-v2\n  state P {\n    a --> b\n    --\n    c --> d\n  }', 'erDiagram\n  CUSTOMER:::highlight ||--o{ ORDER : places']) {
      const parsed = parseMermaid(source)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) continue
      expect(parsed.value.body.kind).not.toBe('opaque')
      expect(verifyMermaid(parsed.value).warnings.some(w => w.code === 'UNSUPPORTED_SYNTAX' && 'syntax' in w && w.syntax.endsWith('_opaque'))).toBe(false)
    }
  })

  test('it is a lint that never flips verify.ok', () => {
    expect(WARNING_TIER.UNSUPPORTED_SYNTAX).toBe('lint')
    expect(WARNING_SEVERITY.UNSUPPORTED_SYNTAX).toBe('warning')
    const p = parseMermaid(OPAQUE_BY_FAMILY.class!)
    expect(p.ok && verifyMermaid(p.value).ok).toBe(true)
  })

  test('a structured (non-opaque) body carries no _opaque warning', () => {
    const p = parseMermaid('classDiagram\n  class A\n  class B\n  A <|-- B')
    expect(p.ok).toBe(true)
    if (!p.ok) return
    expect(p.value.body.kind).toBe('class')
    const opaqueFlags = verifyMermaid(p.value).warnings.filter(w => w.code === 'UNSUPPORTED_SYNTAX' && 'syntax' in w && w.syntax.endsWith('_opaque'))
    expect(opaqueFlags).toEqual([])
  })

  test('rendered-but-source-preserved flowchart metadata stays honest; quadrant keeps its specific warning', () => {
    // A safe URL with an unmodeled target remains losslessly opaque and carries
    // a construct-specific warning rather than silently dropping `_blank`.
    const flow = parseMermaid('flowchart TD\n  A --> B\n  click A "https://x" _blank')
    expect(flow.ok).toBe(true)
    if (flow.ok) {
      const codes = verifyMermaid(flow.value).warnings.filter(w => w.code === 'UNSUPPORTED_SYNTAX')
      expect(codes.some(w => 'syntax' in w && w.syntax === 'flowchart_opaque')).toBe(false)
      expect(codes.some(w => 'syntax' in w && w.syntax === 'flowchart_interaction_directive')).toBe(true)
    }
    // Quadrant point-style metadata → quadrant_point_style_metadata, not
    // quadrant_opaque.
    const quad = parseMermaid('quadrantChart\n  title Q\n  x-axis Low --> High\n  A: [0.3, 0.4]:::c')
    expect(quad.ok).toBe(true)
    if (quad.ok) {
      const codes = verifyMermaid(quad.value).warnings.filter(w => w.code === 'UNSUPPORTED_SYNTAX')
      expect(codes.some(w => 'syntax' in w && w.syntax === 'quadrant_opaque')).toBe(false)
      expect(codes.some(w => 'syntax' in w && w.syntax === 'quadrant_point_style_metadata')).toBe(true)
    }
  })
})
