import { describe, expect, test } from 'bun:test'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

import { layoutGitGraph } from '../gitgraph/layout.ts'
import { layoutMindmap } from '../mindmap/layout.ts'
import type { MindmapNode, MindmapShape } from '../mindmap/types.ts'
import { getStyle, renderMermaidASCII, renderMermaidSVG, verifyNoExternalRefs } from '../index.ts'
import { asGitGraph, asMindmap, layoutMermaid, parseRegisteredMermaid as parseMermaid, serializeMermaid, verifyMermaid } from '../agent/index.ts'
import { visualWidth } from '../ascii/width.ts'
import { audit as auditSvgOverlaps } from '../../eval/overlap-audit/audit.ts'

const CORPUS = join(import.meta.dir, '..', '..', 'eval', 'mindmap-gitgraph-content-corpus')

type Expected = {
  nodeCount?: number
  rootChildren?: number
  layout?: 'central' | 'tidy-tree'
  labels?: string[]
  terminalText: string[]
  shapes?: MindmapShape[]
  icons?: string[]
  classes?: string[]
  commitCount?: number
  branchCount?: number
  direction?: 'LR' | 'TB' | 'BT'
  commitIds?: string[]
  branches?: string[]
  tags?: string[]
  svgText?: string[]
  parentCount?: number
  parentRelations?: Record<string, string[]>
  branchLaneOrder?: string[]
  cherrySource?: string
  cherryParent?: string
  commitLabelFontSize?: number
  rotateCommitLabel?: boolean
  warningCodes: string[]
}
type CorpusCase = {
  id: string
  family: 'mindmap' | 'gitgraph'
  file: string
  scenario: string
  sources: string[]
  expect: Expected
}
type Manifest = { cases: CorpusCase[] }

const manifest = JSON.parse(readFileSync(join(CORPUS, 'manifest.json'), 'utf8')) as Manifest
const sourceFor = (entry: CorpusCase): string => readFileSync(join(CORPUS, entry.file), 'utf8')
const flattenMindmap = (node: MindmapNode): MindmapNode[] =>
  [node, ...node.children.flatMap(flattenMindmap)]
const plainSvgText = (svg: string): string => svg
  .replace(/<\/text>/g, ' ')
  .replace(/<tspan\b[^>]*\bdy="[^"]*"[^>]*>/g, ' ')
  .replace(/<[^>]+>/g, '')
  .replaceAll('&amp;', '&').replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&quot;', '"').replaceAll('&#39;', "'")
  .replace(/\s+/g, ' ').trim()

describe('Mindmap/GitGraph popularity-weighted real-content corpus', () => {

  for (const entry of manifest.cases) {
    test(`${entry.id} preserves structure, family geometry, SVG safety, and terminal content`, () => {
      const source = sourceFor(entry)
      const parsed = parseMermaid(source)
      expect(parsed.ok, entry.id).toBe(true)
      if (!parsed.ok) return
      expect(parsed.value.kind).toBe(entry.family)

      const verified = verifyMermaid(source)
      expect(verified.ok, entry.id).toBe(true)
      expect(verified.warnings.map(warning => warning.code) as string[], entry.id).toEqual(entry.expect.warningCodes)
      expect(verified.layout.nodes.length, `${entry.id}: truthful public layout`).toBeGreaterThan(0)

      const canonical = serializeMermaid(parsed.value)
      const reparsed = parseMermaid(canonical)
      expect(reparsed.ok, entry.id).toBe(true)
      if (reparsed.ok) expect(serializeMermaid(reparsed.value)).toBe(canonical)

      if (entry.family === 'mindmap') {
        const narrowed = asMindmap(parsed.value)
        expect(narrowed, entry.id).not.toBeNull()
        if (!narrowed) return
        const authoredNodes = flattenMindmap(narrowed.body.root)
        expect(authoredNodes).toHaveLength(entry.expect.nodeCount!)
        expect(narrowed.body.root.children).toHaveLength(entry.expect.rootChildren!)
        for (const label of entry.expect.labels ?? []) {
          expect(authoredNodes.some(node => node.label === label), `${entry.id}: ${label}`).toBe(true)
        }
        if (entry.expect.shapes) expect([...new Set(authoredNodes.map(node => node.shape))].sort()).toEqual([...entry.expect.shapes].sort())
        if (entry.expect.icons) expect(authoredNodes.flatMap(node => node.icon ? [node.icon] : [])).toEqual(entry.expect.icons)
        if (entry.expect.classes) expect(authoredNodes.flatMap(node => node.className ? [node.className] : [])).toEqual(entry.expect.classes)
        const positioned = layoutMindmap(narrowed.body, {
          layout: entry.expect.layout === 'tidy-tree' ? 'tidy-tree' : 'radial',
        })
        expect(positioned.nodes).toHaveLength(entry.expect.nodeCount!)
        expect(positioned.edges).toHaveLength(entry.expect.nodeCount! - 1)
        const nonRootSides = new Set(positioned.nodes.filter(node => node.depth > 0).map(node => node.side))
        if (entry.expect.layout === 'tidy-tree') expect(nonRootSides).toEqual(new Set(['right']))
        else expect(nonRootSides).toEqual(new Set(['left', 'right']))
      } else {
        const narrowed = asGitGraph(parsed.value)
        expect(narrowed, entry.id).not.toBeNull()
        if (!narrowed) return
        expect(narrowed.body.commits.map(commit => commit.id)).toEqual(entry.expect.commitIds!)
        expect(new Set(narrowed.body.branches.map(branch => branch.name))).toEqual(new Set(entry.expect.branches!))
        expect(narrowed.body.direction).toBe(entry.expect.direction!)
        const tags = new Set(narrowed.body.commits.flatMap(commit => commit.tags))
        for (const tag of entry.expect.tags ?? []) expect(tags.has(tag), `${entry.id}: tag ${tag}`).toBe(true)
        const parentCount = narrowed.body.commits.reduce((sum, commit) => sum + commit.parents.length, 0)
        expect(parentCount).toBe(entry.expect.parentCount!)
        const positioned = layoutGitGraph(narrowed.body)
        expect(positioned.commits).toHaveLength(entry.expect.commitCount!)
        expect(positioned.edges).toHaveLength(entry.expect.parentCount!)
        expect(positioned.branches).toHaveLength(entry.expect.branchCount!)
        for (const [commitId, parents] of Object.entries(entry.expect.parentRelations ?? {})) {
          const commit = narrowed.body.commits.find(candidate => candidate.id === commitId)
          expect(commit?.parents, `${entry.id}: parents of ${commitId}`).toEqual(parents)
          for (const parent of parents) {
            expect(positioned.edges.some(edge => edge.from === parent && edge.to === commitId), `${entry.id}: ${parent} -> ${commitId}`).toBe(true)
          }
        }
        if (entry.expect.branchLaneOrder) {
          expect([...positioned.branches].sort((a, b) => a.lane - b.lane).map(branch => branch.name)).toEqual(entry.expect.branchLaneOrder)
        }
        const bySequence = [...positioned.commits].sort((a, b) => a.sequence - b.sequence)
        const first = bySequence[0]!
        const last = bySequence.at(-1)!
        if (entry.expect.direction === 'LR') expect(last.x).toBeGreaterThan(first.x)
        if (entry.expect.direction === 'TB') expect(last.y).toBeGreaterThan(first.y)
        if (entry.expect.direction === 'BT') expect(last.y).toBeLessThan(first.y)
        if (entry.expect.cherrySource) {
          const cherry = narrowed.body.commits.find(commit => commit.source === 'cherry-pick')
          expect(cherry?.cherrySource).toBe(entry.expect.cherrySource)
          expect(cherry?.cherryParent).toBe(entry.expect.cherryParent)
        }
        if (entry.expect.commitLabelFontSize) {
          const frontmatter = narrowed.meta.frontmatter as {
            themeVariables?: { commitLabelFontSize?: number }
            gitGraph?: { rotateCommitLabel?: boolean }
          } | undefined
          expect(frontmatter?.themeVariables?.commitLabelFontSize).toBe(entry.expect.commitLabelFontSize)
          expect(frontmatter?.gitGraph?.rotateCommitLabel).toBe(entry.expect.rotateCommitLabel)
        }
      }

      const svg = renderMermaidSVG(source, { embedFontImport: false })
      expect(svg).toContain('<svg')
      expect(renderMermaidSVG(source, { embedFontImport: false })).toBe(svg)
      expect(verifyNoExternalRefs(svg)).toEqual({ ok: true, refs: [] })
      expect(auditSvgOverlaps(svg), `${entry.id}: rendered overlap audit`).toEqual([])
      const svgText = plainSvgText(svg)
      for (const sentinel of entry.expect.svgText ?? entry.expect.labels ?? []) {
        // Positioned soft breaks may fall inside a CJK word. Preserve exact
        // characters while ignoring only layout whitespace in this census.
        expect(svgText.replace(/\s+/g, ''), `${entry.id}: SVG text ${sentinel}`).toContain(sentinel.replace(/\s+/g, ''))
      }
      const terminalWidth = entry.family === 'mindmap' ? 100 : 120
      const terminal = renderMermaidASCII(source, { targetWidth: terminalWidth, colorMode: 'none' })
      for (const sentinel of entry.expect.terminalText) {
        expect(terminal, `${entry.id}: terminal text ${sentinel}`).toContain(sentinel)
      }
      expect(Math.max(...terminal.split('\n').map(visualWidth))).toBeLessThanOrEqual(terminalWidth)
    })
  }

  test('every real-content scenario composes deterministically with Style + Palette stacks', () => {
    const stacks = [
      ['hand-drawn', 'dracula'],
      ['publication-figure', 'github-light'],
      ['watercolor', 'nord-light'],
    ] as const
    for (const entry of manifest.cases) {
      const source = sourceFor(entry)
      for (const stack of stacks) {
        const options = { style: [...stack], seed: 7, security: 'strict' as const, embedFontImport: false }
        const first = renderMermaidSVG(source, options)
        const again = renderMermaidSVG(source, options)
        const palette = getStyle(stack[1])!.colors!
        expect(first, `${entry.id} × ${stack.join('+')}`).toBe(again)
        expect(first).toContain(`--bg:${palette.bg}`)
        expect(first).toContain(`--fg:${palette.fg}`)
        expect(first).not.toMatch(/(?:NaN|Infinity|undefined)/)
        expect(verifyNoExternalRefs(first), `${entry.id} × ${stack.join('+')}`).toEqual({ ok: true, refs: [] })
        const sentinel = entry.expect.svgText?.[0] ?? entry.expect.labels?.[0]
        expect(sentinel, entry.id).toBeDefined()
        // These stacks deliberately change title/header case; the directed
        // prepared-text contracts separately assert the exact transformed case.
        expect(plainSvgText(first).toLowerCase(), `${entry.id} × ${stack.join('+')} text`).toContain(sentinel!.toLowerCase())
      }
    }
  })

  test('public layout honors wrapper-only Mindmap layout and GitGraph main-branch config', () => {
    const tidyEntry = manifest.cases.find(entry => entry.id === 'mindmap-tidy-tree-explicit')!
    const tidyParsed = parseMermaid(sourceFor(tidyEntry))
    expect(tidyParsed.ok).toBe(true)
    if (tidyParsed.ok) {
      const layout = layoutMermaid(tidyParsed.value)
      const root = layout.nodes.find(node => node.id === 'root')!
      expect(layout.nodes.filter(node => node.id !== 'root').every(node => node.x > root.x)).toBe(true)
    }

    for (const id of ['gitgraph-unicode-unusual-branches', 'gitgraph-transit-domain-transfer']) {
      const entry = manifest.cases.find(candidate => candidate.id === id)!
      const parsed = parseMermaid(sourceFor(entry))
      expect(parsed.ok, id).toBe(true)
      if (!parsed.ok) continue
      const body = asGitGraph(parsed.value)!.body
      expect(body.mainBranchName).not.toBe('main')
      expect(layoutMermaid(parsed.value).nodes).toHaveLength(entry.expect.commitCount!)
      expect(verifyMermaid(sourceFor(entry)).warnings).not.toContainEqual(expect.objectContaining({ syntax: 'empty_layout' }))
    }
  })
})
