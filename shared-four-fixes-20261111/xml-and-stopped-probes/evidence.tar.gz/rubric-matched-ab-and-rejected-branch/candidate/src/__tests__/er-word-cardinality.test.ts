import { describe, expect, test } from 'bun:test'
import mermaid from 'mermaid'
import { parseRegisteredMermaid, asEr, mutate, serializeMermaid } from '../agent/index.ts'
import { parseErDiagram, parseErRelationshipSyntax } from '../er/parser.ts'
import { renderMermaidSVG } from '../index.ts'

const parseNative = (statement: string) => parseErDiagram(['erDiagram', statement])

const aliases = [
  ['one or zero', 'zero-one', 'zero-or-one'],
  ['zero or one', 'zero-one', 'zero-or-one'],
  ['one or more', 'many', 'one-or-many'],
  ['one or many', 'many', 'one-or-many'],
  ['many(1)', 'many', 'one-or-many'],
  ['1+', 'many', 'one-or-many'],
  ['zero or more', 'zero-many', 'zero-or-many'],
  ['zero or many', 'zero-many', 'zero-or-many'],
  ['many(0)', 'zero-many', 'zero-or-many'],
  ['0+', 'zero-many', 'zero-or-many'],
  ['only one', 'one', 'one-only'],
  ['1', 'one', 'one-only'],
  ['one', 'one', 'one-only'],
  ['many', 'zero-many', 'zero-or-many'],
] as const

describe('ER word-form relationship aliases (Mermaid 11.16.0)', () => {
  test('both projections recognize every pinned cardinality alias on either side', () => {
    for (const [alias, nativeCard, agentCard] of aliases) {
      for (const side of ['left', 'right'] as const) {
        const statement = side === 'left'
          ? `CAR ${alias} to 1 DRIVER : allows`
          : `CAR 1 to ${alias} DRIVER : allows`
        const native = parseNative(statement)
        expect({ alias, side, count: native.relationships.length }).toEqual({ alias, side, count: 1 })
        expect(side === 'left' ? native.relationships[0]!.cardinality1 : native.relationships[0]!.cardinality2).toBe(nativeCard)
        expect(native.entities.map(entity => entity.id)).toEqual(['CAR', 'DRIVER'])

        const parsed = parseRegisteredMermaid(`erDiagram\n  ${statement}`)
        expect(parsed.ok).toBe(true)
        if (!parsed.ok) continue
        const body = asEr(parsed.value)?.body
        expect(body?.relations).toHaveLength(1)
        expect(side === 'left' ? body?.relations[0]?.leftCard : body?.relations[0]?.rightCard).toBe(agentCard)
        expect(body?.entities.map(entity => entity.id)).toEqual(['CAR', 'DRIVER'])
      }
    }
  })

  test('identifying and non-identifying words and glyphs retain meaning and endpoint identity', () => {
    const cases = [
      ['CAR 1 to zero or more NAMED-DRIVER : allows', true, 'one', 'zero-many', 'CAR', 'NAMED-DRIVER', 'allows'],
      ['PERSON many(0) optionally to 0+ NAMED-DRIVER : is', false, 'zero-many', 'zero-many', 'PERSON', 'NAMED-DRIVER', 'is'],
      ['CUSTOMER 1--one or more DELIVERY-ADDRESS : has', true, 'one', 'many', 'CUSTOMER', 'DELIVERY-ADDRESS', 'has'],
      ['CUSTOMER 1.-one or more DELIVERY-ADDRESS : has', false, 'one', 'many', 'CUSTOMER', 'DELIVERY-ADDRESS', 'has'],
      ['CUSTOMER 1-.one or more DELIVERY-ADDRESS : has', false, 'one', 'many', 'CUSTOMER', 'DELIVERY-ADDRESS', 'has'],
      ['A one or many optionally to zero or one B : has', false, 'many', 'zero-one', 'A', 'B', 'has'],
    ] as const
    for (const [statement, identifying, left, right, from, to, label] of cases) {
      const native = parseNative(statement)
      expect(native.relationships).toHaveLength(1)
      expect(native.relationships[0]).toMatchObject({ identifying, cardinality1: left, cardinality2: right })
      const parsed = parseRegisteredMermaid(`erDiagram\n  ${statement}`)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) continue
      const body = asEr(parsed.value)?.body
      expect(body?.relations).toHaveLength(1)
      expect(body?.relations[0]?.dashed).toBe(!identifying)
      const canonical = serializeMermaid(parsed.value)
      const expected = {
        entity1: from, entity2: to, cardinality1: left, cardinality2: right, identifying, label,
      }
      expect(parseErDiagram(canonical.split('\n')).relationships).toEqual([expected])
      for (const source of [`erDiagram\n  ${statement}`, canonical]) {
        const relations = renderMermaidSVG(source).match(/<polyline class="er-relationship"[^>]*>/g) ?? []
        expect(relations).toHaveLength(1)
        for (const [attribute, value] of Object.entries({
          'data-from': expected.entity1, 'data-to': expected.entity2,
          'data-cardinality1': left, 'data-cardinality2': right, 'data-identifying': identifying,
        })) expect(relations[0]).toContain(`${attribute}="${value}"`)
      }
    }
  })

  test('the pinned Mermaid DB agrees about word-form cardinality and identification', async () => {
    mermaid.initialize({ startOnLoad: false })
    const upstreamCard = {
      one: 'ONLY_ONE', 'zero-one': 'ZERO_OR_ONE', many: 'ONE_OR_MORE', 'zero-many': 'ZERO_OR_MORE',
    } as const
    for (const [alias, nativeCard] of aliases) {
      for (const side of ['left', 'right'] as const) {
        const statement = side === 'left'
          ? `CAR ${alias} to 1 DRIVER : allows`
          : `CAR 1 to ${alias} DRIVER : allows`
        const upstream = await mermaid.mermaidAPI.getDiagramFromText(`erDiagram\n${statement}\n`)
        const db = upstream.db as unknown as { getRelationships(): Array<{ relSpec: { cardA: string; cardB: string } }> }
        expect(db.getRelationships()).toHaveLength(1)
        expect(side === 'left' ? db.getRelationships()[0]!.relSpec.cardB : db.getRelationships()[0]!.relSpec.cardA).toBe(upstreamCard[nativeCard])
      }
    }
    for (const [statement, cardA, cardB, relType] of [
      ['CAR 1 to zero or more DRIVER : allows', 'ZERO_OR_MORE', 'ONLY_ONE', 'IDENTIFYING'],
      ['PERSON many(0) optionally to 0+ DRIVER : is', 'ZERO_OR_MORE', 'ZERO_OR_MORE', 'NON_IDENTIFYING'],
      ['CUSTOMER 1.-one or more DELIVERY-ADDRESS : has', 'ONE_OR_MORE', 'ONLY_ONE', 'NON_IDENTIFYING'],
      ['CUSTOMER 1-.one or more DELIVERY-ADDRESS : has', 'ONE_OR_MORE', 'ONLY_ONE', 'NON_IDENTIFYING'],
    ] as const) {
      const upstream = await mermaid.mermaidAPI.getDiagramFromText(`erDiagram\n${statement}\n`)
      const db = upstream.db as unknown as { getRelationships(): Array<{ relSpec: { cardA: string; cardB: string; relType: string } }> }
      expect(db.getRelationships().map(relation => relation.relSpec)).toEqual([{ cardA, cardB, relType }])
    }
  })

  test('numeric 1 requires adjacency to a glyph operator, matching Mermaid lexer', async () => {
    const rejected = 'A 1 -- 0+ B : x'
    const accepted = 'A one -- many B : x'
    expect(parseErRelationshipSyntax(rejected)).toBeNull()
    expect(parseErRelationshipSyntax(accepted)?.leftToken).toBe('one')
    await expect(mermaid.mermaidAPI.getDiagramFromText(`erDiagram\n${rejected}\n`)).rejects.toThrow()
    const upstream = await mermaid.mermaidAPI.getDiagramFromText(`erDiagram\n${accepted}\n`)
    const db = upstream.db as unknown as { getRelationships(): unknown[] }
    expect(db.getRelationships()).toHaveLength(1)
  })

  test('numeric right-hand entity IDs remain endpoints, not cardinality fragments', () => {
    for (const id of ['1', '12']) {
      const statement = `a many to 1 ${id}: label`
      const native = parseNative(statement)
      expect(native.entities.map(entity => entity.id)).toEqual(['a', id])
      expect(native.relationships).toMatchObject([{
        entity1: 'a', entity2: id, cardinality1: 'zero-many', cardinality2: 'one', identifying: true,
      }])
      const parsed = parseRegisteredMermaid(`erDiagram\n${statement}`)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) continue
      const body = asEr(parsed.value)?.body
      expect(body?.entities.map(entity => entity.id)).toEqual(['a', id])
      expect(body?.relations).toMatchObject([{
        from: 'a', to: id, leftCard: 'zero-or-many', rightCard: 'one-only', dashed: false,
      }])
    }
  })

  test('multiword aliases and operators use Mermaid literal single-space lexemes', async () => {
    for (const rejected of [
      'A one  or zero to 0+ B : x',
      'A one\tor zero to 0+ B : x',
      'A one or zero optionally  to 0+ B : x',
      'A one or zero optionally\tto 0+ B : x',
    ]) {
      expect(parseErRelationshipSyntax(rejected)).toBeNull()
      await expect(mermaid.mermaidAPI.getDiagramFromText(`erDiagram\n${rejected}\n`)).rejects.toThrow()
    }
    // Mermaid accepts this text only by silently making `only` the entity and
    // `one` its cardinality, not as an A-to-B relationship. Do not emulate it.
    const shifted = 'A only  one to 0+ B : x'
    expect(parseErRelationshipSyntax(shifted)).toBeNull()
    const upstream = await mermaid.mermaidAPI.getDiagramFromText(`erDiagram\n${shifted}\n`)
    const db = upstream.db as unknown as { getRelationships(): Array<{ entityA: string }> }
    expect(db.getRelationships()).toHaveLength(1)
    expect(db.getRelationships()[0]!.entityA).toMatch(/^entity-only-/)
  })

  test('a typed mutation keeps surrounding relationships and canonical cardinalities', () => {
    const parsed = parseRegisteredMermaid('erDiagram\n  CAR 1 to zero or more DRIVER : allows\n  DRIVER many(0) optionally to 0+ LICENSE : holds')
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    const er = asEr(parsed.value)
    expect(er).not.toBeNull()
    if (!er) return
    const changed = mutate(er, { kind: 'rename_entity', from: 'DRIVER', to: 'OPERATOR' })
    expect(changed.ok).toBe(true)
    if (!changed.ok) return
    const source = serializeMermaid(changed.value)
    const native = parseErDiagram(source.split('\n').map(line => line.trim()).filter(Boolean))
    expect(native.relationships.map(relation => ({ from: relation.entity1, to: relation.entity2, left: relation.cardinality1, right: relation.cardinality2, identifying: relation.identifying }))).toEqual([
      { from: 'CAR', to: 'OPERATOR', left: 'one', right: 'zero-many', identifying: true },
      { from: 'OPERATOR', to: 'LICENSE', left: 'zero-many', right: 'zero-many', identifying: false },
    ])
  })

  test('a word-form relationship renders one edge carrying both word cardinalities', () => {
    const svg = renderMermaidSVG('erDiagram\nCAR 1 to zero or more DRIVER : allows\n')
    const relations = svg.match(/<polyline class="er-relationship"[^>]*>/g) ?? []
    expect(relations).toHaveLength(1)
    for (const attribute of ['data-from="CAR"', 'data-to="DRIVER"', 'data-cardinality1="one"', 'data-cardinality2="zero-many"', 'data-identifying="true"']) {
      expect(relations[0]).toContain(attribute)
    }
  })
})
