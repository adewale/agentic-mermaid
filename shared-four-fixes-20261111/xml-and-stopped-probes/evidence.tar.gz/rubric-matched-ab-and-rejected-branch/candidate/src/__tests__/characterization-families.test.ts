// ============================================================================
// Cross-family characterisation of the universal invariants.
//
// characterization-layout.test.ts pins the grid + A* flowchart/state engine in
// depth. THIS file extends the *universal* invariants (Tier A) across every
// renderer family and public output surface, asserting only what actually
// holds for each:
//
//   - Dispatch totality: all registered families render as text, SVG, and PNG.
//   - Label conservation + determinism: all registered families on text renderers,
//     with PNG byte stability checked on the canonical matrix.
//   - No diagonals: every text family (even xychart plots with block glyphs).
//   - Rectangularity (all rows one width): only the box families
//     (sequence / class / er). Chart and list families emit ragged rows by
//     design — asserting rectangularity there would be false, so we don't.
//
// scripts/characterization/contact-sheet-families.ts generates the coverage
// matrix and per-family layout strategies on demand. Changes no implementation code.
// ============================================================================

import { describe, expect, it } from 'bun:test'
import fc from 'fast-check'
import { renderMermaidPNG } from '../agent/png.ts'
import { renderMermaidASCII } from '../ascii/index.ts'
import { hasDiagonalLines } from '../ascii/validate.ts'
import { clearElkLayoutCache } from '../elk-instance.ts'
import { renderMermaidSVG } from '../index.ts'
import { fcParameters } from './helpers/fc-parameters.ts'
import { METAMORPHIC_FAMILIES } from './helpers/metamorphic-families.ts'

const RUNS = 60
const U = { colorMode: 'none', useAscii: false } as const
const A = { colorMode: 'none', useAscii: true } as const

// ---------------------------------------------------------------------------
// Per-family generators (bounded, always valid)
// ---------------------------------------------------------------------------

const word = fc.stringMatching(/^[A-Za-z][A-Za-z0-9]{0,5}$/)

const sequenceArb = fc
  .record({
    participants: fc.integer({ min: 2, max: 4 }),
    messages: fc.array(fc.record({ a: fc.nat(), b: fc.nat(), dashed: fc.boolean(), text: word }), { minLength: 1, maxLength: 6 }),
  })
  .map(({ participants, messages }) => {
    const ps = Array.from({ length: participants }, (_, i) => `P${i}`)
    const lines = ['sequenceDiagram', ...ps.map(p => `  participant ${p}`)]
    for (const m of messages) {
      const a = ps[m.a % participants]!
      const b = ps[m.b % participants]!
      lines.push(`  ${a}${m.dashed ? '-->>' : '->>'}${b}: ${m.text}`)
    }
    return lines.join('\n')
  })

const classArb = fc.record({ n: fc.integer({ min: 1, max: 4 }), members: fc.array(word, { maxLength: 3 }) }).map(({ n, members }) => {
  const cs = Array.from({ length: n }, (_, i) => `C${i}`)
  const lines = ['classDiagram']
  for (const c of cs) {
    if (members.length > 0) {
      lines.push(`  class ${c} {`, ...members.map(m => `    +${m} x`), '  }')
    } else {
      lines.push(`  class ${c}`)
    }
  }
  for (let i = 1; i < n; i++) lines.push(`  C${i - 1} <|-- C${i}`)
  return lines.join('\n')
})

const CARD = ['||--o{', '||--|{', '}o--o{', '||--||']
const erArb = fc.record({ rels: fc.array(fc.record({ a: word, b: word, c: fc.nat(), label: word }), { minLength: 1, maxLength: 4 }) }).map(({ rels }) => {
  const lines = ['erDiagram']
  for (const r of rels) lines.push(`  ${r.a.toUpperCase()} ${CARD[r.c % CARD.length]} ${r.b.toUpperCase()} : ${r.label}`)
  return lines.join('\n')
})

const pieArb = fc.array(fc.record({ label: word, value: fc.integer({ min: 1, max: 100 }) }), { minLength: 1, maxLength: 6 }).map(slices => ['pie title P', ...slices.map((s, i) => `  "${s.label}${i}" : ${s.value}`)].join('\n'))

const xychartArb = fc.record({ points: fc.integer({ min: 2, max: 6 }), kind: fc.constantFrom('line', 'bar') }).map(({ points, kind }) => {
  const xs = Array.from({ length: points }, (_, i) => `x${i}`)
  const ys = Array.from({ length: points }, (_, i) => (i * 17 + 5) % 100)
  return ['xychart-beta', '  title "T"', `  x-axis [${xs.join(', ')}]`, '  y-axis "y" 0 --> 100', `  ${kind} [${ys.join(', ')}]`].join('\n')
})

const quadrantArb = fc
  .array(fc.record({ label: word, x: fc.integer({ min: 0, max: 100 }), y: fc.integer({ min: 0, max: 100 }) }), { minLength: 1, maxLength: 6 })
  .map(pts => ['quadrantChart', '  title Q', '  x-axis Low --> High', '  y-axis Low --> High', ...pts.map((p, i) => `  "${p.label}${i}": [${(p.x / 100).toFixed(2)}, ${(p.y / 100).toFixed(2)}]`)].join('\n'))

const timelineArb = fc.array(fc.record({ period: word, event: word }), { minLength: 1, maxLength: 6 }).map(rows => ['timeline', '  title T', ...rows.map(r => `  ${r.period} : ${r.event}`)].join('\n'))

const ganttArb = fc.array(fc.integer({ min: 1, max: 6 }), { minLength: 1, maxLength: 6 }).map(durations => {
  const lines = ['gantt', '  title G', '  dateFormat YYYY-MM-DD', '  axisFormat %m-%d', '  excludes weekends', '  section Build', `    T0 :t0, 2024-01-01, ${durations[0]}d`]
  for (let i = 1; i < durations.length; i++) {
    lines.push(`    T${i} :t${i}, after t${i - 1}, ${durations[i]}d`)
  }
  return lines.join('\n')
})

const journeyArb = fc.array(fc.record({ task: word, score: fc.integer({ min: 1, max: 5 }) }), { minLength: 1, maxLength: 6 }).map(tasks => ['journey', '  title J', '  section S', ...tasks.map((t, i) => `    ${t.task}${i}: ${t.score}: Me`)].join('\n'))

const architectureArb = fc.constant('architecture-beta\n  group api(cloud)[API]\n  service db(database)[Database] in api\n  service server(server)[Server] in api\n  db:L -- R:server')
const c4Arb = fc
  .record({ variant: fc.constantFrom('C4Context', 'C4Container', 'C4Component', 'C4Dynamic', 'C4Deployment'), count: fc.integer({ min: 2, max: 4 }) })
  .map(({ variant, count }) => [variant, ...Array.from({ length: count }, (_, i) => `  System(s${i}, "Service ${i}")`), ...Array.from({ length: count - 1 }, (_, i) => `  Rel(s${i}, s${i + 1}, "Call ${i}", "HTTP")`)].join('\n'))

const flowchartArb = fc.constant('flowchart TD\n  Start[Start] --> Done[Done]')
const stateArb = fc.constant('stateDiagram-v2\n  [*] --> Idle\n  Idle --> Running\n  Running --> [*]')
const mindmapArb = fc.uniqueArray(word, { minLength: 1, maxLength: 6 }).map(labels => ['mindmap', '  Root', ...labels.map((label, index) => `    n${index}[${label}]`)].join('\n'))
const gitgraphArb = fc.integer({ min: 1, max: 8 }).map(length => ['gitGraph', ...Array.from({ length }, (_, index) => `  commit id:"c${index}"`)].join('\n'))

const radarArb = fc.array(fc.array(fc.integer({ min: 1, max: 5 }), { minLength: 3, maxLength: 3 }), { minLength: 1, maxLength: 3 }).map(curves => ['radar-beta', '  axis a, b, c', ...curves.map((vals, i) => `  curve c${i}["C${i}"]{${vals.join(', ')}}`), '  max 5'].join('\n'))

// Distinct source/sink label spaces keep the generated flow graph acyclic.
const sankeyArb = fc.array(fc.record({ src: fc.integer({ min: 0, max: 3 }), dst: fc.integer({ min: 0, max: 3 }), value: fc.integer({ min: 1, max: 500 }) }), { minLength: 1, maxLength: 8 }).map(rows => ['sankey-beta', ...rows.map(r => `  Source ${r.src},Sink ${r.dst},${r.value}`)].join('\n'))

const RENDERER_CASES = [
  { family: 'packet', source: 'packet\n+8: "Source"\n+8: "Destination"', labels: ['Source', 'Destination'] },
  { family: 'kanban', source: 'kanban\nTodo[To do]\n  task[Implement]\nDone[Complete]', labels: ['To do', 'Implement', 'Complete'] },
  { family: 'requirement', source: 'requirementDiagram\nrequirement r {\nid: R1\ntext: "Fast response"\nrisk: high\nverifymethod: test\n}', labels: ['R1', 'Fast response'] },
  { family: 'treemap', source: 'treemap\n"Portfolio"\n  "Build": 60\n  "Learn": 40', labels: ['Portfolio', 'Build', 'Learn'] },
  { family: 'ishikawa', source: 'ishikawa\n  Delay\n  Process\n    Approval\n  Tooling\n    Build', labels: ['Delay', 'Process', 'Approval', 'Tooling', 'Build'] },
  { family: 'block', source: 'block\ncolumns 2\nA["API"] B["Database"]\nA --> B', labels: ['API', 'Database'] },
  {
    family: 'c4',
    source: 'C4Container\n  Person(customer, "Customer")\n  Container(api, "API", "HTTP")\n  Rel(customer, api, "Calls", "HTTPS")',
    labels: ['Customer', 'API', 'HTTP', 'Calls', 'HTTPS'],
  },
  {
    family: 'flowchart',
    source: 'graph TD\n  Start[Start] --> Done[Done]',
    labels: ['Start', 'Done'],
  },
  {
    family: 'state',
    source: 'stateDiagram-v2\n  [*] --> Idle\n  Idle --> Running\n  Running --> [*]',
    labels: ['Idle', 'Running'],
  },
  {
    family: 'sequence',
    source: 'sequenceDiagram\n  participant Alice\n  participant Bob\n  Alice->>Bob: Hello Bob',
    labels: ['Alice', 'Bob', 'Hello Bob'],
  },
  {
    family: 'class',
    source: 'classDiagram\n  class Animal\n  class Dog\n  Animal <|-- Dog',
    labels: ['Animal', 'Dog'],
  },
  {
    family: 'er',
    source: 'erDiagram\n  CUSTOMER ||--o{ ORDER : places',
    labels: ['CUSTOMER', 'ORDER', 'places'],
  },
  {
    family: 'timeline',
    source: 'timeline\n  title Release Plan\n  2026 : Launch',
    labels: ['Release Plan', '2026', 'Launch'],
  },
  {
    family: 'gantt',
    source:
      'gantt\n  title Launch plan\n  dateFormat YYYY-MM-DD\n  axisFormat %b %d\n  excludes weekends\n  section Build\n    Spec :done, spec, 2024-01-01, 2d\n    Implement :active, impl, after spec, 3d\n  section Ship\n    QA :crit, qa, after impl, 2d\n    Launch :milestone, launch, after qa, 0d\n    Release line :vert, release, 2024-01-10, 0d',
    labels: ['Launch plan', 'Build', 'Spec', 'Implement', 'Ship', 'QA', 'Launch', 'Release line'],
  },
  {
    family: 'journey',
    source: 'journey\n  title Checkout\n  section Cart\n  Pay: 5: Shopper',
    labels: ['Checkout', 'Cart', 'Pay', 'Shopper'],
  },
  {
    family: 'xychart',
    source: 'xychart\n  title Sales\n  x-axis [Jan, Feb]\n  y-axis Revenue 0 --> 10\n  bar [3, 7]',
    labels: ['Sales', 'Jan', 'Feb'],
  },
  {
    family: 'pie',
    source: 'pie title Pets\n  "Cats" : 4\n  "Dogs" : 6',
    labels: ['Pets', 'Cats', 'Dogs'],
  },
  {
    family: 'quadrant',
    source: 'quadrantChart\n  title Priorities\n  x-axis Low --> High\n  y-axis Risk --> Reward\n  quadrant-1 Invest\n  A: [0.7, 0.8]',
    labels: ['Priorities', 'Low', 'High', 'Risk', 'Reward', 'Invest', 'A'],
  },
  {
    family: 'architecture',
    source: 'architecture-beta\n  service api(server)[API]\n  service db(database)[DB]\n  api:R --> L:db',
    labels: ['API', 'DB'],
  },
  {
    family: 'mindmap',
    source: 'mindmap\n  root((Product))\n    research[Research]\n    delivery{{Delivery}}',
    labels: ['Product', 'Research', 'Delivery'],
  },
  {
    family: 'gitgraph',
    source: 'gitGraph\n  commit id:"base"\n  branch feature\n  commit id:"work"\n  checkout main\n  merge feature id:"merge"',
    labels: ['main', 'feature', 'base', 'work', 'merge'],
  },
  {
    family: 'radar',
    source: 'radar-beta\n  title Skills\n  axis speed["Speed"], power["Power"], range["Range"]\n  curve now["Current"]{4, 3, 5}\n  curve goal["Target"]{5, 5, 4}\n  max 5',
    labels: ['Skills', 'Speed', 'Power', 'Range', 'Current', 'Target'],
  },
  {
    family: 'sankey',
    source: 'sankey-beta\n  Coal,Electricity,127\n  Gas,Electricity,80\n  Electricity,Homes,120\n  Electricity,Industry,87',
    labels: ['Coal', 'Gas', 'Electricity', 'Homes', 'Industry'],
  },
] as const

// ---------------------------------------------------------------------------
// Invariant assertions
// ---------------------------------------------------------------------------

function assertTotalDeterministicNoDiagonals(src: string): string {
  const out = renderMermaidASCII(src, U)
  expect(out.length).toBeGreaterThan(0) // totality
  expect(renderMermaidASCII(src, U)).toBe(out) // determinism
  expect(hasDiagonalLines(out)).toBe(false) // orthogonality / block-only glyphs
  return out
}

function renderAll(src: string) {
  return {
    unicode: renderMermaidASCII(src, U),
    ascii: renderMermaidASCII(src, A),
    svg: renderMermaidSVG(src, { security: 'strict' }),
    png: renderMermaidPNG(src, { scale: 1 }),
  }
}

// One render per canonical case feeds every surface assertion below; only the
// determinism test renders a second time, to compare against it.
const renderedCases = new Map<string, ReturnType<typeof renderAll>>()
function renderCase(src: string): ReturnType<typeof renderAll> {
  let rendered = renderedCases.get(src)
  if (!rendered) renderedCases.set(src, (rendered = renderAll(src)))
  return rendered
}

function assertPngSignature(bytes: Uint8Array) {
  expect(bytes.length).toBeGreaterThan(8)
  expect(Array.from(bytes.slice(0, 8))).toEqual([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])
}

const ALL_FAMILIES: Array<[string, fc.Arbitrary<string>]> = [
  ...(['packet', 'kanban', 'requirement', 'treemap', 'ishikawa', 'block'] as const).map(family => [family, fc.integer({ min: METAMORPHIC_FAMILIES[family].kRange[0], max: METAMORPHIC_FAMILIES[family].kRange[1] }).chain(k => word.map(tag => METAMORPHIC_FAMILIES[family].build(k, tag)))] as [string, fc.Arbitrary<string>]),
  ['c4', c4Arb],
  ['flowchart', flowchartArb],
  ['state', stateArb],
  ['sequence', sequenceArb],
  ['class', classArb],
  ['er', erArb],
  ['pie', pieArb],
  ['xychart', xychartArb],
  ['quadrant', quadrantArb],
  ['timeline', timelineArb],
  ['gantt', ganttArb],
  ['journey', journeyArb],
  ['architecture', architectureArb],
  ['mindmap', mindmapArb],
  ['gitgraph', gitgraphArb],
  ['radar', radarArb],
  ['sankey', sankeyArb],
]

const BOX_FAMILIES: Array<[string, fc.Arbitrary<string>]> = [
  ['sequence', sequenceArb],
  ['class', classArb],
  ['er', erArb],
]

// ===========================================================================
// Tier A extended across families
// ===========================================================================

describe('characterisation · families · universal invariants', () => {

  it('all registered families render through Unicode, ASCII, SVG, and PNG surfaces', () => {
    for (const { source } of RENDERER_CASES) {
      let rendered: ReturnType<typeof renderCase> | undefined
      expect(() => {
        rendered = renderCase(source)
      }).not.toThrow()
      const { unicode, ascii, svg, png } = rendered!
      expect(unicode.length).toBeGreaterThan(0)
      expect(ascii.length).toBeGreaterThan(0)
      expect(svg).toContain('<svg')
      expect(svg).toContain('</svg>')
      assertPngSignature(png)
    }
  })

  it('all registered families preserve sentinel labels on text renderers', () => {
    for (const { source, labels } of RENDERER_CASES) {
      const { unicode, ascii, svg } = renderCase(source)
      for (const label of labels) {
        expect(unicode).toContain(label)
        expect(ascii).toContain(label)
        expect(svg).toContain(label)
      }
    }
  })

  it('all registered families are byte-stable across repeated renders', () => {
    for (const { source } of RENDERER_CASES) {
      // Lay out afresh each time: a cached ELK result would compare with itself.
      clearElkLayoutCache()
      const first = renderCase(source)
      clearElkLayoutCache()
      const second = renderAll(source)
      expect(second.unicode).toBe(first.unicode)
      expect(second.ascii).toBe(first.ascii)
      expect(second.svg).toBe(first.svg)
      expect(second.png).toEqual(first.png)
    }
  })

  it('all registered families emit clean SVG, Unicode, and 7-bit ASCII', () => {
    for (const { source } of RENDERER_CASES) {
      const { unicode, ascii, svg } = renderCase(source)
      expect(unicode).not.toMatch(/\x1b\[[0-9;]*m/)
      expect(unicode).not.toMatch(/\b(?:NaN|Infinity|undefined)\b/)
      expect(ascii).not.toMatch(/\x1b\[[0-9;]*m/)
      expect(ascii).not.toMatch(/\b(?:NaN|Infinity|undefined)\b/)
      expect(ascii).toMatch(/^[\x09\x0a\x0d\x20-\x7e]*$/)
      expect(svg).not.toMatch(/="[^"]*\b(?:NaN|Infinity|undefined)\b[^"]*"/)
    }
  })

  for (const [name, arb] of ALL_FAMILIES) {
    it(`${name}: total, deterministic, no diagonals`, () => {
      fc.assert(
        fc.property(arb, src => {
          assertTotalDeterministicNoDiagonals(src)
        }),
        fcParameters({ numRuns: RUNS }),
      )
    })
  }

  for (const [name, arb] of BOX_FAMILIES) {
    it(`${name}: rectangular canvas (all rows one width)`, () => {
      fc.assert(
        fc.property(arb, src => {
          const out = renderMermaidASCII(src, U)
          expect(new Set(out.split('\n').map(l => l.length)).size).toBe(1)
        }),
        fcParameters({ numRuns: RUNS }),
      )
    })
  }

  // Known boundary (a characterisation, not an aspiration): the chart and list
  // families do NOT produce rectangular canvases. Pinned so a future change to
  // uniform-width padding is a deliberate, visible decision.
  it('known boundary — pie is non-rectangular today', () => {
    const out = renderMermaidASCII('pie title P\n  "Dogs" : 45\n  "Cats" : 35\n  "Birds" : 20', U)
    expect(new Set(out.split('\n').map(l => l.length)).size).toBeGreaterThan(1)
  })
})
