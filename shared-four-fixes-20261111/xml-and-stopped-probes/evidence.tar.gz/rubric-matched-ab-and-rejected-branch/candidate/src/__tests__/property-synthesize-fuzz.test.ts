// Property fuzz for synthesizeFromGraph — the untrusted-JSON rehydration boundary behind
// `am serialize`, the batch `serialize` op, and Code Mode. It re-hydrates a diagram from a
// JSON payload (the `am parse` output shape). It DECLARES a Result return, so its contract is:
// total — never throw on ANY payload, always return a tagged {ok}. Before the fix, malformed
// (but valid-JSON) payloads threw: `am serialize` surfaced them as exit 4 (and exit 0 on
// `null`), bypassing the clean `!ok` → exit 2 error path. Seed pinned globally
// (fc-seed.preload.ts); AM_FC_SEED=random hunts fresh counterexamples.
import { describe, expect, it } from 'bun:test'
import fc from 'fast-check'
import { fcParameters } from './helpers/fc-parameters.ts'

import { synthesizeFromGraph, serializeMermaid, parseRegisteredMermaid as parseMermaid, createMermaid } from '../agent/index.ts'
import { BUILTIN_FAMILY_METADATA } from '../agent/families.ts'
import type { DiagramKind } from '../agent/types.ts'

const NUM_RUNS = 400

// Every registered built-in family, from the registry (a hand-written list had
// silently left sankey out of this untrusted boundary).
const FAMILIES = BUILTIN_FAMILY_METADATA.map(family => family.id) as DiagramKind[]
/** The `am parse` JSON wire shape: Maps become records and Sets become arrays, as the CLI's replacer does. */
const toWire = (value: unknown) => JSON.parse(JSON.stringify(value, (_key, v) => v instanceof Map ? Object.fromEntries(v) : v instanceof Set ? [...v] : v))
// Real payloads (the `am parse` JSON shape) for every family — the round-trip seed corpus.
const REAL_PAYLOADS = FAMILIES.map(fam => ({ family: fam, payload: toWire(createMermaid(fam)) }))

const junkValue = fc.oneof(
  fc.string({ maxLength: 12 }), fc.integer(), fc.double(), fc.boolean(),
  fc.constant(null), fc.constant(undefined),
  fc.array(fc.oneof(fc.string({ maxLength: 6 }), fc.integer()), { maxLength: 4 }),
  fc.object({ maxDepth: 2 }),
)
// Graph shapes chosen to hit the flowchart rehydration paths that used to throw:
// non-tuple node arrays, null/number node maps, object node maps, missing graph.
const graphArb = fc.oneof(
  fc.constant(undefined), fc.constant(null), fc.constant({}),
  fc.record({ nodes: fc.oneof(fc.integer(), fc.array(junkValue, { maxLength: 4 }), fc.object({ maxDepth: 1 })), edges: junkValue }, { requiredKeys: [] }),
  fc.record({ nodes: fc.array(fc.tuple(fc.string({ maxLength: 4 }), fc.object({ maxDepth: 1 })), { maxLength: 3 }) }),
)
const bodyArb = fc.oneof(
  fc.constant(undefined), junkValue,
  fc.record({ kind: fc.oneof(fc.constantFrom(...FAMILIES, 'opaque', 'toString', '__proto__', 'nope'), junkValue), graph: graphArb }, { requiredKeys: [] }),
)
const payloadArb = fc.oneof(
  fc.anything(),
  fc.record({ kind: fc.oneof(fc.constantFrom(...FAMILIES), fc.string({ maxLength: 6 })), body: bodyArb, meta: fc.oneof(fc.constant(undefined), fc.object({ maxDepth: 1 })) }, { requiredKeys: [] }),
  // A real payload with one corrupted top-level field.
  fc.tuple(fc.constantFrom(...REAL_PAYLOADS.map(real => real.payload)), fc.constantFrom('kind', 'body', 'meta'), junkValue).map(([base, key, v]) => ({ ...base, [key]: v })),
)

describe('synthesize fuzz: synthesizeFromGraph is total and deterministic', () => {
  it('never throws on any payload; always returns a tagged Result', () => {
    fc.assert(fc.property(payloadArb, payload => {
      const r = synthesizeFromGraph(payload as never)
      expect(typeof r.ok).toBe('boolean')
      if (r.ok) {
        // A successful rebuild must publish a parseable, family-consistent
        // source rather than a half-built body that merely did not throw.
        const source = serializeMermaid(r.value)
        expect(typeof source).toBe('string')
        const reparsed = parseMermaid(source)
        expect(reparsed.ok).toBe(true)
        if (reparsed.ok) expect(reparsed.value.kind).toBe(r.value.kind)
      } else {
        expect(Array.isArray(r.error)).toBe(true)
        expect(r.error.length).toBeGreaterThan(0)
        expect(typeof r.error[0]!.message).toBe('string')
      }
    }), fcParameters({ numRuns: NUM_RUNS }))
  })

  it('is deterministic for identical input', () => {
    fc.assert(fc.property(payloadArb, payload => {
      expect(JSON.stringify(synthesizeFromGraph(payload as never))).toBe(JSON.stringify(synthesizeFromGraph(payload as never)))
    }), fcParameters({ numRuns: NUM_RUNS }))
  })
})

// A minimal createMermaid(fam) is a non-degenerate diagram for every family EXCEPT radar,
// whose empty base (no axes) is not a serializable radar — so it is legitimately not
// round-trippable and is exercised only by the crash-freedom/determinism suites above.
const NOT_ROUND_TRIPPABLE: readonly DiagramKind[] = ['radar']

describe('synthesize fuzz: real payloads round-trip', () => {
  it('rejects malformed and family-inconsistent payloads instead of emitting invalid source', () => {
    for (const payload of [
      { kind: 'flowchart', body: { kind: 'flowchart', graph: { nodes: {} } } },
      { kind: 'flowchart', body: { kind: 'opaque', family: 'pie', source: 'pie\n  "A" : 1\n' } },
      { kind: 'constructor', body: { kind: 'opaque', family: 'pie', source: 'pie\n  "A" : 1\n' } },
      { kind: { toString: '' }, body: { kind: 'flowchart' } },
      { kind: 'flowchart', body: { kind: 'opaque', family: { toString: '' } } },
      { kind: 'pie', body: { kind: 'pie', title: '', showData: false, slices: [{ label: 'A', value: 'oops' }] } },
    ]) {
      expect(synthesizeFromGraph(payload as never)).toMatchObject({ ok: false })
    }
  })

  it('publishes the parser-admitted metadata snapshot, not malformed retained JSON', () => {
    const payload = JSON.parse(JSON.stringify(createMermaid('flowchart')))
    payload.body.graph.nodes = { A: { id: 'A', label: 'A', shape: 'rectangle' } }
    payload.meta.comments = null
    const result = synthesizeFromGraph(payload)
    expect(result.ok).toBe(true)
    if (result.ok) expect(Array.isArray(result.value.meta.comments)).toBe(true)
  })

  it('empty creation scaffolds survive JSON rehydration except radar, which requires axes', () => {
    // A deterministic loop, not constantFrom sampling: every family is visited.
    for (const { family, payload } of REAL_PAYLOADS) {
      const r = synthesizeFromGraph(payload as never)
      if (NOT_ROUND_TRIPPABLE.includes(family)) {
        expect({ family, ok: r.ok }).toEqual({ family, ok: false })
        continue
      }
      expect({ family, ok: r.ok }).toEqual({ family, ok: true })
      if (!r.ok) continue
      const source = serializeMermaid(r.value)
      expect({ family, source }).toEqual({ family, source: serializeMermaid(createMermaid(family)) })
      const reparsed = parseMermaid(source)
      expect({ family, reparsed: reparsed.ok && reparsed.value.kind }).toEqual({ family, reparsed: family })
    }
  })
})
