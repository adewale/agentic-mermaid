import { describe, expect, test } from 'bun:test'
import { MAX_RADAR_AXES, parseRadarChart } from '../radar/parser.ts'

const lines = (src: string): string[] => src.split('\n').map(l => l.trim()).filter(Boolean)

describe('radar parser', () => {
  test('parses header forms, axes, curves, options', () => {
    for (const header of ['radar-beta', 'radar-beta:', 'radar-beta :']) {
      const chart = parseRadarChart(lines(`${header}\n  axis a, b, c\n  curve x{1,2,3}`))
      expect(chart.axes.map(a => a.id)).toEqual(['a', 'b', 'c'])
      expect(chart.curves[0]!.values).toEqual([1, 2, 3])
    }
  })

  test('axis and curve labels default to id; quoted labels are captured', () => {
    const chart = parseRadarChart(lines('radar-beta\n  axis a["Alpha"], b\n  curve x["Series"]{1,2}'))
    expect(chart.axes[0]).toEqual({ id: 'a', label: 'Alpha' })
    expect(chart.axes[1]).toEqual({ id: 'b', label: 'b' })
    expect(chart.curves[0]).toEqual({ id: 'x', label: 'Series', values: [1, 2] })
    // A quoted label runs to its closing quote across lines; a `%%` inside it
    // is text, and one after it a comment.
    const multiline = parseRadarChart(lines('radar-beta\n  axis a["Alpha\n    long %% kept"], b %% note\n  curve x[\'Series\n    two %% kept\']{1,2}'))
    expect(multiline.axes).toEqual([{ id: 'a', label: 'Alpha\nlong %% kept' }, { id: 'b', label: 'b' }])
    expect(multiline.curves[0]!.label).toBe('Series\ntwo %% kept')
  })

  test('keyed entries (colon optional) reorder to axis order', () => {
    expect(parseRadarChart(lines('radar-beta\n  axis A,B,C\n  curve m{ C: 3, A: 1, B: 2 }')).curves[0]!.values).toEqual([1, 2, 3])
    expect(parseRadarChart(lines('radar-beta\n  axis A,B,C\n  curve m{ C 3, A 1, B 2 }')).curves[0]!.values).toEqual([1, 2, 3])
  })

  test('resolves keyed curves against the final axis set regardless of statement order', () => {
    const chart = parseRadarChart(lines('radar-beta\n  curve m{ B: 2, A: 1 }\n  axis A, B'))
    expect(chart.axes.map(axis => axis.id)).toEqual(['A', 'B'])
    expect(chart.curves[0]!.values).toEqual([1, 2])
  })

  test('accepts multiline curve entries and trailing Mermaid comments', () => {
    const chart = parseRadarChart(lines(`radar-beta
      axis A, B, C %% dimensions
      curve m{
        1,
        2,
        3
      } %% observations`))
    expect(chart.axes.map(axis => axis.id)).toEqual(['A', 'B', 'C'])
    expect(chart.curves[0]!.values).toEqual([1, 2, 3])
  })

  test('decodes quoted escapes and rejects forms outside the upstream grammar', () => {
    const chart = parseRadarChart(lines(String.raw`radar-beta
      axis a["A \"quoted\" label"], b
      curve x{1,2}`))
    expect(chart.axes[0]!.label).toBe('A "quoted" label')
    expect(() => parseRadarChart(lines('radar-beta\n  axis a[Unquoted], b\n  curve x{1,2}'))).toThrow(/quoted label/i)
    expect(() => parseRadarChart(lines('radar-beta\n  axis a-, b\n  curve x{1,2}'))).toThrow(/Invalid radar axis/)
    expect(() => parseRadarChart(lines('radar-beta\n  axis a, b\n  curve x{1,,2}'))).toThrow(/empty/i)
  })

  test('ticks is a bounded positive integer', () => {
    expect(parseRadarChart(lines('radar-beta\n  axis a\n  curve x{1}\n  ticks 64\n  max 2')).ticks).toBe(64)
    for (const ticks of ['0', '2.5', '65']) {
      expect(() => parseRadarChart(lines(`radar-beta\n  axis a\n  curve x{1}\n  ticks ${ticks}\n  max 2`))).toThrow(/ticks/i)
    }
  })

  test('axis count is resource-bounded before layout', () => {
    const accepted = Array.from({ length: MAX_RADAR_AXES }, (_v, i) => `a${i}`).join(',')
    expect(parseRadarChart(lines(`radar-beta\n axis ${accepted}`)).axes).toHaveLength(MAX_RADAR_AXES)
    expect(() => parseRadarChart(lines(`radar-beta\n axis ${accepted},overflow`))).toThrow(/at most 256 axes/i)
  })

  test('multiple axes/curves per line, comma-joined options', () => {
    const chart = parseRadarChart(lines('radar-beta\n  axis a, b\n  curve x{1,2}, y{2,1}\n  min 1, max 10, ticks 4, graticule polygon'))
    expect(chart.curves.map(c => c.id)).toEqual(['x', 'y'])
    expect({ min: chart.min, max: chart.max, ticks: chart.ticks, graticule: chart.graticule }).toEqual({ min: 1, max: 10, ticks: 4, graticule: 'polygon' })
  })

  test('accepts upstream whitespace-separated statements and header-adjacent titles', () => {
    const titled = parseRadarChart(lines('radar-beta title Skills\n axis a\n curve x{1}\n max 2'))
    expect(titled.title).toBe('Skills')
    expect(titled.axes.map(axis => axis.id)).toEqual(['a'])

    const compact = parseRadarChart(lines('radar-beta axis A,B curve x{1,2} max 3 showLegend false'))
    expect(compact.axes.map(axis => axis.id)).toEqual(['A', 'B'])
    expect(compact.curves[0]!.values).toEqual([1, 2])
    expect(compact.max).toBe(3)
    expect(compact.showLegend).toBe(false)
  })

  test('matches upstream free-text and empty title/comment tokenization', () => {
    const chart = parseRadarChart(lines(`radar-beta
      title Cost {USD %% reviewer note
      accTitle: Coverage %% hidden
      accDescr: Visible description %% hidden
      axis a
      curve x{1}`))
    expect(chart.title).toBe('Cost {USD')
    expect(chart.accessibility).toEqual({ title: 'Coverage', description: 'Visible description' })

    const empty = parseRadarChart(lines('radar-beta\n title\n axis a\n curve x{1}'))
    expect(empty.title).toBe('')
  })

  test('accepts the portable upstream options-only source', () => {
    const chart = parseRadarChart(lines('radar-beta ticks 10 showLegend false graticule polygon min 1 max 10'))
    expect(chart.axes).toEqual([])
    expect(chart.curves).toEqual([])
    expect({ ticks: chart.ticks, showLegend: chart.showLegend, graticule: chart.graticule, min: chart.min, max: chart.max })
      .toEqual({ ticks: 10, showLegend: false, graticule: 'polygon', min: 1, max: 10 })
  })

  test('comments and blank lines are ignored', () => {
    const chart = parseRadarChart(lines('radar-beta\n  %% a comment\n  axis a, b\n\n  curve x{1,2}'))
    expect(chart.axes).toHaveLength(2)
  })

  test('rejects malformed input loudly', () => {
    expect(() => parseRadarChart(lines('radar-beta\n  axis a, b, c\n  curve x{1,-2,3}'))).toThrow(/non-negative|sign/)
    expect(() => parseRadarChart(lines('radar-beta\n  axis a\n  curve x{}'))).toThrow(/empty/)
    expect(() => parseRadarChart(lines('radar-beta\n  axis A,B,C\n  curve x{ A: 1, B: 2 }'))).toThrow(/missing an entry/i)
    expect(() => parseRadarChart(lines('radar-beta\n  axis a, b\n  min 5\n  max 5'))).toThrow(/greater than min/)
    expect(() => parseRadarChart(lines('radar-beta\n  curve x{a: 1}'))).toThrow(/no axes/)
    expect(() => parseRadarChart(lines('radar-beta\n  axis a\n  curve x{1, a: 2}'))).toThrow(/mixes/)
    expect(() => parseRadarChart(lines('radar-beta\n  axis a\n  wut'))).toThrow(/Unrecognized/i)
  })

  test('a positional curve with the wrong value count is kept (not an error)', () => {
    const chart = parseRadarChart(lines('radar-beta\n  axis a, b, c\n  curve x{1, 2}\n  max 5'))
    expect(chart.curves[0]!.values).toEqual([1, 2]) // arity handled at layout, still legended
  })
})
