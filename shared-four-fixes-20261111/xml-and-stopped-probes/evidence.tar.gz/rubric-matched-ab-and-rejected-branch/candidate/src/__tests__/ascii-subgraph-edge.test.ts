// BUILD-14: edges whose endpoint is a subgraph id must attach to the subgraph
// CONTAINER, not a phantom duplicate node.
//
// The TS parser auto-creates a leaf node for every edge endpoint, so an edge
// like `Start --> Pipeline` (where `Pipeline` is a subgraph) used to render a
// separate small box labelled "Pipeline" (the phantom) that the edge connected
// to, while the real container floated separately. The SVG/ELK path already
// filters this via hierarchical ports (see src/layout-engine.ts); these tests
// pin the equivalent behavior for the ASCII renderer.
//
// Assertions (per BUILD-14): exactly ONE occurrence of the container title; the
// phantom box is gone; the edge visually attaches at/inside the container border
// column/row; all internal nodes still render inside the container.

import { describe, test, expect } from 'bun:test'
import { renderMermaidASCII, renderMermaidASCIIWithReceipt } from '../index.ts'
import { terminalDocumentOf } from '../ascii/terminal-document.ts'

/** Count non-overlapping occurrences of a substring. */
function count(haystack: string, needle: string): number {
  let n = 0
  let i = haystack.indexOf(needle)
  while (i !== -1) {
    n++
    i = haystack.indexOf(needle, i + needle.length)
  }
  return n
}

/** Index of the row (line) containing a substring, or -1. */
function rowOf(out: string, needle: string): number {
  return out.split('\n').findIndex(l => l.includes(needle))
}

interface FrameBounds {
  left: number
  right: number
  top: number
  bottom: number
}

function frameAroundLabel(out: string, label: string): FrameBounds {
  const lines = out.split('\n')
  const labelRow = rowOf(out, label)
  expect(labelRow).toBeGreaterThanOrEqual(0)
  const labelColumn = lines[labelRow]!.indexOf(label)

  let left = -1
  let right = -1
  let top = -1
  for (let row = labelRow; row >= 0; row--) {
    const candidateLeft = lines[row]!.lastIndexOf('┌', labelColumn)
    const candidateRight = lines[row]!.indexOf('┐', labelColumn)
    if (candidateLeft >= 0 && candidateRight > labelColumn) {
      left = candidateLeft
      right = candidateRight
      top = row
      break
    }
  }

  let bottom = -1
  if (left >= 0 && right >= 0) {
    for (let row = labelRow + 1; row < lines.length; row++) {
      const leftCorner = lines[row]![left]
      const rightCorner = lines[row]![right]
      if ('└├┴┼'.includes(leftCorner ?? '') && '┘┤┴┼'.includes(rightCorner ?? '')) {
        bottom = row
        break
      }
    }
  }

  expect(Math.min(left, right, top, bottom)).toBeGreaterThanOrEqual(0)
  return { left, right, top, bottom }
}

function expectOutsideFrame(out: string, text: string, frame: FrameBounds): void {
  const lines = out.split('\n')
  const row = rowOf(out, text)
  const column = lines[row]!.indexOf(text)
  expect(row < frame.top || row > frame.bottom || column < frame.left || column > frame.right).toBe(true)
}

const LR_INSIDE_TD = `flowchart TD
  Start --> Pipeline
  subgraph Pipeline
    direction LR
    Fetch --> Parse --> Transform --> Store
  end
  Pipeline --> Done
`

describe('BUILD-14: edge endpoint is a subgraph id (ASCII)', () => {
  test('TD: container title appears exactly once and the phantom box is gone', () => {
    const out = renderMermaidASCII(LR_INSIDE_TD)

    // Exactly one "Pipeline" — the container title, not a phantom node box too.
    expect(count(out, 'Pipeline')).toBe(1)

    // The internal chain still renders inside the container.
    for (const label of ['Fetch', 'Parse', 'Transform', 'Store']) {
      expect(out).toContain(label)
    }

    // The phantom would have been a standalone box whose only text is the
    // subgraph id, placed on its OWN row below Start. The container title row
    // must be the only row mentioning "Pipeline".
    const pipelineRows = out.split('\n').filter(l => l.includes('Pipeline'))
    expect(pipelineRows.length).toBe(1)
  })

  test('TD: the incoming edge attaches to the container top border (not a node)', () => {
    const out = renderMermaidASCII(LR_INSIDE_TD)
    const lines = out.split('\n')

    // The container title row and its top border row.
    const titleRow = rowOf(out, 'Pipeline')
    expect(titleRow).toBeGreaterThan(0)
    const borderRow = lines[titleRow - 1]!

    // The incoming arrowhead terminates AT the container: either embedded in
    // the top border row (clip-style) or on the row immediately above it
    // (drop-style — both honest attachments; the phantom box is what's banned).
    const arrowRow = borderRow.includes('▼') ? borderRow : lines[titleRow - 2] ?? ''
    expect(arrowRow).toContain('▼')
    // The arrow column falls within the container's horizontal span.
    const arrowCol = arrowRow.indexOf('▼')
    expect(arrowCol).toBeGreaterThanOrEqual(borderRow.indexOf('┌'))
    expect(arrowCol).toBeLessThanOrEqual(borderRow.lastIndexOf('┐'))
    // And that border row is a genuine container border (corner + horizontal).
    expect(borderRow).toContain('┌')
    expect(borderRow).toContain('┐')
  })

  test('TD: Start and Done remain outside the container in the outer TD flow', () => {
    const out = renderMermaidASCII(LR_INSIDE_TD)
    for (const label of ['Start', 'Done', 'Pipeline', 'Store']) expect(rowOf(out, label)).toBeGreaterThanOrEqual(0)
    // Start is above the container; Done is below it.
    expect(rowOf(out, 'Start')).toBeLessThan(rowOf(out, 'Pipeline'))
    expect(rowOf(out, 'Done')).toBeGreaterThan(rowOf(out, 'Store'))
    // Done renders as its own node (single occurrence, not duplicated).
    expect(count(out, 'Done')).toBe(1)
  })

  test.each([false, true])('mermaid#2509-shaped: LR outside --> subgraph attaches to the container (ASCII=%p)', useAscii => {
    const rendered = renderMermaidASCIIWithReceipt(`flowchart LR
  outside --> subgraph1
  subgraph subgraph1
    inner1 --> inner2
  end
`, { useAscii, colorMode: 'none' })
    const out = rendered.text, document = terminalDocumentOf(rendered)!, regions = document.regions()

    // Single container title; phantom "subgraph1" box gone.
    expect(count(out, 'subgraph1')).toBe(1)
    // Internal nodes still inside.
    expect(out).toContain('inner1')
    expect(out).toContain('inner2')
    // Physical container contacts can occupy a different row from its cards.
    // The exterior card and both inner cards retain their actual membership.
    expect(count(out, 'outside')).toBe(1)
    expect(regions.filter(region => region.kind === 'node').map(region => region.id).sort()).toEqual(['inner1', 'inner2', 'outside'])
    for (const id of ['inner1', 'inner2']) expect(regions.find(region => region.id === id)?.parentId).toBe('subgraph1')
    const frame = regions.find(region => region.kind === 'subgraph' && region.id === 'subgraph1')!
    const outside = regions.find(region => region.kind === 'node' && region.id === 'outside')!
    expect(outside.canvasColEnd).toBeLessThan(frame.canvasColStart)
    const edge = regions.find(region => region.kind === 'edge' && region.from === 'outside')!
    expect(edge.to).toBe('subgraph1')
    const end = edge.ports!.find(port => port.end === 'end')!
    expect(end).toMatchObject({ nodeId: 'subgraph1', side: 'L', x: frame.canvasColStart })
    expect(end.y).toBeGreaterThan(frame.canvasRow)
    expect(end.y).toBeLessThan(frame.canvasRow + frame.rowSpan! - 1)
    const marker = document.cell(end.x - (end.markerOffset ?? 1), end.y)!
    expect(marker.kind).toBe('marker')
    expect(marker.glyph).toBe(useAscii ? '>' : '►')
    expect(marker.owners.some(owner => owner.kind === 'edge' && owner.id === edge.id)).toBe(true)
    expect(document.diagnostics).toEqual([])
  })

  test('LR target container stays disjoint from an unconnected sibling frame', () => {
    const out = renderMermaidASCII(`flowchart LR
  A --> S
  subgraph S [First]
    s1 --> s2
  end
  subgraph T [Second]
    t1 --> t2
  end
`)

    expect(count(out, 'First')).toBe(1)
    expect(count(out, 'Second')).toBe(1)
    expect(out).not.toContain('SFirst')
    for (const label of ['A', 's1', 's2', 't1', 't2']) expect(count(out, label)).toBe(1)

    const lines = out.split('\n')
    const firstRow = rowOf(out, 'First')
    const secondRow = rowOf(out, 'Second')
    expect(firstRow).not.toBe(secondRow)
    const firstFrameBottom = lines.findIndex(
      (line, index) => index > firstRow && line.includes('└') && line.includes('┘'),
    )
    const secondFrameTop = lines.findLastIndex(
      (line, index) => index < secondRow && line.includes('┌') && line.includes('┐'),
    )
    expect(firstFrameBottom).toBeGreaterThanOrEqual(0)
    expect(secondFrameTop).toBeGreaterThanOrEqual(0)
    expect(firstFrameBottom).toBeLessThan(secondFrameTop)
  })

  for (const direction of ['LR', 'TD'] as const) {
    test(`${direction}: disconnected target members keep outside nodes and root frames disjoint`, () => {
      const out = renderMermaidASCII(`flowchart ${direction}
  X --> S
  subgraph S [One]
    a1
    a2
  end
  subgraph T [Two]
    b1
    b2
  end
`)

      for (const label of ['X', 'One', 'Two', 'a1', 'a2', 'b1', 'b2']) {
        expect(count(out, label), `${direction}: ${label}`).toBe(1)
      }
      const one = frameAroundLabel(out, 'One')
      const two = frameAroundLabel(out, 'Two')
      expectOutsideFrame(out, 'X', one)
      expect(
        one.right < two.left
        || two.right < one.left
        || one.bottom < two.top
        || two.bottom < one.top,
      ).toBe(true)
    })
  }

  for (const direction of ['LR', 'RL'] as const) {
    test(`${direction}: outgoing container edges do not merge sibling frames or titles`, () => {
      const out = renderMermaidASCII(`flowchart ${direction}
  S --> Y
  subgraph S [One]
    a1 --> a2
  end
  subgraph T [Two]
    b1 --> b2
  end
`)

      for (const label of ['Y', 'One', 'Two', 'a1', 'a2', 'b1', 'b2']) {
        expect(count(out, label), `${direction}: ${label}`).toBe(1)
      }
      const lines = out.split('\n')
      expect(lines[rowOf(out, 'Two')]).not.toMatch(/[┌┐└┘┬┴┼]/)
      const one = frameAroundLabel(out, 'One')
      const two = frameAroundLabel(out, 'Two')
      expect(
        one.right < two.left
        || two.right < one.left
        || one.bottom < two.top
        || two.bottom < one.top,
      ).toBe(true)
    })
  }

  test('sad path: id collision — subgraph id also given a standalone label', () => {
    // Mermaid resolves a `subgraph P` ahead of any standalone `P[...]` node:
    // the id refers to the container. Pin that honest behavior — the explicit
    // label is ignored and BOTH edges attach to the container, with no phantom.
    const out = renderMermaidASCII(`flowchart TD
  Start --> P
  P[Real Node] --> Done
  subgraph P
    A --> B
  end
`)

    // The container title "P" appears once; the ignored "Real Node" label
    // produces no phantom box.
    expect(count(out, ' P ')).toBe(1)
    expect(rowOf(out, 'Start')).toBeGreaterThanOrEqual(0)
    expect(out).not.toContain('Real Node')
    expect(count(out, 'Done')).toBe(1)
    // Internal nodes render inside the container.
    expect(out).toContain('A')
    expect(out).toContain('B')
    // Both Start (above) and Done (reached from inside via the container exit)
    // render as their own nodes.
    expect(rowOf(out, 'Start')).toBeLessThan(rowOf(out, 'A'))
  })
})
