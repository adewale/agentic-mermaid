import { describe, expect, it } from 'bun:test'
import type { DiagramColors } from '../theme.ts'
import { lowerArchitectureScene, renderArchitectureSvg } from '../architecture/renderer.ts'
import { DEFAULT_ARCHITECTURE_VISUAL } from '../architecture/config.ts'
import type { PositionedArchitectureDiagram } from '../architecture/types.ts'
import { renderMermaidSVG } from '../index.ts'
import { resolveRenderRequest } from '../render-contract.ts'
import { positionResolvedFamily } from '../positioning.ts'
import { colorPixelBox, redPixel } from './helpers/raster.ts'

const lightColors: DiagramColors = { bg: '#FFFFFF', fg: '#27272A' }

function makeDiagram(overrides: Partial<PositionedArchitectureDiagram> = {}): PositionedArchitectureDiagram {
  return {
    width: 420,
    height: 220,
    groups: [{
      id: 'app',
      label: 'Application <Zone>',
      icon: 'cloud',
      x: 20,
      y: 20,
      width: 220,
      height: 160,
      children: [],
    }],
    services: [
      {
        id: 'api',
        label: 'API & <Gateway>',
        icon: 'server',
        parentId: 'app',
        x: 40,
        y: 70,
        width: 120,
        height: 44,
      },
      {
        id: 'db',
        label: 'Primary "DB"',
        icon: 'database',
        x: 280,
        y: 70,
        width: 120,
        height: 44,
      },
    ],
    junctions: [{
      id: 'bus',
      parentId: 'app',
      x: 120,
      y: 132,
      width: 16,
      height: 16,
    }],
    edges: [{
      source: { id: 'api', side: 'R', boundary: 'item' },
      target: { id: 'db', side: 'L', boundary: 'item' },
      label: 'reads <records> & "writes"',
      hasArrowStart: false,
      hasArrowEnd: true,
      points: [
        { x: 160, y: 92 },
        { x: 220, y: 92 },
        { x: 220, y: 92 },
        { x: 280, y: 92 },
      ],
      labelPosition: { x: 220, y: 92 },
      placement: 'satisfied',
      sourceFacesTarget: true,
      targetFacesSource: true,
      obstacleFree: true,
    }],
    ...overrides,
  }
}

describe('renderArchitectureSvg', () => {
  it('places the visible start and end tips at their service attachment points', () => {
    const scene = lowerArchitectureScene({ positioned: makeDiagram(), colors: lightColors, resolved: { renderOptions: {} } })
    const definitions = scene.parts.find(part => part.id === 'defs')
    if (definitions?.kind !== 'document') throw new Error('missing architecture definitions')
    const markers = definitions.markerResources
    expect(markers?.map(marker => marker.id).sort()).toEqual(['architecture-arrow-end', 'architecture-arrow-start'])
    for (const marker of markers!) {
      if (marker.geometry?.kind !== 'polygon' || !marker.ref) throw new Error('missing arrow geometry')
      const contactX = marker.id.endsWith('start')
        ? Math.min(...marker.geometry.points.map(point => point.x))
        : Math.max(...marker.geometry.points.map(point => point.x))
      expect(marker.ref.x).toBe(contactX)
      const atSource = marker.id.endsWith('start')
      const rotation = atSource && marker.orient === 'auto-start-reverse' ? -1 : 1
      const bodyX = marker.geometry.points.reduce((sum, point) => sum + point.x, 0) / marker.geometry.points.length
      expect((bodyX - contactX) * rotation * (atSource ? 1 : -1)).toBeGreaterThan(0)
    }
  })

  for (const [sourceSide, targetSide] of [['R', 'L'], ['L', 'R'], ['B', 'T'], ['T', 'B']] as const) {
    for (const edgeLineWidth of [1, 2]) {
      it(`keeps both arrowheads outside services for ${sourceSide}↔${targetSide} at ${edgeLineWidth}px`, () => {
        const source = `architecture-beta\nservice api(server)[API]\nservice db(database)[Database]\napi:${sourceSide} <--> ${targetSide}:db`
        const options = { architecture: { visual: { edgeStroke: '#ff0000', edgeLineWidth } } }
        const request = resolveRenderRequest(source, options)
        const positioned = positionResolvedFamily('architecture', request).positioned as PositionedArchitectureDiagram
        const edge = positioned.edges[0]!
        const svg = renderMermaidSVG(source, options)
        for (const [side, point] of [[sourceSide, edge.points[0]!], [targetSide, edge.points.at(-1)!]] as const) {
          const region = side === 'R'
            ? { left: point.x + 2, right: point.x + 19, top: point.y - 13, bottom: point.y + 13 }
            : side === 'L'
              ? { left: point.x - 19, right: point.x - 2, top: point.y - 13, bottom: point.y + 13 }
              : side === 'B'
                ? { left: point.x - 13, right: point.x + 13, top: point.y + 2, bottom: point.y + 19 }
                : { left: point.x - 13, right: point.x + 13, top: point.y - 19, bottom: point.y - 2 }
          const pixels = colorPixelBox(svg, redPixel, {
            left: Math.floor(region.left), right: Math.ceil(region.right),
            top: Math.floor(region.top), bottom: Math.ceil(region.bottom),
          })
          const acrossShaft = side === 'R' || side === 'L' ? pixels.height : pixels.width
          expect(acrossShaft).toBeGreaterThan(edgeLineWidth + 2)
        }
      })
    }
  }

  it('escapes labels and data attributes safely', () => {
    const svg = renderArchitectureSvg({ positioned: makeDiagram(), colors: lightColors, resolved: { renderOptions: {} } })

    expect(svg).toContain('Application &lt;Zone&gt;')
    expect(svg).toContain('API &amp; &lt;Gateway&gt;')
    expect(svg).toContain('Primary &quot;DB&quot;')
    expect(svg).toContain('data-label="reads &lt;records&gt; &amp; &quot;writes&quot;"')
    expect(svg).not.toContain('API & <Gateway>')
  })

  it('escapes a hostile icon name and falls back to a bounded text badge', () => {
    const hostile = 'evil:<script-onload=alert-1>'
    const diagram = makeDiagram()
    const svg = renderArchitectureSvg({
      positioned: { ...diagram, services: diagram.services.map(service => service.id === 'api' ? { ...service, icon: hostile } : service) },
      colors: lightColors,
      resolved: { renderOptions: {} },
    })
    expect(svg).not.toContain('<script')
    expect(svg).not.toMatch(/\sonload=/)
    expect(svg).toContain('data-icon="evil:&lt;script-onload=alert-1&gt;"')
    expect(svg).toContain('architecture-icon-glyph')
  })

  it('emits architecture-specific markers, classes, and theme tokens', () => {
    const svg = renderArchitectureSvg({ positioned: makeDiagram(), colors: lightColors, resolved: { renderOptions: {} } })

    expect(svg).toContain('id="architecture-arrow-end"')
    expect(svg).toContain('class="architecture-service"')
    expect(svg).toContain('class="architecture-edge"')
    expect(svg).toMatch(/<polyline class="architecture-edge"[^>]* stroke="var\(--arch-edge-stroke, var\(--_line\)\)"/)
    expect(svg).toContain('fill="var(--arch-edge-stroke, var(--_arrow))"')
  })

  it('draws structural header fills as paths and omits decorative service rails', () => {
    const svg = renderArchitectureSvg({
      positioned: makeDiagram(),
      colors: lightColors,
      resolved: {
        renderOptions: {
          architecture: {
            visual: {
              ...DEFAULT_ARCHITECTURE_VISUAL,
              groupCornerRadius: 18,
              serviceCornerRadius: 16,
            },
          },
        },
      },
    })

    expect(svg).toContain('<path class="architecture-group-band"')
    expect(svg).not.toContain('<rect class="architecture-group-band"')
    expect(svg).not.toContain('architecture-service-accent')
    expect(svg).not.toContain('architecture-icon-bg')
    expect(svg).not.toContain('architecture-icon-fill')
  })
})
