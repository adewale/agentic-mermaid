import { describe, expect, test } from 'bun:test'
import { parseRegisteredMermaid as parseMermaid } from '../agent/parse.ts'
import { serializeMermaid } from '../agent/serialize.ts'
import { attachSourceMapSpans, mapObservedSource, recordAuthoredSourceMapSpans } from '../agent/source-map-spans.ts'
import { withParserObservation } from '../shared/parser-observation.ts'
import { parseWardleyBody } from '../wardley/body.ts'
import { layoutWardley } from '../wardley/layout.ts'
import { layoutCynefin } from '../cynefin/layout.ts'
import { layoutRailroad } from '../railroad/layout.ts'
import { getFamily } from '../agent/families.ts'
import { mutate, mutateChecked } from '../agent/mutate.ts'
import type { SourceMapSpans, SourceSpan } from '../agent/types.ts'
import { sourceLineStarts, sourcePreservationSpans, sourceSpan } from '../family-detection.ts'
import { DIAGRAM_WORK_LIMITS } from '../shared/diagram-limits.ts'
import { expectNearLinearGrowth, LINEAR_GROWTH_CEILING, measureGrowth } from './helpers/complexity.ts'

function textAt(source: string, span: SourceSpan | undefined): string | undefined {
  return span ? source.slice(span.start.offset, span.end.offset) : undefined
}

describe('flowchart SourceMap', () => {
  test('maps nodes, edges, groups, and labels to source locations', () => {
    const source = `flowchart LR
  subgraph Auth[Auth Layer]
    A[Login]
    B{MFA?}
  end
  A -->|yes| B
  B -- no --> A
`
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return

    // SourceMap locations are over canonical normalized Mermaid source (the
    // current parser trims body indentation before structured parsing).
    expect(parsed.value.source.nodes.get('A')).toEqual({ line: 3, col: 1 })
    expect(parsed.value.source.nodes.get('B')).toEqual({ line: 4, col: 1 })
    expect(parsed.value.source.groups.get('Auth')).toEqual({ line: 2, col: 10 })
    expect(parsed.value.source.labels.get('node:A')).toEqual({ line: 3, col: 3 })
    expect(parsed.value.source.labels.get('group:Auth')).toEqual({ line: 2, col: 15 })
    expect(parsed.value.source.edges.get('edge#0:A->B')).toEqual({ line: 6, col: 1 })
    expect(parsed.value.source.labels.get('edge#0:A->B')).toEqual({ line: 6, col: 7 })
    expect(parsed.value.source.edges.get('edge#1:B->A')).toEqual({ line: 7, col: 1 })
  })

  test('maps a subgraph to its own declaration, not one whose id begins with it', () => {
    const source = 'flowchart LR\n  subgraph S-x\n    A\n  end\n  subgraph S\n    B\n  end\n  subgraph **Two** [t]\n    C\n  end'
    const parsed = parseMermaid(source)
    if (!parsed.ok) throw new Error(JSON.stringify(parsed.error))
    expect(['S-x', 'S', '**Two**'].map(id => parsed.value.source.groups.get(id)?.line)).toEqual([2, 5, 8])
  })

  // The parser reads a label, string or link across lines, and ER statements
  // may share a line: each location is on the line its text came from, and a
  // span covers its statement alone.
  test.each([
    ['flowchart TD\nA["see\nC here"]\nB --> C', 'nodes', 'C', { line: 4, col: 7 }, 'B --> C'],
    ['flowchart TD\nA["see\nC here"]\nB --> C', 'labels', 'node:A', { line: 2, col: 4 }, 'see\nC here'],
    ['flowchart TD\nA -->\nB', 'edges', 'edge#0:A->B', { line: 2, col: 1 }, 'A -->\nB'],
    ['flowchart TD\nA["a\nB"] --> B\nB --> C', 'nodes', 'B', { line: 3, col: 9 }, 'A["a\nB"] --> B'],
    ['flowchart TD\nA["a\nB"] --> B\nB --> C', 'edges', 'edge#0:A->B', { line: 2, col: 1 }, 'A["a\nB"] --> B'],
    ['flowchart TD\n  A -- some\n    text --> B', 'labels', 'edge#0:A->B', { line: 2, col: 6 }, 'some\n    text'],
    ['erDiagram\n  A { int id PK string name } B', 'nodes', 'A', { line: 2, col: 1 }, 'A {'],
    ['erDiagram\n  A { int id PK string name } B', 'nodes', 'B', { line: 2, col: 29 }, 'B'],
    ['erDiagram\n  A { int id PK string name } B', 'labels', 'er:A:attr#0', { line: 2, col: 5 }, 'int id PK'],
    ['erDiagram\n  A { int id PK string name } B', 'labels', 'er:A:attr#1', { line: 2, col: 15 }, 'string name'],
    ['erDiagram\n  A {\n  int\n  id\n  }', 'labels', 'er:A:attr#0', { line: 3, col: 1 }, 'int\n  id'],
    ['erDiagram\n  A ||--o{ B : r %% c', 'edges', 'rel#0:A->B', { line: 2, col: 1 }, 'A ||--o{ B : r'],
    ['erDiagram\n  A ||--o{ B : r %% c', 'labels', 'rel#0:A->B', { line: 2, col: 14 }, 'r'],
    ['erDiagram\n  A ||--o{ B : "r s" %% c', 'labels', 'rel#0:A->B', { line: 2, col: 15 }, 'r s'],
  ] as const)('maps %j %s %s across lines', (source, kind, key, location, text) => {
    const parsed = parseMermaid(source)
    if (!parsed.ok) throw new Error(JSON.stringify(parsed.error))
    expect(parsed.value.source[kind].get(key)).toEqual(location)
    expect(textAt(source, parsed.value.source.spans![kind].get(key))).toBe(text)
  })

  test('BUG-26: spans read `\'` as text and `\\` as no escape, as the parser does', () => {
    // An apostrophe opens no string, so it cannot hide the `;` that ends its
    // statement; a `\` before a closing `"` escapes nothing.
    const source = 'flowchart LR\n  A[it\'s] --> B; C["x\\\\"] --> D; E --> F'
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    const spans = parsed.value.source.spans!
    expect({
      edges: ['edge#0:A->B', 'edge#1:C->D', 'edge#2:E->F'].map(key => textAt(source, spans.edges.get(key))),
      labels: ['node:A', 'node:C'].map(key => textAt(source, spans.labels.get(key))),
      nodeC: parsed.value.source.nodes.get('C'),
    }).toEqual({
      edges: ['A[it\'s] --> B', 'C["x\\\\"] --> D', 'E --> F'],
      labels: ['it\'s', 'x\\\\'],
      nodeC: { line: 2, col: 16 },
    })
  })

  test('maps a label spelled with entity codes to its authored text', () => {
    const source = 'flowchart LR\n  A["I #9829; you"] -->|#35;1<br>x| B((#lt;b))\n  subgraph S[t #amp; u]\n    C\n  end'
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    const labels = parsed.value.source.spans!.labels
    expect(['node:A', 'edge#0:A->B', 'node:B', 'group:S'].map(key => textAt(source, labels.get(key))))
      .toEqual(['I #9829; you', '#35;1<br>x', '#lt;b', 't #amp; u'])
  })

  test('maps a label whose `"` is spelled `#quot;` to its authored text', () => {
    const source = 'flowchart LR\n  A["say #quot;hi#quot;"] -->|"e #quot;q#quot;"| B\n  subgraph S["t #quot;x#quot;"]\n    C\n  end'
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    const labels = parsed.value.source.spans!.labels
    expect(textAt(source, labels.get('node:A'))).toBe('say #quot;hi#quot;')
    expect(textAt(source, labels.get('edge#0:A->B'))).toBe('e #quot;q#quot;')
    expect(textAt(source, labels.get('group:S'))).toBe('t #quot;x#quot;')
  })

  test('maps edge and node labels after the id/operator when text repeats endpoint ids', () => {
    const parsed = parseMermaid(`flowchart LR
  A[A] -->|A| B
`)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return

    expect(parsed.value.source.labels.get('node:A')).toEqual({ line: 2, col: 3 })
    expect(parsed.value.source.labels.get('edge#0:A->B')).toEqual({ line: 2, col: 10 })
  })

  test('class/ER/chart/Gantt traceability maps members, attrs, cardinalities, marks, and tasks', () => {
    const cls = parseMermaid(`classDiagram
  class Animal {
    +String name
  }
  Animal "1" --> "*" Dog : owns
`)
    expect(cls.ok).toBe(true)
    if (!cls.ok) return
    expect(cls.value.source.labels.get('class:Animal:member#0')).toEqual({ line: 3, col: 1 })
    expect(cls.value.source.labels.get('rel#0:Animal->Dog:fromCardinality')).toEqual({ line: 5, col: 9 })
    expect(cls.value.source.labels.get('rel#0:Animal->Dog:toCardinality')).toEqual({ line: 5, col: 17 })

    const er = parseMermaid(`erDiagram
  CUSTOMER {
    string email PK
  }
  CUSTOMER ||--o{ ORDER : places
`)
    expect(er.ok).toBe(true)
    if (!er.ok) return
    expect(er.value.source.labels.get('er:CUSTOMER:attr#0')).toEqual({ line: 3, col: 1 })
    expect(er.value.source.labels.get('rel#0:CUSTOMER->ORDER:leftCardinality')).toEqual({ line: 5, col: 10 })
    expect(er.value.source.labels.get('rel#0:CUSTOMER->ORDER:rightCardinality')).toEqual({ line: 5, col: 14 })

    // Statements sharing a line with an attribute block are located on it.
    const inlineEr = parseMermaid('erDiagram\n  CUSTOMER { string email PK int age } CUSTOMER ||--o{ ORDER : places\n')
    expect(inlineEr.ok).toBe(true)
    if (!inlineEr.ok) return
    expect(inlineEr.value.source.labels.get('er:CUSTOMER:attr#0')).toEqual({ line: 2, col: 12 })
    expect(inlineEr.value.source.labels.get('er:CUSTOMER:attr#1')).toEqual({ line: 2, col: 28 })
    expect(inlineEr.value.source.labels.get('rel#0:CUSTOMER->ORDER:leftCardinality')).toEqual({ line: 2, col: 47 })
    expect(inlineEr.value.source.labels.get('rel#0:CUSTOMER->ORDER:rightCardinality')).toEqual({ line: 2, col: 51 })

    const chart = parseMermaid(`xychart-beta
  x-axis [Jan, Feb]
  bar Sales [3, 7]
`)
    expect(chart.ok).toBe(true)
    if (!chart.ok) return
    expect(chart.value.source.labels.get('xychart:series-0:name')).toEqual({ line: 3, col: 5 })
    expect(chart.value.source.labels.get('xychart:series-0:point#1')).toEqual({ line: 3, col: 15 })

    const gantt = parseMermaid(`gantt
  section Build
    Core engine :core, 2024-01-01, 2d
`)
    expect(gantt.ok).toBe(true)
    if (!gantt.ok) return
    expect(gantt.value.source.groups.get('section-0')).toEqual({ line: 2, col: 9 })
    expect(gantt.value.source.nodes.get('core')).toEqual({ line: 3, col: 1 })
    expect(gantt.value.source.labels.get('gantt:task:core')).toEqual({ line: 3, col: 1 })
  })

  test('retains exact authored wrapper/directive, statement, and sub-statement spans', () => {
    const source = `---
theme: base
---
%%{init: {"flowchart": {"curve": "linear"}}}%%
%% leading comment
flowchart LR
  accTitle: Sign in flow
    A[Login] -->|yes| B[Done]
`
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return

    const spans = parsed.value.source.spans
    expect(spans).toBeDefined()
    if (!spans) return
    expect(textAt(source, spans.preserved.source)).toBe(source)
    expect(textAt(source, spans.preserved.frontmatter)).toBe('---\ntheme: base\n---\n')
    expect(textAt(source, spans.preserved.initDirectives?.[0])).toBe('%%{init: {"flowchart": {"curve": "linear"}}}%%\n')
    expect(textAt(source, spans.preserved.accessibilityDirectives?.[0])).toBe('  accTitle: Sign in flow\n')
    expect(textAt(source, spans.preserved.header)).toBe('flowchart LR')
    expect(textAt(source, spans.nodes.get('A'))).toBe('A[Login] -->|yes| B[Done]')
    expect(textAt(source, spans.edges.get('edge#0:A->B'))).toBe('A[Login] -->|yes| B[Done]')
    expect(textAt(source, spans.labels.get('node:A'))).toBe('Login')
    expect(textAt(source, spans.labels.get('edge#0:A->B'))).toBe('yes')
  })

  test('traces admitted init directives outside the leading wrapper', () => {
    const source = `flowchart LR
  A
  %%{initialize: {"theme": "dark"}}%%
  B`
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return

    expect(parsed.value.meta.initDirectives).toHaveLength(1)
    expect(parsed.value.source.spans?.preserved.initDirectives).toHaveLength(1)
    expect(textAt(source, parsed.value.source.spans?.preserved.initDirectives?.[0]))
      .toBe('  %%{initialize: {"theme": "dark"}}%%\n')
  })

  test('traces a standalone BOM as wrapper syntax outside the family header', () => {
    const source = '\uFEFFflowchart LR\n  A --> B'
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return

    const spans = parsed.value.source.spans?.preserved
    expect(parsed.value.meta.wrapperSource).toBe('\uFEFF')
    expect(textAt(source, spans?.wrapper)).toBe('\uFEFF')
    expect(textAt(source, spans?.header)).toBe('flowchart LR')
  })

  test('does not confuse accessibility prose with semantic statements', () => {
    const source = 'flowchart LR\naccDescr: A links to B\nA[Actual] --> B'
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    expect(textAt(source, parsed.value.source.spans?.nodes.get('A'))).toBe('A[Actual] --> B')
    expect(textAt(source, parsed.value.source.spans?.nodes.get('B'))).toBe('A[Actual] --> B')
    expect(parsed.value.source.nodes.get('A')).toEqual({ line: 3, col: 1 })
  })

  test('separates semicolon statements and preserves commas inside labels', () => {
    const source = 'flowchart LR\n  A[Hello, world]; B[Two]; A --> B'
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    const spans = parsed.value.source.spans!
    expect(textAt(source, spans.nodes.get('A'))).toBe('A[Hello, world]')
    expect(textAt(source, spans.nodes.get('B'))).toBe('B[Two]')
    expect(textAt(source, spans.edges.get('edge#0:A->B'))).toBe('A --> B')
    expect(textAt(source, spans.labels.get('node:A'))).toBe('Hello, world')
  })

  test('maps duplicate chart values to distinct authored occurrences', () => {
    const source = 'xychart-beta\n  x-axis [A, B, C]\n  line [10, 10, 20]'
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    const spans = parsed.value.source.spans!.labels
    const first = spans.get('xychart:series-0:point#0')!
    const second = spans.get('xychart:series-0:point#1')!
    expect(textAt(source, first)).toBe('10')
    expect(textAt(source, second)).toBe('10')
    expect(second.start.offset).toBeGreaterThan(first.end.offset)
  })

  test('anchors authored mapping after frontmatter and excludes wrapper pseudo-directives', () => {
    const source = `---
description: |
  flowchart LR
  A[Fake] --> B
  accTitle: YAML only
---
flowchart LR
  accDescr: {
    Actual description
  }
  A[Real] --> B
`
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    const spans = parsed.value.source.spans!
    expect(textAt(source, spans.nodes.get('A'))).toBe('A[Real] --> B')
    expect(spans.preserved.accessibilityDirectives).toHaveLength(1)
    expect(textAt(source, spans.preserved.accessibilityDirectives?.[0])).toContain('Actual description')
  })

  test('excludes YAML lookalikes from init directives and keeps accDescr suffix statements exact', () => {
    const source = `---
description: |
  %%{init: {theme: dark}}%%
---
%%{init: {theme: base}}%%
flowchart LR
accDescr: {
  A[Fake] prose
} A[Real] --> B
`
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    const spans = parsed.value.source.spans!
    expect(spans.preserved.initDirectives).toHaveLength(1)
    expect(textAt(source, spans.preserved.initDirectives?.[0])).toContain('theme: base')
    expect(textAt(source, spans.preserved.accessibilityDirectives?.[0])).toBe('accDescr: {\n  A[Fake] prose\n}')
    expect(textAt(source, spans.nodes.get('A'))).toBe('A[Real] --> B')
    expect(textAt(source, spans.edges.get('edge#0:A->B'))).toBe('A[Real] --> B')

    const inline = 'flowchart LR\naccDescr: {inline } A[Real] --> B'
    const inlineParsed = parseMermaid(inline)
    expect(inlineParsed.ok).toBe(true)
    if (inlineParsed.ok) expect(textAt(inline, inlineParsed.value.source.spans!.nodes.get('A'))).toBe('A[Real] --> B')
  })

  test('separates a same-line family header from its authored body statement', () => {
    const source = 'flowchart LR; A[One] --> B[Two]'
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    const spans = parsed.value.source.spans!
    expect(textAt(source, spans.preserved.header)).toBe('flowchart LR')
    expect(textAt(source, spans.preserved.body)).toBe('A[One] --> B[Two]')
    expect(textAt(source, spans.nodes.get('A'))).toBe('A[One] --> B[Two]')

    const encoded = 'flowchart&#32;LR; A --> B'
    const encodedParsed = parseMermaid(encoded)
    expect(encodedParsed.ok).toBe(true)
    if (encodedParsed.ok) {
      expect(textAt(encoded, encodedParsed.value.source.spans!.preserved.header)).toBe('flowchart&#32;LR')
      expect(textAt(encoded, encodedParsed.value.source.spans!.preserved.body)).toBe('A --> B')
    }
  })

  // Behind a wrapper too, and after a space where the family reads a statement
  // on its header line; its statement spans stand on that line.
  test.each([
    ['%% c\nflowchart LR; A --> B', 'flowchart LR', 'A --> B', ''],
    ['---\ntitle: T\n---\nflowchart LR; A --> B', 'flowchart LR', 'A --> B', ''],
    ['erDiagram A ||--o{ B : x', 'erDiagram', 'A ||--o{ B : x', 'rel#0:A->B'],
    ['sequenceDiagram A->>B: hi', 'sequenceDiagram', 'A->>B: hi', ''],
    ['gitGraph LR: commit', 'gitGraph LR:', 'commit', ''],
  ])('separates the header of %j from the statement after it', (source, header, body, edge) => {
    const parsed = parseMermaid(source)
    if (!parsed.ok) throw new Error(JSON.stringify(parsed.error))
    const spans = parsed.value.source.spans!
    expect([textAt(source, spans.preserved.header), textAt(source, spans.preserved.body)]).toEqual([header, body])
    if (edge) expect(textAt(source, spans.edges.get(edge))).toBe(body)
  })

  test('maps duplicate indexed objects to their distinct authored occurrences', () => {
    const flow = `flowchart LR
 A --> B
 A --> B`
    const flowParsed = parseMermaid(flow)
    expect(flowParsed.ok).toBe(true)
    if (!flowParsed.ok) return
    const firstEdge = flowParsed.value.source.spans!.edges.get('edge#0:A->B')!
    const secondEdge = flowParsed.value.source.spans!.edges.get('edge#1:A->B')!
    expect(firstEdge.start.line).toBe(2)
    expect(secondEdge.start.line).toBe(3)

    const mixed = `flowchart LR
 A -->|named| B
 A --> B`
    const mixedParsed = parseMermaid(mixed)
    expect(mixedParsed.ok).toBe(true)
    if (mixedParsed.ok) {
      expect(mixedParsed.value.source.spans!.edges.get('edge#0:A->B')!.start.line).toBe(2)
      expect(mixedParsed.value.source.spans!.edges.get('edge#1:A->B')!.start.line).toBe(3)
    }

    const targetNamedLabel = `flowchart LR
 A -- B --> B
 A --> B`
    const targetNamedParsed = parseMermaid(targetNamedLabel)
    expect(targetNamedParsed.ok).toBe(true)
    if (targetNamedParsed.ok) {
      expect(textAt(targetNamedLabel, targetNamedParsed.value.source.spans!.edges.get('edge#0:A->B'))).toBe('A -- B --> B')
      expect(textAt(targetNamedLabel, targetNamedParsed.value.source.spans!.edges.get('edge#1:A->B'))).toBe('A --> B')
    }

    for (const marker of ['x', 'o'] as const) {
      const marked = `flowchart LR\n A -- B --${marker} B\n A --${marker} B`
      const markedParsed = parseMermaid(marked)
      expect(markedParsed.ok).toBe(true)
      if (markedParsed.ok) {
        expect(textAt(marked, markedParsed.value.source.spans!.edges.get('edge#0:A->B'))).toBe(`A -- B --${marker} B`)
        expect(textAt(marked, markedParsed.value.source.spans!.edges.get('edge#1:A->B'))).toBe(`A --${marker} B`)
      }
    }

    const xy = 'xychart-beta\n line [10,20]\n line [30,40]'
    const xyParsed = parseMermaid(xy)
    expect(xyParsed.ok).toBe(true)
    if (xyParsed.ok) {
      expect(textAt(xy, xyParsed.value.source.spans!.labels.get('xychart:series-0:point#0'))).toBe('10')
      expect(textAt(xy, xyParsed.value.source.spans!.labels.get('xychart:series-1:point#0'))).toBe('30')
    }

    const pie = 'pie\n "Same": 1\n "Same": 2'
    const pieParsed = parseMermaid(pie)
    expect(pieParsed.ok).toBe(true)
    if (pieParsed.ok) {
      // A repeated Pie label now falls back to a lossless opaque body: there
      // are no addressable typed slices, but both authored rows remain in the
      // preserved source span.
      expect(pieParsed.value.body.kind).toBe('opaque')
      expect(pieParsed.value.source.spans!.labels.size).toBe(0)
      expect(textAt(pie, pieParsed.value.source.spans!.preserved.body)).toBe(' "Same": 1\n "Same": 2')
    }

    const piePrefix = 'pie\n "AA": 1\n "A": 2'
    const piePrefixParsed = parseMermaid(piePrefix)
    expect(piePrefixParsed.ok).toBe(true)
    if (piePrefixParsed.ok) {
      expect(textAt(piePrefix, piePrefixParsed.value.source.spans!.labels.get('pie:slice#0'))).toBe('AA')
      expect(textAt(piePrefix, piePrefixParsed.value.source.spans!.labels.get('pie:slice#1'))).toBe('A')
      expect(piePrefixParsed.value.source.spans!.labels.get('pie:slice#1')!.start.line).toBe(3)
    }

    for (const [source, keys] of [
      ['classDiagram\n class A {\n +x\n +x\n }', ['class:A:member#0', 'class:A:member#1']],
      ['erDiagram\n A {\n string x\n string x\n }', ['er:A:attr#0', 'er:A:attr#1']],
      ['gantt\n dateFormat YYYY-MM-DD\n Same :a, 2024-01-01, 1d\n Same :b, 2024-01-01, 1d', ['gantt:task:a', 'gantt:task:b']],
    ] as const) {
      const item = parseMermaid(source)
      expect(item.ok).toBe(true)
      if (item.ok) {
        const first = item.value.source.spans!.labels.get(keys[0])!
        const second = item.value.source.spans!.labels.get(keys[1])!
        expect(second.start.line).toBeGreaterThan(first.start.line)
      }
    }
  })

  test('keeps pipe-label semicolons inside statements and maps exact chart tokens', () => {
    const flow = 'flowchart LR\n A[one] -->|x; y| B; C[three]'
    const parsed = parseMermaid(flow)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    expect(textAt(flow, parsed.value.source.spans!.edges.get('edge#0:A->B'))).toBe('A[one] -->|x; y| B')
    expect(textAt(flow, parsed.value.source.spans!.labels.get('edge#0:A->B'))).toBe('x; y')
    expect(textAt(flow, parsed.value.source.spans!.nodes.get('C'))).toBe('C[three]')

    for (const [source, key, expected] of [
      ['pie\n "pie": 1', 'pie:slice#0', 'pie'],
      ['pie\n "multi\n label": 1\n "b": 2', 'pie:slice#1', 'b'],
      ['quadrantChart\n quadrant: [0.2,0.3]', 'quadrant:point#0', 'quadrant'],
      ['radar-beta\n axis a["Same"], b["Same"]\n curve c{1,2}', 'radar:axis#0', 'a'],
      ['radar-beta\n axis a["Same"], b["Same"]\n curve c{1,2}', 'radar:curve#0', 'c'],
      ['gantt\n dateFormat YYYY-MM-DD\n section S\n Same :a, 2024-01-01, 1d', 'gantt:task:a', 'Same'],
      // A text-arrow label ends at the link that closes it, a dotted one
      // without its leading `-` too, and a solid one holds a `.-` as text.
      ['flowchart LR\n  A -. x .- y .-> B', 'edge#0:A->y', 'x'],
      ['flowchart LR\n  A -- a.-b --> B', 'edge#0:A->B', 'a.-b'],
    ] as const) {
      const item = parseMermaid(source)
      expect(item.ok).toBe(true)
      if (item.ok) expect(textAt(source, item.value.source.spans!.labels.get(key))).toBe(expected)
    }
  })

  test('rebuilds source maps after mutation instead of retaining removed objects', () => {
    const parsed = parseMermaid('flowchart LR\n A[Old] --> B')
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    const changed = mutate(parsed.value, { kind: 'remove_node', id: 'A' })
    expect(changed.ok).toBe(true)
    if (!changed.ok) return
    expect(changed.value.source.nodes.has('A')).toBe(false)
    expect(changed.value.source.spans!.nodes.has('A')).toBe(false)
    expect(textAt(changed.value.canonicalSource, changed.value.source.spans!.preserved.source)).toBe(changed.value.canonicalSource)
  })

  test('keeps bare text-arrow semicolons and accDescr suffix shapes inside exact statements', () => {
    const flow = 'flowchart LR\n A -- x;y;z --> B; B --> C'
    const parsed = parseMermaid(flow)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    expect(textAt(flow, parsed.value.source.spans!.edges.get('edge#0:A->B'))).toBe('A -- x;y;z --> B')
    expect(textAt(flow, parsed.value.source.spans!.labels.get('edge#0:A->B'))).toBe('x;y;z')
    expect(textAt(flow, parsed.value.source.spans!.edges.get('edge#1:B->C'))).toBe('B --> C')

    const accessibility = 'flowchart LR\naccDescr: {\n prose\n} A{Decision} --> B'
    const accessible = parseMermaid(accessibility)
    expect(accessible.ok).toBe(true)
    if (!accessible.ok) return
    expect(textAt(accessibility, accessible.value.source.spans!.nodes.get('A'))).toBe('A{Decision} --> B')
    expect(textAt(accessibility, accessible.value.source.spans!.nodes.get('B'))).toBe('A{Decision} --> B')
  })

  test('scopes class and ER source maps to declarations, members, relations, and full cardinalities', () => {
    const cls = `classDiagram
 note "A B"
 note "+x"
 class A {
 +x
 }
 A "one" --> "many" B`
    const classParsed = parseMermaid(cls)
    expect(classParsed.ok).toBe(true)
    if (!classParsed.ok) return
    const classSpans = classParsed.value.source.spans!
    expect(textAt(cls, classSpans.nodes.get('A'))).toBe('class A {')
    expect(textAt(cls, classSpans.nodes.get('B'))).toBe('A "one" --> "many" B')
    expect(textAt(cls, classSpans.labels.get('class:A:member#0'))).toBe('+x')
    expect(textAt(cls, classSpans.edges.get('rel#0:A->B'))).toBe('A "one" --> "many" B')
    expect(textAt(cls, classSpans.labels.get('rel#0:A->B:fromCardinality'))).toBe('one')
    expect(textAt(cls, classSpans.labels.get('rel#0:A->B:toCardinality'))).toBe('many')

    const duplicateCards = 'classDiagram\n A "1" --> "1" B'
    const duplicateParsed = parseMermaid(duplicateCards)
    expect(duplicateParsed.ok).toBe(true)
    if (duplicateParsed.ok) {
      const from = duplicateParsed.value.source.spans!.labels.get('rel#0:A->B:fromCardinality')!
      const to = duplicateParsed.value.source.spans!.labels.get('rel#0:A->B:toCardinality')!
      expect(textAt(duplicateCards, from)).toBe('1')
      expect(textAt(duplicateCards, to)).toBe('1')
      expect(to.start.offset).toBeGreaterThan(from.end.offset)
    }

    const er = `erDiagram
 A ||--o{ B : string x
 A {
 string x
 }
 B`
    const erParsed = parseMermaid(er)
    expect(erParsed.ok).toBe(true)
    if (!erParsed.ok) return
    const erSpans = erParsed.value.source.spans!
    expect(textAt(er, erSpans.nodes.get('A'))).toBe('A {')
    expect(textAt(er, erSpans.nodes.get('B'))).toBe('B')
    expect(textAt(er, erSpans.labels.get('er:A:attr#0'))).toBe('string x')
    expect(textAt(er, erSpans.edges.get('rel#0:A->B'))).toBe('A ||--o{ B : string x')

    const compact = 'classDiagram\n namespace X { class A; class B; A --> B }'
    const compactParsed = parseMermaid(compact)
    expect(compactParsed.ok).toBe(true)
    if (compactParsed.ok) {
      expect(compactParsed.value.source.nodes.get('A')?.line).toBe(2)
      expect(compactParsed.value.source.nodes.get('B')?.line).toBe(2)
      expect(compactParsed.value.source.edges.get('rel#0:A->B')?.line).toBe(2)
      expect(compactParsed.value.source.spans?.nodes.has('A')).toBe(true)
      expect(compactParsed.value.source.spans?.edges.has('rel#0:A->B')).toBe(true)
      expect(textAt(compact, compactParsed.value.source.spans?.nodes.get('A'))).toBe('class A')
      expect(textAt(compact, compactParsed.value.source.spans?.nodes.get('B'))).toBe('class B')
      expect(textAt(compact, compactParsed.value.source.spans?.edges.get('rel#0:A->B'))).toBe('A --> B')
    }
  })

  test('does not map flowchart nodes to family-header or label tokens', () => {
    const source = `flowchart LR
 LR --> A
 X[B]; X -- A --> A; B --> C`
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return

    expect(parsed.value.source.nodes.get('LR')).toEqual({ line: 2, col: 1 })
    expect(textAt(source, parsed.value.source.spans?.nodes.get('LR'))).toBe('LR --> A')
    expect(parsed.value.source.nodes.get('A')).toEqual({ line: 2, col: 8 })
    expect(textAt(source, parsed.value.source.spans?.nodes.get('B'))).toBe('B --> C')
  })

  test('maps compact edge endpoints without confusing hyphenated ids', () => {
    for (const [source, expected] of [
      ['flowchart LR\nA-->B', ['A', 'B']],
      ['flowchart LR\nA---B', ['A', 'B']],
      ['flowchart LR\nfoo-bar-->baz\nbar', ['foo-bar', 'baz', 'bar']],
    ] as const) {
      const parsed = parseMermaid(source)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) continue
      expect([...parsed.value.source.nodes.keys()].sort()).toEqual([...expected].sort())
      expect(parsed.value.source.nodes.get(expected[0])?.line).toBe(2)
    }

    // A single hyphen joins an id; `--` always opens a link, so `foo--bar`
    // is no id (upstream rejects it: its link label never closes).
    expect(parseMermaid('flowchart LR\nfoo--bar\nfoo\nbar').ok).toBe(false)
    const hyphenated = 'flowchart LR\nfoo-bar\nfoo\nbar'
    const hyphenatedParsed = parseMermaid(hyphenated)
    expect(hyphenatedParsed.ok).toBe(true)
    if (hyphenatedParsed.ok) {
      expect(hyphenatedParsed.value.source.nodes.get('foo-bar')).toEqual({ line: 2, col: 1 })
      expect(hyphenatedParsed.value.source.nodes.get('foo')).toEqual({ line: 3, col: 1 })
      expect(hyphenatedParsed.value.source.nodes.get('bar')).toEqual({ line: 4, col: 1 })
      expect(textAt(hyphenated, hyphenatedParsed.value.source.spans!.nodes.get('bar'))).toBe('bar')
    }

    const marked = `flowchart LR
x-->A
o==>B
C--xD
E--oF
Go--xH`
    const markedParsed = parseMermaid(marked)
    expect(markedParsed.ok).toBe(true)
    if (markedParsed.ok) {
      expect([...markedParsed.value.source.nodes.keys()].sort())
        .toEqual(['x', 'A', 'o', 'B', 'C', 'D', 'E', 'F', 'Go', 'H'].sort())
      for (const [key, statement] of [
        ['edge#0:x->A', 'x-->A'],
        ['edge#1:o->B', 'o==>B'],
        ['edge#2:C->D', 'C--xD'],
        ['edge#3:E->F', 'E--oF'],
        // An `o` after id characters is the id's (upstream's node string).
        ['edge#4:Go->H', 'Go--xH'],
      ] as const) {
        expect(textAt(marked, markedParsed.value.source.spans!.edges.get(key))).toBe(statement)
      }
    }

    const sourceMarkers = `flowchart LR
A o--x B
o
A x--o B
x`
    const sourceMarkersParsed = parseMermaid(sourceMarkers)
    expect(sourceMarkersParsed.ok).toBe(true)
    if (sourceMarkersParsed.ok) {
      expect(sourceMarkersParsed.value.source.nodes.get('o')).toEqual({ line: 3, col: 1 })
      expect(sourceMarkersParsed.value.source.nodes.get('x')).toEqual({ line: 5, col: 1 })
      expect(textAt(sourceMarkers, sourceMarkersParsed.value.source.spans!.nodes.get('o'))).toBe('o')
      expect(textAt(sourceMarkers, sourceMarkersParsed.value.source.spans!.nodes.get('x'))).toBe('x')
    }

    for (const statement of [
      'A-->|L|x--xB',
      'A-->|L|o--oB',
      'A-.->|L|x--xB',
      'A==>|L|o--oB',
    ]) {
      const source = `flowchart LR\n${statement}`
      const parsed = parseMermaid(source)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) continue
      const endpoint = statement.includes('|x') ? 'x' : 'o'
      expect(parsed.value.source.nodes.get(endpoint)).toEqual({ line: 2, col: statement.indexOf(endpoint) + 1 })
      expect(parsed.value.source.edges.has(`edge#0:A->${endpoint}`)).toBe(true)
      expect(parsed.value.source.edges.has(`edge#1:${endpoint}->B`)).toBe(true)
      expect(textAt(source, parsed.value.source.spans!.labels.get(`edge#0:A->${endpoint}`))).toBe('L')
    }

    const compactLabel = `flowchart LR
A--lab-->B
A-->B
lab`
    const compactLabelParsed = parseMermaid(compactLabel)
    expect(compactLabelParsed.ok).toBe(true)
    if (compactLabelParsed.ok) {
      expect(compactLabelParsed.value.source.nodes.get('lab')).toEqual({ line: 4, col: 1 })
      expect(textAt(compactLabel, compactLabelParsed.value.source.spans!.edges.get('edge#0:A->B'))).toBe('A--lab-->B')
      expect(textAt(compactLabel, compactLabelParsed.value.source.spans!.edges.get('edge#1:A->B'))).toBe('A-->B')
      expect(textAt(compactLabel, compactLabelParsed.value.source.spans!.labels.get('edge#0:A->B'))).toBe('lab')
    }

    const quotedCompact = 'flowchart LR\nA--"x --> y"-->B'
    const quotedCompactParsed = parseMermaid(quotedCompact)
    expect(quotedCompactParsed.ok).toBe(true)
    if (quotedCompactParsed.ok) {
      expect(textAt(quotedCompact, quotedCompactParsed.value.source.spans!.edges.get('edge#0:A->B'))).toBe('A--"x --> y"-->B')
      expect(textAt(quotedCompact, quotedCompactParsed.value.source.spans!.labels.get('edge#0:A->B'))).toBe('x --> y')
    }

    for (const source of [
      'flowchart LR\nA[--foo-->]-->B',
      'flowchart LR\nA["|foo|"]-->B',
      'flowchart LR\nA@{label: "--foo-->"}-->B',
    ]) {
      const parsed = parseMermaid(source)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) continue
      expect(parsed.value.source.edges.get('edge#0:A->B')).toEqual({ line: 2, col: 1 })
      expect(textAt(source, parsed.value.source.spans!.edges.get('edge#0:A->B'))).toBe(source.split('\n')[1])
    }

    const repeatedLabel = `flowchart LR
A[--lab] -->|other| B
A -->|lab| B`
    const repeatedLabelParsed = parseMermaid(repeatedLabel)
    expect(repeatedLabelParsed.ok).toBe(true)
    if (repeatedLabelParsed.ok) {
      expect(repeatedLabelParsed.value.source.edges.get('edge#1:A->B')).toEqual({ line: 3, col: 1 })
      expect(repeatedLabelParsed.value.source.labels.get('edge#1:A->B')).toEqual({ line: 3, col: 7 })
      expect(textAt(repeatedLabel, repeatedLabelParsed.value.source.spans!.labels.get('edge#1:A->B'))).toBe('lab')
    }

    const inlineCollision = 'flowchart LR\nA[-- x] -- x --> B'
    const inlineCollisionParsed = parseMermaid(inlineCollision)
    expect(inlineCollisionParsed.ok).toBe(true)
    if (inlineCollisionParsed.ok) {
      expect(inlineCollisionParsed.value.source.labels.get('edge#0:A->B')).toEqual({ line: 2, col: 12 })
      expect(textAt(inlineCollision, inlineCollisionParsed.value.source.spans!.labels.get('edge#0:A->B'))).toBe('x')
    }
  })

  test('maps near-limit hyphenated ids without quadratic label scanning', () => {
    const id = `A${'-a'.repeat(25_000)}`
    const parsed = parseMermaid(`flowchart LR\n${id}`)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    expect(parsed.value.source.nodes.get(id)).toEqual({ line: 2, col: 1 })

    expectNearLinearGrowth('hyphenated id', size => {
      expect(parseMermaid(`flowchart LR\nA${'-a'.repeat(size)}`).ok).toBe(true)
    }, 25_000)
    expectNearLinearGrowth('packed statements', size => {
      expect(parseMermaid(`flowchart LR\n${'A;'.repeat(size)}B-->C`).ok).toBe(true)
    }, 10_000)
    expectNearLinearGrowth('semicolon-bearing text label', size => {
      expect(parseMermaid(`flowchart LR\nA -- x; ${'y; '.repeat(size)}z --> B`).ok).toBe(true)
    }, 16_000)
    expectNearLinearGrowth('quoted label with edge-like text', size => {
      expect(parseMermaid(`flowchart LR\nA["${'x -- '.repeat(size)}x"];${Array.from({ length: 100 }, (_, index) => `N${index}`).join(';')}`).ok).toBe(true)
    }, 2_000)
  })

  test('indexes line starts once for many mapped objects', () => {
    const sourceFor = (count: number): string => `flowchart LR\n${Array.from(
      { length: count },
      (_, index) => `N${index}`,
    ).join('\n')}`
    const count = DIAGRAM_WORK_LIMITS.nodes
    const source = sourceFor(count)
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (parsed.ok) {
      const id = `N${count - 1}`
      const last = parsed.value.source.spans!.nodes.get(id)!
      expect(last.start).toEqual({ offset: source.lastIndexOf(id), line: count + 1, col: 1 })
    }
    expectNearLinearGrowth('mapped objects', size => {
      expect(parseMermaid(sourceFor(size)).ok).toBe(true)
    }, count)
  })

  test('keeps same-line and repeated-node chains within a linear-time envelope', () => {
    expectNearLinearGrowth('same-line chain of unique nodes', size => {
      expect(parseMermaid(`flowchart LR\n${Array.from({ length: size }, (_, index) => `N${index}`).join('-->')}`).ok).toBe(true)
    }, 2_400)
    expectNearLinearGrowth('same-line chain of one repeated node', size => {
      expect(parseMermaid(`flowchart LR\n${Array.from({ length: size }, () => 'A').join('-->')}`).ok).toBe(true)
    }, 150)
    expectNearLinearGrowth('same-line chain of shaped nodes', size => {
      expect(parseMermaid(`flowchart LR\n${Array.from({ length: size }, (_, index) => `N${index}[L${index}]`).join('-->')}`).ok).toBe(true)
    }, DIAGRAM_WORK_LIMITS.nodes)
  })

  test('keeps long unquoted labels in a same-line chain within a linear-time envelope', () => {
    const padding = 'x'.repeat(64)
    // measureGrowth's default factor is 16; stay within the host's node cap.
    const { ratio } = measureGrowth(size => {
      const source = `flowchart LR\n${Array.from({ length: size }, (_, index) => `N${index}[L${index}${padding}]`).join('-->')}`
      const parsed = parseMermaid(source)
      expect(parsed.ok).toBe(true)
      if (parsed.ok) expect(parsed.value.body.kind).toBe('flowchart')
      if (parsed.ok && parsed.value.body.kind === 'flowchart') {
        expect(parsed.value.body.graph.nodes.size).toBe(size)
        expect(parsed.value.body.graph.edges).toHaveLength(size - 1)
        expect(textAt(source, parsed.value.source.spans!.labels.get(`node:N${size - 1}`))).toBe(`L${size - 1}${padding}`)
      }
    }, Math.floor(DIAGRAM_WORK_LIMITS.nodes / 16))
    expect(ratio).toBeLessThan(LINEAR_GROWTH_CEILING)
  })

  test('indexes preservation coordinates and merges accessibility spans linearly', () => {
    expectNearLinearGrowth('accTitle preservation spans', size => {
      const titles = `flowchart LR\n${Array.from({ length: size }, (_, index) => `accTitle: T${index}`).join('\n')}`
      expect(sourcePreservationSpans(titles, 'flowchart LR').accessibilityDirectives).toHaveLength(size)
    }, 16_000)
    expectNearLinearGrowth('mixed accDescr/accTitle preservation spans', size => {
      const mixed = `flowchart LR\n${Array.from({ length: size }, (_, index) =>
        `accDescr {\naccTitle: hidden ${index}\n}\naccTitle: visible ${index}`).join('\n')}`
      expect(sourcePreservationSpans(mixed, 'flowchart LR').accessibilityDirectives).toHaveLength(2 * size)
    }, 4_000)
  })

  test('keeps compact labels inside statement and grammar boundaries', () => {
    // Upstream's `--` opens a text-arrow label wherever it is not a link, and
    // the label runs to the closing link, `;` included: one edge foo→B
    // labelled "bar; A" (pinned Mermaid 11.16).
    const packed = 'flowchart LR\nfoo--bar; A-->B'
    const packedParsed = parseMermaid(packed)
    expect(packedParsed.ok).toBe(true)
    if (packedParsed.ok) {
      expect([...packedParsed.value.source.nodes.keys()].sort()).toEqual(['B', 'foo'])
      expect(textAt(packed, packedParsed.value.source.spans!.edges.get('edge#0:foo->B'))).toBe('foo--bar; A-->B')
      expect(textAt(packed, packedParsed.value.source.spans!.labels.get('edge#0:foo->B'))).toBe('bar; A')
    }

    for (const [statement, id] of [
      ['A & o--x B', 'o'],
      ['A & x--o B', 'x'],
    ] as const) {
      const source = `flowchart LR\n${statement}`
      const parsed = parseMermaid(source)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) continue
      expect(parsed.value.source.nodes.get(id)).toEqual({ line: 2, col: 5 })
      expect(parsed.value.source.edges.get(`edge#1:${id}->B`)).toEqual({ line: 2, col: 5 })
    }

    for (const statement of [
      'A -- x --> B --> C',
      'A --> B -- x --> C',
      'A-->|x|B-->C',
      'A-->B-->|x|C',
    ]) {
      const source = `flowchart LR\n${statement}`
      const parsed = parseMermaid(source)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) continue
      expect(parsed.value.source.edges.has('edge#0:A->B')).toBe(true)
      expect(parsed.value.source.edges.has('edge#1:B->C')).toBe(true)
      expect(textAt(source, parsed.value.source.spans!.edges.get('edge#0:A->B'))).toBe(statement)
      expect(textAt(source, parsed.value.source.spans!.edges.get('edge#1:B->C'))).toBe(statement)
    }

    const repeatedNodeChain = 'flowchart LR\nA --> B -->|prior| A --> C'
    const repeatedNodeParsed = parseMermaid(repeatedNodeChain)
    expect(repeatedNodeParsed.ok).toBe(true)
    if (repeatedNodeParsed.ok) {
      expect(repeatedNodeParsed.value.source.edges.get('edge#2:A->C')).toEqual({ line: 2, col: 20 })
      expect(textAt(repeatedNodeChain, repeatedNodeParsed.value.source.spans!.edges.get('edge#2:A->C')))
        .toBe('A --> B -->|prior| A --> C')
    }
  })

  test('does not map nodes to edge ids or class suffixes', () => {
    const source = `flowchart LR
A e1@--> B
e1[Node]
C:::foo
foo[Node]`
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return

    expect(parsed.value.source.nodes.get('e1')).toEqual({ line: 3, col: 1 })
    expect(parsed.value.source.nodes.get('foo')).toEqual({ line: 5, col: 1 })
    expect(textAt(source, parsed.value.source.spans!.nodes.get('e1'))).toBe('e1[Node]')
    expect(textAt(source, parsed.value.source.spans!.nodes.get('foo'))).toBe('foo[Node]')
  })

  test('does not map implicit node labels to unrelated explicit labels', () => {
    for (const [source, absent, present] of [
      ['flowchart LR\nA -->|A| B', 'node:A', 'edge#0:A->B'],
      ['flowchart LR\nA --> B[A]', 'node:A', 'node:B'],
    ] as const) {
      const parsed = parseMermaid(source)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) continue
      expect(parsed.value.source.labels.has(absent)).toBe(false)
      expect(textAt(source, parsed.value.source.spans!.labels.get(present))).toBe('A')
    }
  })

  test('maps chart and Gantt tokens by grammar role and source occurrence', async () => {
    const xy = 'xychart-beta\n line "line" [1 "Q2", 3 "Q4"]'
    const xyParsed = parseMermaid(xy)
    expect(xyParsed.ok).toBe(true)
    if (!xyParsed.ok) return
    expect(textAt(xy, xyParsed.value.source.spans!.labels.get('xychart:series-0:name'))).toBe('line')
    expect(xyParsed.value.source.spans!.labels.get('xychart:series-0:name')!.start.col).toBe(8)
    expect(textAt(xy, xyParsed.value.source.spans!.labels.get('xychart:series-0:point#1'))).toBe('3')

    const { serializeMermaid, renderMermaidSVG } = await import('../agent/index.ts')
    const { startUpstreamMermaid } = await import('./helpers/upstream-mermaid.ts')
    const upstream = startUpstreamMermaid()
    try {
      for (const [source, tokens, labels] of [
        ['quadrantChart\n title quadrant: [fake]\n quadrant: [0.2,0.3]', ['quadrant'], ['quadrant']],
        ['quadrantChart\n"First\n    Second":[0.2,0.3]; Last:[0.6,0.7]', ['"First\n    Second"', 'Last'], ['First\n    Second', 'Last']],
        ['quadrantChart\n "A&amp;amp; B\n    C":::hot:[0.2,0.3]radius:10; "Tail&amp;amp; D":[0.6,0.7]\nclassDef hot color:#112233', ['"A&amp;amp; B\n    C"', '"Tail&amp;amp; D"'], ['A&amp; B\n    C', 'Tail&amp; D']],
      ] as const) {
        const parsed = parseMermaid(source)
        expect(parsed.ok).toBe(true)
        if (!parsed.ok || parsed.value.body.kind !== 'quadrant') throw Error('Expected structured Quadrant points')
        expect(parsed.value.body.points.map(point => point.label)).toEqual([...labels])
        tokens.forEach((token, index) => {
          const point = parsed.value.source.spans!.labels.get(`quadrant:point#${index}`)!
          expect(point).toBeDefined()
          expect(textAt(source, point)).toBe(token)
          expect(point.start.offset).toBe(source.lastIndexOf(token))
        })
        const saved = serializeMermaid(parsed.value, { wrapper: 'canonical' })
        expect(await upstream.publicAccepts(source)).toBe(true)
        expect(await upstream.publicAccepts(saved)).toBe(true)
        expect(renderMermaidSVG(saved)).toBe(renderMermaidSVG(source))
      }
    } finally { upstream.close() }

    const gantt = `gantt
 section Same
 A :a, 2024-01-01, 1d
 section Same
 B :b, 2024-01-02, 1d`
    const ganttParsed = parseMermaid(gantt)
    expect(ganttParsed.ok).toBe(true)
    if (ganttParsed.ok) {
      expect(ganttParsed.value.source.spans!.groups.get('section-0')!.start.line).toBe(2)
      expect(ganttParsed.value.source.spans!.groups.get('section-1')!.start.line).toBe(4)
    }

    const keyword = 'gantt\n section section\n T :t, 2024-01-01, 1d'
    const keywordParsed = parseMermaid(keyword)
    expect(keywordParsed.ok).toBe(true)
    if (keywordParsed.ok) expect(textAt(keyword, keywordParsed.value.source.spans!.labels.get('gantt:section-0:label'))).toBe('section')
  })

  test('does not map ER entities to family or subgraph control lines with the same name', () => {
    const source = `erDiagram
 subgraph Domain
 erDiagram ||--o{ B : owns
 end
 end ||--o{ C : closes`
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return

    expect(parsed.value.source.nodes.get('erDiagram')).toEqual({ line: 3, col: 1 })
    expect(parsed.value.source.nodes.get('end')).toEqual({ line: 5, col: 1 })
    expect(textAt(source, parsed.value.source.spans?.nodes.get('erDiagram'))).toBe('erDiagram ||--o{ B : owns')
    expect(textAt(source, parsed.value.source.spans?.nodes.get('end'))).toBe('end ||--o{ C : closes')

    const bare = parseMermaid('erDiagram\nerDiagram')
    expect(bare.ok).toBe(true)
    if (bare.ok) {
      expect(bare.value.source.nodes.get('erDiagram')).toEqual({ line: 2, col: 1 })
      expect(textAt('erDiagram\nerDiagram', bare.value.source.spans?.nodes.get('erDiagram'))).toBe('erDiagram')
    }
  })
})


test('exact span categories including empty maps retain authority while absent categories fall back', () => {
  const source = 'flowchart LR\nsubgraph S[Group]\nA[Login] -->|yes| B[Done]\nend'
  const parsed = parseMermaid(source)
  if (!parsed.ok) throw new Error(JSON.stringify(parsed.error))
  const map = parsed.value.source
  const starts = sourceLineStarts(source)
  const exactNodes = new Map([
    ['A', sourceSpan(starts, source.indexOf('A[Login]'), source.indexOf('A[Login]') + 8)],
    ['B', sourceSpan(starts, source.indexOf('B[Done]'), source.indexOf('B[Done]') + 7)],
  ])
  const exactLabels = new Map<string, SourceSpan>()
  const metadata: NonNullable<SourceMapSpans['metadata']> = new Map()
  recordAuthoredSourceMapSpans(map, { nodes: exactNodes, labels: exactLabels, metadata })
  attachSourceMapSpans(map, source, source, sourcePreservationSpans(source, 'flowchart LR'), 'flowchart')
  expect(map.spans!.nodes).toBe(exactNodes)
  expect([...map.spans!.nodes].map(([id, span]) => [id, textAt(source, span)])).toEqual([['A', 'A[Login]'], ['B', 'B[Done]']])
  expect(map.spans!.labels).toBe(exactLabels)
  expect([...map.spans!.labels]).toEqual([])
  expect([...map.labels.keys()]).toEqual(['node:A', 'node:B', 'group:S', 'edge#0:A->B'])
  expect([...map.spans!.edges].map(([id, span]) => [id, textAt(source, span)])).toEqual([['edge#0:A->B', 'A[Login] -->|yes| B[Done]'], ['A->B', 'A[Login] -->|yes| B[Done]']])
  expect([...map.spans!.groups].map(([id, span]) => [id, textAt(source, span)])).toEqual([['S', 'subgraph S[Group]']])
  expect(map.spans!.metadata).toBe(metadata)
  expect([...map.nodes]).toEqual([['A', { line: 3, col: 1 }], ['B', { line: 3, col: 19 }]])
})

test.each([
  ['without authored context', '', false, 1, false],
  ['unwrapped identical', '', false, 1, true],
  ['wrapped identical', '---\r\ntitle: Wrapper\r\n---\r\n', false, 1, true],
  ['wrapped different', '---\r\ntitle: Wrapper\r\n---\r\n', true, 2, true],
] as const)('observed maps read %s bytes without losing coordinate projections', (_name, wrapper, different, expectedReads, withContext) => {
  const source = [
    'wardley-beta', 'component A [80.0, 30.0]', 'component B [20.0, 70.0]',
    'component A [60.0, 40.0]', 'pipeline A {', 'component C [50.0]', '}', 'A -> B ;needs',
  ].join('\r\n')
  const authored = different ? source.replace('component A [60.0, 40.0]', 'component "A" [60.0, 40.0]') : source
  const original = wrapper + authored
  const reads: string[] = []
  const map = mapObservedSource(source, withContext ? { originalText: original, wrapperSource: wrapper } : undefined, (text, range) => {
    reads.push(text)
    let link = 0
    withParserObservation('wardley', event => {
      if (event.unit !== 'mutation' || event.source?.offset === undefined || event.source.endOffset === undefined) return
      const add = range(event.source.offset, event.source.endOffset)
      if (event.kind === 'add-node') {
        const { id } = event.value as { id: string }
        add('nodes', id); add('labels', `node:${id}`)
      } else if (event.kind === 'start-pipeline') add('groups', `pipeline:${(event.value as { nodeId: string }).nodeId}`)
      else if (event.kind === 'add-link') add('edges', `dependency:${link++}`)
    }, () => parseWardleyBody(text))
  })
  expect(reads).toEqual(expectedReads === 1 ? [source] : [source, authored.replaceAll('\r\n', '\n')])
  expect([...map.nodes]).toEqual([['A', { line: 4, col: 1 }], ['B', { line: 3, col: 1 }], ['A_C', { line: 6, col: 1 }]])
  expect([...map.groups]).toEqual([['pipeline:A', { line: 5, col: 1 }]])
  expect([...map.edges]).toEqual([['dependency:0', { line: 8, col: 1 }]])
  expect([...map.labels.keys()]).toEqual(['node:A', 'node:B', 'node:A_C'])
  const canonicalLocation = map.nodes.get('A')!
  expect(Object.keys(canonicalLocation)).toEqual(['line', 'col'])
  expect(Object.isFrozen(canonicalLocation)).toBe(false)
  attachSourceMapSpans(map, source, original, sourcePreservationSpans(original, 'wardley-beta', wrapper.length))
  const spans = map.spans!
  expect([...spans.nodes].map(([id, span]) => [id, textAt(original, span)])).toEqual([
    ['A', different ? 'component "A" [60.0, 40.0]' : 'component A [60.0, 40.0]'], ['B', 'component B [20.0, 70.0]'], ['A_C', 'component C [50.0]'],
  ])
  expect(textAt(original, spans.groups.get('pipeline:A'))).toBe('pipeline A {\r\ncomponent C [50.0]\r\n}')
  expect(textAt(original, spans.edges.get('dependency:0'))).toBe('A -> B ;needs')
  expect([...spans.labels].map(([id, span]) => [id, textAt(original, span)])).toEqual([
    ['node:A', different ? 'component "A" [60.0, 40.0]' : 'component A [60.0, 40.0]'], ['node:B', 'component B [20.0, 70.0]'], ['node:A_C', 'component C [50.0]'],
  ])
  const point = spans.nodes.get('A')!
  expect(point.start).toEqual({ offset: original.indexOf(different ? 'component "A"' : 'component A [60'), line: wrapper ? 7 : 4, col: 1 })
  for (const span of [point, spans.labels.get('node:A')!]) {
    expect(Object.isFrozen(span)).toBe(true)
    expect(Object.isFrozen(span.start)).toBe(true)
    expect(Object.isFrozen(span.end)).toBe(true)
    expect(Reflect.set(span.start, 'col', 77)).toBe(false)
  }
  canonicalLocation.col = 99
  expect(point.start.col).toBe(1)
  expect(map.labels.get('node:A')!.col).toBe(1)
  map.labels.get('node:A')!.line = 77
  expect(canonicalLocation.line).toBe(4)
  expect(spans.labels.get('node:A')!.start.col).toBe(1)
})

test('observed source readers preserve native refusals in either coordinate input', () => {
  const invalid = 'wardley-beta\ncomponent A'
  for (const [source, expectedReads] of [[invalid, 1], ['wardley-beta\ncomponent A [80.0, 30.0]', 2]] as const) {
    let reads = 0
    expect(() => mapObservedSource(source, { originalText: invalid }, text => {
      reads++
      parseWardleyBody(text)
    })).toThrow('wardley syntax error at 2:12:')
    expect(reads).toBe(expectedReads)
  }
})

test.each([
  ['venn-beta', 'set A["First\n%%{init: {"theme":"dark"}}%%\nLast"]:10', 'A'],
  ['railroad-beta', 'entry = terminal("First\n%%{init: {"theme":"dark"}}%%\nLast");', 'rule#0:entry'],
] as const)('%s source maps consume admitted grammar while retaining authored directive boundaries', (header, statement, id) => {
  const source = `---\r\ntitle: Wrapper\r\n---\r\n${header}\r\n${statement.replaceAll('\n', '\r\n')}`
  const parsed = parseMermaid(source)
  if (!parsed.ok || parsed.value.body.kind === 'opaque') throw Error('Expected admitted native source')
  const spans = parsed.value.source.spans!
  const span = header === 'venn-beta' ? spans.nodes.get(id) : spans.groups.get(id)
  expect(textAt(source, span)).toBe(statement.replaceAll('\n', '\r\n'))
  expect(span?.start).toEqual({ offset: source.indexOf(statement.split('\n')[0]!), line: 5, col: 1 })
  expect(serializeMermaid(parsed.value)).toContain('First')
})

test.each([
  ['railroad-beta', 'entry = terminal("a");', 'groups', ['rule#0:entry'], true, false],
  ['railroad-beta', 'entry = terminal("a");', 'groups', ['rule#0:entry'], false, true],
  ['venn-beta', 'set A:10', 'nodes', ['A'], true, true],
  ['wardley-beta', 'component A [80.0, 30.0]', 'nodes', ['A'], true, true],
  ['railroad-beta', 'entry = sequence(terminal("a"), optional(terminal("b")));', 'groups', ['rule#0:entry', 'rule#1:entry'], true, true],
] as const)('%s observed token boundaries exclude adjacent init directives (%s)', (header, token, category, ids, leading, trailing) => {
  const directive = '%%{init: {"theme":"dark"}}%%'
  const statement = (leading ? directive + directive : '') + token + (trailing ? directive : '')
  const source = ['---', 'title: Wrapper', '---', header, ...ids.map(() => statement)].join('\r\n')
  const parsed = parseMermaid(source)
  if (!parsed.ok || parsed.value.body.kind === 'opaque') throw Error('Expected admitted native source')
  let cursor = 0
  for (const [index, id] of ids.entries()) {
    const span = parsed.value.source.spans![category].get(id)!
    const start = source.indexOf(token, cursor)
    expect(textAt(source, span)).toBe(token)
    expect(span.start).toEqual({ offset: start, line: index + 5, col: leading ? directive.length * 2 + 1 : 1 })
    expect(span.end.offset).toBe(start + token.length)
    cursor = start + token.length
  }
})

test('Wardley observed source maps follow final component writes, pipelines and native annotation owners', () => {
  const source = [
    '---', 'config:', '  theme: dark', '---', '%% wrapper', 'wardley-beta',
    '  title Supply chain', '  evolution "Build" -> "Buy"',
    '  component "Service API" [80.0, 30.0]',
    '  component "Service API" [75.0, 35.0] (build)',
    '  component Storage [30.0, 70.0]',
    '  pipeline "Service API" {', '    component "Custom part" [40.0]', '    component Utility [60.0]', '  }',
    '  "Custom part" -> Storage ;replicated', '  evolve Storage 90.0',
    '  note "Review\n    exact text" [45.0, 55.0]',
    '  annotation 1, [40, 60] "Risk"',
    '  accelerator Demand [80.0, 80.0]', '  deaccelerator Drag [20.0, 20.0]',
  ].join('\r\n')
  const parsed = parseMermaid(source)
  if (!parsed.ok || parsed.value.body.kind !== 'wardley') throw new Error('Expected typed Wardley')
  const map = parsed.value.source, spans = map.spans!
  expect([...map.nodes.keys()]).toEqual(['Service API', 'Storage', 'Service API_Custom part', 'Service API_Utility'])
  expect(map.nodes.get('Service API')).toEqual({ line: 5, col: 1 })
  expect(textAt(source, spans.nodes.get('Service API'))).toBe('component "Service API" [75.0, 35.0] (build)')
  expect(textAt(source, spans.nodes.get('Service API_Custom part'))).toBe('component "Custom part" [40.0]')
  expect(textAt(source, spans.groups.get('pipeline:Service API'))).toBe('pipeline "Service API" {\r\n    component "Custom part" [40.0]\r\n    component Utility [60.0]\r\n  }')
  expect(textAt(source, spans.edges.get('dependency:0'))).toBe('"Custom part" -> Storage ;replicated')
  expect(textAt(source, spans.edges.get('evolve:0'))).toBe('evolve Storage 90.0')
  expect(textAt(source, spans.labels.get('note:0'))).toBe('note "Review\n    exact text" [45.0, 55.0]')
  expect(textAt(source, spans.labels.get('annotation-text:0'))).toBe('annotation 1, [40, 60] "Risk"')
  expect(textAt(source, spans.labels.get('stage:0'))).toBe('evolution "Build" -> "Buy"')
  expect(textAt(source, spans.labels.get('strategy:Service API'))).toBe('component "Service API" [75.0, 35.0] (build)')
  const chart = layoutWardley(parsed.value.body)
  expect(chart.nodes.every(node => spans.nodes.has(node.id))).toBe(true)
  expect(chart.edges.every(edge => spans.edges.has(edge.id))).toBe(true)
  expect(chart.pipelines.every(group => spans.groups.has(group.id))).toBe(true)
  const edited = mutateChecked(parsed.value, { kind: 'set_component_position', id: 'Storage', x: 65, y: 25 })
  if (!edited.ok) throw new Error(JSON.stringify(edited.error))
  const saved = serializeMermaid(edited.value)
  expect(textAt(saved, edited.value.source.spans?.nodes.get('Storage'))).toBe('component "Storage" [25.0, 65.0]')
})

test('Cynefin observed maps retain multiline items, repeated transition occurrences and editable self loops', () => {
  const source = '---\ntitle: Wrapper\n---\n%% retained\ncynefin-beta\n  complex\n    "Explore\n      with care"\n  clear\n    "Apply"\n  complex --> clear: "Learn"\n  clear --> clear: "Reassess"\n  complex --> clear: "Learn"'
  const parsed = parseMermaid(source)
  if (!parsed.ok || parsed.value.body.kind !== 'cynefin') throw new Error('Expected typed Cynefin including self loop')
  const map = parsed.value.source, spans = map.spans!
  expect([...map.nodes.keys()]).toEqual(['complex:0', 'clear:0'])
  expect([...map.groups.keys()]).toEqual(['complex', 'clear'])
  expect(map.nodes.get('complex:0')).toEqual({ line: 3, col: 1 })
  expect(textAt(source, spans.nodes.get('complex:0'))).toBe('"Explore\n      with care"')
  expect(spans.nodes.get('complex:0')!.start).toEqual({ line: 7, col: 5, offset: source.indexOf('"Explore') })
  expect(textAt(source, spans.edges.get('transition:1'))).toBe('clear --> clear: "Reassess"')
  expect(spans.edges.get('transition:0')!.start.offset).toBe(source.indexOf('complex --> clear'))
  expect(spans.edges.get('transition:2')!.start.offset).toBe(source.lastIndexOf('complex --> clear'))
  const chart = layoutCynefin(parsed.value.body)
  expect(chart.domains.flatMap(domain => domain.items).every(item => spans.nodes.has(item.id))).toBe(true)
  expect(chart.transitions.every(transition => spans.edges.has(transition.id))).toBe(true)
  const edited = mutate(parsed.value, { kind: 'add_transition', from: 'complex', to: 'complex', label: 'Probe again' })
  if (!edited.ok || edited.value.body.kind !== 'cynefin') throw new Error(JSON.stringify(edited))
  expect(edited.value.body.transitions.at(-1)).toEqual({ from: 'complex', to: 'complex', label: 'Probe again' })
  const saved = serializeMermaid(edited.value)
  expect(textAt(saved, edited.value.source.spans?.edges.get('transition:3'))).toBe('complex --> complex: "Probe again"')
  const reload = parseMermaid(saved)
  if (!reload.ok) throw new Error(JSON.stringify(reload.error))
  expect(reload.value.body).toEqual(edited.value.body)
})

test.each([
  ['railroad-beta', 'entry = sequence(terminal("a"), optional(nonterminal("item")));', 'entry = terminal("b");'],
  ['railroad-ebnf-beta', 'entry = "a", [item];', 'entry = base - reserved;'],
  ['railroad-abnf-beta', 'entry = 1*3("a" / item);', 'entry = %x41;'],
  ['railroad-peg-beta', 'entry <- &item ("a" / .)*;', 'entry <- !"reserved" item;'],
] as const)('%s maps actual rule occurrences and all rendered expression owners', (header, first, second) => {
  // IR, EBNF and PEG permit two productions on one line; ABNF closes
  // productions at line end. A wrapped first expression exercises each reader.
  const split = first.indexOf(' = ') >= 0 ? first.replace(' = ', ' = \n    ') : first.replace(' <- ', ' <- \n    ')
  const separator = header === 'railroad-abnf-beta' ? '\n  ' : ' '
  const source = `---\ntitle: Grammar wrapper\n---\n%% retained\n${header}\n  ${split}${separator}${second}`
  const parsed = parseMermaid(source)
  if (!parsed.ok || parsed.value.body.kind !== 'railroad') throw new Error('Expected typed Railroad')
  const map = parsed.value.source, spans = map.spans!, chart = layoutRailroad(parsed.value.body)
  expect([...map.groups.keys()]).toEqual(['rule#0:entry', 'rule#1:entry'])
  expect(textAt(source, spans.groups.get('rule#0:entry'))).toBe(split)
  expect(textAt(source, spans.groups.get('rule#1:entry'))).toBe(second)
  expect(spans.groups.get('rule#0:entry')!.start.offset).toBe(source.indexOf('entry'))
  expect(spans.groups.get('rule#1:entry')!.start.offset).toBe(source.lastIndexOf('entry'))
  // Decorative rails belong to the production group, not an authored edge.
  expect(map.edges.size).toBe(0)
  const leafIds = chart.labels.filter(label => label.kind !== 'annotation').map(label => label.id)
  expect([...map.nodes.keys()]).toEqual(leafIds)
  for (const id of leafIds) expect(textAt(source, spans.nodes.get(id))).toBe(id.startsWith('rule#0:') ? split : second)
  const extracted = getFamily('railroad')!.extractLabels!(source)
  expect(extracted.map(label => label.target)).toEqual(chart.rules.flatMap(rule => [rule.id, ...chart.labels.filter(label => label.ruleId === rule.id && label.kind !== 'annotation').map(label => label.id)]))
  const edited = mutateChecked(parsed.value, { kind: 'replace_rule', index: 1, definition: { type: 'terminal', value: 'changed' } })
  if (!edited.ok) throw new Error(JSON.stringify(edited.error))
  const saved = serializeMermaid(edited.value)
  expect(textAt(saved, edited.value.source.spans?.groups.get('rule#1:entry'))).toContain('changed')
  expect(edited.value.source.groups.size).toBe(2)
})

describe('graph dialect source-map coordinate ownership', () => {
  test.each([
    ['agentflow-beta', 'flow flow[Scope]', 'flow', 6],
    ['flowchart TD', 'subgraph sub[Scope]', 'sub', 10],
  ] as const)('%s group IDs resembling the grammar prefix map to the authored identity', (header, declaration, id, col) => {
    const source = `${header}\n${declaration}\na[A]\nend`, parsed = parseMermaid(source)
    if (!parsed.ok) throw Error(JSON.stringify(parsed.error))
    const location = parsed.value.source.groups.get(id)
    expect(location).toEqual({ line: 2, col })
    expect(declaration.slice(location!.col - 1, location!.col - 1 + id.length)).toBe(id)
    expect(textAt(source, parsed.value.source.spans?.groups.get(id))).toBe(declaration)
  })

  test.each(['\n', '\r\n'])('AgentFlow maps declarations in its executable post-wrapper source with %j endings', newline => {
    const source = ['---', 'title: Workflow', '---', '%% wrapper', 'agentflow-beta TB', '', 'flow demo', '  helper["Helper"]', 'end', '', 'helper@{ instruction: "Answer precisely." }'].join(newline)
    const result = parseMermaid(source)
    if (!result.ok || result.value.body.kind !== 'agentflow') throw Error('Expected native AgentFlow')
    const map = result.value.source
    expect(map.nodes.get('helper')).toEqual({ line: 4, col: 3 })
    expect(result.value.canonicalSource.split(/\r?\n/)[3]!.slice(2)).toBe('helper["Helper"]')
    expect(textAt(source, map.spans?.nodes.get('helper'))).toBe('helper["Helper"]')
    expect(textAt(source, map.spans?.groups.get('demo'))).toBe('flow demo')
    expect(textAt(source, map.spans?.labels.get('node:helper'))).toBe('Helper')
    const edited = mutateChecked(result.value, { kind: 'set_label', target: 'helper', label: 'Renamed' })
    if (!edited.ok) throw Error(JSON.stringify(edited.error))
    const saved = serializeMermaid(edited.value)
    expect(saved).toContain('%% wrapper')
    const again = parseMermaid(saved)
    if (!again.ok || again.value.body.kind !== 'agentflow') throw Error('Expected edited native AgentFlow')
    expect(again.value.body.graph.nodes.get('helper')?.label).toBe('Renamed')
    expect(textAt(saved, again.value.source.spans?.labels.get('node:helper'))).toBe('Renamed')
  })
  test.each([
    ['agentflow-beta TB', 'flow scope[Scope]'],
    ['swimlane-beta TB', 'subgraph scope[Scope]'],
  ])('%s shares multiline and inline-endpoint source identities', (header, container) => {
    const source = `${header}\n\n${container}\n  a["wide\nlabel"] handoff@--> b["Beta"]\nend`
    const result = parseMermaid(source)
    if (!result.ok || !['agentflow', 'swimlane'].includes(result.value.body.kind)) throw Error('Expected graph dialect')
    const map = result.value.source
    for (const id of ['a', 'b']) expect(textAt(source, map.spans?.nodes.get(id))).toBe('a["wide\nlabel"] handoff@--> b["Beta"]')
    expect(textAt(source, map.spans?.labels.get('node:a'))).toBe('wide\nlabel')
    expect(textAt(source, map.spans?.labels.get('node:b'))).toBe('Beta')
    expect(textAt(source, map.spans?.edges.get('edge#0:a->b'))).toBe('a["wide\nlabel"] handoff@--> b["Beta"]')
    if (header.startsWith('agentflow')) expect(map.edges.get('handoff')).toEqual(map.edges.get('edge#0:a->b'))
    expect(textAt(source, map.spans?.groups.get('scope'))).toBe(container)
  })
})
