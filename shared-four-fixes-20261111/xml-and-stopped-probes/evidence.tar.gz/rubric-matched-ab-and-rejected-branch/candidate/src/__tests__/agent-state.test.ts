// BUILD-19: state structured mutation. Promotes the state family from a
// "parses AS flowchart" projection to a dedicated StateBody IR with state-shaped
// ops and a real `asState` narrower. Covers: parse / narrow / mutate / verify /
// serialize, the structured-or-opaque fallback, round-trip identity, an error-
// path table for every op, an opaque-fallback table, the differential proof
// (canonical source re-parses under the LEGACY parser into a graph whose
// nodes/edges correspond 1:1 to the body's states/transitions), a fast-check
// round-trip property over generated state machines (incl. nested composites),
// and the verify-projection proof (state runs the same geometric Tier 2 path
// as the equivalent flowchart).

import { describe, test, expect } from 'bun:test'
import fc from 'fast-check'
import { createRequire } from 'node:module'
import { fcParameters } from './helpers/fc-parameters.ts'
import { parseRegisteredMermaid as parseMermaid } from '../agent/parse.ts'
import { serializeMermaid } from '../agent/serialize.ts'
import { synthesizeFromGraph, renderMermaidASCII, layoutMermaidWithReceipt } from '../agent/core.ts'
import { renderMermaidSVGWithReceipt } from '../index.ts'
import { mutate } from '../agent/mutate.ts'
import { graphGeometryWarnings, verifyMermaid } from '../agent/verify.ts'
import { positionFamilyArtifact } from '../agent/family-layouts.ts'
import { stateBodyToGraph } from '../agent/state-body.ts'
import type { PositionedGraph } from '../types.ts'
import { asState, asFlowchart } from '../agent/types.ts'
import type { LayoutWarning, StateValidDiagram, StateMutationOp, StateNode, StateTransition, MutationError } from '../agent/types.ts'
import { parseMermaid as parseLegacy } from '../parser.ts'
import { describeMermaidFacts } from '../agent/facts.ts'
import { describeMermaid, describeMermaidTree } from '../agent/describe.ts'
import { startUpstreamMermaid } from './helpers/upstream-mermaid.ts'

const SRC = `stateDiagram-v2
  [*] --> Idle
  state "In Progress" as Active
  Idle --> Active : start
  Active --> Idle : pause
  Active --> [*] : done
`

function state(src: string = SRC): StateValidDiagram {
  const r = parseMermaid(src)
  if (!r.ok) throw new Error('parse: ' + JSON.stringify(r.error))
  const s = asState(r.value)
  if (!s) throw new Error('not a structured state: ' + r.value.body.kind)
  return s
}

function apply(d: StateValidDiagram, op: StateMutationOp): StateValidDiagram {
  const r = mutate(d, op)
  if (!r.ok) throw new Error('mutate: ' + JSON.stringify(r.error))
  return r.value
}

function expectErr(d: StateValidDiagram, op: StateMutationOp, code: MutationError['code']): void {
  const r = mutate(d, op)
  expect(r.ok).toBe(false)
  if (!r.ok) expect(r.error.code).toBe(code)
}

// ---------------------------------------------------------------------------
describe('state structured parse', () => {
  test('retains combining marks in state identities, nested ownership, transitions and notes', async () => {
    const source = 'stateDiagram-v2\nstate שָלוֹם {\n [*] --> café\n café --> [*]\n note right of café : done\n}\n[*] --> שָלוֹם'
    const diagram = state(source)
    const composite = diagram.body.states.find(node => node.id === 'שָלוֹם')!
    expect(composite.states?.map(node => node.id)).toEqual(['café'])
    expect(composite.transitions).toContainEqual({ from: '[*]', to: 'café' })
    expect(diagram.body.notes).toContainEqual(expect.objectContaining({ target: 'café', text: 'done' }))
    const graph = parseLegacy(source)
    expect(graph.subgraphs.map(group => group.id)).toEqual(['שָלוֹם'])
    expect(graph.nodes.has('café')).toBe(true)
    const edited = apply(diagram, { kind: 'rename_state', from: 'café', to: 'שָׁלוֹם' })
    const output = serializeMermaid(edited)
    expect(state(output).body).toEqual(edited.body)
    expect(parseLegacy(output).nodes.has('שָׁלוֹם')).toBe(true)
    const upstream = startUpstreamMermaid()
    try { expect(await upstream.accepts(output)).toBe(true) }
    finally { upstream.close() }
  })

  test('class assignment to a hyphenated identity stays source-only and typed assignment fails atomically', () => {
    const source = 'stateDiagram-v2\n-:::-'
    const parsed = parseMermaid(source)
    if (!parsed.ok) throw new Error(JSON.stringify(parsed.error))
    expect(parsed.value.body.kind).toBe('opaque')
    expect(serializeMermaid(parsed.value)).toBe(source + '\n')
    expect(verifyMermaid(parsed.value).warnings).toContainEqual(expect.objectContaining({ code: 'UNSUPPORTED_SYNTAX', syntax: 'state_class_target' }))
    const d = state('stateDiagram-v2\nstate "Working" as in-progress')
    const before = structuredClone(d)
    expectErr(d, { kind: 'set_state_class', id: 'in-progress', className: 'active' }, 'INVALID_OP')
    expect(d).toEqual(before)
  })

  test('models states, labels, transitions, and [*] pseudostates', () => {
    const d = state()
    expect(d.kind).toBe('state')
    expect(d.body.kind).toBe('state')
    const ids = d.body.states.map(s => s.id).sort()
    expect(ids).toEqual(['Active', 'Idle'])
    const active = d.body.states.find(s => s.id === 'Active')!
    expect(active.label).toBe('In Progress')
    expect(d.body.transitions).toContainEqual({ from: '[*]', to: 'Idle' })
    expect(d.body.transitions).toContainEqual({ from: 'Idle', to: 'Active', label: 'start' })
    expect(d.body.transitions).toContainEqual({ from: 'Active', to: '[*]', label: 'done' })
  })

  test('asState narrows; asFlowchart returns null (the BUILD-19 breaking flip)', () => {
    const r = parseMermaid(SRC)
    expect(r.ok).toBe(true)
    if (!r.ok) return
    expect(asState(r.value)).not.toBeNull()
    expect(asFlowchart(r.value)).toBeNull()
  })

  test('models nested composite states with per-composite direction', () => {
    const d = state(`stateDiagram-v2
  [*] --> First
  state First {
    direction LR
    [*] --> inner
    inner --> [*]
  }
  First --> [*]`)
    const first = d.body.states.find(s => s.id === 'First')!
    expect(first.states).toBeDefined()
    expect(first.direction).toBe('LR')
    expect(first.states!.map(s => s.id)).toEqual(['inner'])
    expect(first.transitions).toContainEqual({ from: '[*]', to: 'inner' })
    // The top-level transition referencing the composite stays at top level.
    expect(d.body.transitions).toContainEqual({ from: '[*]', to: 'First' })
    expect(d.body.transitions).toContainEqual({ from: 'First', to: '[*]' })
  })

  test('forward references to nested composites keep one globally unique ID', () => {
    let d = state(`stateDiagram-v2
  A --> C
  state P {
    state C {
      X --> Y
    }
  }`)
    const all: StateNode[] = []
    const walk = (nodes: StateNode[]) => { for (const node of nodes) { all.push(node); if (node.states) walk(node.states) } }
    walk(d.body.states)
    expect(all.filter(node => node.id === 'C')).toHaveLength(1)
    expect(all.find(node => node.id === 'C')?.states).toBeDefined()
    d = apply(d, { kind: 'set_direction', state: 'C', direction: 'LR' })
    expect(state(serializeMermaid(d)).body).toEqual(d.body)
  })

  test('a later composite definition retains its first referenced scope through editing and writing', () => {
    let d = state('stateDiagram-v2\nstate Outer {\n A --> Inner\n}\nstate Inner {\n B --> C\n}')
    const outer = d.body.states.find(node => node.id === 'Outer')!
    expect(d.body.states.map(node => node.id)).toEqual(['Outer'])
    expect(outer.states?.find(node => node.id === 'Inner')?.states?.map(node => node.id)).toEqual(['B', 'C'])
    d = apply(d, { kind: 'set_direction', state: 'Inner', direction: 'LR' })
    const written = serializeMermaid(d)
    expect(state(written).body).toEqual(d.body)
    const graph = parseLegacy(written)
    expect(graph.subgraphs[0]?.children.map(group => group.id)).toEqual(['Inner'])
  })

  test('a cross-scope reference never creates a second editable identity', () => {
    const d = state('stateDiagram-v2\nstate First { Shared --> A }\nstate Second { Shared --> B }')
    const first = d.body.states.find(node => node.id === 'First')!
    const second = d.body.states.find(node => node.id === 'Second')!
    expect(first.states?.map(node => node.id)).toEqual(['Shared', 'A'])
    expect(second.states?.map(node => node.id)).toEqual(['B'])
    expect(second.transitions).toEqual([{ from: 'Shared', to: 'B' }])
    expect(state(serializeMermaid(d)).body).toEqual(d.body)
  })

  test('self-containing composite identities are refused without dropping their source', () => {
    const source = 'stateDiagram-v2\nstate A {\n state A { B }\n C\n}\n'
    expect(() => parseLegacy(source)).toThrow('cannot contain itself')
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    expect(parsed.value.body.kind).toBe('opaque')
    expect(serializeMermaid(parsed.value)).toBe(source)
  })

  test('top-level direction is modeled', () => {
    const d = state(`stateDiagram-v2
  direction LR
  A --> B`)
    expect(d.body.direction).toBe('LR')
  })
})

// ---------------------------------------------------------------------------
describe('state round-trip identity', () => {
  const cases: [string, string][] = [
    ['simple', `stateDiagram-v2
  [*] --> Still
  Still --> Moving
  Moving --> [*]`],
    ['labels', `stateDiagram-v2
  state "Nice Label" as s1
  s1 --> s2 : go`],
    ['nested composite', `stateDiagram-v2
  [*] --> First
  state First {
    [*] --> inner
    inner --> [*]
  }
  First --> [*]`],
  ]
  for (const [name, src] of cases) {
    test(`${name}: serialize → parse → serialize is idempotent`, () => {
      const r = parseMermaid(src)
      expect(r.ok).toBe(true)
      if (!r.ok) return
      const s1 = serializeMermaid(r.value)
      const r2 = parseMermaid(s1)
      expect(r2.ok).toBe(true)
      if (!r2.ok) return
      expect(serializeMermaid(r2.value)).toBe(s1)
      expect(s1.startsWith('stateDiagram-v2')).toBe(true)
    })
  }

  // Layout follows the order a scope creates its states in, so the writer
  // keeps that order, and `[*]` ids are numbered per composite so a block
  // written elsewhere cannot renumber them.
  test.each([
    ['[*] in composites between top-level transitions', '[*] --> First\nstate First {\n[*] --> second\nsecond --> [*]\n}\n[*] --> Named\nstate "Another" as Named {\n[*] --> inner\ninner --> [*]\n}'],
    ['a description after the transition that creates the state', '[*] --> A\nA --> B\nA --> C\nC: described later'],
    ['standalone declaration before contextual start', 'state "Idle" as A\nstate "Other" as D\n[*] --> A\nA --> B'],
    ['standalone declaration after contextual start', 'state "Idle" as A\n[*] --> A\nstate "Other" as D\nA --> B'],
    ['nested declarations around contextual start', 'state P {\nstate "Idle" as A\nstate "Other" as D\n[*] --> A\nA --> B\n}'],
    ['note-created state before contextual start', 'note right of D: Note\n[*] --> A\nA --> B'],
    ['a bare declaration after transitions', 'A --> B\nC'],
    ['a state a class shorthand declares after transitions', 'A --> B\nA --> D\nC:::hot\nclassDef hot fill:#f00'],
    ['a composite block after its siblings', 'A --> B\nA --> C\nstate C {\nx --> y\n}'],
    ['labels declared before use around one between', 'state "s" as S\nstate "x" as X\nstate "z" as Z\nS --> Z'],
    ['a fork declared after use', 'A --> f\nstate f <<fork>>\nf --> B\nf --> C'],
    ['[*] in concurrency regions', '[*] --> P\nstate P {\n[*] --> a\na --> [*]\n--\n[*] --> b\nb --> [*]\n}\nP --> [*]'],
    ['cross-scope leaves after their frames', 'state One {\nA --> B\n}\nstate Two {\nC --> D\n}\nB --> C : handoff'],
    ['a fresh root endpoint before its target frame', 'X --> A : enter\nstate Frame {\nA --> B\n}'],
    ['a fresh root endpoint after its target frame', 'state Frame {\nA --> B\n}\nX --> A : enter'],
    ['an existing root endpoint before its target frame', 'X --> Y\nY --> A\nstate Frame {\nA --> B\n}'],
    ['an existing root endpoint after its target frame', 'X --> Y\nstate Frame {\nA --> B\n}\nY --> A'],
  ])('%s: the parsed and the written diagram lay out as the source does', (_name, body) => {
    const source = `stateDiagram-v2\n${body}`
    const geometry = (input: Parameters<typeof layoutMermaidWithReceipt>[0]) => {
      const { layout } = layoutMermaidWithReceipt(input)
      const box = (item: { id: string; x: number; y: number; w: number; h: number }) => `${item.id} ${item.x} ${item.y} ${item.w} ${item.h}`
      return {
        bounds: layout.bounds,
        nodes: layout.nodes.map(box).sort(),
        edges: layout.edges.map(edge => `${edge.id} ${edge.path.join(' ')}`).sort(),
        groups: layout.groups.map(box).sort(),
      }
    }
    const parsed = state(source)
    const drawn = geometry(source)
    expect(geometry(parsed)).toEqual(drawn)
    expect(geometry(serializeMermaid(parsed))).toEqual(drawn)
    for (const backend of ['elk', 'agentic'] as const) {
      const options = { graphLayout: { backend } }
      const original = renderMermaidSVGWithReceipt(source, options)
      const roundtrip = renderMermaidSVGWithReceipt(parsed, options)
      expect(roundtrip.svg).toBe(original.svg)
      expect(roundtrip.receipt.layoutCertification).toEqual(original.receipt.layoutCertification)
    }
  })

  test('standalone alias with label equal to id stays renderable', () => {
    const d = state(`stateDiagram-v2
  state "as" as as`)
    const out = serializeMermaid(d)
    expect(out).toContain('state "as" as as')
    const v = verifyMermaid(d)
    expect(v.warnings.map(w => w.code)).not.toContain('EMPTY_DIAGRAM')
    expect(v.ok).toBe(true)
  })
})

// ---------------------------------------------------------------------------
describe('state residual syntax promotion table', () => {
  const promoted: [string, string][] = [
    ['concurrency --', `stateDiagram-v2
  state Active {
    [*] --> A
    --
    [*] --> B
  }`],
    ['classDef styling', `stateDiagram-v2
  classDef bad fill:#f00
  A --> B
  class A bad`],
    ['::: shorthand', `stateDiagram-v2
  [*] --> A:::bad`],
    ['bare state id', `stateDiagram-v2
  stateId`],
    ['hyphenated composite id', `stateDiagram-v2
  state a-b {
    x --> y
  }`],
  ]
  for (const [name, src] of promoted) {
    test(`${name} → structured body, round-trips canonically`, () => {
      const r = parseMermaid(src)
      expect(r.ok).toBe(true)
      if (!r.ok) return
      expect(r.value.body.kind).toBe('state')
      expect(asState(r.value)).not.toBeNull()
      const s1 = serializeMermaid(r.value)
      const r2 = parseMermaid(s1)
      expect(r2.ok).toBe(true)
      if (r2.ok) expect(serializeMermaid(r2.value)).toBe(s1)
    })
  }

  test('fork/choice/join/note — the former opaque rows — now parse structured', () => {
    for (const src of [
      'stateDiagram-v2\n  state fork_state <<fork>>\n  [*] --> fork_state',
      'stateDiagram-v2\n  state if_state <<choice>>\n  [*] --> if_state',
      'stateDiagram-v2\n  state join_state <<join>>\n  State2 --> join_state',
      'stateDiagram-v2\n  A --> B\n  note right of A : hello',
    ]) {
      const r = parseMermaid(src)
      expect(r.ok).toBe(true)
      if (!r.ok) continue
      expect(r.value.body.kind).toBe('state')
      expect(asState(r.value)).not.toBeNull()
    }
  })

  test('explicit state declarations retain isolated states in the editable body and drawing', () => {
    const r = parseMermaid(`stateDiagram-v2
  state Active
  state Waiting
  Active --> Done`)
    expect(r.ok).toBe(true)
    if (!r.ok) return
    expect(r.value.body.kind).toBe('state')
    expect(asState(r.value)?.body.states.map(node => node.id).sort()).toEqual(['Active', 'Done', 'Waiting'])
    const verified = verifyMermaid(r.value)
    expect(verified.layout.kind).toBe('state')
    expect(verified.layout.nodes.map(node => node.id).sort()).toEqual(['Active', 'Done', 'Waiting'])
    expect(verified.layout.bounds.w).toBeGreaterThan(0)
    expect(verified.layout.bounds.h).toBeGreaterThan(0)
  })
})

// ---------------------------------------------------------------------------
describe('state mutation — happy paths', () => {
  test('add_state appends a simple state; add_transition wires it', () => {
    let d = state()
    d = apply(d, { kind: 'add_state', id: 'Done', label: 'All Done' })
    expect(d.body.states.find(s => s.id === 'Done')?.label).toBe('All Done')
    d = apply(d, { kind: 'add_transition', from: 'Active', to: 'Done' })
    expect(d.body.transitions).toContainEqual({ from: 'Active', to: 'Done' })
    expect(verifyMermaid(d).ok).toBe(true)
  })

  test('rename_state rewrites transitions', () => {
    const d = apply(state(), { kind: 'rename_state', from: 'Idle', to: 'Waiting' })
    expect(d.body.states.find(s => s.id === 'Waiting')).toBeDefined()
    expect(d.body.states.find(s => s.id === 'Idle')).toBeUndefined()
    expect(d.body.transitions).toContainEqual({ from: '[*]', to: 'Waiting' })
    expect(d.body.transitions.some(t => t.from === 'Idle' || t.to === 'Idle')).toBe(false)
  })

  test('remove_state cascades transitions touching it', () => {
    const d = apply(state(), { kind: 'remove_state', id: 'Active' })
    expect(d.body.states.find(s => s.id === 'Active')).toBeUndefined()
    expect(d.body.transitions.some(t => t.from === 'Active' || t.to === 'Active')).toBe(false)
    // Idle and its [*] transition survive.
    expect(d.body.transitions).toContainEqual({ from: '[*]', to: 'Idle' })
  })

  test('set_state_label sets and clears', () => {
    let d = apply(state(), { kind: 'set_state_label', id: 'Idle', label: 'Waiting Room' })
    expect(d.body.states.find(s => s.id === 'Idle')?.label).toBe('Waiting Room')
    const labeled = renderMermaidSVGWithReceipt(d)
    expect(labeled.svg).toContain('Waiting Room')
    expect(labeled.svg).toBe(renderMermaidSVGWithReceipt(serializeMermaid(d)).svg)
    d = apply(d, { kind: 'set_state_label', id: 'Idle', label: null })
    expect(d.body.states.find(s => s.id === 'Idle')?.label).toBeUndefined()
    const cleared = renderMermaidSVGWithReceipt(d)
    expect(cleared.svg).not.toContain('Waiting Room')
    expect(cleared.svg).toBe(renderMermaidSVGWithReceipt(serializeMermaid(d)).svg)
  })

  test('remove_transition by from/to and by index', () => {
    let d = apply(state(), { kind: 'remove_transition', from: 'Idle', to: 'Active' })
    expect(d.body.transitions.some(t => t.from === 'Idle' && t.to === 'Active')).toBe(false)
    const before = d.body.transitions.length
    d = apply(d, { kind: 'remove_transition', index: 0 })
    expect(d.body.transitions.length).toBe(before - 1)
  })

  test('set_transition_label sets and clears', () => {
    let d = apply(state(), { kind: 'set_transition_label', from: 'Idle', to: 'Active', label: 'begin' })
    expect(d.body.transitions.find(t => t.from === 'Idle' && t.to === 'Active')?.label).toBe('begin')
    d = apply(d, { kind: 'set_transition_label', from: 'Idle', to: 'Active', label: null })
    expect(d.body.transitions.find(t => t.from === 'Idle' && t.to === 'Active')?.label).toBeUndefined()
  })

  test('make_composite wraps members and pulls internal transitions in', () => {
    const base = state(`stateDiagram-v2
  [*] --> A
  A --> B
  B --> C`)
    const d = apply(base, { kind: 'make_composite', id: 'Group', members: ['A', 'B'], label: 'Grouped' })
    const group = d.body.states.find(s => s.id === 'Group')!
    expect(group.label).toBe('Grouped')
    expect(group.states!.map(s => s.id).sort()).toEqual(['A', 'B'])
    expect(group.transitions).toContainEqual({ from: 'A', to: 'B' })
    // Cross-boundary transitions stay at the top level.
    expect(d.body.transitions).toContainEqual({ from: '[*]', to: 'A' })
    expect(d.body.transitions).toContainEqual({ from: 'B', to: 'C' })
    expect(verifyMermaid(d).ok).toBe(true)
  })

  test('add_state into a composite parent (promotes simple parent)', () => {
    let d = state(`stateDiagram-v2
  A --> B`)
    d = apply(d, { kind: 'add_state', id: 'child', parent: 'A' })
    const a = d.body.states.find(s => s.id === 'A')!
    expect(a.states?.map(s => s.id)).toEqual(['child'])
  })
})

// ---------------------------------------------------------------------------
describe('state mutation — error-path table (every op)', () => {
  test('add_state duplicate / invalid id', () => {
    expectErr(state(), { kind: 'add_state', id: 'Idle' }, 'DUPLICATE_STATE')
    expectErr(state(), { kind: 'add_state', id: 'has space' }, 'INVALID_OP')
    expectErr(state(), { kind: 'add_state', id: 'A', parent: 'Nope' }, 'STATE_NOT_FOUND')
  })
  test('remove_state missing / non-empty composite refused', () => {
    expectErr(state(), { kind: 'remove_state', id: 'Ghost' }, 'STATE_NOT_FOUND')
    const comp = state(`stateDiagram-v2
  state First {
    [*] --> inner
    inner --> [*]
  }`)
    expectErr(comp, { kind: 'remove_state', id: 'First' }, 'INVALID_OP')
  })
  test('rename_state missing / duplicate / invalid', () => {
    expectErr(state(), { kind: 'rename_state', from: 'Ghost', to: 'X' }, 'STATE_NOT_FOUND')
    expectErr(state(), { kind: 'rename_state', from: 'Idle', to: 'Active' }, 'DUPLICATE_STATE')
    expectErr(state(), { kind: 'rename_state', from: 'Idle', to: 'bad id' }, 'INVALID_OP')
  })
  test('set_state_label missing / invalid label', () => {
    expectErr(state(), { kind: 'set_state_label', id: 'Ghost', label: 'x' }, 'STATE_NOT_FOUND')
    expectErr(state(), { kind: 'set_state_label', id: 'Idle', label: 'has "quote"' }, 'INVALID_OP')
  })
  test('add_transition invalid endpoint', () => {
    expectErr(state(), { kind: 'add_transition', from: 'bad id', to: 'Idle' }, 'INVALID_OP')
    expectErr(state(), { kind: 'add_transition', from: 'A', to: 'B', parent: 'Nope' }, 'STATE_NOT_FOUND')
  })
  test('remove_transition not found / underspecified', () => {
    expectErr(state(), { kind: 'remove_transition', index: 99 }, 'TRANSITION_NOT_FOUND')
    expectErr(state(), { kind: 'remove_transition', from: 'X', to: 'Y' }, 'TRANSITION_NOT_FOUND')
    expectErr(state(), { kind: 'remove_transition' }, 'INVALID_OP')
  })
  test('set_transition_label not found', () => {
    expectErr(state(), { kind: 'set_transition_label', from: 'X', to: 'Y', label: 'z' }, 'TRANSITION_NOT_FOUND')
  })
  test('make_composite duplicate / missing member', () => {
    expectErr(state(), { kind: 'make_composite', id: 'Idle', members: ['Active'] }, 'DUPLICATE_STATE')
    expectErr(state(), { kind: 'make_composite', id: 'G', members: ['Ghost'] }, 'STATE_NOT_FOUND')
  })
})

// ---------------------------------------------------------------------------
describe('state differential — canonical source re-parses 1:1 under the LEGACY parser', () => {
  // The renderer-projection proof: the source we emit, parsed by the legacy
  // state parser (which the renderer uses), yields a graph whose nodes/edges
  // correspond to the body's states/transitions. [*] maps to _start/_end
  // pseudostate nodes; composites map to subgraphs.
  test('simple body: states ↔ graph nodes, transitions ↔ graph edges', () => {
    const d = state(`stateDiagram-v2
  [*] --> Idle
  Idle --> Run : go
  Run --> [*]`)
    const graph = parseLegacy(serializeMermaid(d))
    // Non-pseudo states become rounded nodes labeled by id/label.
    const rounded = [...graph.nodes.values()].filter(n => n.shape === 'rounded')
    expect(rounded.map(n => n.id).sort()).toEqual(['Idle', 'Run'])
    // [*] sources/targets become state-start/state-end pseudostate nodes.
    expect([...graph.nodes.values()].some(n => n.shape === 'state-start')).toBe(true)
    expect([...graph.nodes.values()].some(n => n.shape === 'state-end')).toBe(true)
    // One graph edge per transition.
    expect(graph.edges.length).toBe(d.body.transitions.length)
    // The labeled transition survives as a labeled edge.
    expect(graph.edges.some(e => e.source === 'Idle' && e.target === 'Run' && e.label === 'go')).toBe(true)
  })

  test('composite body: composite ↔ subgraph with its members', () => {
    const d = state(`stateDiagram-v2
  state First {
    a --> b
  }`)
    const graph = parseLegacy(serializeMermaid(d))
    expect(graph.subgraphs.map(s => s.id)).toEqual(['First'])
    expect(graph.subgraphs[0]!.nodeIds.sort()).toEqual(['a', 'b'])
  })
})

// ---------------------------------------------------------------------------
describe('state verify — geometric Tier 2 projection (parity with flowchart)', () => {
  // State diagrams project to a MermaidGraph and run the SAME verifyGraph as
  // flowcharts. Prove parity: a state source and the equivalent flowchart
  // source produce the same graph-verifier warnings, and state verify
  // produces a real geometric layout (not the empty layout).
  const STATE = `stateDiagram-v2
  A --> B
  B --> C
  C --> A`

  test('state verify yields a real geometric layout with finite coordinates', () => {
    const r = parseMermaid(STATE)
    expect(r.ok).toBe(true)
    if (!r.ok) return
    const v = verifyMermaid(r.value)
    expect(v.layout.nodes.length).toBeGreaterThan(0)
    const pending: unknown[] = [v.layout]
    while (pending.length) {
      const value = pending.pop()
      if (typeof value === 'number') expect(Number.isFinite(value)).toBe(true)
      else if (value && typeof value === 'object') pending.push(...Object.values(value))
    }
  })

  test('composite state ids are valid transition endpoints', () => {
    const r = parseMermaid(`stateDiagram-v2
      state Configuring {
        [*] --> NewValueSelection
        NewValueSelection --> NewValuePreview : EvNewValue
        NewValuePreview --> NewValueSelection : EvNewValueRejected

        state NewValuePreview {
          State1 --> State2
        }
      }`)
    expect(r.ok).toBe(true)
    if (!r.ok) return
    const v = verifyMermaid(r.value)
    expect(v.warnings.filter(w => w.code === 'EDGE_MISANCHORED')).toEqual([])
    expect(v.ok).toBe(true)
  })

  test('state runs the flowchart graph verifier: graph-path warnings match the flowchart projection', () => {
    // DUPLICATE_EDGE and UNREACHABLE_NODE are emitted only by the flowchart
    // graph verifier (the same pass that runs graphGeometryWarnings), so seeing
    // them on a state diagram proves the state path runs it, and suppressing
    // one of them proves suppression is honored. The geometric checks
    // themselves are proven on a doctored state layout below.
    const body = '  [*] --> A\n  A --> B\n  A --> B\n  C --> D\n  D --> C'
    const expected: LayoutWarning[] = [
      { code: 'DUPLICATE_EDGE', edge: 'A->B#1', duplicateOf: 'A->B#0', from: 'A', to: 'B' },
      { code: 'UNREACHABLE_NODE', node: 'C' },
      { code: 'UNREACHABLE_NODE', node: 'D' },
    ]
    expect(verifyMermaid(`stateDiagram-v2\n${body}`).warnings).toEqual(expected)
    expect(verifyMermaid(`flowchart TD\n${body.replace('[*]', 'S')}`).warnings).toEqual(expected)
    expect(verifyMermaid(`stateDiagram-v2\n${body}`, { suppress: ['DUPLICATE_EDGE'] }).warnings).toEqual(expected.slice(1))
  })

  test('the geometric checks fire on a doctored state layout (graphGeometryWarnings, the pass verify runs)', () => {
    const r = parseMermaid('stateDiagram-v2\n  [*] --> A\n  A --> B')
    if (!r.ok || r.value.body.kind !== 'state') throw new Error('expected a state body')
    const graph = stateBodyToGraph(r.value.body)
    const positioned = positionFamilyArtifact(r.value)!.positioned as PositionedGraph
    const moved = (id: string, box: Partial<PositionedGraph['nodes'][number]>): PositionedGraph =>
      ({ ...positioned, nodes: positioned.nodes.map(n => (n.id === id ? { ...n, ...box } : n)) })
    const a = positioned.nodes.find(n => n.id === 'A')!
    const [first, second] = positioned.nodes.filter(n => n.id === 'A' || n.id === 'B').map(n => n.id) as [string, string]

    expect(graphGeometryWarnings(positioned, graph)).toEqual([])
    expect(graphGeometryWarnings(moved('A', { x: -10, y: -10 }), graph)).toEqual([
      { code: 'OFF_CANVAS', target: 'A', axis: 'x' },
      { code: 'OFF_CANVAS', target: 'A', axis: 'y' },
    ])
    expect(graphGeometryWarnings(moved('B', { x: a.x, y: a.y, width: a.width, height: a.height }), graph)).toEqual([
      { code: 'NODE_OVERLAP', a: first, b: second, areaPx: Math.round(a.width * a.height) },
    ])
  })

  test('dense state source: geometric path runs and lays out every state', () => {
    // Verify returns the real positioned layout for state (positioned nodes
    // for every modeled state); the empty-layout fallback would yield zero
    // nodes.
    const dense = `stateDiagram-v2
  [*] --> A
  A --> B
  A --> C
  B --> C
  C --> B
  B --> A
  C --> A`
    const r = parseMermaid(dense)
    expect(r.ok).toBe(true)
    if (!r.ok) return
    const v = verifyMermaid(r.value)
    // Three modeled states (A,B,C) plus the start pseudostate all positioned.
    const ids = new Set(v.layout.nodes.map(n => n.id))
    expect(ids.has('A') && ids.has('B') && ids.has('C')).toBe(true)
    expect(v.layout.nodes.length).toBeGreaterThanOrEqual(4)
    // Every edge has a real polyline path (geometric routing ran).
    expect(v.layout.edges.every(e => e.path.length >= 2)).toBe(true)
  })

  test('EMPTY_DIAGRAM fires for a header-only state diagram', () => {
    const v = verifyMermaid('stateDiagram-v2')
    expect(v.warnings.some(w => w.code === 'EMPTY_DIAGRAM')).toBe(true)
    expect(v.ok).toBe(false)
  })

  test('LABEL_OVERFLOW fires for an over-long state label', () => {
    const v = verifyMermaid(`stateDiagram-v2\n  state "${'x'.repeat(60)}" as s1\n  s1 --> s2`)
    expect(v.warnings.some(w => w.code === 'LABEL_OVERFLOW')).toBe(true)
  })
})

// ---------------------------------------------------------------------------
describe('nested State authored correspondence', () => {
  // Development input: these literal facts precede every parser/renderer call.
  // The named *_start states must coexist with three contextual start circles.
  const source = `stateDiagram-v2
state "外側 📦" as Outer {
  state "外待機 東京" as Outer_start
  state "内側 👩🏽‍💻" as Inner {
    state "待機 東京" as Inner_start
    state "稼働 🧭" as edge__0
    [*] --> Inner_start : 起動
    Inner_start --> edge__0 : 送信 一
    Inner_start --> edge__0 : 送信 二
    edge__0 --> Inner_start : 戻る
    edge__0 --> edge__0 : 再試行
    note right of Inner_start : 注記 🧪
  }
  [*] --> Outer_start : 外起動
  Outer_start --> Inner : 入る
}
state "root literal 🌐" as _start
[*] --> Outer : 全体起動
Outer --> _start : 終了
_start --> Outer : 再開`
  const authoredStates = [
    ['Outer', undefined, '外側 📦'], ['Outer_start', 'Outer', '外待機 東京'],
    ['Inner', 'Outer', '内側 👩🏽‍💻'], ['Inner_start', 'Inner', '待機 東京'],
    ['edge__0', 'Inner', '稼働 🧭'], ['_start', undefined, 'root literal 🌐'],
  ] as const
  const transitions = [
    ['Inner', '[*]', 'Inner_start', '起動'],
    ['Inner', 'Inner_start', 'edge__0', '送信 一'],
    ['Inner', 'Inner_start', 'edge__0', '送信 二'],
    ['Inner', 'edge__0', 'Inner_start', '戻る'],
    ['Inner', 'edge__0', 'edge__0', '再試行'],
    ['Outer', '[*]', 'Outer_start', '外起動'],
    ['Outer', 'Outer_start', 'Inner', '入る'],
    [undefined, '[*]', 'Outer', '全体起動'],
    [undefined, 'Outer', '_start', '終了'],
    [undefined, '_start', 'Outer', '再開'],
  ] as const

  test.each(['agentic', 'elk'] as const)('%s preserves nested authored identities, occurrences and SVG centreline contacts through reload', backend => {
    const { JSDOM } = createRequire(import.meta.url)('jsdom')
    const original = state(source)
    const json = synthesizeFromGraph({ kind: 'state', body: JSON.parse(JSON.stringify(original.body)) })
    if (!json.ok) throw new Error('Expected State JSON reload')
    const inputs = [source, serializeMermaid(original), serializeMermaid(json.value)]
    for (const input of inputs) {
      const diagram = state(input)
      const states: unknown[] = [], edges: unknown[] = []
      const visit = (nodes: StateNode[], relations: StateTransition[], parent?: string): void => {
        for (const node of nodes) {
          states.push([node.id, parent, node.label])
          if (node.states) visit(node.states, node.transitions ?? [], node.id)
        }
        edges.push(...relations.map(edge => [parent, edge.from, edge.to, edge.label]))
      }
      visit(diagram.body.states, diagram.body.transitions)
      expect(states).toEqual([...authoredStates])
      expect(edges).toEqual([...transitions])
      expect(diagram.body.notes?.map(({ target, side, text }) => [target, side, text])).toEqual([['Inner_start', 'right', '注記 🧪']])

      const options = { graphLayout: { backend, fallback: 'none' as const }, embedFontImport: false }
      const { layout } = layoutMermaidWithReceipt(input, options)
      const rendered = renderMermaidSVGWithReceipt(input, options)
      expect(rendered.receipt.layoutDecisions).toEqual([expect.objectContaining({ selected: backend, attempts: [{ backend, outcome: 'selected' }] })])
      expect(layout.groups.map(({ id, parentId }) => [id, parentId])).toEqual([['Outer', undefined], ['Inner', 'Outer']])
      const starts = layout.nodes.filter(node => node.shape === 'state-start')
      expect(starts).toHaveLength(3)
      expect(new Set([...layout.nodes, ...layout.groups].map(node => node.id)).size).toBe(9)
      for (const [parent, members] of [['Outer', ['Outer_start']], ['Inner', ['Inner_start', 'edge__0']]] as const) {
        expect(layout.groups.find(group => group.id === parent)!.members.filter(id => !starts.some(start => start.id === id)).sort()).toEqual([...members].sort())
      }

      const dom = new JSDOM(rendered.svg, { contentType: 'image/svg+xml' })
      try {
        const document = dom.window.document as Document
        const nodes = [...document.querySelectorAll('g.node')]
        const groups = [...document.querySelectorAll('g.subgraph')]
        const carriers = [...document.querySelectorAll('[data-role="edge"][data-from]')]
        // This finite oracle uses untransformed crisp shapes in SVG coordinates.
        expect(document.querySelectorAll('[transform]')).toHaveLength(0)
        expect(nodes).toHaveLength(7)
        expect(groups).toHaveLength(2)
        expect(groups.map(group => [group.getAttribute('data-id'), group.getAttribute('data-parent-id')])).toEqual([['Outer', null], ['Inner', 'Outer']])
        expect(carriers).toHaveLength(transitions.length)
        expect(new Set(carriers.map(tag => tag.getAttribute('data-id'))).size).toBe(transitions.length)
        for (const [id, , label] of authoredStates) {
          const occurrences = [...nodes, ...groups].filter(tag => tag.getAttribute('data-id') === id)
          expect(occurrences).toHaveLength(1)
          expect(occurrences[0]!.getAttribute('data-label')).toBe(label)
        }
        const texts = [...document.querySelectorAll('text')].map(tag => tag.textContent)
        expect(texts.sort()).toEqual([...authoredStates.map(([, , label]) => label), ...transitions.map(([, , , label]) => label), '注記 🧪'].sort())
        expect([...document.querySelectorAll('g.state-note')].map(tag => [tag.getAttribute('data-target'), tag.getAttribute('data-side')])).toEqual([['Inner_start', 'right']])

        // Bind direct XML children to owners, then measure the actual rounded
        // outline centreline with a fixed .02px tolerance, including corner arcs.
        const shapeOf = (owner: Element): Element => {
          const shapes = [...owner.children].filter(child => ['rect', 'circle', 'polygon'].includes(child.localName))
          expect(shapes).toHaveLength(1)
          return shapes[0]!
        }
        const number = (shape: Element, name: string) => Number(shape.getAttribute(name) ?? 0)
        const touches = (point: number[], shape: Element): boolean => {
          const [x, y] = point as [number, number]
          if (shape.localName === 'circle') return Math.abs(Math.hypot(x - number(shape, 'cx'), y - number(shape, 'cy')) - number(shape, 'r')) < 0.02
          expect(shape.localName).toBe('rect')
          const w = number(shape, 'width'), h = number(shape, 'height'), r = number(shape, 'rx')
          expect(number(shape, 'ry')).toBe(r)
          expect(r).toBeGreaterThanOrEqual(0)
          expect(r).toBeLessThanOrEqual(Math.min(w, h) / 2)
          const dx = Math.abs(x - number(shape, 'x') - w / 2) - (w / 2 - r)
          const dy = Math.abs(y - number(shape, 'y') - h / 2) - (h / 2 - r)
          return Math.abs(Math.hypot(Math.max(dx, 0), Math.max(dy, 0)) + Math.min(Math.max(dx, dy), 0) - r) < 0.02
        }
        const ownerOf = (id: string) => [...nodes, ...groups].find(tag => tag.getAttribute('data-id') === id)!
        for (const [parent, from, to, label] of transitions) {
          const occurrence = carriers.filter(tag => tag.getAttribute('data-label') === label)
          expect(occurrence).toHaveLength(1)
          const carrier = occurrence[0]!, sourceId = carrier.getAttribute('data-from')!
          expect(carrier.getAttribute('data-to')).toBe(to)
          if (from === '[*]') {
            const start = ownerOf(sourceId), circle = shapeOf(start)
            expect(start.getAttribute('data-shape')).toBe('state-start')
            expect(circle.localName).toBe('circle')
            expect(number(circle, 'r')).toBeGreaterThan(0)
            expect(authoredStates.some(([id]) => id === sourceId)).toBe(false)
            expect(layout.groups.filter(group => group.members.includes(sourceId)).map(group => group.id)).toEqual(parent === undefined ? [] : [parent])
            const enclosing = groups.filter(group => {
              const box = shapeOf(group), cx = number(circle, 'cx'), cy = number(circle, 'cy'), r = number(circle, 'r')
              return cx - r > number(box, 'x') && cy - r > number(box, 'y')
                && cx + r < number(box, 'x') + number(box, 'width') && cy + r < number(box, 'y') + number(box, 'height')
            }).map(group => group.getAttribute('data-id'))
            expect(enclosing).toEqual(parent === 'Inner' ? ['Outer', 'Inner'] : parent === 'Outer' ? ['Outer'] : [])
            for (const group of groups.filter(group => enclosing.includes(group.getAttribute('data-id')))) {
              const box = shapeOf(group), cx = number(circle, 'cx'), r = number(circle, 'r'), corner = number(box, 'rx')
              // Whole circle occupies the frame's central straight-sided strip;
              // bounding-box containment therefore cannot admit a missing corner.
              expect(cx - r).toBeGreaterThan(number(box, 'x') + corner)
              expect(cx + r).toBeLessThan(number(box, 'x') + number(box, 'width') - corner)
            }
          } else expect(sourceId).toBe(from)
          expect(['polyline', 'path']).toContain(carrier.localName)
          if (carrier.localName === 'path') expect(carrier.getAttribute('d')).toMatch(/^M[-\d.eE+,\s]+(?:[LQC][-\d.eE+,\s]+)+$/)
          const coordinates = (carrier.getAttribute('points') ?? carrier.getAttribute('d') ?? '').match(/-?(?:\d*\.)?\d+(?:e[-+]?\d+)?/gi)!.map(Number)
          expect(coordinates.length).toBeGreaterThanOrEqual(4)
          expect(touches(coordinates.slice(0, 2), shapeOf(ownerOf(sourceId)))).toBe(true)
          expect(touches(coordinates.slice(-2), shapeOf(ownerOf(to)))).toBe(true)
          expect(carrier.getAttribute('marker-start')).toBeNull()
          const markerId = carrier.getAttribute('marker-end')?.match(/^url\(#(.+)\)$/)?.[1]
          const marker = document.getElementById(markerId!)!
          expect(marker).toBeDefined()
          const arrow = shapeOf(marker)
          expect(arrow.localName).toBe('polygon')
          expect(number(marker, 'markerWidth')).toBeGreaterThan(0)
          expect(number(marker, 'markerHeight')).toBeGreaterThan(0)
          expect(marker.getAttribute('orient')).toBe('auto')
          expect(marker.getAttribute('viewBox')).toBeNull()
          expect(arrow.getAttribute('fill')).not.toBe('none')
          const triangle = arrow.getAttribute('points')!.match(/-?(?:\d*\.)?\d+/g)!.map(Number)
          expect(triangle).toHaveLength(6)
          expect(triangle[2]!).toBeGreaterThan(triangle[0]!)
          expect(triangle[2]!).toBeGreaterThan(triangle[4]!)
          expect(triangle[1]!).toBeLessThan(triangle[3]!)
          expect(triangle[5]!).toBeGreaterThan(triangle[3]!)
          expect(triangle.slice(2, 4)).toEqual([number(marker, 'refX'), number(marker, 'refY')])
        }
      } finally { dom.window.close() }
    }
  })
})

describe('state fast-check round-trip property', () => {
  // Generate small state machines (incl. nested composites depth ≤ 2 and [*]
  // usage) and assert serialize → parse → serialize is idempotent and the body
  // survives the round-trip with the same state/transition shape.
  const id = fc.string({ minLength: 1, maxLength: 4 }).filter(s => /^[A-Za-z][A-Za-z0-9]*$/.test(s))

  const shape = (states: StateNode[], transitions: StateTransition[]): unknown => ({
    states: states.map(s => ({ id: s.id, label: s.label, children: s.states ? shape(s.states, s.transitions ?? []) : null })),
    transitions: transitions.map(t => ({ from: t.from, to: t.to, label: t.label })),
  })
  // `state()` throws unless the source parses to a structured state body, so a
  // regression to opaque fails the property instead of passing it vacuously.
  const roundTripsAsState = (src: string, expected: unknown): void => {
    const d = state(src)
    expect(shape(d.body.states, d.body.transitions)).toEqual(expected)
    const s1 = serializeMermaid(d)
    const d2 = state(s1)
    expect({ src, reserialized: serializeMermaid(d2), shape: shape(d2.body.states, d2.body.transitions) })
      .toEqual({ src, reserialized: s1, shape: expected })
  }

  const simpleMachine = fc.record({
    states: fc.uniqueArray(id, { minLength: 1, maxLength: 4 }),
  }).chain(({ states }) => {
    const endpoints = fc.constantFrom('[*]', ...states)
    return fc.record({
      states: fc.constant(states),
      transitions: fc.array(fc.record({ from: endpoints, to: endpoints }), { minLength: 1, maxLength: 5 }),
    })
  })

  test('generated simple machines retain every declared state and labeled transition', () => {
    fc.assert(fc.property(simpleMachine, ({ states, transitions }) => {
      const lines = ['stateDiagram-v2']
      // Emit every generated state, including states no transition references.
      for (const id of states) lines.push(`  state "${id} label" as ${id}`)
      for (const [i, t] of transitions.entries()) lines.push(`  ${t.from} --> ${t.to} : step ${i}`)
      const src = lines.join('\n') + '\n'
      return roundTripsAsState(src, {
        states: states.map(id => ({ id, label: `${id} label`, children: null })),
        transitions: transitions.map((t, i) => ({ ...t, label: `step ${i}` })),
      })
    }), fcParameters({ numRuns: 200 }))
  })

  test('generated nested composites (depth ≤ 2) round-trip stably', () => {
    const composite = fc.record({
      outer: id,
      inner: fc.uniqueArray(id, { minLength: 1, maxLength: 3 }),
    }).filter(({ outer, inner }) => !inner.includes(outer))
    fc.assert(fc.property(composite, ({ outer, inner }) => {
      const lines = ['stateDiagram-v2', `  state ${outer} {`]
      lines.push(`    [*] --> ${inner[0]}`)
      for (let i = 0; i < inner.length - 1; i++) lines.push(`    ${inner[i]} --> ${inner[i + 1]}`)
      lines.push(`    ${inner[inner.length - 1]} --> [*]`)
      lines.push('  }')
      const src = lines.join('\n') + '\n'
      return roundTripsAsState(src, {
        states: [{
          id: outer, label: undefined,
          children: {
            states: inner.map(id => ({ id, label: undefined, children: null })),
            transitions: [
              { from: '[*]', to: inner[0], label: undefined },
              ...inner.slice(0, -1).map((from, i) => ({ from, to: inner[i + 1], label: undefined })),
              { from: inner.at(-1), to: '[*]', label: undefined },
            ],
          },
        }],
        transitions: [],
      })
    }), fcParameters({ numRuns: 100 }))
  })
})

// ---------------------------------------------------------------------------
describe('state semantic read-back', () => {
  test('facts, check surface, and prose expose stereotypes and notes', () => {
    const d = state(`stateDiagram-v2
  state F <<fork>>
  note right of F : hello`)
    const facts = describeMermaidFacts(d)
    expect(facts).toContain('state F stereotype fork')
    expect(facts).toContain('note#0 right of F : hello')
    const prose = describeMermaid(d, { format: 'text' })
    expect(prose).toContain('F (fork)')
    expect(prose).toContain('right of F: hello')
  })
})

describe('state describe (prose + AX tree)', () => {
  test('AX tree exposes states as nodes and transitions as edges', () => {
    const tree = describeMermaidTree(state())
    expect({ kind: tree.kind, nodes: tree.nodes, edges: tree.edges }).toEqual({
      kind: 'state',
      nodes: [{ id: 'Idle', label: 'Idle' }, { id: 'Active', label: 'In Progress' }],
      edges: [
        { from: '[*]', to: 'Idle' },
        { from: 'Idle', to: 'Active', label: 'start' },
        { from: 'Active', to: 'Idle', label: 'pause' },
        { from: 'Active', to: '[*]', label: 'done' },
      ],
    })
  })
})


test('State declaration timing survives JSON, unrelated edits and scope schedule rebasing', () => {
  const before = 'stateDiagram-v2\nstate "Idle" as A\nstate "Other" as D\n[*] --> A\nA --> B'
  const after = 'stateDiagram-v2\nstate "Idle" as A\n[*] --> A\nstate "Other" as D\nA --> B'
  const first = state(before), second = state(after)
  expect(first.body.states.find(node => node.id === 'D')?.declarationBeforeTransition).toBe(0)
  expect(second.body.states.find(node => node.id === 'D')?.declarationBeforeTransition).toBe(1)
  expect(serializeMermaid(first)).not.toBe(serializeMermaid(second))
  for (const [source, parsed] of [[before, first], [after, second]] as const) {
    expect(renderMermaidASCII(parsed)).toBe(renderMermaidASCII(source))
    const json = synthesizeFromGraph({ kind: 'state', body: JSON.parse(JSON.stringify(parsed.body)) })
    if (!json.ok) throw new Error('Expected declaration provenance in JSON')
    expect(serializeMermaid(json.value)).toBe(serializeMermaid(parsed))
    const renamed = mutate(parsed, { kind: 'rename_state', from: 'B', to: 'C' })
    if (!renamed.ok) throw new Error('Expected unrelated rename')
    const written = serializeMermaid(renamed.value)
    expect(renderMermaidASCII(renamed.value)).toBe(renderMermaidASCII(source.replace('A --> B', 'A --> C')))
    expect([...parseLegacy(written).nodes.keys()]).toEqual([...parseLegacy(source.replace('A --> B', 'A --> C')).nodes.keys()])
  }
  const removed = mutate(second, { kind: 'remove_transition', index: 0 })
  if (!removed.ok || removed.value.body.kind !== 'state') throw new Error('Expected transition removal')
  expect(removed.value.body.states.find(node => node.id === 'D')?.declarationBeforeTransition).toBe(0)
  const nested = state('stateDiagram-v2\nstate P {\n[*] --> A\nD\nA --> B\n}\n[*] --> X\nZ')
  const dissolved = mutate(nested, { kind: 'dissolve_composite', id: 'P' })
  if (!dissolved.ok || dissolved.value.body.kind !== 'state') throw new Error('Expected composite schedule hoist')
  const text = serializeMermaid(dissolved.value)
  expect(text.indexOf('[*] --> A')).toBeLessThan(text.indexOf('  D\n'))
  expect(text.indexOf('  D\n')).toBeLessThan(text.indexOf('A --> B'))
  expect(text.indexOf('A --> B')).toBeLessThan(text.indexOf('[*] --> X'))
  expect(state(text).body).toEqual(dissolved.value.body)
  const moved = mutate(nested, { kind: 'move_state', id: 'Z', parent: 'P' })
  if (!moved.ok || moved.value.body.kind !== 'state') throw new Error('Expected scoped append')
  expect(moved.value.body.states.find(node => node.id === 'P')?.states?.find(node => node.id === 'Z')?.declarationBeforeTransition).toBe(2)
  const implicit = state('stateDiagram-v2\n[*] --> A\nA --> B')
  const labeled = mutate(implicit, { kind: 'set_state_label', id: 'A', label: 'A' })
  if (!labeled.ok) throw new Error('Expected implicit-state label edit')
  expect([...parseLegacy(serializeMermaid(labeled.value)).nodes.keys()]).toEqual([...parseLegacy(serializeMermaid(implicit)).nodes.keys()])
  const invalid = JSON.parse(JSON.stringify(first.body))
  invalid.states[0].declarationBeforeTransition = 99
  expect(synthesizeFromGraph({ kind: 'state', body: invalid }).ok).toBe(false)
})
