import { afterAll, describe, expect, test } from 'bun:test'
import { asClass, mutate, parseRegisteredMermaid, serializeMermaid, verifyMermaid } from '../agent/index.ts'
import { renderMermaidASCII } from '../ascii/index.ts'
import { parseClassDiagram, parseClassRelationship } from '../class/parser.ts'
import { renderMermaidSVG } from '../index.ts'
import { expectNearLinearGrowth } from './helpers/complexity.ts'
import { startUpstreamMermaid } from './helpers/upstream-mermaid.ts'

const upstream = startUpstreamMermaid()
afterAll(() => upstream.close())

const cases = [
  { statement: 'classO .. classP : Link(Dashed)', kind: 'link-dashed', lineType: 1, label: 'Link(Dashed)' },
  { statement: 'A..B', kind: 'link-dashed', lineType: 1 },
  { statement: 'A ..B', kind: 'link-dashed', lineType: 1 },
  { statement: 'A.. B', kind: 'link-dashed', lineType: 1 },
  { statement: 'A -- B', kind: 'link-solid', lineType: 0 },
  { statement: 'A--B', kind: 'link-solid', lineType: 0 },
  { statement: 'A .. B %% comment', kind: 'link-dashed', lineType: 1 },
  { statement: 'A -- B %% comment', kind: 'link-solid', lineType: 0 },
  { statement: 'A .. B : dashed %% note', kind: 'link-dashed', lineType: 1, label: 'dashed %% note' },
  { statement: 'A"1".."*"B : dashed', kind: 'link-dashed', lineType: 1, label: 'dashed', fromCardinality: '1', toCardinality: '*' },
  { statement: 'A"1"..B', kind: 'link-dashed', lineType: 1, fromCardinality: '1' },
  { statement: 'A.."*"B', kind: 'link-dashed', lineType: 1, toCardinality: '*' },
] as const

describe('Class markerless link fidelity', () => {
  test('pinned Mermaid gives both bare links two endpoints and no markers', async () => {
    const relations: Array<Record<string, unknown>> = await upstream.projectAll(cases.map(item => `classDiagram\n${item.statement}`), diagram => {
      const relation = diagram.db.getRelations()[0]
      return { classes: [...diagram.db.getClasses().keys()], from: relation?.id1, to: relation?.id2,
        lineType: relation?.relation.lineType, type1: relation?.relation.type1, type2: relation?.relation.type2,
        title: relation?.title, relationTitle1: relation?.relationTitle1, relationTitle2: relation?.relationTitle2 }
    })
    expect(relations).toEqual(cases.map(item => ({
      classes: item.statement.startsWith('classO') ? ['classO', 'classP'] : ['A', 'B'],
      from: item.statement.startsWith('classO') ? 'classO' : 'A',
      to: item.statement.startsWith('classO') ? 'classP' : 'B',
      lineType: item.lineType,
      type1: 'none',
      type2: 'none',
      relationTitle1: 'fromCardinality' in item ? item.fromCardinality : 'none',
      relationTitle2: 'toCardinality' in item ? item.toCardinality : 'none',
      ...('label' in item ? { title: item.label } : {}),
    })))
  })

  test('native, agent, verify, and SVG retain markerless identity and line style', () => {
    for (const item of cases) {
      const source = `classDiagram\n${item.statement}`
      const from = item.statement.startsWith('classO') ? 'classO' : 'A'
      const to = item.statement.startsWith('classO') ? 'classP' : 'B'
      const native = parseClassDiagram(source.split('\n'))
      expect(native.classes.map(node => node.id)).toEqual([from, to])
      expect(native.relationships).toEqual([expect.objectContaining({
        from, to, type: item.kind, markerAt: 'none',
        ...('fromCardinality' in item ? { fromCardinality: item.fromCardinality } : {}),
        ...('toCardinality' in item ? { toCardinality: item.toCardinality } : {}),
      })])

      const parsed = parseRegisteredMermaid(source)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) continue
      expect(asClass(parsed.value)?.body.relations).toEqual([expect.objectContaining({
        from, to, kind: item.kind,
        ...('fromCardinality' in item ? { fromCardinality: item.fromCardinality } : {}),
        ...('toCardinality' in item ? { toCardinality: item.toCardinality } : {}),
      })])
      const verified = verifyMermaid(parsed.value)
      expect(verified.ok).toBe(true)
      expect(verified.layout?.edges).toHaveLength(1)
      expect(verified.warnings.some(warning => warning.code === 'UNSUPPORTED_SYNTAX' && warning.syntax === 'empty_layout')).toBe(false)

      const svg = renderMermaidSVG(source)
      const relation = svg.match(/<(?:path|polyline) class="class-relationship"[^>]+>/)?.[0]
      expect(relation).toBeDefined()
      for (const attribute of [`data-from="${from}"`, `data-to="${to}"`, `data-type="${item.kind}"`]) expect(relation).toContain(attribute)
      expect(relation).not.toContain('marker-start=')
      expect(relation).not.toContain('marker-end=')
      expect(relation?.includes('stroke-dasharray="6 4"')).toBe(item.kind === 'link-dashed')
      if ('label' in item) expect(svg).toContain(`data-label="${item.label}"`)

      const serialized = serializeMermaid(parsed.value)
      expect(parseClassDiagram(serialized.trim().split('\n').map(line => line.trim())).relationships).toEqual([
        expect.objectContaining({ from, to, type: item.kind }),
      ])
    }
  })

  test('cardinalities survive and renaming one endpoint preserves an unrelated arrow', () => {
    const source = 'classDiagram\nA "1" .. "*" B : dashed\nB --> C : directed'
    const parsed = parseRegisteredMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return
    const body = asClass(parsed.value)?.body
    expect(body?.relations).toEqual([
      expect.objectContaining({ from: 'A', to: 'B', kind: 'link-dashed', fromCardinality: '1', toCardinality: '*', label: 'dashed' }),
      expect.objectContaining({ from: 'B', to: 'C', kind: 'association', label: 'directed' }),
    ])
    const renamed = mutate(parsed.value, { kind: 'rename_class', from: 'B', to: 'Branch' })
    expect(renamed.ok).toBe(true)
    if (!renamed.ok) return
    const native = parseClassDiagram(serializeMermaid(renamed.value).trim().split('\n').map(line => line.trim()))
    expect(native.relationships).toEqual([
      expect.objectContaining({ from: 'A', to: 'Branch', type: 'link-dashed', fromCardinality: '1', toCardinality: '*', label: 'dashed' }),
      expect.objectContaining({ from: 'Branch', to: 'C', type: 'association', label: 'directed' }),
    ])
  })

  test('terminal output keeps dashed/solid lines markerless', () => {
    const dashed = renderMermaidASCII('classDiagram\nA .. B', { useAscii: true, colorMode: 'none' })
    const solid = renderMermaidASCII('classDiagram\nA -- B', { useAscii: true, colorMode: 'none' })
    expect(dashed).toContain('  :')
    expect(solid).toContain('  |')
    expect(dashed).not.toMatch(/[<>^v]/)
    expect(solid).not.toMatch(/[<>^v]/)
  })

  test('delimiter-looking IDs stay intact and long malformed links finish promptly', () => {
    const source = 'classDiagram\n`A..B` .. C'
    const native = parseClassDiagram(source.split('\n'))
    expect(native.relationships).toEqual([expect.objectContaining({ from: 'A..B', to: 'C', type: 'link-dashed' })])
    expect(renderMermaidSVG(source)).toContain('data-from="A..B" data-to="C"')

    // Link bytes in an inline member are not a relationship. Mermaid accepts
    // both members; the native fail-loud guard must leave them untouched.
    for (const member of ['A : +String foo--bar', 'A : +foo() .. bar']) {
      const memberSource = `classDiagram\n${member}`
      expect(parseClassDiagram(memberSource.split('\n')).classes.map(node => node.id)).toEqual(['A'])
      expect(parseClassDiagram(memberSource.split('\n')).relationships).toHaveLength(0)
      expect(renderMermaidSVG(memberSource)).toContain('data-id="A"')
    }

    const malformed = (size: number) => `A${'..'.repeat(size)} B`
    expectNearLinearGrowth('malformed dotted relationship', size => {
      expect(parseClassRelationship(malformed(size))).toBeNull()
    }, 32_000)
    expectNearLinearGrowth('malformed dotted relationship through parse + verify', size => {
      const parsed = parseRegisteredMermaid(`classDiagram\n${malformed(size)}`)
      expect(parsed.ok && parsed.value.body.kind).toBe('opaque')
      if (parsed.ok) expect(verifyMermaid(parsed.value).warnings.some(warning => warning.code === 'UNSUPPORTED_SYNTAX')).toBe(true)
    }, 32_000)
    expectNearLinearGrowth('long relationship endpoint', size => {
      expect(parseRegisteredMermaid(`classDiagram\n${'A'.repeat(size)}--B : x:y`).ok).toBe(true)
    }, 60_000)
  })

  test('pinned-invalid bare labels fail loudly without becoming marked arrows', async () => {
    const statements = [
      'A .. B : a:b',
      'Foo--B : a:b',
      'A--out : a:b',
      'A -- B : a:b',
      'A .. B :',
      'A -- B :',
      'A .. B : label;',
      'A -- B : label;',
      'o--B',
      'A--o',
      'o .. B',
      'A .. o',
      '$A -- B',
      'A .. A$B',
      'class -- B',
      'A .. note',
      '`note` -- B',
    ]
    expect(await Promise.all(statements.map(statement => upstream.accepts(`classDiagram\n${statement}`)))).toEqual(statements.map(() => false))
    for (const statement of statements) {
      const invalidSource = `classDiagram\nclass A\nclass B\nclass Foo\nclass out\n${statement}`
      expect(parseClassRelationship(statement)).toBeNull()
      expect(() => parseClassDiagram(invalidSource.split('\n'))).toThrow('Unrecognized class relationship statement')
      expect(() => renderMermaidSVG(invalidSource)).toThrow('Unrecognized class relationship statement')
      const invalidLabel = parseRegisteredMermaid(invalidSource)
      expect(invalidLabel.ok).toBe(true)
      if (!invalidLabel.ok) continue
      expect(invalidLabel.value.body.kind).toBe('opaque')
      const result = verifyMermaid(invalidLabel.value)
      expect(result.ok).toBe(false)
      expect(result.warnings.some(warning => warning.code === 'UNSUPPORTED_SYNTAX')).toBe(true)
      expect(result.warnings.some(warning => warning.code === 'RENDER_FAILED')).toBe(true)
    }
  })

  test('source-normalizer label gaps remain diagnosed, not falsely native', async () => {
    // Upstream accepts both; the shared source projection currently trims a
    // whitespace-only suffix and decodes numeric entities before native parse.
    // Until that seam is repaired under #260, keep them opaque and fail loud.
    const statements = ['A .. B : ', 'A .. B : a&#58;b']
    expect(await upstream.projectAll(statements.map(statement => `classDiagram\n${statement}`), diagram => diagram.db.getRelations().length)).toEqual([1, 1])
    for (const statement of statements) {
      const source = `classDiagram\n${statement}`
      const parsed = parseRegisteredMermaid(source)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) continue
      expect(parsed.value.body.kind).toBe('opaque')
      const result = verifyMermaid(parsed.value)
      expect(result.ok).toBe(false)
      expect(result.warnings.some(warning => warning.code === 'UNSUPPORTED_SYNTAX')).toBe(true)
      expect(result.warnings.some(warning => warning.code === 'RENDER_FAILED')).toBe(true)
    }
  })

  test('accepted endpoint tokens include escaped reserved IDs without overclaiming other ID grammar', async () => {
    const statements = ['`o` .. B', 'A .. `o`', '`class` -- B', '`A$B` .. C', '0 -- B', 'Class -- B']
    expect(await upstream.projectAll(statements.map(statement => `classDiagram\n${statement}`), diagram => diagram.db.getRelations().length)).toEqual(statements.map(() => 1))
    for (const statement of statements) {
      const source = `classDiagram\n${statement}`
      expect(parseClassDiagram(source.split('\n')).relationships).toHaveLength(1)
      const parsed = parseRegisteredMermaid(source)
      expect(parsed.ok).toBe(true)
      if (parsed.ok) expect(asClass(parsed.value)?.body.relations).toHaveLength(1)
    }
  })
})
