/**
 * Property tests for the shared hex color math — the one implementation the
 * SVG theme system, ASCII/ANSI themes, chart palettes, and contrast helpers
 * all rely on.
 */
import { describe, test, expect } from 'bun:test'
import fc from 'fast-check'
import { parseHex, tryParseHex, tryParseCssColor, toHex, mixHex, isHexColor, isSixDigitHex, luma255, ensureContrast } from '../shared/color-math.ts'

const channel = fc.integer({ min: 0, max: 255 })
const hexColor = fc.tuple(channel, channel, channel).map(([r, g, b]) => toHex(r, g, b))

describe('shared color math', () => {
  test.each([
    ['#aaaaaa', '#ffffff', 4.5, undefined, '#767676'],
    ['#777777', '#ffffff', 4.5, undefined, '#767676'],
    ['#abc', '#fff', 7, undefined, '#525a62'],
    ['#8888', '#888888', 3, '#fff', '#ececec'],
    ['red', '#ffffff', 4.5, undefined, '#000000'],
    [' #123456 ', '#123456', 7, undefined, '#b8c2cb'],
    ['var(--ink)', '#ffffff', 4.5, undefined, 'var(--ink)'],
  ] as const)('contrast adjustment retains the first rounded passing color for %s on %s', (candidate, background, minimum, fallback, expected) => {
    expect(ensureContrast(candidate, background, minimum, fallback)).toBe(expected)
  })

  test('parseHex ∘ toHex is the identity on channels', () => {
    fc.assert(fc.property(channel, channel, channel, (r, g, b) => {
      const [r2, g2, b2] = parseHex(toHex(r, g, b))
      return r2 === r && g2 === g && b2 === b
    }))
  })

  test('#RGB shorthand expands per channel digit', () => {
    expect(parseHex('#abc')).toEqual([0xaa, 0xbb, 0xcc])
    expect(parseHex('#fff')).toEqual([255, 255, 255])
  })

  test('#RGBA shorthand expands like #RGB, and its alpha is ignored like #RRGGBBAA\'s', () => {
    expect(parseHex('#abcd')).toEqual([0xaa, 0xbb, 0xcc])
    expect(parseHex('#aabbccdd')).toEqual([0xaa, 0xbb, 0xcc])
  })

  test('mixing any loose hex color yields a concrete #rrggbb', () => {
    const looseHex = fc.constantFrom(3, 4, 6, 8)
      .chain(length => fc.array(fc.constantFrom(...'0123456789abcdefABCDEF'), { minLength: length, maxLength: length }))
      .map(digits => `#${digits.join('')}`)
    fc.assert(fc.property(looseHex, looseHex, fc.integer({ min: 0, max: 100 }), (fg, bg, pct) =>
      isHexColor(fg) && isHexColor(bg) && /^#[0-9a-f]{6}$/.test(mixHex(fg, bg, pct))
    ))
  })

  test('mixing a color with itself is the identity at any percentage', () => {
    fc.assert(fc.property(hexColor, fc.integer({ min: 0, max: 100 }), (c, pct) =>
      mixHex(c, c, pct) === c
    ))
  })

  test('mix endpoints: 100% is fg, 0% is bg', () => {
    fc.assert(fc.property(hexColor, hexColor, (fg, bg) =>
      mixHex(fg, bg, 100) === fg && mixHex(fg, bg, 0) === bg
    ))
  })

  test('mix output channels stay within the endpoint interval', () => {
    fc.assert(fc.property(hexColor, hexColor, fc.integer({ min: 0, max: 100 }), (fg, bg, pct) => {
      const [fr, fgc, fb] = parseHex(fg)
      const [br, bgc, bb] = parseHex(bg)
      const [mr, mg, mb] = parseHex(mixHex(fg, bg, pct))
      const within = (m: number, a: number, b: number) => m >= Math.min(a, b) && m <= Math.max(a, b)
      return within(mr, fr, br) && within(mg, fgc, bgc) && within(mb, fb, bb)
    }))
  })

  test('tryParseHex accepts exactly the documented forms', () => {
    expect(tryParseHex('#3b82f6')).toEqual([0x3b, 0x82, 0xf6])
    expect(tryParseHex('#abc')).toEqual([0xaa, 0xbb, 0xcc])
    expect(tryParseHex('#3b82')).toEqual([0x33, 0xbb, 0x88])
    expect(tryParseHex('#3b82f6ff')).toEqual([0x3b, 0x82, 0xf6])
    expect(tryParseHex('3b82f6')).toBeNull()
    expect(tryParseHex('#3b82f')).toBeNull()
    expect(tryParseHex('#3b82f6f')).toBeNull()
    expect(tryParseHex('#xyzxyz')).toBeNull()
  })

  test('validators: every strict hex is also a loose hex', () => {
    fc.assert(fc.property(hexColor, c => isSixDigitHex(c) && isHexColor(c)))
    expect(isHexColor('#abc')).toBe(true)
    expect(isHexColor('#abcd')).toBe(true)
    expect(isHexColor('#12345')).toBe(false)
    expect(isHexColor('#1234567')).toBe(false)
    expect(isSixDigitHex('#abc')).toBe(false)
  })

  test('CSS HSL hue units resolve to the same concrete sRGB color', () => {
    const cssHex = (value: string): string => {
      const parsed = tryParseCssColor(value)!
      return toHex(parsed[0], parsed[1], parsed[2])
    }
    expect(cssHex('hsl(217 100% 60%)')).toBe('#3381ff')
    expect(cssHex('hsl(217deg 100% 60%)')).toBe('#3381ff')
    expect(cssHex('hsl(241.111111grad 100% 60%)')).toBe('#3381ff')
    expect(cssHex(`hsl(${217 * Math.PI / 180}rad 100% 60%)`)).toBe('#3381ff')
    expect(cssHex('hsl(0.6027777777777777turn 100% 60%)')).toBe('#3381ff')
    expect(tryParseCssColor('hsl(0.5turnjunk 100% 60%)')).toBeNull()
  })

  test('luma255 is bounded and monotone in each channel', () => {
    fc.assert(fc.property(channel, channel, channel, (r, g, b) => {
      const l = luma255(r, g, b)
      return l >= 0 && l <= 255 &&
        luma255(Math.min(r + 1, 255), g, b) >= l &&
        luma255(r, Math.min(g + 1, 255), b) >= l &&
        luma255(r, g, Math.min(b + 1, 255)) >= l
    }))
  })
})
