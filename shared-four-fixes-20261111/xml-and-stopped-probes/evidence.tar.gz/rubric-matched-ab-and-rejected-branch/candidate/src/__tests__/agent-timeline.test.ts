// Timeline structured mutation (3rd structured family).

import { describe, test, expect } from 'bun:test'
import { parseRegisteredMermaid as parseMermaid } from '../agent/parse.ts'
import { serializeMermaid } from '../agent/serialize.ts'
import { mutate } from '../agent/mutate.ts'
import { verifyMermaid } from '../agent/verify.ts'
import { buildMermaid } from '../agent/create.ts'
import { asTimeline } from '../agent/types.ts'
import type { TimelineBody, TimelineValidDiagram, TimelineMutationOp } from '../agent/types.ts'
import { parseTimelineDiagram } from '../timeline/parser.ts'
import { normalizeMermaidSource } from '../mermaid-source.ts'
import { startUpstreamMermaid } from './helpers/upstream-mermaid.ts'
import { renderMermaidSVG, renderMermaidASCII } from '../agent/core.ts'
import { mutateTimeline, renderTimeline } from '../agent/timeline-body.ts'

function parse(src: string) {
  const r = parseMermaid(src); if (!r.ok) throw new Error('parse: ' + JSON.stringify(r.error))
  return r.value
}
function timeline(src: string): TimelineValidDiagram {
  const t = asTimeline(parse(src)); if (!t) throw new Error('not timeline'); return t
}

// Occurrence IDs are local to a parse, so insertion/move tests compare the
// semantic fields while retaining section, period and event order.
function timelineMeaning(body: TimelineBody) {
  return {
    direction: body.direction, title: body.title,
    accessibilityTitle: body.accessibilityTitle, accessibilityDescription: body.accessibilityDescription,
    sections: body.sections.map(section => ({ label: section.label, periods: section.periods.map(period => ({
      label: period.label, events: period.events.map(event => event.text),
    })) })),
  }
}

describe('timeline parsing — structured', () => {
  test('native parsing accepts explicitly absent optional accessibility fields', () => {
    const lines = ['timeline', '2024 : Launch']
    expect(parseTimelineDiagram(lines, { title: undefined, descr: undefined })).toEqual(parseTimelineDiagram(lines))
  })
  test('inline header comments keep neighboring source while typed edits address repeated occurrences', () => {
    const source = 'timeline TD # keep direction\r\n  title History\r\nsection Plan\r\n  2024 : Same\r\n% keep middle\r\n  2024 : Same\r\n# keep footer\r\n'
    const original = timeline(source), before = JSON.stringify(original)
    expect(serializeMermaid(original)).toBe(source)
    const edited = mutate(original, { kind: 'set_event_text', sectionIndex: 0, periodIndex: 1, eventIndex: 0, text: 'Revised' })
    if (!edited.ok) throw new Error(edited.error.message)
    expect(serializeMermaid(edited.value)).toBe(source.replace('  2024 : Same\r\n#', '  2024 : Revised\r\n#'))
    expect(asTimeline(edited.value)!.body.sections[0]!.periods.map(period => period.events[0]!.text)).toEqual(['Same', 'Revised'])
    expect(JSON.stringify(original)).toBe(before)
  })

  test('source continuations retain their native period owner after a section changes', () => {
    const source = 'timeline LR %% keep header\nsection Earlier\n2024 : Launch\n% keep bridge\nsection Later : Follow up\n: Review\n2025 : Scale\n'
    const original = timeline(source)
    const edited = mutate(original, { kind: 'set_event_text', sectionIndex: 0, periodIndex: 0, eventIndex: 1, text: 'Revised' })
    if (!edited.ok) throw new Error(edited.error.message)
    expect(serializeMermaid(edited.value)).toBe('timeline LR %% keep header\nsection Earlier\n  2024 : Launch : Revised : Review\n% keep bridge\nsection Later\n2025 : Scale\n')
    expect(timelineMeaning(timeline(serializeMermaid(edited.value)).body)).toEqual(timelineMeaning(asTimeline(edited.value)!.body))
    const moved = mutate(original, { kind: 'move_section', from: 0, to: 1 })
    expect(moved.ok).toBe(false)
    if (!moved.ok) expect(moved.error.message).toContain('continuation')
    expect(serializeMermaid(original)).toBe(source)
  })

  test('source-aware moves and insertions preserve comments and complete chronology', () => {
    const source = 'timeline # keep header\nsection One\n2024 : A\n% owns One\n2025 : B\nsection Two\n2026 : C\n# owns Two\n'
    const original = timeline(source)
    const moved = mutate(original, { kind: 'move_period', fromSection: 0, fromIndex: 0, toSection: 1, toIndex: 1 })
    if (!moved.ok) throw new Error(moved.error.message)
    const inserted = mutate(moved.value, { kind: 'add_period', sectionIndex: 0, label: '2023', events: ['First'], index: 0 })
    if (!inserted.ok) throw new Error(inserted.error.message)
    const updated = asTimeline(inserted.value)!.body
    expect(updated.sections.map(section => section.periods.map(period => period.label))).toEqual([['2023', '2025'], ['2026', '2024']])
    const serialized = serializeMermaid(inserted.value)
    expect(serialized).toContain('timeline # keep header\n')
    expect(serialized).toContain('% owns One\n')
    expect(serialized).toContain('# owns Two\n')
    expect(timelineMeaning(timeline(serialized).body)).toEqual(timelineMeaning(updated))
    const reordered = mutate(original, { kind: 'move_section', from: 0, to: 1 })
    if (!reordered.ok) throw new Error(reordered.error.message)
    expect(serializeMermaid(reordered.value)).toBe('timeline # keep header\nsection Two\n2026 : C\n# owns Two\nsection One\n2024 : A\n% owns One\n2025 : B\n')
  })

  test.each([
    'timeline\nsection<br>A : event',
    'timeline section<br>A',
    '---\nconfig:\n  theme: forest\n---\ntimeline section<br>A : event\naccTitle: Milestones',
  ])('escaped line breaks keep a section-like prefix inside a period: %s', async source => {
    const parsed = timeline(source)
    const native = parseTimelineDiagram(normalizeMermaidSource(source).lines)
    expect(parsed.body.sections[0]!.periods[0]!.label).toBe('section\nA')
    expect(native.sections[0]!.periods[0]!.label).toBe('section\nA')
    const serialized = serializeMermaid(parsed)
    const upstream = startUpstreamMermaid()
    try { expect(await upstream.publicAccepts(serialized)).toBe(true) } finally { upstream.close() }
    expect(timeline(serialized).body).toEqual(parsed.body)
    expect(verifyMermaid(source).ok).toBe(true)
    expect(verifyMermaid(parsed).ok).toBe(true)
  })

  test.each([
    ['%% authored comment\ntimeline LR\naccTitle: History\nsection Plan\n#115;ection Phase : Launch\n: Follow up', true],
    ['timeline\ntimeline release : Launch', false],
    ['timeline\n2024 : Before\nsection Phase : Launch', true],
    ['timeline\nsection Plan\ntitle\n2026 : Next', true],
    ['timeline\nsection Plan\nsection\n2026 : Next', false],
    ['timeline\nsection Phase %%{text\n2025 : Launch', false],
    ['timeline\n2025 : %%{literal', false],
    ['timeline\ntitle History %%{text\n2025 : Launch', true],
    ['timeline\naccTitle: %%{text\n2025 : Launch', true],
    ['timeline\naccDescr: %%{text\n2025 : Launch', true],
    ['timeline\naccDescr {\n%%{text\n}\n2025 : Launch', false],
  ] as const)('Timeline text stays editable with portable output and the same native drawing: %s', async (source, accepted) => {
    const upstream = startUpstreamMermaid()
    try {
      expect(await upstream.publicAccepts(source)).toBe(accepted)
      const parsed = timeline(source)
      const written = serializeMermaid(parsed)
      expect(await upstream.publicAccepts(written), written).toBe(true)
      expect(timeline(written).body).toEqual(parsed.body)
      expect(renderMermaidSVG(parsed)).toBe(renderMermaidSVG(source))
      expect(renderMermaidASCII(parsed)).toBe(renderMermaidASCII(source))
      for (const input of [source, parsed]) {
        const verified = verifyMermaid(input)
        expect(verified.ok).toBe(true)
        expect(verified.warnings).not.toEqual(expect.arrayContaining([
          expect.objectContaining({ syntax: 'timeline_header_direction' }),
        ]))
      }
      const edit = mutate(parsed, { kind: 'set_title', title: 'Revised' })
      expect(edit.ok).toBe(true)
      if (edit.ok) expect(await upstream.publicAccepts(serializeMermaid(edit.value))).toBe(true)
    } finally { upstream.close() }
  })

  test('Timeline recognizes entities before grammar and decodes labels after grammar', () => {
    const source = 'timeline\nsection Plan\n#115;ection Phase : Launch\n: Follow up'
    const parsed = timeline(source)
    const written = serializeMermaid(parsed)
    expect(written).toContain('#115;ection Phase')
    const native = parseTimelineDiagram(normalizeMermaidSource(written).lines)
    expect(native.sections[0]).toMatchObject({ label: 'Plan', periods: [{ label: 'section Phase', events: [{ text: 'Launch' }, { text: 'Follow up' }] }] })
    expect(parseTimelineDiagram(['timeline', 's#101;ction Phase : Launch']).sections[0]!.periods[0]!.label).toBe('section Phase')
    const quoted = parseTimelineDiagram(['timeline', '"section Phase" : Launch'])
    expect(quoted.sections[0]!.periods[0]!.label).toBe('"section Phase"')
  })

  test('section tokens retain the latest period for same-line and following events', async () => {
    const upstream = startUpstreamMermaid()
    try {
      for (const label of ['Phase', ' \t']) {
        const source = `timeline\nsection Plan\n2024 : Before\nsection ${label} : Launch : Extra\n: Follow up`
        const expected = {
          sections: ['Plan', label.trim()],
          tasks: [{ label: '2024', section: 'Plan', events: ['Before', 'Launch', 'Extra', 'Follow up'] }],
        }
        expect(await upstream.project(source, diagram => ({
          sections: diagram.db.getSections().map((section: string) => section.trim()),
          tasks: diagram.db.getTasks().map((task: { task: string; section: string; events: string[] }) => ({
            label: task.task.trim(), section: task.section.trim(), events: task.events.map(event => event.trim()),
          })),
        }))).toEqual({ ok: true, value: expected })
        const native = parseTimelineDiagram(normalizeMermaidSource(source).lines)
        expect(native.sections.map(section => ({ label: section.label, periods: section.periods.map(period => ({ label: period.label, events: period.events.map(event => event.text) })) }))).toEqual([
          { label: 'Plan', periods: [{ label: '2024', events: expected.tasks[0]!.events }] },
          { label: label.trim(), periods: [] },
        ])
        const parsed = parse(source)
        expect(parsed.body.kind).toBe('timeline')
        expect(renderMermaidSVG(parsed)).toBe(renderMermaidSVG(source))
        expect(renderMermaidASCII(parsed)).toBe(renderMermaidASCII(source))
        const written = serializeMermaid(parsed)
        expect(await upstream.accepts(written)).toBe(true)
        expect<unknown>(timeline(written).body).toEqual(parsed.body)
        const edited = mutate(parsed, { kind: 'set_title', title: 'Revised' })
        if (!edited.ok) throw new Error(edited.error.message)
        expect(timelineMeaning(timeline(serializeMermaid(edited.value)).body).sections).toEqual(timelineMeaning(timeline(source).body).sections)
        expect(await upstream.accepts(serializeMermaid(edited.value))).toBe(true)
      }
    } finally { upstream.close() }
  })

  test.each(['', '2025 : After\n'])('empty section boundaries retain their periods through edits: %s', async tail => {
    const source = `timeline\n2024 : Before\nsection  \n${tail}`
    const expected = [
      { label: undefined, periods: [{ label: '2024', events: ['Before'] }] },
      { label: '', periods: tail ? [{ label: '2025', events: ['After'] }] : [] },
    ]
    const project = (body: TimelineBody) => timelineMeaning(body).sections
    const reference = startUpstreamMermaid()
    try {
      const original = timeline(source)
      expect(project(original.body)).toEqual(expected)
      const edited = mutate(original, { kind: 'set_title', title: 'History' })
      if (!edited.ok) throw new Error(edited.error.message)
      const written = serializeMermaid(edited.value, { wrapper: 'canonical' })
      expect(project(timeline(written).body)).toEqual(expected)
      expect(await reference.publicAccepts(written)).toBe(true)
      expect(await reference.project(written, diagram => ({
        sections: diagram.db.getSections().map((section: string) => section.trim()),
        tasks: diagram.db.getTasks().map((task: { task: string; section: string; events: string[] }) => ({
          label: task.task.trim(), section: task.section.trim(), events: task.events.map(event => event.trim()),
        })),
      }))).toEqual({ ok: true, value: {
        sections: [''],
        tasks: [{ label: '2024', section: '', events: ['Before'] }, ...(tail ? [{ label: '2025', section: '', events: ['After'] }] : [])],
      } })
      expect(renderMermaidSVG(written)).toBe(renderMermaidSVG(`timeline\ntitle History\n2024 : Before\nsection  \n${tail}`))
      expect(renderMermaidASCII(written)).toBe(renderMermaidASCII(`timeline\ntitle History\n2024 : Before\nsection  \n${tail}`))
      const renamed = mutate(edited.value, { kind: 'set_section_label', index: 1, label: 'Next' })
      if (!renamed.ok) throw new Error(renamed.error.message)
      const cleared = mutate(renamed.value, { kind: 'set_section_label', index: 1, label: '' })
      if (!cleared.ok) throw new Error(cleared.error.message)
      expect(project(timeline(serializeMermaid(cleared.value)).body)).toEqual(expected)
    } finally { reference.close() }
  })

  test('normalizes node-label br tags while preserving raw title text like pinned Mermaid', () => {
    const source = 'timeline\n  title <br>Product<br>history<br>\n  section <br>Platform<br>work<br>\n  2024<br>Q1 : <br>Soft<br>launch<br>\n  : Follow<br>up\n  2025<br>Q2'
    const parsed = timeline(source)
    const expected = {
      title: '<br>Product<br>history<br>',
      sections: [{
        label: '\nPlatform\nwork\n',
        periods: [
          { label: '2024\nQ1', events: ['\nSoft\nlaunch\n', 'Follow\nup'] },
          { label: '2025\nQ2', events: [] },
        ],
      }],
    }
    const project = (diagram: { title?: string; sections: { label?: string; periods: { label: string; events: { text: string }[] }[] }[] }) => ({
      title: diagram.title,
      sections: diagram.sections.map(section => ({
        label: section.label,
        periods: section.periods.map(period => ({ label: period.label, events: period.events.map(event => event.text) })),
      })),
    })
    expect(project(parsed.body)).toEqual(expected)
    expect(project(parseTimelineDiagram(normalizeMermaidSource(source).lines))).toEqual(expected)
    const canonical = serializeMermaid(parsed)
    expect(canonical).toContain('title <br>Product<br>history<br>')
    expect(canonical).toContain('section <br>Platform<br>work<br>')
    expect(canonical).toContain('2024<br>Q1 : <br>Soft<br>launch<br>')
    expect(canonical).toContain('2025<br>Q2')
    expect(project(timeline(canonical).body)).toEqual(expected)
    expect(project(parseTimelineDiagram(normalizeMermaidSource(canonical).lines))).toEqual(expected)
  })
  test('preserves literal Timeline text that generic label normalization would rewrite', () => {
    for (const raw of ['A\\nB', '"Quoted"', '**Bold**', '~~Strike~~', '<BR>Upper', '<br/>Slash', '<br />Spaced', 'A<b>Bold</b>']) {
      const source = `timeline\n  title ${raw}\n  section ${raw}\n  ${raw} : ${raw}`
      const projections = [
        timeline(source).body,
        parseTimelineDiagram(normalizeMermaidSource(source).lines),
        timeline(serializeMermaid(timeline(source))).body,
        parseTimelineDiagram(normalizeMermaidSource(serializeMermaid(timeline(source))).lines),
      ]
      for (const body of projections) {
        expect(body.title, raw).toBe(raw)
        expect(body.sections[0]!.label, raw).toBe(raw)
        expect(body.sections[0]!.periods[0]!.label, raw).toBe(raw)
        expect(body.sections[0]!.periods[0]!.events[0]!.text, raw).toBe(raw)
      }
    }
  })
  test('title + sections + periods → structured body', () => {
    const d = parse('timeline\n  title History\n  section Phase 1\n  2020 : First\n  2021 : Second\n  section Phase 2\n  2022 : Third')
    expect(d.body.kind).toBe('timeline')
    if (d.body.kind !== 'timeline') return
    expect(d.body.title).toBe('History')
    expect(d.body.sections.length).toBe(2)
    expect(d.body.sections[0]!.label).toBe('Phase 1')
    expect(d.body.sections[0]!.periods.length).toBe(2)
    expect(d.body.sections[0]!.periods[0]!.events[0]!.text).toBe('First')
    expect(d.body.sections[1]!.label).toBe('Phase 2')
  })

  test('multi-event period via colon-separated text', () => {
    const d = timeline('timeline\n  2020 : A : B : C')
    expect(d.body.sections[0]!.periods[0]!.events.map(e => e.text)).toEqual(['A', 'B', 'C'])
  })

  test('continuation line `: text` adds event to previous period', () => {
    const d = timeline('timeline\n  2020 : First\n  : Second')
    expect(d.body.sections[0]!.periods[0]!.events.map(e => e.text)).toEqual(['First', 'Second'])
  })

  test('no title, implicit section is created on first period', () => {
    const d = timeline('timeline\n  2020 : A')
    expect(d.body.title).toBeUndefined()
    expect(d.body.sections.length).toBe(1)
    expect(d.body.sections[0]!.label).toBeUndefined()
  })
})

describe('timeline fidelity fallback', () => {
  test('unmodeled syntax falls back to opaque (lossless)', () => {
    const d = parse('timeline\n  some:unsupported')
    expect(d.body.kind).toBe('opaque')
    expect(asTimeline(d)).toBeNull()
    // Round-trip preserves the unknown line.
    expect(serializeMermaid(d)).toContain('some:unsupported')
  })

  test('continuation `: text` with no prior period falls back to opaque', () => {
    const d = parse('timeline\n  : orphan continuation')
    expect(d.body.kind).toBe('opaque')
  })

  test('header suffix falls back to opaque instead of being dropped', () => {
    for (const suffix of ['EXTRA', 'TB']) {
      const source = `timeline ${suffix}\n  2020 : A`
      const d = parse(source)
      expect(d.body.kind).toBe('opaque')
      expect(serializeMermaid(d)).toBe(`${source}\n`)
      for (const input of [source, d]) {
        const verified = verifyMermaid(input)
        expect(verified.ok).toBe(false)
        expect(verified.warnings).toEqual(expect.arrayContaining([
          expect.objectContaining({ code: 'UNSUPPORTED_SYNTAX', syntax: 'timeline_header_direction' }),
          expect.objectContaining({ code: 'RENDER_FAILED' }),
        ]))
      }
    }
  })

  test('invalid or reinterpretation-prone event separators stay opaque and fail verification', () => {
    for (const source of [
      'timeline\n  2020 : A :',
      'timeline\n  2020 : A:\n  2021 : B',
      'timeline\n  2020 : A: : B',
      'timeline\n  2020 :',
    ]) {
      const parsed = parse(source)
      expect(parsed.body.kind, source).toBe('opaque')
      expect(serializeMermaid(parsed), source).toContain(source)
      const verified = verifyMermaid(parsed)
      expect(verified.ok, source).toBe(false)
      expect(verified.warnings.map(warning => warning.code), source).toContain('RENDER_FAILED')
    }
  })

  test('diagnoses the grammar-accepted final-colon-at-EOF form rather than silently canonicalizing it', () => {
    const source = 'timeline\n  2020 : A:'
    const parsed = parse(source)
    expect(parsed.body.kind).toBe('opaque')
    if (parsed.body.kind !== 'opaque') return
    expect(parsed.body.source).toBe(source)
    // Pinned Mermaid 11.16's grammar accepts this exact EOF form as event
    // "A:", but its public render API rejects it and our canonical serializer
    // appends a newline, which the grammar also rejects.
    expect(serializeMermaid(parsed)).toBe(`${source}\n`)
    const verified = verifyMermaid(parsed)
    expect(verified.ok).toBe(false)
    expect(verified.warnings.map(warning => warning.code)).toContain('RENDER_FAILED')
  })

  test('diagnoses an upstream-valid whitespace-only middle event instead of dropping it', () => {
    const source = 'timeline\n  2020 : A:  : B\n'
    // Pinned Mermaid 11.16 parses this as ["A", " ", "B"]. The local typed
    // model cannot round-trip the whitespace-only event, so it fails closed.
    const parsed = parse(source)
    expect(parsed.body.kind).toBe('opaque')
    const verified = verifyMermaid(parsed)
    expect(verified.ok).toBe(false)
    expect(verified.warnings.map(warning => warning.code)).toContain('RENDER_FAILED')
  })

  test('colon-ending events retain independent event ownership', () => {
    for (const { source, events } of [
      { source: 'timeline\n  2020 : A:: B\n  2021 : C', events: ['A:', 'B'] },
      { source: 'timeline\n  2020 : A:: B:: C', events: ['A:', 'B:', 'C'] },
      { source: 'timeline\n  2020 : A :: B', events: ['A :', 'B'] },
    ]) {
      const parsed = timeline(source)
      expect(parsed.body.sections[0]!.periods[0]!.events.map(event => event.text)).toEqual(events)
      const canonical = serializeMermaid(parsed)
      expect(timeline(canonical).body.sections[0]!.periods[0]!.events.map(event => event.text)).toEqual(events)
      expect(parseTimelineDiagram(normalizeMermaidSource(canonical).lines).sections[0]!.periods[0]!.events.map(event => event.text)).toEqual(events)
      expect(verifyMermaid(timeline(canonical)).ok).toBe(true)
    }
  })
})

describe('timeline mutate — all 10 ops', () => {
  const SRC = 'timeline\n  title H\n  section P1\n  2020 : A\n  2021 : B\n  section P2\n  2022 : C'

  test('set_title', () => {
    const r = mutate(timeline(SRC), { kind: 'set_title', title: 'New' })
    expect(r.ok && r.value.body.title).toBe('New')
  })
  test('set_title to null clears it', () => {
    const r = mutate(timeline(SRC), { kind: 'set_title', title: null })
    expect(r.ok && r.value.body.title).toBeUndefined()
  })
  test('add_section', () => {
    const r = mutate(timeline(SRC), { kind: 'add_section', label: 'P3' })
    expect(r.ok && r.value.body.sections.length).toBe(3)
    expect(r.ok && r.value.body.sections[2]!.label).toBe('P3')
  })
  test('remove_section', () => {
    const r = mutate(timeline(SRC), { kind: 'remove_section', index: 0 })
    expect(r.ok && r.value.body.sections.length).toBe(1)
    expect(r.ok && r.value.body.sections[0]!.label).toBe('P2')
  })
  test('remove_section missing → SECTION_NOT_FOUND', () => {
    const r = mutate(timeline(SRC), { kind: 'remove_section', index: 99 })
    expect(!r.ok && r.error.code).toBe('SECTION_NOT_FOUND')
  })
  test('set_section_label', () => {
    const r = mutate(timeline(SRC), { kind: 'set_section_label', index: 0, label: 'Updated' })
    expect(r.ok && r.value.body.sections[0]!.label).toBe('Updated')
  })
  test('add_period with events', () => {
    const r = mutate(timeline(SRC), { kind: 'add_period', sectionIndex: 0, label: '2019', events: ['Zero', 'Half'] })
    expect(r.ok && r.value.body.sections[0]!.periods.length).toBe(3)
    expect(r.ok && r.value.body.sections[0]!.periods[2]!.events.length).toBe(2)
    expect(r.ok && new Set(r.value.body.sections[0]!.periods[2]!.events.map(e => e.id)).size).toBe(2)
  })
  test('remove_period', () => {
    const r = mutate(timeline(SRC), { kind: 'remove_period', sectionIndex: 0, periodIndex: 0 })
    expect(r.ok && r.value.body.sections[0]!.periods.length).toBe(1)
    expect(r.ok && r.value.body.sections[0]!.periods[0]!.label).toBe('2021')
  })
  test('remove_period missing → PERIOD_NOT_FOUND', () => {
    const r = mutate(timeline(SRC), { kind: 'remove_period', sectionIndex: 0, periodIndex: 99 })
    expect(!r.ok && r.error.code).toBe('PERIOD_NOT_FOUND')
  })
  test('set_period_label', () => {
    const r = mutate(timeline(SRC), { kind: 'set_period_label', sectionIndex: 0, periodIndex: 0, label: '2020-revised' })
    expect(r.ok && r.value.body.sections[0]!.periods[0]!.label).toBe('2020-revised')
  })
  test('add_event', () => {
    const r = mutate(timeline(SRC), { kind: 'add_event', sectionIndex: 0, periodIndex: 0, text: 'A-extra' })
    expect(r.ok && r.value.body.sections[0]!.periods[0]!.events.length).toBe(2)
  })
  test('remove_event', () => {
    const r = mutate(timeline(SRC), { kind: 'remove_event', sectionIndex: 0, periodIndex: 0, eventIndex: 0 })
    expect(r.ok && r.value.body.sections[0]!.periods[0]!.events.length).toBe(0)
  })
  test('set_event_text', () => {
    const r = mutate(timeline(SRC), { kind: 'set_event_text', sectionIndex: 0, periodIndex: 0, eventIndex: 0, text: 'A-revised' })
    expect(r.ok && r.value.body.sections[0]!.periods[0]!.events[0]!.text).toBe('A-revised')
  })

  test('event mutations preserve clock and URL colons accepted by both parsers', () => {
    const text = 'Standup at 10:30 https://example.test/a:b'
    const base = [
      { label: 'P1', periods: [{ label: '2020', events: ['A'] }, { label: '2021', events: ['B'] }] },
      { label: 'P2', periods: [{ label: '2022', events: ['C'] }] },
    ]
    const cases: { op: TimelineMutationOp; expected: typeof base }[] = [
      {
        op: { kind: 'set_event_text', sectionIndex: 0, periodIndex: 0, eventIndex: 0, text },
        expected: [
          { label: 'P1', periods: [{ label: '2020', events: [text] }, { label: '2021', events: ['B'] }] },
          base[1]!,
        ],
      },
      {
        op: { kind: 'add_event', sectionIndex: 0, periodIndex: 0, text },
        expected: [
          { label: 'P1', periods: [{ label: '2020', events: ['A', text] }, { label: '2021', events: ['B'] }] },
          base[1]!,
        ],
      },
      {
        op: { kind: 'add_period', sectionIndex: 0, label: '2023', events: [text] },
        expected: [
          { label: 'P1', periods: [...base[0]!.periods, { label: '2023', events: [text] }] },
          base[1]!,
        ],
      },
    ]
    const project = (sections: { label?: string; periods: { label: string; events: { text: string }[] }[] }[]) =>
      sections.map(section => ({
        label: section.label,
        periods: section.periods.map(period => ({ label: period.label, events: period.events.map(event => event.text) })),
      }))
    for (const { op, expected } of cases) {
      const result = mutate(timeline(SRC), op)
      expect(result.ok, op.kind).toBe(true)
      if (!result.ok) continue
      expect(project(result.value.body.sections), `${op.kind} typed mutation`).toEqual(expected)
      const source = serializeMermaid(result.value)
      const reparsed = parse(source)
      expect(reparsed.body.kind, op.kind).toBe('timeline')
      if (reparsed.body.kind !== 'timeline') continue
      expect(project(reparsed.body.sections), `${op.kind} agent reparse`).toEqual(expected)
      const native = parseTimelineDiagram(normalizeMermaidSource(source).lines)
      expect(project(native.sections), `${op.kind} native reparse`).toEqual(expected)
    }
  })

  test('event mutation serializes semantic line breaks as br tags', () => {
    const result = mutate(timeline(SRC), {
      kind: 'set_event_text', sectionIndex: 0, periodIndex: 0, eventIndex: 0, text: 'Soft\r\nlaunch',
    })
    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.value.body.sections[0]!.periods[0]!.events[0]!.text).toBe('Soft\nlaunch')
    const source = serializeMermaid(result.value)
    expect(source).toContain('2020 : Soft<br>launch')
    expect(timeline(source).body.sections[0]!.periods[0]!.events[0]!.text).toBe('Soft\nlaunch')
    expect(parseTimelineDiagram(normalizeMermaidSource(source).lines).sections[0]!.periods[0]!.events[0]!.text).toBe('Soft\nlaunch')
  })

  test('Timeline node-text mutation paths round-trip semantic line breaks', () => {
    type TextBody = { title?: string; sections: { label?: string; periods: { label: string; events: { text: string }[] }[] }[] }
    const text = 'Soft\nlaunch'
    const cases: { op: TimelineMutationOp; canonical: string; read: (body: TextBody) => unknown; expected: unknown }[] = [
      { op: { kind: 'set_section_label', index: 0, label: text }, canonical: 'section Soft<br>launch', read: body => body.sections[0]!.label, expected: text },
      { op: { kind: 'add_section', label: text }, canonical: 'section Soft<br>launch', read: body => body.sections[2]!.label, expected: text },
      { op: { kind: 'set_period_label', sectionIndex: 0, periodIndex: 0, label: text }, canonical: 'Soft<br>launch : A', read: body => body.sections[0]!.periods[0]!.label, expected: text },
      { op: { kind: 'add_event', sectionIndex: 0, periodIndex: 0, text }, canonical: ': Soft<br>launch', read: body => body.sections[0]!.periods[0]!.events[1]!.text, expected: text },
      {
        op: { kind: 'add_period', sectionIndex: 0, label: text, events: ['Next\rstep'] },
        canonical: 'Soft<br>launch : Next<br>step',
        read: body => [body.sections[0]!.periods[2]!.label, body.sections[0]!.periods[2]!.events[0]!.text],
        expected: [text, 'Next\nstep'],
      },
    ]
    for (const { op, canonical, read, expected } of cases) {
      const result = mutate(timeline(SRC), op)
      expect(result.ok, op.kind).toBe(true)
      if (!result.ok) continue
      const source = serializeMermaid(result.value)
      expect(source, op.kind).toContain(canonical)
      expect(read(result.value.body), `${op.kind} mutation`).toEqual(expected)
      expect(read(timeline(source).body), `${op.kind} agent reparse`).toEqual(expected)
      expect(read(parseTimelineDiagram(normalizeMermaidSource(source).lines)), `${op.kind} native reparse`).toEqual(expected)
    }
  })

  test('title mutation preserves literal <br> and rejects semantic newlines that upstream cannot draw', () => {
    const literal = mutate(timeline(SRC), { kind: 'set_title', title: 'Soft<br>launch' })
    expect(literal.ok).toBe(true)
    if (literal.ok) {
      const source = serializeMermaid(literal.value)
      expect(source).toContain('title Soft<br>launch')
      expect(timeline(source).body.title).toBe('Soft<br>launch')
      expect(parseTimelineDiagram(normalizeMermaidSource(source).lines).title).toBe('Soft<br>launch')
    }
    for (const title of ['Soft\nlaunch', 'Soft\r\nlaunch', 'Soft\rlaunch', '\nSoft', 'Soft\n', '\rSoft', 'Soft\r', ' \n Soft ', 'Soft\u2028launch', 'Soft\u2029launch']) {
      const result = mutate(timeline(SRC), { kind: 'set_title', title })
      expect(result.ok, title).toBe(false)
      if (!result.ok) expect(result.error.code).toBe('INVALID_OP')
    }
  })

  test('normalizes padded mutation text and updates canonicalSource', () => {
    const r = mutate(timeline(SRC), { kind: 'set_event_text', sectionIndex: 0, periodIndex: 0, eventIndex: 0, text: '  A revised  ' })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    expect(r.value.body.sections[0]!.periods[0]!.events[0]!.text).toBe('A revised')
    expect(r.value.canonicalSource).toContain('2020 : A revised')
    const reparsed = parse(serializeMermaid(r.value))
    expect(reparsed.body.kind).toBe('timeline')
    if (reparsed.body.kind !== 'timeline') return
    expect(reparsed.body.sections[0]!.periods[0]!.events[0]!.text).toBe('A revised')
  })

  test('separator-looking mutation text remains a single field', () => {
    const event = mutate(timeline(SRC), { kind: 'set_event_text', sectionIndex: 0, periodIndex: 0, eventIndex: 0, text: 'A: B' })
    const tabSeparator = mutate(timeline(SRC), { kind: 'add_event', sectionIndex: 0, periodIndex: 0, text: 'A:\tB' })
    // Pinned Mermaid 11.16.0 treats the newline after a trailing colon as a
    // separator; with the next period present it can swallow that period.
    const trailingColonOps: TimelineMutationOp[] = [
      { kind: 'set_event_text', sectionIndex: 0, periodIndex: 0, eventIndex: 0, text: 'A:' },
      { kind: 'add_event', sectionIndex: 0, periodIndex: 0, text: 'A:b:' },
      { kind: 'add_period', sectionIndex: 0, label: '2023', events: ['A::'] },
    ]
    const period = mutate(timeline(SRC), { kind: 'set_period_label', sectionIndex: 0, periodIndex: 0, label: '2020:Q1' })
    const title = mutate(timeline(SRC), { kind: 'set_title', title: '   ' })
    for (const result of [event, tabSeparator]) {
      expect(result.ok).toBe(true)
      if (result.ok) expect(timelineMeaning(timeline(serializeMermaid(result.value)).body)).toEqual(timelineMeaning(result.value.body))
    }
    for (const op of trailingColonOps) {
      const result = mutate(timeline(SRC), op)
      expect(result.ok, op.kind).toBe(true)
      if (result.ok) expect(timelineMeaning(timeline(serializeMermaid(result.value)).body)).toEqual(timelineMeaning(result.value.body))
    }
    expect(period.ok).toBe(true)
    if (period.ok) expect(timeline(serializeMermaid(period.value)).body.sections[0]!.periods[0]!.label).toBe('2020:Q1')
    expect(!title.ok && title.error.code).toBe('INVALID_OP')
  })


  test('new Timeline text cannot become a directive, comment, or section/event separator', async () => {
    const original = timeline('timeline\nsection Plan\n2025 : Launch')
    const before = serializeMermaid(original)
    const ops: TimelineMutationOp[] = [
      ...['section Phase', 'timeline', 'TIMELINE!', 'title', 'title Launch', 'accTitle', 'accDescr', 'accDescr detail', '#comment', '%comment', 'A#B', '%%{text'].flatMap(label => [
        { kind: 'set_period_label' as const, sectionIndex: 0, periodIndex: 0, label },
        { kind: 'add_period' as const, sectionIndex: 0, label, events: ['New event'] },
      ]),
      ...['Phase: next', 'Phase:next', 'Phase %%{text'].flatMap(label => [
        { kind: 'set_section_label' as const, index: 0, label },
        { kind: 'add_section' as const, label },
      ]),
      { kind: 'set_event_text', sectionIndex: 0, periodIndex: 0, eventIndex: 0, text: '%%{event' },
      { kind: 'add_event', sectionIndex: 0, periodIndex: 0, text: '%%{event' },
      { kind: 'add_period', sectionIndex: 0, label: '2026', events: ['%%{event'] },
      { kind: 'set_title', title: 'History %%{text' },
    ]
    for (const op of ops) {
      const result = mutate(original, op)
      expect(result.ok, JSON.stringify(op)).toBe(true)
      if (result.ok) expect(timelineMeaning(timeline(serializeMermaid(result.value)).body)).toEqual(timelineMeaning(result.value.body))
      expect(serializeMermaid(original)).toBe(before)
    }
  })

  test('direct Timeline payloads use the same field writers as mutations', () => {
    const body = { kind: 'timeline' as const, ...parseTimelineDiagram(['timeline', '#115;ection Phase : Launch']) }
    expect(timeline(renderTimeline(body)).body).toEqual(body)
    const result = mutateTimeline(body, { kind: 'remove_event', sectionIndex: 0, periodIndex: 0, eventIndex: 0 })
    expect(result.ok).toBe(true)
    if (result.ok) expect(timeline(renderTimeline(result.value)).body).toEqual(result.value)
  })

  test('a bare title or section period cannot consume an inserted following statement', async () => {
    const upstream = startUpstreamMermaid()
    try {
      for (const label of ['title', 'section']) {
        const source = `timeline\nsection Plan\n${label}\n`
        const original = timeline(source)
        expect(original.body.sections[0]!.periods[0]).toMatchObject({ label, events: [] })
        const exported = serializeMermaid(original)
        expect(await upstream.publicAccepts(exported)).toBe(true)
        const actual = await upstream.project(exported, diagram => diagram.db.getTasks().map((task: { task: string; events: string[] }) => ({ label: task.task.trim().replace(/ﬂ°°(\d+)¶ß/g, (_: string, code: string) => String.fromCodePoint(Number(code))), events: task.events })))
        expect(actual).toEqual({ ok: true, value: [{ label, events: [] }] })
        const result = mutate(original, { kind: 'add_period', sectionIndex: 0, label: '2026', events: ['Next'] })
        expect(result.ok).toBe(true)
        if (result.ok) expect(timelineMeaning(timeline(serializeMermaid(result.value)).body)).toEqual(timelineMeaning(result.value.body))
      }
      const result = mutate(timeline('timeline\nsection Plan\nsection : Launch\n2026 : Next'), { kind: 'remove_event', sectionIndex: 0, periodIndex: 0, eventIndex: 0 })
      expect(result.ok).toBe(true)
      if (result.ok) expect(timelineMeaning(timeline(serializeMermaid(result.value)).body)).toEqual(timelineMeaning(result.value.body))
    } finally { upstream.close() }
  })

  test('neighboring Timeline words remain editable with exact text through both readers', async () => {
    const upstream = startUpstreamMermaid()
    try {
      for (const label of ['timelines', 'timelineX', 'titles', 'section', 'sections', 'section!', 'accTitleX', 'LR', 'A;B', '%{literal']) {
        const result = mutate(timeline('timeline\nsection Plan\n2025 : Launch'), { kind: 'set_period_label', sectionIndex: 0, periodIndex: 0, label })
        expect(result.ok, label).toBe(true)
        if (!result.ok) continue
        const source = serializeMermaid(result.value)
        expect(await upstream.publicAccepts(source), source).toBe(true)
        expect(timeline(source).body).toEqual(result.value.body)
        expect(parseTimelineDiagram(normalizeMermaidSource(source).lines).sections[0]!.periods[0]).toMatchObject({ label, events: [{ text: 'Launch' }] })
      }
    } finally { upstream.close() }
  })

  test('removing last period from an implicit section drops the unrenderable empty section', () => {
    const r = mutate(timeline('timeline\n  2020 : A'), { kind: 'remove_period', sectionIndex: 0, periodIndex: 0 })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    expect(r.value.body.sections).toEqual([])
    expect(parse(serializeMermaid(r.value)).body.kind).toBe('timeline')
  })
})

describe('timeline round-trip stability', () => {
  const corpus = [
    'timeline\n  2020 : A',
    'timeline\n  title History\n  2020 : A',
    'timeline\n  section Phase 1\n  2020 : A\n  2021 : B',
    'timeline\n  title H\n  section P1\n  2020 : A\n  section P2\n  2021 : B',
    'timeline\n  2020 : A : B : C',
    'timeline\n  2020 : A\n  : Continued',
  ]
  for (const src of corpus) {
    test(`stable: ${src.slice(0, 40).replace(/\n/g, ' / ')}…`, () => {
      const d = parse(src); const s1 = serializeMermaid(d)
      const d2 = parse(s1); expect(serializeMermaid(d2)).toBe(s1)
    })
  }

  test('mutation chain → verify → serialize round-trip', () => {
    const t = timeline('timeline\n  title H\n  2020 : A')
    const r1 = mutate(t, { kind: 'add_section', label: 'New' })
    if (!r1.ok) throw new Error('m1')
    const r2 = mutate(r1.value, { kind: 'add_period', sectionIndex: 1, label: '2024', events: ['X', 'Y'] })
    if (!r2.ok) throw new Error('m2')
    const v = verifyMermaid(r2.value)
    expect(v.ok).toBe(true)
    const s = serializeMermaid(r2.value)
    expect(parseMermaid(s).ok).toBe(true)
  })
})

describe('timeline verify', () => {
  test('clean timeline ok', () => {
    expect(verifyMermaid('timeline\n  2020 : A').ok).toBe(true)
  })
  test('header-only → EMPTY_DIAGRAM', () => {
    const r = verifyMermaid('timeline')
    expect(r.ok).toBe(false)
    expect(r.warnings.some(w => w.code === 'EMPTY_DIAGRAM')).toBe(true)
  })
  test('LABEL_OVERFLOW on long event text', () => {
    const r = verifyMermaid(`timeline\n  2020 : ${'x'.repeat(60)}`)
    expect(r.warnings.some(w => w.code === 'LABEL_OVERFLOW')).toBe(true)
  })
  test('section-only timeline is renderable header furniture, not EMPTY_DIAGRAM (upstream parity)', () => {
    const r = verifyMermaid('timeline\n  section Phase 1')
    expect(r.warnings.filter(w => w.code === 'EMPTY_DIAGRAM')).toEqual([])
    expect(r.ok).toBe(true)
  })
})

describe('timeline direction (upstream `timeline TD` contract)', () => {
  test('`timeline TD` parses structured with direction TD and round-trips', () => {
    const d = parse('timeline TD\n  2020 : A')
    expect(d.body.kind).toBe('timeline')
    if (d.body.kind !== 'timeline') return
    expect(d.body.direction).toBe('TD')
    const s1 = serializeMermaid(d)
    expect(s1.startsWith('timeline TD\n')).toBe(true)
    expect(serializeMermaid(parse(s1))).toBe(s1)
  })
  test('`timeline LR` parses structured with explicit LR preserved', () => {
    const d = parse('timeline LR\n  2020 : A')
    expect(d.body.kind).toBe('timeline')
    if (d.body.kind !== 'timeline') return
    expect(d.body.direction).toBe('LR')
    expect(serializeMermaid(d).startsWith('timeline LR\n')).toBe(true)
  })
  test('bare header keeps direction unset and serializes bare', () => {
    const d = timeline('timeline\n  2020 : A')
    expect(d.body.direction).toBeUndefined()
    expect(serializeMermaid(d).startsWith('timeline\n')).toBe(true)
  })
  test('non-direction header suffix still falls back to opaque', () => {
    expect(parse('timeline EXTRA\n  2020 : A').body.kind).toBe('opaque')
    expect(parse('timeline TB\n  2020 : A').body.kind).toBe('opaque')
  })
})

describe('timeline accessibility metadata (accTitle/accDescr)', () => {
  test('accTitle/accDescr lines parse structured (no phantom period) and round-trip', () => {
    const d = parse('timeline\n  accTitle: Accessible roadmap\n  accDescr: Launch milestones\n  2020 : A')
    expect(d.body.kind).toBe('timeline')
    if (d.body.kind !== 'timeline') return
    expect(d.body.accessibilityTitle).toBe('Accessible roadmap')
    expect(d.body.accessibilityDescription).toBe('Launch milestones')
    expect(d.body.sections.flatMap(s => s.periods.map(p => p.label))).toEqual(['2020'])
    const s1 = serializeMermaid(d)
    expect(s1).toContain('accTitle: Accessible roadmap')
    expect(s1).toContain('accDescr: Launch milestones')
    expect(serializeMermaid(parse(s1))).toBe(s1)
  })
  test('accDescr block form parses structured, keeps newlines, and round-trips', () => {
    const d = parse('timeline\n  accDescr {\n    First line\n    Second line\n  }\n  2020 : A')
    expect(d.body.kind).toBe('timeline')
    if (d.body.kind !== 'timeline') return
    expect(d.body.accessibilityDescription).toBe('First line\nSecond line')
    const s1 = serializeMermaid(d)
    expect(s1).toContain('accDescr {')
    expect(serializeMermaid(parse(s1))).toBe(s1)
  })
  test('set_accessibility_title / set_accessibility_description ops set and clear', () => {
    const t = timeline('timeline\n  2020 : A')
    const r1 = mutate(t, { kind: 'set_accessibility_title', title: 'Spoken title' })
    expect(r1.ok && r1.value.body.accessibilityTitle).toBe('Spoken title')
    if (!r1.ok) return
    expect(r1.value.canonicalSource).toContain('accTitle: Spoken title')
    const r2 = mutate(r1.value, { kind: 'set_accessibility_description', description: 'Spoken description' })
    expect(r2.ok && r2.value.body.accessibilityDescription).toBe('Spoken description')
    if (!r2.ok) return
    const cleared = mutate(r2.value, { kind: 'set_accessibility_title', title: null })
    expect(cleared.ok && cleared.value.body.accessibilityTitle).toBeUndefined()
  })
  test('a11y text cannot terminate its own description block', () => {
    const t = timeline('timeline\n  2020 : A')
    const edited = mutate(t, { kind: 'set_accessibility_description', description: 'has } brace\nand { another; %%{text' })
    expect(edited.ok).toBe(true)
    if (edited.ok) expect(timeline(serializeMermaid(edited.value)).body.accessibilityDescription).toBe('has } brace\nand { another; %%{text')
  })
})

describe('timeline ops parity with the journey convention (move/insert)', () => {
  const SRC = 'timeline\n  title H\n  section P1\n  2020 : A\n  2021 : B\n  section P2\n  2022 : C'

  test('add_section with insert index', () => {
    const r = mutate(timeline(SRC), { kind: 'add_section', label: 'P0', index: 0 })
    expect(r.ok && r.value.body.sections.map(s => s.label)).toEqual(['P0', 'P1', 'P2'])
  })
  test('add_section index out of range names the valid range', () => {
    const r = mutate(timeline(SRC), { kind: 'add_section', label: 'X', index: 9 })
    expect(!r.ok && r.error.code).toBe('INVALID_OP')
    if (r.ok) return
    expect(r.error.message).toContain('(0..2)')
  })
  test('add_period with insert index', () => {
    const r = mutate(timeline(SRC), { kind: 'add_period', sectionIndex: 0, label: '2019', events: ['Zero'], index: 0 })
    expect(r.ok && r.value.body.sections[0]!.periods.map(p => p.label)).toEqual(['2019', '2020', '2021'])
  })
  test('add_event with insert index', () => {
    const r = mutate(timeline(SRC), { kind: 'add_event', sectionIndex: 0, periodIndex: 0, text: 'A0', index: 0 })
    expect(r.ok && r.value.body.sections[0]!.periods[0]!.events.map(e => e.text)).toEqual(['A0', 'A'])
  })
  test('move_period across sections', () => {
    const r = mutate(timeline(SRC), { kind: 'move_period', fromSection: 0, fromIndex: 0, toSection: 1, toIndex: 1 })
    expect(r.ok && r.value.body.sections[0]!.periods.map(p => p.label)).toEqual(['2021'])
    expect(r.ok && r.value.body.sections[1]!.periods.map(p => p.label)).toEqual(['2022', '2020'])
  })
  test('move_period bad insert position names the valid range', () => {
    const r = mutate(timeline(SRC), { kind: 'move_period', fromSection: 0, fromIndex: 0, toSection: 1, toIndex: 5 })
    expect(!r.ok && r.error.code).toBe('PERIOD_NOT_FOUND')
    if (r.ok) return
    expect(r.error.message).toContain('(0..1)')
  })
  test('move_period out of an implicit section drops the emptied section', () => {
    const src = 'timeline\n  2020 : A\n  section P1\n  2021 : B'
    const r = mutate(timeline(src), { kind: 'move_period', fromSection: 0, fromIndex: 0, toSection: 1, toIndex: 1 })
    expect(r.ok && r.value.body.sections.length).toBe(1)
    expect(r.ok && r.value.body.sections[0]!.periods.map(p => p.label)).toEqual(['2021', '2020'])
  })
  test('move_event across periods', () => {
    const src = 'timeline\n  2020 : A : B\n  2021 : C'
    const r = mutate(timeline(src), { kind: 'move_event', fromSection: 0, fromPeriod: 0, fromIndex: 1, toSection: 0, toPeriod: 1, toIndex: 0 })
    expect(r.ok && r.value.body.sections[0]!.periods[0]!.events.map(e => e.text)).toEqual(['A'])
    expect(r.ok && r.value.body.sections[0]!.periods[1]!.events.map(e => e.text)).toEqual(['B', 'C'])
  })
  test('move_event bad insert position names the valid range', () => {
    const src = 'timeline\n  2020 : A : B\n  2021 : C'
    const r = mutate(timeline(src), { kind: 'move_event', fromSection: 0, fromPeriod: 0, fromIndex: 0, toSection: 0, toPeriod: 1, toIndex: 7 })
    expect(!r.ok && r.error.code).toBe('EVENT_NOT_FOUND')
    if (r.ok) return
    expect(r.error.message).toContain('(0..1)')
  })
  test('move_section reorders named sections while preserving period ownership', () => {
    const cases = [
      {
        source: SRC, from: 1, to: 0,
        expected: [
          { label: 'P2', periods: [{ label: '2022', events: ['C'] }] },
          { label: 'P1', periods: [{ label: '2020', events: ['A'] }, { label: '2021', events: ['B'] }] },
        ],
      },
      {
        source: 'timeline\n  2019 : Intro\n  section P1\n  2020 : A\n  section P2\n  2021 : B', from: 2, to: 1,
        expected: [
          { label: undefined, periods: [{ label: '2019', events: ['Intro'] }] },
          { label: 'P2', periods: [{ label: '2021', events: ['B'] }] },
          { label: 'P1', periods: [{ label: '2020', events: ['A'] }] },
        ],
      },
    ]
    for (const { source, from, to, expected } of cases) {
      const result = mutate(timeline(source), { kind: 'move_section', from, to })
      expect(result.ok).toBe(true)
      if (!result.ok) continue
      expect(timelineMeaning(result.value.body).sections).toEqual(expected)
      const written = serializeMermaid(result.value)
      expect(timelineMeaning(timeline(written).body).sections).toEqual(expected)
      expect(timelineMeaning({ kind: 'timeline', ...parseTimelineDiagram(normalizeMermaidSource(written).lines) }).sections).toEqual(expected)
    }
  })
  test.each<TimelineMutationOp>([
    { kind: 'move_section', from: 0, to: 1 },
    { kind: 'move_section', from: 1, to: 0 },
    { kind: 'add_section', label: 'Before', index: 0 },
  ])('rejects section ordering that would reparent unnamed periods: %j', op => {
    const input = timeline('timeline\n  2019 : Intro\n  section Named\n  2020 : Milestone')
    const before = structuredClone(input.body)
    const result = mutate(input, op)
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.error.code).toBe('INVALID_OP')
      expect(result.error.message).toContain('unnamed section must remain first')
    }
    expect(input.body).toEqual(before)
    expect(timelineMeaning(input.body).sections).toEqual([
      { label: undefined, periods: [{ label: '2019', events: ['Intro'] }] },
      { label: 'Named', periods: [{ label: '2020', events: ['Milestone'] }] },
    ])
  })
  test('move_section bad target names the valid range', () => {
    const r = mutate(timeline(SRC), { kind: 'move_section', from: 0, to: 4 })
    expect(!r.ok && r.error.code).toBe('SECTION_NOT_FOUND')
    if (r.ok) return
    expect(r.error.message).toContain('(0..1)')
  })
  test('not-found errors name the valid index range', () => {
    const r = mutate(timeline(SRC), { kind: 'remove_period', sectionIndex: 0, periodIndex: 99 })
    expect(!r.ok && r.error.code).toBe('PERIOD_NOT_FOUND')
    if (r.ok) return
    expect(r.error.message).toContain('(valid: 0..1)')
  })
  test('mutation chain with new ops stays round-trip stable', () => {
    const t = timeline(SRC)
    const ops: TimelineMutationOp[] = [
      { kind: 'add_period', sectionIndex: 1, label: '2023', events: ['D'], index: 0 },
      { kind: 'move_period', fromSection: 1, fromIndex: 0, toSection: 0, toIndex: 2 },
      { kind: 'move_section', from: 0, to: 1 },
      { kind: 'set_accessibility_title', title: 'Roadmap' },
    ]
    let cur = t
    for (const op of ops) {
      const r = mutate(cur, op)
      if (!r.ok) throw new Error(JSON.stringify(r.error))
      cur = r.value
    }
    const s1 = serializeMermaid(cur)
    expect(serializeMermaid(parse(s1))).toBe(s1)
    expect(verifyMermaid(cur).ok).toBe(true)
  })
})

describe('timeline differential vs renderer-grade parser', () => {
  test('the canonical source the body serializer emits re-parses identically under parseTimelineDiagram', () => {
    const built = buildMermaid('timeline', [
      { kind: 'set_title', title: 'Release history' },
      { kind: 'set_accessibility_title', title: 'Spoken title' },
      { kind: 'set_accessibility_description', description: 'Spoken description' },
      { kind: 'add_section', label: 'Phase 1' },
      { kind: 'add_period', sectionIndex: 0, label: '2020', events: ['Alpha', 'Beta'] },
      { kind: 'add_period', sectionIndex: 0, label: '2021', events: ['GA'] },
      { kind: 'add_section', label: 'Phase 2' },
      { kind: 'add_period', sectionIndex: 1, label: '2022', events: ['Scale-out'] },
      { kind: 'add_event', sectionIndex: 1, periodIndex: 0, text: 'Hardening', index: 0 },
    ])
    if (!built.ok) throw new Error(JSON.stringify(built.error))
    const d = built.value
    const out = serializeMermaid(d)
    const model = parseTimelineDiagram(normalizeMermaidSource(out).lines)
    expect(model.title).toBe(d.body.title)
    expect(model.accessibilityTitle).toBe(d.body.accessibilityTitle)
    expect(model.accessibilityDescription).toBe(d.body.accessibilityDescription)
    expect(model.sections.map(s => s.label)).toEqual(d.body.sections.map(s => s.label))
    expect(model.sections.map(s => s.periods.map(p => p.label)))
      .toEqual(d.body.sections.map(s => s.periods.map(p => p.label)))
    expect(model.sections.map(s => s.periods.map(p => p.events.map(e => e.text))))
      .toEqual(d.body.sections.map(s => s.periods.map(p => p.events.map(e => e.text))))
  })

  test('direction survives the body → renderer seam', () => {
    const d = parse('timeline TD\n  2020 : A')
    if (d.body.kind !== 'timeline') throw new Error('expected structured timeline')
    const model = parseTimelineDiagram(normalizeMermaidSource(serializeMermaid(d)).lines)
    expect(model.direction).toBe('TD')
  })

  test('clock times containing a colon stay one event on both parser surfaces', () => {
    const source = 'timeline\n  2020 : Standup at 10:30 daily'
    const d = parse(source)
    expect(d.body.kind).toBe('timeline')
    if (d.body.kind !== 'timeline') return
    expect(d.body.sections[0]!.periods[0]!.events.map(event => event.text))
      .toEqual(['Standup at 10:30 daily'])

    const model = parseTimelineDiagram(normalizeMermaidSource(source).lines)
    expect(model.sections[0]!.periods[0]!.events.map(event => event.text))
      .toEqual(['Standup at 10:30 daily'])
  })

  test('event-less periods serialize to the bare form accepted by both parser surfaces', () => {
    const d = parse('timeline\n  2020')
    expect(d.body.kind).toBe('timeline')
    if (d.body.kind !== 'timeline') return
    expect(d.body.sections[0]!.periods[0]!.events).toEqual([])

    const canonical = serializeMermaid(d)
    expect(canonical).toBe('timeline\n  2020\n')
    const model = parseTimelineDiagram(normalizeMermaidSource(canonical).lines)
    expect(model.sections[0]!.periods[0]!.label).toBe('2020')
    expect(model.sections[0]!.periods[0]!.events).toEqual([])
  })
})

describe('timeline INEFFECTIVE_CONFIG lint (wire-or-warn)', () => {
  const withConfig = (fields: string) => `---
config:
  timeline:
${fields}
---
timeline
  2020 : A`

  test('documented-but-unwired timeline config keys are named', () => {
    const r = verifyMermaid(withConfig('    noteMargin: 4\n    rightAngles: true'))
    const fields = r.warnings.filter(w => w.code === 'INEFFECTIVE_CONFIG').map(w => (w as { field?: string }).field)
    expect(fields).toEqual(['timeline.noteMargin', 'timeline.rightAngles'])
    expect(r.ok).toBe(true) // lint only — never flips verify
  })

  test('wired keys (disableMulticolor/sectionFills/sectionColours) never warn', () => {
    const r = verifyMermaid(withConfig('    disableMulticolor: true'))
    expect(r.warnings.filter(w => w.code === 'INEFFECTIVE_CONFIG')).toEqual([])
  })
})
