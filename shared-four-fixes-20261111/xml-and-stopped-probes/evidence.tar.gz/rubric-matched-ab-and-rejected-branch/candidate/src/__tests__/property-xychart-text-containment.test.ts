// Every piece of chart text must land on the canvas. The check measures the
// real rasterizer's glyph boxes (resvg, with the bundled fonts) rather than the
// layout's own width estimates, so it cannot agree with a wrong estimate.
// Before value-axis overhang was reserved, an untitled vertical chart drew its
// top tick label above y = 0 and a horizontal chart drew its rightmost value
// label past the right edge; before bars clamped their value end, a value
// beyond an authored range drew its bar off the canvas. The x-axis title's
// baseline sat on the bottom edge, and in short horizontal charts the last
// category label's descenders crossed it.
import { describe, expect, it } from 'bun:test'
import fc from 'fast-check'
import { fcParameters } from './helpers/fc-parameters.ts'
import { Resvg } from '@resvg/resvg-js'
import { join } from 'node:path'

import { renderMermaidSVG } from '../index.ts'

const FONT_DIR = join(import.meta.dir, '..', '..', 'assets', 'fonts')
// Rasterizer antialiasing and the 0.01 px coordinate grid.
const TOLERANCE = 0.75

/** The SVG with every non-text mark removed, so the bounding box is text only. */
function textOnly(svg: string): string {
  return svg.replace(/<(rect|line|path|circle|polyline|polygon|ellipse)\b[^>]*?(?:\/>|>[\s\S]*?<\/\1>)/g, '')
}

const nameArb = fc.stringMatching(/^[A-Za-z][A-Za-z0-9 ]{0,17}[A-Za-z0-9]$/)

const chartArb = fc.integer({ min: 1, max: 12 }).chain(count => fc.record({
  horizontal: fc.boolean(),
  title: fc.option(fc.oneof(nameArb, fc.stringMatching(/^[A-Za-z][A-Za-z0-9 ]{60,120}$/)), { nil: undefined }),
  // Descenders (g, p, q, y) are what cross a bottom edge first.
  xTitle: fc.option(fc.constantFrom('Quarterly spending', 'Typography', 'gypsy query', 'Q'), { nil: undefined }),
  yTitle: fc.option(fc.constantFrom('Revenue', 'Throughput (qps)', 'y'), { nil: undefined }),
  categories: fc.uniqueArray(fc.stringMatching(/^[a-z][a-z0-9]{0,10}[gjpqy]?$/), { minLength: count, maxLength: count }),
  series: fc.array(fc.record({
    kind: fc.constantFrom('bar', 'line'),
    values: fc.array(fc.integer({ min: -100, max: 100 }), { minLength: count, maxLength: count }),
  }), { minLength: 1, maxLength: 3 }),
  // Authored round ranges put ticks exactly on the plot edges, where centered
  // end labels overhang; the scale varies the label width.
  range: fc.option(fc.constantFrom([0, 100], [-100, 100], [0, 200], [-100, 0]), { nil: undefined }),
  scale: fc.constantFrom(1, 1000, 100000),
  showDataLabel: fc.boolean(),
  width: fc.integer({ min: 300, max: 900 }),
  height: fc.integer({ min: 200, max: 700 }),
}))

describe('xychart text stays on the canvas', () => {
  it.each(['', ' horizontal'])('keeps point-label glyphs inside the viewport%s', orientation => {
    const source = `xychart-beta${orientation}\n x-axis [A,B]\n y-axis 0 --> 10\n line [10 "Top",0 "${'Wide '.repeat(20)}"]`
    const svg = renderMermaidSVG(source)
    const [, , width, height] = svg.match(/viewBox="([^"]+)"/)![1]!.split(' ').map(Number)
    const box = new Resvg(textOnly(svg), { font: { loadSystemFonts: false, fontDirs: [FONT_DIR], defaultFontFamily: 'Inter' } }).getBBox()
    expect(box).toBeDefined()
    expect(box!.x).toBeGreaterThanOrEqual(-TOLERANCE)
    expect(box!.y).toBeGreaterThanOrEqual(-TOLERANCE)
    expect(box!.x + box!.width).toBeLessThanOrEqual(width! + TOLERANCE)
    expect(box!.y + box!.height).toBeLessThanOrEqual(height! + TOLERANCE)
  })

  it('keeps every rendered glyph and bar inside the viewBox', () => {
    fc.assert(
      fc.property(chartArb, chart => {
        const source = [
          '---',
          'config:',
          '  xyChart:',
          `    width: ${chart.width}`,
          `    height: ${chart.height}`,
          `    showDataLabel: ${chart.showDataLabel}`,
          '---',
          chart.horizontal ? 'xychart-beta horizontal' : 'xychart-beta',
          ...(chart.title ? [`  title "${chart.title}"`] : []),
          `  x-axis ${chart.xTitle ? `"${chart.xTitle}" ` : ''}[${chart.categories.join(', ')}]`,
          ...(chart.range || chart.yTitle
            ? [`  y-axis ${chart.yTitle ? `"${chart.yTitle}" ` : ''}${chart.range ? `${chart.range[0]! * chart.scale} --> ${chart.range[1]! * chart.scale}` : ''}`.trimEnd()]
            : []),
          ...chart.series.map((series, index) => `  ${series.kind} "S${index}" [${series.values.map(value => value * chart.scale).join(', ')}]`),
        ].join('\n')
        const svg = renderMermaidSVG(source)
        const [, , width, height] = svg.match(/viewBox="([^"]+)"/)![1]!.split(' ').map(Number)
        // Bars clamp both ends into the axis range, so a value beyond an
        // authored range cannot push its bar (or its label) off the canvas.
        for (const [tag] of svg.matchAll(/<rect\b[^>]*\sclass="xychart-bar[^>]*>/g)) {
          const [x, y, w, h] = ['x', 'y', 'width', 'height'].map(name => Number(tag.match(new RegExp(`\\s${name}="([^"]+)"`))?.[1])) as [number, number, number, number]
          expect({ bar: [x, y, w, h], inside: x >= 0 && y >= 0 && x + w <= width! + 0.01 && y + h <= height! + 0.01 }).toEqual({ bar: [x, y, w, h], inside: true })
        }
        const box = new Resvg(textOnly(svg), { font: { loadSystemFonts: false, fontDirs: [FONT_DIR], defaultFontFamily: 'Inter' } }).getBBox()
        // Every chart has at least one category label, so a missing text box
        // means the bundled fonts failed to load, not that there is no text.
        expect({ source, textBox: box !== undefined }).toEqual({ source, textBox: true })
        if (!box) return
        expect({ left: box.x >= -TOLERANCE, top: box.y >= -TOLERANCE, right: box.x + box.width <= width! + TOLERANCE, bottom: box.y + box.height <= height! + TOLERANCE })
          .toEqual({ left: true, top: true, right: true, bottom: true })
      }),
      fcParameters({ numRuns: 150 }),
    )
  })
})
