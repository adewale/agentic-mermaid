// Loop 9 M1 — MCP `render_png` tool. Decodes base64 and asserts PNG magic bytes.

import { describe, test, expect } from 'bun:test'
import { join } from 'node:path'
import { handleRequest, LOCAL_TOOLS } from '../mcp/server.ts'
import { decodePng } from './helpers/png-pixels.ts'

const PNG_MAGIC = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]
const REPO = join(import.meta.dir, '..', '..')
// This regression deliberately starts a second Bun runtime, warms the native
// rasterizer, enters node:vm, and renders under the parent shard's coverage
// load. Keep the hang detector above the observed cold-start contention; the
// MCP sandbox and transport retain their own much tighter execution limits.
const STDIO_RENDER_REGRESSION_TIMEOUT_MS = 60_000

describe('MCP — render_png tool', () => {
  test('tool annotations reflect managed-file side effects and advertise the font remedy', () => {
    const tool = LOCAL_TOOLS.find(candidate => candidate.name === 'render_png')!
    expect(tool.annotations).toMatchObject({
      readOnlyHint: false,
      destructiveHint: false,
      idempotentHint: false,
      openWorldHint: false,
    })
    expect((tool.inputSchema as any).properties.fontDirs).toBeDefined()
    expect((tool.inputSchema as any).properties.loadSystemFonts).toBeDefined()
  })

  test('returns deterministic configuration and font-coverage warnings', async () => {
    const source = '---\nconfig:\n  state:\n    titleTopMargin: 10\n---\nstateDiagram-v2\n  東京 --> Done'
    const r = await handleRequest({
      jsonrpc: '2.0', id: 100, method: 'tools/call',
      params: { name: 'render_png', arguments: { source } },
    })
    const result = r!.result as { content: Array<{ text: string }>; isError: boolean }
    const payload = JSON.parse(result.content[0]!.text) as { ok: boolean; warnings?: Array<{ code: string; field?: string }> }
    expect(payload.ok).toBe(true)
    expect(result.isError).toBe(false)
    expect(payload.warnings).toContainEqual(expect.objectContaining({ code: 'PNG_FONT_COVERAGE' }))
    expect(payload.warnings).toContainEqual(expect.objectContaining({ code: 'INEFFECTIVE_CONFIG', field: 'state.titleTopMargin' }))
  })

  test('a below-floor fitTo carries BELOW_READABLE_SIZE in the tool result', async () => {
    const r = await handleRequest({
      jsonrpc: '2.0', id: 101, method: 'tools/call',
      params: { name: 'render_png', arguments: { source: 'flowchart LR\n  A[Start] -- go --> B[Finish]', fitTo: { width: 100 } } },
    })
    const result = r!.result as { content: Array<{ text: string }>; isError: boolean }
    const payload = JSON.parse(result.content[0]!.text) as { ok: boolean; warnings?: Array<{ code: string; cause?: string }> }
    expect(payload.ok).toBe(true)
    expect(payload.warnings).toContainEqual(expect.objectContaining({ code: 'BELOW_READABLE_SIZE', cause: 'fitTo' }))
  })

  test('happy path returns base64 PNG', async () => {
    const r = await handleRequest({
      jsonrpc: '2.0', id: 1, method: 'tools/call',
      params: { name: 'render_png', arguments: { source: 'flowchart TD\n  A --> B' } },
    })
    const result = r!.result as { content: Array<{ text: string }>; isError: boolean }
    expect(result.isError).toBe(false)
    const payload = JSON.parse(result.content[0]!.text) as { ok: boolean; png_base64?: string }
    expect(payload.ok).toBe(true)
    expect(typeof payload.png_base64).toBe('string')
    const bytes = Buffer.from(payload.png_base64!, 'base64')
    expect(bytes.length).toBeGreaterThan(100)
    for (let i = 0; i < PNG_MAGIC.length; i++) expect(bytes[i]).toBe(PNG_MAGIC[i]!)
  })

  test('honors scale on a fractional canvas', async () => {
    const source = 'flowchart TD\n  A --> B'
    const options = { padding: 40.1 }
    const small = await handleRequest({
      jsonrpc: '2.0', id: 2, method: 'tools/call',
      params: { name: 'render_png', arguments: { source, options, scale: 1 } },
    })
    const big = await handleRequest({
      jsonrpc: '2.0', id: 3, method: 'tools/call',
      params: { name: 'render_png', arguments: { source, options, scale: 3 } },
    })
    const a = JSON.parse((small!.result as { content: Array<{ text: string }> }).content[0]!.text) as { png_base64: string }
    const b = JSON.parse((big!.result as { content: Array<{ text: string }> }).content[0]!.text) as { png_base64: string }
    const smallPng = decodePng(Buffer.from(a.png_base64, 'base64'))
    const bigPng = decodePng(Buffer.from(b.png_base64, 'base64'))
    // Each raster rounds up its scaled intrinsic dimensions independently.
    for (const [small, big] of [[smallPng.width, bigPng.width], [smallPng.height, bigPng.height]] as const) {
      expect(big).toBeGreaterThanOrEqual(small * 3 - 2)
      expect(big).toBeLessThanOrEqual(small * 3)
    }
  })

  test('honors background option', async () => {
    const corner = async (id: number, background: string) => {
      const response = await handleRequest({
        jsonrpc: '2.0', id, method: 'tools/call',
        params: { name: 'render_png', arguments: { source: 'flowchart TD\n  A --> B', background } },
      })
      const { png_base64 } = JSON.parse((response!.result as { content: Array<{ text: string }> }).content[0]!.text) as { png_base64: string }
      return Array.from(decodePng(Buffer.from(png_base64, 'base64')).rgba.slice(0, 4))
    }
    expect({ white: await corner(4, 'white'), black: await corner(5, 'black') })
      .toEqual({ white: [255, 255, 255, 255], black: [0, 0, 0, 255] })
  })

  test('style and seed are accepted only through the canonical options object', async () => {
    const source = 'flowchart TD\n  A --> B'
    const render = async (arguments_: Record<string, unknown>) => {
      const response = await handleRequest({
        jsonrpc: '2.0', id: 50, method: 'tools/call',
        params: { name: 'render_png', arguments: { source, scale: 0.1, ...arguments_ } },
      })
      return JSON.parse((response!.result as { content: Array<{ text: string }> }).content[0]!.text) as {
        png_base64: string
        receipt: unknown
      }
    }
    const crisp = await render({ options: { style: 'crisp', seed: 7 } })
    const handDrawn = await render({
      options: { style: 'hand-drawn', seed: 1 },
    })
    expect(handDrawn.png_base64).not.toBe(crisp.png_base64)
    expect(handDrawn.receipt).not.toEqual(crisp.receipt)

    const removed = await handleRequest({
      jsonrpc: '2.0', id: 51, method: 'tools/call',
      params: { name: 'render_png', arguments: { source, scale: 0.1, style: 'crisp', seed: 7 } },
    })
    expect(removed?.error?.code).toBe(-32602)
  })

  test('missing source → -32602', async () => {
    const r = await handleRequest({
      jsonrpc: '2.0', id: 6, method: 'tools/call',
      params: { name: 'render_png', arguments: {} },
    })
    expect(r!.error).toBeDefined()
    expect(r!.error!.code).toBe(-32602)
  })

  test('invalid source surfaces the canonical family diagnostic', async () => {
    const r = await handleRequest({
      jsonrpc: '2.0', id: 7, method: 'tools/call',
      params: { name: 'render_png', arguments: { source: '' } },
    })
    const result = r!.result as { content: Array<{ text: string }>; isError: boolean }
    // Empty source is diagnosed before rasterization. Keep the canonical
    // unknown-header diagnostic instead of relabelling it as a PNG failure.
    expect(result.isError).toBe(true)
    const payload = JSON.parse(result.content[0]!.text) as {
      ok: boolean
      error?: { code: string; help?: string; preservation?: { source: string } }
    }
    expect(payload.ok).toBe(false)
    expect(payload.error).toMatchObject({
      code: 'UNKNOWN_HEADER',
      preservation: { source: '' },
      help: expect.stringContaining('source was preserved unchanged'),
    })
  })

  // Regression (#298): a real client session runs Code Mode `execute` (a
  // node:vm sandbox) and then `render_png` through the actual shipped stdio
  // bin, out-of-process, so a crash surfaces as an exit code or a missing
  // response rather than killing the test runner. Bun 1.2.15-1.3.14 left the
  // sandbox call's vm watchdog armed until the next macrotask turn, with the
  // last vm call's 50ms deadline; a render_png sent beside execute rendered in
  // that window, was terminated mid-call (a SIGILL crash on some releases) or
  // left the server spinning. This render takes far longer than 50ms, so on
  // those releases it fails every run; the spawn timeout kills a spinning
  // server. bun-version.ts refuses those releases.
  test('stdio server survives execute then answers a render_png sent beside it', async () => {
    const edges = Array.from({ length: 40 }, (_, i) => `  N${i}[Step ${i}] --> N${(i * 7 + 3) % 40}[Step ${(i * 7 + 3) % 40}]`)
    const proc = Bun.spawn(['bun', 'run', join(REPO, 'bin/agentic-mermaid-mcp.ts')], {
      cwd: REPO, stdin: 'pipe', stdout: 'pipe', stderr: 'pipe',
      timeout: STDIO_RENDER_REGRESSION_TIMEOUT_MS / 2, killSignal: 'SIGKILL',
    })
    const requests = [
      { jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-11-25', capabilities: {}, clientInfo: { name: 'png-test', version: '0' } } },
      { jsonrpc: '2.0', id: 2, method: 'tools/call', params: { name: 'execute', arguments: { code: 'return 1' } } },
      { jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'render_png', arguments: { source: `flowchart TD\n${edges.join('\n')}`, output: 'base64' } } },
    ]
    proc.stdin.write(requests.map(r => JSON.stringify(r)).join('\n') + '\n')
    await proc.stdin.end()
    const stdout = await new Response(proc.stdout).text()
    expect(await proc.exited).toBe(0)
    const responses = stdout.split('\n').filter(Boolean).map(line => JSON.parse(line) as { id: number; result?: { content: Array<{ text: string }> } })
    expect(responses.map(r => r.id).sort()).toEqual([1, 2, 3])
    const payload = JSON.parse(responses.find(r => r.id === 3)!.result!.content[0]!.text) as { ok: boolean; png_base64?: string }
    expect(payload.ok).toBe(true)
    expect(Buffer.from(payload.png_base64!, 'base64').subarray(0, PNG_MAGIC.length)).toEqual(Buffer.from(PNG_MAGIC))
  }, STDIO_RENDER_REGRESSION_TIMEOUT_MS)
})
