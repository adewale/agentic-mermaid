/**
 * Golden-file tests for the ASCII/Unicode renderer.
 *
 * Ported from AlexanderGrooff/mermaid-ascii cmd/graph_test.go.
 * Each .txt file contains mermaid input above a `---` separator
 * and the expected ASCII/Unicode output below it.
 *
 * Test data: auto-discovered ASCII and Unicode golden files.
 */
import { describe, it, expect } from 'bun:test'
import { renderMermaidASCII } from '../ascii/index.ts'
import { hasDiagonalLines, DIAGONAL_CHARS } from '../ascii/validate.ts'
import { readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { parseAsciiGoldenFixture } from '../../scripts/ascii-golden-fixture.ts'

// ============================================================================
// Whitespace normalization — matches Go's testutil.NormalizeWhitespace
// ============================================================================

/**
 * Normalize whitespace for comparison:
 * - Trim trailing spaces from each line
 * - Remove leading/trailing blank lines
 */
function normalizeWhitespace(s: string): string {
  const lines = s.split('\n')
  let normalized = lines.map(l => l.trimEnd())

  // Remove leading blank lines
  while (normalized.length > 0 && normalized[0] === '') {
    normalized.shift()
  }
  // Remove trailing blank lines
  while (normalized.length > 0 && normalized[normalized.length - 1] === '') {
    normalized.pop()
  }

  return normalized.join('\n')
}

/** Replace spaces with middle dots for clearer diff output. */
function visualizeWhitespace(s: string): string {
  return s.replaceAll(' ', '·')
}

// ============================================================================
// Test runner — dynamically loads all golden files from testdata directories
// ============================================================================

function runGoldenTests(dir: string, useAscii: boolean): void {
  const files = readdirSync(dir).filter(f => f.endsWith('.txt')).sort()

  expect(files.length).toBeGreaterThan(0)
  for (const file of files) {
    const testName = file.replace('.txt', '')

    it(testName, () => {
      const content = readFileSync(join(dir, file), 'utf-8')
      const tc = parseAsciiGoldenFixture(content)

      const actual = renderMermaidASCII(tc.mermaid, {
        useAscii,
        paddingX: tc.paddingX,
        paddingY: tc.paddingY,
      })

      const normalizedExpected = normalizeWhitespace(tc.expected)
      const normalizedActual = normalizeWhitespace(actual)
      const diagonals = useAscii ? DIAGONAL_CHARS.ascii : DIAGONAL_CHARS.unicode
      expect([...diagonals].filter(char => actual.includes(char))).toEqual([])

      if (normalizedExpected !== normalizedActual) {
        const expectedVis = visualizeWhitespace(normalizedExpected)
        const actualVis = visualizeWhitespace(normalizedActual)
        expect(actualVis).toBe(expectedVis)
      }
    })
  }
}

// ============================================================================
// Test suites
// ============================================================================

const testdataDir = join(import.meta.dir, 'testdata')

describe('ASCII rendering', () => {
  runGoldenTests(join(testdataDir, 'ascii'), true)
})

describe('Unicode rendering', () => {
  runGoldenTests(join(testdataDir, 'unicode'), false)
})

// ============================================================================
// Config behavior tests — ported from Go's TestGraphUseAsciiConfig
// ============================================================================

describe('Config behavior', () => {
  const mermaidInput = 'graph LR\nA --> B'

  it('ASCII and Unicode outputs should differ', () => {
    const asciiOutput = renderMermaidASCII(mermaidInput, { useAscii: true })
    const unicodeOutput = renderMermaidASCII(mermaidInput, { useAscii: false })
    expect(asciiOutput).not.toBe(unicodeOutput)
  })

  it('ASCII output should not contain Unicode box-drawing characters', () => {
    const output = renderMermaidASCII(mermaidInput, { useAscii: true })
    expect(output).not.toContain('┌')
    expect(output).not.toContain('─')
    expect(output).not.toContain('│')
  })

  it('Unicode output should contain Unicode box-drawing characters', () => {
    const output = renderMermaidASCII(mermaidInput, { useAscii: false })
    const hasUnicode = output.includes('┌') || output.includes('─') || output.includes('│')
    expect(hasUnicode).toBe(true)
  })
})

// ============================================================================
// Diagonal validation — ensures all edges use orthogonal Manhattan routing
// ============================================================================

describe('Diagonal validation', () => {
  it('hasDiagonalLines utility correctly detects diagonal characters', () => {
    // Should detect ASCII diagonals
    expect(hasDiagonalLines('A / B')).toBe(true)
    expect(hasDiagonalLines('A \\ B')).toBe(true)

    // Should detect Unicode diagonals
    expect(hasDiagonalLines('A ╱ B')).toBe(true)
    expect(hasDiagonalLines('A ╲ B')).toBe(true)

    // Should not flag clean output
    expect(hasDiagonalLines('┌───┐\n│ A │\n└───┘')).toBe(false)
    expect(hasDiagonalLines('+---+\n| A |\n+---+')).toBe(false)
  })
})

describe('Sequence pre-message notes (Loop 7 A2 — rnbguy#54)', () => {
  // Regression coverage: a `Note over X: foo` placed BEFORE the first message
  // in a sequenceDiagram must render in the canvas above the first message
  // row. Upstream rnbguy#54 was the inspiration; this test pins our coverage.

  it('renders a pre-message Note over the first message rows', () => {
    const src = `sequenceDiagram
  participant A
  participant B
  Note over A: setup before flow
  A->>B: ping`
    const result = renderMermaidASCII(src)
    expect(result).toContain('setup before flow')
    expect(result).toContain('ping')
    // The note row must appear ABOVE the message row (smaller y index).
    const lines = result.split('\n')
    const noteRow = lines.findIndex(l => l.includes('setup before flow'))
    const msgRow = lines.findIndex(l => l.includes('ping'))
    expect(noteRow).toBeGreaterThanOrEqual(0)
    expect(msgRow).toBeGreaterThan(noteRow)
  })

  it('renders a pre-message Note over multiple participants', () => {
    const src = `sequenceDiagram
  participant A
  participant B
  Note over A,B: shared preamble
  A->>B: go`
    const result = renderMermaidASCII(src)
    expect(result).toContain('shared preamble')
    expect(result).toContain('go')
    const lines = result.split('\n')
    const noteRow = lines.findIndex(l => l.includes('shared preamble'))
    const msgRow = lines.findIndex(l => l.includes('go'))
    expect(noteRow).toBeGreaterThanOrEqual(0)
    expect(msgRow).toBeGreaterThan(noteRow)
  })
})
