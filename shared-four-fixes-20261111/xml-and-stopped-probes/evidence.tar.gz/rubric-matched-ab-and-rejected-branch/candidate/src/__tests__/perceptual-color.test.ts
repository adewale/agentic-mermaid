// Unit + property tests for the perceptual-color primitives (OKLab/OKLCH,
// ΔE_OK, APCA). These are pure, deterministic functions of concrete sRGB hex,
// so the contracts are exact: round-trips, monotonicity, and known anchors.

import { describe, it, expect } from 'bun:test'
import fc from 'fast-check'
import { fcParameters } from './helpers/fc-parameters.ts'
import {
  hexToOklab,
  oklabToHex,
  hexToOklch,
  oklchToHex,
  oklabToOklch,
  deltaEOK,
  minPairwiseDeltaEOK,
  apcaLc,
  apcaContrast,
} from '../shared/perceptual-color.ts'

const hexColorArb = fc
  .integer({ min: 0, max: 0xffffff })
  .map(n => '#' + n.toString(16).padStart(6, '0'))

describe('OKLab / OKLCH conversions', () => {
  it('anchors: white L≈1, black L≈0, both achromatic', () => {
    const white = hexToOklab('#ffffff')!
    const black = hexToOklab('#000000')!
    expect(white.L).toBeCloseTo(1, 3)
    expect(black.L).toBeCloseTo(0, 3)
    expect(Math.hypot(white.a, white.b)).toBeLessThan(1e-3)
    expect(Math.hypot(black.a, black.b)).toBeLessThan(1e-3)
  })

  // Published references (Björn Ottosson's OKLab definition, as tabulated by
  // CSS Color 4 implementations). Anchors, round-trips and monotonicity cannot
  // catch an a/b axis swap, a sign flip or a scale error; these can.
  it('matches the published OKLab values of the sRGB primaries', () => {
    const references: Record<string, { L: number; a: number; b: number }> = {
      '#ff0000': { L: 0.627955, a: 0.224863, b: 0.125846 },
      '#00ff00': { L: 0.866440, a: -0.233888, b: 0.179498 },
      '#0000ff': { L: 0.452014, a: -0.032457, b: -0.311528 },
    }
    for (const [hex, expected] of Object.entries(references)) {
      const { L, a, b } = hexToOklab(hex)!
      expect({ hex, L, a, b }).toEqual({
        hex,
        L: expect.closeTo(expected.L, 5),
        a: expect.closeTo(expected.a, 5),
        b: expect.closeTo(expected.b, 5),
      })
    }
  })

  it('hex → OKLCH → hex round-trips exactly for in-gamut colors', () => {
    fc.assert(
      fc.property(hexColorArb, hex => {
        expect(oklchToHex(hexToOklch(hex)!)).toBe(hex)
      }),
      fcParameters({ numRuns: 300 }),
    )
  })

  it('hex → OKLab → hex round-trips exactly', () => {
    fc.assert(
      fc.property(hexColorArb, hex => {
        expect(oklabToHex(hexToOklab(hex)!)).toBe(hex)
      }),
      fcParameters({ numRuns: 300 }),
    )
  })

  it('OKLCH lightness is monotone in luminance (lighter grey ⇒ larger L)', () => {
    const greys = ['#111111', '#444444', '#888888', '#cccccc', '#eeeeee']
    const Ls = greys.map(g => hexToOklch(g)!.L)
    for (let i = 1; i < Ls.length; i++) expect(Ls[i]!).toBeGreaterThan(Ls[i - 1]!)
  })

  it('hue is defined in degrees [0,360) and chroma is non-negative', () => {
    fc.assert(
      fc.property(hexColorArb, hex => {
        const { h, C } = oklabToOklch(hexToOklab(hex)!)
        expect(h).toBeGreaterThanOrEqual(0)
        expect(h).toBeLessThan(360)
        expect(C).toBeGreaterThanOrEqual(0)
      }),
      fcParameters({ numRuns: 200 }),
    )
  })

  it('returns null on unparseable input', () => {
    expect(hexToOklab('var(--x)')).toBeNull()
    expect(hexToOklch('nonsense')).toBeNull()
    expect(deltaEOK('#fff', 'var(--x)')).toBeNull()
  })
})

describe('ΔE_OK perceptual distance', () => {
  it('is zero for identical colors and symmetric', () => {
    fc.assert(
      fc.property(hexColorArb, hexColorArb, (a, b) => {
        expect(deltaEOK(a, a)).toBe(0)
        expect(deltaEOK(a, b)).toBeCloseTo(deltaEOK(b, a)!, 10)
      }),
      fcParameters({ numRuns: 200 }),
    )
  })

  it('black↔white is the largest separation (~1 L unit)', () => {
    expect(deltaEOK('#000000', '#ffffff')).toBeCloseTo(1, 2)
  })

  it('minPairwiseDeltaEOK finds the closest pair', () => {
    const cols = ['#000000', '#ffffff', '#fefefe'] // white/near-white are closest
    expect(minPairwiseDeltaEOK(cols)).toBeCloseTo(deltaEOK('#ffffff', '#fefefe')!, 10)
  })

  it('is Infinity for fewer than two colors', () => {
    expect(minPairwiseDeltaEOK([])).toBe(Infinity)
    expect(minPairwiseDeltaEOK(['#abcdef'])).toBe(Infinity)
  })
})

describe('APCA lightness contrast', () => {
  it('is polarity-signed: dark-on-light positive, light-on-dark negative', () => {
    expect(apcaLc('#000000', '#ffffff')!).toBeGreaterThan(50)
    expect(apcaLc('#ffffff', '#000000')!).toBeLessThan(-50)
  })

  // Reference text/background pairs published with APCA 0.0.98G-4g (apca-w3).
  it('matches the published APCA reference Lc values', () => {
    const references: Array<[string, string, number]> = [
      ['#888888', '#ffffff', 63.056469930209424],
      ['#ffffff', '#888888', -68.54146436644962],
      ['#000000', '#aaaaaa', 58.146262578561334],
      ['#aaaaaa', '#000000', -56.24113336839742],
      ['#112233', '#ddeeff', 91.66830811481631],
      ['#ddeeff', '#112233', -93.06770049484275],
      ['#112233', '#444444', 8.32326136957393],
      ['#444444', '#112233', -7.526878460278154],
    ]
    for (const [text, background, lc] of references) {
      expect({ text, background, lc: apcaLc(text, background) }).toEqual({ text, background, lc: expect.closeTo(lc, 3) })
    }
  })

  it('a color against itself has zero contrast', () => {
    fc.assert(
      fc.property(hexColorArb, hex => {
        expect(apcaLc(hex, hex)).toBe(0)
      }),
      fcParameters({ numRuns: 100 }),
    )
  })

  it('catches dark-on-dark that WCAG overstates', () => {
    // A dim slate on a near-black page: APCA correctly reports near-invisible,
    // where a naive WCAG ratio can still clear a low decorative threshold.
    const lc = apcaContrast('#2a2d3a', '#1a1b26')!
    expect(lc).toBeLessThan(15)
  })

  it('|Lc| grows as a fill separates in lightness from a dark background', () => {
    const bg = '#1a1b26'
    const dim = apcaContrast('#3a3d4a', bg)!
    const bright = apcaContrast('#c9ccd9', bg)!
    expect(bright).toBeGreaterThan(dim)
  })

  it('returns null on unparseable input', () => {
    expect(apcaLc('#fff', 'var(--bg)')).toBeNull()
    expect(apcaContrast('rgb(0,0,0)', '#fff')).toBeNull()
  })
})
