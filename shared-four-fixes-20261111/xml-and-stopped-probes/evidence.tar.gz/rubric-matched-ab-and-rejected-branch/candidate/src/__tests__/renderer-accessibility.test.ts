// Loop 11 M2 (#7254/#7255 + #7349): SVG accessibility (title/desc/ARIA) and
// the structured AX tree from describeMermaid({format:'json'}).

import { describe, test, expect } from 'bun:test'
import { renderMermaidSVG } from '../index.ts'
import { describeMermaidSource, describeMermaidTree } from '../agent/describe.ts'
import { parseRegisteredMermaid as parseMermaid } from '../agent/parse.ts'
import { mutate, mutateChecked } from '../agent/mutate.ts'
import { verifyMermaid } from '../agent/verify.ts'
import { startUpstreamMermaid, type UpstreamDiagram } from './helpers/upstream-mermaid.ts'
import { createMermaid } from '../agent/create.ts'
import { parseEventModeling } from '../eventmodeling/parser.ts'
import { parseVennDiagram } from '../venn/parser.ts'
import { parseZenUML } from '../zenuml/native-parser.ts'
import { synthesizeFromGraph } from '../agent/index.ts'
import { parseMindmap } from '../mindmap/parser.ts'
import { decodeXML } from 'entities'
import { serializeMermaid } from '../agent/serialize.ts'
import { SaxesParser } from 'saxes'
import { useTestChildren } from './helpers/test-child.ts'

const runChild = useTestChildren(25_000)

test('successful accessibility edits close through body, metadata and source without creating statements', () => {
  const parsed = parseMermaid('packet\n0-7: "Payload"')
  if (!parsed.ok) throw new Error('Expected Packet')
  const original = structuredClone(parsed.value)
  for (const description of ['', '\n \t', 'one\n}\naccDescr {\ntwo', '{unfinished', 'one\r\ntwo', 'ordinary description']) {
    const result = mutate(parsed.value, { kind: 'set_accessibility_description', description })
    if (!description.trim()) expect(result.ok).toBe(false)
    if (description === 'ordinary description' || description === 'one\r\ntwo') expect(result.ok).toBe(true)
    if (!result.ok) {
      expect(result.error.code).toBe('INVALID_OP')
    } else {
      const expected = description.replace(/\r\n?/g, '\n')
      const reload = parseMermaid(serializeMermaid(result.value))
      if (!reload.ok || result.value.body.kind !== 'packet' || reload.value.body.kind !== 'packet') throw new Error('Expected Packet reload')
      expect(result.value.body.accessibilityDescription).toBe(expected)
      expect(result.value.meta.accessibility.descr).toBe(expected)
      expect(reload.value.body.accessibilityDescription).toBe(expected)
      expect(reload.value.body.fields).toEqual(original.body.kind === 'packet' ? original.body.fields : [])
    }
    expect(parsed.value).toEqual(original)
  }
  for (const title of ['', ' \t', '%%{init: {"theme":"dark"}}%%', 'ordinary title']) {
    const result = mutate(parsed.value, { kind: 'set_accessibility_title', title })
    if (!title.trim()) expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.error.code).toBe('INVALID_OP')
    } else {
      const reload = parseMermaid(serializeMermaid(result.value))
      if (!reload.ok || result.value.body.kind !== 'packet' || reload.value.body.kind !== 'packet') throw new Error('Expected Packet reload')
      expect(result.value.body.accessibilityTitle).toBe(title)
      expect(result.value.meta.accessibility.title).toBe(title)
      expect(reload.value.body.accessibilityTitle).toBe(title)
      expect(reload.value.meta.initDirectives).toEqual(original.meta.initDirectives)
      expect(reload.value.meta.frontmatter).toEqual(original.meta.frontmatter)
    }
    expect(parsed.value).toEqual(original)
  }
  const control = mutate(parsed.value, { kind: 'set_accessibility_title', title: 'ordinary title' })
  expect(control.ok).toBe(true)
  const emptyTitle = parseMermaid('packet\naccTitle: \n0-7: "Payload"')
  if (!emptyTitle.ok || emptyTitle.value.body.kind !== 'packet') throw new Error('Expected Packet with an empty title')
  const emptyOriginal = structuredClone(emptyTitle.value)
  const refused = mutate(emptyTitle.value, { kind: 'set_title', title: 'Edited' })
  expect(refused.ok).toBe(false)
  if (!refused.ok) expect(refused.error.code).toBe('INVALID_OP')
  expect(emptyTitle.value).toEqual(emptyOriginal)
})

test.each([
  ['usecase-beta', 'actor A("A")'],
  ['wardley-beta', 'component A [50.0, 50.0]'],
  ['venn-beta', 'set A:10'],
  ['cynefin-beta', 'complex\n  "Explore"'],
  ['treeView-beta', '"file.ts"'],
] as const)('%s accessibility clears close through the final envelope and checked edits', (header, content) => {
  const source = `---\ntitle: Preserved wrapper\n---\n%% authored wrapper\n${header}\naccTitle: Original\naccDescr: Preserve until cleared\n${content}`
  const parsed = parseMermaid(source)
  if (!parsed.ok || parsed.value.body.kind === 'opaque') throw new Error('Expected editable native family')
  const original = structuredClone(parsed.value)
  for (const edit of [mutate, mutateChecked]) {
    for (const op of [{ kind: 'set_accessibility_title', title: null }, { kind: 'set_accessibility_description', description: null }] as const) {
      const result = edit(parsed.value, op)
      if (!result.ok) throw new Error(JSON.stringify(result.error))
      const expected = op.kind === 'set_accessibility_title' ? { descr: 'Preserve until cleared' } : { title: 'Original' }
      expect(result.value.meta.accessibility).toEqual(expected)
      const body = result.value.body as { accessibilityTitle?: string; accessibilityDescription?: string }
      expect(body.accessibilityTitle).toBe(expected.title)
      expect(body.accessibilityDescription).toBe(expected.descr)
      const serialized = serializeMermaid(result.value)
      expect(serialized.startsWith('---\ntitle: Preserved wrapper\n---\n%% authored wrapper\n')).toBe(true)
      const reload = parseMermaid(serialized)
      if (!reload.ok) throw new Error(JSON.stringify(reload.error))
      expect(reload.value.meta.accessibility).toEqual(expected)
      expect(reload.value.body).toEqual(result.value.body)
      expect(parsed.value).toEqual(original)
    }
  }
})

test.each([
  ['usecase-beta', 'actor A("A")'],
  ['wardley-beta', 'component A [50.0, 50.0]'],
  ['venn-beta', 'set A:10'],
  ['cynefin-beta', 'complex\n  "Explore"'],
  ['treeView-beta', '"file.ts"'],
  ['railroad-beta', 'entry = terminal("a");'],
] as const)('%s display title edits own the existing frontmatter scalar', (header, content) => {
  const parsed = parseMermaid(`---\ntitle: Original display\nconfig:\n  theme: dark\n---\n%% wrapper rationale\n${header}\naccTitle: Accessible\n${content}`)
  if (!parsed.ok || parsed.value.body.kind === 'opaque') throw new Error('Expected typed native family')
  for (const edit of [mutate, mutateChecked]) for (const title of [null, 'Changed display']) {
    const result = edit(parsed.value, { kind: 'set_title', title })
    if (!result.ok) throw new Error(JSON.stringify(result.error))
    expect((result.value.body as { title?: string }).title).toBe(title ?? undefined)
    expect(result.value.meta.frontmatter?.title).toBe(title ?? undefined)
    expect(result.value.meta.frontmatter?.theme).toBe('dark')
    expect(result.value.meta.accessibility).toEqual({ title: 'Accessible' })
    const saved = serializeMermaid(result.value)
    expect(saved).toContain('%% wrapper rationale')
    expect(saved).not.toContain('Original display')
    const reload = parseMermaid(saved)
    if (!reload.ok) throw new Error(JSON.stringify(reload.error))
    expect((reload.value.body as { title?: string }).title).toBe(title ?? undefined)
    expect(reload.value.meta.frontmatter).toEqual(result.value.meta.frontmatter)
  }
})

test.each([
  ['eventmodeling', 'eventmodeling\n%% retained body comment\ntf 01 ui Main', parseEventModeling],
  ['zenuml', 'zenuml\n%% retained body comment\nAlice->Bob: hello', parseZenUML],
  ['venn', 'venn-beta\n%% retained body comment\nset A:10', parseVennDiagram],
] as const)('%s native accessibility decodes protected punctuation once through checked edits and public reload', (family, source, readNative) => {
  const parsed = parseMermaid('%% retained wrapper comment\n' + source)
  if (!parsed.ok || parsed.value.body.kind !== family) throw new Error('Expected typed native metadata owner')
  for (const initial of [createMermaid(family), parsed.value]) for (const text of ['https://example.com?a=1&b=2', 'Literal #58; &amp; #35; %% text', 'Control %%{init: {theme: dark}}%% and <b>literal</b>']) {
    const original = structuredClone(initial), description = text + '\nSecond line'
    const titled = mutateChecked(initial, { kind: 'set_accessibility_title', title: text })
    if (!titled.ok) throw new Error(JSON.stringify(titled.error))
    const changed = mutateChecked(titled.value, { kind: 'set_accessibility_description', description })
    if (!changed.ok) throw new Error(JSON.stringify(changed.error))
    if (changed.value.body.kind !== family) throw new Error('Metadata edit changed its native family')
    expect(changed.value.meta.accessibility).toEqual({ title: text, descr: description })
    const saved = serializeMermaid(changed.value), direct = readNative(saved), reload = parseMermaid(saved)
    expect(direct.accessibilityTitle).toBe(text)
    expect(direct.accessibilityDescription).toBe(description)
    if (!reload.ok || reload.value.body.kind !== family) throw new Error('Expected typed public reload')
    expect(reload.value.body).toEqual(changed.value.body)
    expect(reload.value.meta.accessibility).toEqual({ title: text, descr: description })
    expect(reload.value.meta.initDirectives).toEqual([])
    if (initial === parsed.value) {
      expect(saved.startsWith('%% retained wrapper comment\n')).toBe(true)
      expect(saved.match(/^%% retained body comment$/gm)).toHaveLength(1)
    }
    const cleared = mutateChecked(changed.value, { kind: 'set_accessibility_title', ...(family === 'venn' ? { title: null } : {}) })
    if (!cleared.ok) throw new Error(JSON.stringify(cleared.error))
    expect(cleared.value.meta.accessibility).toEqual({ descr: description })
    const clearReload = parseMermaid(serializeMermaid(cleared.value))
    if (!clearReload.ok) throw new Error('Expected metadata clear reload')
    expect(clearReload.value.meta.accessibility).toEqual({ descr: description })
    expect(initial).toEqual(original)
  }
})

describe('#7254/#7255 SVG accessibility', () => {
  test('literal directive openers in accessibility stay source-only and cannot escape through an edit', () => {
    const source = 'pie\naccDescr {\nReview %%{prose\n}\n"Share": 2'
    const parsed = parseMermaid(source)
    if (!parsed.ok) throw new Error(JSON.stringify(parsed.error))
    expect(parsed.value.body.kind).toBe('opaque')
    expect(serializeMermaid(parsed.value)).toBe(source + '\n')
    expect(verifyMermaid(parsed.value).warnings).toContainEqual(expect.objectContaining({ code: 'UNSUPPORTED_SYNTAX', syntax: 'accessibility_directive_text' }))
    const editable = parseMermaid('pie\n"Share": 2')
    if (!editable.ok) throw new Error(JSON.stringify(editable.error))
    const edited = mutate(editable.value, { kind: 'set_accessibility_description', description: 'Review %%{prose' })
    expect(edited.ok).toBe(false)
    expect(editable.value.meta.accessibility.descr).toBeUndefined()
  })

  test.each([
    ['xychart-beta', 'line [2]', { kind: 'set_title', title: 'Changed' }, 'Changed'],
    ['pie', '"Share": 2', { kind: 'add_slice', label: 'Other', value: 3 }, 'Other'],
    ['stateDiagram-v2', 'A --> B', { kind: 'add_state', id: 'C' }, 'C'],
    ['packet', '0-7: "Payload"', { kind: 'set_field_label', index: 0, label: 'Changed' }, 'Changed'],
    ['classDiagram', 'class A', { kind: 'add_class', id: 'Changed' }, 'Changed'],
    ['classDiagram', 'namespace Domain {\nclass A\n}', { kind: 'add_class', id: 'Changed' }, 'Changed'],
  ] as const)('empty description blocks survive writing and unrelated %s edits', async (header, content, op, changedText) => {
    const upstream = startUpstreamMermaid()
    try {
      const parsed = parseMermaid(`${header}\naccDescr{}${content}%%`)
      if (!parsed.ok) throw new Error(JSON.stringify(parsed.error))
      const original = structuredClone(parsed.value)
      expect(parsed.value.meta.accessibility.descr).toBe('')
      expect(verifyMermaid(parsed.value).ok).toBe(true)
      if (header === 'classDiagram') expect(verifyMermaid(parsed.value).warnings).toContainEqual(expect.objectContaining({ code: 'UNSUPPORTED_SYNTAX', syntax: 'class_empty_accessibility_description' }))
      expect(await upstream.publicAccepts(serializeMermaid(parsed.value))).toBe(true)
      const edited = mutate(parsed.value, op)
      expect(edited.ok).toBe(true)
      if (!edited.ok) throw new Error(JSON.stringify(edited.error))
      expect(edited.value.meta.accessibility.descr).toBe('')
      const written = serializeMermaid(edited.value)
      expect(written).toContain(changedText)
      expect(await upstream.publicAccepts(written), written).toBe(true)
      if (header === 'classDiagram') expect(verifyMermaid(written).warnings).not.toContainEqual(expect.objectContaining({ syntax: 'class_empty_accessibility_description' }))
      const reread = parseMermaid(written)
      if (!reread.ok) throw new Error(JSON.stringify(reread.error))
      expect(reread.value.meta.accessibility.descr).toBe('')
      expect(reread.value.body.kind).toBe(parsed.value.body.kind)
      expect(parsed.value).toEqual(original)
    } finally { upstream.close() }
  })

  test('accTitle → <title>, accDescr → <desc>, role + ARIA references on root', () => {
    const svg = renderMermaidSVG('flowchart TD\n accTitle: Login Flow\n accDescr: How a user logs in\n A[Start] --> B[End]')
    expect(svg).toContain('<title id="svg-title">Login Flow</title>')
    expect(svg).toContain('<desc id="svg-desc">How a user logs in</desc>')
    expect(svg).toContain('role="img"')
    expect(svg).toContain('aria-labelledby="svg-title"')
    expect(svg).toContain('aria-describedby="svg-desc"')
  })

  test('accDescr block form is captured', () => {
    const svg = renderMermaidSVG('flowchart TD\n accTitle: T\n accDescr {\n   multi  line\n\n   description\n }\n A --> B')
    expect(svg).toContain('<title id="svg-title">T</title>')
    expect(svg).toContain('multi  line\n\ndescription')
    expect(svg).not.toContain('data-id="accTitle"')
    expect(svg).not.toContain('data-id="accDescr"')
  })

  test('sequence malformed accDescr opener does not prevent rendering valid messages', () => {
    const svg = renderMermaidSVG('sequenceDiagram\n  accDescr: {foo\n  A->>B: hi')
    expect(svg).toContain('hi')
    expect(svg).toContain('data-id="A"')
    expect(svg).toContain('data-id="B"')
  })

  test('class, ER, and timeline reject unclosed accDescr blocks', () => {
    const cases = [
      ['class', 'classDiagram\n accDescr {\n never closed\n class A'],
      ['ER', 'erDiagram\n accDescr {\n never closed\n A ||--o{ B : rel'],
      ['timeline', 'timeline\n accDescr {\n never closed\n 2026 : Ship'],
    ] as const

    for (const [family, source] of cases) {
      expect(() => renderMermaidSVG(source), family).toThrow(/accDescr block/)
    }
  })

  test('diagram without acc directives emits no <title>/<desc>', () => {
    const svg = renderMermaidSVG('flowchart TD\n A --> B')
    expect(svg).not.toContain('<title')
    expect(svg).not.toContain('aria-labelledby')
  })

  test('title text is XML-escaped', () => {
    const svg = renderMermaidSVG('flowchart TD\n accTitle: A < B & C\n A --> B')
    expect(svg).toContain('A &lt; B &amp; C')
  })

  test('acc title/desc ids carry the idPrefix (collision-free with other diagrams)', () => {
    const svg = renderMermaidSVG('flowchart TD\n accTitle: X\n A --> B', { idPrefix: 'd3-' })
    expect(svg).toContain('<title id="d3-svg-title">X</title>')
    expect(svg).toContain('aria-labelledby="d3-svg-title"')
  })

  test.each(['0', '1'])('late accessibility IDs preserve marker targets with Scene assertions %s', async mode => {
    const child = await runChild(process.execPath, ['--eval', String.raw`
      import assert from 'node:assert/strict'
      import { renderMermaidSVG } from './src/index.ts'
      import { getFamily, replaceFamilyForTest } from './src/agent/families.ts'
      import { sceneLowering, nativeDrawingOf } from './src/scene/drawing.ts'
      import { sceneAssertionsEnabled } from './src/scene/assertions.ts'
      assert.equal(sceneAssertionsEnabled(), process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS === '1')
      const family = getFamily('flowchart')
      const original = nativeDrawingOf(family.lowerScene)
      const rows = []
      for (const prefix of ['', 'probe-']) {
        for (const resource of ['safe-terminal', 'svg-title', 'svg-desc']) {
          for (const occupied of resource === 'safe-terminal' ? ['none'] : ['none', 'ordinary', 'encoded']) {
            const rename = marker => marker && marker.id === 'arrowhead' ? { ...marker, id: resource } : marker
            const custom = sceneLowering((factory, context) => {
              const drawing = original({
                ...factory,
                definitions(fields, svg) {
                  const markers = fields.markerResources.map(rename)
                  const markup = svg.replaceAll('id="arrowhead"', 'id="' + resource + '"')
                  return factory.definitions({ ...fields, markerResources: markers }, markup)
                },
                connector(fields) {
                  const markers = fields.markers
                  return factory.connector({ ...fields, ...(markers ? { markers: {
                    ...markers, ...(markers.start ? { start: rename(markers.start) } : {}),
                    ...(markers.end ? { end: rename(markers.end) } : {}),
                    ...(markers.mid ? { mid: markers.mid.map(rename) } : {}),
                  } } : {}) })
                },
              }, context)
              if (occupied !== 'none') {
                const firstId = resource + (occupied === 'encoded' ? '-&#49;' : '-1')
                drawing.parts.splice(1, 0, factory.documentContent({ id: 'reserved-accessibility-ids', role: 'chrome', nonPaint: 'accessibility' },
                  '<desc id="' + firstId + '">Reserved first identity</desc><desc id="' + resource + '-2">Reserved second identity</desc>'))
              }
              return drawing
            })
            const restore = replaceFamilyForTest('flowchart', { ...family, lowerScene: custom })
            try {
              const source = 'flowchart LR\naccTitle: Visible terminal\naccDescr: Authored diagram description\nA[Start] --> B[End]'
              const svg = renderMermaidSVG(source, { embedFontImport: false, security: 'strict', ...(prefix ? { idPrefix: prefix } : {}),
                graphLayout: { backend: 'agentic' } })
              rows.push({ prefix, resource, occupied, svg })
            } finally { restore() }
          }
        }
      }
      console.log(JSON.stringify(rows))
    `], { cwd: `${import.meta.dir}/../..`, env: { ...process.env, AGENTIC_MERMAID_SCENE_ASSERTIONS: mode } })
    expect(child.stderr).toBe('')
    expect(child.status).toBe(0)
    const rows = JSON.parse(child.stdout) as Array<{ prefix: string; resource: string; occupied: string; svg: string }>
    expect(rows).toHaveLength(14)
    for (const row of rows) {
      const label = `${row.prefix || 'unprefixed'} ${row.resource} ${row.occupied}`
      const elements: Array<{ name: string; attributes: Record<string, string>; text: string }> = []
      const stack: typeof elements = []
      const parser = new SaxesParser({ xmlns: true })
      parser.on('opentag', tag => {
        const element = { name: tag.local, attributes: Object.fromEntries(Object.entries(tag.attributes).map(([key, value]) => [key, value.value])), text: '' }
        elements.push(element)
        stack.push(element)
      })
      parser.on('text', text => { if (stack.length) stack.at(-1)!.text += text })
      parser.on('closetag', () => { stack.pop() })
      parser.write(row.svg).close()
      const declarations = elements.filter(element => element.attributes.id !== undefined)
      const ids = declarations.map(element => element.attributes.id!)
      expect(new Set(ids).size, label).toBe(ids.length)
      const root = elements[0]!
      for (const [attribute, name, text] of [
        ['aria-labelledby', 'title', 'Visible terminal'],
        ['aria-describedby', 'desc', 'Authored diagram description'],
      ] as const) {
        const target = root.attributes[attribute]!
        expect(target, label).toBeTruthy()
        const resolved = declarations.filter(element => element.attributes.id === target)
        expect(resolved.map(element => [element.name, element.text]), label).toEqual([[name, text]])
      }
      const markerId = row.prefix + row.resource
      expect(declarations.filter(element => element.attributes.id === markerId).map(element => element.name), label).toEqual(['marker'])
      const references = elements.flatMap(element => element.attributes['marker-end'] ? [element.attributes['marker-end']] : [])
      expect(references, label).toContain(`url(#${markerId})`)
      for (const reference of references) {
        expect(reference, label).toMatch(/^url\(#[^)]*\)$/)
        const id = /^url\(#([^)]*)\)$/.exec(reference)![1]
        expect(declarations.filter(element => element.attributes.id === id).map(element => element.name), label).toEqual(['marker'])
      }
      if (row.occupied !== 'none') for (const suffix of ['-1', '-2']) {
        expect(declarations.filter(element => element.attributes.id === markerId + suffix).map(element => element.name), label).toEqual(['desc'])
      }
    }
  }, 30_000)
})

describe('#7349 AX tree — describeMermaid({format:json})', () => {
  test('flowchart: every node + edge in the tree', () => {
    const tree = describeMermaidTree(parseMermaidOk('flowchart TD\n A[Start] --> B[Mid]\n B --> C[End]'))
    expect(tree.kind).toBe('flowchart')
    expect(tree.nodes.map(n => n.id).sort()).toEqual(['A', 'B', 'C'])
    expect(tree.nodes.find(n => n.id === 'A')!.label).toBe('Start')
    expect(tree.edges).toEqual([
      { from: 'A', to: 'B', label: undefined },
      { from: 'B', to: 'C', label: undefined },
    ])
    expect(tree.entryPoints).toEqual(['A'])
    expect(tree.sinks).toEqual(['C'])
  })

  test('json format is valid JSON with the tree shape', () => {
    const json = describeMermaidSource('flowchart TD\n A --> B', { format: 'json' })
    const parsed = JSON.parse(json)
    expect(parsed.kind).toBe('flowchart')
    expect(Array.isArray(parsed.nodes)).toBe(true)
    expect(Array.isArray(parsed.edges)).toBe(true)
  })

  test('sequence: participants → nodes, messages → edges', () => {
    const tree = describeMermaidTree(parseMermaidOk('sequenceDiagram\n Alice->>Bob: Hi\n Bob-->>Alice: Hello'))
    expect(tree.nodes.map(n => n.id).sort()).toEqual(['Alice', 'Bob'])
    expect(tree.edges.map(({ from, to, label }) => ({ from, to, label }))).toEqual([
      { from: 'Alice', to: 'Bob', label: 'Hi' },
      { from: 'Bob', to: 'Alice', label: 'Hello' },
    ])
  })

  test('class: classes → nodes, relations → edges', () => {
    const tree = describeMermaidTree(parseMermaidOk('classDiagram\n class A\n class B\n A <|-- B'))
    expect(tree.nodes.map(n => n.id).sort()).toEqual(['A', 'B'])
    expect(tree.edges).toEqual([{ from: 'A', to: 'B', label: 'inheritance' }])
  })

  test('an unregistered source → preserved-family JSON tree, not a throw', () => {
    const json = describeMermaidSource('not a diagram', { format: 'json' })
    const parsed = JSON.parse(json)
    expect(parsed.kind).toBe('family:unknown')
    expect(parsed.nodes).toEqual([])
  })
})

function parseMermaidOk(src: string) {
  const r = parseMermaid(src)
  if (!r.ok) throw new Error('parse failed')
  return r.value
}


test('native accessibility comments preserve editable metadata and external topology without changing captured wrappers', async () => {
  const pin = startUpstreamMermaid()
  const wrapper = '---\ntitle: Diagram\n---\n%% wrapper rationale\n'
  const project = (d: UpstreamDiagram) => {
    if (d.type === 'block') return { blocks: d.db.getBlocks(), edges: d.db.getEdges() }
    if (d.type === 'mindmap') return d.db.getMindmap()
    if (d.type === 'ishikawa') return d.db.getRoot()
    return d.db.getGraph()
  }
  try {
    for (const bare of ['block\nA["A"]', 'sankey-beta\nA,B,1', 'mindmap\n  root((Root))\n    A', 'ishikawa\nEffect\n  Cause']) {
      const [header, ...body] = bare.split('\n')
      const source = wrapper + [header, 'accTitle: Accessible', 'accDescr {', 'First line', 'Second line', '}', '%% body rationale', ...body].join('\n')
      const parsed = parseMermaid(source)
      if (!parsed.ok || parsed.value.body.kind === 'opaque') throw new Error('Expected editable metadata: ' + source)
      const written = serializeMermaid(parsed.value)
      expect(written.startsWith(wrapper)).toBe(true)
      expect(written.match(/%% body rationale/g)).toHaveLength(1)
      expect(await pin.project(written, project)).toEqual(await pin.project(wrapper + bare, project))
      expect(await pin.publicAccepts(written), written).toBe(true)
      const reload = parseMermaid(written)
      if (!reload.ok) throw new Error('Expected native comment reload')
      expect(reload.value.meta.accessibility).toEqual({ title: 'Accessible', descr: 'First line\nSecond line' })
      expect(reload.value.meta.comments).not.toContainEqual(expect.objectContaining({ text: expect.stringContaining('agentic-mermaid acc') }))
      expect(serializeMermaid(reload.value)).toBe(written)
      expect(renderMermaidSVG(written)).toContain('Accessible</title>')
      expect(renderMermaidSVG(written)).toContain('First line\nSecond line</desc>')
      expect(verifyMermaid(reload.value).warnings).toContainEqual(expect.objectContaining({ code: 'UNSUPPORTED_SYNTAX', syntax: parsed.value.body.kind + '_accessibility' }))
      const kind = parsed.value.body.kind
      const edited = kind === 'block' ? mutate(parsed.value, { kind: 'rename_block', from: 'A', to: 'B' })
        : kind === 'sankey' ? mutate(parsed.value, { kind: 'rename_node', from: 'A', to: 'C' })
        : kind === 'mindmap' ? mutate(parsed.value, { kind: 'rename_node', from: 'A', to: 'B' })
        : kind === 'ishikawa' ? mutate(parsed.value, { kind: 'set_label', id: parsed.value.body.nodes[1]!.id, label: 'Changed' }) : undefined
      if (!edited?.ok) throw new Error('Expected unrelated typed edit: ' + JSON.stringify(edited))
      expect(edited.value.meta.accessibility).toEqual(reload.value.meta.accessibility)
      expect(await pin.publicAccepts(serializeMermaid(edited.value))).toBe(true)
    }
    for (const bare of ['mindmap\n  root((Root))', 'ishikawa\nEffect\n  Cause']) {
      const parsed = parseMermaid(bare)
      if (!parsed.ok) throw new Error('Expected native diagram')
      for (const title of ['literal #44; &amp; ﬂ°12¶ß', '%%{init:{"theme":"dark"}}%% <b>text</b>', 'Product%%cut', 'A\u2028B', 'A\u2029B', 'A<br>B', 'A<br/>B', 'A\nB']) {
        const edited = mutate(parsed.value, { kind: 'set_accessibility_title', title })
        if (!edited.ok) throw new Error('Expected constructive metadata: ' + JSON.stringify(edited))
        const source = serializeMermaid(edited.value)
        expect(await pin.publicAccepts(source), source).toBe(true)
        const reload = parseMermaid(source)
        if (!reload.ok) throw new Error('Expected literal metadata reload')
        expect(reload.value.meta.accessibility.title).toBe(title)
        expect(reload.value.meta.initDirectives).toEqual([])
        const svg = renderMermaidSVG(source)
        expect(decodeXML(svg.match(/<title[^>]*>([\s\S]*?)<\/title>/)![1]!)).toBe(title)
      }
    }
  } finally { pin.close() }
})


test('native metadata owns preprocessing, while moved ordinary comments remain comments', () => {
  for (const bare of ['block\nA["A"]', 'sankey-beta\nA,B,1', 'mindmap\n root((Root))', 'ishikawa\nEffect\n Cause']) {
    for (const title of ['%%{init: {theme: dark}}%%', '%%{wrap}%%', 'A\u2028B', 'A\u2029B', 'A<br/>B']) {
      const native = '%% agentic-mermaid accTitle: ' + JSON.stringify(title) + '\n'
      const parsed = parseMermaid(native + bare)
      if (!parsed.ok) throw new Error('Expected native field read')
      expect(parsed.value.meta.accessibility).toEqual({ title })
      expect(parsed.value.meta.initDirectives).toEqual([])
      expect(parsed.value.meta.frontmatter?.wrap).toBeUndefined()
      const written = serializeMermaid(parsed.value)
      expect(written.match(/%% agentic-mermaid accTitle:/g)).toHaveLength(1)
      const reload = parseMermaid(written)
      if (!reload.ok) throw new Error('Expected metadata reload')
      expect(reload.value.meta.accessibility).toEqual({ title })
      const body = parsed.value.body
      if (body.kind !== 'block' && body.kind !== 'sankey' && body.kind !== 'mindmap' && body.kind !== 'ishikawa') throw new Error('Expected native metadata family')
      const synthesized = synthesizeFromGraph({
        kind: body.kind,
        body: body.kind === 'sankey' ? body : { ...body, accessibilityTitle: title },
        meta: { accessibility: { title } },
      })
      if (!synthesized.ok) throw new Error('Expected JSON metadata construction: ' + JSON.stringify(synthesized))
      expect(synthesized.value.meta.accessibility).toEqual({ title })
      if (parsed.value.kind === 'mindmap' || parsed.value.kind === 'ishikawa') {
        const clear = mutate(parsed.value, { kind: 'set_accessibility_title', title: null })
        if (!clear.ok) throw new Error('Expected leading metadata removal')
        expect(clear.value.meta.accessibility).toEqual({})
      }
      if (parsed.value.kind === 'mindmap') expect(parseMindmap(written).accessibilityTitle).toBe(title)
    }
  }
  for (const bare of ['block\nA["A"]', 'sankey-beta\nA,B,1', 'mindmap\n root((Root))', 'ishikawa\nEffect\n Cause']) {
    for (const [field, expected] of [['&amp;', '&'], ['&amp;amp;', '&amp;'], ['&#35;44;', ','], ['&lt;br&gt;', '<br>'], ['#amp;amp#59;', '&amp;']] as const) {
      const source = '%% agentic-mermaid accTitle: ' + JSON.stringify(field) + '\n' + bare
      const parsed = parseMermaid(source)
      if (!parsed.ok) throw new Error('Expected authored native field')
      expect(parsed.value.meta.accessibility.title).toBe(expected)
      for (const input of [source, serializeMermaid(parsed.value)]) {
        const svg = renderMermaidSVG(input)
        expect(decodeXML(svg.match(/<title[^>]*>([\s\S]*?)<\/title>/)![1]!)).toBe(expected)
      }
    }
  }
  for (const header of ['mindmap', 'mindm&#97;p']) for (const field of ['accTitle', 'accDescr']) {
    const text = `agentic-mermaid ${field}: "Ordinary comment"`
    const parsed = parseMermaid(`${header}\n root((Start\n%% ${text}\nEnd))`)
    if (!parsed.ok) throw new Error('Expected multiline shaped node')
    const written = serializeMermaid(parsed.value)
    const reload = parseMermaid(written)
    if (!reload.ok) throw new Error('Expected ordinary comment reload')
    expect(reload.value.meta.accessibility).toEqual({})
    expect(reload.value.meta.comments).toContainEqual(expect.objectContaining({ text }))
    expect(serializeMermaid(reload.value)).toBe(written)
  }
})


test('leading native metadata keeps exact header, wrapper and directive source ownership', () => {
  for (const ending of ['\n', '\r\n', '\r']) {
    const wrapper = ['---', 'title: Diagram', '---', '%% wrapper rationale', ''].join(ending)
    const native = '%% agentic-mermaid accTitle: "%%{wrap}%% &amp; #35;44; 👩🏽‍💻"' + ending
    const init = ['%%{init: {', '"theme": "dark"', '}}%%', ''].join(ending)
    const source = wrapper + native + init + 'mindmap' + ending + ' root((Root))'
    const parsed = parseMermaid(source)
    if (!parsed.ok) throw new Error('Expected metadata and config before header')
    expect(parsed.value.meta.wrapperSource).toBe(wrapper)
    expect(parsed.value.meta.initDirectives).toHaveLength(1)
    const spans = parsed.value.source.spans!.preserved
    const text = (span: { start: { offset: number }; end: { offset: number } }) => source.slice(span.start.offset, span.end.offset)
    expect(text(spans.header)).toBe('mindmap')
    expect(text(spans.wrapper!)).toBe(wrapper)
    expect(spans.initDirectives?.map(text)).toEqual([init])
    expect(spans.accessibilityDirectives?.map(text)).toEqual([native])
    const reload = parseMermaid(serializeMermaid(parsed.value))
    if (!reload.ok) throw new Error('Expected owned metadata reload')
    expect(reload.value.meta.accessibility).toEqual(parsed.value.meta.accessibility)
    expect(reload.value.meta.initDirectives).toHaveLength(1)
  }
})


test('an enclosing init scalar owns native-looking text even after a literal unclosed opener', () => {
  for (const ending of ['\n', '\r\n', '\r']) for (const title of [undefined, 'ordinary', '%%{init: literal opener']) {
    const prefix = '%% agentic-mermaid accTitle: "A&B"\n'
    const init = ['%%{init:', 'sankey:', '  showValues: true', '  prefix: |', '    ' + prefix.trimEnd(), '}%%', ''].join(ending)
    const native = '%% agentic-mermaid accDescr: "Actual metadata"' + ending
    const leading = title === undefined ? '' : '%% agentic-mermaid accTitle: ' + JSON.stringify(title) + ending
    const source = leading + init + native + 'sankey-beta' + ending + 'A,B,1'
    const parsed = parseMermaid(source)
    if (!parsed.ok) throw new Error('Expected lenient config read')
    expect(parsed.value.meta.accessibility).toEqual({ ...(title === undefined ? {} : { title }), descr: 'Actual metadata' })
    expect(parsed.value.meta.frontmatter?.sankey).toMatchObject({ prefix })
    const spans = parsed.value.source.spans!.preserved
    const slice = (span: { start: { offset: number }; end: { offset: number } }) => source.slice(span.start.offset, span.end.offset)
    expect(spans.initDirectives?.map(slice)).toEqual([init])
    expect(spans.accessibilityDirectives?.map(slice)).toEqual(leading ? [leading, native] : [native])
    const written = serializeMermaid(parsed.value)
    const reloaded = parseMermaid(written)
    if (!reloaded.ok) throw new Error('Expected verbatim config preservation')
    expect(reloaded.value.meta.frontmatter?.sankey).toMatchObject({ prefix })
    expect(decodeXML(renderMermaidSVG(source))).toContain('A&B')
    expect(renderMermaidSVG(source)).not.toContain('A\\u0026B')
  }
})
