import { describe, expect, it } from 'bun:test'
import { renderMermaidASCII, renderMermaidSVG } from '../index.ts'
import { categoricalPalette } from '../shared/categorical-palette.ts'
import { pieSliceColors } from '../pie/palette.ts'
import { getSeriesColor } from '../xychart/colors.ts'
import { mixHex, toHex, tryParseCssColor, wcagContrastRatio } from '../shared/color-math.ts'
import { apcaContrast, minPairwiseDeltaEOK } from '../shared/perceptual-color.ts'

const sources = {
  pie: `pie
  "A" : 1
  "B" : 1
  "C" : 1
  "D" : 1
  "E" : 1
  "F" : 1
  "G" : 1
  "H" : 1`,
  radar: `radar-beta
  axis a, b, c
  curve c1{1, 2, 3}
  curve c2{2, 3, 1}
  curve c3{3, 1, 2}
  curve c4{1, 3, 2}
  curve c5{2, 1, 3}
  curve c6{3, 2, 1}
  curve c7{2, 2, 3}
  curve c8{3, 2, 2}`,
  xychart: `xychart-beta
  x-axis [A, B]
  y-axis 0 --> 10
  line [1, 2]
  line [2, 3]
  line [3, 4]
  line [4, 5]
  line [5, 6]
  line [6, 7]
  line [7, 8]
  line [8, 9]`,
  journey: `journey
  section One
    A: 1: Ada
    B: 2: Ben
    C: 3: Cy
    D: 4: Dee
  section Two
    E: 5: Eve
    F: 4: Fox
    G: 3: Gia
    H: 2: Hal`,
  mindmap: `mindmap
  root((Root))
    A
    B
    C
    D
    E
    F
    G
    H`,
  gitgraph: `gitGraph LR:
  commit id: "root"
  branch a order: 1
  commit id: "a"
  checkout main
  branch b order: 2
  commit id: "b"
  checkout main
  branch c order: 3
  commit id: "c"
  checkout main
  branch d order: 4
  commit id: "d"
  checkout main
  branch e order: 5
  commit id: "e"
  checkout main
  branch f order: 6
  commit id: "f"
  checkout main
  branch g order: 7
  commit id: "g"`,
} as const

function colorsFromSvg(family: keyof typeof sources, svg: string): string[] {
  if (family === 'pie') {
    return [...svg.matchAll(/<path class="pie-slice"[^>]*\sfill="(#[0-9a-f]{6})"/gi)]
      .map(match => match[1]!.toLowerCase())
  }
  if (family === 'radar') {
    return [...svg.matchAll(/<path class="radar-area"[^>]*\sfill="(#[0-9a-f]{6})"/gi)]
      .map(match => match[1]!.toLowerCase())
  }
  if (family === 'xychart') {
    return [...svg.matchAll(/--xychart-color-(\d+):\s*(#[0-9a-f]{6})/gi)]
      .sort((a, b) => Number(a[1]) - Number(b[1])).map(match => match[2]!.toLowerCase())
  }
  if (family === 'journey') {
    const byIndex = new Map<number, string>()
    for (const tag of svg.matchAll(/<circle class="journey-actor-dot journey-actor-(\d+)"[^>]*>/gi)) {
      const color = tag[0].match(/\sfill="(#[0-9a-f]{6})"/i)?.[1]
      if (color) byIndex.set(Number(tag[1]), color.toLowerCase())
    }
    return [...byIndex.entries()].sort((a, b) => a[0] - b[0]).map(([, color]) => color)
  }
  if (family === 'mindmap') {
    const byIndex = new Map<number, string>()
    for (const tag of svg.matchAll(/<path class="mindmap-edge"[^>]+>/gi)) {
      const index = tag[0].match(/data-branch-index="(\d+)"/)?.[1]
      const color = tag[0].match(/stroke="(#[0-9a-f]{6})"/i)?.[1]
      if (index && color) byIndex.set(Number(index), color.toLowerCase())
    }
    return [...byIndex.entries()].sort((a, b) => a[0] - b[0]).map(([, color]) => color)
  }
  return [...svg.matchAll(/<line class="git-branch-line"[^>]*stroke="(#[0-9a-f]{6})"/gi)].map(match => match[1]!.toLowerCase())
}

describe('controlled {1,2,3} categorical palette rollout', () => {
  it('keeps the legacy ladder byte-for-byte for at most six categories wherever it meets the palette contract', () => {
    // The unconditional byte pin this replaces also preserved the ladder's
    // collisions (#0969da at five slices held a pair below ΔE_OK 0.10).
    // Compliant slots, including the authored slot-zero spelling, stay exact.
    const inputs = [
      { accent: '#0969da', bg: '#ffffff' },
      { accent: '#38f', bg: '#fff' },
      { accent: 'royalblue', bg: 'white' },
      { accent: 'rgb(9, 105, 218)', bg: 'rgb(255, 255, 255)' },
    ]
    const concrete = (color: string): string => {
      const [r, g, b] = tryParseCssColor(color)!
      return toHex(r, g, b)
    }
    for (const colors of inputs) {
      for (let count = 1; count <= 6; count++) {
        const ladder = Array.from({ length: count }, (_unused, index) => getSeriesColor(index, colors.accent, colors.bg))
        const palette = categoricalPalette(count, colors)
        expect(palette[0]).toBe(ladder[0])
        if (count > 1) expect(minPairwiseDeltaEOK(palette.map(concrete))).toBeGreaterThanOrEqual(0.10)
        const ladderMeetsContract = count === 1 || minPairwiseDeltaEOK(ladder.map(concrete))! >= 0.10
        if (ladderMeetsContract) expect(palette).toEqual(ladder)
      }
    }
  })

  it('preserves each family-specific low-count CSS compatibility contract', () => {
    const svg = renderMermaidSVG(`mindmap
  root((Root))
    One
    Two`, {
      style: { colors: { bg: '#fff', fg: '#111', accent: '#f00' } },
      embedFontImport: false,
    })
    const firstBranch = [...svg.matchAll(/<path class="mindmap-edge"[^>]+>/gi)]
      .find(match => match[0].includes('data-branch-index="0"'))?.[0]
    expect(firstBranch).toContain('stroke="#f00"')

    // Pie/radar and GitGraph historically required strict six-digit inputs and
    // fell back; their <=6 bytes must not inherit Mindmap/XY's passthrough.
    expect(pieSliceColors(2, { accent: '#f00', bg: '#fff' })).toEqual(
      Array.from({ length: 2 }, (_unused, index) => getSeriesColor(index, '#3b82f6')),
    )
    const gitgraph = renderMermaidSVG(`gitGraph LR:
  commit id: "root"
  branch feature
  commit id: "feature"`, {
      style: { colors: { bg: '#fff', fg: '#111', accent: '#f00' } },
      embedFontImport: false,
    })
    expect(colorsFromSvg('gitgraph', gitgraph)).toEqual(
      categoricalPalette(2, { accent: '#3b82f6', bg: '#ffffff' }),
    )
  })

  it("keeps Journey's established low-cardinality actor colors", () => {
    const svg = renderMermaidSVG(`journey
  section Existing
    A: 1: Ada
    B: 2: Ben
    C: 3: Cy
    D: 4: Dee
    E: 5: Eve`, { embedFontImport: false })
    expect(colorsFromSvg('journey', svg)).toEqual([
      '#34438d', '#8d3f34', '#348d59', '#74348d', '#8d8d34',
    ])
  })

  it('reaches each selected SVG family and clears the perceptual contracts', () => {
    for (const [family, source] of Object.entries(sources) as Array<[keyof typeof sources, string]>) {
      const colors = colorsFromSvg(family, renderMermaidSVG(source, { style: 'dracula', embedFontImport: false }))
      expect(colors, family).toHaveLength(8)
      expect(new Set(colors).size, family).toBe(8)
      expect(minPairwiseDeltaEOK(colors), family).toBeGreaterThanOrEqual(0.10)
      for (const color of colors) {
        expect(wcagContrastRatio(color, '#282a36')!, `${family}: ${color}`).toBeGreaterThanOrEqual(1.25)
        expect(Math.abs(apcaContrast(color, '#282a36')!), `${family}: ${color}`).toBeGreaterThanOrEqual(15)
      }
    }
  })

  it('repairs an invisible XY accent consistently in SVG and terminal output', () => {
    const style = { colors: { bg: '#ffffff', fg: '#111111', accent: '#ffffff' } } as const
    const expected = categoricalPalette(8, { accent: '#ffffff', bg: '#ffffff' })
    const svg = renderMermaidSVG(sources.xychart, { style, embedFontImport: false })
    const svgColors = colorsFromSvg('xychart', svg)
    const terminal = renderMermaidASCII(sources.xychart, { style, colorMode: 'html' })

    expect(expected[0]).toBe('#aee2ff')
    expect(svgColors).toEqual(expected)
    expect(terminal).toContain('color:#aee2ff')
    expect(wcagContrastRatio(svgColors[0]!, '#ffffff')).toBeGreaterThanOrEqual(1.25)
    expect(apcaContrast(svgColors[0]!, '#ffffff')).toBeGreaterThanOrEqual(15)
  })

  it('normalizes supported concrete CSS colors before public-renderer repair', () => {
    const cases = [
      { css: '#38f', hex: '#3388ff' },
      { css: 'royalblue', hex: '#4169e1' },
      { css: 'rgb(51, 136, 255)', hex: '#3388ff' },
      { css: 'hsl(217, 100%, 60%)', hex: '#3381ff' },
      { css: 'hsl(0.6027777777777777turn 100% 60%)', hex: '#3381ff' },
    ]
    for (const { css, hex } of cases) {
      const style = { colors: { bg: css, fg: '#111111', accent: css } } as const
      const expected = categoricalPalette(8, { accent: css, bg: css })
      for (const [family, source] of Object.entries(sources) as Array<[keyof typeof sources, string]>) {
        const svgColors = colorsFromSvg(family, renderMermaidSVG(source, { style, embedFontImport: false }))
        expect(svgColors, `${family}/${css}`).toEqual(expected)
        expect(new Set(svgColors).size, `${family}/${css}`).toBe(8)
        expect(minPairwiseDeltaEOK(svgColors), `${family}/${css}`).toBeGreaterThanOrEqual(0.10)
        for (const color of svgColors) {
          expect(wcagContrastRatio(color, hex)!, `${family}/${css}: ${color}`).toBeGreaterThanOrEqual(1.25)
          expect(Math.abs(apcaContrast(color, hex)!), `${family}/${css}: ${color}`).toBeGreaterThanOrEqual(15)
        }
      }
      for (const color of categoricalPalette(25, { accent: css, bg: css })) {
        expect(wcagContrastRatio(color, hex)!, `${css} linear tail: ${color}`).toBeGreaterThanOrEqual(1.25)
        expect(Math.abs(apcaContrast(color, hex)!), `${css} linear tail: ${color}`).toBeGreaterThanOrEqual(15)
      }
    }

    const css = '#38f'
    const expected = categoricalPalette(8, { accent: css, bg: css })
    const style = { colors: { bg: css, fg: '#111', accent: css } } as const
    const gitgraphSvg = colorsFromSvg('gitgraph', renderMermaidSVG(sources.gitgraph, { style, embedFontImport: false }))
    const gitgraphTerminal = renderMermaidASCII(sources.gitgraph, { style, colorMode: 'html' })
    expect(gitgraphSvg).toEqual(expected)
    for (const color of expected) expect(gitgraphTerminal).toContain(`color:${color}`)

    const journeyTen = `journey
  section Team
    A: 1: Ada
    B: 2: Ben
    C: 3: Cy
    D: 4: Dee
    E: 5: Eve
    F: 4: Fox
    G: 3: Gia
    H: 2: Hal
    I: 1: Ian
    J: 2: Joy`
    const ten = colorsFromSvg('journey', renderMermaidSVG(journeyTen, { style, embedFontImport: false }))
    expect(ten).toEqual(categoricalPalette(10, { accent: css, bg: css }))

    const journeySections = `journey
  section One
    A: 1: Ada
  section Two
    B: 2: Ben
  section Three
    C: 3: Cy
  section Four
    D: 4: Dee
  section Five
    E: 5: Eve
  section Six
    F: 4: Fox
  section Seven
    G: 3: Gia
  section Eight
    H: 2: Hal`
    const sectionSvg = renderMermaidSVG(journeySections, { style, embedFontImport: false })
    const sectionFills = [...sectionSvg.matchAll(/<rect class="journey-section-bg journey-section-(\d+)"[^>]*\sfill="(#[0-9a-f]{6})"/gi)]
      .sort((a, b) => Number(a[1]) - Number(b[1]))
      .map(match => match[2]!.toLowerCase())
    expect(sectionFills).toEqual(expected.map((base, index) => mixHex(base, '#3388ff', index === 0 ? 8 : 9)))
  })

  it('is deterministic and does not use a fixed-size modulo palette', () => {
    const first = categoricalPalette(24, { accent: '#4493f8', bg: '#0d1117' })
    expect(first).toEqual(categoricalPalette(24, { accent: '#4493f8', bg: '#0d1117' }))
    expect(new Set(first).size).toBe(24)
  })
})

it('watercolor keyed marks and legends retain distinguishable categorical paint', () => {
  const attributes = (tag: string) => new Map([...tag.matchAll(/([\w-]+)="([^"]*)"/g)].map(match => [match[1]!, match[2]!]))
  const pie = renderMermaidSVG('pie\n "A": 3\n "B": 2\n "C": 1', { style: 'watercolor' })
  const marks = [...pie.matchAll(/<path[^>]*data-role="pie-slice"[^>]*>/g)].map(match => attributes(match[0]))
  const keys = [...pie.matchAll(/<rect[^>]*class="pie-legend-swatch"[^>]*>/g)].map(match => attributes(match[0]))
  expect(marks).toHaveLength(3)
  expect(keys).toHaveLength(3)
  expect(marks.map(mark => mark.get('fill-opacity'))).toEqual(['1', '1', '1'])
  expect(marks.map(mark => mark.get('fill'))).toEqual(keys.map(key => key.get('fill')))
  expect(minPairwiseDeltaEOK(marks.map(mark => mark.get('fill')!))).toBeGreaterThanOrEqual(0.10)

  const journey = renderMermaidSVG('journey\n section One\n A:3:Ada\n B:4:Ben\n C:5:Cy', { style: 'watercolor' })
  const dots = [...journey.matchAll(/<path[^>]*data-role="actor"[^>]*>/g)].map(match => attributes(match[0]))
  expect(dots).toHaveLength(6)
  expect(dots.every(dot => dot.get('fill-opacity') === '1')).toBe(true)
  expect(new Set(dots.map(dot => dot.get('fill'))).size).toBe(3)

  const radar = renderMermaidSVG('radar-beta\n axis a,b,c\n curve A{1,2,3}\n curve B{3,2,1}\n curve C{2,1,3}', { style: 'watercolor' })
  const radarKeys = [...radar.matchAll(/<rect[^>]*class="radar-legend-swatch"[^>]*>/g)].map(match => attributes(match[0]))
  expect(radarKeys).toHaveLength(3)
  expect(radarKeys.every(key => key.get('fill-opacity') === '1')).toBe(true)
  expect(minPairwiseDeltaEOK(radarKeys.map(key => key.get('fill')!))).toBeGreaterThanOrEqual(0.10)
})
