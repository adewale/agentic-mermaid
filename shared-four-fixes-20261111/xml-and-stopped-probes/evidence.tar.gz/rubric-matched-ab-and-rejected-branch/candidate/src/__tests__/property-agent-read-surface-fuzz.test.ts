// Property fuzz for the agent "read" surface — the source-in functions an agent calls to
// inspect a diagram it did not author: describeMermaidSource, describeMermaidFactsSource,
// analyzeMermaidSource, checkMermaidSource, and asciiToMermaid. These take UNTRUSTED strings
// (and, for checkMermaidSource, an untrusted spec). property-crash-freedom covers the parsers;
// this closes the gap that the describe/facts/analyze/check/reverse *readers* had no
// generated-input coverage. Contracts:
//   • total: never throw on any string / any spec — return a value or a tagged Result.
//   • deterministic: two calls on the same input are byte-identical (guards a Date.now()/
//     Math.random() leak into agent-facing output, which cross-run determinism gates on the
//     layout JSON would not catch on these text/JSON readers).
// Seed pinned globally (fc-seed.preload.ts); AM_FC_SEED=random hunts fresh counterexamples.
import { describe, expect, it } from 'bun:test'
import fc from 'fast-check'
import { fcParameters } from './helpers/fc-parameters.ts'

import {
  describeMermaidSource, describeMermaidFactsSource, analyzeMermaidSource, checkMermaidSource,
  asciiToMermaid, parseRegisteredMermaid as parseMermaid, serializeMermaid,
  describeMermaid, describeMermaidTree, describeMermaidFacts, analyzeMermaid, checkMermaid,
} from '../agent/index.ts'
import { BUILTIN_FAMILY_METADATA } from '../agent/families.ts'
import type { DiagramKind } from '../agent/types.ts'
import { METAMORPHIC_FAMILIES } from './helpers/metamorphic-families.ts'

const NUM_RUNS = 250

const SPECIAL_CHARS = [
  '[', ']', '{', '}', '(', ')', '<', '>', '|', ':', ';', '-', '=', '.', ',', '!', '?', '@',
  '#', '$', '%', '^', '&', '*', '+', '~', '`', '"', "'", '\\', '/', '\n', '\r', '\t', ' ',
  '\0', '￿', '​', 'é', '☃', '-->', '==>', 'graph', 'end', 'subgraph',
]
const specialStringArb = fc.array(fc.constantFrom(...SPECIAL_CHARS), { maxLength: 60 }).map(c => c.join(''))
// Every registered header keyword plus each family's example header line, from the
// registry: the hand-written list this replaces had no radar or sankey header.
const headers = [...new Set(BUILTIN_FAMILY_METADATA.flatMap(family => [...family.headers, family.example.split('\n')[0]!]))]
// Header + random body: exercises the "valid-family-then-garbage" path, where readers do real
// projection work rather than bailing at the family-detection gate.
const sourceArb = fc.oneof(
  fc.string({ maxLength: 200 }),
  specialStringArb,
  fc.tuple(fc.constantFrom(...headers), fc.string({ maxLength: 160 })).map(([h, b]) => `${h}\n${b}`),
  fc.tuple(fc.constantFrom(...headers), specialStringArb).map(([h, b]) => `${h}\n${b}`),
)

const specArb = fc.oneof(
  fc.array(fc.string({ maxLength: 20 }), { maxLength: 6 }),
  fc.record({
    include: fc.array(fc.string({ maxLength: 16 }), { maxLength: 4 }),
    exclude: fc.array(fc.string({ maxLength: 16 }), { maxLength: 4 }),
    exact: fc.boolean(),
  }, { requiredKeys: [] }),
  fc.object({ maxDepth: 2 }),
  fc.anything(),
)

// The source-in readers are "safe" APIs: they return a value or a tagged Result for ANY input
// and must NEVER throw (unlike the raw parsers, whose crash-freedom convention tolerates a
// clean Error). So this helper does not swallow throws — a throw fails the property, which is
// exactly how the checkMermaid(null) TypeError was caught.
function assertTotalAndDeterministic<T>(fn: () => T, shape: (v: T) => void): void {
  const first = fn()
  shape(first)
  // Determinism: a second call must be byte-identical (guards a Date.now()/Math.random() leak).
  const second = fn()
  expect(JSON.stringify(second)).toBe(JSON.stringify(first))
}

describe('read-surface fuzz: source readers are total and deterministic', () => {
  it('describeMermaidSource', () => {
    fc.assert(fc.property(sourceArb, src => {
      assertTotalAndDeterministic(() => describeMermaidSource(src), v => expect(typeof v).toBe('string'))
    }), fcParameters({ numRuns: NUM_RUNS }))
  })

  it('describeMermaidFactsSource', () => {
    fc.assert(fc.property(sourceArb, src => {
      assertTotalAndDeterministic(() => describeMermaidFactsSource(src), v => {
        expect(typeof v.ok).toBe('boolean')
        if (v.ok) expect(Array.isArray(v.value)).toBe(true)
      })
    }), fcParameters({ numRuns: NUM_RUNS }))
  })

  it('analyzeMermaidSource', () => {
    fc.assert(fc.property(sourceArb, src => {
      assertTotalAndDeterministic(() => analyzeMermaidSource(src), v => expect(typeof v.ok).toBe('boolean'))
    }), fcParameters({ numRuns: NUM_RUNS }))
  })

  it('checkMermaidSource tolerates an arbitrary spec', () => {
    fc.assert(fc.property(sourceArb, specArb, (src, spec) => {
      assertTotalAndDeterministic(() => checkMermaidSource(src, spec as never), v => {
        expect(typeof v.ok).toBe('boolean')
        if (v.ok) expect(typeof v.value.ok).toBe('boolean')
      })
    }), fcParameters({ numRuns: NUM_RUNS }))
  })

  it('asciiToMermaid', () => {
    fc.assert(fc.property(fc.oneof(fc.string({ maxLength: 200 }), specialStringArb), ascii => {
      assertTotalAndDeterministic(() => asciiToMermaid(ascii), v => expect(typeof v.ok).toBe('boolean'))
    }), fcParameters({ numRuns: NUM_RUNS }))
  })
})

// A valid diagram per family, with content, in canonical source, so the typed readers run
// their full projection over real content. (The empty `createMermaid` base does not do: an
// empty pie, xychart or radar serializes to a bare header that reparses as opaque, which
// used to skip those three families silently.) The family list comes from the registry; the
// hand-written one it replaces had left sankey out.
const FAMILIES = BUILTIN_FAMILY_METADATA.map(family => family.id) as DiagramKind[]
const CORPUS = FAMILIES.map(fam => {
  const generator = METAMORPHIC_FAMILIES[fam]
  const parsed = parseMermaid(generator.build(generator.kRange[0], 'q'))
  if (!parsed.ok) throw new Error(`${fam}: metamorphic base build failed to parse`)
  return serializeMermaid(parsed.value)
})

describe('read-surface fuzz: typed readers deterministic over the family corpus', () => {
  it('describe / describeTree / facts / analyze / checkMermaid are byte-stable per diagram', () => {
    fc.assert(fc.property(fc.constantFrom(...CORPUS), specArb, (source, spec) => {
      const parsed = parseMermaid(source)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) return
      const d = parsed.value
      // parseMermaid yields structured families or an opaque fallback; the typed readers below
      // require a ValidDiagram (non-opaque). Every CORPUS entry must be a structured family.
      expect({ source, body: d.body.kind === 'opaque' ? 'opaque' : 'structured' }).toEqual({ source, body: 'structured' })
      if (d.body.kind === 'opaque') return
      const valid = d as never
      expect(describeMermaid(valid)).toBe(describeMermaid(valid))
      expect(JSON.stringify(describeMermaidTree(valid))).toBe(JSON.stringify(describeMermaidTree(valid)))
      expect(describeMermaidFacts(valid)).toEqual(describeMermaidFacts(valid))
      expect(JSON.stringify(analyzeMermaid(valid))).toBe(JSON.stringify(analyzeMermaid(valid)))
      expect(JSON.stringify(checkMermaid(valid, spec as never))).toBe(JSON.stringify(checkMermaid(valid, spec as never)))
    }), fcParameters({ numRuns: NUM_RUNS }))
  })
})
