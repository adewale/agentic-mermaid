// Gantt agent surface (docs/design/families/gantt.md §Test tiers, agent row):
// parseMermaid detects kind:'gantt'; the segment-preserving structured body
// keeps directives/click/comment lines VERBATIM while exposing typed ops on
// title/sections/tasks; serialize is idempotent; every declared op
// round-trips through mutate; whole-opaque fallbacks round-trip
// byte-verbatim; fast-check round-trip property; verify warnings
// (EMPTY_DIAGRAM / LABEL_OVERFLOW / EDGE_MISANCHORED); capabilities and a
// differential check against the renderer-grade parser.

import { describe, expect, test } from 'bun:test'
import fc from 'fast-check'
import { analyzeMermaid } from '../agent/analyze.ts'
import { describeMermaid } from '../agent/describe.ts'
import { ganttGeometryWarnings } from '../agent/family-layouts.ts'
import { layoutMermaid, renderMermaidASCIIWithMeta, renderMermaidSVG } from '../agent/index.ts'
import { mutate } from '../agent/mutate.ts'
import { parseRegisteredMermaid as parseMermaid } from '../agent/parse.ts'
import { serializeMermaid } from '../agent/serialize.ts'
import type { GanttBodyTaskTag, GanttMutationOp, GanttValidDiagram } from '../agent/types.ts'
import { asGantt } from '../agent/types.ts'
import { verifyMermaid } from '../agent/verify.ts'
import { parseGanttModel } from '../gantt/parser.ts'
import { resolveGanttSchedule } from '../gantt/schedule.ts'
import { renderMermaidASCII as renderSourceASCII, renderMermaidSVG as renderSourceSVG } from '../index.ts'
import { normalizeMermaidSource } from '../mermaid-source.ts'
import { projectEntityMarkers } from '../shared/mermaid-entity-display.ts'
import { fcParameters } from './helpers/fc-parameters.ts'
import { startUpstreamMermaid } from './helpers/upstream-mermaid.ts'
import { useTestChildren } from './helpers/test-child.ts'

const runChild = useTestChildren(20_000)

const SRC = `gantt
  title Release plan
  dateFormat YYYY-MM-DD
  excludes weekends
  section Build
    Core engine :core, 2024-01-01, 10d
    Polish :pol, after core, 5d
  section Ship
    Release :milestone, rel, after pol, 0d
  click core href "https://example.com/core"
`

test('task metadata beginning with percent retains a lexical separator after the colon', async () => {
  const source = 'gantt\n  Task : %H:%M'
  const parsed = gantt(source)
  expect(parsed.body.sections[0]!.tasks[0]!.end).toBe('%H:%M')
  const canonical = serializeMermaid(parsed)
  const upstream = startUpstreamMermaid()
  try {
    expect(await upstream.accepts(source)).toBe(true)
    expect(await upstream.accepts(canonical)).toBe(true)
  } finally {
    upstream.close()
  }
  expect(gantt(canonical).body).toEqual(parsed.body)
})

function gantt(src: string = SRC): GanttValidDiagram {
  const r = parseMermaid(src)
  if (!r.ok) throw new Error('parse: ' + JSON.stringify(r.error))
  const g = asGantt(r.value)
  if (!g) throw new Error('not a structured gantt: ' + r.value.body.kind)
  return g
}

function apply(d: GanttValidDiagram, op: GanttMutationOp): GanttValidDiagram {
  const r = mutate(d, op)
  if (!r.ok) throw new Error('mutate: ' + JSON.stringify(r.error))
  return r.value
}

// Internal section/task ids are parse-order counters ("stable within one
// parse; not a durable identifier"), so post-mutation re-parse comparisons
// use the durable shape: labels, Mermaid taskIds, tags, dates, statements.
function shape(d: GanttValidDiagram) {
  return {
    title: d.body.title,
    sections: d.body.sections.map(s => ({
      label: s.label,
      tasks: s.tasks.map(({ id: _id, ...rest }) => rest),
    })),
    statements: d.body.statements,
  }
}

describe('gantt structured parse', () => {
  test('literal directive words retain task meaning, dependencies, and dates through portable export and typed edits', async () => {
    const upstream = startUpstreamMermaid()
    try {
      for (const label of ['call', 'Call', 'title', 'section', 'accDescription', 'ganttish', '2014-01-01a', 'call-me', 'href', 'accDescription #']) {
        const source = `gantt\n  ${label}:a, 2024-01-01, 2d\n  Ship :ship, after a, 1d\n`
        const diagram = gantt(source)
        const exported = serializeMermaid(diagram)
        expect(gantt(exported).body, label).toEqual(diagram.body)
        const reference = await upstream.project(exported, d => d.db.getTasks().map((task: any) => ({
          label: task.task.trim(), id: task.id, start: task.startTime.toISOString(), end: task.endTime.toISOString(),
        })))
        if (!reference.ok) throw new Error('Expected pinned Gantt tasks')
        expect(reference.value.map((task: { label: string }) => ({ ...task, label: projectEntityMarkers(task.label) })), label).toEqual([
          { label, id: 'a', start: '2024-01-01T00:00:00.000Z', end: '2024-01-03T00:00:00.000Z' },
          { label: 'Ship', id: 'ship', start: '2024-01-03T00:00:00.000Z', end: '2024-01-04T00:00:00.000Z' },
        ])
        expect(renderSourceSVG(exported), label).toBe(renderSourceSVG(source))
        expect(renderSourceASCII(exported), label).toBe(renderSourceASCII(source))
        const edited = apply(gantt('gantt\n  Build :a, 2024-01-01, 2d\n  Ship :ship, after a, 1d\n'), { kind: 'rename_task', sectionIndex: 0, taskIndex: 0, label })
        const reloaded = gantt(serializeMermaid(edited))
        expect(reloaded.body.sections[0]!.tasks.map(task => [task.label, task.taskId, task.start, task.end])).toEqual([
          [label, 'a', '2024-01-01', '2d'], ['Ship', 'ship', 'after a', '1d'],
        ])
        const schedule = resolveGanttSchedule(parseGanttModel(normalizeMermaidSource(serializeMermaid(reloaded)).lines))
        expect(schedule.tasks.map(task => [task.start, task.end])).toEqual([
          [Date.UTC(2024, 0, 1), Date.UTC(2024, 0, 3)], [Date.UTC(2024, 0, 3), Date.UTC(2024, 0, 4)],
        ])
      }
    } finally {
      upstream.close()
    }
  })

  test('directive-like task text remains editable with its native schedule', async () => {
    const source = 'gantt\n  Build :build, 2024-01-01, 2d\n  ki%%{wi :ship, after build, 1d\n'
    const parsed = parseMermaid(source)
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) throw Error(JSON.stringify(parsed.error))
    if (parsed.value.body.kind !== 'gantt') throw new Error('Expected editable Gantt')
    expect(parsed.value.body.kind).toBe('gantt')
    const written = serializeMermaid(parsed.value)
    expect(gantt(written).body).toEqual(parsed.value.body)
    expect(renderMermaidSVG(parsed.value)).toBe(renderSourceSVG(source))
    expect(renderSourceASCII(source)).toContain('ki%%{wi')
    for (const op of [{ kind: 'set_title', title: '%%{literal' }, { kind: 'rename_section', index: 0, label: '%%{literal' }] as const) expect(mutate(gantt(), op).ok).toBe(false)
    const upstream = startUpstreamMermaid()
    try {
      expect(await upstream.publicAccepts(source)).toBe(false)
      expect(await upstream.publicAccepts(written)).toBe(true)
    } finally { upstream.close() }
  })

  test.each(['alien content', 'topAxis :2024-01-01, 2d'])('preserves unsupported %s during an edit without drawing it as a task', unsupported => {
    const source = `gantt\n  Build :build, 2024-01-01, 2d\n  %% keep this note\n  ${unsupported}\n  Ship :ship, after build, 1d\n`
    const diagram = gantt(source)
    expect(diagram.body.sections.flatMap(section => section.tasks).map(task => task.label)).toEqual(['Build', 'Ship'])
    const edited = apply(diagram, { kind: 'rename_task', sectionIndex: 0, taskIndex: 1, label: 'Release' })
    const canonical = serializeMermaid(edited)
    expect(canonical).toContain(`  %% keep this note\n  ${unsupported}\n  Release :ship, after build, 1d\n`)
    expect(gantt(canonical).body.sections[0]!.tasks.map(task => task.label)).toEqual(['Build', 'Release'])
    expect(() => renderMermaidSVG(canonical)).toThrow(`Unrecognized gantt line "${unsupported}"`)
    const verified = verifyMermaid(edited)
    expect(verified.ok).toBe(false)
    expect(verified.warnings).toContainEqual(
      expect.objectContaining({
        code: 'UNRESOLVABLE_SCHEDULE',
        reason: expect.stringContaining(`Unrecognized gantt line "${unsupported}"`),
      }),
    )
  })

  test.each([
    ['task', '  accDescr { description } Ship :ship, 2024-01-01, 2d', undefined],
    ['section', '  accDescr { description } section Delivery\n  Ship :ship, 2024-01-01, 2d', 'Delivery'],
  ] as const)('consumes an accessibility-block suffix %s through the public render and edit paths', (_kind, body, sectionLabel) => {
    const source = `gantt\n${body}\n`
    const diagram = gantt(source)
    expect(diagram.body.sections.map(section => section.label)).toEqual([sectionLabel])
    expect(diagram.body.sections[0]!.tasks).toMatchObject([{ label: 'Ship', taskId: 'ship', start: '2024-01-01', end: '2d' }])
    const svg = renderMermaidSVG(source)
    expect(svg).toMatch(/<text\b[^>]*>Ship<\/text>/)
    expect(svg).toContain('<desc')
    expect(svg).toContain('description</desc>')
    if (sectionLabel) {
      // Legacy maps use normalized columns; exact spans use authored offsets.
      expect(diagram.source.groups.get('section-0')).toEqual({ line: 2, col: 34 })
      expect(diagram.source.labels.get('gantt:section-0:label')).toEqual({ line: 2, col: 34 })
      const span = diagram.source.spans?.labels.get('gantt:section-0:label')
      expect(span).toBeDefined()
      expect(source.slice(span!.start.offset, span!.end.offset)).toBe('Delivery')
    }
    const edited = apply(diagram, { kind: 'rename_task', sectionIndex: 0, taskIndex: 0, label: 'Release' })
    const serialized = serializeMermaid(edited)
    expect(gantt(serialized).body.sections[0]!.tasks[0]!.label).toBe('Release')
    expect(renderMermaidSVG(serialized)).toMatch(/<text\b[^>]*>Release<\/text>/)
    expect(verifyMermaid(edited).ok).toBe(true)
  })

  test('inline task comments do not change dates, and survive a neighboring task edit', () => {
    const source = 'gantt\n  Build :build, 2024-01-01, 2d %% duration, not a date\n  Ship :ship, after build, 1d\n'
    const d = gantt(source)
    expect(d.body.sections[0]!.tasks.map(({ taskId, start, end }) => ({ taskId, start, end }))).toEqual([
      { taskId: 'build', start: '2024-01-01', end: '2d' },
      { taskId: 'ship', start: 'after build', end: '1d' },
    ])
    const model = parseGanttModel(normalizeMermaidSource(source).lines)
    expect(model.tasks[0]!.end).toEqual({ kind: 'duration', raw: '2d' })
    expect(verifyMermaid(d).warnings).toContainEqual(
      expect.objectContaining({
        code: 'UNSUPPORTED_SYNTAX',
        syntax: 'gantt_inline_task_comment',
        line: 2,
      }),
    )
    const schedule = resolveGanttSchedule(model)
    expect(schedule.tasks.map(task => task.end - task.start)).toEqual([2 * 86_400_000, 86_400_000])
    const edited = apply(d, { kind: 'rename_task', sectionIndex: 0, taskIndex: 1, label: 'Release' })
    const canonical = serializeMermaid(edited)
    expect(canonical).toContain('  Build :build, 2024-01-01, 2d\n%% duration, not a date\n  Release :ship, after build, 1d\n')
    expect(gantt(canonical).body.sections[0]!.tasks[0]!.end).toBe('2d')
    expect(verifyMermaid(edited).ok).toBe(true)
    expect(verifyMermaid(edited).warnings.map(warning => warning.code)).not.toContain('UNSUPPORTED_SYNTAX')
  })

  test('detects kind gantt and models title/sections/tasks', () => {
    const d = gantt()
    expect(d.kind).toBe('gantt')
    expect(d.body.kind).toBe('gantt')
    expect(d.body.title).toBe('Release plan')
    expect(d.body.sections.map(s => s.label)).toEqual(['Build', 'Ship'])
    expect(d.body.sections[0]!.tasks.map(t => t.label)).toEqual(['Core engine', 'Polish'])
    expect(d.body.sections[0]!.tasks[0]).toMatchObject({ taskId: 'core', start: '2024-01-01', end: '10d' })
    expect(d.body.sections[0]!.tasks[1]).toMatchObject({ start: 'after core', end: '5d' })
    expect(d.body.sections[1]!.tasks[0]!.tags).toEqual(['milestone'])
  })

  test('directives, click lines, and comments ride along as verbatim opaque segments', () => {
    const d = gantt()
    const opaque = d.body.statements!.filter(s => s.kind === 'opaque-block').flatMap(s => (s.kind === 'opaque-block' ? s.lines : []))
    expect(opaque).toContain('  dateFormat YYYY-MM-DD')
    expect(opaque).toContain('  excludes weekends')
    expect(opaque).toContain('  click core href "https://example.com/core"')
    // ...and serialization re-emits them byte-verbatim, in position.
    const out = serializeMermaid(d)
    expect(out).toContain('  dateFormat YYYY-MM-DD\n')
    expect(out).toContain('  excludes weekends\n')
    expect(out).toContain('  click core href "https://example.com/core"\n')
    expect(out.indexOf('dateFormat')).toBeLessThan(out.indexOf('section Build'))
  })

  // Mermaid reads the href only on the line after the task id; ours also
  // reads it after blank or comment lines, which the renderer never sees.
  test.each([
    ['the next line', ['  click a1', '    href "https://x.y"']],
    ['a line after a blank line', ['  click a1', '', '    href "https://x.y"']],
    ['a line after a comment', ['  click a1', '  %% note', '    href "https://x.y"']],
  ])('a click whose href starts %s renders and rides along as one statement', (_where, click) => {
    const source = `gantt\n  dateFormat YYYY-MM-DD\n  section S\n  Task :a1, 2024-01-01, 3d\n${click.join('\n')}\n  Next :a2, after a1, 1d\n`
    const d = gantt(source)
    expect(d.body.sections[0]!.tasks.map(task => task.label)).toEqual(['Task', 'Next'])
    expect(d.body.statements!.filter(s => s.kind === 'opaque-block').at(-1)).toEqual({ kind: 'opaque-block', lines: click })
    expect(serializeMermaid(d)).toContain(`${click.join('\n')}\n`)
    expect(verifyMermaid(d).warnings).toEqual([])
  })

  // Mermaid ends a task's data, and a date or format value, at `;` and reads
  // what follows into the next task's label; ours reads the next statement,
  // reports the `;`, and writes each statement on its own line. Each task's
  // spans cover its own statement and label.
  test.each([
    ['Task :a1, 2024-01-01, 3d; Task2 :a2, after a1, 2d', ['Task', 'Task2'], ['Task :a1, 2024-01-01, 3d', 'Task2 :a2, after a1, 2d'], undefined],
    ['Task :a1, 2024-01-01, 3d;', ['Task'], ['Task :a1, 2024-01-01, 3d'], undefined],
    ['dateFormat YYYY-MM-DD; title T\n  Task :a1, 2024-01-01, 3d', ['Task'], ['Task :a1, 2024-01-01, 3d'], 'T'],
    ['dateFormat YYYY-MM-DD; Task :a1, 2024-01-01, 3d', ['Task'], ['Task :a1, 2024-01-01, 3d'], undefined],
  ])('%j reads each `;`-separated statement and reports the `;`', async (body, labels, statements, title) => {
    const source = `gantt\n  dateFormat YYYY-MM-DD\n  ${body}\n`
    const d = gantt(source)
    expect(parseGanttModel(normalizeMermaidSource(source).lines).tasks.map(task => task.label)).toEqual(labels)
    const tasks = d.body.sections.flatMap(section => section.tasks)
    expect(tasks.map(task => task.label)).toEqual(labels)
    const text = (span: { start: { offset: number }; end: { offset: number } } | undefined) => span && source.slice(span.start.offset, span.end.offset)
    expect(tasks.map(task => text(d.source.spans?.labels.get(`gantt:task:${task.taskId}`)))).toEqual(labels)
    expect(tasks.map(task => text(d.source.spans?.nodes.get(task.taskId!)))).toEqual(statements)
    expect(d.body.title).toBe(title)
    expect(
      verifyMermaid(d)
        .warnings.filter(w => w.code === 'UNSUPPORTED_SYNTAX')
        .map(w => (w as { syntax: string }).syntax),
    ).toEqual(['gantt_semicolon_separator'])
    const out = serializeMermaid(d)
    const upstream = startUpstreamMermaid()
    try {
      expect(await upstream.accepts(out), out).toBe(true)
    } finally {
      upstream.close()
    }
    expect(gantt(out).body).toEqual(d.body)
  })

  test('a todayMarker keeps the `;` of its CSS', () => {
    const d = gantt('gantt\n  dateFormat YYYY-MM-DD\n  todayMarker stroke:#f00;stroke-width:2px\n  Task :a1, 2024-01-01, 3d\n')
    expect(serializeMermaid(d)).toContain('  todayMarker stroke:#f00;stroke-width:2px\n')
    expect(verifyMermaid(d).warnings.filter(w => w.code === 'UNSUPPORTED_SYNTAX')).toEqual([])
  })

  test('serialize is idempotent and bodies are equal across cycles', () => {
    const d = gantt()
    const s1 = serializeMermaid(d)
    const d2 = gantt(s1)
    expect(serializeMermaid(d2)).toBe(s1)
    expect(d2.body).toEqual(d.body)
  })

  test('tasks before any section land in an implicit unlabeled section', () => {
    const d = gantt('gantt\n  Loose :l1, 2024-01-01, 2d\n  section Named\n    Inside :i1, after l1, 1d')
    expect(d.body.sections).toHaveLength(2)
    expect(d.body.sections[0]!.label).toBeUndefined()
    expect(d.body.sections[0]!.tasks[0]!.label).toBe('Loose')
  })
})

describe('gantt lexical text and structure-level failures', () => {
  test('keyword-like task labels remain editable without changing scheduling or drawing', async () => {
    const upstream = startUpstreamMermaid()
    try {
      for (const label of ['gantt', 'gantt-plan', 'ki%%{wi', '2014-01-01', '2014-01-01 later', 'href "', 'call worker', 'accDescription text']) {
        const source = `gantt\n  Build :a, 2024-01-01, 2d\n  ${label}:b, after a, 1d\n  Ship :ship, after b, 1d\n`
        expect(await upstream.accepts(source), label).toBe(false)
        const parsed = parseMermaid(source)
        if (!parsed.ok) throw new Error('Expected source-preserved Gantt')
        if (parsed.value.body.kind !== 'gantt') throw new Error('Expected editable Gantt')
        expect(parsed.value.body.kind, label).toBe('gantt')
        const written = serializeMermaid(parsed.value)
        expect(await upstream.accepts(written), written).toBe(true)
        expect(gantt(written).body, label).toEqual(parsed.value.body)
        const schedule = resolveGanttSchedule(parseGanttModel(normalizeMermaidSource(source).lines))
        expect(schedule.tasks.map(task => [task.label, task.id, task.start, task.end]), label).toEqual([
          ['Build', 'a', Date.UTC(2024, 0, 1), Date.UTC(2024, 0, 3)],
          [label, 'b', Date.UTC(2024, 0, 3), Date.UTC(2024, 0, 4)],
          ['Ship', 'ship', Date.UTC(2024, 0, 4), Date.UTC(2024, 0, 5)],
        ])
        expect(renderMermaidSVG(parsed.value), label).toBe(renderSourceSVG(source))
        expect(renderMermaidASCIIWithMeta(parsed.value, { useAscii: true, colorMode: 'none' }).ascii, label).toBe(renderSourceASCII(source, { useAscii: true, colorMode: 'none' }))
        expect(verifyMermaid(parsed.value).warnings, label).toContainEqual(expect.objectContaining({ code: 'UNSUPPORTED_SYNTAX', syntax: 'gantt_task_label', line: 3 }))
        expect(mutate(parsed.value, { kind: 'set_title', title: 'Changed' }).ok, label).toBe(true)
        for (const op of [
          { kind: 'rename_task', sectionIndex: 0, taskIndex: 0, label },
          { kind: 'add_task', sectionIndex: 0, label, start: '2024-01-01', end: '1d' },
        ] as const) {
          const edited = mutate(gantt(), op)
          expect(edited.ok, label).toBe(true)
          if (edited.ok) expect(await upstream.accepts(serializeMermaid(edited.value)), label).toBe(true)
        }
      }
    } finally {
      upstream.close()
    }
  })

  const opaqueCases: Array<[string, string]> = [
    ['header suffix', 'gantt LR\n  Task :t1, 2024-01-01, 1d'],
    ['duplicate task ids', 'gantt\n  A :x, 2024-01-01, 1d\n  B :x, 2024-01-02, 1d'],
    ['unclosed accDescr block', 'gantt\n  accDescr {\n    never closed\n  Task :t1, 2024-01-01, 1d'],
  ]
  for (const [name, src] of opaqueCases) {
    test(`${name} falls back to opaque and round-trips byte-verbatim`, () => {
      const r = parseMermaid(src)
      expect(r.ok).toBe(true)
      if (!r.ok) return
      expect(r.value.body.kind).toBe('opaque')
      expect(asGantt(r.value)).toBeNull()
      expect(serializeMermaid(r.value).trimEnd()).toBe(src)
    })
  }

  test('a malformed task line stays a verbatim opaque segment (not dropped, not whole-opaque)', () => {
    const src = 'gantt\n  Good :g1, 2024-01-01, 2d\n  Broken : a, b, c, d, e\n  Also good :g2, after g1, 1d'
    const d = gantt(src)
    expect(d.body.sections[0]!.tasks.map(t => t.taskId)).toEqual(['g1', 'g2'])
    expect(serializeMermaid(d)).toContain('  Broken : a, b, c, d, e\n')
  })
})

describe('gantt mutation ops (every declared op round-trips)', () => {
  test('set_title sets and clears', () => {
    expect(apply(gantt(), { kind: 'set_title', title: 'New plan' }).body.title).toBe('New plan')
    const cleared = apply(gantt(), { kind: 'set_title', title: null })
    expect(cleared.body.title).toBeUndefined()
    expect(cleared.canonicalSource).not.toContain('title')
  })

  test('add_section / rename_section / remove_section', () => {
    let d = apply(gantt(), { kind: 'add_section', label: 'QA' })
    expect(d.body.sections.map(s => s.label)).toEqual(['Build', 'Ship', 'QA'])
    d = apply(d, { kind: 'rename_section', index: 2, label: 'Verification' })
    expect(d.body.sections[2]!.label).toBe('Verification')
    expect(d.canonicalSource).toContain('section Verification')
    d = apply(d, { kind: 'remove_section', index: 0 })
    expect(d.body.sections.map(s => s.label)).toEqual(['Ship', 'Verification'])
    // Removing the section removed its tasks AND their statements.
    expect(d.canonicalSource).not.toContain('Core engine')
    expect(shape(gantt(d.canonicalSource))).toEqual(shape(d))
  })

  test('add_task appends inside the right section even with directives interleaved', () => {
    const d = apply(gantt(), { kind: 'add_task', sectionIndex: 0, label: 'Docs', taskId: 'docs', start: 'after core', end: '3d' })
    const out = d.canonicalSource
    expect(out.indexOf('Docs')).toBeGreaterThan(out.indexOf('Polish'))
    expect(out.indexOf('Docs')).toBeLessThan(out.indexOf('section Ship'))
    expect(shape(gantt(out))).toEqual(shape(d))
  })

  test('add_task with tags and no start (inherit previous end)', () => {
    const d = apply(gantt(), { kind: 'add_task', sectionIndex: 1, label: 'Retro', tags: ['done'], end: '1d' })
    const t = d.body.sections[1]!.tasks.find(t => t.label === 'Retro')!
    expect(t.tags).toEqual(['done'])
    expect(t.start).toBeUndefined()
    expect(d.canonicalSource).toContain('Retro :done, 1d')
  })

  test('remove_task / rename_task / set_task_status / set_task_dates', () => {
    let d = apply(gantt(), { kind: 'rename_task', sectionIndex: 0, taskIndex: 0, label: 'Engine room' })
    expect(d.body.sections[0]!.tasks[0]!.label).toBe('Engine room')
    d = apply(d, { kind: 'set_task_status', sectionIndex: 0, taskIndex: 0, status: 'done' })
    expect(d.body.sections[0]!.tasks[0]!.tags).toEqual(['done'])
    d = apply(d, { kind: 'set_task_status', sectionIndex: 0, taskIndex: 0, status: null })
    expect(d.body.sections[0]!.tasks[0]!.tags).toEqual([])
    // Status never disturbs structural tags.
    d = apply(d, { kind: 'set_task_status', sectionIndex: 1, taskIndex: 0, status: 'crit' })
    expect(d.body.sections[1]!.tasks[0]!.tags).toEqual(['crit', 'milestone'])
    d = apply(d, { kind: 'set_task_dates', sectionIndex: 0, taskIndex: 0, start: '2024-02-01', end: '4d' })
    expect(d.body.sections[0]!.tasks[0]).toMatchObject({ start: '2024-02-01', end: '4d' })
    d = apply(d, { kind: 'set_task_dates', sectionIndex: 0, taskIndex: 1, start: null })
    expect(d.body.sections[0]!.tasks[1]!.start).toBeUndefined()
    d = apply(d, { kind: 'remove_task', sectionIndex: 0, taskIndex: 1 })
    expect(d.body.sections[0]!.tasks).toHaveLength(1)
    expect(shape(gantt(d.canonicalSource))).toEqual(shape(d))
  })

  test('error paths: not-found, duplicates, values that cannot round-trip', () => {
    const cases: Array<[GanttMutationOp, import('../agent/types.ts').MutationError['code']]> = [
      [{ kind: 'remove_section', index: 9 }, 'SECTION_NOT_FOUND'],
      [{ kind: 'rename_section', index: 9, label: 'X' }, 'SECTION_NOT_FOUND'],
      [{ kind: 'remove_task', sectionIndex: 0, taskIndex: 9 }, 'TASK_NOT_FOUND'],
      [{ kind: 'add_task', sectionIndex: 9, label: 'X', end: '1d' }, 'SECTION_NOT_FOUND'],
      [{ kind: 'add_task', sectionIndex: 0, label: 'X', taskId: 'core', end: '1d' }, 'DUPLICATE_TASK'],
      [{ kind: 'add_task', sectionIndex: 0, label: 'Has\nnewline', end: '1d' }, 'INVALID_OP'],
      [{ kind: 'add_task', sectionIndex: 0, label: 'X', end: 'has, comma' }, 'INVALID_OP'],
      [{ kind: 'add_task', sectionIndex: 0, label: 'X', taskId: 'bad id', end: '1d' }, 'INVALID_OP'],
      [{ kind: 'add_task', sectionIndex: 0, label: 'X', end: '' }, 'INVALID_OP'],
      [{ kind: 'set_title', title: '' }, 'INVALID_OP'],
      [{ kind: 'add_section', label: 'with : colon' }, 'INVALID_OP'],
    ]
    for (const [op, code] of cases) {
      const r = mutate(gantt(), op)
      expect({ op: op.kind, ok: r.ok, code: r.ok ? null : r.error.code }).toEqual({ op: op.kind, ok: false, code })
    }
  })

  test('mutation does not alias the input diagram', () => {
    const d = gantt()
    apply(d, { kind: 'rename_task', sectionIndex: 0, taskIndex: 0, label: 'Changed' })
    expect(d.body.sections[0]!.tasks[0]!.label).toBe('Core engine')
  })
})

// Ordering + identity ops (family-elevation-plan §Gantt item 4). Source order
// IS scheduling semantics for gantt: an implicit start ("end, no start")
// chains from the PREVIOUS task in flat source order, so move ops REJECT any
// move that would change an implicit-start task's predecessor — the caller
// materializes an explicit start first. Insertion (add_task index) into a
// chain is the documented exception: re-chaining the follower onto the
// inserted task is the point of inserting mid-pipeline.
describe('gantt ordering ops (move_task / move_section / add_task index)', () => {
  // Chained (implicit start, no id — an id would force an explicit start slot).
  const CHAIN = `gantt
  dateFormat YYYY-MM-DD
  section Build
    Core :core, 2024-01-01, 10d
    Chained :5d
    Explicit :ex, 2024-02-01, 2d
  section Ship
    Release :rel, after ex, 1d
`

  test('move_task moves an explicit-start task across sections and round-trips', () => {
    // Explicit (0,2) -> Ship head: flat source order is unchanged, so no
    // implicit chain is disturbed.
    const d = apply(gantt(CHAIN), { kind: 'move_task', fromSection: 0, fromIndex: 2, toSection: 1, toIndex: 0 })
    expect(d.body.sections[0]!.tasks.map(t => t.label)).toEqual(['Core', 'Chained'])
    expect(d.body.sections[1]!.tasks.map(t => t.label)).toEqual(['Explicit', 'Release'])
    const out = d.canonicalSource
    expect(out.indexOf('Explicit')).toBeGreaterThan(out.indexOf('section Ship'))
    expect(out.indexOf('Explicit')).toBeLessThan(out.indexOf('Release'))
    expect(shape(gantt(out))).toEqual(shape(d))
  })

  test('move_task within a section keeps statements coherent', () => {
    const d = apply(gantt(), { kind: 'move_task', fromSection: 0, fromIndex: 1, toSection: 1, toIndex: 0 })
    expect(d.body.sections[0]!.tasks.map(t => t.label)).toEqual(['Core engine'])
    expect(d.body.sections[1]!.tasks.map(t => t.label)).toEqual(['Polish', 'Release'])
    // Opaque directives (dateFormat, excludes, click) survive verbatim.
    expect(d.canonicalSource).toContain('  click core href "https://example.com/core"\n')
    expect(shape(gantt(d.canonicalSource))).toEqual(shape(d))
  })

  test('move_task rejects moving a task with an implicit start (prescriptive)', () => {
    const r = mutate(gantt(CHAIN), { kind: 'move_task', fromSection: 0, fromIndex: 1, toSection: 1, toIndex: 1 })
    expect(r.ok).toBe(false)
    if (r.ok) return
    expect(r.error.code).toBe('INVALID_OP')
    expect(r.error.message).toContain('Chained')
    expect(r.error.message).toContain('implicit')
    expect(r.error.message).toContain('set_task_dates')
  })

  test('move_task rejects when the old or new follower has an implicit start', () => {
    // Moving Core away re-chains Chained (implicit) onto nothing.
    const oldFollower = mutate(gantt(CHAIN), { kind: 'move_task', fromSection: 0, fromIndex: 0, toSection: 1, toIndex: 1 })
    expect(oldFollower.ok).toBe(false)
    if (!oldFollower.ok) expect(oldFollower.error.message).toContain('Chained')
    // Moving Explicit between Core and Chained re-chains Chained onto Explicit.
    const newFollower = mutate(gantt(CHAIN), { kind: 'move_task', fromSection: 0, fromIndex: 2, toSection: 0, toIndex: 1 })
    expect(newFollower.ok).toBe(false)
    if (!newFollower.ok) expect(newFollower.error.message).toContain('Chained')
  })

  test('move_task not-found and out-of-range errors', () => {
    expect(mutate(gantt(), { kind: 'move_task', fromSection: 9, fromIndex: 0, toSection: 0, toIndex: 0 }).ok).toBe(false)
    expect(mutate(gantt(), { kind: 'move_task', fromSection: 0, fromIndex: 9, toSection: 0, toIndex: 0 }).ok).toBe(false)
    expect(mutate(gantt(), { kind: 'move_task', fromSection: 0, fromIndex: 0, toSection: 9, toIndex: 0 }).ok).toBe(false)
    expect(mutate(gantt(), { kind: 'move_task', fromSection: 0, fromIndex: 0, toSection: 1, toIndex: 5 }).ok).toBe(false)
  })

  test('move_section reorders labeled sections and drags their statements along', () => {
    const d = apply(gantt(), { kind: 'move_section', from: 1, to: 0 })
    expect(d.body.sections.map(s => s.label)).toEqual(['Ship', 'Build'])
    const out = d.canonicalSource
    expect(out.indexOf('section Ship')).toBeLessThan(out.indexOf('section Build'))
    expect(out.indexOf('dateFormat')).toBeLessThan(out.indexOf('section Ship'))
    // The click line was inside Ship's statement span and travels with it.
    expect(out.indexOf('click core')).toBeLessThan(out.indexOf('section Build'))
    expect(shape(gantt(out))).toEqual(shape(d))
  })

  test('move_section rejects when it would re-chain an implicit start across sections', () => {
    const src = 'gantt\n  dateFormat YYYY-MM-DD\n  section Build\n    Core :core, 2024-01-01, 10d\n  section Ship\n    Wrap :2d'
    const r = mutate(gantt(src), { kind: 'move_section', from: 1, to: 0 })
    expect(r.ok).toBe(false)
    if (r.ok) return
    expect(r.error.code).toBe('INVALID_OP')
    expect(r.error.message).toContain('Wrap')
  })

  test('move_section rejects the implicit section and positions before it', () => {
    const src = 'gantt\n  Loose :l1, 2024-01-01, 2d\n  section Named\n    Inside :i1, after l1, 1d'
    const moveImplicit = mutate(gantt(src), { kind: 'move_section', from: 0, to: 1 })
    expect(moveImplicit.ok).toBe(false)
    if (!moveImplicit.ok) expect(moveImplicit.error.message).toContain('implicit')
    const beforeImplicit = mutate(gantt(src), { kind: 'move_section', from: 1, to: 0 })
    expect(beforeImplicit.ok).toBe(false)
  })

  test('add_task with index inserts at position and re-chains an implicit follower (documented)', () => {
    const src = 'gantt\n  dateFormat YYYY-MM-DD\n  A :a, 2024-01-01, 2d\n  B follows :3d'
    const d = apply(gantt(src), { kind: 'add_task', sectionIndex: 0, index: 1, label: 'Inserted', taskId: 'ins', start: 'after a', end: '1d' })
    expect(d.body.sections[0]!.tasks.map(t => t.label)).toEqual(['A', 'Inserted', 'B follows'])
    const out = d.canonicalSource
    expect(out.indexOf('Inserted')).toBeGreaterThan(out.indexOf('A :a'))
    expect(out.indexOf('Inserted')).toBeLessThan(out.indexOf('B follows'))
    expect(shape(gantt(out))).toEqual(shape(d))
  })

  test('add_task index out of range is INVALID_OP', () => {
    const r = mutate(gantt(), { kind: 'add_task', sectionIndex: 0, index: 7, label: 'X', end: '1d' })
    expect(r.ok).toBe(false)
    if (!r.ok) expect(r.error.code).toBe('INVALID_OP')
  })
})

describe('gantt set_task_flags (milestone/vert toggles after creation)', () => {
  test('toggles milestone off and on, preserving status tags in canonical order', () => {
    let d = apply(gantt(), { kind: 'set_task_flags', sectionIndex: 1, taskIndex: 0, milestone: false })
    expect(d.body.sections[1]!.tasks[0]!.tags).toEqual([])
    expect(d.canonicalSource).toContain('Release :rel, after pol, 0d')
    d = apply(d, { kind: 'set_task_status', sectionIndex: 1, taskIndex: 0, status: 'done' })
    d = apply(d, { kind: 'set_task_flags', sectionIndex: 1, taskIndex: 0, milestone: true })
    expect(d.body.sections[1]!.tasks[0]!.tags).toEqual(['done', 'milestone'])
    expect(d.canonicalSource).toContain('Release :done, milestone, rel, after pol, 0d')
    expect(shape(gantt(d.canonicalSource))).toEqual(shape(d))
  })

  test('toggles vert on a plain task', () => {
    const d = apply(gantt(), { kind: 'set_task_flags', sectionIndex: 0, taskIndex: 0, vert: true })
    expect(d.body.sections[0]!.tasks[0]!.tags).toEqual(['vert'])
    expect(d.canonicalSource).toContain('Core engine :vert, core, 2024-01-01, 10d')
  })

  test('task not found', () => {
    expect(mutate(gantt(), { kind: 'set_task_flags', sectionIndex: 0, taskIndex: 9, milestone: true }).ok).toBe(false)
  })
})

// Reference-coherence contract (documented in docs/design/families/gantt.md):
// renaming a task id REWRITES all structured after/until references so the
// dependency graph stays coherent; it REJECTS while the id is referenced from
// opaque segments (click lines, unmodeled task lines) because typed ops never
// rewrite opaque source; clearing an id (null) REJECTS while ANY reference
// exists — there is nothing to retarget the referents to.
describe('gantt set_task_id (rename keeps after/until references coherent)', () => {
  const REFS = `gantt
  dateFormat YYYY-MM-DD
  section Build
    Core :core, 2024-01-01, 10d
    Polish :pol, after core, 5d
    Wrap :wrap, 2024-01-05, until pol
  section Ship
    Release :rel, after core pol, 1d
`

  test('rename rewrites every structured after/until reference', () => {
    const d = apply(gantt(REFS), { kind: 'set_task_id', sectionIndex: 0, taskIndex: 0, taskId: 'engine' })
    expect(d.body.sections[0]!.tasks[0]!.taskId).toBe('engine')
    const out = d.canonicalSource
    expect(out).toContain('Polish :pol, after engine, 5d')
    expect(out).toContain('Release :rel, after engine pol, 1d')
    expect(out).not.toContain('after core')
    expect(verifyMermaid(d).warnings.map(w => w.code)).not.toContain('EDGE_MISANCHORED')
    expect(shape(gantt(out))).toEqual(shape(d))
  })

  test('rename rewrites until references too', () => {
    const d = apply(gantt(REFS), { kind: 'set_task_id', sectionIndex: 0, taskIndex: 1, taskId: 'shine' })
    expect(d.canonicalSource).toContain('Wrap :wrap, 2024-01-05, until shine')
    expect(d.canonicalSource).toContain('Release :rel, after core shine, 1d')
  })

  test('rename rejects while the id is referenced from an opaque segment (click line)', () => {
    const r = mutate(gantt(), { kind: 'set_task_id', sectionIndex: 0, taskIndex: 0, taskId: 'engine' })
    expect(r.ok).toBe(false)
    if (r.ok) return
    expect(r.error.code).toBe('INVALID_OP')
    expect(r.error.message).toContain('opaque')
    expect(r.error.message).toContain('click core')
  })

  test('clearing an id rejects while referenced, listing the referents', () => {
    const r = mutate(gantt(REFS), { kind: 'set_task_id', sectionIndex: 0, taskIndex: 0, taskId: null })
    expect(r.ok).toBe(false)
    if (r.ok) return
    expect(r.error.message).toContain('Polish')
    expect(r.error.message).toContain('Release')
    // Unreferenced ids clear cleanly.
    const d = apply(gantt(REFS), { kind: 'set_task_id', sectionIndex: 0, taskIndex: 2, taskId: null })
    expect(d.body.sections[0]!.tasks[2]!.taskId).toBeUndefined()
    expect(d.canonicalSource).toContain('Wrap :2024-01-05, until pol')
  })

  test('assigns an id to a task that had none', () => {
    const src = 'gantt\n  dateFormat YYYY-MM-DD\n  Loose :2024-01-01, 2d'
    const d = apply(gantt(src), { kind: 'set_task_id', sectionIndex: 0, taskIndex: 0, taskId: 'loose' })
    expect(d.canonicalSource).toContain('Loose :loose, 2024-01-01, 2d')
  })

  test('duplicate and malformed ids are rejected', () => {
    const dup = mutate(gantt(REFS), { kind: 'set_task_id', sectionIndex: 0, taskIndex: 0, taskId: 'pol' })
    expect(dup.ok).toBe(false)
    if (!dup.ok) expect(dup.error.code).toBe('DUPLICATE_TASK')
    const bad = mutate(gantt(REFS), { kind: 'set_task_id', sectionIndex: 0, taskIndex: 0, taskId: 'has space' })
    expect(bad.ok).toBe(false)
    if (!bad.ok) expect(bad.error.code).toBe('INVALID_OP')
  })
})

describe('gantt verify', () => {
  test('healthy diagram verifies clean; layout is the real gantt geometry', () => {
    const v = verifyMermaid(gantt())
    expect(v.ok).toBe(true)
    expect(v.warnings).toHaveLength(0)
    expect(v.layout.nodes.length).toBe(3)
    expect(v.layout.groups.length).toBe(2)
    expect(layoutMermaid(gantt()).nodes.length).toBe(3)
  })

  test('EMPTY_DIAGRAM on a header-only gantt', () => {
    const v = verifyMermaid('gantt')
    expect(v.ok).toBe(false)
    expect(v.warnings.map(w => w.code)).toContain('EMPTY_DIAGRAM')
  })

  test('LABEL_OVERFLOW on long title/section/task labels', () => {
    const long = 'X'.repeat(60)
    const v = verifyMermaid(gantt(`gantt\n  title ${long}\n  section ${long}\n    ${long} :t1, 2024-01-01, 1d`))
    const targets = v.warnings.filter(w => w.code === 'LABEL_OVERFLOW')
    expect(targets.length).toBe(3)
  })

  test('EDGE_MISANCHORED on unknown after/until refs, quiet on known ones', () => {
    const bad = verifyMermaid(gantt('gantt\n  A :a, 2024-01-01, 2d\n  B :b, after ghost, 1d'))
    expect(bad.warnings.map(w => w.code)).toContain('EDGE_MISANCHORED')
    const ok = verifyMermaid(gantt('gantt\n  A :a, 2024-01-01, 2d\n  B :b, after a, 1d'))
    expect(ok.warnings).toHaveLength(0)
    // An id defined on a malformed (opaque) task line is still "known".
    const partial = verifyMermaid(gantt('gantt\n  Broken : x, y, z, w, v\n  B :b, after x, 1d'))
    expect(partial.warnings.map(w => w.code)).not.toContain('EDGE_MISANCHORED')
  })
})

describe('gantt describe', () => {
  test('prose covers sections, tasks, schedule range, and the critical path', () => {
    const text = describeMermaid(gantt())
    expect(text).toContain('Gantt chart')
    expect(text).toContain('Release plan')
    expect(text).toContain('Build')
    expect(text).toContain('Critical path: core -> pol -> rel')
    expect(text).toContain('2024-01-01')
  })

  test('AX tree exposes tasks as nodes, dependencies as edges, entries and sinks', () => {
    const tree = JSON.parse(describeMermaid(gantt(), { format: 'json' }))
    expect(tree.kind).toBe('gantt')
    expect(tree.nodes.map((n: { id: string }) => n.id)).toEqual(['core', 'pol', 'rel'])
    expect(tree.edges).toEqual([
      { from: 'core', to: 'pol', label: 'after' },
      { from: 'pol', to: 'rel', label: 'after' },
    ])
    expect(tree.entryPoints).toEqual(['core'])
    expect(tree.sinks).toEqual(['rel'])
  })
})

describe('gantt round-trip property (generated diagrams)', () => {
  const labelArb = fc.stringMatching(/^[A-Za-z][A-Za-z0-9 _-]{0,16}[A-Za-z0-9]$/).filter(l => !/^(section|title|dateFormat|axisFormat|excludes|includes|click|gantt|todayMarker|weekday|weekend|tickInterval|inclusiveEndDates|topAxis|accTitle|accDescr)\b/i.test(l))
  const idArb = fc.stringMatching(/^[a-z][a-z0-9_-]{0,8}$/)
  const tagArb = fc.subarray(['active', 'done', 'crit', 'milestone'] as const, { minLength: 0, maxLength: 2 })
  const dayArb = fc.integer({ min: 1, max: 28 })
  const durArb = fc.oneof(
    fc.integer({ min: 1, max: 30 }).map(n => `${n}d`),
    fc.integer({ min: 1, max: 8 }).map(n => `${n}w`),
  )

  const diagramArb = fc
    .record({
      title: fc.option(labelArb, { nil: undefined }),
      sections: fc.array(
        fc.record({
          label: labelArb,
          tasks: fc.uniqueArray(fc.record({ label: labelArb, id: idArb, tags: tagArb, day: dayArb, dur: durArb }), {
            minLength: 1,
            maxLength: 4,
            selector: t => t.id,
          }),
        }),
        { minLength: 1, maxLength: 3 },
      ),
    })
    .map(({ title, sections }) => {
      const lines = ['gantt']
      if (title) lines.push(`  title ${title}`)
      lines.push('  dateFormat YYYY-MM-DD')
      const seen = new Set<string>()
      const expectedSections = sections.map(s => {
        lines.push(`  section ${s.label}`)
        const tasks: Array<{ label: string; taskId: string; tags: GanttBodyTaskTag[]; start: string; end: string }> = []
        for (const t of s.tasks) {
          if (seen.has(t.id)) continue
          seen.add(t.id)
          const start = `2024-01-${String(t.day).padStart(2, '0')}`
          const tags = t.tags.length ? `${t.tags.join(', ')}, ` : ''
          lines.push(`  ${t.label} :${tags}${t.id}, ${start}, ${t.dur}`)
          tasks.push({ label: t.label, taskId: t.id, tags: [...t.tags], start, end: t.dur })
        }
        return { label: s.label, tasks }
      })
      return { source: lines.join('\n') + '\n', expected: { title, sections: expectedSections } }
    })

  test('parse and serialized read-back preserve independently generated task meaning', () => {
    const meaning = (diagram: GanttValidDiagram) => ({
      title: diagram.body.title,
      sections: diagram.body.sections.map(section => ({
        label: section.label,
        tasks: section.tasks.map(({ label, taskId, tags, start, end }) => ({ label, taskId, tags, start, end })),
      })),
    })
    fc.assert(
      fc.property(diagramArb, ({ source, expected }) => {
        const diagram = gantt(source)
        expect(meaning(diagram)).toEqual(expected)
        const serialized = serializeMermaid(diagram)
        const reloaded = gantt(serialized)
        expect(meaning(reloaded)).toEqual(expected)
        expect(serializeMermaid(reloaded)).toBe(serialized)
      }),
      fcParameters({ numRuns: 60 }),
    )
  })
})

describe('gantt UNRESOLVABLE_SCHEDULE (closes the verify-ok/render-throws seam)', () => {
  // Found via the upstream bench: mermaid's parser accepts `excludes weekdays`
  // and silently ignores it; we render-error — but verify used to stay silent.
  test('a parseable-but-unschedulable diagram flips verify.ok with the named reason', () => {
    const v = verifyMermaid(gantt('gantt\n  dateFormat YYYY-MM-DD\n  excludes weekdays 2019-02-01\n  A :a, 2019-02-04, 3d'))
    expect(v.ok).toBe(false)
    const w = v.warnings.find(w => w.code === 'UNRESOLVABLE_SCHEDULE') as { code: string; reason: string } | undefined
    expect(w).toBeDefined()
    expect(w!.reason).toContain('GANTT_BAD_DATE')
    expect(v.warnings.map(w => w.code)).toEqual(['UNRESOLVABLE_SCHEDULE'])
  })

  test('a dependency cycle among known ids surfaces (EDGE_MISANCHORED cannot catch it)', () => {
    const v = verifyMermaid(gantt('gantt\n  A :a, after c, 1d\n  B :b, after a, 1d\n  C :c, after b, 1d'))
    expect(v.ok).toBe(false)
    const w = v.warnings.find(w => w.code === 'UNRESOLVABLE_SCHEDULE') as { code: string; reason: string } | undefined
    expect(w!.reason).toContain('GANTT_DEPENDENCY_CYCLE')
  })

  test('a task-less gantt maps to EMPTY_DIAGRAM, not UNRESOLVABLE_SCHEDULE', () => {
    const v = verifyMermaid(gantt('gantt\n  title Just a title\n  dateFormat YYYY-MM-DD'))
    expect(v.ok).toBe(false)
    expect(v.warnings.map(w => w.code)).toEqual(['EMPTY_DIAGRAM'])
  })

  test('empty Gantt renders an honest reusable template without fabricated dates or tasks', () => {
    for (const source of ['gantt', 'gantt\n  title Release planning\n  tickInterval 1week\n  weekday monday', 'gantt\n  title Release planning\n  section Delivery']) {
      const parsed = parseMermaid(source)
      expect(parsed.ok).toBe(true)
      if (!parsed.ok) throw Error('empty Gantt did not parse')
      const serialized = serializeMermaid(parsed.value)
      expect(verifyMermaid(parsed.value).warnings.map(w => w.code)).toContain('EMPTY_DIAGRAM')
      const svg = renderMermaidSVG(parsed.value)
      expect(svg).toContain('No tasks scheduled')
      expect(svg).not.toContain('gantt-axis-label')
      expect(svg).not.toContain('1970')
      const terminal = renderMermaidASCIIWithMeta(serialized, { useAscii: true, colorMode: 'none' })
      expect(terminal.ascii).toContain('No tasks scheduled')
      expect(terminal.ascii).not.toContain('1970')
      expect(terminal.warnings.some(warning => warning.code === 'ASCII_RENDER_FAILED')).toBe(false)
      expect(layoutMermaid(parsed.value).nodes).toEqual([])
      expect(describeMermaid(parsed.value)).toContain('No tasks scheduled')
      expect(describeMermaid(parsed.value)).not.toContain('1970')
      expect(analyzeMermaid(parsed.value).gantt).toBeUndefined()
      if (source.includes('Release planning')) {
        expect(svg).toContain('Release planning')
        expect(terminal.ascii).toContain('Release planning')
      }
      if (source.includes('Delivery')) {
        expect(svg).toContain('Delivery')
        expect(terminal.ascii).toContain('Delivery')
      }
      const reloaded = parseMermaid(serialized)
      expect(reloaded.ok).toBe(true)
      if (reloaded.ok) expect(serializeMermaid(reloaded.value)).toBe(serialized)
    }
  })

  test('healthy diagrams and the suppress knob behave', () => {
    expect(verifyMermaid(gantt()).warnings.map(w => w.code)).not.toContain('UNRESOLVABLE_SCHEDULE')
    const suppressed = verifyMermaid(gantt('gantt\n  excludes weekdays\n  A :a, 2019-02-04, 3d'), { suppress: ['UNRESOLVABLE_SCHEDULE'] })
    expect(suppressed.ok).toBe(true)
    expect(suppressed.warnings).toEqual([])
  })
})

describe('gantt geometric tripwires (issue #26 WS11)', () => {
  // The layout contains bars by construction (property-tested), so on real
  // diagrams these stay silent; the validator itself is proven reachable with
  // hand-built layouts (a validator nothing can trigger is dead code).
  test('healthy diagram: no OFF_CANVAS / GROUP_BREACH from the geometry pass', () => {
    const v = verifyMermaid(gantt())
    expect(v.warnings.filter(w => w.code === 'OFF_CANVAS' || w.code === 'GROUP_BREACH')).toEqual([])
  })

  test('a bar outside the canvas raises OFF_CANVAS per axis', () => {
    const layout = layoutMermaid(gantt())
    const doctored = {
      ...layout,
      nodes: layout.nodes.map((n, i) => (i === 0 ? { ...n, x: (layout.bounds.w + 10) as typeof n.x, y: -50 as typeof n.y } : n)),
    }
    const codes = ganttGeometryWarnings(doctored)
    expect(codes).toContainEqual({ code: 'OFF_CANVAS', target: 'core', axis: 'x' })
    expect(codes).toContainEqual({ code: 'OFF_CANVAS', target: 'core', axis: 'y' })
  })

  test('a bar escaping its section band raises GROUP_BREACH', () => {
    const layout = layoutMermaid(gantt())
    const band = layout.groups[0]!
    const doctored = {
      ...layout,
      nodes: layout.nodes.map(n => (n.id === 'core' ? { ...n, y: (band.y + band.h + 100) as typeof n.y } : n)),
    }
    const warnings = ganttGeometryWarnings(doctored)
    expect(warnings).toContainEqual({ code: 'GROUP_BREACH', group: 'section#0', member: 'core' })
  })
})

describe('gantt ASCII regions (issue #26 WS10)', () => {
  test('renderMermaidASCIIWithMeta exposes section and task regions keyed by Mermaid task id', () => {
    const { ascii, regions } = renderMermaidASCIIWithMeta(SRC)
    expect(ascii).toContain('Core engine')
    const byId = new Map(regions.map(r => [r.id, r]))
    for (const id of ['core', 'pol', 'rel']) {
      const region = byId.get(id)
      expect({ id, found: Boolean(region) }).toEqual({ id, found: true })
      // The region points at the label text in the rendered grid.
      const line = ascii.split('\n')[region!.canvasRow]!
      expect(line.slice(region!.canvasColStart, region!.canvasColEnd)).toBe(id === 'core' ? 'Core engine' : id === 'pol' ? 'Polish' : 'Release')
    }
    expect(regions.some(r => byId.get('core') === r && r.kind === 'node')).toBe(true)
  })
})

describe('gantt CLI mutate dispatch', () => {
  // Regression: mutateAny in src/cli/index.ts keeps its own narrower chain;
  // a new family that misses it returns UNSUPPORTED_FAMILY from `am mutate`
  // even though the library mutate works.
  test('am mutate applies a gantt op end-to-end', async () => {
    const { writeFileSync, mkdtempSync, rmSync } = require('node:fs') as typeof import('node:fs')
    const { join } = require('node:path') as typeof import('node:path')
    const { tmpdir } = require('node:os') as typeof import('node:os')
    const dir = mkdtempSync(join(tmpdir(), 'am-gantt-'))
    try {
      const file = join(dir, 'g.mmd')
      writeFileSync(file, 'gantt\n  dateFormat YYYY-MM-DD\n  section Build\n    Core :core, 2024-01-01, 10d\n')
      const r = await runChild('bun', ['run', join(import.meta.dir, '..', '..', 'bin', 'am.ts'), 'mutate', file, '--op', '{"kind":"add_task","sectionIndex":0,"label":"Ship","taskId":"ship","start":"after core","end":"2d"}'])
      expect({ status: r.status, stderr: r.stderr }).toEqual({ status: 0, stderr: '' })
      expect(r.stdout).toContain('Ship :ship, after core, 2d')
      expect(r.stdout).toContain('dateFormat YYYY-MM-DD')
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })
})

describe('gantt differential vs renderer-grade parser', () => {
  test('the canonical source the body serializer emits re-parses identically under parseGanttModel', () => {
    const d = gantt()
    const out = serializeMermaid(d)
    const model = parseGanttModel(normalizeMermaidSource(out).lines)
    expect(model.title).toBe(d.body.title)
    expect(model.sections.filter(s => s.label !== undefined).map(s => s.label)).toEqual(d.body.sections.filter(s => s.label !== undefined).map(s => s.label))
    expect(model.tasks.map(t => t.label)).toEqual(d.body.sections.flatMap(s => s.tasks.map(t => t.label)))
    expect(model.tasks.map(t => t.id)).toEqual(d.body.sections.flatMap(s => s.tasks.map(t => t.taskId)))
  })
})
