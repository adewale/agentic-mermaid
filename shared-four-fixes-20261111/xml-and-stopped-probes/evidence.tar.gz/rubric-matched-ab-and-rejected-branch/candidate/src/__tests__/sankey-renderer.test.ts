import { describe, expect, test } from 'bun:test'
import { renderMermaidSVG, verifyNoExternalRefs } from '../index.ts'
import { getFamily } from '../agent/families.ts'
import { positionResolvedFamily } from '../positioning.ts'
import { resolveRenderRequest } from '../render-contract.ts'
import type { SceneDoc } from '../scene/ir.ts'
import type { RenderContext } from '../types.ts'

const BASIC = 'sankey-beta\n  Coal,Electricity,127.93\n  Gas,Electricity,80\n  Electricity,Homes,120\n  Electricity,Industry,87.93'

const configured = (config: string, body = BASIC) => `---\nconfig:\n  sankey:\n${config}\n---\n${body}`

function lowerSankeyScene(source: string): SceneDoc {
  const request = resolveRenderRequest(source, {}, 'svg')
  const result = positionResolvedFamily('sankey', request)
  const context: RenderContext = {
    positioned: result.positioned,
    colors: request.appearance.colors,
    resolved: {
      renderOptions: request.renderOptions,
      ...(request.appearance.face ? { styleFace: request.appearance.face } : {}),
      ...(request.familyConfig ? { familyConfig: request.familyConfig } : {}),
      ...(request.appearance.family ? { familyAppearance: request.appearance.family } : {}),
    },
  }
  return getFamily('sankey')!.lowerScene!(context)
}

describe('sankey SVG renderer · structure', () => {
  test('emits a complete SVG with the sankey role description', () => {
    const svg = renderMermaidSVG(BASIC)
    expect(svg).toContain('<svg')
    expect(svg).toContain('</svg>')
    expect(svg).toContain('aria-roledescription="sankey diagram"')
  })

  test('one node rect per distinct label, one ribbon path per row', () => {
    const svg = renderMermaidSVG(BASIC)
    expect(svg.match(/class="sankey-node"/g)?.length).toBe(5)
    expect(svg.match(/class="sankey-link"/g)?.length).toBe(4)
  })

  test('node rects carry data-label/data-value/data-layer; ribbons carry endpoints', () => {
    const svg = renderMermaidSVG(BASIC)
    expect(svg).toContain('data-label="Electricity" data-value="207.93"')
    expect(svg).toContain('data-source="Coal" data-target="Electricity" data-value="127.93"')
    // Layering: sources at 0, hub at 1, sinks at 2.
    expect(svg).toMatch(/data-label="Coal"[^/]*data-layer="0"/)
    expect(svg).toMatch(/data-label="Homes"[^/]*data-layer="2"/)
  })

  test('ribbon stroke width encodes the flow value proportionally', () => {
    const svg = renderMermaidSVG(BASIC)
    const widths = [...svg.matchAll(/class="sankey-link"[^/]*stroke-width="([\d.]+)"/g)].map(m => Number(m[1]))
    expect(widths.length).toBe(4)
    // Row order: Coal(127.93), Gas(80), Homes(120), Industry(87.93).
    expect(widths[0]!).toBeGreaterThan(widths[1]!)
    expect(widths[0]! / widths[1]!).toBeCloseTo(127.93 / 80, 1)
  })

  test('byte-identical across repeated renders (determinism)', () => {
    const first = renderMermaidSVG(BASIC)
    expect(renderMermaidSVG(BASIC)).toBe(first)
  })

  test('legal long labels do not escape the bounded Scene identity contract', () => {
    const label = 'L'.repeat(255)
    const source = `sankey-beta\n"${label}",Target,1`
    const svg = renderMermaidSVG(source)
    expect(svg).toContain(`data-label="${label}"`)
    expect(svg).toContain(`data-id="${label}"`)
    const node = lowerSankeyScene(source).parts.find(mark => mark.kind === 'shape' && mark.identity?.id === label)
    expect(node?.id).toBe('sankey-node-1')
    expect(svg).toContain('</svg>')
  })

  test('multiline quoted labels render as multiline text through the public seam', () => {
    const svg = renderMermaidSVG('sankey-beta\n"North\nAmerica",Demand,1')
    expect(svg).toContain('>North</tspan>')
    expect(svg).toContain('>America</tspan>')
    expect(svg).toMatch(/<tspan x="[^"]+" dy="[^"]+" textLength="[^"]+" lengthAdjust="spacingAndGlyphs" data-font-metrics="deterministic-fit">North<\/tspan>/)
  })
})

describe('sankey SVG renderer · config wiring', () => {
  test('showValues (default on) adds a value line; prefix/suffix format it', () => {
    const svg = renderMermaidSVG(configured('    prefix: "€"\n    suffix: "M"'))
    expect(svg.replace(/<[^>]*>/g, '')).toContain('€127.93M')
    const withoutValues = renderMermaidSVG(configured('    showValues: false'))
    expect(withoutValues.replace(/<[^>]*>/g, '')).not.toContain('127.93')
  })

  test('linkColor: source paints ribbons with the source node color', () => {
    const svg = renderMermaidSVG(configured('    linkColor: source'))
    const attribute = (tag: string, name: string) => tag.match(new RegExp(`\\s${name}="([^"]*)"`))?.[1]
    const nodeFill = Object.fromEntries((svg.match(/<rect class="sankey-node"[^>]*>/g) ?? []).map(tag => [attribute(tag, 'data-label'), attribute(tag, 'fill')]))
    const ribbons = (svg.match(/<path class="sankey-link"[^>]*>/g) ?? [])
      .map(tag => ({ link: `${attribute(tag, 'data-source')}->${attribute(tag, 'data-target')}`, stroke: attribute(tag, 'stroke') }))
    expect(ribbons.map(r => r.link)).toEqual(['Coal->Electricity', 'Gas->Electricity', 'Electricity->Homes', 'Electricity->Industry'])
    expect(ribbons.every(r => /^#[0-9a-fA-F]{6}$/.test(r.stroke ?? ''))).toBe(true)
    expect(ribbons).toEqual(ribbons.map(r => ({ link: r.link, stroke: nodeFill[r.link.split('->')[0]!] })))
    // The sources carry distinct colors, so one shared stroke could not pass.
    expect(new Set(ribbons.map(r => r.stroke)).size).toBe(3)
  })

  test('linkColor accepts a static CSS color', () => {
    const svg = renderMermaidSVG(configured('    linkColor: "#94a3b8"'))
    expect(svg).toContain('stroke="#94a3b8"')
  })

  test('gradient mode emits typed fragment-local source-to-target gradients', () => {
    const svg = renderMermaidSVG(BASIC)
    expect(svg.match(/<linearGradient /g)?.length).toBe(4)
    expect(svg).toContain('gradientUnits="userSpaceOnUse"')
    expect(svg).toContain('<stop offset="0%"')
    expect(svg).toContain('<stop offset="100%"')
    expect(svg).toContain('stroke="url(#sankey-gradient-1)"')
    expect(verifyNoExternalRefs(svg)).toEqual({ ok: true, refs: [] })
    // The suite preload enables Scene assertions. Ordinary production must
    // admit the same typed resources in a fresh process before any import.
    const ordinary = Bun.spawnSync({
      cmd: [process.execPath, '-e', `import { renderMermaidSVG } from ${JSON.stringify(new URL('../index.ts', import.meta.url).pathname)}; process.stdout.write(renderMermaidSVG(${JSON.stringify(BASIC)}));`],
      env: { ...process.env, AGENTIC_MERMAID_SCENE_ASSERTIONS: '0' },
      stdout: 'pipe', stderr: 'pipe',
    })
    expect({ status: ordinary.exitCode, stderr: new TextDecoder().decode(ordinary.stderr) }).toEqual({ status: 0, stderr: '' })
    expect(new TextDecoder().decode(ordinary.stdout)).toBe(svg)
  })

  test('each gradient runs from its ribbon source end to its target end', () => {
    const svg = renderMermaidSVG(BASIC)
    const gradients = new Map([...svg.matchAll(/<linearGradient id="([^"]+)" gradientUnits="userSpaceOnUse" x1="([^"]+)" y1="([^"]+)" x2="([^"]+)" y2="([^"]+)">/g)]
      .map(m => [m[1]!, [m[2], m[3], m[4], m[5]].map(Number)]))
    const ribbons = [...svg.matchAll(/<path class="sankey-link" [^>]*\sd="M (\S+) (\S+) C [^"]*, (\S+) (\S+)" [^>]*stroke="url\(#([^)]+)\)"/g)]
    expect(ribbons).toHaveLength(4)
    for (const [, sx, sy, tx, ty, id] of ribbons) {
      expect(gradients.get(id!)).toEqual([sx, sy, tx, ty].map(Number))
    }
  })

  test('gradient resources and references are namespaced together', () => {
    const svg = renderMermaidSVG(BASIC, { idPrefix: 'diagram-7-' })
    expect(svg).toContain('id="diagram-7-sankey-gradient-1"')
    expect(svg).toContain('stroke="url(#diagram-7-sankey-gradient-1)"')
    expect(svg).not.toContain('stroke="url(#sankey-gradient-1)"')
  })

  test('authored node colors remain exact gradient endpoints', () => {
    const svg = renderMermaidSVG(configured('    nodeColors:\n      Coal: "#112233"\n      Electricity: "#abcdef"'))
    const firstGradient = svg.match(/<linearGradient id="sankey-gradient-1"[\s\S]*?<\/linearGradient>/)?.[0]
    expect(firstGradient).toContain('stop-color="#112233"')
    expect(firstGradient).toContain('stop-color="#abcdef"')
  })

  test('ribbons use Mermaid multiply blending on light pages and stay visible on dark pages', () => {
    const lightLinks = renderMermaidSVG(BASIC).match(/<path class="sankey-link"[^>]+>/g) ?? []
    expect(lightLinks).toHaveLength(4)
    expect(lightLinks.every(link => link.includes('style="mix-blend-mode:multiply"'))).toBe(true)

    const darkLinks = renderMermaidSVG(BASIC, { bg: '#071823', fg: '#e6edf3', accent: '#2dd4bf' })
      .match(/<path class="sankey-link"[^>]+>/g) ?? []
    expect(darkLinks).toHaveLength(4)
    expect(darkLinks.every(link => link.includes('style="mix-blend-mode:normal"'))).toBe(true)
  })

  test('nodeColors overrides win over the derived palette', () => {
    const svg = renderMermaidSVG(configured('    nodeColors:\n      Coal: "#4e79a7"'))
    expect(svg).toMatch(/<rect class="sankey-node" [^>]*data-label="Coal"[^>]* fill="#4e79a7"/)
  })

  // Labels sit on the ribbons, so both label styles halo them in the page
  // color (chart honesty H1); `labelStyle` still chooses the side.
  test('every label carries a page-colored halo; labelStyle: outlined chooses the label side', () => {
    const labels = (svg: string) => svg.match(/<text[^>]*class="sankey-node-label"[^>]*>/g) ?? []
    const legacy = renderMermaidSVG(BASIC)
    const outlined = renderMermaidSVG(configured('    labelStyle: outlined'))
    for (const svg of [legacy, outlined]) {
      const page = svg.match(/--bg:(#[0-9A-Fa-f]{3,8})/)![1]
      expect(labels(svg)).toHaveLength(5)
      for (const label of labels(svg)) expect(label).toContain(`stroke="${page}" stroke-width="3" paint-order="stroke fill"`)
    }
    const anchors = (svg: string) => labels(svg).map(label => label.match(/text-anchor="(\w+)"/)![1])
    expect(anchors(outlined)).not.toEqual(anchors(legacy))
  })

  test('display values match Mermaid two-decimal rounding while data stays exact', () => {
    const svg = renderMermaidSVG('sankey-beta\n  A,B,1.239')
    expect(svg).toContain('>1.24</tspan>')
    expect(svg).toContain('data-value="1.239"')
  })

  test('nodeWidth widens every node rect', () => {
    const svg = renderMermaidSVG(configured('    nodeWidth: 24'))
    expect(svg.match(/class="sankey-node" [^/]*width="24"/g)?.length).toBe(5)
  })

  test('width/height size the flow area (larger config, larger canvas)', () => {
    const small = renderMermaidSVG(configured('    width: 400\n    height: 200'))
    const large = renderMermaidSVG(configured('    width: 800\n    height: 500'))
    const dims = (svg: string) => svg.match(/<svg[^>]*width="([\d.]+)" height="([\d.]+)"/)!
    expect(Number(dims(large)[1])).toBeGreaterThan(Number(dims(small)[1]))
    expect(Number(dims(large)[2])).toBeGreaterThan(Number(dims(small)[2]))
  })

  test('every nodeAlignment places short sources and sinks as d3-sankey documents', () => {
    // A-B-C is the three-layer spine. D is a pure source that feeds only the
    // final node; E is a pure sink that stops one layer short. The four policies
    // disagree on exactly these two nodes (d3-sankey's sankeyLeft / Right /
    // Center / Justify): left and justify keep sources at depth 0, right and
    // center pull them next to their target; justify and right push sinks to the
    // last layer, left and center keep them at their depth.
    const body = 'sankey-beta\n  A,B,10\n  B,C,10\n  D,C,5\n  A,E,5'
    const layers = (alignment: string) => {
      const svg = renderMermaidSVG(configured(`    showValues: false\n    nodeAlignment: ${alignment}`, body))
      return Object.fromEntries([...svg.matchAll(/data-label="(\w+)"[^/]*data-layer="(\d+)"/g)].map(m => [m[1], Number(m[2])]))
    }
    expect(layers('justify')).toEqual({ A: 0, B: 1, C: 2, D: 0, E: 2 })
    expect(layers('left')).toEqual({ A: 0, B: 1, C: 2, D: 0, E: 1 })
    expect(layers('right')).toEqual({ A: 0, B: 1, C: 2, D: 1, E: 2 })
    expect(layers('center')).toEqual({ A: 0, B: 1, C: 2, D: 1, E: 1 })
    // justify is the default.
    const unset = renderMermaidSVG(configured('    showValues: false', body))
    expect(unset).toBe(renderMermaidSVG(configured('    showValues: false\n    nodeAlignment: justify', body)))
  })

  test('frontmatter title renders centered above the chart', () => {
    const svg = renderMermaidSVG(`---\ntitle: Energy flows\n---\n${BASIC}`)
    expect(svg).toContain('class="sankey-title"')
    expect(svg).toContain('Energy flows')
  })
})
