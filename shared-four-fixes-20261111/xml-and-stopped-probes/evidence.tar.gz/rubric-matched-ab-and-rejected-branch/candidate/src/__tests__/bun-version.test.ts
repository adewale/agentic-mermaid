// The minimum Bun version (src/mcp/bun-version.ts) and every place that states
// it or pins a Bun: package.json, the workflows, and the cloud-session
// SessionStart hook that upgrades an older Bun.
import { describe, expect, test } from 'bun:test'
import { accessSync, constants, readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { parse as parseYaml } from 'yaml'
import pkg from '../../package.json'
import { MIN_BUN_VERSION, unsupportedBunReason } from '../mcp/bun-version.ts'

const REPO = join(import.meta.dir, '..', '..')
const SESSION_START = join(REPO, 'scripts', 'ci', 'session-start.sh')

function sessionStartVersion(name: 'MIN_BUN' | 'PIN_BUN'): string | undefined {
  return new RegExp(`^${name}=(\\S+)$`, 'm').exec(readFileSync(SESSION_START, 'utf8'))?.[1]
}

function workflowBunPins(): string[] {
  const dir = join(REPO, '.github', 'workflows')
  return readdirSync(dir).filter(file => /\.ya?ml$/.test(file)).flatMap(file => {
    const workflow = parseYaml(readFileSync(join(dir, file), 'utf8')) as { jobs?: Record<string, { steps?: Array<{ uses?: string; with?: Record<string, unknown> }> }> }
    return Object.values(workflow.jobs ?? {}).flatMap(job => job.steps ?? [])
      .filter(step => step.uses?.startsWith('oven-sh/setup-bun@'))
      .map(step => String(step.with?.['bun-version']))
  })
}

describe('minimum Bun version', () => {
  test('refuses every Bun before 1.4.0, whose node:vm timeout outlives the call or is ignored', () => {
    for (const version of ['0.9.99', '1.2.14', '1.2.15', '1.3.12', '1.3.13', '1.3.14']) {
      expect(unsupportedBunReason(version)).toContain(`requires Bun ${MIN_BUN_VERSION} or later (found ${version})`)
    }
  })

  test('accepts 1.4.0 onwards, comparing versions numerically', () => {
    for (const version of ['1.4.0', '1.4.2', '1.4.1-canary.3+abcdef', '1.10.0', '2.0.0']) {
      expect(unsupportedBunReason(version)).toBeUndefined()
    }
  })

  test('does not apply off Bun, fails closed on an unreadable version, and holds for this run', () => {
    expect(unsupportedBunReason(undefined)).toBeUndefined()
    expect(unsupportedBunReason('canary')).toContain('found canary')
    expect(unsupportedBunReason()).toBeUndefined()
  })

  test('package.json, every workflow, and the session hook agree on a supported Bun', () => {
    expect(pkg.engines.bun).toBe(`>=${MIN_BUN_VERSION}`)
    const pins = workflowBunPins()
    expect(pins.length).toBeGreaterThan(0)
    for (const pin of pins) expect(unsupportedBunReason(pin)).toBeUndefined()
    // One Bun everywhere: the payload delta compares base and head bundles built
    // by the same toolchain, and local/CI/release runs must not drift.
    expect(new Set(pins).size).toBe(1)
    expect(sessionStartVersion('MIN_BUN')).toBe(MIN_BUN_VERSION)
    expect(sessionStartVersion('PIN_BUN')).toBe(pins[0])
  })

  test('the SessionStart hook is registered and does nothing outside cloud sessions', () => {
    const settings = JSON.parse(readFileSync(join(REPO, '.claude', 'settings.json'), 'utf8')) as { hooks: { SessionStart: Array<{ hooks: Array<{ command: string }> }> } }
    expect(settings.hooks.SessionStart.flatMap(entry => entry.hooks.map(hook => hook.command))).toEqual(['"$CLAUDE_PROJECT_DIR"/scripts/ci/session-start.sh'])
    expect(() => accessSync(SESSION_START, constants.X_OK)).not.toThrow()
    const { CLAUDE_CODE_REMOTE: _remote, ...localEnv } = process.env
    const local = Bun.spawnSync(['bash', SESSION_START], { timeout: 20_000, killSignal: 'SIGKILL', cwd: REPO, env: localEnv, stdout: 'pipe', stderr: 'pipe' })
    expect({ exitCode: local.exitCode, stdout: local.stdout.toString(), stderr: local.stderr.toString() }).toEqual({ exitCode: 0, stdout: '', stderr: '' })
  })
})
