import json,pathlib,collections
r=pathlib.Path(__file__).parent
backendRows={};changes=[];pending=[];paired=[]
def proof(s):return (s.get('svgReceipt')or{}).get('layoutCertification',{}).get('status','not-returned')
def outcome(s):
 if s.get('svg') is not None:return 'returned'
 return 'unsupported' if s.get('errorCode')=='GRAPH_LAYOUT_UNSUPPORTED' else 'refused-or-error'
for backend in ['agentic','elk','trinity']:
 totals=collections.Counter();before=collections.Counter();after=collections.Counter();families={};quality=[]
 for cohort in range(8):
  bp=r/f'cohort-{cohort}-{backend}-before/snapshot.json';ap=r/f'cohort-{cohort}-{backend}-after/snapshot.json'
  if not bp.exists() or not ap.exists():pending.append([cohort,backend]);continue
  b=json.load(open(bp));a=json.load(open(ap));assert b['renderOptions']==a['renderOptions'];assert len(b['samples'])==len(a['samples'])
  for old,new in zip(b['samples'],a['samples']):
   assert all(old[k]==new[k] for k in ['id','family','source']);totals['enrolled']+=1
   pb,pa=proof(old),proof(new);before[outcome(old)+':'+pb]+=1;after[outcome(new)+':'+pa]+=1
   families.setdefault(new['family'],collections.Counter())[outcome(new)+':'+pa]+=1
   flags={'SVGChanged':old.get('svg')!=new.get('svg'),'deliveryChanged':outcome(old)!=outcome(new),'proofChanged':pb!=pa,'entireReceiptChanged':old.get('svgReceipt')!=new.get('svgReceipt'),'layoutChanged':old.get('layout')!=new.get('layout'),'metricsChanged':old.get('metrics')!=new.get('metrics')}
   for k,v in flags.items():totals[k]+=v
   if pb=='passed' and pa!='passed':totals['passedToOther']+=1
   if pb!='passed' and pa=='passed':totals['otherToPassed']+=1
   if any(flags.values()):changes.append({'cohort':cohort,'backend':backend,'id':old['id'],'family':old['family'],'outcome':[outcome(old),outcome(new)],'proof':[pb,pa],**flags,'beforeMetrics':old.get('metrics'),'afterMetrics':new.get('metrics'),'beforeIssues':(old.get('svgReceipt')or{}).get('layoutCertification',{}).get('issues'),'afterIssues':(new.get('svgReceipt')or{}).get('layoutCertification',{}).get('issues')})
   quality.append({'cohort':cohort,'id':new['id'],'family':new['family'],'outcome':outcome(new),'proof':pa,'jointConsumerOK':new['ok'],'layoutReturned':new.get('layout') is not None,'failures':new.get('failures'),'errorCode':new.get('errorCode'),'error':new.get('error'),'metrics':new.get('metrics'),'backendDecisions':(new.get('svgReceipt')or{}).get('layoutDecisions')})
 backendRows[backend]={'totals':dict(totals),'before':dict(before),'after':dict(after),'families':{k:dict(v)for k,v in families.items()},'qualityVectors':quality}
result={'scope':'Existing snapshotSample consumer and original874enrolledsources. Current15a7ab421baseline vs retainedbodygaplateproposal; all3 explicitbackends/fallbacknone, originalrestoptions. Actualink is separate; proofcounts are not visualcorrectness. Every refusal/error/qualityvector retained. No solver-only or execution-performance claim. Replay is validation, Native201+invis separately supplies demonstrated visiblegain.','backends':backendRows,'pending':pending,'changes':changes}
(r/'COHORT-COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'pending':pending,'changes':len(changes),'backends':{k:{n:v[n]for n in ['totals','before','after','families']}for k,v in backendRows.items()}},indent=2))
