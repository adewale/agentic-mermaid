import fs from 'node:fs';
import path from 'node:path';
import inspector from 'node:inspector';
import {promisify} from 'node:util';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {registerHooks,stripTypeScriptTypes} from 'node:module';
import {gzipSync,gunzipSync} from 'node:zlib';
const root='/tmp/pr449-main-integration-20261029-762',out=process.argv[2],job=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
fs.mkdirSync(out,{recursive:true});
const maps={};
registerHooks({
 resolve(specifier,context,next){
  if(specifier.startsWith('.')&&(context.parentURL?.startsWith(pathToFileURL(root+'/').href)||context.parentURL?.includes('/node_modules/roughjs/bin/'))){
   const p=new URL(specifier,context.parentURL);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.ts'))return next(p.href+'.ts',context);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.js'))return next(p.href+'.js',context);
  }
  if(specifier.startsWith('roughjs/bin/')&&!path.extname(specifier))return next(specifier+'.js',context);
  return next(specifier,context);
 },
 load(url,context,next){
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.json'))return{format:'json',shortCircuit:true,source:fs.readFileSync(fileURLToPath(url),'utf8')};
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.ts')){
   const original=fs.readFileSync(job.moduleOverrides?.[fileURLToPath(url)] ?? fileURLToPath(url),'utf8');
   const source=stripTypeScriptTypes(original,{mode:'transform',sourceMap:job.profile !== false,sourceUrl:url});
   const m=source.match(/sourceMappingURL=data:application\/json;base64,([^\s]+)/);
   if(m)maps[url]=JSON.parse(Buffer.from(m[1],'base64').toString());
   return{format:'module',shortCircuit:true,source};
  }
  return next(url,context);
 }
});
const gz=(name,value)=>fs.writeFileSync(out+'/'+name+'.gz',gzipSync(typeof value==='string'?value:JSON.stringify(value)));
const importStart=performance.now();
const api=await import(pathToFileURL(root+'/src/index.ts'));
const {withRenderStageObserver}=await import(pathToFileURL(root+'/src/render-stages.ts'));
const {withPerformanceObserver}=await import(pathToFileURL(root+'/src/performance-observations.ts'));
const importMs=performance.now()-importStart;
const session=new inspector.Session();session.connect();const post=promisify(session.post).bind(session);
await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:200});
const products=[];const rows=[];
function consume(source){const product=api.renderMermaidSVGWithReceipt(source,job.options);const receiptJSON=JSON.stringify(product.receipt);const svg=product.svg;const bytes=Buffer.byteLength(JSON.stringify({svg,receipt:product.receipt}));return{svg,receiptJSON,bytes};}
// First render in this fresh Node process; module import is recorded separately.
let warmup,coldFailure;const coldBefore=process.memoryUsage(),coldStart=performance.now(),coldCPU=process.cpuUsage();
try{warmup=consume(job.source);}catch(e){coldFailure={name:e.name,message:e.message,stack:e.stack,certification:e.certification};}
const coldWallMs=performance.now()-coldStart,coldUsed=process.cpuUsage(coldCPU),coldAfter=process.memoryUsage();
const coldRow={phase:'cold-render',status:warmup?'returned':'error',wallMs:coldWallMs,cpuMs:(coldUsed.user+coldUsed.system)/1000,before:coldBefore,after:coldAfter,peakRssKiB:process.resourceUsage().maxRSS,bytes:warmup?.bytes,proof:warmup?JSON.parse(warmup?.receiptJSON).layoutCertification:undefined,failure:coldFailure};
rows.push(coldRow);gz('cold-render.row.json',coldRow);
if(warmup){gz('warmup.svg',warmup?.svg);gz('warmup.receipt.json',warmup?.receiptJSON);}else gz('warmup-error.json',coldFailure);
for(const phase of (job.phases ?? ['repeat1','repeat2','edit'])){
 global.gc?.();const stages=[],events=[];const before=process.memoryUsage();if (job.profile !== false) await post('Profiler.start');const start=performance.now(),cpu=process.cpuUsage();let product,failure;
 try{product=job.observers === false ? consume(phase.startsWith('edit')?job.edit:job.source) : withPerformanceObserver(e=>events.push(e),()=>withRenderStageObserver(s=>stages.push(s),()=>consume(phase.startsWith('edit')?job.edit:job.source)));}catch(e){failure={name:e.name,message:e.message,stack:e.stack,certification:e.certification};}
 const wallMs=performance.now()-start,cpuTime=process.cpuUsage(cpu);const {profile}=job.profile === false ? {profile:{startTime:0,endTime:0}} : await post('Profiler.stop');const after=process.memoryUsage();
 gz(phase+'.cpuprofile',profile);
 if(product){gz(phase+'.svg',product.svg);gz(phase+'.receipt.json',product.receiptJSON);}
 const row={phase,status:product?'returned':'error',wallMs,cpuMs:(cpuTime.user+cpuTime.system)/1000,before,after,peakRssKiB:process.resourceUsage().maxRSS,bytes:product?.bytes,wholeSvgExactWarmup:phase.startsWith('edit')?undefined:product?.svg===warmup?.svg,entireReceiptExactWarmup:phase.startsWith('edit')?undefined:product?.receiptJSON===warmup?.receiptJSON,editChanged:phase.startsWith('edit')?product?.svg!==warmup?.svg:undefined,proof:product?JSON.parse(product.receiptJSON).layoutCertification:undefined,failure,stages,events,profileStart:profile.startTime,profileEnd:profile.endTime,samples:profile.samples?.length};
 rows.push(row);gz(phase+'.row.json',row);console.log(JSON.stringify({case:job.case,backend:job.backend,phase,status:row.status,wallMs,cpuMs:row.cpuMs,samples:row.samples}));
}
const cacheEvents=[];let cacheAudit;
try{const last=withPerformanceObserver(e=>{if(e.kind==='cache')cacheEvents.push(e)},()=>consume(job.edit));cacheAudit={status:'returned',events:cacheEvents,bytes:last.bytes,wholeSVGExactFinalEdit:last.svg===gunzipSync(fs.readFileSync(out+'/edit2.svg.gz')).toString()};}catch(e){cacheAudit={status:'error',name:e.name,message:e.message,events:cacheEvents};}
gz('cache-audit.json',cacheAudit);
gz('source-maps.json',maps);gz('RESULT.json',{runtime:process.version,importMs,cacheAudit,job,cache:process.env.AGENTIC_MERMAID_ELK_CACHE,samplingIntervalUs:200,scope:'Fresh Node source API: module import separate from first render; full SVG+entire receipt serialized. Sampling and timed observers disabled. Compression/artifact writes/explicit GC outside measured render windows; warmup product retained for determinism. RSS includes harness/import/compression; not browser/package memory.',rows});session.disconnect();
