import * as original from './browser-lazy/index.js';
const api={renderConsumed:async(source,options)=>{const product=await original.renderMermaidSVGWithReceiptAsync(source,options);JSON.stringify(product.receipt);return product.svg}};
import {declaredRenderer} from './declared-adapter.mjs';
export async function createRenderer(){return declaredRenderer(api,{"export":"renderConsumed","options":{"graphLayout":{"backend":"trinity","fallback":"none"}}},'svg')}
globalThis.unifiedMermaid={createRenderer};
