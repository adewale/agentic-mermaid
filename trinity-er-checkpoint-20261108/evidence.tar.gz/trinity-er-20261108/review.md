# Independent flat ER review

Read-only review of the uncommitted ER adapter. No tests, builds, renders or profiles were run by this reviewer.

## Actionable finding

The intended canonical-paint admission is missing at this boundary. `layoutErDiagram` does not receive a paint-backend identity, and `svg-family-hooks/er.ts` passes only diagram/options/style face. The new Trinity branch checks orthogonal bend geometry but therefore also accepts requests whose selected rough/custom drawing backend can alter the canonical card/cardinality paint assumed by preparation. Class already carries this context explicitly. Pass the existing `ctx.paintBackendId` through the ER hook and decline nondefault backends in the Trinity branch, unless broader paint support is separately qualified. This is an admission gap, not an observed visible defect in a nondefault render.

## Remaining reviewed boundaries

No other actionable finding. The Native dimension overrides, incident-span reservations, layer-spacing rule and isolate packing remain in its branch. Trinity starts from measured entity minima and preserves actual returned dimensions after the old size-map spread; extraction retains the measured header height and row pitch, leaving any added body space blank. The shared paint helper preserves default/named/inline precedence and matches the renderer's numeric stroke resolution.

Per-role endpoint support combines the actual relationship shaft width with the canonical cardinality envelope's symmetric perpendicular extent. Cardinality paint continues to use the global cardinality stroke authority, while graph-wide shaft clearance conservatively includes relationship-role widths. Global and role-specific bend guards prevent the declared sharp kernel from silently accepting rounded relationship paint. Groups and entity memberships decline; size limits remain 64/128.

ER label centers are copied directly, with no Class-style offset. Completed extraction, title/contact/caption changes and final actual glyph/shaft/body checks remain inside selection. The fallback wrapper translates only `ErRouteGeometryError`; ER label/route work errors and neutral kernel work errors remain hard failures. ER preparation and finalization retain the same ER work object, and a retry does not replenish it. No cache or default-backend change appears in this diff.

The coordinator reports four directional red-to-green public owners. Those results were not replayed here. This review establishes neither general ER coverage nor a speed, quality or delivery-size gain.

## Resolution addendum

Verified the paint-backend fix in current source: `svg-family-hooks/er.ts` forwards the existing captured `ctx.paintBackendId`, `layoutErDiagram` accepts it as an optional fourth argument, and the nonempty Trinity measured-placement branch declines any explicit identity other than `backend:default`. Native/ELK branches do not consult the new identity. Empty ER remains valid because it contains no card or cardinality paint requiring the restricted geometry contract. The public hand-drawn refusal owner exercises the hook, rather than supplying the identity only to a private helper.

The shared producer is now named `measuredPlacement`; no further actionable finding from the targeted re-read. The coordinator reports the expanded focused owners passing, including actual dimension growth, role-specific stroke separation, loop/cycle captions and hard-error propagation under explicit fallback. These checks were not replayed by this reviewer, and the prior scope/performance limitations remain.
