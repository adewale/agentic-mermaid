# ELK owned-marker scope:100-node fan comparison

Existing serial Node24 source API collector, cache0, complete SVG plus entire receipt serialized. One before/after processpair; independent instrumentation-only diagnostic. Baseline loads9recorded sourceoverrides at cb4204a50; candidate enables the owned marker context on fresh ELK-projected geometry. No manual CI or production source edits by profiler.

| Phase | Before ms | After ms |
|---|---:|---:|
| cold-render | 1148.89 | 1397.28 |
| repeat1 | 748.08 | 883.19 |
| repeat2 | 578.74 | 640.36 |
| edit | 566.77 | 646.17 |

All24original/edit SVG and complete receipt filecomparisons are byte-exact across baseline,candidate and diagnostic: **True**. All12enrolled calls return with unverified receipts; retain OUTPUT_SCOPE/CHECK_BUDGET capturelimit. This is validation of unchanged products, not finalink correctness.

Actual diagnostic across5complete calls including one untimedcollector audit: **5 contexts, 1485 blocker entries, 0 peer queries, 0 prepared snapshots**.
The new peer index is never queried on this fan. There is no attributable publicperformance improvement or speedratio; preserve all cold/warm/edit and memory variation.100nodes<100ms remains unmet on fullproducts.

Raw jobs,9baselineoverrides, fullSVG/receipt artifacts, cost/memoryrows and diagnosticcounters retained in this directory. Source imports, compression/writes and explicitGC are outside render timers; RSS includes harness/import/artifact lifetimes. Existing derived caches remain.
