import fs from 'node:fs';
import path from 'node:path';
import inspector from 'node:inspector';
import {promisify} from 'node:util';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {registerHooks,stripTypeScriptTypes} from 'node:module';
import {gzipSync,gunzipSync} from 'node:zlib';
const root='/tmp/pr449-main-integration-20261029-762',out=process.argv[2],job=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
fs.mkdirSync(out,{recursive:true});
const maps={};
registerHooks({
 resolve(specifier,context,next){
  if(specifier.startsWith('.')&&(context.parentURL?.startsWith(pathToFileURL(root+'/').href)||context.parentURL?.includes('/node_modules/roughjs/bin/'))){
   const p=new URL(specifier,context.parentURL);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.ts'))return next(p.href+'.ts',context);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.js'))return next(p.href+'.js',context);
  }
  if(specifier.startsWith('roughjs/bin/')&&!path.extname(specifier))return next(specifier+'.js',context);
  return next(specifier,context);
 },
 load(url,context,next){
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.json'))return{format:'json',shortCircuit:true,source:fs.readFileSync(fileURLToPath(url),'utf8')};
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.ts')){
   const original=fs.readFileSync(job.moduleOverrides?.[fileURLToPath(url)] ?? fileURLToPath(url),'utf8');
   const source=stripTypeScriptTypes(original,{mode:'transform',sourceMap:job.profile !== false,sourceUrl:url});
   const m=source.match(/sourceMappingURL=data:application\/json;base64,([^\s]+)/);
   if(m)maps[url]=JSON.parse(Buffer.from(m[1],'base64').toString());
   return{format:'module',shortCircuit:true,source};
  }
  return next(url,context);
 }
});
const gz=(name,value)=>fs.writeFileSync(out+'/'+name+'.gz',gzipSync(typeof value==='string'?value:JSON.stringify(value)));

const api=await import(pathToFileURL(root+'/src/layout/route-marker-clearance.ts'));
const indexed=job.indexed,style={lineWidth:1,edgeBendRadius:0};
const peers=Array.from({length:96},(_,i)=>({id:'e'+i,edgeIndex:i,source:'s'+i,target:'t'+i,style:'solid',hasArrowStart:false,hasArrowEnd:true,points:[{x:i*40,y:100},{x:i*40+20,y:100}]}));
const proposed=edge=>{const [a,b]=edge.points;return [{...a},{x:a.x,y:a.y+30},{x:b.x,y:b.y+30},{...b}]};
const context=indexed?api.createRouteMarkerPeerContext(peers,style):undefined;
let checksum=0;const results=[],rows=[];
const pass=phase=>{global.gc?.();const before=process.memoryUsage(),start=performance.now(),cpu=process.cpuUsage();
 const values=[];for(const edge of peers){const points=proposed(edge);const blocker=api.routeCandidateMarkerBlocker(edge,points,peers,style,edge,context),clear=api.routeCandidateMarkersClear(edge,points,peers,style,edge,context);values.push([blocker??null,clear]);checksum+=Number(clear)+(blocker?.id.length??0);}
 const wallMs=performance.now()-start,used=process.cpuUsage(cpu),after=process.memoryUsage();rows.push({phase,wallMs,cpuMs:(used.user+used.system)/1000,before,after,peakRssKiB:process.resourceUsage().maxRSS});results.push({phase,values});};
pass('first-owned-pass');pass('warm1');pass('warm2');
peers[48].points=peers[48].points.map(p=>({x:p.x,y:p.y+500}));context?.invalidate(peers[48]);pass('edit-one-peer');
fs.writeFileSync(out+'/RESULT.json',JSON.stringify({job,rows,checksum,results,scope:'Marker guard kernel ONLY;96roster edges,192blocker/Boolean calls perpass; exactsame geometry/queries acrossarms. No body/layout/SVG/receipt/correctness claim. Firstpass includes lazyindex/views; no persistentcache. GCoutsidewindows; heap/RSSincludeharness and retainedresults.'},null,2));
