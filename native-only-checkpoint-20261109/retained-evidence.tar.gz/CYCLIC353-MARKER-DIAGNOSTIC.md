# Native cyclic353 owned-marker diagnostic

Exact current public fixture from native-layout-cache.test.ts; original plus one label edit. Existing source collector fully consumes SVG and entire receipt, layoutcache0. Canonical root checks ran concurrently; elapsed rows are retained but are not performance evidence. No source edits.

{'created': 15, 'entries': 820, 'queries': 90, 'prepares': 15}

[('cold-render', 'returned', 'passed'), ('repeat1', 'returned', 'passed'), ('repeat2', 'returned', 'passed'), ('edit', 'returned', 'passed')]

Actualpublicindexedpeerpathdemonstrated Counts cover5complete rendercalls including an untimed collector audit;4enrolled wholeproducts are retained.
