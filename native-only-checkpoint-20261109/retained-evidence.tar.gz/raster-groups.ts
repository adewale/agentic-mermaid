import {readFileSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import {prepareResvgMarkerOrientation} from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const repo='/tmp/pr449-main-integration-20261029-762',root='/tmp/pr449-week-comparison-20261101/native-only-20261109'
const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const p=repo+'/'+f.path;if(createHash('sha256').update(readFileSync(p)).digest('hex')!==f.sha256)throw Error('font mismatch');return p})
for(const dir of ['TB','BT','LR','RL'])for(const arm of ['before','after']){const path=root+'/group-cycle-'+dir+'-'+arm;const svg=readFileSync(path+'.svg','utf8');const result=new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(svg)),{background:'#fff',fitTo:{mode:'zoom',value:2},font:{fontFiles:fonts,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();writeFileSync(path+'.png',result.asPng())}
console.log('8 actual public SVG rasters; manifest-verified Inter; system fonts off')
