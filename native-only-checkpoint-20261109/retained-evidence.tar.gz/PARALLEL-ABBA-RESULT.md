# Rejected early-parallel performance hypothesis

Existing fully consumed source API collector, layoutcache0, sampling/observers off. Baseline uses `job.moduleOverrides` for exactly the prechange `src/shared/edge-crossings.ts`; no live file swaps. Four fan processes in ABBA order plus one chain before/after pair. Root tests/builds paused. No producer/consumer bypass or skipped receipt work.

| Input/arm | Cold target ms | Warm repeats ms | Edit ms |
|---|---:|---|---:|
| fanin100/before | 652.37, 802.42 | 245.31, 290.68, 702.31, 272.38 | 212.29, 351.87 |
| fanin100/after | 468.67, 922.31 | 306.90, 218.36, 261.58, 519.73 | 196.55, 244.88 |
| chain100/before | 380.28 | 201.51, 164.81 | 190.66 |
| chain100/after | 389.53 | 175.64, 173.53 | 198.69 |

All24enrolled calls returned; every emitted original/edit SVG and entire receipt is byte-exact across arms and replicas (48file comparisons; two products percall). All retain unverified OUTPUT_SCOPE/CHECK_BUDGET400000operations; unchanged proof availability is validation, not visible correctness.

No credible speedup is established. Fan timing noise includes warm702.31ms before and519.73ms after; sourceimport39.30s on firstbefore vs3.12–5.19s later (excluded from targettimers). Preserve all adverse observations; no ratio or p95 claim.100nodes<100ms is not reached. Existing profile samples point to generic crossing/localRays work but do not prove parallel pairs dominate; earlyparallel rejection alone is insufficient. Stop this optimization hypothesis unless an independent targeted crossing workload justifies it. The three-line guard may be behavior-preserving, but cannot be called campaign performance progress.

Raw `PARALLEL-ABBA-RUNS.json`, `PARALLEL-ABBA-COMPARISON.json`, jobs, exactbefore source, fullproducts and costrows retained. No production source edits by profiler agent.
