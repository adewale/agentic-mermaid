from pathlib import Path
import os,subprocess,json,gzip,time,resource
out=Path(__file__).parent/'production-builds';out.mkdir(exist_ok=True);rows=[]
for arm,root,sha in [('main','/tmp/pr449-current-main-39a-20261107','39a500425f6b74eb486b9add9e90d538fab6a914'),('pr','/tmp/pr449-main-integration-20261029-762','1693c2a2b7fd93cb5da11f1a358d162180fa19cc')]:
 repo=Path(root);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==sha;html=repo/'editor.html'
 if html.exists():(out/(arm+'-prior-product.html.gz')).write_bytes(gzip.compress(html.read_bytes()))
 env=dict(os.environ,PATH='/tmp/pr449-tools-20261106/package/bin:'+os.environ['PATH'],NODE_ENV='production',AGENTIC_MERMAID_SCENE_ASSERTIONS='0',AM_EDITOR_BUILD_METAFILE=str(out/(arm+'-metafile.json')));env.pop('AM_EDITOR_RUNTIME_DIR',None);env.pop('AM_EDITOR_FONT_PREFIX',None);start=time.monotonic()
 with (out/(arm+'-build.log')).open('w') as log:
  p=subprocess.Popen(['bun','run','scripts/site/editor.ts'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT);deadline=start+55;timeout=False
  while True:
   pid,status,use=os.wait4(p.pid,os.WNOHANG)
   if pid:break
   if time.monotonic()>deadline:p.kill();timeout=True;pid,status,use=os.wait4(p.pid,0);break
   time.sleep(.1)
  code=os.waitstatus_to_exitcode(status);p.returncode=code
 row={'arm':arm,'revision':sha,'exitCode':code,'timeout':timeout,'wallSeconds':time.monotonic()-start,'peakRssKiB':use.ru_maxrss,'cpuUser':use.ru_utime,'cpuSystem':use.ru_stime};rows.append(row)
 (out/'STATUS.json').write_text(json.dumps({'rows':rows,'recipe':'Bun1.4.4 production, assertions0, same deps, no runtimeDir/fontPrefix override. Existing55s child deadline. Prior HTML retained; candidate product remains materialized for actual browser owner. No timing ratio.'},indent=2)+'\n')
 if code:raise RuntimeError(str(row))
 (out/(arm+'-production.html.gz')).write_bytes(gzip.compress(html.read_bytes()));print(json.dumps(row),flush=True)
