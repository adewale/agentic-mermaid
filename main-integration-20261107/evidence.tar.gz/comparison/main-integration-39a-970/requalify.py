from pathlib import Path
import json,os,subprocess,gzip,time
base=Path(__file__).parent;old=json.loads((base/'old-jobs-preserved.json').read_text());jobs=[]
for index,item in enumerate(old):
 mode=item.get('backend',item['arm']);arm=item['arm'] if 'backend' in item else item['revision'];root='/tmp/pr449-current-main-39a-20261107' if arm=='main' else '/tmp/pr449-main-integration-20261029-762';head='39a500425f6b74eb486b9add9e90d538fab6a914' if arm=='main' else '1693c2a2b7fd93cb5da11f1a358d162180fa19cc';dest=base/'products'/item['caseId']/arm/mode
 job={**item,'root':root,'expectedHead':head,'revision':arm,'arm':mode,'backend':mode,'out':str(dest)};prior=Path(item['priorReference'])
 if (prior/'actual.svg.gz').exists():job['bindingReference']={'svgReference':str(prior/'actual.svg.gz'),'receiptReference':str(prior/'actual.receipt.json.gz'),'sourceHead':item['expectedHead']}
 else:job.pop('bindingReference',None)
 jobs.append(job)
(base/'qualification-manifest.json').write_text(json.dumps({'basis':'Existing 36 frozen jobs; main and candidate changed. No re-enrollment or exclusion. Full SVG and entire receipt, no runtime ratio.', 'jobs':jobs},indent=2)+'\n')
env=dict(os.environ,AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0');rows=[]
for job in jobs:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=job['root'],text=True).strip()==job['expectedHead']
 assert subprocess.run(['git','diff','--quiet','HEAD','--','src'],cwd=job['root']).returncode==0
 dest=Path(job['out']);dest.mkdir(parents=True,exist_ok=True);assert not (dest/'RESULT.json.gz').exists(),'Never overwrite retained outcome';(dest/'job.json').write_text(json.dumps(job,indent=2)+'\n')
 with (dest/'worker.log').open('w') as log:
  try:p=subprocess.run(['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','/tmp/pr449-week-comparison-20261101/main-vs-pr-741/capture.mjs',str(dest),str(dest/'job.json')],cwd=job['root'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90);exit=p.returncode
  except subprocess.TimeoutExpired:exit='timeout'
 if (dest/'RESULT.json.gz').exists():r=json.loads(gzip.decompress((dest/'RESULT.json.gz').read_bytes()))
 else:r={'status':'unknown-worker','actualPublicCalls':'unknown'}
 row={'case':job['caseId'],'revision':job['revision'],'mode':job['backend'],'exit':exit,'status':r['status'],'actualPublicCalls':r['actualPublicCalls'],'proof':r.get('proof',{}).get('status'),'binding':r.get('bindingValidation')};rows.append(row)
 (base/'QUALIFICATION.json').write_text(json.dumps({'completed':len(rows),'expected':len(jobs),'rows':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
