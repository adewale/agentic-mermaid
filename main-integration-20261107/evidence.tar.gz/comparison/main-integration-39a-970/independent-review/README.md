# Independent source-boundary review

Recorded 7 November 2026 from the already completed review calls. These files
copy the exact JavaScript supplied to `bun -e` and its JSONL stdout from the
session tool transcript; the probes were not rerun to create this archive.

Working directory: `/tmp/pr449-main-integration-20261029-762`.
Executable: `/tmp/pr449-tools-20261106/package/bin/bun` (session Bun 1.4.4).
Both probe commands exited 0. Recorded tool wall times were 0.701 and 1.193
seconds respectively; these are execution observations, not performance claims.
The original commands used `bun -e '<contents of *.executed.js>'`, with imports
resolved from the repository working directory; these source files are evidence
copies, not new repository entry points.

Source state tested: normal merge in progress, not a committed final head:

- HEAD/first parent: `970c9f807bd82b6c3e731aadef3585ee6b071523`.
- MERGE_HEAD/second parent: `39a500425f6b74eb486b9add9e90d538fab6a914`.
- Main's parser-source, typed parser, capability planning and source-MCP changes
  were present in the working tree alongside the inherited ownership/capture
  foundation. The initially reported conflict was only the browser payload
  ceiling; root owns its resolution and the integration commit.
- HEAD and MERGE_HEAD above were re-read when preserving this evidence. No
  production source was edited by this reviewer. A Git source fingerprint is
  not substituted for this explicit producer/state description.

## Expectation and observations

Parser failures should identify the same authored UTF-16 token across parser,
SVG and terminal boundaries after CRLF, frontmatter, entity projection, astral
characters and inline splitting. Identical text removed from accessibility
fields or comments must not capture the later grammar token. The position probe
independently derives expected positions from the last authored malformed token.
Five Flowchart sources matched parse/SVG/ASCII positions. Two sequence sources
matched SVG/ASCII positions; permissive agent parsing returned success for their
unsupported statement, which is not claimed as a parser/render equivalence
failure. Exact source strings and observed diagnostics are in the JSONL.

The source-tool helper should use the canonical renderer under the same hosted
policy. For one nested Flowchart with astral/entity label text, the observed SVG
strings were byte-exact and JSON serialization of the entire receipts was equal.
The complete SVG and receipt objects were compared in memory and were not printed
or retained by the original call; only the actual observed equality results are
archived here. No product files are invented or regenerated for this archive.

Local and hosted source-tool admission rejected nonstring source, an unknown
argument and a noninteger targetWidth with -32602. Hosted admission rejected
17,000 astral characters (over 64 KiB UTF-8 despite fewer UTF-16 code units) as
SOURCE_TOO_LARGE before rendering.

Code inspection traced the capability decision cache to recursively captured,
frozen family/backend metadata and executable hooks. Per-request host backend
selection precedes tuple lookup. No additional cache was introduced by the
reviewer and no getter/capture regression was reproduced.

## Conclusion and limits

No actionable integration defect reproduced in this bounded review. Root's
existing parser, source-MCP and ownership suites supply their own recorded
qualification. This review does not establish full-suite, performance,
whole-diagram ink, final-head CI or readiness claims. Keep the campaign's original
payload ceilings and stopped six-pass/raw representation trials unchanged.
