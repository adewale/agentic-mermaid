from pathlib import Path
import os,json,subprocess,datetime,time
out=Path(__file__).parent;cases=json.loads((out/'CASES.json').read_text());rows=[];source='3f2c26bd860eadcfb48746eabb45801ab8e07c7a';deadline=datetime.datetime.fromisoformat('2026-11-09T20:00:00+00:00')
for i,c in enumerate(cases):
 for cache in [0,1]:
  for replica in [0,1]:
   order=[['elk','trinity','agentic'],['agentic','trinity','elk']][(cache+replica+i)%2]
   for backend in order:
    if datetime.datetime.now(datetime.timezone.utc)>=deadline:raise SystemExit('Owner deadline reached; no new work')
    name=f'c{i:02d}-cache{cache}-r{replica}-{backend}';p=out/'measurements'/name;p.parent.mkdir(exist_ok=True);start=time.monotonic()
    with (p.parent/(name+'.log')).open('w') as log:
     try:r=subprocess.run(['node','--expose-gc',str(out/'measure.mjs'),str(p),str(out/'jobs'/f'{i:02d}-{backend}.json')],env={**os.environ,'AGENTIC_MERMAID_ELK_CACHE':str(cache)},stdout=log,stderr=subprocess.STDOUT,timeout=90);status=r.returncode
     except subprocess.TimeoutExpired:status='bounded-process-timeout90s'
    row={'name':name,'case':c['id'],'caseIndex':i,'family':c['family'],'cache':cache,'replica':replica,'backend':backend,'exit':status,'processWallSeconds':time.monotonic()-start};rows.append(row)
    (out/'MEASUREMENT-RUNS.json').write_text(json.dumps({'source':source,'runs':rows,'scope':'Existing full-product source collector;30frozen inputs, serialfreshNode24processes,cache0/1 x2replicas. Literalpreludesuntimed. Profile/timedobserversoff. No newruntime source or benchmarkframework.'},indent=2)+'\n')
 print(json.dumps({'caseIndex':i,'case':c['id'],'processes':len(rows),'failures':sum(r['exit']!=0 for r in rows)}),flush=True)
