from pathlib import Path
import json
out=Path(__file__).parent
p=json.loads((out/'PERFORMANCE.json').read_text())
m=json.loads((out/'SVG-METRICS.json').read_text())
cases=json.loads((out/'CASES.json').read_text())
def cell(index,backend,cache=0):
 return next(r for r in p['rows'] if r['caseIndex']==index and r['backend']==backend and r['cache']==str(cache))
def phase(index,backend,cache,name):
 r=cell(index,backend,cache)['phases'].get(name)
 if not r:return '—'
 if r['returned']!=r['attempts']:return f"{r['returned']}/{r['attempts']} returned"
 return f"{r['returnedCost']['wallMs']['median']:.2f}"
def triple(index,backend,cache=0):
 return '/'.join(phase(index,backend,cache,k) for k in ['cold-render','repeat1','repeat2'])
def metric(index,backend):
 return next(r for r in m['rows'] if r['id']==cases[index]['id'] and r['backend']==backend)
lines=['# ELK, Native and Trinity: frozen-workload costs','',
'Source **'+p['source']+'**; layout runtime4db8570d389246bb5f1eede8c5b1899fe6cd687e. Source was unchanged during acquisition. Existing draftPR602; deadline9November2026,20:00UTC. This adds the first complete frozen30 cost coverage; it is not an optimization or new visible-correctness gain. Overlap with earlier selected-case timings is validation, not a claimed improvement.','',
'## What was measured','',
f"{p['completedProcesses']} serial fresh Node24 processes,30 frozen inputs ×3backends ×2cache modes ×2process replicas: **{p['totals']['attempts']} timed attempts, {p['totals']['returned']} returned, {p['totals']['proofPassed']} proof-passed, {p['totals']['errors']} product errors**. Process failures: {len(p['processFailures'])}; missing terminal records: {len(p['missing'])}. Product errors are caught and retained even when the collector exits0.", '',
'The existing full-product collector and summary were reused. Exact source/options, literal preludes and original seven authored edits remain. No invented edit is added to the23 other cases. Full SVG and entire receipt serialization/byte counting occur inside each render window. Imports, explicit GC, compression/writes and cache audits are outside. Profiler sampling and timed observers are off; empty profile placeholders are not CPU profiles. No concurrent builds/tests/profiles/browser or archive jobs ran. Two replicas are descriptive, not p95 or statistically established superiority.', '',
'“First target” follows module import/inspector setup; after a literal prelude it is also preconditioned by that render. It is not application/package/browser startup. Cache0 is the existing AGENTIC_MERMAID_ELK_CACHE switch and leaves other derived caches live. Repeat1/2 and edit/edit2 in one process are correlated. Refusal/error durations are not equivalent completed-work costs. Shared family measurement, capture and final emission contribute to every backend; these are not isolated kernel timings.','',
'## Delivery, meaning and proof','',
'| Frozen30 original-input outcome | ELK | Native | Trinity |','|---|---:|---:|---:|']
def disposition(i,b):
 r=cell(i,b,0)['phases']['cold-render']
 if r['returned']==r['attempts']:return 'returned / proof-passed' if all(v.get('proof')=='passed' for v in r['outcomes']) else 'returned / proof unknown'
 names={v.get('failure',{}).get('name') for v in r['outcomes']}
 if names=={'RenderConfigError'}:return 'shared input errors'
 if names=={'GraphLayoutUnsupportedError'} and 'authored-image-presence' in cases[i].get('features',[]):return 'unsupported image'
 return 'other error / unknown'
for status in ['returned / proof-passed','unsupported image','shared input errors','other error / unknown']:
 counts=[]
 for b in ['elk','agentic','trinity']:
  n=0
  for i in range(30):
   if disposition(i,b)==status:n+=1
  counts.append(n)
 lines.append('|'+status+'|'+ '|'.join(map(str,counts))+'|')
lines += ['',
'The two shared invalid fontSize API inputs remain input errors. Trinity’s controlled-image refusal is separate: Native/ELK return vector placeholders whose existing independent embedded-image criterion fails. Returned/proof-passed is not complete visible correctness. The unchanged613-criterion ledger remains ELK575P/6U/29blocked/3failed, Native576/6/28/3, Trinity564/19/28/2; common parser/prelude credit is not selected-kernel delivery. All prior unknowns and failures remain. Broad capacity/stress domains are not established by this small frozen cohort.','',
f"Artifact validation: {p['totals']['priorSVGExact']}/{p['totals']['priorSVGComparisons']} newly acquired original SVGs are byte-exact to the prior observed cohort. Returned repeat whole-SVG/entire-receipt comparisons: {p['totals']['repeatExact']}/{p['totals']['repeatPairs']}. Returned edit/edit2 whole products exact: {p['totals']['editExact']}/{p['totals']['editPairs']}. Equality flags on errors are not counted. These checks preserve earlier observed output; they are not new raster/meaning coverage.", '',
'## First target and uncached repeats','',
'Median wall ms, first target/repeat1/repeat2, cache0, two process replicas. These six portable inputs have no prelude. Import remains outside the windows.','',
'| Family | ELK | Native | Trinity |','|---|---:|---:|---:|']
for i in range(6):lines.append('|'+cases[i]['family']+'|'+'|'.join(triple(i,b) for b in ['elk','agentic','trinity'])+'|')
lines += ['', '## Cached repeats and authored edits','',
'These are the six original configuration-reset workflows: literal different-family preludes run untimed, then target/repeats and the original authored edit/edit2. Each cell is repeat2/edit2 median ms; separate fresh processes per mode. Do not splice their preconditioned first-target costs into the table above.','',
'| Family/mode | ELK | Native | Trinity |','|---|---:|---:|---:|']
for i in [15,17,19,21,23,25]:
 for cache in [0,1]:lines.append('|'+cases[i]['family']+'/cache'+str(cache)+'|'+'|'.join('/'.join(phase(i,b,cache,k) for k in ['repeat2','edit2']) for b in ['elk','agentic','trinity'])+'|')
lines += ['', '## Every original input','',
'Cache0 first-target/repeat1/repeat2 median ms. Configuration-reset rows include their exact preludes. All ranges, per-phase CPU, process lifetime RSS, heap snapshots/deltas, cache audits and complete failures are in PERFORMANCE.json and the raw RESULT files. Error cells retain their costs in attemptWallMs; no speed ratio uses them.','',
'| Frozen input | ELK | Native | Trinity |','|---|---:|---:|---:|']
for i,c in enumerate(cases):lines.append('|'+c['id']+'|'+'|'.join(triple(i,b) for b in ['elk','agentic','trinity'])+'|')
lines += ['', '## Geometry and output bytes','',
'Actual acquired SVG viewport and owned untransformed orthogonal relationship carriers, using existing crossing/overlap helpers. Unknown transforms, paths, ownership or roster mismatches are retained as unknown, not zero. Notes contribute to viewport; note tethers are not graph relationships. This is geometric/output observation, not a new raster readability, marker contact or image decode proof. SVG-METRICS.json retains every cell and unknown.','',
'| Portable family/backend | Area | Wire | Bends/crossings | SVG gzip9/Br11 bytes |','|---|---:|---:|---:|---:|']
for i in range(6):
 for b in ['elk','agentic','trinity']:
  r=metric(i,b);g=r.get('geometry');lines.append('|'+cases[i]['family']+'/'+b+'|'+str(round(r['area'],2))+'|'+(f"{g['wire']:.3f}" if g else 'unknown')+'|'+(f"{g['bends']}/{g['crossings']}" if g else 'unknown')+'|'+f"{r['gzip9']}/{r['brotli11']}"+'|')
lines += ['',
'Actual complete SVG+receipt JSON and standalone SVG gzip9/Brotli11 byte streams are retained in payloads/ and svg-payloads/ with sizes/hashes. They use Node24’s matching codecs across all arms. These are render-result payloads, not shipped renderer code or compressed network transfer. The prior equal13-input lazy browser union remains separately bound to runtime4db: ELK/Native/Trinity gzip856327/484054/476329, Brotli687180/415162/408167, requests41/47/48 including binding. Raw serving/offline compression gives no compressed-wire/startup claim. The artifact-only notice fix now makes standalone editor gzip1338451 (4243 fewer), still3951 over its original1334500 ceiling; no cap/default/version change.','',
'## Memory limits','',
'Peak RSS is the process lifetime high-water mark, including imports, TypeScript transformation, inspector, preludes and earlier compression/artifact work. It cannot be reset per call. Before/after heap snapshots are not peaks, allocation rate, settled retention or leak evidence; the original warmup SVG/receipt stays live. First-target and repeat heap deltas also differ in pre-call explicit GC. Do not sum row RSS or claim browser/package memory superiority. Per-input raw values and ranges remain available.','',
'## Decision and remaining losses','',
'Retain ELK and draft status. Trinity27/30 versus28 for controls is delivery/proof coverage only; actual image, broader domains/capacity, contacts152/372/201/241, crossing276, Sparse32 and resource ceilings remain. This acquisition adds comparable cost coverage and preserves adverse cells; it does not remove a failure, prove universal performance/memory dominance or qualify retirement. The header, source-group ordering, image shortcut, heap directory and XML bitset/streaming probes remain stopped. No new cache or runtime optimization ships. Original2dad baseline and equivalent pinned Pele runtime remain unavailable. Replacement24 stays sealed.','',
'Exact source3f2 CI42552670015 completed with failure: Sparse32 emitted-proof owner, lazy-family size ceilings, demo payload and generated advisory; other passed lanes are recorded in the PR. Original limits remain. No source edits during collection or new source commit for this report. Existing evidence branch preserves raw jobs, products, costs, errors, review and reproduction; no retained work/evidence deleted.','',
'Reproduce with the existing Node24 source loader in measure.mjs and exact jobs/*.json; run.py schedules the serial comparison and honors the owner deadline before starting new processes. summarize-cost.mjs and run-svg-metrics.mjs only read acquired products after collection. cost-review.md records independent acquisition review and its limits.']
extra=['Cache0 portable inputs, two process replicas. Cells show lifetime RSS range / repeat2 heap-used-after snapshot range, MiB.','',
'| Family | ELK | Native | Trinity |','|---|---:|---:|---:|']
for i in range(6):
 values=[]
 for b in ['elk','agentic','trinity']:
  v=cell(i,b,0)['phases']['repeat2'];rss=v['returnedCost']['peakRssKiB']['range'];heap=v['heapUsedAfter']['range'];values.append(f'{rss[0]/1024:.1f}–{rss[1]/1024:.1f} / {heap[0]/1048576:.1f}–{heap[1]/1048576:.1f}')
 extra.append('|'+cases[i]['family']+'|'+'|'.join(values)+'|')
extra += ['', '## Complete render-result JSON bytes','',
'Cache0 original products, complete SVG plus entire receipt JSON. Actual Node24 gzip9/Brotli11 artifacts are retained; replicas match. This is response payload, not renderer download.','',
'| Family | ELK gzip/Br | Native gzip/Br | Trinity gzip/Br |','|---|---:|---:|---:|']
for i in range(6):
 values=[]
 for b in ['elk','agentic','trinity']:
  v=cell(i,b,0)['products'][0]['compression'];values.append(str(v['gzip9']['bytes'])+'/'+str(v['brotli11']['bytes']))
 extra.append('|'+cases[i]['family']+'|'+'|'.join(values)+'|')
extra += ['', '## Adverse and unavailable observations','',
'Retain every adverse cell, including cache1 workflow flowchart repeat/edit ELK5.24/15.26ms versus Trinity7.43/31.09; Architecture19.66/19.06 versus63.65/47.68. No general speedup follows. Nested-State cache0 first-target Trinity median1613.80ms has range261.02–2966.59; ELK529.64–609.88. Its repeat2 Trinity38.69–102.07 versusELK62.87–151.07ms overlaps. This is an adverse sample/variability finding, not a stable kernel slowdown ratio or reason for a speculative optimization. Raw per-process CPU and memory remain.','',
'Six returned SVG geometry rows remain unknown in this generic extraction: three Class namespace products include note connectors beyond graph relationships; three State pseudo-state products use generated endpoint identities outside the authored endpoint roster. Their actual SVGs/receipts and earlier family-specific observations remain. Unknown is not a layout failure or zero; do not weaken roster correspondence to fill a table. Prior Class graph-only wire/area observations remain separately bound to the owner-specific extraction.','']
at=lines.index('## Decision and remaining losses');lines[at:at]=extra
(out/'README.md').write_text('\n'.join(lines)+'\n')
print('Wrote report',len(lines),'lines')
