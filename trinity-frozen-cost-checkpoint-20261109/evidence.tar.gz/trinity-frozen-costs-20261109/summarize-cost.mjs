// Adapted from the existing Class full-product cost summary. No runtime code.
import fs from 'node:fs';
import path from 'node:path';
import { gunzipSync, gzipSync, brotliCompressSync, constants } from 'node:zlib';
import { createHash } from 'node:crypto';
const p = path.dirname(new URL(import.meta.url).pathname);
const read = f => JSON.parse(gunzipSync(fs.readFileSync(f)));
const runs = JSON.parse(fs.readFileSync(p + '/MEASUREMENT-RUNS.json'));
const priorRoot = '/tmp/pr449-week-comparison-20261101/trinity-class-scopes-20261109';
const prior = JSON.parse(fs.readFileSync(priorRoot + '/COHORT-PRODUCTS.json'));
const groups = new Map(), artifacts = [], missing = [];
fs.mkdirSync(p + '/payloads', { recursive: true });
for (const run of runs.runs) {
  const dir = p + '/measurements/' + run.name, file = dir + '/RESULT.json.gz';
  if (!fs.existsSync(file)) { missing.push(run); continue; }
  const x = read(file), key = [x.job.caseIndex, x.cache, x.job.backend].join('/');
  if (!groups.has(key)) groups.set(key, []);
  groups.get(key).push({ run, dir, x });
}
const bounds = values => {
  const a = values.filter(Number.isFinite).sort((a, b) => a - b);
  return a.length ? { n: a.length, median: (a[Math.floor((a.length - 1) / 2)] + a[Math.ceil((a.length - 1) / 2)]) / 2, range: [a[0], a.at(-1)] } : null;
};
const hash = data => createHash('sha256').update(data).digest('hex');
const rows = [], totals = { attempts: 0, returned: 0, proofPassed: 0, errors: 0, repeatPairs: 0, repeatExact: 0, editPairs: 0, editExact: 0, priorSVGComparisons: 0, priorSVGExact: 0 };
for (const [key, replicates] of groups) {
  const job = replicates[0].x.job, r = { caseIndex: job.caseIndex, case: job.case, family: job.family, cache: replicates[0].x.cache, backend: job.backend, replicas: replicates.length, preconditioned: !!job.prelude.length, importMs: bounds(replicates.map(v => v.x.importMs)), phases: {}, products: [], workflowChecks: [] };
  for (const phase of ['cold-render', ...job.phases]) {
    const a = replicates.map(({ x }) => x.rows.find(r => r.phase === phase)).filter(Boolean);
    const returned = a.filter(r => r.status === 'returned');
    totals.attempts += a.length; totals.returned += returned.length; totals.proofPassed += returned.filter(r => r.proof?.status === 'passed').length; totals.errors += a.length - returned.length;
    r.phases[phase] = { attempts: a.length, returned: returned.length, outcomes: a.map(v => ({ status: v.status, proof: v.proof?.status, failure: v.failure })), attemptWallMs: bounds(a.map(v => v.wallMs)), returnedCost: Object.fromEntries(['wallMs', 'cpuMs', 'peakRssKiB', 'bytes'].map(k => [k, bounds(returned.map(v => v[k]))])), heapUsedAfter: bounds(returned.map(v => v.after.heapUsed)), heapUsedDelta: bounds(returned.map(v => v.after.heapUsed - v.before.heapUsed)) };
  }
  for (const { dir, x, run } of replicates) {
    const cold = x.rows[0];
    const workflow = { replica: run.replica, preludeOutcomes: x.preludeRows, cacheAudit: x.cacheAudit };
    for (const v of x.rows.filter(v => v.phase.startsWith('repeat'))) {
      if (cold.status !== 'returned' || v.status !== 'returned') continue;
      totals.repeatPairs++; if (v.wholeSvgExactWarmup && v.entireReceiptExactWarmup) totals.repeatExact++;
    }
    const edit = x.rows.find(v => v.phase === 'edit'), edit2 = x.rows.find(v => v.phase === 'edit2');
    if (edit?.status === 'returned' && edit2?.status === 'returned') {
      totals.editPairs++;
      if (['svg', 'receipt.json'].every(ext => gunzipSync(fs.readFileSync(dir + '/edit.' + ext + '.gz')).equals(gunzipSync(fs.readFileSync(dir + '/edit2.' + ext + '.gz'))))) totals.editExact++;
      workflow.editChangedFromReturnedOriginal = cold.status === 'returned' ? edit.editChanged && edit2.editChanged : null;
      const expectedEdit = prior.find(v => v.id === job.case + ':edit' && v.backend === job.backend);
      if (expectedEdit?.delivery === 'returned') workflow.editSVGExactPrior = gunzipSync(fs.readFileSync(dir + '/edit.svg.gz')).toString() === fs.readFileSync(priorRoot + '/products/' + expectedEdit.stem + '.svg', 'utf8');
    }
    r.workflowChecks.push(workflow);
    if (cold.status !== 'returned') continue;
    const svg = gunzipSync(fs.readFileSync(dir + '/warmup.svg.gz')).toString(), receipt = read(dir + '/warmup.receipt.json.gz');
    const retained = prior.find(v => v.id === job.case && v.backend === job.backend);
    const priorSVGExact = retained?.delivery === 'returned' ? svg === fs.readFileSync(priorRoot + '/products/' + retained.stem + '.svg', 'utf8') : undefined;
    if (priorSVGExact !== undefined) { totals.priorSVGComparisons++; if (priorSVGExact) totals.priorSVGExact++; }
    const data = Buffer.from(JSON.stringify({ svg, receipt })), prefix = 'payloads/' + run.name;
    const compressed = [ ['gzip9', '.json.gz', gzipSync(data, { level: 9 })], ['brotli11', '.json.br', brotliCompressSync(data, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } })] ];
    const payload = { replica: run.replica, raw: data.length, rawMatchesTimedProductBytes: data.length === cold.bytes, sha256: hash(data), priorSVGExact, selected: receipt.layoutDecisions, compression: {} };
    for (const [codec, ext, bytes] of compressed) { fs.writeFileSync(p + '/' + prefix + ext, bytes); payload.compression[codec] = { file: prefix + ext, bytes: bytes.length, sha256: hash(bytes) }; artifacts.push(payload.compression[codec]); }
    r.products.push(payload);
  }
  r.replicaProductComparisons = Math.max(0, r.products.length - 1);
  r.replicaWholeProductsExact = r.replicaProductComparisons ? r.products.every(v => v.sha256 === r.products[0].sha256) : null;
  rows.push(r);
}
rows.sort((a, b) => a.caseIndex - b.caseIndex || a.cache.localeCompare(b.cache) || a.backend.localeCompare(b.backend));
const result = { source: runs.source, runtime: process.version, completedProcesses: runs.runs.length, processFailures: runs.runs.filter(r => r.exit !== 0), missing, totals, scope: 'Frozen30 source API comparison; exact target sources/options and literal prelude workflows. Two fresh process replicas per backend/cache/input. Full SVG+entire receipt consumed; imports, explicit GC, compression and writes outside timing; sampling and timed observers disabled. First target after a prelude is preconditioned. Error costs are not completed costs. Lifetime RSS includes harness/imports/artifact work; heap snapshots are not peaks or settled retention. Original warmup product remains retained. Node24 gzip9/Brotli11 artifacts are actual combined SVG+receipt JSON, not browser/editor/network payloads. No general ratios or p95.', rows };
fs.writeFileSync(p + '/PERFORMANCE.json', JSON.stringify(result, null, 2) + '\n');
fs.writeFileSync(p + '/PAYLOAD-FILES.json', JSON.stringify(artifacts, null, 2) + '\n');
console.log(JSON.stringify({ processes: result.completedProcesses, processFailures: result.processFailures.length, missing: missing.length, totals }));
