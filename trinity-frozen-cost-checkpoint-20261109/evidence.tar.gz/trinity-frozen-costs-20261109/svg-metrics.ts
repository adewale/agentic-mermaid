// Existing carrier/crossing metrics applied to acquired SVG, with unknowns retained.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { gunzipSync, gzipSync, brotliCompressSync, constants } from 'node:zlib'
import { SaxesParser } from '/tmp/pr449-main-integration-20261029-762/node_modules/saxes/saxes.js'
import { countPolylineCrossings } from '/tmp/pr449-main-integration-20261029-762/src/shared/edge-crossings.ts'
import { countOpposingRouteOverlaps, countParallelRouteOverlaps } from '/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts'
const root = '/tmp/pr449-week-comparison-20261101/trinity-frozen-costs-20261109'
const cases = JSON.parse(readFileSync(root + '/CASES.json', 'utf8')), rows: any[] = []
mkdirSync(root + '/svg-payloads', { recursive: true })
for (const [index, c] of cases.entries()) for (const backend of ['elk', 'agentic', 'trinity']) {
  const name = `c${String(index).padStart(2, '0')}-cache0-r0-${backend}`, dir = root + '/measurements/' + name
  let result: any
  try { result = JSON.parse(gunzipSync(readFileSync(dir + '/RESULT.json.gz')).toString()) }
  catch (error) { rows.push({ id: c.id, backend, unavailable: String(error) }); continue }
  const outcome = result.rows[0]
  if (outcome.status !== 'returned') { rows.push({ id: c.id, backend, status: outcome.status, failure: outcome.failure }); continue }
  const bytes = gunzipSync(readFileSync(dir + '/warmup.svg.gz')), svg = bytes.toString(), edges: any[] = [], unknown: string[] = []
  const stack: boolean[] = [], number = /[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?/gi
  let width = NaN, height = NaN
  const parser = new SaxesParser({ xmlns: true })
  parser.on('opentag', tag => {
    const a = Object.fromEntries(Object.entries(tag.attributes).map(([key, value]: any) => [key, value.value])) as Record<string, string>
    const transformed = !!stack.at(-1) || a.transform !== undefined; stack.push(transformed)
    if (tag.local === 'svg' && stack.length === 1) { width = Number(a.width); height = Number(a.height) }
    if (a['data-role'] !== 'edge' && a['data-role'] !== 'relationship') return
    if (!['path', 'polyline', 'line'].includes(tag.local)) return
    if (transformed) { unknown.push('transformed relationship carrier'); return }
    if (a['data-from'] === undefined || a['data-to'] === undefined) { unknown.push('missing endpoint ownership'); return }
    let coordinates: number[]
    if (tag.local === 'line') {
      if (['x1', 'y1', 'x2', 'y2'].some(key => a[key] === undefined)) { unknown.push('implicit line coordinate'); return }
      coordinates = ['x1', 'y1', 'x2', 'y2'].map(key => Number(a[key]))
    } else {
      const value = tag.local === 'polyline' ? a.points : a.d
      if (value === undefined || tag.local === 'path' && ((value.match(/M/g) ?? []).length !== 1 || value.replace(number, '').replace(/[ML\s,]/g, '') !== '')) { unknown.push('non-polyline path'); return }
      coordinates = (value.match(number) ?? []).map(Number)
    }
    if (coordinates.length < 4 || coordinates.length % 2 || coordinates.some(v => !Number.isFinite(v))) { unknown.push('nonfinite/incomplete coordinates'); return }
    edges.push({ source: a['data-from'], target: a['data-to'], style: 'solid' as const, points: Array.from({ length: coordinates.length / 2 }, (_, i) => ({ x: coordinates[i * 2]!, y: coordinates[i * 2 + 1]! })) })
  })
  parser.on('closetag', () => { stack.pop() })
  parser.write(svg).close()
  let wire = 0, bends = 0
  for (const edge of edges) {
    let last = ''
    for (let i = 1; i < edge.points.length; i++) {
      const a = edge.points[i - 1]!, b = edge.points[i]!, length = Math.hypot(b.x - a.x, b.y - a.y)
      if (!length) continue
      wire += length
      const axis = a.x === b.x ? 'v' : a.y === b.y ? 'h' : 'diagonal'
      if (axis === 'diagonal') unknown.push('nonorthogonal carrier')
      if (last && last !== axis) bends++
      last = axis
    }
  }
  const expected = c.expected?.edges, expectedRelationships = expected?.length
  const comparable = Array.isArray(expected) && expected.every((edge: any) => typeof edge.source === 'string' && typeof edge.target === 'string')
  let rosterExact: boolean | null = null
  if (comparable) {
    const occurrences = new Map<string, number>(), key = (source: string, target: string) => JSON.stringify([source, target])
    for (const edge of edges) { const k = key(edge.source, edge.target); occurrences.set(k, (occurrences.get(k) ?? 0) + 1) }
    const take = (source: string, target: string): boolean => { const k = key(source, target), n = occurrences.get(k) ?? 0; if (!n) return false; occurrences.set(k, n - 1); return true }
    rosterExact = expected.length === edges.length
    // Reserve directed occurrences before admitting either orientation of an
    // undirected authored pair, preserving parallel-edge multiplicity.
    for (const edge of expected) if (edge.directed !== false && !take(edge.source, edge.target)) rosterExact = false
    for (const edge of expected) if (edge.directed === false && !take(edge.source, edge.target) && !take(edge.target, edge.source)) rosterExact = false
    if ([...occurrences.values()].some(n => n !== 0)) rosterExact = false
  }
  if (rosterExact !== true) unknown.push(comparable ? 'endpoint occurrence roster differs from authored edges' : 'independent endpoint roster unavailable')
  const gzip = gzipSync(bytes, { level: 9 }), brotli = brotliCompressSync(bytes, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } })
  writeFileSync(root + '/svg-payloads/' + name + '.svg.gz', gzip); writeFileSync(root + '/svg-payloads/' + name + '.svg.br', brotli)
  rows.push({ id: c.id, family: c.family, backend, status: outcome.status, proof: outcome.proof?.status, width, height, area: width * height, observedRelationshipCarriers: edges.length, expectedRelationships, carrierRosterExact: rosterExact, geometryUnknown: unknown, geometry: unknown.length ? null : { wire, bends, crossings: countPolylineCrossings(edges), parallelOverlaps: countParallelRouteOverlaps(edges), opposingOverlaps: countOpposingRouteOverlaps(edges) }, svgBytes: bytes.length, gzip9: gzip.length, brotli11: brotli.length })
}
writeFileSync(root + '/SVG-METRICS.json', JSON.stringify({ source: '3f2c26bd860eadcfb48746eabb45801ab8e07c7a', runtime: process.version, scope: 'Actual acquired SVG root viewport and owned untransformed orthogonal relationship carriers; unknown paths/transforms/roster mismatches retained rather than coerced to zero. Existing crossing/overlap helpers. No raster readability or decoded image claim. Node gzip9/Brotli11 artifacts retained.', rows }, null, 2) + '\n')
console.log('SVG rows', rows.length, 'geometry available', rows.filter(r => r.geometry).length, 'unknown', rows.filter(r => r.geometryUnknown?.length).length)
