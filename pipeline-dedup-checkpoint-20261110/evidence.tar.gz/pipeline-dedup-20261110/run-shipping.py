import os,subprocess,time
p='/tmp/pr449-week-comparison-20261101/pipeline-dedup-20261110'
w='/tmp/pr449-week-comparison-20261101/native-only-20261109/worker.mjs'
for case in ['chain100','fanin100','chain300']:
 for arm,repeat in [('baseline',1),('shipping',1)]:
  out=f'{p}/shipping-paired-{arm}-{case}-{repeat}'
  with open(out+'.log','w') as log:
   result=subprocess.run(['node','--expose-gc',w,out,f'{p}/{arm}-{case}-job.json'],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'AGENTIC_MERMAID_ELK_CACHE':'0'})
  print(case,arm,repeat,'exit',result.returncode,flush=True)
  if result.returncode:raise SystemExit(result.returncode)
