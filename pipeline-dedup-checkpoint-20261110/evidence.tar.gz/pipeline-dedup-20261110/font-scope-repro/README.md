# Public group-font scope false proof

The exact String.raw child script from paint-certification.test.ts721 was extracted without modifications and executed in fresh Bun1.4.4 children via --eval. Bun preload onLoad supplied frozen original-module-path source overrides, never swapped working files. Loaded-file records verify all five modules. The five baseline sources match c3dc4630881bd904ed08c7d2a8696c248e684146 exactly: True.

Baseline and the four-file pipeline packet both falsely pass freeze-attribute despite the actual public SVG carrying <g class="mono"> and the emitted .mono font-family rule. The Inter-prepared block has no own fontFamily override; retained private class metadata was changed from mono to safe by a preimport Object.freeze hook. That is a public font-scope false proof, not an internal holder artifact.

The c3dc allocation optimization handed mutable private record literals to its captured freeze callback. Capturing a hook before module load does not make it authentic. The fix removes those fast paths for attributes, tags, emission records and parse records, restoring the earlier pinned data-property constructors. Every retained field is readonly/nonconfigurable before prevention; no new parser, cache, qualification framework, scan, fee or cap is introduced. Existing descriptor-prototype fallback behavior is retained.

Fresh five-source baseline / packet / fixed runs: safe=P/P/P; all ordinary and hooked mono controls=U/U/U; freeze-attribute=P/P/U with OUTPUT_SCOPE; writer-mutation=P/P/P. All nine full SVG strings are byte-exact across all arms. Existing owner passes1test/82expectations; one-file lint passes. No test expectation was changed.

Raw evidence: exact-child-script.js; baseline-five, packet-five and fixed-five preloads, loaded-module lists, full stdout packets and stderr logs; RESULTS.json; FIXED-PUBLIC-SVG-SUMMARY.json; fixed-group-emission.ts; fixed-owner.log. Prior four-source repro is also retained.

Only src/scene/group-emission.ts changed. It is frozen for root qualification, which must include this fifth runtime file.
