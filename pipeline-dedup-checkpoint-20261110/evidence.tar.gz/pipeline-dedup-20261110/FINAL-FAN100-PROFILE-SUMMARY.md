# Final fan-in100 profiler attribution

One frozen baseline/final source pair, explicit AGENTIC_MERMAID_ELK_CACHE=0. Existing worker and existing cold-profile wrapper; fully consumed SVG and entire receipt, module import separate. Sampling weights are diagnostic, not a speed ratio. No additional ABBA loops or production changes. Raw profiles, rows, whole products, jobs and four runtime overrides are retained.

| Phase | Baseline copy self / inclusive union ms | Final copy self / inclusive union ms | Baseline issue self ms | Final issue self ms |
|---|---:|---:|---:|---:|
| cold |37.79 /48.59|38.83 /45.88|1.92|3.16|
| warm repeat1 |33.11 /42.81|44.99 /51.73|1.46|3.97|
| edit1 |32.51 /42.88|34.98 /42.73|2.87|2.57|
| edit2 |21.16 /27.99|46.88 /53.69|2.14|1.13|

Recursive inclusive union counts each function once per sample, rather than summing recursive stack-frame weights. Profiler stop/inspector samples are outside measured render timers and are not charged to copy/XML work.

Attribution remains **unknown**. Copy can account for a material part of the adverse second edit sample (+25.7ms self), but the first edit inclusive weight is unchanged. XML issue and shared resource traversal do not show a matching edit increase: final resource-visit inclusive weights are0.29/0.30ms in the two edits. Unchanged layout also varies (115.3/85.4→102.3/101.3ms) and unchanged mark construction jumps in the final warm sample. This pair does not establish one causal regression component. The prior final unprofiled ABBA adverse fan/edit result remains valid evidence; these profiles do not replace it or establish a speedup.

Measured profiled render elapsed values, kept separate: cold670.7→682.3ms; warm281.4→460.6ms; edit1296.1→261.3ms; edit2229.9→319.2ms. No cross-phase ratio is claimed.

Whole products: {"svg": {"pairs": 4, "exact": 4}, "receipt.json": {"pairs": 4, "exact": 4}}

Full function/stage tables: FINAL-FAN100-PROFILE.txt and FINAL-FAN100-PROFILE.json. CPU handed back to root for qualification.
