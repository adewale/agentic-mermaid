import fs from 'node:fs'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {gzipSync,gunzipSync} from 'node:zlib'
import {createRequire} from 'node:module'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const {JSDOM}=createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
const root='/tmp/pr449-main-integration-20261029-762',base='/tmp/pr449-week-comparison-20261101/forest-source-ports-3b35c1b3d',scratch=fs.mkdtempSync('/tmp/pr449-forest-source-fonts-'),rows=[]
try {
 const fontFiles=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const bytes=fs.readFileSync(root+'/'+f.path);assert.equal(bytes.length,f.bytes);assert.equal(createHash('sha256').update(bytes).digest('hex'),f.sha256);const p=scratch+'/'+f.file;fs.writeFileSync(p,bytes);return p})
 for(const arm of ['before','after']){
  const out=base+'/'+arm+'/source-ink';fs.mkdirSync(out,{recursive:true});const raw=gunzipSync(fs.readFileSync(base+'/'+arm+'/actual.svg.gz')).toString(),dom=new JSDOM(raw,{contentType:'image/svg+xml'}),d=dom.window.document,carriers=[...d.querySelectorAll('[data-role="edge"][data-from="D"]')];assert.equal(carriers.length,2)
  const raster=(svg,name)=>{const rendered=new Resvg(inlineFontVarForRaster(svg),{background:'#ffffff',fitTo:{mode:'zoom',value:2},font:{fontFiles,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();fs.writeFileSync(out+'/'+name+'.png.gz',gzipSync(rendered.asPng()));return rendered}
  const full=raster(raw,'full'),serialize=()=>new dom.window.XMLSerializer().serializeToString(d)
  for(const carrier of carriers){const previous=carrier.getAttribute('visibility'),points=carrier.getAttribute('points').trim().split(/\s+/).map(p=>p.split(',').map(Number)),[a,b]=points;assert.equal(a[0],b[0]);const half=Number(carrier.getAttribute('stroke-width'))/2,roi={x0:a[0]-half-1,x1:a[0]+half+1,y0:Math.min(a[1],b[1])+1,y1:Math.max(a[1],b[1])-1};let darker=0,lighter=0
   try{carrier.setAttribute('visibility','hidden');const mask=raster(serialize(),carrier.getAttribute('data-to')+'-mask');assert.equal(full.width,mask.width);assert.equal(full.height,mask.height);for(let y=0;y<full.height;y++)for(let x=0;x<full.width;x++){const wx=(x+.5)/2,wy=(y+.5)/2;if(wx<roi.x0||wx>roi.x1||wy<roi.y0||wy>roi.y1)continue;const p=(y*full.width+x)*4,delta=full.pixels[p]+full.pixels[p+1]+full.pixels[p+2]-mask.pixels[p]-mask.pixels[p+1]-mask.pixels[p+2];if(delta < -12)darker++;if(delta>12)lighter++}}
   finally{if(previous===null)carrier.removeAttribute('visibility');else carrier.setAttribute('visibility',previous)}
   rows.push({arm,from:'D',to:carrier.getAttribute('data-to'),roi,darker,lighter,scope:'Only this carrier hidden; same-color sibling shafts/heads/cards remain; original viewport retained; first normal source run excludes its boundary and elbow.'})
  }
  dom.window.close()
 }
 fs.writeFileSync(base+'/source-ink.json',JSON.stringify({offlineRasterCalls:6,rows},null,2));console.log(JSON.stringify(rows))
}finally{fs.rmSync(scratch,{recursive:true,force:true})}
