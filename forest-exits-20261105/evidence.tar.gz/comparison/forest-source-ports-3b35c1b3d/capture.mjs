import fs from 'node:fs';
import path from 'node:path';


import {pathToFileURL,fileURLToPath} from 'node:url';
import {registerHooks,stripTypeScriptTypes} from 'node:module';
import {gzipSync} from 'node:zlib';
const root='/tmp/pr449-main-integration-20261029-762',out=process.argv[2],job=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
fs.mkdirSync(out,{recursive:true});
const maps={};
registerHooks({
 resolve(specifier,context,next){
  if(specifier.startsWith('.')&&context.parentURL?.startsWith(pathToFileURL(root+'/').href)){
   const p=new URL(specifier,context.parentURL);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.ts'))return next(p.href+'.ts',context);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.js'))return next(p.href+'.js',context);
  }
  if(specifier.startsWith('roughjs/bin/')&&!path.extname(specifier))return next(specifier+'.js',context);
  return next(specifier,context);
 },
 load(url,context,next){
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.json'))return{format:'json',shortCircuit:true,source:fs.readFileSync(fileURLToPath(url),'utf8')};
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.ts')){
   const original=fs.readFileSync(url.endsWith('/src/layout/passes/fanout.ts') && job.baselinePath ? job.baselinePath : fileURLToPath(url),'utf8');
   const source=stripTypeScriptTypes(original,{mode:'transform',sourceMap:true,sourceUrl:url});
   const m=source.match(/sourceMappingURL=data:application\/json;base64,([^\s]+)/);
   if(m)maps[url]=JSON.parse(Buffer.from(m[1],'base64').toString());
   return{format:'module',shortCircuit:true,source};
  }
  return next(url,context);
 }
});
const gz=(name,value)=>fs.writeFileSync(out+'/'+name+'.gz',gzipSync(typeof value==='string'?value:JSON.stringify(value)));
const api=await import(pathToFileURL(root+'/src/index.ts'));
const {withRenderStageObserver}=await import(pathToFileURL(root+'/src/render-stages.ts'));
const {withPerformanceObserver}=await import(pathToFileURL(root+'/src/performance-observations.ts'));
const stages=[],events=[];const start=performance.now(),cpu=process.cpuUsage();let product,failure;
try{product=withPerformanceObserver(e=>events.push(e),()=>withRenderStageObserver(s=>stages.push(s),()=>api.renderMermaidSVGWithReceipt(job.source,job.options))); const consumed=JSON.stringify(product);gz('actual.svg',product.svg);gz('actual.receipt.json',JSON.stringify(product.receipt));gz('RESULT.json',{status:'returned',actualPublicCalls:1,runtime:process.version,bytes:Buffer.byteLength(consumed),wallMs:performance.now()-start,cpu:process.cpuUsage(cpu),peakRssKiB:process.resourceUsage().maxRSS,stages,events,job});console.log(JSON.stringify({status:'returned',actualPublicCalls:1,bytes:Buffer.byteLength(consumed),wallMs:performance.now()-start}));}catch(e){failure={name:e.name,message:e.message,stack:e.stack,certification:e.certification};gz('RESULT.json',{status:'refused',actualPublicCalls:1,runtime:process.version,failure,job,stages,events});console.log(JSON.stringify(failure));process.exitCode=1;}
