import {readFileSync,writeFileSync} from 'node:fs'
import {layoutGraphSync} from '/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts'
import {parseMermaid} from '/tmp/pr449-main-integration-20261029-762/src/parser.ts'
const root='/tmp/pr449-week-comparison-20261101/contact-origin-3234',rows:any[]=[]
;(globalThis as any).__pr449Origin=(input:any,before:any,after:any,stage:string)=>{
 const n=input.nodes.findIndex((n:any)=>n.id==='n4'),from=input.nodes.findIndex((n:any)=>n.id==='n16'),to=input.nodes.findIndex((n:any)=>n.id==='n12'),e=input.edges.findIndex((e:any)=>e.source===from&&e.target===to)
 if(n<0||e<0)return
 const observe=(placed:any)=>{const box={...placed.nodes[n],width:input.nodes[n].width,height:input.nodes[n].height};return{node:box,route:placed.edges[e],gap:Math.min(...placed.edges[e].points.slice(1).map((b:any,i:number)=>{const a=placed.edges[e].points[i];return Math.max(box.x-Math.max(a.x,b.x),Math.min(a.x,b.x)-box.x-box.width,box.y-Math.max(a.y,b.y),Math.min(a.y,b.y)-box.y-box.height)-.875}))}}
 rows.push({stage,compact:input.compactPrivateRanks,authored:input.authoredCycleOrder,before:observe(before),after:observe(after)})
}
const job=JSON.parse(readFileSync(root+'/job152.json','utf8'));layoutGraphSync(parseMermaid(job.source),job.options)
writeFileSync(root+'/SHORTENING.json',JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows.map(r=>({stage:r.stage,compact:r.compact,authored:r.authored,before:r.before.gap,after:r.after.gap,changed:JSON.stringify(r.before)!==JSON.stringify(r.after)}))))
