import{readFileSync,writeFileSync}from'node:fs'
import{gunzipSync}from'node:zlib'
import{chromium}from'/tmp/pr449-main-integration-20261029-762/node_modules/playwright/index.mjs'
import{HOSTED_FONT_RESOURCES}from'/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import{inlineFontVarForRaster}from'/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import{createHash}from'node:crypto'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/contact-origin-3234'
const faces=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const bytes=readFileSync(root+'/'+f.path);if(createHash('sha256').update(bytes).digest('hex')!==f.sha256)throw Error('font mismatch');return `@font-face{font-family:Inter;src:url(data:font/woff2;base64,${bytes.toString('base64')}) format('woff2');font-weight:100 900}`}).join('\n')
const browser=await chromium.launch({headless:true});try{const context=await browser.newContext({viewport:{width:1000,height:1600},deviceScaleFactor:4});const page=await context.newPage();await page.route('**/*',r=>r.abort());
for(const[arm,path]of[['before',out+'/before/actual.svg.gz'],['after',out+'/candidate-final/actual.svg.gz']]){
 const svg=inlineFontVarForRaster(gunzipSync(readFileSync(path!)).toString());await page.setContent(`<style>html,body{margin:0;background:white}${faces}</style>${svg}`);await page.evaluate(()=>document.fonts.ready);await page.screenshot({path:out+'/'+arm+'-crop.png',clip:{x:278,y:831,width:28,height:43}});console.log(arm)
}
writeFileSync(out+'/CROPS.json',JSON.stringify({engine:'Chromium actual SVG screenshot',viewport:[1000,1600],deviceScaleFactor:4,clip:{x:278,y:831,width:28,height:43},font:'manifest-verified Inter, data URI, all network requests aborted',scope:'Two focused screenshot captures of unchanged saved SVG geometry; separate from Resvg four-mask raster counts.'},null,2)+'\n')
}finally{await browser.close()}
