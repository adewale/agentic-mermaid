import {readFileSync,writeFileSync} from 'node:fs'
import {LAYOUT_PIPELINE,layoutGraphSync} from '/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts'
import {parseMermaid} from '/tmp/pr449-main-integration-20261029-762/src/parser.ts'
const root='/tmp/pr449-week-comparison-20261101/contact-origin-3234'
const job=JSON.parse(readFileSync(root+'/job152.json','utf8')),rows:any[]=[],restore:any[]=[]
const observe=(c:any)=>{
 const n=c.nodes.find((n:any)=>n.id==='n4'),e=c.edges.find((e:any)=>e.source==='n16'&&e.target==='n12');if(!n||!e)return
 const gaps=e.points.slice(1).map((b:any,i:number)=>{const a=e.points[i];if(a.x!==b.x&&a.y!==b.y)return null;return Math.max(n.x-Math.max(a.x,b.x),Math.min(a.x,b.x)-(n.x+n.width),n.y-Math.max(a.y,b.y),Math.min(a.y,b.y)-(n.y+n.height))-.875})
 return {node:{id:n.id,shape:n.shape,x:n.x,y:n.y,width:n.width,height:n.height},points:e.points.map((p:any)=>({...p})),label:e.labelPosition&&{...e.labelPosition},minGap:Math.min(...gaps.filter((x:any)=>x!==null)),gaps}
}
try{
 for(const pass of LAYOUT_PIPELINE){const p=pass as any,old=p.run;restore.push([p,old]);p.run=(c:any)=>{const before=observe(c),value=old(c),after=observe(c);rows.push({pass:p.id,before,after,changed:JSON.stringify(before)!==JSON.stringify(after)});return value}}
 const graph=layoutGraphSync(parseMermaid(job.source),job.options)
 writeFileSync(root+'/STAGES.json',JSON.stringify(rows,null,2)+'\n');writeFileSync(root+'/FINAL-LAYOUT.json',JSON.stringify(graph)+'\n')
 console.log(JSON.stringify(rows.map(r=>({pass:r.pass,before:r.before?.minGap,after:r.after?.minGap,changed:r.changed})),null,2))
}finally{for(const[p,run]of restore)p.run=run}
