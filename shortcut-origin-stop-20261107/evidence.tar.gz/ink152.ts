import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';import{createHash}from'node:crypto'
import{Resvg}from'/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import{HOSTED_FONT_RESOURCES}from'/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import{inlineFontVarForRaster}from'/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import{prepareResvgMarkerOrientation}from'/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/contact-origin-3234'
const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const p=root+'/'+f.path;if(createHash('sha256').update(readFileSync(p)).digest('hex')!==f.sha256)throw Error('font mismatch');return p})
const rows=[]
for(const[arm,path]of[['before',out+'/before/actual.svg.gz'],['after',out+'/candidate-final/actual.svg.gz']]){
 const svg=gunzipSync(readFileSync(path!)).toString(),shaft=[...svg.matchAll(/<polyline\b[^>]*\/>/g)].find(m=>m[0].includes('data-from="n16"')&&m[0].includes('data-to="n12"'))![0],circle=[...svg.matchAll(/<rect\b[^>]*\/>/g)].find(m=>m[0].includes('data-id="node-shape:n4"'))![0]
 const attr=(key:string)=>Number(new RegExp('\\b'+key+'="([^"]+)"').exec(circle)![1]),cx=attr('x'),cy=attr('y'),r=attr('height'),zoom=2
 const images=[svg,svg.replace(shaft,''),svg.replace(circle,''),svg.replace(shaft,'').replace(circle,'')].map(s=>new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(s)),{background:'#fff',fitTo:{mode:'zoom',value:zoom},font:{fontFiles:fonts,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render())
 writeFileSync(out+'/'+arm+'152.png',images[0]!.asPng());const pixels=images.map(i=>i.pixels),roi={x0:Math.floor((cx-12)*zoom),x1:Math.ceil((cx+3)*zoom),y0:Math.ceil((cy+3)*zoom),y1:Math.floor((cy+r-3)*zoom)}
 let exposed=0,visible=0,attenuated=0,hidden=0;const delta=(a:Uint8Array,b:Uint8Array,k:number)=>Math.abs(a[k]!-b[k]!)+Math.abs(a[k+1]!-b[k+1]!)+Math.abs(a[k+2]!-b[k+2]!)
 for(let y=roi.y0;y<roi.y1;y++)for(let x=roi.x0;x<roi.x1;x++){const k=(y*images[0]!.width+x)*4,e=delta(pixels[2]!,pixels[3]!,k),v=delta(pixels[0]!,pixels[1]!,k);if(e>=6){exposed++;if(v>=6)visible++;if(v+6<e)attenuated++;if(v<6)hidden++}}
 rows.push({arm,sha256:createHash('sha256').update(svg).digest('hex'),roi,exposed,visible,attenuated,hidden,actualShaft:shaft,actualCircle:circle})
}
if(!rows[0]!.attenuated||rows[1]!.attenuated!==0||rows[1]!.visible!==rows[1]!.exposed)throw Error('Selected actual shaft/rectangle attribution did not confirm repair')
writeFileSync(out+'/INK152.json',JSON.stringify({font:'manifest-verified Inter; system fonts off',zoom:3,offlineRasters:8,rows,scope:'Selected border interval only; marginal shaft contribution with/without foreign rectangle, not whole-glyph readability.'},null,2)+'\n');console.log(JSON.stringify(rows.map(({actualShaft,actualCircle,...r})=>r)))
