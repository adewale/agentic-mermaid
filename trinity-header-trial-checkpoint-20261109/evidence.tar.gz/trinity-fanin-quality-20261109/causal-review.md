# Two-group fan-in: existing-geometry causal review

Reviewed retained `trinity-community-ports-20261109` direction products/PNGs and unchanged Flow routing source (community-port runtime e928 lineage; Class-only 4db857 changes do not alter this path). No renders, builds, tests, profiles, network or production edits. `intersections.ts` reads existing SVG/layout files and invokes the existing small crossing helper only; detailed locations and dock faces are saved in `INTERSECTIONS.json`.

**Smallest supported counterfactual: construct the related ancestor's header obstacle from its measured `headerHeight`, retaining the existing inflation and fallback when no height is known, instead of treating all `padding.top` as painted header.** This is a demonstrated terminal-eligibility discrepancy before side penalties or route strategy order. It is not yet a demonstrated crossing improvement; root must run any candidate.

## Actual intersections and tradeoff

The existing crossing helper and independent enumeration through its `crossingPoint` agree exactly:

| Retained product | Proper carrier crossings | Above label band | Within label band | Below label band | Crossing centers under halo/node |
| --- | ---: | ---: | ---: | ---: | ---: |
| Trinity TB | 29 | 9 | 0 | 20 | 0 |
| Trinity BT | 10 | 3 | 0 | 7 | 0 |
| ELK TB | 13 | 0 | 8 | 5 | 0 |
| ELK BT | 25 | 5 | 11 | 9 | 0 |

These are incidences per logical edge pair/location, not necessarily 29 different screen coordinates. `label band` means the vertical union range of all labels, not that a crossing hits a label. Mask checks use actual SVG rounded halo geometry and node rectangles: no crossing center lies inside them. The saved PNGs visibly corroborate many unmasked crossings. This is carrier geometry with a targeted mask check, not a new complete raster/ink qualification. It does not prove all nearby stroke pixels remain visible or certify other label/marker contacts.

Trinity TB is also materially more compact: area 293,974.2948 versus ELK 509,478.8339, wire 4,742.624 versus 5,878.856. ELK puts b1–b4 in a vertical column; Trinity puts them in a row. A crossing count alone is not a dominance result.

All eight TB Trinity source docks are S. Target docks by authored edge index are `W,S,S,S,E,S,E,E`; none is N. ELK TB targets are all N. In Trinity BT every target is S, while every source avoids N (`W,S,W,E,W,E,E,E`). Thus the direction reversal moves the north-face obstruction from four target cards to two source cards; its impact need not be symmetric.

## First concrete obstruction: padding becomes header ink

`src/layout/measured-graph-producer.ts:53–60` supplies distinct header height and padding. Defaults (`src/styles.ts:196,205–206`) yield header 28 and top padding 44 = 28 + 16. SVG `products/trinity-TB.svg` paints B's header at y253.45–281.45; B's full top padding extends to y297.45. The shared boundary router at `src/layout/compound-boundary-routes.ts:757` chooses **full `groups[group].padding.top` for this <=64-leaf, non-ancestor-edge case**, then inflates by 3 pixels (`max(2, edgeSpacing/2)`, edgeSpacing 6). Its forbidden header therefore extends to y300.45.

The preferred north stubs produced by `terminals` (`:22–32`, clearance 8 at `:710`) are:

| Target | Top face y | North stub y | Inside current padded header | Inside measured header + same 3px inflation |
| --- | ---: | ---: | --- | --- |
| b1,b2,b3 | 306.65 | 298.65 | yes | no |
| b4 | 298.20 | 290.20 | yes | no |

All fraction choices lie horizontally inside B's header span. `compound-lazy-visibility.ts:167–173` rejects blocked stub/port-to-stub roots **before** adding terminal penalty to path cost. For b4 even the north port is inside the inflated padded obstacle. No adjustment to N/E/S/W penalty can restore these candidates while this obstruction remains.

This difference is exactly 16 pixels of unpainted content padding. It is not a proposal to remove the painted header, its stroke clearance or labels. Actual header geometry is already used by final physical checks: `compound-boundary-routes.ts:482,533,592` use `headerHeight ?? padding.top`. The same geometry is painted by `renderer.ts:184,211–220`. The corrected north stubs clear that same inflated header; this establishes **local terminal eligibility only**, not a full free corridor around peers, labels and markers.

The 20 below-label TB crossings occur in the detours around B and its row of cards. Examples: e0 (`a1→b1`) crosses the left detours of e1/e2/e3 at (110.869,324.325), (123.869,324.325), (114.722,324.325); e2/e3 cross twice at y393.8. These are consistent with the forced side/bottom approaches, but the final selection history is not captured here and the 20 cannot all be attributed quantitatively to this one obstacle without a trial.

## Why not the other hypotheses first

The quotient loses descendant endpoint identity for local ordering (`agentic-compound-core.ts:53–71,92–99`); all eight become parallel A→B edges. Trinity's label vertices retain authored edge order when equal-barycenter ties remain (`trinity.ts:184–220`). The saved labels indeed run left-to-right in authored order: a1→b1, a2→b1, a1→b2, etc. This can explain source-side weaving, but changing it trades source and target correspondence; no optimal new order is demonstrated here. The concrete padded-header exclusion is a smaller falsifiable cause than redesigning that ordering. General port awareness already exists.

## One counterfactual and stop condition

Change only the measured-related-header obstacle's height selection at line757, preserving current margins, bounds, terminal samples/penalties, label shafts, route strategy sequence, shared ledgers and all final physical proof. Where `headerHeight` is absent, retain the existing padding fallback. Keep the same frozen source/style and inspect that node/frame/label placement is unchanged; then compare docks, complete paths, raw crossings, actual mask/ink contacts and resource/refusal results in all four directions. The exact target is removal of falsely blocked top-padding corridors, not a prescribed N-face result.

Stop this hypothesis if the corrected obstacle does not admit safer complete paths under the original budget, if header/text/marker/contact proof fails, or if the quality tradeoff is unacceptable. Do not force north docks, delete obstacles, skip proof, reset work, or revive direct-first/skip-third experiments. No claim is made that this will beat ELK TB or preserve BT's crossing advantage.
