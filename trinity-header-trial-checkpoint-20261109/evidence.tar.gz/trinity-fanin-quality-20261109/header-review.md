# Independent related-header obstacle review

Read-only comparison of retained baseline-router.ts and candidate-router.ts, measured producers/renderers/ancestor planning, and completed before/after direction and metric tables. No production edits, runtime products, tests, builds, profiles, network or new agents.

**Disposition: STOP this unconditional candidate; keep it nonshipping.** Root reports production source remains clean. This is an operational/quality regression, not a reason to relax limits or invent another gate.

## Concrete adverse outcomes

| Case | Baseline | Candidate | Assessment |
| --- | --- | --- | --- |
| Native/Agentic LR | Returned/passed | Visibility-resource refusal | Loses an existing delivered case. Inspected after DIRECTIONS spells this as visibility-expansion limit. |
| Trinity TB | Returned/passed, 29 crossings | Visibility-expansion refusal | Loses the intended quality target entirely. |
| Trinity BT | Passed, crossings 10, bends 31, wire 3291.953 | Passed, crossings 14, bends 34, wire 3152.4 | Shorter wire with more crossings/bends. |
| Trinity LR/RL | Passed, crossings 9, bends 35, wire 2693.097 | Passed, crossings 9, bends 37, wire 2593.597 | No crossing improvement; two additional bends. |

Native RL remains passed with retained metrics; Native TB/BT remain refusals. Returned Trinity areas are unchanged. A missing candidate product earns neither zero crossings nor passed ink. These adverse outcomes suffice to stop this trial without a broader acceptance replay.

## Causal correctness is narrower than operational success

The measured distinction is real. MeasuredGraph groups describe the painted header strip separately from blank content padding. Flowchart/State groupHeaderHeight, retainGraphText and renderer.renderGroup agree on the retained strip. Class namespace measurement and emission also use the same retained header height. Ancestor planning preserves the original strip when adding internal routing rows. Shared final marker/header checks already prefer headerHeight ?? padding.top.

For the frozen defaults, the trial removes 16 pixels of falsely forbidden blank space and restores local north-terminal eligibility. This does not establish a globally better complete route or lower cumulative resource use. New refusals and the BT tradeoff falsify those operational expectations.

The diff preserves full-frame obstacles for explicit frame endpoints and unrelated frames. Only related ancestor header obstacles change. Only <=64-leaf cases without an ancestor plan acquire a different numerical height; larger/ancestor-plan inputs already used the proposed expression. This affects ordinary Native Flowchart/State and physical Trinity/Class domains, rather than only the motivating Trinity example. Frame ownership, host bounds, body/label/peer obstacles and final paint/contact owners remain unchanged.

## Conservatism, fallbacks and live inputs

Missing header height retains the padding fallback. Explicit zero retains zero before unchanged inflation, conservatively leaving a narrow obstacle for a headerless concurrency region. Existing compound admission validates finite nonnegative height no larger than top padding. Public producers supply local measured rows. No cache, borrowed geometry or authority shortcut is added.

Small non-ancestor cases now read headerHeight where they previously read padding.top alone. Arbitrary live caller getters therefore need not preserve the old read count/order. Reviewed public producers supply ordinary owned data, so this is not a demonstrated public getter failure; do not infer generic getter equivalence.

Measured strip height does not replace centered-stroke, corner, label, custom-style or final-transform proof. Those existing final owners must remain authoritative. The trial retains them; its adverse delivery results prevent a shipping/final-ink claim before any broader coverage question arises.

Expansion/arc/pair caps, inflation, terminal inventory, ordering, fallback sequence and final proof functions are unchanged. A changed search domain can still allocate differently and commit different earlier routes. Preserve the useful causal finding and all adverse evidence, and stop this intervention without index-specific exceptions, increased caps, refunded failed work or treating strategy tuning as the same proven fix.
