import {readFileSync,writeFileSync} from 'node:fs';
import {scanSvgStartTags} from '/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts';
import {crossingPoint,countPolylineCrossings} from '/tmp/pr449-main-integration-20261029-762/src/shared/edge-crossings.ts';
const dir=import.meta.dir,root='/tmp/pr449-week-comparison-20261101/trinity-community-ports-20261109/products';
const rows=[];
for(const backend of ['trinity','elk'])for(const direction of ['TB','BT']){
 const stem=`${backend}-${direction}`, layout=JSON.parse(readFileSync(`${root}/${stem}.layout.json`,'utf8'));
 const tags=scanSvgStartTags(readFileSync(`${root}/${stem}.svg`,'utf8')).map(t=>({name:t.name,a:Object.fromEntries(t.attributes.map(a=>[a.name,a.value]))}));
 const edges=tags.filter(t=>t.a['data-role']==='edge'&&t.a.points).map(t=>({source:t.a['data-from'],target:t.a['data-to'],points:t.a.points.split(/\s+/).map(p=>{const[x,y]=p.split(',').map(Number);return{x:x!,y:y!}})}));
 const halos=tags.filter(t=>t.a.class==='edge-label-halo').map(t=>({x:+t.a.x!,y:+t.a.y!,w:+t.a.width!,h:+t.a.height!,rx:+(t.a.rx??0),fill:t.a.fill}));
 const inside=(p:any,b:any)=>p.x>=b.x&&p.x<=b.x+b.w&&p.y>=b.y&&p.y<=b.y+b.h;
 const inRounded=(p:any,b:any)=>{if(!inside(p,b))return false;const r=Math.min(b.rx,b.w/2,b.h/2);const x=Math.max(b.x+r,Math.min(p.x,b.x+b.w-r)),y=Math.max(b.y+r,Math.min(p.y,b.y+b.h-r));return (p.x-x)**2+(p.y-y)**2<=r*r};
 const crossings:any[]=[];
 for(let i=0;i<edges.length;i++)for(let j=i+1;j<edges.length;j++)for(let a=0;a<edges[i]!.points.length-1;a++)for(let b=0;b<edges[j]!.points.length-1;b++){
  const p=crossingPoint({a:edges[i]!.points[a]!,b:edges[i]!.points[a+1]!,edgeIndex:i,pointIndex:a},{a:edges[j]!.points[b]!,b:edges[j]!.points[b+1]!,edgeIndex:j,pointIndex:b},edges);
  if(p&&!crossings.some(q=>q.i===i&&q.j===j&&Math.abs(q.x-p.x)<1e-8&&Math.abs(q.y-p.y)<1e-8))crossings.push({i,j,x:p.x,y:p.y,segmentA:a,segmentB:b,haloMask:halos.map((h,k)=>inRounded(p,h)?k:-1).filter(k=>k>=0),nodeMask:layout.nodes.filter((n:any)=>inside(p,n)).map((n:any)=>n.id)});
 }
 const face=(id:string,p:any)=>{const n=layout.nodes.find((n:any)=>n.id===id);return [['N',p.y-n.y],['S',p.y-n.y-n.h],['W',p.x-n.x],['E',p.x-n.x-n.w]].filter(([s,d])=>Math.abs(d as number)<1e-6).map(([s])=>s).join('');};
 const minHaloY=Math.min(...halos.map(h=>h.y)),maxHaloY=Math.max(...halos.map(h=>h.y+h.h));
 for(const c of crossings)c.zone=c.y<minHaloY?'above-labels':c.y>maxHaloY?'below-labels':'label-band';
 const row={stem,summary:{helperCount:countPolylineCrossings(edges),enumerated:crossings.length,masked:crossings.filter(c=>c.haloMask.length||c.nodeMask.length).length,zones:Object.fromEntries(['above-labels','label-band','below-labels'].map(z=>[z,crossings.filter(c=>c.zone===z).length]))},nodes:layout.nodes.map(({id,x,y,w,h,parentId}:any)=>({id,x,y,w,h,parentId})),groups:layout.groups,halos,edges:edges.map((e,i)=>({...e,index:i,sourceFace:face(e.source!,e.points[0]),targetFace:face(e.target!,e.points.at(-1))})),crossings};rows.push(row);
 console.log(JSON.stringify({stem,summary:row.summary,faces:row.edges.map(e=>`${e.index}:${e.source}${e.sourceFace}->${e.target}${e.targetFace}`),nodes:row.nodes,groups:row.groups}));
}
writeFileSync(`${dir}/INTERSECTIONS.json`,JSON.stringify(rows,null,2)+'\n');
