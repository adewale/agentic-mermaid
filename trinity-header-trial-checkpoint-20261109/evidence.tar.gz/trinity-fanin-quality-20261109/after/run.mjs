import fs from 'node:fs';import path from 'node:path';import {pathToFileURL,fileURLToPath}from'node:url';import{registerHooks,stripTypeScriptTypes}from'node:module';
const root="/tmp/pr449-main-integration-20261029-762",job={"moduleOverrides": {"/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts": "/tmp/pr449-week-comparison-20261101/trinity-fanin-quality-20261109/candidate-router.ts"}};
const maps={};
registerHooks({
 resolve(specifier,context,next){
  if(specifier.startsWith('.')&&(context.parentURL?.startsWith(pathToFileURL(root+'/').href)||context.parentURL?.includes('/node_modules/roughjs/bin/'))){
   const p=new URL(specifier,context.parentURL);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.ts'))return next(p.href+'.ts',context);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.js'))return next(p.href+'.js',context);
  }
  if(specifier.startsWith('roughjs/bin/')&&!path.extname(specifier))return next(specifier+'.js',context);
  return next(specifier,context);
 },
 load(url,context,next){
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.json'))return{format:'json',shortCircuit:true,source:fs.readFileSync(fileURLToPath(url),'utf8')};
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.ts')){
   const original=fs.readFileSync(job.moduleOverrides?.[fileURLToPath(url)] ?? fileURLToPath(url),'utf8');
   const source=stripTypeScriptTypes(original,{mode:'transform',sourceMap:true,sourceUrl:url});
   const m=source.match(/sourceMappingURL=data:application\/json;base64,([^\s]+)/);
   if(m)maps[url]=JSON.parse(Buffer.from(m[1],'base64').toString());
   return{format:'module',shortCircuit:true,source};
  }
  return next(url,context);
 }
});

await import('./qualify.ts');await import('./metrics.ts');
