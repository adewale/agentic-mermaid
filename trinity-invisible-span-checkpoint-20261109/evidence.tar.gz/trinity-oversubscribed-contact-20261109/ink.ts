import {readFileSync,writeFileSync} from 'node:fs'
import {gunzipSync} from 'node:zlib'
import {createHash} from 'node:crypto'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import {prepareResvgMarkerOrientation} from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const repo='/tmp/pr449-main-integration-20261029-762',root='/tmp/pr449-week-comparison-20261101/trinity-oversubscribed-contact-20261109'
const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const p=repo+'/'+f.path;if(createHash('sha256').update(readFileSync(p)).digest('hex')!==f.sha256)throw Error('font mismatch');return p})
const rows=[];const zoom=3
for(const [arm,path] of [['baseline','baseline/0.svg.gz'],['trial','trial/0.svg.gz'],['elk','elk0.svg.gz']]){
 const svg=gunzipSync(readFileSync(root+'/'+path)).toString(),carriers=[...svg.matchAll(/<polyline\b[^>]*\/>/g)].map(m=>m[0]).filter(t=>t.includes('data-to="n7"')&&t.includes('marker-end='))
 if(carriers.length!==6)throw Error('expected six authored heads')
 const heads=carriers.map(t=>{const p=/points="([^"]+)"/.exec(t)![1]!.split(/\s+/).at(-1)!.split(',').map(Number);return {id:/data-id="([^"]+)"/.exec(t)![1],x:p[0]!,y:p[1]!}})
 const roi={x:Math.floor(Math.min(...heads.map(p=>p.x))-12),y:Math.floor(Math.min(...heads.map(p=>p.y))-12),width:Math.ceil(Math.max(...heads.map(p=>p.x))-Math.min(...heads.map(p=>p.x)))+24,height:Math.ceil(Math.max(...heads.map(p=>p.y))-Math.min(...heads.map(p=>p.y)))+24}
 const cropped=svg
 const images=new Map<string,Uint8Array>();let width=0
 function render(remove:number[]){const key=remove.slice().sort((a,b)=>a-b).join(',');if(images.has(key))return images.get(key)!;let s=cropped;for(const i of remove)s=s.replace(carriers[i]!,carriers[i]!.replace(/ marker-end="[^"]*"/,''));const prepared=prepareResvgMarkerOrientation(inlineFontVarForRaster(s));const im=new Resvg(prepared,{background:'#fff',fitTo:{mode:'zoom',value:zoom},font:{fontFiles:fonts,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();width=im.width;const pixels=im.pixels;images.set(key,pixels);if(!remove.length)writeFileSync(root+'/'+arm+'-heads.png',im.asPng());return pixels}
 const actual=render([]),pairs=[];const delta=(a:Uint8Array,b:Uint8Array,k:number)=>Math.abs(a[k]!-b[k]!)+Math.abs(a[k+1]!-b[k+1]!)+Math.abs(a[k+2]!-b[k+2]!)
 for(let i=0;i<6;i++)for(let j=0;j<6;j++)if(i!==j){const noSelected=render([i]),noPeer=render([j]),neither=render([i,j]);let exposed=0,visible=0,hidden=0,attenuated=0;for(let y=roi.y*zoom;y<(roi.y+roi.height)*zoom;y++)for(let x=roi.x*zoom;x<(roi.x+roi.width)*zoom;x++){const k=(y*width+x)*4;const e=delta(noPeer,neither,k),v=delta(actual,noSelected,k);if(e>=6){exposed++;if(v>=6)visible++;if(v<6)hidden++;if(v+6<e)attenuated++}}pairs.push({selected:heads[i]!.id,peer:heads[j]!.id,exposed,visible,hidden,attenuated})}
 rows.push({arm,sha256:createHash('sha256').update(svg).digest('hex'),roi,heads,pairs});console.log(arm,JSON.stringify({hidden:pairs.reduce((s,p)=>s+p.hidden,0),attenuated:pairs.reduce((s,p)=>s+p.attenuated,0),images:images.size}))
}
writeFileSync(root+'/INK.json',JSON.stringify({font:'manifest verified Inter, system fonts off',zoom,scope:'six selected authored n7 heads, each directed pair; finite region of actual fullSVG rasters; pair pixel counts must not be summed as unique pixels',rows},null,2)+'\n')
