import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const out=import.meta.dir,prior='/tmp/pr449-week-comparison-20261101/trinity-class-scopes-20261109',cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-native-elk-df133-20261108/FIDELITY-CASES.json','utf8')).selected,rows=JSON.parse(readFileSync(prior+'/COHORT-PRODUCTS.json','utf8')),results=[]
mkdirSync(out+'/frozen-products',{recursive:true})
for(const row of rows){const c=cases.find((c:any)=>c.id===row.id);for(const pre of c.prelude??[])try{renderMermaidSVGWithReceipt(pre.source)}catch{};let after
try{const p=renderMermaidSVGWithReceipt(c.source,{...c.renderOptions,graphLayout:{backend:row.backend,fallback:'none'},embedFontImport:false});const receipt=JSON.stringify(p.receipt);writeFileSync(out+'/frozen-products/'+row.stem+'.svg',p.svg);writeFileSync(out+'/frozen-products/'+row.stem+'.receipt.json',receipt);after={delivery:'returned',proof:p.receipt.layoutCertification?.status,svgExact:row.delivery==='returned'?p.svg===readFileSync(prior+'/products/'+row.stem+'.svg','utf8'):null}}
catch(e:any){after={delivery:e.code==='GRAPH_LAYOUT_UNSUPPORTED'?'unsupported':'error',error:String(e),code:e.code}}
results.push({id:row.id,family:row.family,backend:row.backend,before:{delivery:row.delivery,proof:row.proof,error:row.error},after});writeFileSync(out+'/FROZEN-REQUALIFICATION.json',JSON.stringify(results,null,2)+'\n')}
console.log(JSON.stringify({total:results.length,returned:results.filter(x=>x.after.delivery==='returned').length,svgChanged:results.filter(x=>x.after.svgExact===false),transitions:results.filter(x=>x.before.delivery!==x.after.delivery||x.before.proof!==x.after.proof)}))
