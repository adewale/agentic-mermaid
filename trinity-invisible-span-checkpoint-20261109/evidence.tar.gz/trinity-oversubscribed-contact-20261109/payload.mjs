import fs from 'node:fs';import {gunzipSync,gzipSync,brotliCompressSync,constants} from 'node:zlib';import {createHash} from 'node:crypto';
const root='/tmp/pr449-week-comparison-20261101/trinity-oversubscribed-contact-20261109',rows=[];
for(const [arm,dir] of [['before','baseline'],['after','trial']]){
 const svg=gunzipSync(fs.readFileSync(root+'/'+dir+'/0.svg.gz')),receipt=JSON.parse(gunzipSync(fs.readFileSync(root+'/'+dir+'/0.receipt.json.gz'))),product=Buffer.from(JSON.stringify({svg:svg.toString(),receipt}));
 for(const [kind,raw] of [['svg',svg],['svg+receipt',product]]){const gz=gzipSync(raw,{level:9}),br=brotliCompressSync(raw,{params:{[constants.BROTLI_PARAM_QUALITY]:11}});fs.writeFileSync(root+'/'+arm+'-'+kind+'.gzip9',gz);fs.writeFileSync(root+'/'+arm+'-'+kind+'.br11',br);rows.push({arm,kind,rawBytes:raw.length,gzip9:gz.length,brotli11:br.length,rawSHA256:createHash('sha256').update(raw).digest('hex')});}
}
fs.writeFileSync(root+'/PAYLOAD.json',JSON.stringify({runtime:process.version,scope:'actual offline output byte streams, no transfer/startup or runtime timing claim',rows},null,2)+'\n');console.log(JSON.stringify(rows));
