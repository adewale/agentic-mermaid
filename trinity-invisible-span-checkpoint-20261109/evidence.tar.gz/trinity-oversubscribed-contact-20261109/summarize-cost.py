import json,pathlib,gzip,statistics,collections,hashlib
r=pathlib.Path(__file__).parent
runs=json.load(open(r/'COST-RUNS.json'));assert len(runs)==8 and all(x['exit']==0 for x in runs)
rows=[];products=collections.defaultdict(list)
for run in runs:
 out=pathlib.Path(run['out']);result=json.load(gzip.open(out/'RESULT.json.gz','rt'))
 for row in result['rows']:
  rows.append({k:run[k] for k in ['cache','arm','index']}|{'phase':row['phase'],'status':row['status'],'wallMs':row['wallMs'],'cpuMs':row['cpuMs'],'proof':row.get('proof',{}).get('status'),'peakRssMiB':row['peakRssKiB']/1024,'heapUsedMiB':row['after']['heapUsed']/1024**2,'bytes':row.get('bytes')})
  stem='warmup' if row['phase']=='cold-render' else row['phase']
  svg=gzip.open(out/(stem+'.svg.gz'),'rb').read();receipt=gzip.open(out/(stem+'.receipt.json.gz'),'rb').read();products[(run['arm'],run['cache'])].append((svg,receipt))
summary=[]
for cache in ['0','1']:
 for phase in ['cold-render','repeat1','repeat2']:
  for arm in ['before','after']:
   cells=[x for x in rows if (x['cache'],x['phase'],x['arm'])==(cache,phase,arm)]
   summary.append({'cache':cache,'phase':phase,'arm':arm,'n':len(cells),'wallMedianMs':statistics.median(x['wallMs'] for x in cells),'wallRangeMs':[min(x['wallMs'] for x in cells),max(x['wallMs'] for x in cells)],'cpuMedianMs':statistics.median(x['cpuMs'] for x in cells),'RSSRangeMiB':[min(x['peakRssMiB'] for x in cells),max(x['peakRssMiB'] for x in cells)],'heapRangeMiB':[min(x['heapUsedMiB'] for x in cells),max(x['heapUsedMiB'] for x in cells)]})
q={'attempts':len(rows),'allReturned':all(x['status']=='returned' for x in rows),'beforeProof':dict(collections.Counter(x['proof'] for x in rows if x['arm']=='before')),'afterProof':dict(collections.Counter(x['proof'] for x in rows if x['arm']=='after')),'completeProductExactWithinArms':all(all(p==v[0] for p in v) for v in products.values()),'rows':rows,'summary':summary,'scope':'Eight serial freshNode24 processes, ABBA per startup cache setting, firsttarget/repeat1/repeat2 separate, wholeSVG and receipt serialized; no authorededit existed so none invented. Sampling/observers off, imports/explicitGC/compression/writes outside. Two processreplicas percell descriptive, no stable speed ratio or kernel speedup. Cache0 leaves other derivedcaches live. BeforeU/afterP kept; lifetimeRSS includes harness and imports/artifacts, heapnotpeakretention.'}
(r/'COST-SUMMARY.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items() if k not in ['rows','scope']}))
