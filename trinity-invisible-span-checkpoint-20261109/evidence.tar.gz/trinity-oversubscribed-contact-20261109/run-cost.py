import json,pathlib,subprocess,os,time
r=pathlib.Path(__file__).parent
assert len(json.load(open(r/'COHORT-RUNS.json')))==16,'finish qualification before cost acquisition'
rows=[]
for cache in ['0','1']:
 for i,arm in enumerate(['before','after','after','before']):
  out=r/('cost-cache'+cache+'-'+str(i)+'-'+arm)
  with open(str(out)+'.log','w') as log:
   p=subprocess.run(['node','--expose-gc',str(r/'measure.mjs'),str(out),str(r/('cost-'+arm+'-job.json'))],env={**os.environ,'AGENTIC_MERMAID_ELK_CACHE':cache},stdout=log,stderr=subprocess.STDOUT)
  rows.append({'cache':cache,'arm':arm,'index':i,'out':str(out),'exit':p.returncode});(r/'COST-RUNS.json').write_text(json.dumps(rows,indent=2)+'\n');print(cache,i,arm,p.returncode,flush=True)
  if p.returncode:raise SystemExit(p.returncode)
