import json,subprocess,pathlib,time
r=pathlib.Path(__file__).parent
rows=[]
for j in json.load(open(r/'COHORT-JOBS.json')):
 start=time.time()
 with open(r/('cohort-'+str(j['cohort'])+'-'+j['arm']+'.log'),'w') as log:
  p=subprocess.run(['node',str(r/'snapshot-probe.mjs'),j['out'],j['job']],stdout=log,stderr=subprocess.STDOUT)
 rows.append({**j,'exit':p.returncode,'acquisitionSeconds':time.time()-start});(r/'COHORT-RUNS.json').write_text(json.dumps(rows,indent=2)+'\n');print(j['cohort'],j['arm'],p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
