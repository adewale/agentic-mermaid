import {readFileSync,writeFileSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
import {createHash} from 'node:crypto'
import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const root='/tmp/pr449-week-comparison-20261101/trinity-oversubscribed-contact-20261109'
const job=JSON.parse(readFileSync(root+'/JOB.json','utf8')), rows=[]
for(const backend of ['agentic'] as const){let prior:string|undefined;for(let call=0;call<2;call++){try{const p=renderMermaidSVGWithReceipt(job.source.replace('flowchart LR','flowchart '+process.argv[2]),{...job.options,graphLayout:{...job.options.graphLayout,backend}});const product=JSON.stringify(p);writeFileSync(root+'/same-options-'+process.argv[2]+'-'+backend+call+'.svg.gz',gzipSync(p.svg));writeFileSync(root+'/same-options-'+process.argv[2]+'-'+backend+call+'.receipt.json.gz',gzipSync(JSON.stringify(p.receipt)));rows.push({backend,call,status:'returned',proof:p.receipt.layoutCertification?.status,issues:p.receipt.layoutCertification?.issues,sha256:createHash('sha256').update(p.svg).digest('hex'),repeatExact:prior===undefined?null:prior===product});prior=product}catch(e){rows.push({backend,call,status:'error',error:String(e)})}}}
writeFileSync(root+'/same-options-'+process.argv[2]+'-RESULT.json',JSON.stringify({head:'af92dd1473cb7e4e5b7e5cf75856d7506a34a807',runtime:Bun.version,rows},null,2)+'\n');console.log(JSON.stringify(rows))
