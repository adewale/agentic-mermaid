from pathlib import Path
import tarfile,hashlib,json,subprocess,os,shutil,sys
root=Path('/tmp/pr449-week-comparison-20261101');src=root/sys.argv[1];out=root/sys.argv[2];out.mkdir(exist_ok=True);runtime=sys.argv[3]
files=[]
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=6) as tar:
 for p in sorted(src.rglob('*')):
  if p.is_file() and p.name not in {'agentic-after.json.gz'}:
   name=str(Path(src.name)/p.relative_to(src));tar.add(p,arcname=name,recursive=False);files.append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
with tarfile.open(out/'evidence.tar.gz','r:gz') as tar:
 for row in files:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
archive=out/'evidence.tar.gz';meta={'runtime':runtime,'files':len(files),'archiveBytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archiveFilesVerified':True,'omitted':'Only redundant unchanged Native replay, if present; original remains local and exact earlier products are remote.'}
(out/'ARCHIVE.json').write_text(json.dumps(meta,indent=2)+'\n');(out/'FILES.json').write_text(json.dumps(files,indent=2)+'\n');shutil.copyfile('/tmp/pr449-correctness-24h-20261030/campaign-state.json',out/'campaign-state.json');(out/'README.md').write_text((src/'README.md').read_text()+'\nRaw scripts, logs, final products, built assets and failed probes are retained in evidence.tar.gz. FILES.json records verified archive members and SHA256; ARCHIVE.json binds the runtime and archive. No local evidence was deleted.\n')

for n in ['baseline-heads.png', 'trial-heads.png', 'elk-heads.png']:shutil.copyfile(src/n,out/n)
base=subprocess.check_output(['git','rev-parse','review/pr449-evidence-20261105'],text=True).strip();env={**os.environ,'GIT_INDEX_FILE':str(out/'git-index')};subprocess.run(['git','read-tree',base],env=env,check=True)
for n in ['README.md', 'ARCHIVE.json', 'FILES.json', 'campaign-state.json', 'evidence.tar.gz', 'baseline-heads.png', 'trial-heads.png', 'elk-heads.png']:
 blob=subprocess.check_output(['git','hash-object','-w',str(out/n)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo',f'100644,{blob},{out.name}/{n}'],env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree,'-p',base],input='Preserve '+src.name+' verified delivery evidence\n',text=True).strip();subprocess.run(['git','update-ref','refs/heads/review/pr449-evidence-20261105',commit,base],check=True);(out/'EVIDENCE-COMMIT.txt').write_text(commit+'\n');print(commit,json.dumps(meta))
