/**
 * Browser E2E tests for the live editor, using Playwright with bun:test.
 *
 * These open the editor (built by scripts/site/editor.ts — the same generator
 * the Cloudflare site ships) in a real browser and verify:
 * - The editor renders diagrams (incl. fork-added families) through the bundle
 * - Theme registry, examples sidebar, mobile pane tabs, and topbar behavior
 * - Visual-regression baselines for styled renders
 *
 * Requires: Playwright browsers installed (`bunx playwright install chromium`).
 * Run:  bun run test:browser
 */

import { describe, it, expect, beforeAll, afterAll } from 'bun:test'
import { join } from 'path'
import { brotliDecompressSync, deflateRawSync, gzipSync } from 'node:zlib'
import { deserialize } from 'node:v8'
import { chromium, type Browser, type BrowserContext, type CDPSession, type Page } from 'playwright'
import { BUILTIN_FAMILY_METADATA } from '../src/agent/families.ts'
import { renderMermaidSVG, renderMermaidASCIIWithReceipt, knownStyleDescriptors, inferBackend, type RenderOptions } from '../src/index.ts'
import type { PreviewArtifact } from '../src/browser-editor-protocol.ts'
import { useTestChildren } from '../src/__tests__/helpers/test-child.ts'
import { serveWithAvailablePort } from './test-port.ts'
import { PIE_ENTITY_FIXTURES } from '../src/__tests__/helpers/pie-entity-fixtures.ts'
import { resolveSvgScene } from '../src/scene/resolve-svg.ts'

const ROOT = join(import.meta.dir, '..')
const runSourceChild = useTestChildren(30_000)

/** Match the preview operation in a fresh production realm. The test preload
 * intentionally forces Scene assertions in this parent; changing its env now
 * cannot undo assertion modules that have already been imported. */
async function sourcePreviews(examples: readonly { source: string; options: RenderOptions }[]): Promise<Pick<PreviewArtifact, 'svg' | 'receipt' | 'verification'>[]> {
  const child = await runSourceChild(process.execPath, ['--eval', `
    const { serialize } = await import('node:v8')
    await import('./src/index.ts')
    const { renderAndVerifyMermaid } = await import('./src/agent/verify.ts')
    const examples = JSON.parse(await Bun.stdin.text())
    const results = examples.map(({ source, options }) => {
      const result = renderAndVerifyMermaid(source, { ...options, security: 'strict', embedFontImport: false })
      return { svg: result.svg, receipt: result.receipt, verification: {
        ok: result.verification.ok, warnings: result.verification.warnings, checks: result.verification.checks,
      } }
    })
    process.stdout.write(serialize(results).toString('base64'))
  `], { cwd: ROOT, env: { ...process.env, AGENTIC_MERMAID_SCENE_ASSERTIONS: '0' }, input: JSON.stringify(examples) })
  expect(child.status, child.stderr).toBe(0)
  expect(child.signal).toBeNull()
  // Preserve optional undefined fields as well as every receipt value. JSON
  // transport would silently discard those fields before the equality check.
  return deserialize(Buffer.from(child.stdout, 'base64'))
}

const PREFERRED_PORT = 4567
let BASE = ''
const SCREENSHOT_DIR = join(ROOT, 'e2e', 'screenshots')
// Browser font rasterization differs between local macOS and GitHub's Linux runners.
// Structural SVG assertions catch the exact regression; this tolerance keeps
// screenshot checks focused on gross visual drift rather than text antialiasing.
const ROUNDED_FILL_SCREENSHOT_MAX_DIFF = 0.05
const ARCHITECTURE_ROUNDED_FILL_SOURCE = `architecture-beta
  group edge(cloud)[Edge Layer]
  group core(server)[Core Services]
  service web(server)[Web App] in edge
  service api(server)[API] in core
  service db(database)[Postgres] in core
  web:R --> L:api
  api:R --> L:db`
const ROUNDED_FILL_CONFIG = { style: 'status-dashboard' } as const

// ---------------------------------------------------------------------------
// Browser + page references
// ---------------------------------------------------------------------------

let browser: Browser
let context: BrowserContext
let page: Page
let cdpSession: CDPSession | null = null

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Wait for the live editor preview to show a successful SVG render. */
async function waitForEditorRender(timeoutMs = 30_000): Promise<void> {
  await page.waitForFunction(
    () => {
      const status = document.getElementById('status-text')?.textContent
      return status === 'OK' && document.querySelector('#preview-inner svg') !== null
    },
    undefined,
    { timeout: timeoutMs },
  )
}

/**
 * Navigate to the local app without waiting for the page's load event.
 *
 * The generated editor page runs large module scripts and renders many SVGs
 * before `load` can fire. On GitHub's slower Chromium runners that makes
 * Playwright's default `page.goto(..., waitUntil: "load")` flaky and leaves the
 * shared page in a pending-navigation state after one timeout. These tests wait
 * for app-specific readiness (`waitForEditorRender` or a selector) after
 * navigation, so committing the response is the useful boundary.
 *
 * The page also embeds many SVGs whose Google Font imports can keep Chromium's
 * previous document in a loading state even after the app reports that rendering
 * is done. Use a fresh Page for each explicit navigation while keeping the same
 * BrowserContext, so editor palette preferences persist but a stuck prior document cannot
 * block the next response from committing on slower GitHub runners.
 */
async function gotoApp(url: string, options: { clearDraft?: boolean } = {}): Promise<void> {
  const previous = page
  const viewport = previous?.viewportSize() ?? null
  try { await cdpSession?.send('Page.stopLoading') } catch {}
  page = await context.newPage()
  if (viewport) await page.setViewportSize(viewport)
  if (options.clearDraft) {
    await page.addInitScript(() => {
      sessionStorage.removeItem('bm-editor-draft')
      localStorage.removeItem('bm-editor-draft')
    })
  }
  cdpSession = await context.newCDPSession(page)
  if (previous && !previous.isClosed()) {
    void previous.close({ runBeforeUnload: false }).catch(() => {})
  }

  const response = await page.goto(url, { waitUntil: 'commit', timeout: 60_000 })
  if (!response || !response.ok()) {
    throw new Error(`Failed to navigate to ${url}: ${response?.status() ?? 'no response'}`)
  }
}

/**
 * Run `body` in its own BrowserContext with Playwright's fake clock installed,
 * then restore the shared context. The clock belongs to the context, so
 * installing it on the shared one would leak fake time into every later test.
 * It flows naturally until `pausePageClock`.
 */
async function withFakeClock(body: () => Promise<void>): Promise<void> {
  const shared = { context, page, cdpSession }
  context = await browser.newContext({ viewport: page.viewportSize() })
  await context.clock.install()
  try {
    await body()
  } finally {
    await context.close().catch(() => {})
    ;({ context, page, cdpSession } = shared)
  }
}

/** Freeze the fake clock so timing-sensitive UI (toast dismissal, momentum
 *  coast) advances only by explicit `page.clock.runFor`, independent of runner
 *  load. The clock keeps running while the target is computed, so it pauses
 *  one second ahead (never in the past); call it only while nothing
 *  timing-sensitive is in flight, and `page.clock.resume()` before loading a
 *  page that must render. */
async function pausePageClock(): Promise<void> {
  await page.clock.pauseAt(await page.evaluate(() => Date.now() + 1_000))
}

function editorHash(source: string, config = ROUNDED_FILL_CONFIG, palette = 'salmon'): string {
  return 'deflate:' + deflateRawSync(Buffer.from(JSON.stringify({ source, palette, config }), 'utf8')).toString('base64url')
}

async function gotoEditorWithWarmFonts(query: string, hash: string): Promise<void> {
  await gotoApp(`${BASE}/editor?empty=1`)
  await page.waitForSelector('#code-editor', { timeout: 30_000 })
  await page.evaluate(() => document.fonts?.ready)
  await gotoApp(`${BASE}/editor${query}#${hash}`)
  await waitForEditorRender(60_000)
  await page.evaluate(() => document.fonts?.ready)
}

async function comparePngScreenshots(
  currentPath: string,
  baselinePath: string,
  channelThreshold = 5,
): Promise<{ width: number; height: number; diffPixels: number; totalPixels: number; diffRatio: number; maxChannelDelta: number; dimensionMismatch: boolean }> {
  const [currentBytes, baselineBytes] = await Promise.all([
    Bun.file(currentPath).arrayBuffer(),
    Bun.file(baselinePath).arrayBuffer(),
  ])
  const currentDataUrl = `data:image/png;base64,${Buffer.from(currentBytes).toString('base64')}`
  const baselineDataUrl = `data:image/png;base64,${Buffer.from(baselineBytes).toString('base64')}`

  return page.evaluate(
    async ({ currentDataUrl, baselineDataUrl, channelThreshold }) => {
      function loadImage(src: string): Promise<HTMLImageElement> {
        return new Promise((resolve, reject) => {
          const img = new Image()
          img.onload = () => resolve(img)
          img.onerror = () => reject(new Error('Failed to load screenshot image'))
          img.src = src
        })
      }

      const [current, baseline] = await Promise.all([
        loadImage(currentDataUrl),
        loadImage(baselineDataUrl),
      ])
      if (current.width !== baseline.width || current.height !== baseline.height) {
        return {
          width: current.width,
          height: current.height,
          diffPixels: Number.POSITIVE_INFINITY,
          totalPixels: 0,
          diffRatio: Number.POSITIVE_INFINITY,
          maxChannelDelta: Number.POSITIVE_INFINITY,
          dimensionMismatch: true,
        }
      }

      const canvas = document.createElement('canvas')
      canvas.width = current.width
      canvas.height = current.height
      const ctx = canvas.getContext('2d')!
      ctx.drawImage(current, 0, 0)
      const currentData = ctx.getImageData(0, 0, canvas.width, canvas.height).data
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      ctx.drawImage(baseline, 0, 0)
      const baselineData = ctx.getImageData(0, 0, canvas.width, canvas.height).data

      let diffPixels = 0
      let maxChannelDelta = 0
      for (let i = 0; i < currentData.length; i += 4) {
        const dr = Math.abs(currentData[i]! - baselineData[i]!)
        const dg = Math.abs(currentData[i + 1]! - baselineData[i + 1]!)
        const db = Math.abs(currentData[i + 2]! - baselineData[i + 2]!)
        const da = Math.abs(currentData[i + 3]! - baselineData[i + 3]!)
        const maxDelta = Math.max(dr, dg, db, da)
        maxChannelDelta = Math.max(maxChannelDelta, maxDelta)
        if (maxDelta > channelThreshold) diffPixels++
      }

      const totalPixels = current.width * current.height
      return {
        width: current.width,
        height: current.height,
        diffPixels,
        totalPixels,
        diffRatio: diffPixels / totalPixels,
        maxChannelDelta,
        dimensionMismatch: false,
      }
    },
    { currentDataUrl, baselineDataUrl, channelThreshold },
  )
}

// ---------------------------------------------------------------------------
// Server lifecycle
// ---------------------------------------------------------------------------

let server: ReturnType<typeof Bun.serve>

beforeAll(async () => {
  // The live editor is built by scripts/site/editor.ts — the same generator the
  // Cloudflare site uses — so these tests exercise the shipped editor. Build the
  // standalone editor.html if it isn't already present.
  const editorPath = join(ROOT, 'editor.html')
  if (!(await Bun.file(editorPath).exists())) {
    const proc = Bun.spawn(['bun', 'run', join(ROOT, 'scripts/site/editor.ts')], {
      cwd: ROOT, stdout: 'inherit', stderr: 'inherit',
    })
    await proc.exited
  }

  // Ensure screenshot dir exists
  await Bun.spawn(['mkdir', '-p', SCREENSHOT_DIR]).exited

  // Serve the editor at /editor plus root public/ assets.
  const served = serveWithAvailablePort({
    preferredPort: PREFERRED_PORT,
    async fetch(req) {
      const url = new URL(req.url)
      const route = url.pathname === '/editor' ? 'editor.html' : url.pathname
      const filePath = join(ROOT, route)
      const file = Bun.file(filePath)
      if (await file.exists()) return new Response(file)
      const pubFile = Bun.file(join(ROOT, 'public', url.pathname))
      if (await pubFile.exists()) return new Response(pubFile)
      return new Response('Not found', { status: 404 })
    },
  })
  server = served.server
  BASE = served.base

  // Launch Playwright browser and warm up the editor.
  browser = await chromium.launch()
  context = await browser.newContext()
  page = await context.newPage()
  cdpSession = await context.newCDPSession(page)

  await gotoApp(`${BASE}/editor`)
  await waitForEditorRender(60_000)
}, 120_000)

afterAll(async () => {
  // Cleanup: reset to default theme before closing
  try {
    await page.evaluate(() => {
      localStorage.removeItem('mermaid-theme')
      localStorage.removeItem('bm-editor-palette')
      localStorage.removeItem('bm-editor-theme')
    })
  } catch {}

  try { await browser?.close() } catch {}
  server?.stop()
})

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

it('shipped sketch looks paint readable label ink against an opaque halo', async () => {
  const labels = await browser.newPage()
  await labels.route('**/*', route => route.abort())
  try {
    const looks = knownStyleDescriptors().filter(descriptor => descriptor.kind === 'look' && inferBackend(descriptor.spec) !== 'default')
    expect(looks.length).toBeGreaterThan(0)
    for (const style of looks) {
      await labels.setContent(renderMermaidSVG('flowchart TD\n A["Readable label"]', { style: style.inputName, embedFontImport: false, seed: 7 }))
      const paint = await labels.evaluate(() => {
        const text = [...document.querySelectorAll('text')].find(node => node.textContent?.toLowerCase() === 'readable label')
        if (!text) throw new Error('Shipped look did not paint the node label')
        const computed = getComputedStyle(text)
        // Canvas normalizes supported CSS colors without pinning hex spelling.
        const canvas = document.createElement('canvas')
        canvas.width = canvas.height = 1
        const ctx = canvas.getContext('2d')!
        const rgba = (color: string) => {
          if (!CSS.supports('color', color)) return []
          ctx.clearRect(0, 0, 1, 1)
          ctx.fillStyle = color
          ctx.fillRect(0, 0, 1, 1)
          return [...ctx.getImageData(0, 0, 1, 1).data]
        }
        return {
          fill: rgba(computed.fill), halo: rgba(computed.stroke),
          width: parseFloat(computed.strokeWidth), order: computed.paintOrder.split(' ')[0],
          opacity: [computed.opacity, computed.fillOpacity, computed.strokeOpacity].map(Number),
          visibility: computed.visibility, display: computed.display,
        }
      })
      expect(paint, style.inputName).toMatchObject({ order: 'stroke', opacity: [1, 1, 1], visibility: 'visible' })
      expect(paint.display, style.inputName).not.toBe('none')
      expect(paint.width, style.inputName).toBeGreaterThan(0)
      expect(paint.fill[3], style.inputName).toBe(255)
      expect(paint.halo[3], style.inputName).toBe(255)
      // WCAG 2 relative luminance, independently of the production guardrail.
      const luminance = (rgba: number[]) => rgba.slice(0, 3).reduce((sum, channel, i) => {
        const c = channel / 255
        return sum + [0.2126, 0.7152, 0.0722][i]! * (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4)
      }, 0)
      const [light, dark] = [luminance(paint.fill), luminance(paint.halo)].sort((a, b) => b - a)
      expect((light! + 0.05) / (dark! + 0.05), style.inputName).toBeGreaterThanOrEqual(4.5)
    }
  } finally {
    await labels.close()
  }
})

it('resolved circle and ellipse paths preserve the native stroke traversal for dashes', async () => {
  const svg = '<svg width="200" height="120"><circle cx="60" cy="60" r="40" stroke="black" stroke-dasharray="7 3" /><ellipse cx="150" cy="60" rx="30" ry="20" stroke="black" stroke-dasharray="7 3" /></svg>'
  const scene = resolveSvgScene(svg, { family: 'flowchart', width: 200, height: 120,
    transparent: false, colors: { bg: '#ffffff', fg: '#000000' }, parts: [] }, [])
  const paths = scene.frame.map(primitive => {
    if (primitive.kind !== 'path') throw new Error('Expected path geometry')
    expect(primitive.paint.dashArray).toEqual([7, 3])
    return primitive.d
  })
  const probe = await browser.newPage()
  try {
    await probe.setContent(svg)
    const pairs = await probe.evaluate(({ paths }) => {
      const root = document.querySelector('svg')!
      return [...root.querySelectorAll('circle,ellipse')].map((element, index) => {
        const converted = document.createElementNS(root.namespaceURI, 'path') as SVGPathElement
        converted.setAttribute('d', paths[index]!)
        root.appendChild(converted)
        return [0, 1].map(distance => {
          const expected = (element as SVGGeometryElement).getPointAtLength(distance)
          const actual = converted.getPointAtLength(distance)
          return Math.hypot(actual.x - expected.x, actual.y - expected.y)
        })
      })
    }, { paths })
    for (const pair of pairs) {
      expect(pair[0]).toBeLessThan(0.0001)
      expect(pair[1]).toBeLessThan(0.05)
    }
  } finally { await probe.close() }
})

it('standalone editor stays within its single-renderer payload budget', async () => {
  const html = new Uint8Array(await Bun.file(join(ROOT, 'editor.html')).arrayBuffer())
<<<<<<< HEAD
  // Keep this campaign's original ceilings while integrating Main's delivery
  // changes. One renderer serves both realms; relative growth is checked too.
  expect(html.byteLength).toBeLessThanOrEqual(4_429_400)
  expect(gzipSync(html, { level: 9 }).byteLength).toBeLessThanOrEqual(1_334_500)
=======
  // Packed Inter metrics, bounded layout search and parser diagnostics must
  // fit the existing raw/gzip limits. Keep the relative-growth gate too.
  expect(html.byteLength).toBeLessThanOrEqual(4_774_000)
  expect(gzipSync(html, { level: 9 }).byteLength).toBeLessThanOrEqual(1_440_000)
>>>>>>> origin/main
  const runtime = new TextDecoder().decode(html).match(/<script type="module" id="editor-runtime">([\s\S]*?)<\/script>/)?.[1]
  expect(runtime).toBeDefined()
  // These literals belong to the page catalog, not its private renderer worker.
  const packed = new TextDecoder().decode(html).match(/<script type="application\/octet-stream" id="editor-worker-payload">([\s\S]*?)<\/script>/)?.[1]
  expect(packed).toBeDefined()
  const worker = brotliDecompressSync(Buffer.from(packed!.trim(), 'base64')).toString('utf8')
  expect(worker.length).toBeGreaterThan(0)
  for (const module of [runtime!, worker]) expect(module).not.toMatch(/(?:\beditor(?:DiagramType|Label|Description|ExampleId|Glyph|Example)|["']editor(?:DiagramType|Label|Description|ExampleId|Glyph|Example)["'])\s*:\s*["'`]/)
})

it('standalone editor renders and verifies with one persistent Blob worker', async () => {
  const standalone = await browser.newPage()
  try {
    // Observe the actual immutable Blob handed to the browser, independently
    // of the payload CRC helper and the render receipt.
    await standalone.addInitScript(() => {
      const original = URL.createObjectURL.bind(URL)
      URL.createObjectURL = value => {
        if (value instanceof Blob && value.type === 'text/javascript') {
          (window as unknown as { __workerBytes: Promise<ArrayBuffer> }).__workerBytes = value.arrayBuffer()
        }
        return original(value)
      }
    })
    await standalone.goto(`${BASE}/editor?empty=1`, { waitUntil: 'networkidle' })
    // The page still offers the complete public catalog while its worker omits
    // the duplicated editor prose. Rendering and receipts below cover every hook.
    expect(BUILTIN_FAMILY_METADATA.length).toBeGreaterThan(0)
    const catalog = await standalone.locator('#examples-sidebar .example-dropdown-item').evaluateAll(items => items.map(item => ({
      id: (item as HTMLElement).dataset.example,
      diagramType: (item as HTMLElement).dataset.diagram,
      description: item.querySelector('.example-item-description')?.textContent,
      title: item.getAttribute('title'),
    })))
    for (const family of BUILTIN_FAMILY_METADATA) expect(catalog.find(item => item.id === family.editorExampleId)).toEqual({
      id: family.editorExampleId, diagramType: family.editorDiagramType,
      description: family.editorDescription, title: family.editorDescription,
    })
    const started = standalone.waitForEvent('worker')
    await standalone.locator('#code-editor').fill('flowchart LR\nStandalone --> Verified')
    const worker = await started
    await standalone.waitForFunction(() => document.getElementById('status-text')?.textContent === 'OK')
    expect(await standalone.locator('#preview-inner svg').textContent()).toContain('Standalone')
    expect(worker.url()).toStartWith('blob:')
    const emittedHtml = await Bun.file(join(ROOT, 'editor.html')).text()
    const encodedWorker = emittedHtml.match(/<script type="application\/octet-stream" id="editor-worker-payload">([\s\S]*?)<\/script>/)?.[1]
    expect(encodedWorker).toBeDefined()
    const expectedWorker = brotliDecompressSync(Buffer.from(encodedWorker!.trim(), 'base64'))
    const writtenWorker = await standalone.evaluate(async encoded => {
      const actual = new Uint8Array(await (window as unknown as { __workerBytes: Promise<ArrayBuffer> }).__workerBytes)
      const expected = atob(encoded)
      let firstDifference = actual.length === expected.length ? -1 : Math.min(actual.length, expected.length)
      for (let index = 0; index < Math.min(actual.length, expected.length); index++) {
        if (actual[index] !== expected.charCodeAt(index)) { firstDifference = index; break }
      }
      return { bytes: actual.length, firstDifference }
    }, expectedWorker.toString('base64'))
    expect(writtenWorker).toEqual({ bytes: expectedWorker.length, firstDifference: -1 })
    const preview = await standalone.evaluate(async () => {
      const api = (globalThis as any).__mermaid
      const source = 'flowchart LR\nStandalone --> Verified'
      const artifact = await api.renderMermaidSVGWithReceipt(source)
      const selections = []
      for (const backend of ['elk', 'agentic']) {
        const result = await api.renderMermaidSVGWithReceipt(source, { graphLayout: { backend } })
        selections.push({ selected: result.receipt.layoutDecisions?.[0]?.selected, verified: result.verification.ok })
      }
      const compound = 'flowchart TB\nsubgraph One\n A --> B\nend\nsubgraph Two\n C --> D\nend\nOne --> C'
      const promoted = await api.renderMermaidSVGWithReceipt(compound, { graphLayout: { backend: 'agentic' } })
      // Use the unchanged private-rank limit as the fallback witness.
      const fallbackSource = ['flowchart LR', 'subgraph One', ' A[Leaf]', ' B[Tail]', ' A ' + '-'.repeat(2049) + '> B', 'end'].join('\n')
      const fallback = await api.renderMermaidSVGWithReceipt(fallbackSource, {
        graphLayout: { backend: 'agentic', fallback: 'elk' },
      })
      return { checks: artifact.verification.checks, selections, promoted: promoted.receipt.layoutDecisions?.[0], fallback: fallback.receipt.layoutDecisions?.[0] }
    })
    expect(preview.checks).toEqual({ renderability: 'passed', sourceLoss: 'not-detected', taskCorrectness: 'not-checked' })
    expect(preview.selections).toEqual([{ selected: 'elk', verified: true }, { selected: 'agentic', verified: true }])
    expect(preview.promoted).toMatchObject({ requested: 'agentic', selected: 'agentic' })
    expect(preview.fallback).toMatchObject({ requested: 'agentic', selected: 'elk', fallback: 'elk' })
    // The self-contained module has its own compression path. Exercise every
    // registered family through that emitted worker against the source renderer.
    const styles = [undefined, 'hand-drawn', 'watercolor'] as const
    const examples = BUILTIN_FAMILY_METADATA.flatMap(family => styles.map(style => ({
      id: family.id, source: family.example, options: { security: 'strict' as const, embedFontImport: false, ...(style ? { style } : {}) },
    })))
    const parity = await standalone.evaluate(async examples => {
      const results = []
      for (const example of examples) {
        const artifact = await (globalThis as any).__mermaid.renderMermaidSVGWithReceipt(example.source, example.options)
        results.push({ id: example.id, style: example.options.style, svg: artifact.svg, receipt: artifact.receipt, verification: artifact.verification })
      }
      return results
    }, examples)
    // One family's styles fit the existing child's bounded output buffer.
    // Every family remains enrolled; only process boundaries differ.
    const expected: Awaited<ReturnType<typeof sourcePreviews>> = []
    for (let offset = 0; offset < examples.length; offset += styles.length) expected.push(...await sourcePreviews(examples.slice(offset, offset + styles.length)))
    expect(parity.map(result => [result.id, result.style])).toEqual(examples.map(example => [example.id, example.options.style]))
    expect(parity).toHaveLength(expected.length)
    for (let index = 0; index < expected.length; index++) {
      const label = `${examples[index]!.id}, ${examples[index]!.options.style ?? 'default'}`
      expect(parity[index]!.svg, label).toBe(expected[index]!.svg)
      expect(parity[index]!.receipt, label).toEqual(expected[index]!.receipt)
      expect(parity[index]!.verification, label).toEqual(expected[index]!.verification)
    }
    await standalone.locator('#code-editor').fill('flowchart LR\nSecond --> Verified')
    await standalone.waitForFunction(() => document.getElementById('preview-inner')?.textContent?.includes('Second') && document.getElementById('status-text')?.textContent === 'OK')
    expect(standalone.workers()).toEqual([worker])
    expect(await standalone.locator('#render-time').textContent()).toContain('Rendered and verified')
    // The first Blob URL has already been revoked. Recovery must create a
    // fresh URL from the retained module, not reuse that dead URL.
    const stopped = new Promise<void>(done => worker.once('close', () => done()))
    await worker.evaluate(() => { setTimeout(() => { throw new Error('intentional worker crash') }, 0) })
    await stopped
    const restarted = standalone.waitForEvent('worker')
    await standalone.locator('#code-editor').fill('flowchart LR\nRecovered --> Verified')
    const replacement = await restarted
    await standalone.waitForFunction(() => document.getElementById('preview-inner')?.textContent?.includes('Recovered') && document.getElementById('status-text')?.textContent === 'OK')
    expect(replacement.url()).toStartWith('blob:')
    expect(replacement.url()).not.toBe(worker.url())
    expect(standalone.workers()).toEqual([replacement])

    await replacement.evaluate(() => {
      const host = globalThis as any, original = host.onmessage
      host.__exportOperations = []
      host.onmessage = (event: MessageEvent) => {
        if (event.data.operation) host.__exportOperations.push(event.data.operation)
        return original(event)
      }
    })
    const text = await standalone.evaluate(async () => {
      const api = (window as any).__mermaid
      const source = 'flowchart LR\nRecovered --> Verified'
      const [ascii, unicode] = await Promise.all([
        api.renderMermaidASCIIWithReceipt(source, { colorMode: 'none', graphLayout: { backend: 'agentic' } }),
        api.renderMermaidUnicodeWithReceipt(source, { colorMode: 'none', graphLayout: { backend: 'agentic' } }),
      ])
      return {
        ascii: ascii.text,
        unicode: unicode.text,
        asciiDecisions: ascii.receipt.layoutDecisions,
        unicodeDecisions: unicode.receipt.layoutDecisions,
      }
    })
    expect(text.ascii).toContain('Recovered')
    expect(text.unicode).toContain('Verified')
    for (const decisions of [text.asciiDecisions, text.unicodeDecisions]) expect(decisions).toEqual([
      expect.objectContaining({ selected: 'agentic', role: 'companion' }),
    ])
    // Exercise the real Canvas/font/export path, which remains on the main thread.
    await standalone.locator('#export-chevron-btn').click()
    const downloaded = standalone.waitForEvent('download')
    await standalone.locator('#export-png-btn').click()
    const png = new Uint8Array(await Bun.file((await (await downloaded).path())!).arrayBuffer())
    expect([...png.slice(0, 8)]).toEqual([137, 80, 78, 71, 13, 10, 26, 10])
    expect(await replacement.evaluate(() => (globalThis as any).__exportOperations)).toEqual(['ascii', 'unicode', 'png'])
    // The single-file worker uses complete eager families rather than hosted
    // loaders. Check graphical and terminal hooks through that actual worker.
    for (const family of BUILTIN_FAMILY_METADATA) {
      const artifacts = await standalone.evaluate(async source => {
        const api = (window as any).__mermaid
        return {
          svg: await api.renderMermaidSVGWithReceipt(source),
          ascii: await api.renderMermaidASCIIWithReceipt(source, { colorMode: 'none' }),
        }
      }, family.example)
      const [expected] = await sourcePreviews([{ source: family.example, options: { security: 'strict', embedFontImport: false } }])
      expect(artifacts.svg.svg, family.id).toBe(expected!.svg)
      expect(artifacts.svg.receipt, family.id).toEqual(expected!.receipt)
      expect(artifacts.svg.verification, family.id).toEqual(expected!.verification)
      const ascii = renderMermaidASCIIWithReceipt(family.example, { colorMode: 'none', useAscii: true })
      expect(artifacts.ascii.text, family.id).toBe(ascii.text)
      expect(artifacts.ascii.receipt, family.id).toEqual(ascii.receipt)
    }
  } finally { await standalone.close() }
})

describe('browser: live editor integration', () => {
  it('browser DOM retains independently authored Pie entity labels', async () => {
    const labelPage = await browser.newPage()
    try {
      await labelPage.setContent('<div id="labels"></div>')
      const fixtures = [
        ...PIE_ENTITY_FIXTURES,
        { sourceLabel: 'A#60;br#62;B', display: 'A<br>B' },
        { sourceLabel: 'A#60;b#62;X#60;/b#62;B', display: 'A<b>X</b>B' },
        { sourceLabel: 'A&#60;b>B', display: 'A&<b>B' },
        { sourceLabel: 'A#\\35;B', display: 'A#35;B' },
        { sourceLabel: 'A#92;nB', display: 'A\\nB' },
        { sourceLabel: 'A#92;#114;B', display: 'A\\rB' },
        { sourceLabel: 'styleX:#35;', display: 'styleX:#35' },
        { sourceLabel: 'classDefX:#35;', display: 'classDefX:#35' },
      ]
      for (const { sourceLabel, display } of fixtures) {
        const actual = await labelPage.evaluate(svg => {
          const wrapper = document.getElementById('labels')!
          wrapper.innerHTML = svg
          return wrapper.querySelector('.pie-legend-text')?.textContent
        }, renderMermaidSVG(`pie\n  "${sourceLabel}" : 1\n`))
        expect(actual, sourceLabel).toBe(`${display} (100.0%)`)
      }
    } finally {
      await labelPage.close()
    }
  })

  it('contains long regular and highlighted pie legend rows across fallback fonts', async () => {
    const label = 'W'.repeat(48)
    const cases = [
      { file: 'Inter-Regular.ttf', family: 'E2E Inter Regular', weight: 500, highlighted: false },
      { file: 'DejaVuSans.ttf', family: 'E2E DejaVu Regular', weight: 500, highlighted: false },
      { file: 'Inter-Bold.ttf', family: 'E2E Inter Bold', weight: 700, highlighted: true },
      { file: 'DejaVuSans-Bold.ttf', family: 'E2E DejaVu Bold', weight: 700, highlighted: true },
    ] as const

    for (const testCase of cases) {
      const frontmatter = testCase.highlighted
        ? `---\nconfig:\n  pie:\n    highlightSlice: ${label}\n---\n`
        : ''
      const svg = renderMermaidSVG(`${frontmatter}pie showData
  "${label}" : 2
  "Other" : 1`, { embedFontImport: false })
      const fontBytes = await Bun.file(join(ROOT, 'assets', 'fonts', testCase.file)).arrayBuffer()
      const fontUrl = `data:font/ttf;base64,${Buffer.from(fontBytes).toString('base64')}`
      await page.setContent(svg)
      await page.addStyleTag({ content: `
        @font-face {
          font-family: "${testCase.family}";
          src: url("${fontUrl}") format("truetype");
          font-weight: ${testCase.weight};
        }
        svg text { font-family: "${testCase.family}" !important; }
      ` })
      await page.evaluate(async ({ family, weight }) => {
        await document.fonts.load(`${weight} 13px "${family}"`)
        await document.fonts.ready
      }, { family: testCase.family, weight: testCase.weight })

      const bounds = await page.locator('.pie-legend-text').first().evaluate((text: SVGGraphicsElement) => {
        const box = text.getBBox()
        const viewBox = text.ownerSVGElement!.viewBox.baseVal
        return {
          textRight: box.x + box.width,
          canvasRight: viewBox.x + viewBox.width,
          remaining: viewBox.x + viewBox.width - box.x - box.width,
        }
      })
      expect(await page.locator('.pie-legend-text').first().textContent()).toContain(label)
      expect(bounds.textRight).toBeLessThanOrEqual(bounds.canvasRight)
      expect(bounds.remaining).toBeGreaterThanOrEqual(1)
    }
  })

  it('pie hover emphasis remains reachable when interactive tooltips add a hit target', async () => {
    const svg = renderMermaidSVG(`---
config:
  pie:
    highlightSlice: hover
---
pie showData
  "Dogs" : 386
  "Cats" : 85
  "Rats" : 15`, { interactive: true, embedFontImport: false })
    await page.setContent(svg)

    const hitTarget = page.locator('.pie-slice-hover-target').first()
    const box = await hitTarget.boundingBox()
    expect(box).not.toBeNull()
    if (!box) return

    // The transparent overlay owns pointer hit-testing. Find an interior point
    // instead of assuming the bounding-box centre lies inside this wedge.
    const point = await hitTarget.evaluate((path, bounds) => {
      for (let y = bounds.y + 2; y < bounds.y + bounds.height - 1; y += 3) {
        for (let x = bounds.x + 2; x < bounds.x + bounds.width - 1; x += 3) {
          if (document.elementFromPoint(x, y) === path) return { x, y }
        }
      }
      return null
    }, box)
    expect(point).not.toBeNull()
    if (!point) return

    await page.mouse.move(point.x, point.y)
    await page.waitForFunction(() => {
      const path = document.querySelector('.pie-slice-hover-target')
      const tip = document.querySelector('.pie-tip')
      if (!path || !tip) return false
      const style = getComputedStyle(path)
      return style.stroke === 'rgb(39, 39, 42)' &&
        parseFloat(style.strokeWidth) === 2.5 &&
        style.opacity === '1' &&
        getComputedStyle(tip).opacity === '1'
    })
    expect(await hitTarget.evaluate(path => ({
      stroke: getComputedStyle(path).stroke,
      strokeWidth: parseFloat(getComputedStyle(path).strokeWidth),
      opacity: getComputedStyle(path).opacity,
    }))).toEqual({ stroke: 'rgb(39, 39, 42)', strokeWidth: 2.5, opacity: '1' })
    expect(await page.locator('.pie-tip').first().evaluate(tip =>
      getComputedStyle(tip).opacity)).toBe('1')
  })

  it('pie hover emphasis survives styled redraws without enabling tooltips', async () => {
    const source = `---
config:
  pie:
    highlightSlice: hover
---
pie showData
  "Dogs" : 386
  "Cats" : 85
  "Rats" : 15`

    for (const style of ['hand-drawn', 'watercolor'] as const) {
      const svg = renderMermaidSVG(source, { style, embedFontImport: false })
      await page.setContent(svg)
      expect(await page.locator('.pie-tip').count()).toBe(0)
      expect(await page.locator('title').count()).toBe(0)

      const hitTarget = page.locator('.pie-slice-hover-target').first()
      const box = await hitTarget.boundingBox()
      expect(box).not.toBeNull()
      if (!box) continue
      const point = await hitTarget.evaluate((path, bounds) => {
        for (let y = bounds.y + 2; y < bounds.y + bounds.height - 1; y += 3) {
          for (let x = bounds.x + 2; x < bounds.x + bounds.width - 1; x += 3) {
            if (document.elementFromPoint(x, y) === path) return { x, y }
          }
        }
        return null
      }, box)
      expect(point).not.toBeNull()
      if (!point) continue

      await page.mouse.move(point.x, point.y)
      await page.waitForFunction(() => {
        const path = document.querySelector('.pie-slice-hover-target')
        if (!path) return false
        const computed = getComputedStyle(path)
        return computed.stroke !== 'rgba(0, 0, 0, 0)' &&
          parseFloat(computed.strokeWidth) >= 2.5 &&
          computed.opacity === '1'
      })
      expect(await hitTarget.evaluate(path => ({
        stroke: getComputedStyle(path).stroke,
        strokeWidth: parseFloat(getComputedStyle(path).strokeWidth),
        opacity: getComputedStyle(path).opacity,
      }))).toMatchObject({ strokeWidth: 2.5, opacity: '1' })
    }
  })

  it('opens /editor to the default loop diagram on the Kiln Stone chrome', async () => {
    await gotoApp(`${BASE}/editor`)
    await page.waitForSelector('#code-editor', { timeout: 30_000 })
    await waitForEditorRender(60_000)

    // The editor opens with its own parse -> verify -> serialize loop already
    // rendered, so the loop "just works" on first paint instead of a blank canvas.
    expect(await page.inputValue('#code-editor')).toContain('flowchart TD')
    expect(await page.evaluate(() => document.querySelector('#preview-inner svg') !== null)).toBe(true)
    // Chrome is the Kiln Stone brand (light), independent of the diagram theme.
    expect(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--t-bg').trim())).toBe('#F8F4F0')
    // The default diagram theme is applied automatically, so nothing is persisted.
    expect(await page.evaluate(() => localStorage.getItem('bm-editor-palette'))).toBeNull()
  }, 60_000)

  it('mobile editor uses pane tabs instead of clipping the workspace', async () => {
    // Restore the desktop viewport even on failure — gotoApp carries the
    // previous page's viewport forward, so a leak here cascades into every
    // later test that expects the desktop layout.
    try {
      await page.setViewportSize({ width: 390, height: 844 })
      await gotoApp(`${BASE}/editor`)
      // Mobile first-run opens on Preview so the rendered diagram and the
      // verify bar are the first thing a phone visitor sees.
      await page.waitForSelector('#panel-right', { state: 'visible', timeout: 30_000 })

      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true)
      expect(await page.locator('#mode-preview').isVisible()).toBe(true)
      expect(await page.evaluate(() => getComputedStyle(document.getElementById('panel-left')!).display)).toBe('none')
      expect(await page.evaluate(() => getComputedStyle(document.getElementById('panel-right')!).display)).toBe('flex')

      await page.click('#mode-source')
      expect(await page.evaluate(() => getComputedStyle(document.getElementById('panel-left')!).display)).toBe('flex')
      await page.waitForSelector('#code-editor', { state: 'visible', timeout: 30_000 })
    } finally {
      await page.setViewportSize({ width: 1280, height: 720 })
    }
  }, 60_000)

  it('retargets preview zoom and pauses a focused toast without blocking its eventual dismissal', async () => {
    await withFakeClock(async () => {
      await gotoApp(`${BASE}/editor`)
      await page.waitForSelector('#code-editor', { timeout: 30_000 })
      await waitForEditorRender(60_000)

      await page.click('#zoom-label')
      await page.waitForFunction(() => document.getElementById('zoom-label')?.textContent === '100%', undefined, { timeout: 10_000 })
      await page.click('#zoom-in-btn')
      await page.click('#zoom-in-btn')
      await page.click('#zoom-in-btn')
      await page.waitForFunction(() => document.getElementById('zoom-label')?.textContent === '195%', undefined, { timeout: 10_000 })

      await page.click('#pan-btn')
      await page.evaluate(() => {
        const body = document.getElementById('preview-body')!
        const pointer = (type: string, pointerId: number, clientX: number, clientY: number) => body.dispatchEvent(new PointerEvent(type, {
          bubbles: true, cancelable: true, pointerId, pointerType: 'touch', clientX, clientY,
        }))
        pointer('pointerdown', 1, 120, 160)
        pointer('pointerdown', 2, 220, 160)
        pointer('pointermove', 2, 300, 160)
        pointer('pointerup', 2, 300, 160)
        pointer('pointerup', 1, 120, 160)
      })
      await page.waitForFunction(() => Number.parseInt(document.getElementById('zoom-label')?.textContent || '0', 10) > 195, undefined, { timeout: 10_000 })

      // From here the toast's timers run on the paused fake clock: the 80 ms
      // replacement and the 2500 ms dismissal fire only when the test says so.
      await pausePageClock()
      // The generated editor runs from a local HTTP origin, so clipboard access
      // intentionally fails and exercises the same user-visible toast path.
      await page.click('#copy-text-output-btn')
      await page.locator('#toast.show').waitFor({ state: 'visible', timeout: 10_000 })
      await page.locator('#toast').focus()
      // Programmatic activation preserves focus on the status node, exercising
      // replacement while a reader is still holding the pause.
      await page.evaluate(() => (document.getElementById('copy-text-output-btn') as HTMLButtonElement).click())
      await page.clock.runFor(150)
      expect(await page.locator('#toast').evaluate((el) => ({ show: el.classList.contains('show'), replacing: el.classList.contains('replacing') })))
        .toEqual({ show: true, replacing: false })
      // Well past the 2500 ms duration, the focused toast is still paused on screen.
      await page.clock.runFor(2600)
      expect(await page.locator('#toast').evaluate((el) => el.classList.contains('show'))).toBe(true)
      // Moving focus away resumes it, and it dismisses after its remaining time.
      await page.locator('#zoom-label').focus()
      await page.clock.runFor(2600)
      expect(await page.locator('#toast').evaluate((el) => el.classList.contains('show'))).toBe(false)
      await page.clock.resume()

      await page.click('#export-chevron-btn')
      await page.keyboard.press('Escape')
      expect(await page.locator('#export-dropdown').evaluate((el) => ({ inert: (el as HTMLElement).inert, closing: el.classList.contains('closing') }))).toEqual({ inert: true, closing: true })
      await page.waitForFunction(() => !document.getElementById('export-dropdown')?.classList.contains('closing'), undefined, { timeout: 1_000 })
    })
  }, 60_000)

  it('lets an ordinary pointer grab preview momentum and suppresses coast under reduced motion', async () => {
    await withFakeClock(async () => {
      // Each preview runs on a paused fake clock once it is ready: pointer
      // samples read performance.now() and the coast runs on requestAnimationFrame,
      // so velocity and coast distance depend only on the runFor steps below.
      async function preparePannablePreview() {
        await context.clock.resume() // the clock is per context: let the new page load and render
        await gotoApp(`${BASE}/editor`)
        await page.waitForSelector('#code-editor', { timeout: 30_000 })
        await waitForEditorRender(60_000)
        await page.click('#zoom-label')
        await page.waitForFunction(() => document.getElementById('zoom-label')?.textContent === '100%', undefined, { timeout: 10_000 })
        for (let i = 0; i < 6; i++) await page.click('#zoom-in-btn')
        await page.waitForFunction(() => Number.parseInt(document.getElementById('zoom-label')?.textContent || '0', 10) >= 380, undefined, { timeout: 10_000 })
        await page.click('#pan-btn')
        await pausePageClock()
      }
      async function flingLeft(stationaryBeforeReleaseMs = 0) {
        const box = await page.locator('#preview-body').boundingBox()
        expect(box).not.toBeNull()
        const x = box!.x + box!.width * 0.6
        const y = box!.y + box!.height * 0.5
        await page.mouse.move(x, y)
        await page.mouse.down()
        await page.clock.runFor(24)
        await page.mouse.move(x - 140, y)
        if (stationaryBeforeReleaseMs) await page.clock.runFor(stationaryBeforeReleaseMs)
        await page.mouse.up()
      }
      const scrollLeft = () => page.locator('#preview-body').evaluate((el) => (el as HTMLElement).scrollLeft)

      await preparePannablePreview()
      await flingLeft()
      await page.clock.runFor(40)
      const beforeGrab = await scrollLeft()
      await page.clock.runFor(120)
      expect(await scrollLeft()).toBeGreaterThan(beforeGrab)
      // A release after a deliberate stationary hold must not reuse old drag velocity.
      await preparePannablePreview()
      await flingLeft(150)
      const afterStationaryRelease = await scrollLeft()
      await page.clock.runFor(160)
      expect(await scrollLeft()).toBe(afterStationaryRelease)

      // Start a fresh coast and grab it promptly, before it can reach its scroll bound.
      await preparePannablePreview()
      await flingLeft()
      await page.clock.runFor(16)
      const coasting = await scrollLeft()
      await page.clock.runFor(16)
      expect(await scrollLeft()).toBeGreaterThan(coasting) // the coast is live when grabbed
      await page.click('#pan-btn')
      const box = await page.locator('#preview-body').boundingBox()
      await page.mouse.move(box!.x + box!.width * 0.6, box!.y + box!.height * 0.5)
      await page.mouse.down()
      await page.mouse.up()
      const afterGrab = await scrollLeft()
      await page.clock.runFor(120)
      expect(await scrollLeft()).toBe(afterGrab)

      try {
        await preparePannablePreview()
        await page.emulateMedia({ reducedMotion: 'reduce' })
        await flingLeft()
        const afterRelease = await scrollLeft()
        await page.clock.runFor(160)
        expect(await scrollLeft()).toBe(afterRelease)
      } finally {
        await page.emulateMedia({ reducedMotion: 'no-preference' })
      }
    })
  }, 60_000)

  it('commits button zoom immediately under reduced motion', async () => {
    await gotoApp(`${BASE}/editor`)
    await page.waitForSelector('#code-editor', { timeout: 30_000 })
    await waitForEditorRender(60_000)
    try {
      await page.emulateMedia({ reducedMotion: 'reduce' })
      await page.click('#zoom-label')
      await page.waitForFunction(() => document.getElementById('zoom-label')?.textContent === '100%', undefined, { timeout: 10_000 })
      await page.click('#zoom-in-btn')
      expect(await page.locator('#zoom-label').textContent()).toBe('125%')
      expect(await page.locator('#preview-inner svg').evaluate((el) => ({ transform: (el as HTMLElement).style.transform, width: (el as HTMLElement).style.width }))).toEqual({ transform: '', width: expect.stringMatching(/px$/) })
    } finally {
      await page.emulateMedia({ reducedMotion: 'no-preference' })
    }
  }, 60_000)

  it('empty-state CTA opens a persistent examples sidebar', async () => {
    await gotoApp(`${BASE}/editor`)
    await page.waitForSelector('#code-editor', { timeout: 30_000 })

    // The editor opens with the default loop diagram; clearing the source drops
    // it to the blank-canvas empty state, which surfaces the load-example CTA.
    await page.fill('#code-editor', '')
    await page.waitForSelector('[data-action="load-example"]', { state: 'visible', timeout: 30_000 })

    expect(await page.evaluate(() => document.getElementById('examples-sidebar')?.classList.contains('open'))).toBe(false)
    await page.click('[data-action="load-example"]')
    await page.waitForFunction(
      () => document.getElementById('examples-sidebar')?.classList.contains('open') === true,
      undefined,
      { timeout: 10_000 },
    )

    await page.waitForFunction(
      () => (document.getElementById('examples-sidebar')?.getBoundingClientRect().width ?? 0) >= 280,
      undefined,
      { timeout: 10_000 },
    )
    const sidebarBox = await page.locator('#examples-sidebar').boundingBox()
    expect(sidebarBox).not.toBeNull()
    expect(sidebarBox!.width).toBeGreaterThanOrEqual(280)

    await page.click('#examples-sidebar .example-dropdown-item[data-example="flowchart-basic"]')
    await waitForEditorRender(60_000)
    expect(await page.inputValue('#code-editor')).toContain('flowchart TD')
    // Picking an example closes the sidebar so the rendered result is unobstructed.
    expect(await page.evaluate(() => document.getElementById('examples-sidebar')?.classList.contains('open'))).toBe(false)
  }, 120_000)

  it('opens /editor and renders fork-added diagram families through the bundled renderer', async () => {
    await gotoApp(`${BASE}/editor`)
    await page.waitForSelector('#code-editor', { timeout: 30_000 })

    const cases: Array<
      | { source: string; markers: string[] }
      | { example: string; header: string; label: string; editedLabel: string; markers: string[] }
    > = [
      {
        source: `architecture-beta
  group app(cloud)[Application]
  service api(server)[Public API] in app
  service db(database)[Postgres] in app
  api:B --> T:db`,
        markers: ['Public API', 'Postgres', 'architecture-group'],
      },
      {
        source: `timeline
  title Product roadmap
  section Foundation
  2024 : Private alpha
       : Public beta`,
        markers: ['Product roadmap', 'Private alpha', 'timeline-period'],
      },
      {
        source: `journey
  title Onboarding
  section Discover
    Read docs: 4: User
    Try editor: 5: User, Developer`,
        markers: ['Onboarding', 'Try editor', 'journey-task'],
      },
      {
        source: `xychart-beta
  title "Editor Sales"
  x-axis [Widgets, Gadgets, Gizmos]
  bar [150, 230, 180]
  line [120, 210, 200]`,
        markers: ['Editor Sales', 'xychart-bar', 'xychart-line'],
      },
      { example: 'packet-basic', header: 'packet', label: 'Source port', editedLabel: 'AuditPort', markers: ['UDP datagram', 'Source port', 'data-field-id="field-0"'] },
      { example: 'kanban-basic', header: 'kanban', label: 'Packet family', editedLabel: 'AuditPacket', markers: ['Packet family', 'In progress', 'data-parent="doing"'] },
      { example: 'requirement-basic', header: 'requirementDiagram', label: 'Requests retain authored meaning', editedLabel: 'AuditMeaning', markers: ['data-id="reliable"', 'data-id="suite"', 'verifies'] },
      { example: 'block-basic', header: 'block', label: 'Client', editedLabel: 'AuditClient', markers: ['Client', 'Primary', 'data-parent="data"'] },
      { example: 'treemap-basic', header: 'treemap', label: 'Engineering', editedLabel: 'AuditEngineering', markers: ['Product investment', 'Engineering', 'Research'] },
      { example: 'ishikawa-basic', header: 'ishikawa', label: 'Delayed release', editedLabel: 'AuditRelease', markers: ['Delayed release', 'Cold caches', 'Unstable test data'] },
    ]

    for (const testCase of cases) {
      if ('example' in testCase) {
        // Start blank so selecting the next template cannot overwrite an
        // authored draft or depend on a confirmation dialog from a prior case.
        await page.fill('#code-editor', '')
        await page.click('#examples-sidebar-btn')
        await page.click(`#examples-sidebar .example-dropdown-item[data-example="${testCase.example}"]`)
        const source = await page.inputValue('#code-editor')
        expect(source).toStartWith(testCase.header)
        expect(source).toContain(testCase.label)
      } else {
        await page.fill('#code-editor', testCase.source)
      }
      await page.waitForFunction(
        (markers: string[]) => {
          const html = document.querySelector('#preview-inner svg')?.outerHTML ?? ''
          return markers.every(marker => html.includes(marker))
        },
        testCase.markers,
        { timeout: 60_000 },
      )
      expect(await page.evaluate(
        (markers: string[]) => {
          const html = document.querySelector('#preview-inner svg')?.outerHTML ?? ''
          return markers.every(marker => html.includes(marker))
        },
        testCase.markers,
      )).toBe(true)
      if ('example' in testCase) {
        await waitForEditorRender(60_000)
        const digest = await page.locator('#preview-inner').getAttribute('data-shared-request-digest')
        expect(digest).toBeTruthy()
        await page.fill('#code-editor', (await page.inputValue('#code-editor')).replace(testCase.label, testCase.editedLabel))
        await page.waitForFunction(({ digest, label }) => {
          const preview = document.querySelector<HTMLElement>('#preview-inner')
          return document.getElementById('status-text')?.textContent === 'OK'
            && Boolean(preview?.dataset.sharedRequestDigest)
            && preview?.dataset.sharedRequestDigest !== digest
            && preview?.querySelector('svg')?.textContent?.includes(label)
        }, { digest, label: testCase.editedLabel }, { timeout: 60_000 })
        await page.click('#format-ascii')
        await page.waitForFunction(label => {
          const preview = document.querySelector<HTMLElement>('#preview-inner')
          return document.getElementById('ascii-output')?.textContent?.includes(label)
            && Boolean(preview?.dataset.asciiSharedRequestDigest)
            && preview?.dataset.asciiSharedRequestDigest === preview?.dataset.sharedRequestDigest
        }, testCase.editedLabel, { timeout: 60_000 })
        await page.click('#format-diagram')
      }
    }
  }, 120_000)

  it('uses local theme registry entries in the editor theme dropdown', async () => {
    await page.evaluate(() => { localStorage.removeItem('bm-editor-palette') })
    await gotoApp(`${BASE}/editor`)
    await page.waitForSelector('#code-editor', { timeout: 30_000 })
    await page.fill('#code-editor', 'graph TD\n  A[Theme] --> B[Render]')
    await waitForEditorRender(60_000)

    const salmonBg = await page.evaluate(
      () => (window as unknown as { __mermaid: { getStyle(name: string): { colors?: { bg?: string } } | undefined } })
        .__mermaid.getStyle('salmon')?.colors?.bg,
    )
    expect(typeof salmonBg).toBe('string')
    if (typeof salmonBg !== 'string') throw new Error('salmon style must define a background colour')
    expect(await page.locator('#preview-inner svg').getAttribute('style')).not.toContain('--bg: ' + salmonBg)

    await page.click('#theme-dropdown-btn')
    await page.click('.theme-dropdown-item[data-theme="salmon"]')
    // Selecting a diagram theme recolors the rendered SVG, not the editor chrome:
    // the SVG picks up salmon's --bg while --t-bg stays the Paper brand chrome.
    await page.waitForFunction(
      (bg: string) => (document.querySelector('#preview-inner svg')?.getAttribute('style') ?? '').includes('--bg: ' + bg),
      salmonBg,
      { timeout: 30_000 },
    )
    await waitForEditorRender(60_000)

    expect(await page.evaluate(() => localStorage.getItem('bm-editor-palette'))).toBe('salmon')
    expect(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--t-bg').trim())).toBe('#F8F4F0')
  }, 120_000)

  it('examples sidebar keeps the selected theme and exposes blank reset without a floating source toolbar', async () => {
    await gotoApp(`${BASE}/editor`, { clearDraft: true })
    await page.waitForSelector('#code-editor', { timeout: 30_000 })

    await page.click('#theme-dropdown-btn')
    await page.click('.theme-dropdown-item[data-theme="salmon"]')
    // The diagram recolors to salmon; the editor chrome stays Kiln Stone.
    await page.waitForFunction(
      () => (document.querySelector('#preview-inner svg')?.getAttribute('style') ?? '').includes('--bg: #FFFBF5'),
      undefined,
      { timeout: 30_000 },
    )

    expect(await page.locator('#source-toolbar').count()).toBe(0)
    expect(await page.locator('#example-dropdown-btn').count()).toBe(0)
    expect(await page.locator('#copy-source-btn').count()).toBe(1)

    await page.click('#export-chevron-btn')
    await page.waitForFunction(
      () => document.getElementById('export-dropdown')?.classList.contains('open') === true,
      undefined,
      { timeout: 10_000 },
    )
    expect(await page.locator('#copy-source-btn').isVisible()).toBe(true)
    // The editor opened with the default loop diagram rendered, so PNG export is enabled.
    expect(await page.locator('#export-png-btn').isDisabled()).toBe(false)

    await page.click('#examples-sidebar-btn')
    await page.waitForFunction(
      () => document.getElementById('examples-sidebar')?.classList.contains('open') === true,
      undefined,
      { timeout: 10_000 },
    )

    const diagramTypes = await page.evaluate(() => Array.from(
      new Set(Array.from(document.querySelectorAll('#examples-sidebar .example-dropdown-item'))
        .map(el => (el as HTMLElement).dataset.diagram)
        .filter(Boolean)),
    ).sort())

    expect(diagramTypes).toEqual(BUILTIN_FAMILY_METADATA.map(f => f.editorDiagramType).sort())

    const sidebarBox = await page.locator('#examples-sidebar').boundingBox()
    expect(sidebarBox).not.toBeNull()
    expect(sidebarBox!.width).toBeGreaterThanOrEqual(280)

    await page.click('#examples-sidebar .example-dropdown-item[data-example="state-basic"]')
    await page.waitForFunction(
      () => (document.querySelector('#preview-inner svg')?.outerHTML ?? '').includes('Processing'),
      undefined,
      { timeout: 60_000 },
    )
    expect(await page.inputValue('#code-editor')).toContain('stateDiagram-v2')
    // Chrome stays Kiln Stone; the example kept the salmon diagram theme (not overridden).
    expect(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--t-bg').trim())).toBe('#F8F4F0')
    expect(await page.evaluate(() => localStorage.getItem('bm-editor-palette'))).toBe('salmon')

    // Selecting the example closed the sidebar; re-open it to reach the blank reset.
    await page.click('#examples-sidebar-btn')
    await page.waitForFunction(
      () => document.getElementById('examples-sidebar')?.classList.contains('open') === true,
      undefined,
      { timeout: 10_000 },
    )
    await page.click('#examples-sidebar [data-action="clear-editor"]')
    expect(await page.inputValue('#code-editor')).toBe('')
    expect(await page.evaluate(() => document.getElementById('status-text')?.textContent)).toBe('Ready')
    expect(await page.evaluate(() => document.querySelector('#preview-inner svg') === null)).toBe(true)
  }, 120_000)

  it('topbar button dimensions do not shift when toggling day/dark mode', async () => {
    // #dark-light-btn is hidden below 760px; pin a desktop viewport so a prior
    // mobile test can't leave it hidden here.
    await page.setViewportSize({ width: 1280, height: 720 })
    await gotoApp(`${BASE}/editor`)
    await page.waitForSelector('#code-editor', { timeout: 30_000 })

    const before = await page.locator('#dark-light-btn').boundingBox()
    const themeBefore = await page.locator('#theme-dropdown-btn').boundingBox()
    const chromeBefore = await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--t-bg').trim())
    await page.click('#dark-light-btn')
    const after = await page.locator('#dark-light-btn').boundingBox()
    const themeAfter = await page.locator('#theme-dropdown-btn').boundingBox()

    expect(before).not.toBeNull()
    expect(after).not.toBeNull()
    expect(themeBefore).not.toBeNull()
    expect(themeAfter).not.toBeNull()
    expect(after!.width).toBe(before!.width)
    expect(after!.height).toBe(before!.height)
    expect(themeAfter!.width).toBe(themeBefore!.width)
    expect(themeAfter!.height).toBe(themeBefore!.height)
    expect(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--t-bg').trim())).not.toBe(chromeBefore)
  }, 60_000)

  it('loads source/config examples without overriding the selected theme', async () => {
    await gotoApp(`${BASE}/editor`, { clearDraft: true })
    await page.waitForSelector('#code-editor', { timeout: 30_000 })
    // The chrome bg must not change with the diagram theme; capture it up front so
    // the assertion holds whether or not a prior test left the editor in dark mode.
    const chromeBg = await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--t-bg').trim())

    await page.click('#theme-dropdown-btn')
    await page.click('.theme-dropdown-item[data-theme="dracula"]')
    // Diagram theme becomes dracula (recolors the SVG); chrome stays Kiln Stone.
    await page.waitForFunction(
      () => (document.querySelector('#preview-inner svg')?.getAttribute('style') ?? '').includes('--bg: #282a36'),
      undefined,
      { timeout: 30_000 },
    )

    await page.click('#examples-sidebar-btn')
    await page.click('#examples-sidebar .example-dropdown-item[data-example="xychart-basic"]')

    await page.waitForFunction(
      () => {
        const svg = document.querySelector('#preview-inner svg')
        const html = svg?.outerHTML ?? ''
        return html.includes('Weekly renders')
          && html.includes('xychart-bar')
          && (svg?.getAttribute('style') ?? '').includes('--bg: #282a36')
      },
      undefined,
      { timeout: 60_000 },
    )

    // Source, config, and theme updates share one compressed hash but are
    // scheduled independently by the editor. Wait for the semantic hash state,
    // not merely the earlier SVG paint, so this test cannot race a config write.
    await page.waitForFunction(async () => {
      try {
        const hash = window.location.hash.slice(1)
        if (!hash.startsWith('deflate:')) return false
        let b64 = hash.slice('deflate:'.length).replace(/-/g, '+').replace(/_/g, '/')
        while (b64.length % 4) b64 += '='
        const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0))
        const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'))
        const state = JSON.parse(await new Response(stream).text()) as { config?: { interactive?: boolean } | null; palette?: string }
        return state.config?.interactive === true && state.palette === 'dracula'
      } catch {
        return false
      }
    }, undefined, { timeout: 30_000 })

    const hashState = await page.evaluate(async () => {
      // Mirrors sharing.js decodeSource: canonical hashes are
      // deflate:-prefixed base64url(deflate-raw).
      const hash = window.location.hash.slice(1)
      if (!hash.startsWith('deflate:')) throw new Error('non-canonical editor hash')
      let b64 = hash.slice('deflate:'.length).replace(/-/g, '+').replace(/_/g, '/')
      while (b64.length % 4) b64 += '='
      const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0))
      const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'))
      return JSON.parse(await new Response(stream).text())
    })

    expect(hashState.config).toMatchObject({ interactive: true })
    expect(hashState.config.style).toBeUndefined()
    expect(hashState.palette).toBe('dracula')
    // The diagram keeps the dracula theme; the editor chrome is unchanged by it.
    expect(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--t-bg').trim())).toBe(chromeBg)
    expect(await page.evaluate(() => localStorage.getItem('bm-editor-palette'))).toBe('dracula')
  }, 120_000)

  it('treats shared hash configuration as untrusted and renders only inert SVG', async () => {
    await context.addInitScript(() => { (window as any).__amAudit = 0 })
    const externalRequests: string[] = []
    const recordRequest = (request: { url(): string }) => {
      if (request.url().startsWith('https://evil.example/')) externalRequests.push(request.url())
    }
    context.on('request', recordRequest as any)
    try {
      const hostileCss = '@import url(https://evil.example/font.css);</style><svg onload="window.__amAudit=123"><script>window.__amAudit=456</script>'
      const source = 'flowchart TD\n  A[Safe] --> B[Preview]'
      const hostileHash = 'deflate:' + deflateRawSync(Buffer.from(JSON.stringify({
        source,
        palette: 'salmon',
        config: {
          accent: '#123456',
          security: 'loose',
          themeCSS: hostileCss,
        },
        style: { font: hostileCss },
      }), 'utf8')).toString('base64url')
      await gotoApp(`${BASE}/editor?empty=1#${hostileHash}`)
      await page.waitForFunction(
        () => ['OK', 'Error'].includes(document.querySelector('#status-text')?.textContent ?? ''),
        undefined,
        { timeout: 60_000 },
      )
      const settled = await page.evaluate(() => ({
        status: document.querySelector('#status-text')?.textContent ?? '',
        html: document.querySelector('#preview-inner')?.innerHTML ?? '',
      }))
      if (settled.status !== 'OK') {
        throw new Error(`untrusted share config did not render safely: ${settled.html}`)
      }
      await page.waitForFunction(() => location.hash.startsWith('#deflate:'), undefined, { timeout: 30_000 })

      const result = await page.evaluate(async () => {
        let b64 = location.hash.slice('#deflate:'.length).replace(/-/g, '+').replace(/_/g, '/')
        while (b64.length % 4) b64 += '='
        const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0))
        const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'))
        return {
          audit: (window as any).__amAudit,
          hasSvg: document.querySelector('#preview-inner svg') !== null,
          html: document.querySelector('#preview-inner svg')?.outerHTML ?? '',
          shared: JSON.parse(await new Response(stream).text()),
        }
      })
      expect(result.audit).toBe(0)
      expect(result.hasSvg).toBe(true)
      expect(result.html).not.toMatch(/<script|\sonload=|evil\.example/i)
      expect(result.html).toContain('#123456')
      expect(result.shared.config).toEqual({ accent: '#123456' })
      expect(result.shared.style).toBe('crisp')
      expect(result.shared.palette).toBe('salmon')
      expect(result.shared.seed).toBe(0)
      expect(externalRequests).toEqual([])
    } finally {
      context.off('request', recordRequest as any)
    }
  }, 120_000)

})

describe('browser: visual regression', () => {

  it('architecture rounded fills match screenshot baseline without decorative rails', async () => {
    await page.setViewportSize({ width: 1280, height: 720 })
    await gotoEditorWithWarmFonts('?visual=architecture-rounded-fill', editorHash(ARCHITECTURE_ROUNDED_FILL_SOURCE))
    await page.waitForFunction(
      () => {
        const svg = document.querySelector('#preview-inner svg')
        return svg !== null
          && svg.querySelectorAll('.architecture-group-band').length === 2
          && svg.querySelectorAll('.architecture-group-outline').length === 2
          && svg.querySelectorAll('.architecture-service-outline').length === 3
      },
      undefined,
      { timeout: 60_000 },
    )
    await page.evaluate(() => document.fonts?.ready)

    const svgHtml = await page.locator('#preview-inner svg').evaluate(el => el.outerHTML)
    // The hash supplies the status-dashboard Look, but the explicitly selected
    // Salmon Palette remains the final color layer.
    expect(svgHtml).toContain('--bg: #FFFBF5')
    expect(svgHtml).toContain('<path class="architecture-group-band"')
    expect(svgHtml).toContain('<rect class="architecture-group-outline"')
    expect(svgHtml).toContain('<rect class="architecture-service-outline"')
    expect(svgHtml).not.toContain('architecture-service-accent')
    expect(svgHtml).not.toContain('architecture-icon-bg')
    expect(svgHtml).not.toContain('architecture-icon-fill')
    expect(svgHtml).not.toContain('<rect class="architecture-group-band"')

    const currentPath = join(SCREENSHOT_DIR, 'current-architecture-rounded-fill.png')
    const baselinePath = join(SCREENSHOT_DIR, 'baseline-architecture-rounded-fill.png')
    await page.locator('#preview-inner svg').screenshot({ path: currentPath, animations: 'disabled' })

    if (!(await Bun.file(baselinePath).exists())) {
      if (process.env.UPDATE_BASELINES) {
        await Bun.write(baselinePath, Bun.file(currentPath))
        console.log('  Created baseline: baseline-architecture-rounded-fill.png')
        return
      }
      throw new Error(
        'Missing baseline screenshot: baseline-architecture-rounded-fill.png. ' +
        'Run with UPDATE_BASELINES=1 to create it.',
      )
    }

    const diff = await comparePngScreenshots(currentPath, baselinePath)
    expect(diff.dimensionMismatch).toBe(false)
    expect(diff.diffRatio).toBeLessThanOrEqual(ROUNDED_FILL_SCREENSHOT_MAX_DIFF)
  }, 120_000)

  it('rounded header fills and slop-free cards match screenshot baselines', async () => {
    await page.setViewportSize({ width: 1280, height: 720 })
    const cases = [
      {
        name: 'flowchart-rounded-fill',
        source: `flowchart TD
  subgraph edge[Edge Layer]
    web[Web App]
  end
  subgraph core[Core Services]
    api[API]
    db[(Postgres)]
  end
  web --> api
  api --> db`,
        required: ['<g class="subgraph" data-id="edge"', '<path d="M', 'A10,10'],
        forbidden: ['rx="18" ry="18" fill="var(--_group-hdr)"'],
      },
      {
        name: 'class-rounded-fill',
        source: `classDiagram
  class WebApp {
    +render()
    +fetchData()
  }
  class ApiService {
    +request()
  }
  WebApp --> ApiService : calls`,
        required: ['<g class="class-node"', '<path d="M', 'A10,10'],
        forbidden: ['rx="16" ry="16" fill="var(--_group-hdr)"'],
      },
      {
        name: 'er-rounded-fill',
        source: `erDiagram
  CUSTOMER {
    string id PK
    string name
  }
  ORDER {
    string id PK
    string customer_id FK
  }
  CUSTOMER ||--o{ ORDER : places`,
        required: ['<g class="entity"', '<path d="M', 'A10,10'],
        forbidden: ['rx="16" ry="16" fill="var(--_group-hdr)"'],
      },
      {
        name: 'journey-rounded-fill',
        source: `journey
  title Product journey
  section Discover
    Try editor: 5: User
  section Deliver
    Deploy fix: 4: Engineer`,
        required: [
          '<rect class="journey-section-label-band journey-section-band-',
          '<line class="journey-baseline"',
          '<g class="journey-score-marker"',
        ],
        forbidden: ['journey-task-accent'],
      },
      {
        name: 'timeline-rounded-fill',
        source: `timeline
  title Product roadmap
  section Build
  2024 : Alpha
       : Beta
  section Launch
  2025 : GA`,
        required: ['<path class="timeline-section-band"'],
        forbidden: ['<rect class="timeline-section-band"', 'timeline-event-accent'],
      },
    ]

    for (const testCase of cases) {
      await gotoEditorWithWarmFonts(`?visual=${encodeURIComponent(testCase.name)}`, editorHash(testCase.source))
      await page.evaluate(() => document.fonts?.ready)
      const svgHtml = await page.locator('#preview-inner svg').evaluate(el => el.outerHTML)
      for (const snippet of testCase.required) expect(svgHtml).toContain(snippet)
      for (const snippet of testCase.forbidden) expect(svgHtml).not.toContain(snippet)

      const currentPath = join(SCREENSHOT_DIR, `current-${testCase.name}.png`)
      const baselinePath = join(SCREENSHOT_DIR, `baseline-${testCase.name}.png`)
      await page.locator('#preview-inner svg').screenshot({ path: currentPath, animations: 'disabled' })

      if (!(await Bun.file(baselinePath).exists())) {
        if (process.env.UPDATE_BASELINES) {
          await Bun.write(baselinePath, Bun.file(currentPath))
          console.log(`  Created baseline: baseline-${testCase.name}.png`)
          continue
        }
        throw new Error(
          `Missing baseline screenshot: baseline-${testCase.name}.png. ` +
          'Run with UPDATE_BASELINES=1 to create it.',
        )
      }

      const diff = await comparePngScreenshots(currentPath, baselinePath)
      expect(diff.dimensionMismatch).toBe(false)
      expect(diff.diffRatio).toBeLessThanOrEqual(ROUNDED_FILL_SCREENSHOT_MAX_DIFF)
    }
  }, 240_000)
})
