import json,pathlib,gzip,subprocess
r=pathlib.Path('/tmp/pr449-week-comparison-20261101/main-9fb-integration');old=pathlib.Path('/tmp/pr449-week-comparison-20261101/current-execution-c9/affected-public-products');rows=[]
for p in sorted(old.glob('*/*/job.json')):
 rel=p.relative_to(old).parent;out=r/'frozen-controls-refined'/rel;out.mkdir(parents=True,exist_ok=True);j=json.load(open(p));j.update(root='/tmp/pr449-main-integration-20261029-762',revision='combined9fb main integration',expectedHead='combined9fb main integration',bindingReference=None);(out/'job.json').write_text(json.dumps(j,indent=2)+'\n')
 with open(out/'worker.log','w') as log:ret=subprocess.run(['node','/tmp/pr449-week-comparison-20261101/requirement-directions-62af/capture.mjs',str(out),str(out/'job.json')],stdout=log,stderr=subprocess.STDOUT)
 d=json.load(gzip.open(out/'RESULT.json.gz'));b=json.load(gzip.open(p.parent/'RESULT.json.gz'));row={'case':str(rel),'exit':ret.returncode,'status':d['status'],'beforeStatus':b['status']}
 if d['status']=='returned':row.update(svgExact=gzip.open(out/'actual.svg.gz','rb').read()==gzip.open(p.parent/'actual.svg.gz','rb').read(),receiptExact=gzip.open(out/'actual.receipt.json.gz','rb').read()==gzip.open(p.parent/'actual.receipt.json.gz','rb').read(),proof=d.get('proof',{}).get('status'))
 else:row['failureExact']=all(d.get('failure',{}).get(k)==b.get('failure',{}).get(k) for k in ['name','code','message'])
 rows.append(row);print(json.dumps(row),flush=True)
(r/'FROZEN-CONTROLS-REFINED.json').write_text(json.dumps(rows,indent=2)+'\n')
