import '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import {executeGraphicalRequest} from '/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts'
const rows=[]
for(const source of [
'flowchart LR\nA((One)) -->|left| T((Hub))\nB((Two)) -->|right| T',
'flowchart LR\nA((One)) --> T((Hub))\nB((Two)) --> T\nC((Three)) --> T',
'flowchart LR\nA((One)) --> T((Hub))\nB((Two)) --> T\nA --> B',
'flowchart TD\nA((One)) --> T((Hub))\nB((Two)) --> T',
]){const arms=[];for(const balanced of [false,true]){let g:any;const p=executeGraphicalRequest(source,{graphLayout:{backend:'agentic',...(balanced?{quality:'balanced'}:{})}},'svg',undefined,{}, {validate(){},consume(_r,v){g=v.positioned}});arms.push({score:g.certification.preference.selectedScore,opt:p.receipt.layoutOptimization,svg:p.svg,points:g.edges.map((e:any)=>e.points)});}rows.push({source,arms});console.log(source.replaceAll('\n','; '),arms.map(a=>({bends:a.score.totalBends,opt:a.opt})),arms[0].svg===arms[1].svg)}
await Bun.write('/tmp/pr449-week-comparison-20261101/main-9fb-integration/fan-probe.json',JSON.stringify(rows,null,2))
