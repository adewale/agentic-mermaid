## What changes

**Draft; retain ELK.** Head `9ec32417a7a0fafa340b9bf05db1ae66e029fa42`, base `e7cb05baa7f68154942a9ce9c6e9aaaee163dc94`. This PR repairs shared SVG ownership/measurement, improves selected Native workloads and adds opt-in Trinity. Defaults, versions and original limits are unchanged; omitted Flowchart layout retains the forest fast path already in main. ELK retirement is unqualified.

- Bind proof to actual SVG writes and occurrence ownership, preserving mutable/getter/CSS/definitions isolation and cumulative budgets.
- Reuse ER measurements/finalization: Native and ELK deliver ER256 in four directions at the original400k geometry limit; formerly refused BT/RL use385344 Native/371874 ELK operations. Refused work gets no speed ratio.
- Repair Native endpoint capacity, phantom paint demand from invisible constraints, shortening clearance, component packing and forests.
- Introduce explicit measured placement/routed results and selected-backend evidence. Trinity supports bounded rectangular/rounded Flowchart and State scopes, fixed State circles, canonical Class scopes with members/notes/cardinalities, flat ER/Requirement and single-container Architecture forests. Routed admission remains64subjects/128edges; Architecture's existing placement slice is separate. Unknown domains decline unless fallback was requested; exhaustion stays hard.
- Share canonical sharp-shaft Requirement demand across all three solvers. ELK translates endpoint support to actual ports/growth; emitted cards consume selected dimensions. Crowded containment-circle centers move7.67/10.77→20px versus11px required; a selected pair's hidden pixels180→0. [Repair, actual ink and adverse costs](https://github.com/adewale/agentic-mermaid/blob/91400dc282c7717ffa9bf658c83351969dc679de/trinity-common-requirement-checkpoint-20261109/README.md).
- Project flat-root Trinity contacts toward reserved neighbor lanes before routing. Requirement TB bends18→6, wire1072.96→507.03, area244079.95→242350.83, crossings0. Compound locals retain centered contacts because their external corridors are absent from local IR. [Three-way Requirement evidence and mixed costs](https://github.com/adewale/agentic-mermaid/blob/004cc22d0c46d053a708a95d5a6cf92f5ada74d5/trinity-root-ports-checkpoint-20261109/CURRENT-THREE-WAY.md).
- Add flat canonical decision diamonds: the existing labelled fan, inlet and feedback change12 directional Trinity refusals into12 returned/proof-passed products. The shape owner supplies exact facets and joined-stroke support; actual marker-roster facts are captured once into paid private bytes. Unmarked multiport facets and singleton cardinal marked ends are supported. Diamond compounds, loops and marked multiport faces still decline. Native/ELK's public diamond output is unchanged.

The earlier profiled heap/priority reuse preserves storage, ties, charges and full products. Its40-call paired result has overlapping ranges and no general speedup claim. [Five self/inclusive hotspots, cache inventory and stopped hypotheses](https://github.com/adewale/agentic-mermaid/blob/9ec32417a7a0fafa340b9bf05db1ae66e029fa42/docs/design/system/layout-0.6-performance-review.md); [paired raw results](https://github.com/adewale/agentic-mermaid/blob/77aa38c73ad6e4846bd7dffdfa95bf56366ff8c0/trinity-lazy-priority-checkpoint-20261109/README.md).

Current bounded extension under qualification: allow canonical diamonds inside authored groups only when **every** edge joins two leaf nodes with the same immediate parent and no boundary artwork. The shared compound pipeline then uses its existing local solves and no-lift contact closure; it never enters box-only boundary terminals. Preserve nested parents, frame headers, fixed/minimum growth, actual facet contacts, proof and all caps. A diamond-containing request with any crossing edge, even an unrelated rectangle-only edge, stays unsupported. Broad admission and the isolated cardinal-terminal shortcut remain unshipped: later terminals and joined-stroke obstacles need a complete boundary contract.

## Correctness and delivery

| Frozen30 original inputs | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| Returned / proof-passed | 28 | 28 | 27 |
| Unsupported image | 0 | 0 | 1 |
| Shared invalid-option errors | 2 | 2 | 2 |

These vectors are unchanged. The new diamond supplement is outside that denominator. Native/ELK's image return is a placeholder whose actual-image criterion fails. Proof-passed is not complete visible correctness. The retained613-criterion authored-meaning/finalSVG ledger is ELK575passed/6unsupported/29blocked/3failed, Native576/6/28/3, Trinity564/19/28/2; all19 Trinity unsupported criteria belong to the one image input. Parser/prelude credit is separate from selected-solver delivery.

The new milestone retains83 byte-exact frozen whole SVGs/entire receipts, six errors and one Trinity image refusal. Its72 prior Native/ELK directional SVG/receipt/layout files stay exact. Public owners inspect authored identities/endpoints/labels and actual emitted facet contacts; sampled canonical PNG review retains visible heads and connected routes. Rough/hybrid ink remains unqualified. These finite observations do not establish workload-wide parity.

Earlier scoped Native gains remain dated: forest wire700.04→397.71 versus ELK396.47, area226466→165356 versus176727. Sparse256's implemented historical area gap is+5.04%; the+0.97% backfill remains unshipped. [Prior comparison](https://github.com/adewale/agentic-mermaid/blob/fb8258f17fadf2996e15aa4c82a0973b1cefae4f/rebase-c366-reconsider-20261107/README.md).

## Current decision-fan comparison

Same authored TB source, explicit backend/fallback:none; full public SVG and entire receipt serialized. Two fresh Node24 processes/cell; medians are descriptive. Imports are separate2.59–5.99s source-loader observations, so first-target rows are not complete cold startup.

| Metric | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| Returned / proof | returned / passed | returned / passed | returned / passed |
| Area | 150521.35 | 120145.11 | 112311.36 |
| Written shaft wire / bends / crossings | 696.35 /4/0 | 456.51 /4/0 | 444.24 /4/0 |
| First target cache0, ms | 612.60 | 231.29 | 191.28 |
| Repeat2 cache0 wall / CPU, ms | 81.60 /151.20 | 36.81 /61.21 | 27.94 /54.75 |
| Authored edit cache0, ms | 73.37 | 31.67 | 31.17 |
| Repeat2 cache1, ms | 7.68 | 8.15 | 8.81 |
| Authored edit cache1, ms | 126.57 | 40.81 | 46.08 |
| API-return heap cache0repeat2, MiB | 64.93–65.42 | 39.90–39.95 | 38.09–38.86 |
| Lifetime RSS cache0repeat2, MiB | 201.80–208.96 | 183.51–184.70 | 167.63–184.74 |
| Complete response gzip9 / Brotli11 | 2685 /2282 | 2701 /2304 | 2703 /2303 |

All60 diamond calls return/P. Cached repeat and Native cached edit comparisons are adverse for Trinity; Native's LR/RL area93625.75 is below Trinity95380.17. Heap/RSS include harness/imports/retained products, not isolated solver peak or settled retention. No ratio against former Trinity refusal, general speedup, p95 or memory superiority follows.

Forty corrected baseline/candidate compound-control calls retain exact whole products with mixed costs: repeat1 wall147.99→152.91ms and authored-edit CPU280.74→334.85ms are adverse. Initial eight control processes had incorrect source-override paths and are explicitly excluded and retained. All100 qualified timed response streams match serialized lengths and decode exactly from actual gzip9/Brotli11 bytes. [Full costs, memory, original edits, exclusions and raw recovery](https://github.com/adewale/agentic-mermaid/blob/a937680f5eb35827c7da65466d1b9aa436f8c4a5/trinity-diamond-contact-checkpoint-20261109/README.md).

The [earlier frozen30 cost report](https://github.com/adewale/agentic-mermaid/blob/86869bd66c21f73db5c33928c242ed7a9b50186b/trinity-frozen-cost-checkpoint-20261109/README.md), source3f2, retains360 serial processes/1248attempts:1140returned/P,96invalid-option errors,12image refusals. Cached Flowchart and Architecture costs are adverse for Trinity; this narrower new case does not replace that workload scope.

## Distribution cost

Actual original13-input lazy-browser product union; all three lanes and the separate diamond browser case pass existing Trident qualification. Product bytes exclude the separately retained binding:

| Metric | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| gzip9 bytes | 858338 | 486523 | 479684 |
| Brotli11 bytes | 688745 | 417097 | 410948 |
| Requests including binding | 43 | 49 | 50 |
| Diamond milestone gzip / Brotli delta | +629 /+402 | +1030 /+710 | +1771 /+1404 |

Each lane adds two requests. These are actual fetched modules compressed offline; raw serving is not compressed-wire/startup or total-package measurement. Last standalone measurement at3f2 is1338451gzip bytes,3951 above the original1334500cap; it is not freshly rebuilt for this feature. No new cache or budget increase hides these costs.

## Visual evidence

Baseline SHA: `3d159ad7d99a1b29ea9d5c9f1e90d620ec631ce5`.
Current SHA: `9ec32417a7a0fafa340b9bf05db1ae66e029fa42`. Trinity previously declined this input; it has no before SVG. Images compare the unchanged ELK control and new Trinity delivery, using actual finalSVGs, manifest-verified Inter and system fonts off.

```mermaid
flowchart TD
Q{Decision} -->|left| L[Left]
Q -->|middle| M[Middle]
Q -.->|right| R[Right]
```

ELK control, TB:
![ELK decision fan](https://raw.githubusercontent.com/adewale/agentic-mermaid/a937680f5eb35827c7da65466d1b9aa436f8c4a5/trinity-diamond-contact-checkpoint-20261109/decision-fan-ELK-TB.png)

Trinity delivery, TB:
![Trinity decision fan](https://raw.githubusercontent.com/adewale/agentic-mermaid/a937680f5eb35827c7da65466d1b9aa436f8c4a5/trinity-diamond-contact-checkpoint-20261109/decision-fan-Trinity-TB.png)

[Singleton inlet, LR](https://raw.githubusercontent.com/adewale/agentic-mermaid/a937680f5eb35827c7da65466d1b9aa436f8c4a5/trinity-diamond-contact-checkpoint-20261109/decision-inlet-Trinity-LR.png), [feedback, TB](https://raw.githubusercontent.com/adewale/agentic-mermaid/a937680f5eb35827c7da65466d1b9aa436f8c4a5/trinity-diamond-contact-checkpoint-20261109/decision-feedback-Trinity-TB.png), all SVGs, receipts, layouts and failed probes are in the [verified recovery checkpoint](https://github.com/adewale/agentic-mermaid/blob/a937680f5eb35827c7da65466d1b9aa436f8c4a5/trinity-diamond-contact-checkpoint-20261109/README.md).

## Reproduce and verify

Run `bun test src/__tests__/graph-layout-selection.test.ts src/__tests__/trinity-layout.test.ts --timeout 30000`. The old kernel fails nine new owners; row aborts prevent claiming every inner variant independently red. Final milestone:497 owning checks across10files, core/repository types and lint pass. Independent review repaired an introduced ellipse-inheritance regression and found no remaining supported blocker. Only new diamond metadata is own-only; the previous ellipse contract is preserved. Full suite runs in CI.

## Remaining losses and CI

[Exact-head CI42611539845](https://github.com/adewale/agentic-mermaid/actions/runs/42611539845) is in progress; Ruff/pinning pass. [Previous CI42597120679](https://github.com/adewale/agentic-mermaid/actions/runs/42597120679) completed/failure: unit shard1, quality, payload and advisory jobs failed; unit shards2/3 passed. Pending work is not ready.

Native compound TB arc/BT no-corridor refusals, Trinity compound TB29 versus ELK13 crossings, controlled images, shared Sparse32 emitted-proof exhaustion at400k, Native TB/BT marker/halo loss, historical crossing276 and adverse distribution costs remain. The pending-stub shortcut, global port projection and Native label-gap prototype stay stopped/unshipped. No late routing-repair phase ships. Original2dad baseline/equivalent pinned Pele runtime remain unavailable; Replacement24 stays sealed. Adoption and retirement are deferred.
