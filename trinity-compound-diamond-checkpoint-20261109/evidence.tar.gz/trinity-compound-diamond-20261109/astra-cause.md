# Compound diamond: first contact owner and bounded admission

Reviewed `9ec32417a7a0fafa340b9bf05db1ae66e029fa42`, read-only; no probes/tests/builds/source edits. Read coordinator's retained contained and boundary admission-only trials.

**An internal-only compound slice is useful and structurally small. Full gate removal is falsified. A cardinal-terminal intervention can address the named boundary endpoint failure, but changing the ordinary terminal generator alone does not close the compound paint/contact contract.**

## Actual evidence

The retained contained fan is the existing three-labelled-edge decision wrapped in Stage. Before: Trinity4unsupported, Native4passed, ELK2passed/2group-containment refusals. Removing only the two diamond guards yields Trinity4returned/proof-passed. This supports feasibility; independent actual-ink/meaning qualification still belongs to final acceptance.

The boundary fan adds S→Q and R→E across Stage. Before, Native/ELK pass all4; broad admission gives Trinity3passed/1TB failure. TB specifically reports S→Q's target at `(249.9,202.5)` off the diamond outline, with inward/tangent approach. Preserve this failure; do not count the three other directions as broad correctness.

## Internal-only path: diamond data is already preserved

After the producer guard (`measured-graph-producer.ts:36`) and adapter guard (`trinity-compound.ts:27`):

- `agentic-compound-core.ts:81–88` strips leaf shape metadata for generic scope layout, but Trinity's callback rehydrates the original leaf at `trinity-compound.ts:32–35`, retaining contactDiamond, actual stroke, size policy and other contact metadata. It supplies the current projected dimensions.
- Local edges at `agentic-compound-core.ts:93–97` spread the original edge before changing endpoint indices. Thus sourceMarkerPresent/targetMarkerPresent, spans and labels survive. No new marker-translation repair is required for same-parent leaf edges. Missing facts must remain missing; never default them to false.
- Flat `trinity.ts:71–78,158–214,345–367` already budgets the joined-stroke envelope, applies fixed/minimum capacity, returns logical grown dimensions, and seats on the shared canonical facet owner. Scope context intentionally retains centered offsets, rather than root neighbor projection; it still uses facet seating.
- `measured-scopes.ts:18–24,31–40` builds parent frames around the actual local extent and preserves returned leaf dimensions. `agentic-compound-core.ts:106–111` translates fresh route/label points by the same scope offset. Local diamond miter support is inside that extent; it is not lost merely because the returned logical node excludes its outer paint envelope.
- With no lifted edges, no ancestor plan and no raw markerPaint, the existing branch `agentic-compound-core.ts:125–132` closes final route-pair contacts and returns. It never enters box terminal restoration or global marker seating. The final contact owner checks projected route pairs; it does not silently re-seat their endpoints.

Small useful admission: **every routed edge in a diamond-containing compound request joins two leaf nodes having the same immediate parent**, plus the existing raw-artwork, diamond-loop, marker-cardinality and scope limits. This permits nested independent scopes and their internal decisions. Do not merely require diamond-incident edges to be internal: an unrelated rectangle boundary edge sends the *whole* scene into global consumers which still treat foreign diamonds as boxes.

Validate malformed endpoints/parents as malformed, rather than turning them into capability refusals. Normalize omitted parent consistently with existing owner `-1`. The public preparation guard must operate before `measured-graph-producer.ts:248`, which currently indexes `nodes[source/target]!.id` while diamondContacts is true: a frame endpoint is outside that node array. Leaf-only admission avoids that hazard; broader support needs an explicit leaf bound there.

## Boundary path: first responsible stage

The first geometry producer that fails for the named S→Q is `compound-boundary-routes.ts:22–32`: it creates fractional box-face terminals. At `:789–790` these are used for lifted descendant endpoints. A point on the diamond's bounding-box top at x≠center is not on its sloping outline. Local Trinity facet output does not repair this because the descendant connection is reconstructed after quotient placement.

`restoreMeasuredEndpointFaces` (`:436–458`) is **not the cause of this ordinary failure**. Its caller `seatFinalMeasuredMarkers` runs only for raw markerPaint in this compound path (`:708–709,1241`), and `trinity-compound.ts:23` already rejects raw artwork. Ordinary canonical arrows are measured through endpoint spans/presence, not this raw-artwork field. The contained path avoids this routine entirely. Do not modify restoration merely to explain the reproduced failure.

## Cardinal-only boundary proposal: useful, but not sufficient alone

Canonical diamond cardinal points are also the extrema of its logical box. Generating those actual points from `shared/shape-routing-boundary.ts` can preserve current orthogonal outward tests, while avoiding arbitrary sloping-facet marker placement. It need not add a second router. Preserve fixed dimensions and original terminal/search budgets; duplicate fractional samples must not become extra capacity or new candidate allowances.

However, ordinary `terminals()` is not the only producer:

1. `compound-boundary-routes.ts:975–995` builds late terminals independently, with an occurrence fraction. A failed ordinary cardinal search can still fall back to an off-outline box terminal. It must use the same diamond-specific cardinal ownership or explicitly decline that late diamond domain.
2. `ancestor-boundary-routes.ts:146–156` also manufactures fractional box terminals, and `:193–197` checks rectangular outward faces. The smallest boundary slice should keep ancestor/frame endpoint cases unsupported unless that owner is deliberately covered. Public preparation must guard frame lookup as above.
3. Foreign-body obstacles need the diamond's measured joined-stroke envelope. Global node boxes at `compound-boundary-routes.ts:711–712,750` are logical dimensions inflated by generic clearance; they do not consume contactDiamond.strokeExtent. Cardinal endpoint selection cannot fix an unrelated route passing through the diamond's miter tip.

Concrete **static predicate counterexample**, not a reproduced public fixture: a200×100 canonical diamond with stroke8/default miter4 has a left-tip extension `4*sqrt(5)≈8.944`. A vertical shaft at `x_left−8.5` clears the current8px logical-box inflation yet intersects actual tip ink near the cardinal y. The miter ratio sqrt(5)<4, so this is not clipped away by the default limit. Existing contactDiamond.strokeExtent conservatively bounds it (16 here). The shared obstacle producer must consume that bound, including edge paint clearance; do not claim half-stroke is enough or substitute its envelope as the attachment outline.

A further useful negative is a diamond with an internal decision edge already occupying one cardinal escape plus an external marked incidence. The boundary generator must reject occupied physical rays or select another legal cardinal, rather than merge distinct authored occurrences. Existing incident-peer guards and final contact checks must stay authoritative. More than available cardinal capacity may legitimately decline; do not silently squeeze spans or grow only the shell.

If raw marker seating is expanded later, `restoreMeasuredEndpointFaces` must distinguish cardinal diamonds from internal facet contacts; `seatFinalMeasuredMarkers` uses half-stroke body envelopes and rectangular endpoint checks (`:481,508–515`). Those are separate contracts, presently excluded. Passing the ordinary cardinal boundary witness is not authorization to admit them.

## Ownership, cost and preservation

Keep original request data immutable. The current node-rest and edge-spread projections read/copy own enumerable values; do not turn inherited/missing marker facts into new proof authority or retain a cross-call contact cache. New admission/geometry work must be charged to the existing caller ledger; local solves already accumulate expansion under the same compound cap. Preserve actual grown dimensions through every parent scope and final family projection.

Native's measured diamond refusal now resides in `agentic-layered-core.ts:91–92`; ELK's is at `elk-measured-adapter.ts:13`. Preserve both and existing public legacy behavior. Scope changes should not modify ordinary Native/ELK geometry through unconditional shared obstacle or terminal changes; branch on the explicit measured diamond contact, not an authored id or guessed silhouette.

Recommended boundary for this turn: qualify the internal-only slice first, using the retained all4 contained products plus actual polygon contact, label/identity, miter/header containment and fixed/minimum growth checks. If pursuing the external cardinal slice, cover ordinary+late terminal owners, joined-stroke obstacle support and explicit ancestor exclusions together. The TB counterexample falsifies broader gate removal; the late-terminal and miter examples falsify a terminal-only claim. Stop on any new refusal, wrong endpoint/marker ink, lost authored meaning, size-policy violation or changed unaffected backend behavior. No speedup or general compound-diamond claim follows from this review.
