# Mermaid fidelity campaigns

These public-artifact campaigns collect meaning and painted-output evidence. They do not create an overall tool score or retime unrelated workloads. Old published result bundles have been removed. See [setup](../README.md) and [benchmark value judgments](../BENCHMARKS.md).

| Lane | Observable boundary | Main limits |
| --- | --- | --- |
| `mermaid-fidelity` | Actual public Node models and browser SVG for pinned Mermaid, Agentic and Pele; 70 authored cases plus 21 edits, across 25 families | Finite feature combinations; ambiguous native/paint projections stay unavailable. |
| `community-fidelity` | The same authored cases and actual Chromium paint checks on frozen prepared community SVG artifacts | No acquisition, old timing reruns or inferred native-model passes. Terminal/parser/editor tools retain their separate boundaries. |
| `upstream-original` | Genuine Mermaid 12.2.0 source core Vite/Vitest project, unchanged expectations and read-only snapshots | Excludes the docs-site and browser/e2e workspaces. Expanded callbacks are not individual assertions. |
| `upstream-fidelity` | Original source callbacks/expectations through reviewed actual public parser/models | Private helpers, imports, state and matchers are unavailable; diagnostic/representation mismatches do not automatically establish a drawing defect. |
| `fidelity/report.ts` | Read-only composition of recorded criteria, versions, shared authored/observer Git objects and actual browser identity | No new renderer calls or performance claims. Different case/observer contracts cannot compose. |

All policy-stable families are required. Event Modeling and ZenUML remain
conservatively required pending maturity-policy review; issues
[#501](https://github.com/adewale/agentic-mermaid/issues/501) and
[#502](https://github.com/adewale/agentic-mermaid/issues/502) retain missing-product
evidence. Optional/beta supplements retain their explicit required flags. The
first-party ZenUML reference addon is separately pinned to 1.0.1 and explicitly
registered in the browser; it does not make core Mermaid's Node parser expose
ZenUML models. Pele is uniformly 1.9.0. A set rejects mixed tool versions.

## Run and update

Install the private benchmark package as described in [the package guide](../README.md).
Provide real built artifacts, Chromium, matching pinned Mermaid source/reference,
and the genuine upstream test runner dependencies. Nothing is installed by the
fidelity collectors. Start by inspecting available suites:

```sh
bun commands.ts bench --projects OWNER/TOOL,... --profile full --rounds 5 \
  --suites fidelity,native-fidelity,upstream-fidelity,upstream-original --out /evidence/fidelity
```

The campaign prepares actual catalog artifacts and applies reviewed public
bindings. Other model projections remain unsupported; all prepared SVG projects
use the same painted observer. No Agentic source checkout is inferred.

## Read the evidence

A criterion plan is created before rendering. It includes every authored
identity, relationship, value and paint requirement. Missing results remain
blocked or unsupported. Reports reconstruct that plan even if producers omit
rows for every tool, and retain wholly missing admitted projects. They show
three dimensions separately: public SVG/API behavior, actual owned paint and
native models. Serializer-specific operations remain unranked capabilities.

The raw denominator and baseline-unqualified criteria are always visible.
Reference-qualified comparisons admit criteria pinned Mermaid actually passes;
reference failures require source/observer/product review. Their exclusion from
that scoped comparison does not erase them or establish that peers are correct.
A complete case requires every declared criterion, including unavailable ones.

Labels alone earn no topology/value credit. Independent model checks compare
identities, direction, multiplicity, parents, ordering and values. Actual SVG
checks observe owned shapes/routes/markers, relationship-label correspondence,
visibility, clipping, font-size changes, decoded images and supported chart
value geometry. Styles/gradients/masks without a reviewed projection remain
unavailable. PNGs and lossless community SVGs belong to retained attempts;
identical artifact aliases reference their real source experiment rather than
adding independent votes.

Public docs and tests are external workloads, not a hidden holdout. Dave's
full occurrence acceptance and common-success time remain valuable separate
measures. Security/configuration rejection, unavailable backend and drawing
fidelity need different columns. A generic runtime exception cannot earn a
negative-syntax pass. Original assertion wording and private DB shapes are
strict compatibility results, not automatic independent correctness findings.

Remaining scopes include full feature combinations, private upstream APIs,
browser/e2e source tests, complete custom paint/ownership, accessibility and
perceptual/typographic review. Memory/startup belong to the existing separate
resource protocols: document V8 heap is not whole-browser/native/GPU memory;
leak slopes, concurrency and deployed/provider dollar costs remain incomplete.
