# Independent payload dictionary review

Recorded 7 November 2026. Base source is
`930faf846c6bec55e1f9b053844700e08281faf6`, with a private build-time dictionary
specialization in progress. The reviewer made no production source changes.

## Exact already-executed falsification probe

`restoration-probe.executed.js` copies the exact JavaScript supplied to
`/tmp/pr449-tools-20261106/package/bin/bun -e` from repository working directory
`/tmp/pr449-main-integration-20261029-762`. Its two observed stdout records are in
`restoration-probe.stdout.jsonl`. The command exited 0. This archive was copied
from the session tool transcript without rerunning the probe.

This probe ran against the **Set-based predecessor**, preserved separately as
`../set-prototype.patch`. It is not represented as execution of the final
direct-buffer implementation. It packed two different Latin-transform/mixed
UTF-8 sources in A/B/A order, checked exact decoding and per-stream dictionaries,
and checked original CJS dictionary identity restoration after every pack. It
also injected a decoder exception through that isolated process's require cache;
the exception propagated and the original dictionary identity was restored.
These observed outputs passed. No timing ratio is inferred.

## Final implementation review and actual product identity

The final implementation replaces the Set/index roster with one fixed-length
Uint8Array. The proxy obtains each actual Reflect.get value, copies numeric-index
reads into that same index and returns that same value. Assignment, two full-output
comparisons and finally restoration retain the reviewed structure. This avoids
rereading a source table to populate the specialized dictionary. No actionable
code defect was found in the final read-only review. The earlier restoration
probe was not repeated after this implementation change.

The final generated init retains the 122,784-byte table length, calls
limitCodecOutput, uses the already-instrumented base64-js implementation and
passes through boundStandaloneCodec. Dictionary transforms, lengths/offsets,
worker CRC/length checks, budget/cancellation and Blob custody remain. Third-party
notices truthfully disclose the private dictionary modification. CRC remains
accidental-corruption detection, not authentication or a generic decoder API.

`artifact-identity-probe.executed.js` copies the separate already-executed
read-only Node inspection of the retained before/after HTML products. That
inspection exited 0; its exact output is in
`artifact-identity-probe.stdout.json`. It is artifact inspection, not a repeated
public renderer probe. Both products contain the exact same 1,100,017 packed bytes
and 4,699,169 decoded worker bytes. Both independent byte comparisons pass, and
the shipped byte SHA256 values are retained. Original complete HTML products
remain in the parent evidence directory.

## Value and remaining limits

The complete retained 930-before/current-after comparison records raw
2,091,362 -> 2,186,915 (+95,553), gzip9 1,348,449 -> 1,310,748 (-37,701), and
Brotli11 1,282,268 -> 1,245,137 (-37,131). The raw increase is a real retained
source-delivery cost; both measured compressed authorities improve. These are
matched product counts, not a runtime result. The existing original gzip ceiling
1,334,500 now passes locally by 23,752 bytes.

Inspected final evidence: BUILD-STATUS.json exit0/no timeout, 19.19 seconds and
674,760 KiB peak RSS; browser-owner.log 2 passes/504 assertions including original
payload budget and actual persistent Blob-worker operations; full-owners.log
46 passes; core-types-status.json exit0; lint evidence passes. Retained before
timing/resources and one after observation establish no speed or memory ratio.

This is a narrow build/delivery improvement with byte-exact worker behavior.
Main-relative Brotli still grows 146,733 bytes (about 13.36%); lazy/demo budgets,
Sparse32 and other enrolled gaps remain. No overall replacement, performance
parity, complete-suite or final-head readiness claim follows. Stopped six-pass
and raw representation experiments remain stopped.
