// Bounded adapter around existing layout-compare sample collection and public APIs.
import { mkdirSync, writeFileSync, existsSync, readFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
const [phase,id]=process.argv.slice(2),out='/tmp/pr449-week-comparison-20261101/requirement-png-review-499'
if(process.env.PR449_REQUIREMENT_PNG_GO!=='2'||!['before','after'].includes(phase)||id!=='requirement-citizenship')throw Error('Bounded exact sample/phase required')
const repo=phase==='before'?'/tmp/pr449-main-ci-base-f9ec8c115':'/tmp/pr449-main-integration-20261029-762',dir=out+'/'+phase+'/'+id.replaceAll('/','__')
if(existsSync(dir+'/RESULT.json.gz'))throw Error('Existing product retained; refusing overwrite')
mkdirSync(dir,{recursive:true})
const {parseRegisteredMermaid,layoutMermaidWithReceipt,renderMermaidSVGWithReceipt}=await import(repo+'/src/agent/index.ts')
const input={id,source:readFileSync(repo+'/eval/stable-families/fixtures/requirement.mmd','utf8')}
if(!input)throw Error('Exact collected sample missing')
const revision=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),options={style:'publication-figure',seed:17,security:'strict',embedFontImport:false}
writeFileSync(dir+'/source.mmd',input.source);writeFileSync(dir+'/options.json',JSON.stringify(options)+'\n')
const packet:any={phase,id,repo,revision,source:input.source,options,actualPublicSvgCalls:0,caseCosts:{},limits:'Source/default-options capture only; wall costs are isolated case observations, not a benchmark. No raster/actual glyph-ink claim.'}
const save=(name:string,value:unknown)=>writeFileSync(dir+'/'+name+'.json.gz',gzipSync(JSON.stringify(value)))
try{packet.parsed=parseRegisteredMermaid(input.source);save('parsed',packet.parsed)}catch(error:any){packet.parseError={name:error.name,message:error.message,stack:error.stack}}
let start=performance.now()
try{packet.layout=layoutMermaidWithReceipt(input.source,options);save('layout',packet.layout)}catch(error:any){packet.layoutError={name:error.name,message:error.message,stack:error.stack,certification:error.certification}}
packet.caseCosts.layoutMs=performance.now()-start
start=performance.now();packet.actualPublicSvgCalls=1
try{const product=renderMermaidSVGWithReceipt(input.source,options);packet.svgStatus='returned';packet.receipt=product.receipt;writeFileSync(dir+'/actual.svg.gz',gzipSync(product.svg));save('receipt',product.receipt);packet.svgBytes=Buffer.byteLength(product.svg)}catch(error:any){packet.svgStatus='refused';packet.svgError={name:error.name,message:error.message,stack:error.stack,certification:error.certification};save('svg-error',packet.svgError)}
packet.caseCosts.svgMs=performance.now()-start
save('RESULT',packet)
console.log(JSON.stringify({phase,id,revision,status:packet.svgStatus,proof:packet.receipt?.layoutCertification?.status,operations:packet.receipt?.layoutCertification?.checks?.operations,caseCosts:packet.caseCosts,svgError:packet.svgError?.message,layoutError:packet.layoutError?.message,dir}))
