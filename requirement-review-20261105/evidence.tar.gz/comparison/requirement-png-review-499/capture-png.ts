// Exact owning citizenship PNG API and existing decoder; two retained products only.
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
const phase=process.argv[2],out='/tmp/pr449-week-comparison-20261101/requirement-png-review-499'
if(!['before','after'].includes(phase))throw Error('Exact before/after phase required')
const repo=phase==='before'?'/tmp/pr449-main-ci-base-f9ec8c115':'/tmp/pr449-main-integration-20261029-762',file=out+'/'+phase+'.actual.png'
if(existsSync(file))throw Error('Preserve previous actual PNG; do not replay')
const {renderMermaidPNG}=await import(repo+'/src/agent/png.ts'),{decodePng}=await import(repo+'/src/__tests__/helpers/png-pixels.ts')
const source=readFileSync(repo+'/eval/stable-families/fixtures/requirement.mmd','utf8'),options={style:'publication-figure',seed:17,security:'strict',embedFontImport:false,scale:1} as const
const start=performance.now(),cpu=process.cpuUsage(),png=renderMermaidPNG(source,options),wallMs=performance.now()-start,cpuUs=process.cpuUsage(cpu)
writeFileSync(file,png)
const actual=decodePng(png),golden=decodePng(readFileSync(repo+'/src/__tests__/testdata/stable-families/requirement.png'))
const report={phase,revision:execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),source,options,width:actual.width,height:actual.height,goldenWidth:golden.width,goldenHeight:golden.height,goldenDimensionsExact:actual.width===golden.width&&actual.height===golden.height,goldenRGBAExact:Buffer.from(actual.rgba).equals(golden.rgba),pngBytes:png.length,wallMs,cpuUs,scope:'Owning API exact options, scale1, bundled verified fonts; case timing only, not performance study.'}
writeFileSync(out+'/'+phase+'.png-result.json',JSON.stringify(report,null,2)+'\n');writeFileSync(out+'/'+phase+'.rgba.gz',gzipSync(actual.rgba));console.log(JSON.stringify(report))
if(phase==='before'&&(!report.goldenDimensionsExact||!report.goldenRGBAExact))process.exitCode=2
