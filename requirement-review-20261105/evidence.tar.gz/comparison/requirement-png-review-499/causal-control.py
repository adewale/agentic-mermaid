from pathlib import Path
import subprocess,os,json,difflib,hashlib,time
p=Path('/tmp/pr449-week-comparison-20261101/requirement-png-review-499');source=Path('/tmp/pr449-main-integration-20261029-762/src/requirement/layout.ts');before=source.read_bytes();text=before.decode();old="'elk.spacing.edgeNode': String(elkTerminalLead),\n        'elk.layered.spacing.edgeNodeBetweenLayers': String(elkTerminalLead),";new="'elk.spacing.edgeNode': String(terminalLead),\n        'elk.layered.spacing.edgeNodeBetweenLayers': String(terminalLead),"
assert text.count(old)==1
candidate=text.replace(old,new).encode();(p/'layout.before.ts').write_bytes(before);(p/'layout.causal.ts').write_bytes(candidate);(p/'causal.patch').write_text(''.join(difflib.unified_diff(text.splitlines(True),candidate.decode().splitlines(True),fromfile='layout.before.ts',tofile='layout.causal.ts')))
s=(p/'capture.ts').read_text().replace("!['before','after'].includes(phase)","!['before','after','causal'].includes(phase)");(p/'causal-capture.ts').write_text(s)
status={'sourcePath':str(source),'beforeSHA256':hashlib.sha256(before).hexdigest(),'causalSHA256':hashlib.sha256(candidate).hexdigest(),'actualSvgCallLimit':1,'restoredByteExact':False,'controlledDifference':'Only the two ELK spacing fields use existing terminalLead instead of max with contains-start terminal; authored source/options unchanged.'}
try:
 source.write_bytes(candidate)
 with (p/'causal.log').open('w')as out,(p/'causal.stderr').open('w')as err:
  result=subprocess.run(['/tmp/pr449-campaign-bin/bun',str(p/'causal-capture.ts'),'causal','requirement-citizenship'],env={**os.environ,'PR449_REQUIREMENT_PNG_GO':'2'},stdout=out,stderr=err,timeout=60)
 status['exitCode']=result.returncode
except BaseException as e:status['exception']=repr(e);raise
finally:
 source.write_bytes(before);status['restoredByteExact']=source.read_bytes()==before;(p/'CAUSAL-CONTROL-STATUS.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
