import { ROLE_STYLE_PROPERTY_DESCRIPTORS, validateStyleSpec, styleSpecJsonSchema } from '../schema-runtime-20261112/src/scene/style-registry.ts'
const number=ROLE_STYLE_PROPERTY_DESCRIPTORS.fontSize,values=ROLE_STYLE_PROPERTY_DESCRIPTORS.textTransform.values,minimum=number.minimum,length=values.length
let result:unknown
try {
 const boundsChanged=Reflect.set(number,'minimum',0),enumChanged=Reflect.set(values,String(length),'injected')
 const projected=styleSpecJsonSchema()as any
 result={boundsChanged,enumChanged,rangeProblems:validateStyleSpec({roles:{node:{fontSize:0}}}),enumProblems:validateStyleSpec({roles:{node:{textTransform:'injected'}}}),schemaMinimum:projected.$defs['roleStyle-node'].properties.fontSize.minimum,schemaEnum:projected.$defs['roleStyle-node'].properties.textTransform.enum}
}finally{Reflect.set(number,'minimum',minimum);Reflect.set(values,'length',length)}
console.log(JSON.stringify(result))
