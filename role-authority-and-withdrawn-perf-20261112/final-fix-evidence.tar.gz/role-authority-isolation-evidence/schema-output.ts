import { readFileSync } from 'node:fs'
import { styleSpecJsonSchema } from '../schema-runtime-20261112/src/scene/style-registry.ts'
const expected = JSON.stringify(JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/schema-runtime-20261112/docs/schemas/style-spec.schema.json','utf8')))
const actual = JSON.stringify(styleSpecJsonSchema())
console.log(JSON.stringify({actualBytes:Buffer.byteLength(actual),expectedBytes:Buffer.byteLength(expected),exactIncludingOrder:actual===expected}))
if(actual!==expected)process.exitCode=1
