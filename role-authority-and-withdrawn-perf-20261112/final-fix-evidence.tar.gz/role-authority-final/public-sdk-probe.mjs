import {writeFileSync} from 'node:fs';
const roots={control:'/dev/shm/pr449-four-final-20261111/state-minimal-node',candidate:'/dev/shm/pr449-four-final-20261111/role-authority-qualified'},rows=[];
for(const[target,root]of Object.entries(roots)){
 const api=await import(root+'/dist/index.js'),number=api.ROLE_STYLE_PROPERTY_DESCRIPTORS.fontSize,values=api.ROLE_STYLE_PROPERTY_DESCRIPTORS.textTransform.values,minimum=number.minimum,length=values.length;
 try{const boundsChanged=Reflect.set(number,'minimum',0),enumChanged=Reflect.set(values,String(length),'injected'),schema=api.styleSpecJsonSchema();rows.push({target,boundsChanged,enumChanged,rangeProblems:api.validateStyleSpec({roles:{node:{fontSize:0}}}),enumProblems:api.validateStyleSpec({roles:{node:{textTransform:'injected'}}}),schemaMinimum:schema.$defs['roleStyle-node'].properties.fontSize.minimum,schemaEnum:schema.$defs['roleStyle-node'].properties.textTransform.enum})}
 finally{Reflect.set(number,'minimum',minimum);Reflect.set(values,'length',length)}
}
writeFileSync(new URL('PUBLIC-SDK-REGRESSION.json',import.meta.url),JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows));
