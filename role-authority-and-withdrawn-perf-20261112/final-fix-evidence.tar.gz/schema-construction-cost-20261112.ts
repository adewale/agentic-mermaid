import { execFileSync } from 'node:child_process'
import { readFileSync, writeFileSync } from 'node:fs'
import ts from '/tmp/pr449-main-integration-20261029-762/node_modules/typescript/lib/typescript.js'
import { SCENE_ROLE_DESCRIPTORS } from './schema-runtime-20261112/src/scene/roles.ts'
import { ROLE_STYLE_PROPERTY_DESCRIPTORS } from './schema-runtime-20261112/src/scene/role-style-contract.ts'
import { styleSpecJsonSchema } from './schema-runtime-20261112/src/scene/style-spec.ts'
const root='/dev/shm/pr449-four-final-20261111/schema-runtime-20261112'
const before=execFileSync('git',['show','HEAD:src/scene/style-spec.ts'],{cwd:root,encoding:'utf8'})
const after=readFileSync(root+'/src/scene/style-spec.ts','utf8')
function owner(source:string) {
 const ast=ts.createSourceFile('style-spec.ts',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS)
 const fns=ast.statements.filter((s:any)=>ts.isFunctionDeclaration(s)&&['rolePropertyJsonSchemas','roleStyleJsonSchema'].includes(s.name?.text))
 const compiled=ts.transpile(fns.map((s:any)=>s.getText(ast)).join('\n'),{target:ts.ScriptTarget.ES2022})
 let accesses=0, kinds=0
 const descriptors=Object.fromEntries(Object.entries(ROLE_STYLE_PROPERTY_DESCRIPTORS).map(([key,value])=>[key,new Proxy(value,{get(t,k){accesses++;if(k==='kind')kinds++;return Reflect.get(t,k)}})]))
 const run=Function('ROLE_STYLE_PROPERTY_DESCRIPTORS',compiled+'\nreturn roleStyleJsonSchema;')(descriptors)
 const defs=SCENE_ROLE_DESCRIPTORS.filter(d=>d.traits.styleConsumption!=='fallback-only').map(d=>run(d.style.applicableProperties))
 defs.push(run())
 return {defs,accesses,kinds}
}
const old=owner(before), next=owner(after)
if(JSON.stringify(old.defs)!==JSON.stringify(next.defs))throw Error('role projection differs')
const publicSchema=styleSpecJsonSchema() as any
const result={source:'9644bce7e + local 7-line role projection subtraction',roles:old.defs.length,before:{propertySchemas:old.defs.length*Object.keys(ROLE_STYLE_PROPERTY_DESCRIPTORS).length,kindReads:old.kinds,descriptorReads:old.accesses},after:{propertySchemas:next.defs.reduce((n,d)=>n+Object.keys(d.properties).length,0),kindReads:next.kinds,descriptorReads:next.accesses},equalRoleSchemas:true,publicJsonBytes:JSON.stringify(publicSchema).length}
writeFileSync('/dev/shm/pr449-four-final-20261111/schema-construction-cost-20261112.json',JSON.stringify(result,null,2)+'\n')
console.log(result)
