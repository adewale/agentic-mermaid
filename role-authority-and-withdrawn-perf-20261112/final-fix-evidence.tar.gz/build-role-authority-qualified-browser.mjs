import { build } from '/tmp/pr449-main-integration-20261029-762/node_modules/tsup/dist/index.js'
import config from '/dev/shm/pr449-four-final-20261111/role-authority-qualified/tsup.browser-lazy.config.ts'
await build({ ...config, dts: false, config: false })
