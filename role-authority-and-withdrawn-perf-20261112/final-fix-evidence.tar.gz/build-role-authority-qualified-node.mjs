import {build} from '/tmp/pr449-main-integration-20261029-762/node_modules/tsup/dist/index.js';
import cfg from '/dev/shm/pr449-four-final-20261111/role-authority-qualified/tsup.config.ts';
const entries=['index','agent-core','elk-constructor','builtin-font-metrics','builtin-font-metrics.node','layout-optimization','layout-optimization.node'];
await build({...cfg,entry:Object.fromEntries(entries.map(k=>[k,cfg.entry[k]])),dts:false,sourcemap:true,config:false});
