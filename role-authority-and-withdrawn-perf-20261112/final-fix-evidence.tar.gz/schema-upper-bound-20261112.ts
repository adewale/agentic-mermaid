import { readFileSync } from 'node:fs'
import { gzipSync, brotliCompressSync } from 'node:zlib'
import { build } from '/tmp/pr449-main-integration-20261029-762/node_modules/esbuild/lib/main.js'
const root = '/dev/shm/pr449-four-final-20261111/schema-runtime-20261112'
const m = JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/payload-state-minimal-candidate/dist/metafile-esm.json','utf8'))
for (const n of ['src/shared/schema-validation.ts', 'src/render-option-contract.ts', 'src/scene/style-spec.ts', 'src/render-style-option-schema.ts']) {
 const built = await build({entryPoints:[root+'/'+n],bundle:false,write:false,format:'esm',target:'es2022',minify:true})
 const b=built.outputFiles[0].contents
 console.log(JSON.stringify({name:n, emittedContribution:Object.values(m.outputs).reduce((a:any,o:any)=>a+(o.inputs?.[n]?.bytesInOutput||0),0), isolatedRaw:b.length,isolatedGzip:gzipSync(b,{level:9}).length,isolatedBr:brotliCompressSync(b).length}))
}
