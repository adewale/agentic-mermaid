# Matched Native100 stock SVG profile

Control `9644bce7edd0cd9706bb5dbfc30a89d8d2feb643`: `state-minimal-node`. Candidate `313a142bf3f02632f0461273f4c8c975c685cf94`: `classification-schema-final`. One fresh sequential Node worker per arm, 200us V8 sampling, cache0, one cold warmup outside profiling and ten fully consumed same-source calls. No concurrent CPU workers or browsers were started. Both worker jobs exited0 and are closed.

The worker calls only `renderMermaidSVG` and consumes `Buffer.byteLength(svg)`. It never accesses or constructs a receipt or makes an extra certification/observer call. SVG retention/compression and explicit GC run outside API/profiler windows.

These are sampled elapsed weights, including instrumentation. They are not stock latency, CPU time, a causal ratio or a predicted speedup. Inclusive ancestors overlap and must not be added. There is one process per arm; neither stable all-process performance nor the responsible source edit is established.

| Source frame | Control self / inclusive ms per call | Candidate self / inclusive ms per call |
|---|---:|---:|
| copyInner (`src/scene/native-paint-emission.ts:228→228`) | 14.732 / 19.469 | 14.534 / 20.867 |
| copy (`src/scene/native-paint-emission.ts:410→407`) | 4.838 / 20.630 | 6.730 / 22.073 |
| assessLayoutGeometry (`src/layout-rubric.ts:496→496`) | 5.889 / 11.393 | 7.179 / 14.853 |
| measureRubricMetrics (`src/layout-rubric.ts:656→656`) | 3.378 / 17.690 | 4.790 / 23.230 |
| validateNode (`src/scene/scene-validation-core.ts:783→783`) | 4.158 / 11.370 | 4.518 / 13.425 |
| capture leaf (`src/scene/native-paint-emission.ts:833→835`) | 1.758 / 49.368 | 2.434 / 56.381 |
| scene validation write (`src/scene/scene-validation-core.ts:1527→1527`) | 1.645 / 27.983 | 2.488 / 32.028 |

Garbage collector self: 6.118→4.224ms per call. Inspector `post` self: 41.969→43.550ms per call, reported separately.

| Instrumented boundary | Control | Candidate |
|---|---:|---:|
| Import ms | 270.732 | 306.546 |
| First unprofiled cold render ms | 357.744 | 408.925 |
| Median profiled warm call wall ms | 186.416 | 201.442 |
| Sum ten profiled call wall ms | 1888.231 | 2123.485 |
| Total sampled elapsed weight ms, including inspector | 2306.745 | 2560.205 |
| Samples | 5405 | 5992 |

The actual failing API boundary is slower in this profiled pair as well. The layout rubric frames grow in both self and inclusive sampled elapsed; `copy` grows, while `copyInner` self is nearly unchanged and GC falls. Thus this pair does not support blaming increased GC or a demonstrated reduction in copy work. It locates increased elapsed in the existing rubric/pipeline and capture work, but cannot assign that increase causally to the classification or schema edit. Those unchanged rubric functions and the one-process sample bound prevent a stronger attribution.

All11 retained whole SVG products are byte-exact between arms. No receipt was read for this comparison. The earlier unprofiled adverse stock/full results remain authoritative for value; this profile does not replace them.

Every mapped generated artifact matched its retained final-qualification SHA256. Each mapped source was bound to the actual emitted map and its embedded sourceContent, whose bytes matched the corresponding source on disk. `SUMMARY.json` retains all global/generated rankings, mapped sources, per-call rows, actual artifact/source hashes, and every sampled delta≥5ms without exclusions. `IDENTITY.json`, both job JSON files, worker source, logs, raw `.cpuprofile.gz`, SVGs and closed-job record are beside this report.

No production source edits, additional variants, further profiling jobs or unprofiled retiming were performed.
