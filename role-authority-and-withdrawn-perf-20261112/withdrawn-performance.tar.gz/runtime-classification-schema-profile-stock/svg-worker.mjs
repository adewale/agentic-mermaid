import fs from 'node:fs';
import inspector from 'node:inspector';
import {promisify} from 'node:util';
import {pathToFileURL} from 'node:url';
import {gzipSync} from 'node:zlib';
const out=process.argv[2],job=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
fs.mkdirSync(out,{recursive:true});
const gz=(name,value)=>fs.writeFileSync(out+'/'+name+'.gz',gzipSync(typeof value==='string'?value:JSON.stringify(value)));
const importStart=performance.now(),api=await import(pathToFileURL(job.root+'/dist/index.js')),importMs=performance.now()-importStart;
const session=new inspector.Session();session.connect();const post=promisify(session.post).bind(session);
await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:200});
function consume(){const svg=api.renderMermaidSVG(job.source,job.options);const bytes=Buffer.byteLength(svg);return{svg,bytes};}
const rows=[];
const coldBefore=process.memoryUsage(),coldStart=performance.now(),coldCPU=process.cpuUsage();let warmup,coldFailure;
try{warmup=consume();}catch(e){coldFailure={name:e.name,message:e.message,stack:e.stack};}
const coldWallMs=performance.now()-coldStart,coldUsed=process.cpuUsage(coldCPU),coldAfter=process.memoryUsage();
const coldRow={phase:'cold-render',status:warmup?'returned':'error',wallMs:coldWallMs,cpuMs:(coldUsed.user+coldUsed.system)/1000,before:coldBefore,after:coldAfter,peakRssKiB:process.resourceUsage().maxRSS,bytes:warmup?.bytes,failure:coldFailure};
rows.push(coldRow);gz('cold-render.row.json',coldRow);if(warmup)gz('warmup.svg',warmup.svg);else gz('warmup-error.json',coldFailure);
for(let index=1;index<=10;index++){
 const phase='repeat'+index;global.gc?.();const before=process.memoryUsage();await post('Profiler.start');const start=performance.now(),cpu=process.cpuUsage();let product,failure;
 try{product=consume();}catch(e){failure={name:e.name,message:e.message,stack:e.stack};}
 const wallMs=performance.now()-start,cpuTime=process.cpuUsage(cpu),after=process.memoryUsage();const {profile}=await post('Profiler.stop');
 gz(phase+'.cpuprofile',profile);if(product)gz(phase+'.svg',product.svg);
 const row={phase,status:product?'returned':'error',wallMs,cpuMs:(cpuTime.user+cpuTime.system)/1000,before,after,peakRssKiB:process.resourceUsage().maxRSS,bytes:product?.bytes,wholeSvgExactWarmup:product&&warmup?product.svg===warmup.svg:undefined,failure,profileStart:profile.startTime,profileEnd:profile.endTime,samples:profile.samples?.length};
 rows.push(row);gz(phase+'.row.json',row);console.log(JSON.stringify({case:job.case,backend:job.backend,phase,status:row.status,wallMs,cpuMs:row.cpuMs,samples:row.samples}));
}
gz('RESULT.json',{runtime:process.version,importMs,job,cache:process.env.AGENTIC_MERMAID_ELK_CACHE,samplingIntervalUs:200,scope:'Actual built stock renderMermaidSVG only, SVG consumed by Buffer.byteLength. No receipt construction/access, observers or certification call in worker. One unprofiled cold warmup and ten profiled same-source calls; module import separate. Per-call explicit GC and retained SVG gzip outside API/profiler windows.',rows});session.disconnect();
