import {readFileSync,writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
process.env.AGENTIC_MERMAID_ELK_CACHE='0';process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS='0';
const roots={control:'/dev/shm/pr449-four-final-20261111/state-minimal-node',candidate:'/dev/shm/pr449-four-final-20261111/classification-schema-final'};
const api=Object.fromEntries(await Promise.all(Object.entries(roots).map(async([key,root])=>[key,await import(root+'/dist/index.js')])));
const cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/shared-four-fixes-20261111/task1/inplace-closure-ceiling/capacity/EXISTING-CASES.json','utf8'));const rows=[];
for(const c of cases)for(const backend of ['agentic','elk']){
 const products={};for(const target of Object.keys(roots)){
  try{products[target]=api[target].renderMermaidSVGWithReceipt(c.source,{graphLayout:{backend,fallback:'none'}});writeFileSync(new URL(`capacity-${c.name}-${backend}-${target}.json.gz`,import.meta.url),gzipSync(JSON.stringify(products[target])))}catch(e){products[target]={error:String(e),code:e.code}}
 }
 const a=products.control,b=products.candidate;const row={name:c.name,backend,entireProductExact:JSON.stringify(a)===JSON.stringify(b),before:a.receipt?.layoutCertification??a,after:b.receipt?.layoutCertification??b};rows.push(row);console.log(JSON.stringify({name:c.name,backend,entireProductExact:row.entireProductExact,before:row.before.status,after:row.after.status,operations:row.after.checks?.operations}));
}
writeFileSync(new URL('CAPACITY-CURRENT.json',import.meta.url),JSON.stringify(rows,null,2)+'\n');
