# Matched Native100 full response profile

Control `9644bce7edd0cd9706bb5dbfc30a89d8d2feb643`: `state-minimal-node`. Candidate `313a142bf3f02632f0461273f4c8c975c685cf94`: `classification-schema-final`. One fresh sequential Node worker per arm, 200us V8 sampling, cache0, one cold warmup outside profiling and ten fully consumed same-source calls. No concurrent CPU workers or browsers were started. Both worker jobs exited0 and are closed.

The existing `runtime-main913-profile/receipt-worker.mjs` is copied byte-exact. It calls `renderMermaidSVGWithReceipt`, consumes the SVG and serializes the entire product once inside the API clock. Its later retained-receipt JSON encoding remains inside the sampled interval but outside the API clock, exactly as in that existing worker. This full-response profile cannot diagnose the stock-SVG loss.

These are sampled elapsed weights, including instrumentation. They are not stock latency, CPU time, a causal ratio or a predicted speedup. Inclusive ancestors overlap and must not be added. There is one process per arm; neither stable all-process performance nor the responsible source edit is established.

| Source frame | Control self / inclusive ms per call | Candidate self / inclusive ms per call |
|---|---:|---:|
| copyInner (`src/scene/native-paint-emission.ts:228→228`) | 24.974 / 31.831 | 19.998 / 26.091 |
| copy (`src/scene/native-paint-emission.ts:410→407`) | 7.213 / 33.846 | 7.093 / 27.500 |
| assessLayoutGeometry (`src/layout-rubric.ts:496→496`) | 8.504 / 19.001 | 6.782 / 16.729 |
| measureRubricMetrics (`src/layout-rubric.ts:656→656`) | 7.350 / 28.772 | 6.001 / 26.311 |
| validateNode (`src/scene/scene-validation-core.ts:783→783`) | 7.361 / 20.703 | 8.673 / 21.265 |
| capture leaf (`src/scene/native-paint-emission.ts:833→835`) | 2.786 / 86.488 | 9.684 / 97.206 |
| scene validation write (`src/scene/scene-validation-core.ts:1527→1527`) | 3.064 / 50.436 | 3.946 / 59.093 |

Garbage collector self: 7.812→6.541ms per call. Inspector `post` self: 69.342→65.481ms per call, reported separately.

| Instrumented boundary | Control | Candidate |
|---|---:|---:|
| Import ms | 459.648 | 393.346 |
| First unprofiled cold render ms | 853.953 | 642.352 |
| Median profiled warm call wall ms | 297.998 | 292.109 |
| Sum ten profiled call wall ms | 2968.830 | 2983.333 |
| Total sampled elapsed weight ms, including inspector | 3667.805 | 3636.445 |
| Samples | 7400 | 7036 |

Copy and rubric sampled weights fall in this full-response pair, and GC falls. Candidate repeat1 contains individual80.219ms and69.972ms sampled deltas attributed to the SVG number formatter and capture leaf respectively; both remain in the total and raw profiles. These isolated elapsed deltas cannot be represented as stable CPU costs or a stock-SVG diagnosis.

All11 whole SVG and entire receipt products are byte-exact between arms. Final proof remains passed at238786 operations; this is retained receipt evidence, not a stock-worker certification call.

Every mapped generated artifact matched its retained final-qualification SHA256. Each mapped source was bound to the actual emitted map and its embedded sourceContent, whose bytes matched the corresponding source on disk. `SUMMARY.json` retains all global/generated rankings, mapped sources, per-call rows, actual artifact/source hashes, and every sampled delta≥5ms without exclusions. `IDENTITY.json`, both job JSON files, worker source, logs, raw `.cpuprofile.gz`, SVGs and closed-job record are beside this report.

No production source edits, additional variants, further profiling jobs or unprofiled retiming were performed.
