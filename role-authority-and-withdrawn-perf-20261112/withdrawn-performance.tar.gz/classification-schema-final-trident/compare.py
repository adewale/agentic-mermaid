from pathlib import Path
import gzip,json,copy,re
r=Path(__file__).parent
read=lambda p:json.loads(gzip.decompress(p.read_bytes()))
out={'control':'9644bce7edd0cd9706bb5dbfc30a89d8d2feb643','candidate':'313a142bf3f02632f0461273f4c8c975c685cf94'}
for lane,path in [('portable','PILOT.json.gz'),('authored','fidelity/RESULTS.json.gz')]:
 rows=read(r/path);pairs={}
 for row in rows:pairs.setdefault((row['id'],row['backend']),{})[row['target']]=row
 s={'pairs':len(pairs),'returnedPairs':0,'sameErrors':0,'svgExact':0,'noncertExact':0,'entireReceiptExact':0,'meaningInkQualityExact':0,'mismatches':[]}
 for key,p in pairs.items():
  x,y=p['control'],p['candidate'];a=x if lane=='portable' else x['rendered'];b=y if lane=='portable' else y['rendered'];yes=a['delivery']=='returned' if lane=='portable' else a['accepted'];yes2=b['delivery']=='returned' if lane=='portable' else b['accepted']
  if yes!=yes2:s['mismatches'].append([key,'delivery']);continue
  if not yes:
   if {k:v for k,v in a.items() if k!='target'}=={k:v for k,v in b.items() if k!='target'}:s['sameErrors']+=1
   else:s['mismatches'].append([key,'error'])
   continue
  s['returnedPairs']+=1
  if lane=='portable':
   stem=key[1]+'-'+re.sub('[^a-z0-9_.-]','_',key[0],flags=re.I)
   svgx=gzip.decompress((r/'pilot'/('control-'+stem+'.svg.gz')).read_bytes());svgy=gzip.decompress((r/'pilot'/('candidate-'+stem+'.svg.gz')).read_bytes());a=read(r/'pilot'/('control-'+stem+'.receipt.json.gz'));b=read(r/'pilot'/('candidate-'+stem+'.receipt.json.gz'))
   if x['qualification']!=y['qualification']:s['mismatches'].append([key,'qualification'])
  else:
   svgx=a['svg'];svgy=b['svg'];a=a['receipt'];b=b['receipt']
   if all(x.get(k)==y.get(k) for k in ['preludes','acquired','meaning','paint','quantitative','quality','expectationDepth']):s['meaningInkQualityExact']+=1
   else:s['mismatches'].append([key,'meaningInkQuality'])
  if svgx==svgy:s['svgExact']+=1
  else:s['mismatches'].append([key,'svg'])
  ax=copy.deepcopy(a);by=copy.deepcopy(b);ax.pop('layoutCertification',None);by.pop('layoutCertification',None)
  if ax==by:s['noncertExact']+=1
  else:s['mismatches'].append([key,'noncert'])
  if a==b:s['entireReceiptExact']+=1
  else:s['mismatches'].append([key,'entireReceipt'])
 out[lane]=s
out['browserClosed']=json.loads((r/'fidelity/CLOSED.json').read_text());(r/'COMPARISON.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
