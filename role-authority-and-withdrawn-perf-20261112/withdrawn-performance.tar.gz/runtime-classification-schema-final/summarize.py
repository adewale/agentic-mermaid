from pathlib import Path
import json,gzip,statistics,math,sys
backend=sys.argv[1]
r=Path(__file__).parent
read=lambda p:json.loads(gzip.decompress(p.read_bytes()))
p95=lambda xs:sorted(xs)[math.ceil(.95*len(xs))-1]
report={'base':'9644bce7edd0cd9706bb5dbfc30a89d8d2feb643','candidate':'313a142bf3f02632f0461273f4c8c975c685cf94','backend':backend,'workers':12,'errors':0,'full':{},'svg':{},'products':{'pairs':0,'svgExact':0,'noncertExact':0,'proofExceptOperationsExact':0,'mismatches':[]}}
for target in ['control','candidate']:
 values=[read(p)for p in sorted((r/'receipt-performance').glob('cache0-'+target+'-'+backend+'-*/RESULT.json.gz'))];arm={}
 for name,phases in [('repeat',['repeat1','repeat2','repeat3','repeat4']),('cold',['cold-render']),('firstEdit',['edit1']),('repeatedEdit',['edit2','edit3','edit4'])]:
  groups=[[x['wallMs']for x in v['rows']if x['phase']in phases]for v in values];arm[name]={'processMediansMs':[statistics.median(x)for x in groups],'medianMs':statistics.median([statistics.median(x)for x in groups]),'pooledP95Ms':p95(sum(groups,[])),'rawMs':groups}
 arm['importMs']=[v['importMs']for v in values];arm['rssPeakMiB']=[max(x['peakRssKiB']for x in v['rows'])/1024 for v in values];arm['heapAfterPeakMiB']=[max(x['after']['heapUsed']for x in v['rows'])/1048576 for v in values];report['full'][target]=arm
 values=[json.loads(p.read_text())for p in sorted((r/'performance/results').glob('cache0-'+target+'-'+backend+'-*.json'))];arm={}
 for name in ['warm-repeat','warm-new-source','warm-label-edit']:
  groups=[v['tracks'][name]for v in values];flat=sum(groups,[]);arm[name]={'processMediansMs':[statistics.median(x)for x in groups],'medianMs':statistics.median([statistics.median(x)for x in groups]),'pooledMedianMs':statistics.median(flat),'pooledP95Ms':p95(flat),'rawMs':groups}
 report['svg'][target]=arm
for replica in [0,1,2]:
 a=r/'receipt-performance'/f'cache0-control-{backend}-diagnostic_chain100-{replica}';b=r/'receipt-performance'/f'cache0-candidate-{backend}-diagnostic_chain100-{replica}'
 for phase in ['warmup','repeat1','repeat2','repeat3','repeat4','edit1','edit2','edit3','edit4']:
  q=report['products'];q['pairs']+=1
  if gzip.decompress((a/(phase+'.svg.gz')).read_bytes())==gzip.decompress((b/(phase+'.svg.gz')).read_bytes()):q['svgExact']+=1
  else:q['mismatches'].append([replica,phase,'svg'])
  x=read(a/(phase+'.receipt.json.gz'));y=read(b/(phase+'.receipt.json.gz'));cx=x.pop('layoutCertification');cy=y.pop('layoutCertification')
  if x==y:q['noncertExact']+=1
  else:q['mismatches'].append([replica,phase,'noncert'])
  cx.get('checks',{}).pop('operations',None);cy.get('checks',{}).pop('operations',None)
  if cx==cy:q['proofExceptOperationsExact']+=1
  else:q['mismatches'].append([replica,phase,'proof'])
report['observedThreeSVGMediansBelow100ms']=all(x<100 for x in report['svg']['candidate']['warm-repeat']['processMediansMs'])
(r/('SUMMARY-'+backend+'.json')).write_text(json.dumps(report,indent=2)+'\n')
for target in ['control','candidate']:
 print(target,json.dumps({'full':{k:v['medianMs']for k,v in report['full'][target].items()if isinstance(v,dict)},'rssPeakMedianMiB':statistics.median(report['full'][target]['rssPeakMiB']),'heapAfterPeakMedianMiB':statistics.median(report['full'][target]['heapAfterPeakMiB']),'svg':{k:{x:y for x,y in v.items()if x!='rawMs'}for k,v in report['svg'][target].items()}}))
print('products',report['products'],'observedThreeSVGMediansBelow100ms',report['observedThreeSVGMediansBelow100ms'])
