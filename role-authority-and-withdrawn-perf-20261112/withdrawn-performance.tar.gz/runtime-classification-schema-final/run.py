from pathlib import Path
import subprocess,os,json
r=Path(__file__).parent;env=os.environ.copy();env['PATH']='/tmp/pr449-tools-20261106/package/bin:'+env['PATH'];env['TMPDIR']='/dev/shm/pr449-four-final-20261111/tmp'
for name,log in [('svg-performance.ts','SVG.log'),('receipt-performance.ts','RECEIPT.log')]:
 with (r/log).open('w') as out:
  q=subprocess.run(['/tmp/pr449-tools-20261106/package/bin/bun',name],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
 assert q.returncode==0,(name,q.returncode)
 print(name,'CLOSED',flush=True)
for n in ['PERFORMANCE-COMPLETED.json','RECEIPT-PERFORMANCE-COMPLETED.json']:print((r/n).read_text(),flush=True)
