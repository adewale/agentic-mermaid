import { spyOn } from 'bun:test'
import * as rubric from '/dev/shm/pr449-four-final-20261111/layout-pass-cost-9644/src/layout-rubric.ts'
import { LAYOUT_PIPELINE } from '/dev/shm/pr449-four-final-20261111/layout-pass-cost-9644/src/layout/legacy-completion.ts'
import { renderMermaidSVGWithReceipt } from '/dev/shm/pr449-four-final-20261111/layout-pass-cost-9644/src/index.ts'
const source = ['flowchart TB',...Array.from({length:100},(_,i)=>`n${i}[Node ${i}]`),...Array.from({length:99},(_,i)=>`n${i} --> n${i+1}`)].join('\n')
const measure = rubric.measureRubricMetrics
const measurements:any[]=[];let pass=''
spyOn(rubric,'measureRubricMetrics').mockImplementation((...args)=>{const start=performance.now();const metrics=measure(...args); measurements.push({pass,requested:args[2],metrics,ms:performance.now()-start});return metrics})
const passes:any[]=[]
for(const p of LAYOUT_PIPELINE){const original=p.run;p.run=c=>{pass=p.id;const start=performance.now();const result=original(c);passes.push({pass:p.id,bundled:c.bundled.size,ms:performance.now()-start});return result}}
for(let i=0;i<5;i++){measurements.length=0;passes.length=0;const start=performance.now();const product=renderMermaidSVGWithReceipt(source,{embedFontImport:false,graphLayout:{backend:'agentic',fallback:'none'}});const bytes=JSON.stringify(product).length;console.log(JSON.stringify({run:i,totalMs:performance.now()-start,bytes,measurements,passes}))}
