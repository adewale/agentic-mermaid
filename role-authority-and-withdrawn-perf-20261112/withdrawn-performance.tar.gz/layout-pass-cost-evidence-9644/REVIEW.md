# Layout-pass subtraction review at 9644

Source worktree: `/dev/shm/pr449-four-final-20261111/layout-pass-cost-9644`, detached `9644bce7edd0cd9706bb5dbfc30a89d8d2feb643`. No production edits. Existing corrected rubric-topology/ordering and point-fusion dispositions were read and are not replayed.

`observe.ts` and `observe.jsonl` record five instrumented Bun source calls on the existing 100-node chain, cache disabled, public SVG+receipt API fully serialized. These are causal diagnostics, not stock Node speed comparisons. Instrumentation wraps pass runs and spies on the existing metric entry. The pass label on a before measurement is the previous completed pass; requested metrics and before/after order identify its owner.

The chain has no branching peers, yet the enabled cosmetic `centerPeerBarycenters` proposal receives a `symErr,bends,hard` baseline. In the final diagnostic the baseline takes 1.42971ms; the pass itself takes 0.361462ms and makes no move. This suggests a necessary fan-degree guard, but the existing public graph remains live: `layoutGraphSync` normally returns its original argument through `graphWithDisplayCaptions`, and the measured producer passes that graph unchanged to `finishGraphGeometry`. Skipping the pass also suppresses graph.edges/direction reads from the hard baseline and centering owner. User getters can alter later state, so no safe existing private admission was established. No guard or ownership mechanism was added.

The empty-bundle `collapseTinyBundledHitches` pass takes 0.126147ms, plus 0.007086ms for its two bend metric calls in the final diagnostic. Its small ceiling does not justify broad work or a value claim.

The previous corrected rubric trial already introduced placement metrics and map reuse with hard-first batching, and was withdrawn for worse stock and full-response medians. It cannot be reused as a fresh intervention. Lazy baseline measurement would move graph/getter observations across the proposal body; new deferred-proposal machinery or authority registries were rejected.

No processes remain open. Diagnostics stopped before root's scalar candidate timing hold.

## Independent review of root scalar copy change

Reviewed the only difference between 9644 and `scalar-dispatch-9644/src/scene/native-paint-emission.ts`: the new primitive return follows the unchanged depth>64 guard in `copy`. Those primitive values previously pass only local/context/type tests before identical return in `copyInner`; they execute no pay, parents, reflection, transfer, or sealing operations. Returning number/string preserves NaN, negative zero, Infinity and UTF16 bytes. Object/proxy/boxed primitive and function/symbol/bigint follow the old path. The default parents Set allocation and depth failure order remain unchanged. No finding; owning checks and stock Node timing belong to root.
