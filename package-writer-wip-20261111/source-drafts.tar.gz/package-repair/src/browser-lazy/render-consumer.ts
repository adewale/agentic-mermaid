import type { FamilyDescriptor } from '../agent/families.ts'
import type { RenderOptions } from '../types.ts'
import type { FirstPartyDrawingConsumer } from '../scene/default-drawing-consumer.ts'

/** Source/SDK/isolated consumers keep the canonical synchronous Scene owner. */
export async function prepareFamilyDrawingConsumer(backend: string, _options: RenderOptions, _family: FamilyDescriptor): Promise<FirstPartyDrawingConsumer | undefined> {
  if (backend !== 'default') await import('../scene/builtin-backends.ts')
  return undefined
}
export { executeResolvedGraphicalRequest as executeFamilyRenderRequest } from '../graphical-render.ts'
