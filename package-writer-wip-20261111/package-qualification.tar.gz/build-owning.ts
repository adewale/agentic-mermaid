import { pathToFileURL } from 'node:url'
import { build } from '/tmp/pr449-main-integration-20261029-762/node_modules/tsup/dist/index.js'
const root=process.argv[2]!,kind=process.argv[3]!
process.chdir(root)
if(kind==='node'){
 const config=(await import(pathToFileURL(root+'/tsup.config.ts').href)).default
 await build({...config,config:false,dts:false,sourcemap:false,metafile:true,clean:true,entry:Object.fromEntries(Object.entries(config.entry).map(([name,p])=>[name,root+'/'+p])),outDir:root+'/dist',tsconfig:root+'/tsconfig.json',onSuccess:async()=>{process.chdir(root);await config.onSuccess()}})
}else{
 const configs=(await import(pathToFileURL(root+'/tsup.zenuml.config.ts').href)).default
 for(const config of configs)await build({...config,config:false,dts:false,sourcemap:false,clean:false,entry:Object.fromEntries(Object.entries(config.entry).map(([name,p])=>[name,root+'/'+p])),outDir:root+'/dist',tsconfig:root+'/tsconfig.json'})
}
