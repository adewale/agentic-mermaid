import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs'
import {join} from 'node:path'
import {publishPackageProblems,expectedFilesWithLazyBuild,normalizePackagePath} from './candidate/scripts/ci/verify-publish-package.ts'
const task=import.meta.dir,required=['package.json','README.md','LICENSE','THIRD_PARTY_NOTICES.md','LICENSES/Apache-2.0.txt','server.json']
const collect=(root:string):string[]=>readdirSync(join(root,'dist'),{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(root,'dist/'+e.name):e.name.endsWith('.js')?['dist/'+e.name]:[])
const walk=(root:string,dir:string):string[]=>readdirSync(join(root,dir),{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(root,dir+'/'+e.name):e.name.endsWith('.js')?[dir+'/'+e.name]:[])
const actualPackage=JSON.parse(readFileSync(task+'/candidate/package.json','utf8'))
const pkg={bin:actualPackage.bin,exports:Object.fromEntries(Object.entries(actualPackage.exports).map(([k,v]:any)=>[k,typeof v==='string'?v:Object.fromEntries(Object.entries(v).filter(([p,v]:any)=>p!=='types'&&String(v).endsWith('.js')&&!String(v).includes('browser.global.js')))]).filter(([k,v]:any)=>typeof v==='string'?v.endsWith('.js')&&!v.includes('browser.global.js'):Object.keys(v).length))}
const initial=JSON.parse(readFileSync(task+'/candidate/scripts/ci/publish-package-files.json','utf8')).files
const rows=[]
for(const arm of ['bad','candidate']){
 const root=task+'/'+arm,actual=[...required.filter(p=>existsSync(join(root,p))),...collect(root).filter(p=>!p.startsWith('dist/browser-lazy/'))]
 const expected=[...required,...initial.filter((p:string)=>p.startsWith('dist/')&&p.endsWith('.js')&&p!=='dist/browser.global.js'&&!p.startsWith('dist/browser-lazy/'))]
 const scopedPkg={...pkg,exports:Object.fromEntries(Object.entries(pkg.exports).filter(([k])=>k!=='./browser/lazy'))}
 const problems=publishPackageProblems(scopedPkg,actual,expected)
 rows.push({arm,scope:'Actual canonical full14Node + owning isolatedZen JS inventory and public JS targets; unchanged existing verifier; excludes unbuilt IIFE and declaration files, not a full npm tarball qualification.',actual,normalized:actual.map(normalizePackagePath),problems})
}
writeFileSync(task+'/'+(process.argv[2]??'PACK-RED-BEFORE-INVENTORY.json'),JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows.map(x=>({arm:x.arm,problems:x.problems})),null,2))
