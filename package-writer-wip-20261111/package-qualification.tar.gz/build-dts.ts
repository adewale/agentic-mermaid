import {pathToFileURL} from 'node:url'
const root=process.argv[2]!
process.chdir(root)
const {build}=await import('/tmp/pr449-main-integration-20261029-762/node_modules/tsup/dist/index.js')
const config=(await import(pathToFileURL(root+'/tsup.config.ts').href)).default
await build({...config,config:false,clean:false,sourcemap:false,entry:Object.fromEntries(Object.entries(config.entry).map(([n,p])=>[n,root+'/'+p])),dts:{...config.dts,only:true,entry:Object.fromEntries(Object.entries(config.dts.entry).map(([n,p])=>[n,root+'/'+p]))},outDir:root+'/dts-only',tsconfig:root+'/tsconfig.json',onSuccess:async()=>{}})
