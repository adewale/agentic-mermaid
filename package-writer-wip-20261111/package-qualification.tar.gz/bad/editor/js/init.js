import { ui } from './context.js';
import { DEFAULT_EDITOR_PALETTE, editorPaletteColors, editorPaletteInput, state } from './state.js';
import { editor, themeMenu } from './elements.js';
import { discardEditorDraft, draftRestoreFailure, getHashSource, getQueryExampleId, hasOwnConfig, hashDecodeFailure, readEditorDraft, safeLocalStorageGet, safeLocalStorageRemove, safeLocalStorageSet, sanitizeEditorConfig, sanitizeEditorStyle } from './sharing.js';
import { applyThemeToPage, scheduleRender } from './rendering.js';
import { hydrateConfigControls, refreshAllColorUIs } from './config-panel.js';
import { createListboxPopupController, setEditorErrorLine } from './helpers.js';
import { applyColorMode, isDark } from './dark-mode.js';
import { updateCursorPos, updateLineNumbers } from './editor-helpers.js';
import { showToast } from './toast.js';
import { findEditorExample, loadEditorExample } from './examples.js';
import { setMobilePanel } from './tabs.js';
export var themeBtnLabel, themeBtnSwatch, themeDropdownBtn, themeMenuPopup, savedPaletteInput, savedPalette, styleBtnLabel, styleDropdownBtn, styleMenu, styleMenuPopup, savedStyle, DEFAULT_SOURCE, draftNotice, draftDiscardBtn, draftNoticeTimer;


export function updateThemeButton() {
  var key = state.palette;
  var colors = editorPaletteColors(key);
  if (key && colors) {
    themeBtnLabel.textContent =
      themeDropdownBtn.getAttribute("data-label-" + key) || key;
    themeBtnSwatch.style.background = colors.bg;
    themeBtnSwatch.style.display = "";
  } else {
    themeBtnLabel.textContent = "Default";
    // Keep the ringed swatch visible (CSS supplies a neutral fill) — on mobile
    // the swatch is the entire control, so hiding it left a blank button.
    themeBtnSwatch.style.background = "";
    themeBtnSwatch.style.display = "";
  }
  // Update active state in dropdown
  themeMenu.querySelectorAll(".theme-dropdown-item").forEach(function (item) {
    var active = item.dataset.theme === key;
    item.classList.toggle("active", active);
    item.setAttribute("aria-selected", active ? "true" : "false");
    item.tabIndex = themeMenu.classList.contains("open") && active ? 0 : -1;
  });
}


export function setTheme(key) {
  state.palette = key ? editorPaletteInput(key) : "";
  ui.diagramThemeIsAuto = false;
  if (key) {
    safeLocalStorageSet("bm-editor-palette", state.palette);
  } else {
    safeLocalStorageRemove("bm-editor-palette");
  }
  applyThemeToPage(key);
  updateThemeButton();
  refreshAllColorUIs();
  scheduleRender(0);
}


export function setThemeMenuOpen(open, focusActive) {
  themeMenuPopup.setOpen(open, { focusFirst: !!focusActive });
}


export function updateStyleButton() {
  var key = state.style || "crisp";
  styleBtnLabel.textContent =
    styleDropdownBtn.getAttribute("data-label-" + key) || key;
  styleMenu.querySelectorAll(".theme-dropdown-item").forEach(function (item) {
    var active = (item.dataset.style || "crisp") === key;
    item.classList.toggle("active", active);
    item.setAttribute("aria-selected", active ? "true" : "false");
    item.tabIndex = styleMenu.classList.contains("open") && active ? 0 : -1;
  });
}


export function setStyle(key) {
  state.style = key || "crisp";
  if (state.style !== "crisp") {
    safeLocalStorageSet("bm-editor-style", state.style);
  } else {
    safeLocalStorageRemove("bm-editor-style");
  }
  updateStyleButton();
  scheduleRender(0);
}


export function setStyleMenuOpen(open, focusActive) {
  styleMenuPopup.setOpen(open, { focusFirst: !!focusActive });
}


export function hideDraftNotice() {
  if (draftNoticeTimer) clearTimeout(draftNoticeTimer);
  draftNoticeTimer = null;
  if (draftNotice) draftNotice.hidden = true;
}


export function showDraftRestoredNotice() {
  if (!draftNotice) return;
  draftNotice.hidden = false;
  if (draftNoticeTimer) clearTimeout(draftNoticeTimer);
  draftNoticeTimer = setTimeout(hideDraftNotice, 8000);
}


export function discardRestoredDraft() {
  if (typeof discardEditorDraft === "function") discardEditorDraft();
  hideDraftNotice();
  editor.value = DEFAULT_SOURCE;
  state.config = {};
  setEditorErrorLine(0);
  refreshAllColorUIs();
  updateLineNumbers();
  updateCursorPos();
  scheduleRender(0);
  showToast("Draft discarded.");
}


export function shouldOpenEmptyEditor() {
  try {
    var value = new URLSearchParams(window.location.search).get('empty');
    return value === '1' || value === 'true';
  } catch(e) { return false; }
}

export function initialize() {
// Theme dropdown logic
themeBtnLabel = document.getElementById("theme-btn-label");

themeBtnSwatch = document.getElementById("theme-btn-swatch");

themeDropdownBtn = document.getElementById("theme-dropdown-btn");


themeMenuPopup = createListboxPopupController({
  popup: themeMenu,
  trigger: themeDropdownBtn,
  itemSelector: '.theme-dropdown-item',
  activeSelector: '.theme-dropdown-item.active',
  visualClose: true,
  contains: function(target) { return !!target.closest("#theme-dropdown-wrap"); },
  onSelect: function(item) { setTheme(item.dataset.theme || ""); },
});


// Store label data for lookup
themeMenu.querySelectorAll(".theme-dropdown-item").forEach(function (item) {
  var key = item.dataset.theme || "";
  themeDropdownBtn.setAttribute("data-label-" + key, item.textContent.trim());
});


// Apply initial dark/light mode (must happen after all DOM refs + functions are ready)
applyColorMode(isDark);


// Restore saved theme, otherwise start on the brand Paper theme so the editor
// opens with the same diagram palette the public site renders.
savedPaletteInput = safeLocalStorageGet("bm-editor-palette") || "";

savedPalette = editorPaletteInput(savedPaletteInput);

if (savedPalette) {
  state.palette = savedPalette;
  safeLocalStorageSet("bm-editor-palette", savedPalette);
  ui.diagramThemeIsAuto = false;
} else if (!editorPaletteInput(state.palette)) {
  state.palette = DEFAULT_EDITOR_PALETTE;
  ui.diagramThemeIsAuto = true;
}

applyThemeToPage(state.palette);

updateThemeButton();

setThemeMenuOpen(false, false);


// ── Style dropdown (renderer treatment — hand-drawn, watercolor, …) ─────────
// Mirrors the Palette dropdown: style picks mark treatment, palette picks
// colors; buildOptions stacks them (palette colors win by render precedence).
styleBtnLabel = document.getElementById("style-btn-label");

styleDropdownBtn = document.getElementById("style-dropdown-btn");

styleMenu = document.getElementById("style-dropdown-menu");


styleMenuPopup = createListboxPopupController({
  popup: styleMenu,
  trigger: styleDropdownBtn,
  itemSelector: '.theme-dropdown-item',
  activeSelector: '.theme-dropdown-item.active',
  visualClose: true,
  contains: function(target) { return !!target.closest("#style-dropdown-wrap"); },
  onSelect: function(item) { setStyle(item.dataset.style || "crisp"); },
});


styleMenu.querySelectorAll(".theme-dropdown-item").forEach(function (item) {
  var key = item.dataset.style || "crisp";
  styleDropdownBtn.setAttribute("data-label-" + key, item.textContent.trim());
});


savedStyle = sanitizeEditorStyle(safeLocalStorageGet("bm-editor-style") || "");

if (savedStyle) state.style = savedStyle;

updateStyleButton();

setStyleMenuOpen(false, false);


// Load from URL hash or start on an on-brand default so the editor opens with
// the loop already working (a rendered diagram, verify results, and on-demand
// text outputs) instead of five empty states. The default is the product's own
// parse -> verify -> serialize loop.
DEFAULT_SOURCE = [
  "flowchart TD",
  "  A[Parse source] --> B[Narrow intent]",
  "  B --> C[Mutate one node]",
  "  C --> D{Verify}",
  "  D -- ok --> E[Serialize]",
  "  D -- warnings --> B",
].join("\n");


// Draft restore notice: polite, transient, with an explicit way to discard.
draftNotice = document.getElementById("draft-notice");

draftDiscardBtn = document.getElementById("draft-discard-btn");

draftNoticeTimer = null;


if (draftDiscardBtn) draftDiscardBtn.addEventListener("click", discardRestoredDraft);


// getHashSource decodes compressed share links asynchronously, so the initial
// source pick runs in an async IIFE; nothing below in this file depends on it.
(async function initializeEditorSource() {
  var hashSource = await getHashSource();
  // A share link that exists but cannot be decoded must say so — silently
  // showing the recipient their old draft or the default diagram would let
  // them believe they are looking at what was shared.
  if (!hashSource && typeof hashDecodeFailure === 'string' && hashDecodeFailure && typeof showToast === 'function') {
    showToast(hashDecodeFailure === 'unsupported'
      ? 'This share link needs a newer browser to open (missing DecompressionStream). Nothing was loaded.'
      : hashDecodeFailure === 'too-large'
        ? 'This share link is too large to open safely. Nothing was loaded.'
        : 'This share link could not be decoded (truncated or damaged). Nothing was loaded.');
  }
  var queryExampleId = getQueryExampleId();
  var queryEmptyEditor = shouldOpenEmptyEditor();
  var loadedInitialExample = false;
  if (hashSource) {
    editor.value = hashSource;
    applyThemeToPage(state.palette);
    updateThemeButton();
    updateStyleButton();
    if (typeof hydrateConfigControls === 'function') hydrateConfigControls(state.config);
    else refreshAllColorUIs();
  } else if (hashDecodeFailure) {
    // Fail closed: a broken shared URL must never be replaced by a local draft,
    // query example, or plausible-looking default.  Clear the unopenable URL so
    // the next edit starts a new share state rather than retrying it.
    editor.value = '';
    state.config = {};
    if (typeof hydrateConfigControls === 'function') hydrateConfigControls(state.config);
    else refreshAllColorUIs();
    window.history.replaceState(null, '', window.location.pathname);
  } else if (queryExampleId && typeof loadEditorExample === 'function' && findEditorExample(queryExampleId)) {
    loadEditorExample(queryExampleId);
    loadedInitialExample = true;
  } else if (queryEmptyEditor) {
    editor.value = '';
    state.config = {};
    if (typeof hydrateConfigControls === 'function') hydrateConfigControls(state.config);
    else refreshAllColorUIs();
  } else {
    // No shared source or explicit blank-start request in the URL: restore the autosaved draft if one exists.
    var draft = typeof readEditorDraft === 'function' ? readEditorDraft() : null;
    if (draft) {
      editor.value = draft.source;
      state.config = hasOwnConfig(draft.config) ? sanitizeEditorConfig(draft.config) : {};
      var draftStyle = sanitizeEditorStyle(draft.style);
      state.style = draftStyle || 'crisp';
      state.seed = typeof draft.seed === 'number' && Number.isFinite(draft.seed) ? draft.seed : 0;
      updateStyleButton();
      if (typeof hydrateConfigControls === 'function') hydrateConfigControls(state.config);
      else refreshAllColorUIs();
      showDraftRestoredNotice();
      // A restored draft means a returning editor: on mobile, put Source (and
      // the draft notice) back on screen instead of the first-run Preview.
      if (typeof setMobilePanel === 'function' && document.body.dataset.mobilePanel === 'preview') {
        setMobilePanel('code');
      }
    } else {
      editor.value = DEFAULT_SOURCE;
      if (typeof draftRestoreFailure === 'string' && draftRestoreFailure && typeof showToast === 'function') {
        showToast(draftRestoreFailure === 'too-large'
          ? 'A saved draft was too large to restore safely and was cleared.'
          : 'A saved draft was corrupt and was cleared.');
      }
    }
  }

  if (!loadedInitialExample) {
    updateLineNumbers();
    scheduleRender(0);
  }
})();
}
