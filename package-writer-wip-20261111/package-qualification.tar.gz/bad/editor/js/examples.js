import { ui } from './context.js';
import { createPopupController, escAttr, escHtml, setEditorErrorLine } from './helpers.js';
import { editor } from './elements.js';
import { DEFAULT_SOURCE, updateThemeButton } from './init.js';
import { state } from './state.js';
import { hydrateConfigControls } from './config-panel.js';
import { scheduleDraftSave, updateHash } from './sharing.js';
import { applyThemeToPage, scheduleRender } from './rendering.js';
import { updateCursorPos, updateLineNumbers } from './editor-helpers.js';
import { showToast } from './toast.js';
export var selectedExampleId, examplesSidebar, examplesSidebarBtn, examplesSidebarClose, examplesSidebarList, examplesPopup;


export function cloneEditorConfig(config) {
  return config ? JSON.parse(JSON.stringify(config)) : {};
}


export function findEditorExample(id) {
  for (var i = 0; i < ui.EDITOR_EXAMPLES.length; i++) {
    if (ui.EDITOR_EXAMPLES[i].id === id) return ui.EDITOR_EXAMPLES[i];
  }
  return null;
}


export function exampleGroups() {
  var groups = [];
  var groupMap = {};
  ui.EDITOR_EXAMPLES.forEach(function(example) {
    var category = example.category || 'Examples';
    if (!groupMap[category]) {
      groupMap[category] = { category: category, examples: [] };
      groups.push(groupMap[category]);
    }
    groupMap[category].examples.push(example);
  });
  return groups;
}


export function exampleGlyph(example) {
  var type = example.diagramType || 'Example';
  return example.glyph || type.slice(0, 2).toUpperCase();
}


export function renderExamplePaletteHtml() {
  var examplesHtml = exampleGroups().map(function(group) {
    return '<section class="example-category">'
      + '<div class="example-category-title">' + escHtml(group.category) + '</div>'
      + '<div class="example-category-grid">'
      + group.examples.map(function(example) {
        return '<button class="example-dropdown-item" type="button" data-example="' + escAttr(example.id) + '" data-diagram="' + escAttr(example.diagramType || '') + '" title="' + escAttr(example.description || example.label) + '">'
          + '<span class="example-item-title"><span class="example-item-glyph" aria-hidden="true">' + escHtml(exampleGlyph(example)) + '</span>' + escHtml(example.label) + '</span>'
          + '<span class="example-item-description">' + escHtml(example.description || '') + '</span>'
          + '</button>';
      }).join('')
      + '</div>'
      + '</section>';
  }).join('');

  return examplesHtml
    + '<div class="example-menu-footer">'
    + '<button class="example-clear-btn" type="button" data-action="clear-editor">New blank diagram</button>'
    + '</div>';
}


export function renderExamplePalettes() {
  if (examplesSidebarList) examplesSidebarList.innerHTML = renderExamplePaletteHtml();
}


export function markActiveExample(id) {
  selectedExampleId = id || '';
  document.querySelectorAll('.example-dropdown-item').forEach(function(item) {
    item.classList.toggle('active', item.dataset.example === selectedExampleId);
  });
}


// Unsaved work = source the user authored: non-empty and not a preset the
// editor itself put there (an example, or the default starter diagram from
// init.js). Loading an example replaces both the source and the autosaved
// draft, so those cases get a confirm() before being overwritten.
export function editorHasUnsavedWork() {
  var current = editor.value.trim();
  if (!current) return false;
  if (typeof DEFAULT_SOURCE === 'string' && current === DEFAULT_SOURCE.trim()) return false;
  for (var i = 0; i < ui.EDITOR_EXAMPLES.length; i++) {
    if (ui.EDITOR_EXAMPLES[i].source.trim() === current) return false;
  }
  return true;
}


export function loadEditorExample(id) {
  var example = findEditorExample(id);
  if (!example) return;
  if (editorHasUnsavedWork()
      && !window.confirm('Replace your current diagram with "' + example.label + '"? Your edits (and the autosaved draft) will be overwritten.')) {
    return;
  }

  editor.value = example.source.trim();
  state.config = cloneEditorConfig(example.options);
  if (typeof hydrateConfigControls === 'function') hydrateConfigControls(state.config);
  markActiveExample(example.id);
  if (typeof setEditorErrorLine === 'function') setEditorErrorLine(0);
  if (typeof scheduleDraftSave === 'function') scheduleDraftSave();

  // Examples are source/config presets only; keep the user's selected theme.
  if (typeof applyThemeToPage === 'function') applyThemeToPage(state.palette);
  if (typeof updateThemeButton === 'function') updateThemeButton();

  updateLineNumbers();
  updateCursorPos();
  scheduleRender(0);
  updateHash();
  showToast('Loaded ' + example.label + '.');
}


export function positionExamplesSidebar() {
  if (!examplesSidebar || !examplesSidebarBtn) return;
  var rect = examplesSidebarBtn.getBoundingClientRect();
  var gutter = 12;
  var preferred = 360;
  var width = Math.min(preferred, window.innerWidth - gutter * 2);
  var left = Math.min(Math.max(gutter, rect.left), window.innerWidth - width - gutter);
  var top = rect.bottom + 8;
  var maxHeight = Math.max(260, window.innerHeight - top - gutter);
  examplesSidebar.style.setProperty('--examples-left', Math.round(left) + 'px');
  examplesSidebar.style.setProperty('--examples-top', Math.round(top) + 'px');
  examplesSidebar.style.setProperty('--examples-width', Math.round(width) + 'px');
  examplesSidebar.style.setProperty('--examples-max-height', Math.round(maxHeight) + 'px');
}


export function setExamplesSidebarOpen(open, meta) {
  examplesPopup.setOpen(open, meta || {});
}


export function openExamplesSidebar() {
  setExamplesSidebarOpen(true, { focusFirst: true });
}

export function initialize() {
selectedExampleId = '';


examplesSidebar = document.getElementById('examples-sidebar');

examplesSidebarBtn = document.getElementById('examples-sidebar-btn');

examplesSidebarClose = document.getElementById('examples-sidebar-close');

examplesSidebarList = document.getElementById('examples-sidebar-list');


examplesPopup = typeof createPopupController === 'function' ? createPopupController({
  popup: examplesSidebar,
  trigger: examplesSidebarBtn,
  visibility: { manageTabStops: true, toggleTriggerClass: false },
  beforeOpen: positionExamplesSidebar,
  afterOpen: function(meta) {
    if (examplesSidebarBtn) {
      examplesSidebarBtn.classList.add('active');
      examplesSidebarBtn.setAttribute('aria-pressed', 'true');
    }
    if (meta && meta.focusFirst && examplesSidebarList) {
      var activeItem = examplesSidebarList.querySelector('.example-dropdown-item.active') || examplesSidebarList.querySelector('.example-dropdown-item');
      if (activeItem) activeItem.focus({ preventScroll: false });
    }
  },
  afterClose: function() {
    if (examplesSidebarBtn) {
      examplesSidebarBtn.classList.remove('active');
      examplesSidebarBtn.setAttribute('aria-pressed', 'false');
    }
  },
  contains: function(target) {
    return !!(target.closest('#examples-sidebar') || target.closest('#examples-sidebar-btn'));
  },
  repositionOnResize: true,
  position: positionExamplesSidebar,
}) : { setOpen: function() {} };


renderExamplePalettes();

setExamplesSidebarOpen(false);


if (examplesSidebarClose) {
  examplesSidebarClose.addEventListener('click', function() {
    setExamplesSidebarOpen(false, { restoreFocus: true });
  });
}


if (examplesSidebarList) {
  examplesSidebarList.addEventListener('click', function(e) {
    var item = e.target.closest('.example-dropdown-item');
    if (!item) return;
    loadEditorExample(item.dataset.example || '');
    setExamplesSidebarOpen(false);
  });
}


document.addEventListener('click', function(e) {
  var starter = e.target.closest('.placeholder-chip[data-example]');
  if (starter) {
    loadEditorExample(starter.dataset.example || '');
    return;
  }
  if (e.target.closest('[data-action="load-example"]')) {
    openExamplesSidebar();
    return;
  }
});
}
