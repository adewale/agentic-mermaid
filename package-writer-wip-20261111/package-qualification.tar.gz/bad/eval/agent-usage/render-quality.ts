import { executeInSandbox } from '../../src/mcp/sandbox.ts'
import { BUILTIN_FAMILY_METADATA, parseRegisteredMermaid as parseMermaid, renderMermaidSVG, verifyMermaid, verifyNoExternalRefs, type DiagramKind } from '../../src/agent/index.ts'
import { DEFAULT_CASES, type AgentUsageEvalCase } from './run.ts'

export const AGENT_USAGE_SUPPORTED_FAMILIES: readonly DiagramKind[] = BUILTIN_FAMILY_METADATA.map(family => family.id)

export interface AgentUsageRenderQualityResult {
  id: string
  family: DiagramKind | 'unknown'
  ok: boolean
  sourceOk: boolean
  verifyOk: boolean
  renderOk: boolean
  safeSvgOk: boolean
  boundsOk: boolean
  semanticLabelsOk: boolean
  warnings: string[]
  metrics?: {
    width: number
    height: number
    nodes: number
    edges: number
    svgBytes: number
  }
  error?: string
}

export interface AgentUsageRenderQualitySummary {
  ok: boolean
  total: number
  passed: number
  families: DiagramKind[]
  results: AgentUsageRenderQualityResult[]
}

const EXPECTED_VISIBLE_LABELS: Record<string, string[]> = {
  agentflow_set_search_role: ["LLM API", "Brand guide", "Plan work", "Search documents", "Publish result", "PUBLISHING"],
  author_agentflow_source: ["LLM API", "Brand guide", "Plan work", "Search documents", "Publish result", "PUBLISHING"],
  usecase_set_vertical_direction: ["Customer", "STOREFRONT", "Browse catalogue", "Checkout"],
  author_usecase_source: ["Customer", "STOREFRONT", "Browse catalogue", "Checkout"],
  wardley_evolve_service: ["PLATFORM EVOLUTION", "Customer", "Service", "Power", "Custom", "Utility", "Keep all note text", "Adopt utility"],
  author_wardley_source: ["PLATFORM EVOLUTION", "Customer", "Service", "Power", "Custom", "Utility", "Keep all note text", "Adopt utility"],
  venn_update_overlap: ["Alpha", "Beta", "Shared", "Owned note"],
  author_venn_source: ["Alpha", "Beta", "Shared", "Owned note"],
  cynefin_automate_clear_domain: ["Decisions with feedback", "Explore", "Analyse", "Automate", "Stabilise", "Investigate", "Learning", "Recover"],
  author_cynefin_source: ["Decisions with feedback", "Explore", "Analyse", "Automate", "Stabilise", "Investigate", "Learning", "Recover"],
  railroad_replace_item_literal: ["entry", "start", "item", "end", "datum"],
  author_railroad_source: ["entry", "start", "item", "end", "datum"],
  swimlane_rename_dispatch: ["CUSTOMER", "OPERATIONS", "Request order", "Receive order", "In stock?", "Ship parcel", "Yes"],
  author_swimlane_source: ["CUSTOMER", "OPERATIONS", "Request order", "Receive order", "In stock?", "Ship parcel", "Yes"],
  treeview_rename_component: ["PROJECT", "src/", "Application.tsx", "widgets/", "按钮.ts", "README.md", "main component"],
  author_treeview_source: ["PROJECT", "src/", "Application.tsx", "widgets/", "按钮.ts", "README.md", "main component"],
  zenuml_rename_inventory: ['Customer', 'API', 'Inventory', 'checkout()', 'reserve()'],
  author_zenuml_source: ['Customer', 'API', 'Inventory', 'checkout()', 'reserve()'],
  eventmodeling_add_read_model: ['Cart.UI', 'Cart.AddItem', 'Cart.ItemAdded', 'Cart.Items', 'description: string'],
  cache_between_api_and_db: ['API', 'Cache', 'DB'],
  state_add_done_transition: ['Processing', 'done'],
  sequence_alt_add_message: ['hi', 'bye', 'yes'],
  timeline_add_event: ['Alpha', 'Beta'],
  class_add_duck: ['Duck', 'quack'],
  er_add_order: ['CUSTOMER', 'ORDER', 'string'],
  journey_add_review_task: ['Draft', 'Review', 'Agent'],
  architecture_add_cache: ['API', 'Cache', 'cache'],
  xychart_add_forecast: ['Q1', 'Q2'],
  pie_add_docs_slice: ['Build', 'Test', 'Docs'],
  quadrant_add_docs_point: ['API', 'Docs'],
  gantt_add_docs_task: ['Core', 'Docs'],
  mindmap_add_evidence_node: ['Product', 'Research', 'Evidence'],
  gitgraph_add_release_commit: ['ROOT', 'RC', 'rc.1'],
  radar_add_beta_curve: ['Speed', 'Alpha', 'Beta'],
  c4_add_cache_container: ['Platform', 'API', 'DB', 'Cache', 'TypeScript', 'PostgreSQL', 'Redis', 'Serves requests', 'Stores records', 'Caches responses', 'Reads cache'],
  author_c4_source: ['Customer', 'Shop', 'Payments', 'Places orders', 'Sells products', 'Processes payments', 'Uses', 'Charges'],
  author_auth_flow_source: ['User', 'Login Page', 'Dashboard'],
  author_api_sequence_source: ['User', 'App', 'API', 'Render SVG', 'Download'],
  packet_add_checksum: ['Version', 'Payload', 'Checksum'],
  kanban_move_completed_task: ['To do', 'Done', 'Build parser', 'Research', 'Maya', 'AM-1'],
  requirement_rename_evidence: ['fast', 'evidence', 'Respond within 100ms', 'Analysis', 'verifies', 'traces'],
  block_rename_database: ['API', 'DB'],
  treemap_update_design_value: ['Product', 'Engineering', 'Design'],
  ishikawa_add_cache_cause: ['Slow release', 'Process', 'Tooling', 'Manual checks', 'Slow builds', 'Cold caches'],
}

function escapeXmlText(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

function numericBoundsFromSvg(svg: string): { width: number; height: number } | undefined {
  const viewBox = svg.match(/\bviewBox="\s*[-\d.]+\s+[-\d.]+\s+([\d.]+)\s+([\d.]+)\s*"/i)
  if (viewBox) return { width: Number(viewBox[1]), height: Number(viewBox[2]) }
  const width = svg.match(/\bwidth="([\d.]+)"/i)
  const height = svg.match(/\bheight="([\d.]+)"/i)
  if (!width || !height) return undefined
  return { width: Number(width[1]), height: Number(height[1]) }
}

function hasVisibleSvgContent(svg: string): boolean {
  return /<(?:text|tspan|path|rect|circle|ellipse|line|polyline|polygon)\b/i.test(svg)
}

function semanticLabelsOk(id: string, svg: string): boolean {
  const labels = EXPECTED_VISIBLE_LABELS[id] ?? []
  if (labels.length === 0) return true
  return labels.every(label => svg.includes(escapeXmlText(label)))
}

export async function scoreAgentUsageRenderedQuality(cases: AgentUsageEvalCase[] = DEFAULT_CASES): Promise<AgentUsageRenderQualitySummary> {
  const results: AgentUsageRenderQualityResult[] = []
  for (const c of cases) {
    try {
      const exec = await executeInSandbox(c.script, { trace: true })
      const source = exec.ok ? (exec.value as { source?: unknown } | undefined)?.source : undefined
      if (typeof source !== 'string') {
        results.push({ id: c.id, family: c.family ?? 'unknown', ok: false, sourceOk: false, verifyOk: false, renderOk: false, safeSvgOk: false, boundsOk: false, semanticLabelsOk: false, warnings: [], error: exec.ok ? 'script did not return { source }' : String(exec.error) })
        continue
      }
      const parsed = parseMermaid(source)
      if (!parsed.ok) {
        results.push({ id: c.id, family: c.family ?? 'unknown', ok: false, sourceOk: false, verifyOk: false, renderOk: false, safeSvgOk: false, boundsOk: false, semanticLabelsOk: false, warnings: [], error: 'source did not parse' })
        continue
      }
      const verify = verifyMermaid(parsed.value)
      const warnings = verify.warnings.map(w => w.code)
      let svg = ''
      let renderError: string | undefined
      try {
        svg = renderMermaidSVG(source, { security: 'strict', compact: true, idPrefix: `agent-usage-${c.id}-` })
      } catch (error) {
        renderError = error instanceof Error ? error.message : String(error)
      }
      const safeSvg = svg ? verifyNoExternalRefs(svg) : { ok: false, refs: [] as string[] }
      const svgBounds = svg ? numericBoundsFromSvg(svg) : undefined
      const width = svgBounds?.width ?? verify.layout.bounds.w
      const height = svgBounds?.height ?? verify.layout.bounds.h
      const boundsOk = Number.isFinite(width) && Number.isFinite(height) && width > 0 && height > 0 && width <= 4000 && height <= 4000
      const renderOk = !renderError && svg.startsWith('<svg') && hasVisibleSvgContent(svg)
      const labelsOk = renderOk && semanticLabelsOk(c.id, svg)
      const result: AgentUsageRenderQualityResult = {
        id: c.id,
        family: c.family ?? (AGENT_USAGE_SUPPORTED_FAMILIES.includes(parsed.value.kind as DiagramKind) ? (parsed.value.kind as DiagramKind) : 'unknown'),
        ok: verify.ok && renderOk && safeSvg.ok && boundsOk && labelsOk,
        sourceOk: true,
        verifyOk: verify.ok,
        renderOk,
        safeSvgOk: safeSvg.ok,
        boundsOk,
        semanticLabelsOk: labelsOk,
        warnings: safeSvg.ok ? warnings : [...warnings, ...safeSvg.refs.map(ref => `external:${ref}`)],
        metrics: { width, height, nodes: verify.layout.nodes.length, edges: verify.layout.edges.length, svgBytes: Buffer.byteLength(svg) },
        error: renderError,
      }
      results.push(result)
    } catch (error) {
      results.push({ id: c.id, family: c.family ?? 'unknown', ok: false, sourceOk: false, verifyOk: false, renderOk: false, safeSvgOk: false, boundsOk: false, semanticLabelsOk: false, warnings: [], error: error instanceof Error ? error.message : String(error) })
    }
  }
  const passed = results.filter(r => r.ok).length
  const families = [...new Set(results.map(r => r.family).filter((f): f is DiagramKind => f !== 'unknown'))]
  return { ok: passed === results.length, total: results.length, passed, families, results }
}
