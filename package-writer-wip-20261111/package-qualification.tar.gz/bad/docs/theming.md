# Palettes and theming

Agentic Mermaid themes start from a two-color contract (`bg`, `fg`) and can be enriched with optional semantic slots. This keeps diagrams usable in live editors, documentation pages, and agent-generated artifacts without requiring a large design-token object.

> **Palette is the registry kind.** Every built-in theme registers as a
> palette-only *style*, so its stable input name works anywhere a style is accepted and
> composes with full looks by stacking: `{ style: ['hand-drawn', 'dracula'] }`
> renders hand-drawn geometry with the Dracula palette. See
> [docs/style-authoring.md](./style-authoring.md) for the full model.

## Two-color foundation

```ts
import { renderMermaidSVG } from 'agentic-mermaid'

const svg = renderMermaidSVG(source, {
  bg: '#0B1020',
  fg: '#E5E7EB',
})
```

From those colors the renderer derives contrast-aware node fills, labels, edges, and accents. This is the safest default for agents: pick readable foreground/background colors and let the renderer complete the palette.

Automatic card and boundary outlines adjust the palette's `border` candidate
to reach at least 3:1 contrast against a known opaque diagram background. This
shared rule also applies when a look and palette are stacked. Authored strokes
and `roles.node.borderColor` / `roles.group.borderColor` keep their exact paint,
including intentionally hidden or zero-width outlines.

Opaque literal background and foreground colors (hex, RGB, HSL and named
colors) share concrete contrast resolution for outlines, text and connectors.
Palette tokens and host-controlled CSS variable references remain authored.

This background comparison does not certify contrast against nested custom
fills or an arbitrary host behind a transparent SVG. Unresolved CSS colors and
translucent outline/background colors retain their supplied values; choose and
check those paints against the actual embedding surface.
The ratio compares source paint colors. Check thin outlines at the intended
PNG size, since antialiasing changes individual pixels.

## Enriched mode

Use extra slots when your product already has semantic tokens:

```ts
const svg = renderMermaidSVG(source, {
  bg: 'var(--canvas)',
  fg: 'var(--text)',
  line: 'var(--line)',
  accent: 'var(--accent)',
  muted: 'var(--muted)',
  surface: 'var(--surface)',
  border: 'var(--border)',
})
```

Slots:

| Slot | Meaning |
|---|---|
| `bg` | SVG canvas/background. |
| `fg` | Primary text. |
| `line` | Connectors and strokes. |
| `accent` | Arrowheads and emphasis. |
| `muted` | Secondary labels. |
| `surface` | Node/card fill. |
| `border` | Node/card border. |

## CSS custom properties

CSS variables are first-class values:

```ts
const svg = renderMermaidSVG(source, {
  bg: 'var(--diagram-bg)',
  fg: 'var(--diagram-fg)',
  accent: 'var(--diagram-accent)',
  embedFontImport: false,
})
```

Because the generated SVG references variables directly, host pages can switch light/dark themes without re-rendering the diagram.

## Built-in Palettes

`theme` is not a registry kind; discovery returns `kind: "palette"`.
Discover current Palette identities and stable input names with
`knownStyleDescriptors()` or `am styles`; this guide does not copy the registry.

```ts
import { renderMermaidSVG } from 'agentic-mermaid'

const svg = renderMermaidSVG(source, { style: 'tokyo-night' })
```

## Custom themes

```ts
import type { DiagramColors } from 'agentic-mermaid'

export const myTheme: DiagramColors = {
  bg: '#111827',
  fg: '#F9FAFB',
  line: '#64748B',
  accent: '#38BDF8',
  muted: '#94A3B8',
  surface: '#1F2937',
  border: '#334155',
}
```

Then pass it to any renderer:

```ts
renderMermaidSVG(source, myTheme)
```

## Shiki compatibility

Turn a Shiki or VS Code theme into a diagram palette:

```ts no-run
import { fromShikiTheme, renderMermaidSVG } from 'agentic-mermaid'
import githubDark from 'shiki/themes/github-dark.mjs'

const colors = fromShikiTheme(githubDark)
const svg = renderMermaidSVG(source, colors)
```

`fromShikiTheme(theme)` reads the editor background/foreground and token colors, then maps them to Agentic Mermaid's semantic slots.

## Style + Palette stacks

Use `style` for renderer treatment and palettes, not Mermaid source edits:

```ts
const svg = renderMermaidSVG(source, {
  style: ['publication-figure', 'zinc-light'],
  seed: 2,
})
```

For per-element emphasis, keep using Mermaid-native directives such as `classDef`, `class`, `style`, and `linkStyle`. See [`api.md`](./api.md) for the full `RenderOptions` table.

## Security and fonts

Default SVG output makes no font requests. Google Fonts `@import` rules are
opt-in via `embedFontImport: true`; the selected font then gets one only when it
is a single plain family name, and class and ER diagrams can also import
JetBrains Mono for monospace labels. CSS-variable references and font stacks do
not produce an import for the selected family.

```ts
renderMermaidSVG(source, { embedFontImport: true })
```

For untrusted diagrams, use strict mode:

```ts
renderMermaidSVG(source, { security: 'strict' })
```

`security: 'strict'` disables external-fetch references, including font imports
requested with `embedFontImport: true`, and is the recommended default for
untrusted diagrams.

For custom Style font selection, browser faces, PNG `fontDirs`, fallbacks, and
output-surface differences, see [Fonts in custom styles](./custom-fonts.md).
