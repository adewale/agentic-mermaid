# React integration

Browser-rendered React components should use the browser ESM entry. It loads the
selected diagram family on demand and does not pull the Node/native package
entry into a client bundle.

## Basic component

```tsx
'use client'

import { useEffect, useId, useRef, useState } from 'react'
import { renderMermaidSVGAsync } from 'agentic-mermaid/browser/lazy'

export function MermaidDiagram({ source }: { source: string }) {
  const output = useRef<HTMLDivElement>(null)
  const idPrefix = `diagram-${useId().replace(/[^a-zA-Z0-9_-]/g, '')}`
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let current = true
    const host = output.current
    if (!host) return
    host.replaceChildren()
    setLoading(true)
    setError('')
    renderMermaidSVGAsync(source, { security: 'strict', idPrefix }).then(
      result => {
        if (!current) return
        const parsed = new DOMParser().parseFromString(result, 'image/svg+xml')
        if (parsed.querySelector('parsererror') || parsed.documentElement.localName !== 'svg') {
          setError('Renderer returned invalid SVG')
          setLoading(false)
          return
        }
        host.replaceChildren(document.importNode(parsed.documentElement, true))
        setLoading(false)
        setError('')
      },
    ).catch(cause => {
      if (!current) return
      setError(cause instanceof Error ? cause.message : String(cause))
      setLoading(false)
    })
    return () => { current = false }
  }, [source, idPrefix])

  return <>
    {error && <pre role="alert">{error}</pre>}
    <div ref={output} className="diagram diagram-surface" aria-busy={loading} />
  </>
}
```

`security: 'strict'` removes external-fetch references and is the safest default
for user- or agent-generated diagrams. The cancellation guard prevents an older
render from replacing a newer source after it resolves. The per-component
`idPrefix` prevents collisions between SVG definitions in multiple diagrams.
Insert only this renderer's strict output, not arbitrary SVG: XML parsing is
not sanitization. Rendering policy and the host's DOM/CSP policy remain separate.

This basic recipe assumes the host does not enforce Trusted Types. With
`require-trusted-types-for 'script'`, `DOMParser.parseFromString` is also a
protected sink: adapt insertion through the application's reviewed,
narrowly scoped TrustedHTML policy. Do not add a permissive default policy or
disable CSP to make the example work. See [`browser.md`](./browser.md).

## Theme from CSS variables

```tsx
const svg = await renderMermaidSVGAsync(source, {
  bg: 'var(--diagram-bg)',
  fg: 'var(--diagram-fg)',
  accent: 'var(--diagram-accent)',
  surface: 'var(--diagram-surface)',
  border: 'var(--diagram-border)',
  embedFontImport: false,
})
```

```css
.diagram-surface {
  --diagram-bg: #ffffff;
  --diagram-fg: #18181b;
  --diagram-accent: #2563eb;
  --diagram-surface: #f8fafc;
  --diagram-border: #cbd5e1;
}

.dark .diagram-surface {
  --diagram-bg: #0f172a;
  --diagram-fg: #f8fafc;
  --diagram-accent: #38bdf8;
  --diagram-surface: #1e293b;
  --diagram-border: #334155;
}
```

Because the SVG keeps CSS variables in place, toggling `.dark` updates existing diagrams without re-rendering.

## PNG export button

PNG rendering returns bytes. The native helper below needs a server action/API route or other Node-capable boundary where `@resvg/resvg-js` is available.

```ts
import { renderMermaidPNG } from 'agentic-mermaid/agent'

export function renderDiagramPng(source: string) {
  return renderMermaidPNG(source, { fitTo: { width: 1200 }, background: '#fff' })
}
```

For client-only exports, the root `agentic-mermaid` entry also exports a
host-injected browser PNG path: `renderMermaidPNGInBrowserWithReceipt(source,
options, output, rasterize)` or the reusable
`createMermaidBrowserPNGRenderer({ rasterize })`. No browser rasterizer ships
with the library: the host supplies `rasterize(securedSvg, context)` (for
example with Canvas/OffscreenCanvas), which must resolve to `{ png }` bytes at
exactly `context.rasterDimensions` on `context.rasterBackground`, and may report
`fontSources` and `diagnostics`. See [browser PNG details](./api-advanced.md#png-fonts-portability-and-rasterization). Otherwise, post
the source to a server endpoint.

## Error handling

The component above reports parse and render failures through its `role="alert"`
fallback. If a client workflow also needs structured parse/verify results, use
the runtime-neutral agent entry; do not import the Node/native
`agentic-mermaid/agent` entry into the browser bundle:

```ts
import { parseRegisteredMermaid, verifyMermaid } from 'agentic-mermaid/agent/core'
```

For server components, build steps, and API routes, the synchronous
`renderMermaidSVG` export from `agentic-mermaid` remains appropriate.

## See also

- [`api.md`](./api.md) for render options.
- [`theming.md`](./theming.md) for palette and CSS-variable details.
- [`config.md`](./config.md) for Mermaid frontmatter/init support.
