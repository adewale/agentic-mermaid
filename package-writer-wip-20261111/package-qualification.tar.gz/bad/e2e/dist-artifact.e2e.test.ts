// Built-artifact contracts with distinct browser/Node bundler and lazy-ELK risks.
// Installed Node/Bun fuzz and PNG parity live at the stronger tarball consumer boundary.
import { describe, test, expect, beforeAll } from 'bun:test'
import { spawnSync } from 'node:child_process'
import { existsSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { useTempDirs } from '../src/__tests__/helpers/temp-dir.ts'

const REPO = join(import.meta.dir, '..')
const DIST_CORE = join(REPO, 'dist', 'agent-core.js')
const DIST_ROOT = join(REPO, 'dist', 'index.js')
const BUILD_TIMEOUT_MS = 180_000
const RUN_TIMEOUT_MS = 180_000

function findNodeBinary(): string | null {
  const candidates = [process.env.NODE_BINARY, 'node', '/opt/node22/bin/node'].filter((x): x is string => Boolean(x))
  for (const candidate of candidates) {
    try { if (spawnSync(candidate, ['--version'], { encoding: 'utf8' }).status === 0) return candidate } catch {}
  }
  return null
}

const NODE = findNodeBinary()
if (!NODE) throw new Error('dist artifact gate requires a plain Node executable')

const temp = useTempDirs('am-dist-')

beforeAll(() => {
  const build = process.env.AM_CI_ARTIFACTS === '1' ? null : spawnSync('bun', ['run', 'build'], { cwd: REPO, encoding: 'utf8', timeout: BUILD_TIMEOUT_MS })
  // A broken build must fail loudly, not skip — that is exactly what shipping
  // would break.
  if ((build && build.status !== 0) || !existsSync(DIST_CORE)) {
    throw new Error(`Portable build is unavailable (status ${build?.status ?? 'missing transferred artifact'}); built artifact contracts cannot run.\n${build?.stderr ?? ''}`)
  }
}, BUILD_TIMEOUT_MS)

describe('built artifact bundler and deferred dependency contracts', () => {

  test('runtime-neutral agent entry bundles for a browser target', () => {
    const work = temp.dir('am-agent-core-browser-')
    const outfile = join(work, 'agent-core.js')
    const bundled = spawnSync('bun', ['build', DIST_CORE, '--target=browser', '--outfile', outfile], {
      cwd: REPO,
      encoding: 'utf8',
      timeout: BUILD_TIMEOUT_MS,
    })
    expect({ status: bundled.status, stderr: bundled.stderr }).toEqual({ status: 0, stderr: '' })
    expect(existsSync(outfile)).toBe(true)
    // A browser bundler resolves `#elk-constructor` to the bundled ELK, so an
    // ELK family lays out synchronously with no Node module loader.
    const rendered = spawnSync('bun', ['--eval', `const { renderMermaidSVG } = await import(${JSON.stringify(outfile)}); console.log(renderMermaidSVG('flowchart TD\\n  A -->|needs ELK| B', { fontMetrics: 'bundled-inter', graphLayout: { backend: 'elk', quality: 'balanced' } }).startsWith('<svg'))`], { cwd: work, encoding: 'utf8', timeout: RUN_TIMEOUT_MS })
    expect({ status: rendered.status, stdout: rendered.stdout.trim(), stderr: rendered.stderr }).toEqual({ status: 0, stdout: 'true', stderr: '' })
  }, BUILD_TIMEOUT_MS + RUN_TIMEOUT_MS)

  test('Node loads solver and optional kernels only on demand', () => {
    const probe = `
      import assert from 'node:assert/strict'
      import { createRequire } from 'node:module'
      const require = createRequire(import.meta.url)
      const elkImplementation = require.resolve('elkjs/lib/elk.bundled.js')
      const loaded = () => { const files = Object.keys(require.cache); return [files.includes(elkImplementation), files.some(path => path.endsWith('/inter-metrics-kernel.cjs')), files.some(path => path.endsWith('/layout-optimization.cjs'))] }
      const { renderMermaidSVG } = await import(${JSON.stringify(DIST_CORE)})
      const { renderMermaidSVGWithReceipt, renderContractDigest } = await import(${JSON.stringify(DIST_ROOT)})
      const states = [loaded()]
      renderMermaidSVG('sequenceDiagram\\n  A->>B: hi')
      states.push(loaded())
      const native = renderMermaidSVGWithReceipt('flowchart TD\\n  A --> B', { graphLayout: { backend: 'agentic', fallback: 'none' } })
      assert.equal(native.receipt.layoutCertification.status, 'passed')
      assert.equal(native.receipt.layoutCertification.coverage.conditional, 0)
      assert.equal(native.receipt.layoutCertification.checks.markers, 1)
      assert.equal(native.receipt.layoutCertification.outputDigest, renderContractDigest(native.svg))
      const edge = native.svg.match(/<(?:polyline|line|path)\\b[^>]*data-role="edge"[^>]*>/)?.[0]
      assert.ok(edge, 'Native actual edge must be emitted')
      assert.match(edge, /data-from="A"/)
      assert.match(edge, /data-to="B"/)
      assert.match(edge, /marker-end="url\\(#.+\\)"/)
      states.push(loaded())
      renderMermaidSVG('flowchart TD\\n  A -->|needs ELK| B\\n  B --> A', { graphLayout: { backend: 'elk' } })
      states.push(loaded())
      renderMermaidSVG('flowchart TD\\n A --> B', { fontMetrics: 'bundled-inter' })
      states.push(loaded())
      renderMermaidSVG('flowchart TD\\n A --> B', { graphLayout: { backend: 'elk', quality: 'balanced' } })
      states.push(loaded())
      console.log(JSON.stringify(states))`
    const run = spawnSync(NODE, ['--input-type=module', '--eval', probe], { cwd: REPO, encoding: 'utf8', timeout: RUN_TIMEOUT_MS, env: { ...process.env, AGENTIC_MERMAID_SCENE_ASSERTIONS: '0', AGENTIC_MERMAID_ELK_CACHE: '0' } })
    expect({ status: run.status, stderr: run.stderr }).toEqual({ status: 0, stderr: '' })
    // Import, sequence, certified forest, then an explicit ELK request.
    expect(JSON.parse(run.stdout)).toEqual([[false, false, false], [false, false, false], [false, false, false], [true, false, false], [true, true, false], [true, true, true]])
  }, RUN_TIMEOUT_MS)

  test('a Node bundle of the agent entry carries ELK and needs no node_modules', () => {
    const work = temp.dir('am-agent-core-node-bundle-')
    const entry = join(work, 'entry.mjs')
    writeFileSync(entry, `import { renderMermaidSVG } from ${JSON.stringify(DIST_CORE)}\nconsole.log(renderMermaidSVG('flowchart TD\\n  A -->|needs ELK| B', { fontMetrics: 'bundled-inter', graphLayout: { backend: 'elk', quality: 'balanced' } }).startsWith('<svg'))\n`)
    for (const format of ['esm', 'cjs'] as const) {
      const outfile = join(work, `bundle.${format === 'esm' ? 'mjs' : 'cjs'}`)
      const bundled = spawnSync('bun', ['build', entry, '--target=node', `--format=${format}`, '--outfile', outfile], { cwd: work, encoding: 'utf8', timeout: BUILD_TIMEOUT_MS })
      expect({ format, status: bundled.status, stderr: bundled.stderr }).toEqual({ format, status: 0, stderr: '' })
      const rendered = spawnSync(NODE, [outfile], { cwd: work, encoding: 'utf8', timeout: RUN_TIMEOUT_MS })
      expect({ format, status: rendered.status, stdout: rendered.stdout.trim(), stderr: rendered.stderr }).toEqual({ format, status: 0, stdout: 'true', stderr: '' })
    }
  }, BUILD_TIMEOUT_MS + RUN_TIMEOUT_MS)
})
