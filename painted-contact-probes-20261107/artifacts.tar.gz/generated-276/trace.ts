import { readFileSync, writeFileSync } from 'node:fs'
import { parseMermaid } from '/tmp/pr449-main-integration-20261029-762/src/parser.ts'
import { LAYOUT_PIPELINE, layoutGraphSync } from '/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts'
import { countEdgeCrossings } from '/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts'
const root='/tmp/pr449-week-comparison-20261101/forest-placement-deafff/generated-276'
const source=readFileSync(root+'/source.mmd','utf8'), rows:any[]=[]
const snapshot=(c:any)=>({crossings:countEdgeCrossings(c.edges),bends:c.edges.reduce((n:number,e:any)=>n+Math.max(0,e.points.length-2),0), nodes:c.nodes.map((n:any)=>({id:n.id,x:n.x,y:n.y,width:n.width,height:n.height})), edges:c.edges.map((e:any)=>({source:e.source,target:e.target,id:e.id,points:e.points.map((p:any)=>({...p})),labelPosition:e.labelPosition&&{...e.labelPosition}}))})
const old=LAYOUT_PIPELINE.map(p=>p.run)
try {
  for(const [index,pass]of LAYOUT_PIPELINE.entries()) (pass as any).run=(ctx:any)=>{const before=snapshot(ctx);const value=old[index]!(ctx);const after=snapshot(ctx);rows.push({pass:pass.id,before,after});return value}
  const result=layoutGraphSync(parseMermaid(source),{graphLayout:{backend:'agentic',fallback:'none'}})
  writeFileSync(root+'/TRACE.json',JSON.stringify({rows,result},null,2)+'\n')
  console.log(JSON.stringify({finalCrossings:countEdgeCrossings(result.edges),passes:rows.map(r=>({pass:r.pass,before:r.before.crossings,after:r.after.crossings,bends:r.after.bends}))},null,2))
} finally { for(const [index,pass]of LAYOUT_PIPELINE.entries()) (pass as any).run=old[index] }
