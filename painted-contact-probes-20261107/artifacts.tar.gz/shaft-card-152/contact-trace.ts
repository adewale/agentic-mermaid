import{readFileSync,writeFileSync}from'node:fs'
import{parseMermaid}from'/tmp/pr449-main-integration-20261029-762/src/parser.ts'
import{LAYOUT_PIPELINE,layoutGraphSync}from'/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts'
import{bodyShaftPaintContext}from'/tmp/pr449-main-integration-20261029-762/src/layout/graph-paint-support.ts'
import{withinGraphInkBudget}from'/tmp/pr449-main-integration-20261029-762/src/layout/label-conflicts.ts'
const root='/tmp/pr449-week-comparison-20261101/forest-placement-deafff/shaft-card-152',p=LAYOUT_PIPELINE.find(p=>p.id==='rerouteEdgesThroughNodes')!,old=p.run,rows:any[]=[]
try{
 (p as any).run=(ctx:any)=>{const edge=ctx.edges.find((e:any)=>e.source==='n16'&&e.target==='n12'),node=ctx.nodes.find((n:any)=>n.id==='n4');let work=0;const contact=bodyShaftPaintContext(ctx.style,n=>(work+=n,true));const row={eligible:withinGraphInkBudget(ctx.nodes,ctx.edges,ctx.groups),curve:edge.curve,edgeStyle:edge.style,bendRadius:ctx.style.edgeBendRadius,cornerRadius:ctx.style.cornerRadius,contact:contact(edge,edge.points,node),work,node,points:edge.points};const value=old(ctx);rows.push({...row,after:edge.points});return value}
 const result=layoutGraphSync(parseMermaid(JSON.parse(readFileSync(root+'/before/job.json','utf8')).source),{graphLayout:{backend:'agentic',fallback:'none'}})
 writeFileSync(root+'/CONTACT-TRACE.json',JSON.stringify(rows,null,2)+'\n');console.log(rows.map(x=>({eligible:x.eligible,curve:x.curve,bendRadius:x.bendRadius,cornerRadius:x.cornerRadius,contact:x.contact,changed:JSON.stringify(x.points)!==JSON.stringify(x.after)})))
}finally{(p as any).run=old}
