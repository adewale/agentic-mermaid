import {readFileSync,writeFileSync} from 'node:fs'
import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const root='/tmp/pr449-week-comparison-20261101/marker-capacity-6edd',rows:any[]=[]
;(globalThis as any).__pr449MarkerPrep=(data:any)=>{
 const n=data.nodes.findIndex((n:any)=>n.id==='n7')
 rows.push({order:data.order,node:data.nodes[n],span:data.spans[n],incoming:data.incoming[n],outgoing:data.outgoing[n],maximumStroke:data.maximumStroke,margin:data.margin})
}
const job=JSON.parse(readFileSync(root+'/job201.json','utf8')),product=renderMermaidSVGWithReceipt(job.source,job.options)
writeFileSync(root+'/PREPARATION.json',JSON.stringify(rows,null,2)+'\n');writeFileSync(root+'/preparation-product.json',JSON.stringify(product)+'\n');console.log(JSON.stringify({proof:product.receipt.layoutCertification?.status,rows}))
