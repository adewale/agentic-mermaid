import fs from 'node:fs';
import path from 'node:path';
import {gunzipSync} from 'node:zlib';
import {createRequire} from 'node:module';

const repo='/tmp/pr449-main-integration-20261029-762';
const evidence=process.argv[2] ?? '/tmp/pr449-week-comparison-20261101/performance-review-bebf1d52f';
const output=path.dirname(new URL(import.meta.url).pathname);
const require=createRequire(repo+'/package.json');
const {TraceMap,originalPositionFor}=require('@jridgewell/trace-mapping');
const readGz=file=>JSON.parse(gunzipSync(fs.readFileSync(file)).toString());
const frames=new Map();
const aggregate=new Map();
const groups=new Map();
const phaseRows=[];
const make=()=>new Map();
const add=(bank,key,delta,inclusive=false)=>{
  let entry=bank.get(key);
  if(!entry){entry={selfSamples:0,selfWeightUs:0,largestSelfDeltaUs:0,inclusiveSamples:0,inclusiveWeightUs:0,over5msSelfSamples:0,over20msSelfSamples:0,over100msSelfSamples:0};bank.set(key,entry);}
  if(inclusive){entry.inclusiveSamples++;entry.inclusiveWeightUs+=delta;}
  else {entry.selfSamples++;entry.selfWeightUs+=delta;entry.largestSelfDeltaUs=Math.max(entry.largestSelfDeltaUs,delta);entry.over5msSelfSamples+=Number(delta>5000);entry.over20msSelfSamples+=Number(delta>20000);entry.over100msSelfSamples+=Number(delta>100000);}
};
const records=bank=>[...bank].map(([key,v])=>({...frames.get(key),selfSamples:v.selfSamples,selfSampleWeightMs:v.selfWeightUs/1000,largestSelfDeltaMs:v.largestSelfDeltaUs/1000,selfWeightWithoutLargestMs:(v.selfWeightUs-v.largestSelfDeltaUs)/1000,inclusiveSamples:v.inclusiveSamples,inclusiveSampleWeightMs:v.inclusiveWeightUs/1000,over5msSelfSamples:v.over5msSelfSamples,over20msSelfSamples:v.over20msSelfSamples,over100msSelfSamples:v.over100msSelfSamples}));
const rank=bank=>records(bank).filter(x=>x.selfSamples>0).sort((a,b)=>b.selfSampleWeightMs-a.selfSampleWeightMs || b.selfSamples-a.selfSamples);

for(const job of fs.readdirSync(evidence).filter(name=>fs.existsSync(path.join(evidence,name,'RESULT.json.gz'))).sort()){
  const dir=path.join(evidence,job),result=readGz(path.join(dir,'RESULT.json.gz'));
  const rawMaps=readGz(path.join(dir,'source-maps.json.gz')),traces=new Map();
  const getTrace=url=>{if(!traces.has(url))traces.set(url,rawMaps[url] ? new TraceMap(rawMaps[url],url) : undefined);return traces.get(url);};
  const mappingRows=[];
  const mapFrame=frame=>{
    const generated={url:frame.url,line:frame.lineNumber+1,column:frame.columnNumber+1};
    if(!frame.url.startsWith('file://'+repo+'/src/'))return {project:false,generated};
    const trace=getTrace(frame.url);
    const mapped=trace && frame.lineNumber>=0 && frame.columnNumber>=0 ? originalPositionFor(trace,{line:frame.lineNumber+1,column:frame.columnNumber}) : undefined;
    if(!mapped?.source || mapped.line===null || mapped.column===null)return {project:true,mapped:false,generated,function:frame.functionName||'<anonymous>'};
    const record={function:frame.functionName||mapped.name||'<anonymous>',url:mapped.source,line:mapped.line,column:mapped.column+1};
    const key=JSON.stringify(record);
    if(!frames.has(key))frames.set(key,record);
    mappingRows.push({...record,generated});
    return {project:true,mapped:true,key,generated};
  };
  for(const phase of ['repeat1','repeat2','edit']){
    const profile=readGz(path.join(dir,phase+'.cpuprofile.gz'));
    const row=readGz(path.join(dir,phase+'.row.json.gz'));
    const nodes=new Map(profile.nodes.map(node=>[node.id,node]));
    const parent=new Map(profile.nodes.flatMap(node=>(node.children??[]).map(child=>[child,node.id])));
    const mapped=new Map(profile.nodes.map(node=>[node.id,mapFrame(node.callFrame)]));
    const ancestors=new Map();
    const ancestorsOf=id=>{if(!ancestors.has(id)){const values=[],seen=new Set();for(let cursor=id;cursor!==undefined&&!seen.has(cursor);cursor=parent.get(cursor)){seen.add(cursor);values.push(cursor);}ancestors.set(id,values);}return ancestors.get(id);};
    const bank=make(),nonSource=make();
    const groupKey=[result.job.case,result.job.backend,result.cache,phase==='edit'?'edit':'repeats'].join('/');
    if(!groups.has(groupKey))groups.set(groupKey,{bank:make(),windows:[],rowCount:0});
    const group=groups.get(groupKey);group.rowCount++;
    let totalUs=0,maxUs=-Infinity,maxLeaf,sourceN=0,mappedN=0,unmappedN=0,mappedUs=0,unmappedUs=0;
    let over1ms=0,over5ms=0,over20ms=0,over100ms=0;
    const samples=profile.samples??[],deltas=profile.timeDeltas??[];
    if(samples.length!==deltas.length)throw new Error('Mismatched samples/timeDeltas: '+job+'/'+phase);
    for(let index=0;index<samples.length;index++){
      const id=samples[index],delta=deltas[index],leaf=mapped.get(id),node=nodes.get(id);
      totalUs+=delta;if(delta>maxUs){maxUs=delta;maxLeaf=id;}
      over1ms+=Number(delta>1000);over5ms+=Number(delta>5000);over20ms+=Number(delta>20000);over100ms+=Number(delta>100000);
      if(leaf.project){sourceN++;if(leaf.mapped){mappedN++;mappedUs+=delta;}else{unmappedN++;unmappedUs+=delta;}}
      if(leaf.mapped){for(const target of [bank,aggregate,group.bank])add(target,leaf.key,delta);}
      else {
        const key=JSON.stringify({function:node.callFrame.functionName||'<anonymous>',url:node.callFrame.url,line:node.callFrame.lineNumber+1,column:node.callFrame.columnNumber+1,mapping:leaf.project?'unmapped-project':'non-project'});
        if(!frames.has(key))frames.set(key,JSON.parse(key));add(nonSource,key,delta);
      }
      const keys=new Set(ancestorsOf(id).map(ancestor=>mapped.get(ancestor).key).filter(Boolean));
      for(const key of keys)for(const target of [bank,aggregate,group.bank])add(target,key,delta,true);
    }
    const largest=nodes.get(maxLeaf)?.callFrame;
    const reliability={samples:samples.length,nominalIntervalUs:result.samplingIntervalUs,profileSpanMs:(profile.endTime-profile.startTime)/1000,sampleWeightMs:totalUs/1000,unweightedTailMs:(profile.endTime-profile.startTime-totalUs)/1000,largestDeltaMs:maxUs/1000,deltaOver1ms:over1ms,deltaOver5ms:over5ms,deltaOver20ms:over20ms,deltaOver100ms:over100ms,projectLeafSamples:sourceN,mappedProjectLeafSamples:mappedN,unmappedProjectLeafSamples:unmappedN,mappedProjectLeafWeightMs:mappedUs/1000,unmappedProjectLeafWeightMs:unmappedUs/1000,largestDeltaLeaf:largest,largestDeltaMapped:mapped.get(maxLeaf)};
    const summary={job,phase,case:result.job.case,backend:result.job.backend,cache:result.cache,status:row.status,wallMs:row.wallMs,cpuMs:row.cpuMs,bytes:row.bytes,proofStatus:row.proof?.status,wholeSvgExactWarmup:row.wholeSvgExactWarmup,entireReceiptExactWarmup:row.entireReceiptExactWarmup,editChanged:row.editChanged,stages:row.stages,reliability,top5ProjectSelf:rank(bank).slice(0,5),top5NonProjectOrUnmappedSelf:rank(nonSource).slice(0,5)};
    phaseRows.push(summary);group.windows.push({job,phase,wallMs:row.wallMs,cpuMs:row.cpuMs,reliability});
  }
  const uniqueMappings=[...new Map(mappingRows.map(value=>[JSON.stringify(value),value])).values()];
  fs.writeFileSync(path.join(output,job+'-frame-mappings.json'),JSON.stringify(uniqueMappings,null,2)+'\n');
}
const grouped=[...groups].map(([key,g])=>({key,windows:g.rowCount,meanWallMs:g.windows.reduce((n,r)=>n+r.wallMs,0)/g.rowCount,meanProcessCpuMs:g.windows.reduce((n,r)=>n+r.cpuMs,0)/g.rowCount,windowReliability:g.windows,top5ProjectSelf:rank(g.bank).slice(0,5)}));
const globalRank=rank(aggregate);
const report={scope:'Review only. V8 elapsed sample-delta weights are not exclusive CPU durations. Exclusive leaf samples and inclusive stack presence are reported separately; recursively repeated function identities count once inclusively per sample. All source positions use per-job transform source maps, zero-based V8 positions converted to one-based original lines/columns via GLB mapping. Unmapped project positions remain explicitly unmapped and excluded from original-source ranking.',evidence,phaseCount:phaseRows.length,top5ProjectSelf:globalRank.slice(0,5),top5ProjectBySampleCount:[...globalRank].sort((a,b)=>b.selfSamples-a.selfSamples).slice(0,5),allProjectSelf:globalRank,groups:grouped,phases:phaseRows};
fs.writeFileSync(path.join(output,'analysis.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({output,phaseCount:report.phaseCount,top5ProjectSelf:report.top5ProjectSelf,top5ProjectBySampleCount:report.top5ProjectBySampleCount,groups:grouped.map(g=>({key:g.key,meanWallMs:g.meanWallMs,meanProcessCpuMs:g.meanProcessCpuMs,top5:g.top5ProjectSelf.map(x=>({function:x.function,file:x.url.split('/src/')[1],line:x.line,samples:x.selfSamples,weightMs:x.selfSampleWeightMs,maxDeltaMs:x.largestSelfDeltaMs})),largestWindowDeltaMs:Math.max(...g.windowReliability.map(w=>w.reliability.largestDeltaMs))}))},null,2));
