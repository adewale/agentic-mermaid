import json,zipfile,pathlib,hashlib
r=pathlib.Path('/tmp/pr449-week-comparison-20261101/marker-capacity-6edd');old=zipfile.ZipFile('/tmp/pr449-week-comparison-20261101/contact-origin-3234/generated-layouts-6edd.zip');new=zipfile.ZipFile(r/'generated-layouts-4db9.zip');rows=[];totals=[]
for name in sorted(n for n in new.namelist() if n.endswith(('agentic.json','elk.json'))):
 a=json.loads(old.read(name));b=json.loads(new.read(name));assert a['renderOptions']==b['renderOptions'],name
 aa={x['id']:x for x in a['samples']};bb={x['id']:x for x in b['samples']};assert list(aa)==list(bb),name
 summary={'snapshot':name,'cases':len(aa),'svgChanged':0,'layoutChanged':0,'deliveryChanged':0,'PtoU':0,'UtoP':0}
 for key,x in aa.items():
  y=bb[key];assert x['source']==y['source'],key
  pc=lambda v:v.get('metrics',{}).get('paintCertification',{}).get('status')
  changed=x.get('svg')!=y.get('svg');layout=x.get('layout')!=y.get('layout');delivery=x['ok']!=y['ok'];trans=(pc(x),pc(y));summary['svgChanged']+=changed;summary['layoutChanged']+=layout;summary['deliveryChanged']+=delivery;summary['PtoU']+=trans==('passed','unverified');summary['UtoP']+=trans==('unverified','passed')
  if changed or layout or delivery or trans[0]!=trans[1]:
   row={'snapshot':name,'id':key,'delivery':[x['ok'],y['ok']],'svgChanged':changed,'layoutChanged':layout,'proof':trans,'beforeMetrics':x.get('metrics'),'afterMetrics':y.get('metrics'),'beforeSHA256':hashlib.sha256(x.get('svg','').encode()).hexdigest(),'afterSHA256':hashlib.sha256(y.get('svg','').encode()).hexdigest()};rows.append(row)
 totals.append(summary)
result={'before':'6edd3fd3b','after':'4db9d6db2','scope':'Existing CI snapshots; matched source/options/identities per backend. Comparison validation, not new rendering calls or a general workload ranking. Full adverse metrics and proof/delivery transitions retained.','totals':totals,'changed':rows};(r/'CI-COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(totals,indent=2));print('CHANGED',[(x['snapshot'],x['id'],x['proof'],x['svgChanged'],x['layoutChanged']) for x in rows])
