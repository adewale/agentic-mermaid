Read-only GPT-6.1 Sol High review by /root/joint_caption_review,7 November.

Before intervention, both enrolled subroutine targets have seven oriented face ports and36.9px height. Rank-core proportional fallback gives36.9/8=4.6125px pitch. Cycle restoration preserves node metadata and reverses routes; shortening preserves endpoints. Preparation excludes subroutines and uses authoredmax(in,out), undercounting ports combined by cycle orientation. Threshold removal alone is falsified by241: authoredmax4 cannot enlarge its existing face enough.

The new ordinary-head branch reuses existing measured spans, sizing and cache-keyed minimumPortSpacing. Its all-endpoint incident array is correctly prepaid withN+1slots and2units/edge in existing ledgers; invisible constraints count too. Legacy visible counts and wide-marker branch remain. Self-loops count twice, matching helper spokes; ordinary long-edge helpers add no extra original-node endpoints. ServedPositionedNode dimensions come directly from measured dimensions, so growth is actualbody capacity rather than virtualport space. Explicit-size/semantic exclusions remain.

The public final-SVG SAT oracle is independent: .75 times axisnorm reserves both .375round-stroke expansions. A separating axis proves written triangle/stroke support separation, conservatively including clipped parts. It is not a raster/readability certificate; coordinator independently raster-attributed selected heads afterward.

No blocking finding. Counting all incident endpoints is conservative and can enlarge an already-clear acyclic mixed-direction node; actualpairedcontrol is recorded separately. Extra preparation lowers remaining allowance near original caps. Whole matchedCI and realpayload/browser qualification remain necessary; localpasscounts do not establish preservation.

Reviewer performed no edits, tests, builds or publicrendercalls.
