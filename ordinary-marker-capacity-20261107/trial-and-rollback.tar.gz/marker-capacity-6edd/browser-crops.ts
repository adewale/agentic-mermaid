import {readFileSync,writeFileSync} from 'node:fs'
import {gunzipSync} from 'node:zlib'
import {createHash} from 'node:crypto'
import {chromium} from '/tmp/pr449-main-integration-20261029-762/node_modules/playwright/index.mjs'
import {SaxesParser} from '/tmp/pr449-main-integration-20261029-762/node_modules/saxes/saxes.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const repo='/tmp/pr449-main-integration-20261029-762',root='/tmp/pr449-week-comparison-20261101/marker-capacity-6edd'
const faces=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const b=readFileSync(repo+'/'+f.path);if(createHash('sha256').update(b).digest('hex')!==f.sha256)throw Error('font mismatch');const format=b.subarray(0,4).toString()==='wOF2'?'woff2':'truetype';return `@font-face{font-family:Inter;src:url(data:font/${format==='woff2'?'woff2':'ttf'};base64,${b.toString('base64')}) format('${format}');font-weight:${f.weight};font-style:${f.style}}`}).join('\n')
const browser=await chromium.launch({headless:true}),rows=[]
try{
 const context=await browser.newContext({viewport:{width:2600,height:900},deviceScaleFactor:3}),page=await context.newPage();await page.route('**/*',r=>r.abort())
 for(const arm of ['before','after']){
  const path=arm==='before'?root+'/profile-before/warmup.svg.gz':root+'/final201/actual.svg.gz',raw=gunzipSync(readFileSync(path)).toString(),svg=inlineFontVarForRaster(raw)
  let node:Record<string,string>|undefined;const parser=new SaxesParser({xmlns:true});parser.on('opentag',t=>{const a=Object.fromEntries(Object.values(t.attributes).map(a=>[a.name,a.value]));if(a['data-id']==='node-shape:n7'&&t.local==='rect')node=a});parser.write(raw).close();if(!node)throw Error('target missing')
  const clip={x:Number(node.x)-5,y:Number(node.y)-8,width:135,height:88};await page.setContent(`<style>html,body{margin:0;background:white}${faces}</style>${svg}`);await page.evaluate(()=>document.fonts.ready)
  if(!await page.evaluate(()=>document.fonts.check('500 14px Inter')))throw Error('Inter not loaded')
  await page.screenshot({path:root+'/'+arm+'-crop.png',clip});rows.push({arm,clip,svgSHA256:createHash('sha256').update(raw).digest('hex'),node})
 }
 writeFileSync(root+'/CROPS.json',JSON.stringify({engine:'Chromium actual saved SVG; unchanged geometry',font:'manifest-verified Inter with actual file format/weight/style; network aborted',scale:3,scope:'Same scale and target-top anchoring; served target grows36.9→56.5px. Separate Resvg masks quantify selected head contribution.',rows},null,2)+'\n');console.log(JSON.stringify(rows.map(({node,...r})=>r)))
}finally{await browser.close()}
