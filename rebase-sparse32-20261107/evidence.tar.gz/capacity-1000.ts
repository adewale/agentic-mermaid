import * as marks from '/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts'
import { preparePixelText } from '/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts'
import { tipAnchoredArrow, serializeMarkerResource } from '/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts'
import { drawNative } from '/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts'
import { nativeEmissionWorkOf } from '/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts'
import { certifyNativePaint, certifyScenePaint } from '/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts'
import { gzipSync } from 'node:zlib'
import { writeFileSync } from 'node:fs'
const out=process.argv[2]!
const rows=[]
for (const [markerCount,definitions] of [[32,true]] as const) {
 const width=200,height=31000,colors={bg:'#fff',fg:'#111'}
 const block=preparePixelText('x',{fontSize:12,fontWeight:400})
 const marker=tipAnchoredArrow('decorative-arrow',{width:8,height:5},'end',{fill:'#111',stroke:'#111',strokeWidth:'0.75'},'userSpaceOnUse')
 const context={positioned:{width,height},colors,resolved:{renderOptions:{}}}
 const producer=(factory:any)=>({family:'flowchart',width,height,colors,transparent:false,parts:[
  factory.documentOpen({id:'root',width,height,colors,transparent:false,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="200" height="31000">'),
  ...(definitions?[factory.definitions({id:'resources'},'<defs>'+serializeMarkerResource(marker)+'</defs>')]:[]),
  ...Array.from({length:markerCount},(_,index)=>factory.connector({id:'chrome:'+index,role:'chrome',lineStyle:'solid',geometry:{kind:'line',x1:20,y1:40+index*20,x2:60,y2:40+index*20},paint:{stroke:'#111',strokeWidth:'1'},markers:{end:marker}})),
  ...Array.from({length:1000},(_,index)=>factory.text({id:'text:'+index,role:'label',text:'x',block,x:20,y:1000+index*20,fontSize:12,anchor:'start',paint:{fill:'#111'}})),
  factory.documentClose()
 ]})
 const drawing=drawNative(producer,context,'flowchart')
 const work=nativeEmissionWorkOf(drawing.paint)
 const direct=certifyScenePaint(producer(marks))
 const emitted=certifyNativePaint(drawing.header,drawing.paint)
 const row={labelCount:1000,markerCount,definitions,svgBytes:Buffer.byteLength(drawing.svg),emission:work,direct,emitted,debug:(globalThis as any).__sparseBudgetTrace}
 rows.push(row);console.log(JSON.stringify({markerCount,definitions,emission:work,direct:direct.status,emitted:emitted.status,checks:emitted.checks}))
 writeFileSync(out+'/'+markerCount+'-'+definitions+'.svg.gz',gzipSync(drawing.svg))
}
writeFileSync(out+'/RESULT.json',JSON.stringify(rows,null,2)+'\n')

