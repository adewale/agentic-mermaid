from pathlib import Path
import hashlib,io,json,posixpath,re,tarfile,zipfile
root=Path('/dev/shm/pr449-four-final-20261111')
zip_path=root/'CI689-verified-test-package.zip'
assert hashlib.sha256(zip_path.read_bytes()).hexdigest()=='a593abf15ae7e5364883633552b1b52ed018c20afaf94990084745090705c8d1'
with zipfile.ZipFile(zip_path) as z:
    manifest=json.loads(z.read('package-manifest.json')); tgz=z.read('package.tgz')
assert hashlib.sha256(tgz).hexdigest()==manifest['sha256']=='62ac69ba8225005e24f712a99c13477039c8d417b0f201cdabdea8d25415893b'
with tarfile.open(fileobj=io.BytesIO(tgz),mode='r:gz') as archive:
    members={m.name:m for m in archive.getmembers() if m.isfile()}
    def read(name): return archive.extractfile(members['package/'+name]).read()
    package=json.loads(read('package.json')); aliases={}
    for key,value in package['imports'].items():
        aliases[key]=(value.get('node',value.get('default')) if isinstance(value,dict) else value).removeprefix('./')
    todo=['package.json',package['main'],*aliases.values()]; seen={}
    while todo:
        name=todo.pop()
        if name in seen: continue
        assert not name.startswith('/') and '..' not in name.split('/')
        data=read(name);seen[name]=data
        if not name.endswith(('.js','.cjs','.mjs')): continue
        for spec in re.findall(r'''["']((?:\.{1,2}/|#)[^"'\n]+)["']''',data.decode()):
            if spec.startswith('#'):
                if spec in aliases: todo.append(aliases[spec])
            elif spec.endswith(('.js','.cjs','.mjs')):
                target=posixpath.normpath(posixpath.join(posixpath.dirname(name),spec))
                assert 'package/'+target in members,(name,spec,target)
                todo.append(target)
    out=root/'ci689-sdk';assert not out.exists();out.mkdir()
    for name,data in seen.items():
        p=out/'package'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    (out/'package/node_modules').symlink_to('/workspace/agentic-mermaid/node_modules',target_is_directory=True)
    result={'source':'68986ba8e3b76ad99dad44c6ec8d43475cc5e12f','run':43311727806,'artifact':13985303828,'zipSHA256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'tgzSHA256':manifest['sha256'],'scope':'Exact canonical Node root SDK bytes plus recursive relative JS dependencies and all four package Node imports; existing locked dependency symlink. No source build, rewritten JS or timing claim.','aliases':aliases,'files':[{'path':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(seen.items())]}
    (out/'RECOVERY-MANIFEST.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'files':len(seen),'bytes':sum(map(len,seen.values())),'root':str(out/'package'),'aliases':aliases}))
