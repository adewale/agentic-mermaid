| Family | Native requests | Native gzip Δ | Native Br Δ | ELK requests | ELK gzip Δ | ELK Br Δ |
|---|---:|---:|---:|---:|---:|---:|
| flowchart | 37→30 | -3756 | -3590 | 27→25 | -1099 | -782 |
| state | 34→27 | -3778 | -3593 | 24→22 | -1121 | -785 |
| architecture | 35→28 | -4019 | -3845 | 25→23 | -1362 | -1037 |
| class | 33→26 | -3959 | -3884 | 20→18 | -1732 | -1398 |
| er | 34→27 | -4119 | -3998 | 22→19 | -2123 | -1757 |
| requirement | 28→21 | -3670 | -3666 | 13→11 | -852 | -663 |

Initial Brotli5543→5545(+2B); actualeditor-empty routeBrotli66327→66413(+86B). Assetclosure counts do not prove latency. Mixed/demo/editorbudget failures remain.
