// Existing Trident portablecriteria on TWO SOURCE BUN arms; notbuiltNode orbrowser/performancequalification. Node dirname and lossless report storage adapters only.
import {fileURLToPath} from 'node:url'
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {join,dirname} from 'node:path'
import {gzipSync} from 'node:zlib'
import {qualifyPortable} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/fidelity.ts'
const out=dirname(fileURLToPath(import.meta.url)),cases=JSON.parse(readFileSync(join(out,'CASES.json'),'utf8')).all,roots={control:'/dev/shm/pr449-four-final-20261111/native-only-control-2525',candidate:'/dev/shm/pr449-four-final-20261111/finish-geometry-943'}
process.env.AGENTIC_MERMAID_ELK_CACHE='0'
const apis=Object.fromEntries(await Promise.all(Object.entries(roots).filter(([key])=>key===process.argv[2]).map(async([key,root])=>[key,await import(root+'/src/index.ts')]))),rows=[]
mkdirSync(join(out,'pilot'),{recursive:true})
for(const [index,c]of cases.entries())for(const target of Object.keys(apis))for(const policy of [{backend:'elk',fallback:'none'},{backend:'agentic',fallback:'none'},{backend:'agentic',fallback:'elk'},{backend:'trinity',fallback:'none'},{backend:'trinity',fallback:'elk'}].filter(policy=>target==='candidate'||policy.backend!=='trinity')){ const {backend,fallback}=policy;
 const options={...c.renderOptions,graphLayout:{backend,fallback}},stem=target+'-'+backend+'-'+fallback+'-'+c.id.replace(/[^a-z0-9_.-]/gi,'_');let row:any
 try{for(const p of c.prelude??[])try{apis[target].renderMermaidSVG(p.source)}catch{};const value=apis[target].renderMermaidSVGWithReceipt(c.source,options),receipt=JSON.stringify(value.receipt);Buffer.byteLength(JSON.stringify(value));const qualification=qualifyPortable(c,{svg:value.svg,adapter:'agentic'});row={target,backend,fallback,id:c.id,family:c.family,delivery:'returned',proof:value.receipt.layoutCertification?.status,selected:value.receipt.layoutDecisions,qualification,svgBytes:Buffer.byteLength(value.svg),receiptBytes:Buffer.byteLength(receipt)};writeFileSync(join(out,'pilot',stem+'.svg.gz'),gzipSync(value.svg));writeFileSync(join(out,'pilot',stem+'.receipt.json.gz'),gzipSync(receipt))}
 catch(e:any){row={target,backend,fallback,id:c.id,family:c.family,delivery:e.code==='GRAPH_LAYOUT_UNSUPPORTED'?'unsupported':'error',code:e.code,error:String(e),qualification:qualifyPortable(c,{error:String(e),adapter:'agentic'})}}
 rows.push(row);writeFileSync(join(out,'pilot',stem+'.row.json.gz'),gzipSync(JSON.stringify(row,null,2)+'\n'));if(rows.length%24===0)console.log(JSON.stringify({completed:rows.length,total:cases.length*5*Object.keys(roots).length,last:{target,backend,id:c.id,delivery:row.delivery}}))
}
writeFileSync(join(out,process.argv[2]+'-PILOT.json.gz'),gzipSync(JSON.stringify(rows,null,2)+'\n'));
console.log(JSON.stringify({done:true,rows:rows.length,returned:rows.filter(r=>r.delivery==='returned').length}))
