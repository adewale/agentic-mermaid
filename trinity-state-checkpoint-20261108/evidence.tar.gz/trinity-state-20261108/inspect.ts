import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import {layoutMermaidWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/agent/core.ts'
import {writeFileSync} from 'node:fs'
const source='stateDiagram-v2\ndirection TB\n[*] --> Idle\nIdle --> Done: complete\nDone --> [*]'
const options={graphLayout:{backend:'trinity' as const},embedFontImport:false}
const p=renderMermaidSVGWithReceipt(source,options);writeFileSync('/tmp/pr449-week-comparison-20261101/trinity-state-20261108/state.svg',p.svg);console.log(JSON.stringify(layoutMermaidWithReceipt(source,options).layout.nodes));console.log(p.svg.split('\n').filter(l=>l.includes('circle')||l.includes('ellipse')||l.includes('data-role="edge"')).join('\n'))
