from pathlib import Path
import subprocess,os,json,time,gzip
r=Path('/tmp/pr449-week-comparison-20261101/trinity-state-20261108/editor-build');repo=Path('/tmp/pr449-main-integration-20261029-762');env=dict(os.environ,PATH='/tmp/pr449-tools-20261106/package/bin:'+os.environ['PATH'],NODE_ENV='production',AGENTIC_MERMAID_SCENE_ASSERTIONS='0',AM_EDITOR_BUILD_METAFILE=str(r/'after-metafile.json'));env.pop('AM_EDITOR_RUNTIME_DIR',None);env.pop('AM_EDITOR_FONT_PREFIX',None);start=time.monotonic()
with (r/'production-build.log').open('w') as log:
 p=subprocess.Popen(['bun','run','scripts/site/editor.ts'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT);deadline=start+55;timeout=False
 while True:
  pid,status,use=os.wait4(p.pid,os.WNOHANG)
  if pid:break
  if time.monotonic()>deadline:p.kill();timeout=True;pid,status,use=os.wait4(p.pid,0);break
  time.sleep(.1)
 p.returncode=os.waitstatus_to_exitcode(status)
j={'exitCode':p.returncode,'timeout':timeout,'wallSeconds':time.monotonic()-start,'peakRssKiB':use.ru_maxrss,'cpuUser':use.ru_utime,'cpuSystem':use.ru_stime,'beforeReference':'Retained main608 production artifact: 1333923 gzip9 / 1273449 Brotli11; extraction cost only, no build-time ratio.'};(r/'BUILD-STATUS.json').write_text(json.dumps(j,indent=2)+'\n');print(j)
if p.returncode:raise SystemExit(p.returncode)
(r/'after-production.html.gz').write_bytes(gzip.compress((repo/'editor.html').read_bytes()))
