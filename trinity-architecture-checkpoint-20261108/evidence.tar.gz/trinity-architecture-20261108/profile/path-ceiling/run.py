import pathlib,os,subprocess,json
p=pathlib.Path(__file__).parent;worker='/tmp/pr449-week-comparison-20261101/trinity-architecture-20261108/measure.mjs';rows=[]
for replica in range(4):
 for variant in (['base','ceiling'] if replica%2==0 else ['ceiling','base']):
  out=p/f'r{replica}-{variant}'
  with (p/f'r{replica}-{variant}.log').open('w') as log:r=subprocess.run(['node','--expose-gc',worker,str(out),str(p/(variant+'-job.json'))],env={**os.environ,'AGENTIC_MERMAID_ELK_CACHE':'0'},stdout=log,stderr=subprocess.STDOUT)
  rows.append({'replica':replica,'variant':variant,'exit':r.returncode});print(rows[-1],flush=True)
  if r.returncode:raise SystemExit(r.returncode)
(p/'RUNS.json').write_text(json.dumps(rows,indent=2)+'\n')
