import pathlib,os,subprocess,json
p=pathlib.Path(__file__).parent;records=[]
for i,case in enumerate(['flowchart','requirement','class','er','architecture']):
 backends=['elk','agentic','trinity'];backends=backends[i%3:]+backends[:i%3]
 for backend in backends:
  name=case+'-'+backend
  with (p/(name+'.log')).open('w') as log:r=subprocess.run(['node','--expose-gc',str(p/'worker.mjs'),str(p/name),str(p/(name+'-job.json'))],env={**os.environ,'AGENTIC_MERMAID_ELK_CACHE':'0'},stdout=log,stderr=subprocess.STDOUT)
  records.append({'case':case,'backend':backend,'exit':r.returncode});print(records[-1],flush=True)
  if r.returncode:raise SystemExit(r.returncode)
(p/'RUNS.json').write_text(json.dumps({'runtime':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runs':records,'scope':'Current runtime; five supported cases, three backends, two profiled repeats and edit;45 full SVG+receipt calls, separate from all unprofiled timing/browser/build work. One unprofiled warmup per fresh process. Layout-cache flagoff; derived caches remain. Cold-render cause not isolated by this steady profile.'},indent=2)+'\n')
