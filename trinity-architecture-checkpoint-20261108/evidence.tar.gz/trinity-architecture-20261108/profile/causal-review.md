# Independent causal review of the completed profile

Read-only review at `fe9113601`, using the retained 45 complete SVG/entire-receipt calls: five cases × three backends × two repeats and one edit. All 45 returned with passed certification. No source changes, tests, builds, profiles or timing replays were performed by this reviewer.

The top raw elapsed sampling weights, averaged over all 45 calls, are:

| Frame | Self / inclusive sampled weight, ms/call |
| --- | ---: |
| Native paint `copyInner`, line 105 | 2.162 / 2.842 |
| Scene snapshot `visit`, line 98 | 1.581 / 1.749 |
| `certifyNativePaint`, line 1491 | 0.740 / 3.531 |
| Native paint `copy`, line 243 | 0.623 / 2.948 |
| `omitUndefinedObjectFields`, line 501 | 0.552 / 0.604 |

These are V8 elapsed sample-delta weights, not exclusive CPU durations or removable wall time. Inclusive rows overlap and must not be added. The active-window/cutoff diagnostics do not identify whether excluded gaps came from GC, JIT, native work or scheduling. Separate unprofiled costs remain the performance observations; this profile does not establish a speedup or a cold-render cause.

The new snapshot frame points to a shared Class/ER admission question, not a Trinity-specific solver cause:

| Case | Native self / inclusive | ELK self / inclusive | Trinity self / inclusive |
| --- | ---: | ---: | ---: |
| Class | 4.685 / 4.954 | 3.902 / 4.636 | 3.840 / 4.247 |
| ER | 4.280 / 4.586 | 3.734 / 4.181 | 3.271 / 3.625 |

Each cell covers its three retained calls, including the edit. Flowchart, Requirement and Architecture have no attributed snapshot-`visit` samples in this collection; that does not prove zero snapshot work. These few observations are not a cross-backend significance test or a stable effect estimate.

## Causal boundary and one possible next question

`admitSceneDocumentWith` already returns the privately admitted identity before traversing properties (scene-data-snapshot.ts257–266), with a strict-check upgrade when necessary. The hot first capture protects own-data descriptors, arrays, alias/cycle behavior, post-admission immutability, aggregate UTF-8/property/entry budgets and metadata publication order. Another membership shortcut, caller-frozen-object shortcut or removal of that capture is not supported by this evidence. The other four previously stopped hypotheses remain stopped.

One distinct bounded future probe could ask whether eager **diagnostic path construction** contributes useful removable cost inside this first capture. The visitor constructs `${path}.${key}` or `${path}[${index}]` for every successful child traversal (lines 172 and 221), although paths are consumed for diagnostics. A call-local lazy error-path representation could potentially avoid those successful-path strings while retaining the exact descriptor walk, ordering, fresh snapshots, limits and ownership transfer. It needs no new cache and must not grant a prior snapshot a different budget authority.

This is only a falsifiable candidate: the profile identifies the visitor, not the cost of its path strings. Before considering shipment, a bounded counterfactual would need to preserve exact successful SVG/receipt products and exact error paths/ordering for nested objects/arrays, accessors, proxies, cycles, aliases and all aggregate limits. Its full-call unprofiled Class/ER cost and memory must improve under the existing protocol; a smaller visitor sample weight alone is insufficient. If that subtraction is negligible or changes observation/limits, stop it. No implementation or claimed gain is warranted by the present profile alone.
