import {build} from '/tmp/pr449-main-integration-20261029-762/node_modules/tsup/dist/index.js'
import config from '/tmp/pr449-main-integration-20261029-762/tsup.browser-lazy.config.ts'
await build({...config,config:false,dts:false,clean:false,outDir:'/tmp/pr449-week-comparison-20261101/trinity-architecture-20261108/dist'})
