import{readFileSync,writeFileSync}from'node:fs'
import{gunzipSync}from'node:zlib'
import{SaxesParser}from'/tmp/pr449-main-integration-20261029-762/node_modules/saxes/saxes.js'
import{createHash}from'node:crypto'
import{countPolylineCrossings}from'/tmp/pr449-main-integration-20261029-762/src/shared/edge-crossings.ts'
const root='/tmp/pr449-week-comparison-20261101/joint-caption-dd365',old='/tmp/pr449-week-comparison-20261101/forest-placement-deafff/shaft-card-152/before'
function parse(svg:string){const tags:any[]=[];const p=new SaxesParser({xmlns:true});p.on('opentag',t=>tags.push({name:t.local,attrs:Object.fromEntries(Object.values(t.attributes).map(a=>[a.name,a.value]))}));p.write(svg).close();return tags}
const rows=[];const originals=gunzipSync(readFileSync(old+'/actual.svg.gz')).toString(),candidate=gunzipSync(readFileSync(root+'/candidate/actual.svg.gz')).toString()
const before=parse(originals),after=parse(candidate);if(before.length!==after.length)throw Error('tag count changed')
const changes=before.flatMap((a,i)=>JSON.stringify(a)===JSON.stringify(after[i])?[]:[{index:i,before:a,after:after[i]}]);
for(const c of changes)if(c.before.name!==c.after.name)throw Error('tag ownership/order changed')
for(const tags of[before,after]){
 const shafts=tags.filter(t=>t.attrs['data-role']==='edge'&&t.name==='polyline')
 const routes=shafts.map(t=>({points:t.attrs.points.split(/\s+/).map((p:string)=>{const[x,y]=p.split(',').map(Number);return{x:x!,y:y!}})}))
 rows.push({crossings:countPolylineCrossings(routes),sha256:createHash('sha256').update(tags===before?originals:candidate).digest('hex'),viewport:tags.find(t=>t.name==='svg').attrs.viewBox,edges:shafts.length,bends:shafts.reduce((n,t)=>n+t.attrs.points.split(/\s+/).length-2,0),wire:shafts.reduce((n,t)=>{const pts=t.attrs.points.split(/\s+/).map((p:string)=>p.split(',').map(Number));return n+pts.slice(1).reduce((m:number,b:number[],i:number)=>m+Math.hypot(b[0]!-pts[i][0],b[1]!-pts[i][1]),0)},0)})
}
writeFileSync(root+'/CORRESPONDENCE.json',JSON.stringify({tagCount:before.length,rows,changes,scope:'Actual finalSVG start tags parsed independently by Saxes; every unchanged tag and attribute compared, not a helper/certificate claim.'},null,2)+'\n');console.log(JSON.stringify({rows,changedTags:changes.map(c=>({i:c.index,name:c.before.name,keys:Object.keys(c.before.attrs).filter(k=>c.before.attrs[k]!==c.after.attrs[k])}))}))
