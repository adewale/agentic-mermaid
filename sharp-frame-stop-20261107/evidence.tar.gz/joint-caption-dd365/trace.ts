import { readFileSync,writeFileSync } from 'node:fs'
import { parseMermaid } from '/tmp/pr449-main-integration-20261029-762/src/parser.ts'
import { LAYOUT_PIPELINE,layoutGraphSync } from '/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts'
import { graphInkClear,graphInkWork,preservesLabelInkSeparation } from '/tmp/pr449-main-integration-20261029-762/src/layout/label-conflicts.ts'
import { calculatePathMidpoint } from '/tmp/pr449-main-integration-20261029-762/src/layout/geometry.ts'
import { labelRect } from '/tmp/pr449-main-integration-20261029-762/src/shared/edge-label-geometry.ts'
const root='/tmp/pr449-week-comparison-20261101/joint-caption-dd365'
const source=readFileSync('/tmp/pr449-week-comparison-20261101/forest-placement-deafff/shaft-card-152/source.mmd','utf8')
const p=LAYOUT_PIPELINE.find(p=>p.id==='rerouteEdgesThroughNodes')!, old=p.run, rows:any[]=[]
try {
 (p as any).run=(ctx:any)=>{
  const idx=ctx.edges.findIndex((e:any)=>e.source==='n16'&&e.target==='n12'),edge=ctx.edges[idx],node=ctx.nodes.find((n:any)=>n.id==='n4')
  const points=edge.points.map((p:any,i:number)=>i===2||i===3?{...p,x:node.x-10}:{...p})
  const results=[]
  for(const caption of ['midpoint','retained']) {
   const proposal={...edge,points,labelPosition:caption==='midpoint'?calculatePathMidpoint(points):edge.labelPosition}
   const edges=ctx.edges.map((e:any,i:number)=>i===idx?proposal:e), budget=graphInkWork()
   const admitted=graphInkClear(ctx.nodes,edges,ctx.nodes,ctx.edges,ctx.groups,ctx.style,budget)
   const peers=[]
   for(let i=0;i<edges.length;i++) {
    const before=i===idx?[edge]:[edge,ctx.edges[i]],after=i===idx?[proposal]:[proposal,edges[i]]
    let count=0
    if(!preservesLabelInkSeparation(before,after,ctx.style,new Set([0]),()=>{count++;return true})) peers.push({i,source:ctx.edges[i].source,target:ctx.edges[i].target,label:ctx.edges[i].label,labelPosition:ctx.edges[i].labelPosition,points:ctx.edges[i].points,count})
   }
   results.push({caption,admitted,remaining:budget.remaining,labelPosition:proposal.labelPosition,labelRect:labelRect(proposal,ctx.style),peers})
  }
  rows.push({idx,node:{id:node.id,x:node.x,y:node.y,w:node.width,h:node.height},original:{points:edge.points,labelPosition:edge.labelPosition,labelRect:labelRect(edge,ctx.style)},points,results})
  if(rows.length===3) writeFileSync(root+'/context.json',JSON.stringify({nodes:ctx.nodes,edges:ctx.edges,groups:ctx.groups,style:ctx.style},null,2)+'\n')
  return old(ctx)
 }
 layoutGraphSync(parseMermaid(source),{graphLayout:{backend:'agentic',fallback:'none'}})
 writeFileSync(root+'/TRACE.json',JSON.stringify(rows,null,2)+'\n')
 console.log(JSON.stringify(rows.map(x=>({node:x.node,original:x.original,results:x.results})),null,2))
}finally{(p as any).run=old}
