import{readFileSync,writeFileSync}from'node:fs'
import{graphInkClear,graphInkWork,preservesLabelInkSeparation}from'/tmp/pr449-main-integration-20261029-762/src/layout/label-conflicts.ts'
import{calculatePathMidpoint}from'/tmp/pr449-main-integration-20261029-762/src/layout/geometry.ts'
import{labelRect,labelHaloExtension}from'/tmp/pr449-main-integration-20261029-762/src/shared/edge-label-geometry.ts'
const root='/tmp/pr449-week-comparison-20261101/joint-caption-dd365',ctx=JSON.parse(readFileSync(root+'/context.json','utf8'))
const idx=16,edge=ctx.edges[idx],node=ctx.nodes.find((n:any)=>n.id==='n4'),peer=ctx.edges[32]
const rows=[]
for(const gap of [0.876,1,2,4,8,10]) for(const caption of ['midpoint','retained']){
 const points=edge.points.map((p:any,i:number)=>i===2||i===3?{...p,x:node.x-gap}:{...p}), proposed={...edge,points,labelPosition:caption==='midpoint'?calculatePathMidpoint(points):edge.labelPosition}
 const budget=graphInkWork(),admitted=graphInkClear(ctx.nodes,ctx.edges.map((e:any,i:number)=>i===idx?proposed:e),ctx.nodes,ctx.edges,ctx.groups,ctx.style,budget)
 rows.push({gap,caption,admitted,remaining:budget.remaining,position:proposed.labelPosition,labelRect:labelRect(proposed,ctx.style),pair32:preservesLabelInkSeparation([edge,peer],[proposed,peer],ctx.style,new Set([0]),()=>true)})
}
const out={peer:{label:peer.label,labelRect:labelRect(peer,ctx.style),halo:labelHaloExtension(peer,ctx.style.lineWidth??1)},rows};writeFileSync(root+'/LANES.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out))
