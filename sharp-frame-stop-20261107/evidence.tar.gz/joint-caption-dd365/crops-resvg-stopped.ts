import{readFileSync,writeFileSync}from'node:fs'
import{gunzipSync}from'node:zlib'
import{Resvg}from'/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import{HOSTED_FONT_RESOURCES}from'/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import{inlineFontVarForRaster}from'/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import{prepareResvgMarkerOrientation}from'/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
import{createHash}from'node:crypto'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/joint-caption-dd365'
const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const p=root+'/'+f.path;if(createHash('sha256').update(readFileSync(p)).digest('hex')!==f.sha256)throw Error('font mismatch');return p})
for(const[arm,path]of[['before','/tmp/pr449-week-comparison-20261101/forest-placement-deafff/shaft-card-152/before/actual.svg.gz'],['after',out+'/candidate/actual.svg.gz']]){
 const svg=gunzipSync(readFileSync(path!)).toString().replace(/viewBox="[^"]+"/,'viewBox="270 815 155 75"').replace(/(<svg\b[^>]*?)\swidth="[^"]+"/,'$1 width="775"').replace(/(<svg\b[^>]*?)\sheight="[^"]+"/,'$1 height="375"')
 const result=new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(svg)),{background:'#fff',fitTo:{mode:'width',value:775},font:{fontFiles:fonts,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();writeFileSync(out+'/'+arm+'-crop.png',result.asPng());console.log(arm,result.width,result.height)
}
