import{readFileSync,writeFileSync}from'node:fs'
import{gunzipSync}from'node:zlib'
import{createHash}from'node:crypto'
import{Resvg}from'/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import{SaxesParser}from'/tmp/pr449-main-integration-20261029-762/node_modules/saxes/saxes.js'
import{HOSTED_FONT_RESOURCES}from'/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import{inlineFontVarForRaster}from'/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import{prepareResvgMarkerOrientation}from'/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/joint-caption-dd365'
const actual=gunzipSync(readFileSync(out+'/candidate/actual.svg.gz')).toString()
const shaft=[...actual.matchAll(/<polyline\b[^>]*\/>/g)].find(m=>m[0].includes('data-from="n16"')&&m[0].includes('data-to="n12"'))![0]
const card=[...actual.matchAll(/<rect\b[^>]*\/>/g)].find(m=>m[0].includes('data-id="node-shape:n4"'))![0]
let attributes:Record<string,string>={}
const parser=new SaxesParser({xmlns:true});parser.on('opentag',tag=>{if(tag.local==='rect'&&Object.values(tag.attributes).some(a=>a.name==='data-id'&&a.value==='node-shape:n4'))attributes=Object.fromEntries(Object.values(tag.attributes).map(a=>[a.name,a.value]))});parser.write(actual).close()
const fontFiles=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const p=root+'/'+f.path,b=readFileSync(p);if(createHash('sha256').update(b).digest('hex')!==f.sha256)throw Error('font bytes');return p})
const variants=[actual,actual.replace(shaft,''),actual.replace(card,''),actual.replace(shaft,'').replace(card,'')]
const images=variants.map(svg=>new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(svg)),{background:'#fff',fitTo:{mode:'zoom',value:2},font:{fontFiles,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render())
if(!images.every(i=>i.width===images[0]!.width&&i.height===images[0]!.height))throw Error('viewport changed')
writeFileSync(out+'/actual.png',images[0]!.asPng())
const x=Number(attributes.x),y=Number(attributes.y),h=Number(attributes.height),zoom=2
const roi={x0:Math.floor((x-6)*zoom),x1:Math.ceil((x+2)*zoom),y0:Math.ceil((y+3)*zoom),y1:Math.floor((y+h-3)*zoom)}
let exposedShaftPixels=0,visibleWithCardPixels=0,attenuatedShaftPixels=0,fullyHiddenShaftPixels=0
const delta=(a:Uint8Array,b:Uint8Array,k:number)=>Math.abs(a[k]!-b[k]!)+Math.abs(a[k+1]!-b[k+1]!)+Math.abs(a[k+2]!-b[k+2]!)
const [full,noShaft,noCard,neither]=images.map(i=>i.pixels)
for(let row=roi.y0;row<roi.y1;row++)for(let col=roi.x0;col<roi.x1;col++){
 const k=(row*images[0]!.width+col)*4,exposed=delta(noCard!,neither!,k),visible=delta(full!,noShaft!,k)
 if(exposed>=6){exposedShaftPixels++;if(visible>=6)visibleWithCardPixels++;if(visible+6<exposed)attenuatedShaftPixels++;if(visible<6)fullyHiddenShaftPixels++}
}
const result={svgSHA256:createHash('sha256').update(actual).digest('hex'),publicCalls:0,offlineRasters:4,font:'manifest-verified Inter, system fonts off',zoom,roi,exposedShaftPixels,visibleWithCardPixels,attenuatedShaftPixels,fullyHiddenShaftPixels,actualShaft:shaft,actualCard:card,scope:'Actual saved output, independent per-pixel marginal shaft contribution with and without the foreign card; selected border interval only, not whole glyph/readability qualification.'}
if(!exposedShaftPixels || visibleWithCardPixels!==exposedShaftPixels || fullyHiddenShaftPixels!==0)throw Error('Selected shaft ink still hidden')
writeFileSync(out+'/INK.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result))
