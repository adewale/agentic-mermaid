import assert from'node:assert/strict'
globalThis.__actualConformanceCalls={control:0,candidate:0}
const control=await import('../consumer-package-order-repair/candidate/src/index.ts'),candidate=await import('../node-drawing-consumer-pilot/src/index.ts')
const source='flowchart TD\n A --> B',options={graphLayout:{backend:'agentic',fallback:'none'}}
const a=control.renderMermaidSVGWithReceipt(source,options),b=candidate.renderMermaidSVGWithReceipt(source,options)
assert.equal(typeof b,'object');assert.equal(typeof b.then,'undefined');assert.equal(a.svg,b.svg);assert.deepEqual(a.receipt,b.receipt)
assert.equal(globalThis.__actualConformanceCalls.control,1);assert.equal(globalThis.__actualConformanceCalls.candidate,0)
console.log(JSON.stringify({phase:'high-level-native',actualConformanceCalls:{...globalThis.__actualConformanceCalls},synchronous:true,wholeSvgAndReceiptExact:true,proof:b.receipt.layoutCertification.status}))
const marks=await import('../node-drawing-consumer-pilot/src/scene/marks.ts')
const shape=marks.shape({id:'sdk',role:'node',geometry:{kind:'rect',x:0,y:0,width:10,height:10},paint:{fill:'#111'}})
shape.geometry.x=2
const svg=candidate.DefaultBackend.drawNode(shape,{seed:0});assert.match(svg,/x="2"/);assert.equal(globalThis.__actualConformanceCalls.candidate,1)
console.log(JSON.stringify({phase:'real-sdk-default-draw',actualConformanceCalls:{...globalThis.__actualConformanceCalls},mutableSdkInputRetained:true,actualSvg:svg}))
