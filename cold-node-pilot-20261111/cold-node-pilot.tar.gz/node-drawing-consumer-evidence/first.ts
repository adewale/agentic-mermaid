import {writeFileSync}from'node:fs';import{gzipSync}from'node:zlib'
const a=await import('../consumer-package-order-repair/candidate/src/index.ts')
const b=await import('../node-drawing-consumer-pilot/src/index.ts')
const source='flowchart TD\n A --> B',options={graphLayout:{backend:'agentic',fallback:'none'}}
const control=a.renderMermaidSVGWithReceipt(source,options),candidate=b.renderMermaidSVGWithReceipt(source,options)
writeFileSync(new URL('FIRST-PRODUCTS.json.gz',import.meta.url),gzipSync(JSON.stringify({control,candidate})))
console.log(JSON.stringify({svgExact:control.svg===candidate.svg,entireReceiptExact:JSON.stringify(control.receipt)===JSON.stringify(candidate.receipt),control:control.receipt.layoutCertification,candidate:candidate.receipt.layoutCertification}))
const{withRenderStageObserver}=await import('../node-drawing-consumer-pilot/src/render-stages.ts')
const{getFamily}=await import('../node-drawing-consumer-pilot/src/agent/families.ts')
const{sceneLowering,inheritNativeDrawing}=await import('../node-drawing-consumer-pilot/src/scene/drawing.ts')
const family=getFamily('flowchart'),events=[];let changedCalls=0,optionReads=0
const lower=sceneLowering(()=>{changedCalls++;throw Error('changed producer must use Scene fallback')})
const observedOptions={get graphLayout(){optionReads++;return{backend:'agentic',fallback:'none'}}}
const fallback=withRenderStageObserver(event=>{events.push(event.stage);if(event.stage==='layout')inheritNativeDrawing(lower,family.lowerScene)},()=>b.renderMermaidSVGWithReceipt(source,observedOptions))
writeFileSync(new URL('FALLBACK-PRODUCT.json.gz',import.meta.url),gzipSync(JSON.stringify(fallback)))
console.log(JSON.stringify({fallbackSvgExact:control.svg===fallback.svg,fallbackProof:fallback.receipt.layoutCertification,changedCalls,optionReads,events}))
