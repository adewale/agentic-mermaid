import{plugin}from'bun';import{readFileSync}from'node:fs'
plugin({name:'actual-conformance-invocation-observer',setup(build){build.onLoad({filter:/scene\/backend-conformance\.ts$/},args=>{
const arm=args.path.includes('/node-drawing-consumer-pilot/')?'candidate':'control'
return{loader:'ts',contents:readFileSync(args.path,'utf8').replace('  FIXTURE ??= withTextMeasurementExecution(undefined, createFixture)',`  globalThis.__actualConformanceCalls.${arm}++;\n  FIXTURE ??= withTextMeasurementExecution(undefined, createFixture)`)}
})}})
