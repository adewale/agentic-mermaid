import assert from'node:assert/strict';import{writeFileSync}from'node:fs';import{gzipSync}from'node:zlib'
const rows=[];const full={}
for(const root of ['consumer-package-order-repair/candidate','node-drawing-consumer-pilot']){
 const api=await import(`../${root}/src/index.ts`),{getFamily}=await import(`../${root}/src/agent/families.ts`),{sceneLowering,inheritNativeDrawing,originalNativeDrawingOf}=await import(`../${root}/src/scene/drawing.ts`),{withRenderStageObserver}=await import(`../${root}/src/render-stages.ts`)
 const family=getFamily('flowchart'),original=originalNativeDrawingOf(family.lowerScene),restore=sceneLowering(original),source='flowchart TD\n A --> B',options={graphLayout:{backend:'agentic',fallback:'none'}}
 const before=api.renderMermaidSVGWithReceipt(source,options);let calls=0;const events=[]
 const changed=sceneLowering((factory,context)=>{calls++;context.positioned.nodes[0].x+=3;return original(factory,context)})
 let altered,error
 try{altered=withRenderStageObserver(event=>{events.push(event.stage);if(event.stage==='layout')inheritNativeDrawing(changed,family.lowerScene)},()=>api.renderMermaidSVGWithReceipt(source,options))}catch(e){error={name:e?.name,message:e?.message,certification:e?.certification}}
 inheritNativeDrawing(restore,family.lowerScene)
 const after=api.renderMermaidSVGWithReceipt(source,options)
 assert.equal(calls,1);assert.equal(before.svg,after.svg);assert.deepEqual(before.receipt,after.receipt)
 full[root]={before,altered,error,after};rows.push({root,calls,events,alteredStatus:altered?.receipt.layoutCertification.status,error,restoredWholeProductExact:before.svg===after.svg&&JSON.stringify(before.receipt)===JSON.stringify(after.receipt)})
}
const a=full['consumer-package-order-repair/candidate'],b=full['node-drawing-consumer-pilot'];assert.equal(a.altered?.svg,b.altered?.svg);assert.deepEqual(a.altered?.receipt,b.altered?.receipt);assert.deepEqual(a.error,b.error)
writeFileSync(new URL('CHANGED-GEOMETRY-PRODUCTS.json.gz',import.meta.url),gzipSync(JSON.stringify(full)));console.log(JSON.stringify({rows,alteredWholeProductsExact:true}))
