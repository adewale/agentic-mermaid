globalThis.__actualConformanceCalls={control:0,candidate:0}
import assert from'node:assert/strict'
for(const root of ['consumer-package-order-repair/candidate','node-drawing-consumer-pilot']){
 const api=await import(`../${root}/src/index.ts`),{getFamily}=await import(`../${root}/src/agent/families.ts`),{sceneLowering,inheritNativeDrawing}=await import(`../${root}/src/scene/drawing.ts`),{withRenderStageObserver}=await import(`../${root}/src/render-stages.ts`)
 const family=getFamily('flowchart'),events=[];let calls=0,reads=0;const sentinel=Error('same late producer sentinel')
 const changed=sceneLowering(()=>{calls++;throw sentinel})
 let returned=false,caught=false,other
 try{withRenderStageObserver(event=>{events.push(event.stage);if(event.stage==='layout')inheritNativeDrawing(changed,family.lowerScene)},()=>api.renderMermaidSVGWithReceipt('flowchart TD\n A --> B',{get graphLayout(){reads++;return{backend:'agentic',fallback:'none'}}}));returned=true}catch(error){caught=error===sentinel;if(!caught)other=String(error)}
 console.log(JSON.stringify({root,returned,caughtSameCallerException:caught,other,calls,reads,events,actualConformanceCalls:{...globalThis.__actualConformanceCalls}}))
}
