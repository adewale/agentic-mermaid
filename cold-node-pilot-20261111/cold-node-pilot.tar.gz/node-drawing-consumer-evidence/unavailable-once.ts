await import('../node-drawing-consumer-pilot/src/index.ts')
import assert from'node:assert/strict'
const{executeGraphicalRequest}=await import('../node-drawing-consumer-pilot/src/graphical-render.ts')
const{FIRST_PARTY_DRAWING_CONSUMER}=await import('../node-drawing-consumer-pilot/src/scene/default-drawing-consumer.ts')
const{assertScenesOf}=await import('../node-drawing-consumer-pilot/src/scene/assertions.ts')
const{withRenderStageObserver}=await import('../node-drawing-consumer-pilot/src/render-stages.ts')
const events=[];let reads=0,validate=0,consume=0
const value=withRenderStageObserver(event=>events.push(event.stage),()=>executeGraphicalRequest('flowchart TD\n A --> B',{get graphLayout(){reads++;return{backend:'agentic',fallback:'none'}}},'svg',undefined,{drawingConsumer:FIRST_PARTY_DRAWING_CONSUMER},{validate(){validate++},consume(request){consume++;assertScenesOf(request)}}))
assert.equal(typeof value.then,'undefined');assert.equal(value.receipt.layoutCertification.status,'passed');assert.equal(reads,1);assert.equal(validate,1);assert.equal(consume,1);for(const stage of ['request','layout','scene','backend'])assert.equal(events.filter(x=>x===stage).length,1)
console.log(JSON.stringify({synchronous:true,reads,validate,consume,events,proof:value.receipt.layoutCertification}))
