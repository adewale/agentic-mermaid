import { readFileSync,writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const candidate=await import('../ordinary-rect-constructor-pilot/src/index.ts')
const control=await import('../consumer-package-order-repair/candidate/src/index.ts')
const job=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-e0cac-focused/profile-current.job.json','utf8'))
const options={graphLayout:{backend:'agentic',fallback:'none'}}
const a=control.renderMermaidSVGWithReceipt(job.source,options),b=candidate.renderMermaidSVGWithReceipt(job.source,options)
writeFileSync(new URL('PRODUCTS.json.gz',import.meta.url),gzipSync(JSON.stringify({control:a,candidate:b})))
const omit=value=>{const{layoutCertification,...rest}=value.receipt;return rest}
console.log(JSON.stringify({svgExact:a.svg===b.svg,noncertExact:JSON.stringify(omit(a))===JSON.stringify(omit(b)),control:a.receipt.layoutCertification,candidate:b.receipt.layoutCertification}))
