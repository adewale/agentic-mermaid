import { writeFileSync } from 'node:fs'
const close = Object.preventExtensions
let actualShapes = 0
Object.preventExtensions = function(value) { if (value?.constructor?.name === 'WrittenShape') actualShapes++; return close(value) }
const candidate = await import('../writer-fact-pilot/src/index.ts')
const control = await import('../consumer-package-order-repair/candidate/src/index.ts')
const source = 'flowchart TD\n A --> B'
const options = { graphLayout: { backend: 'agentic', fallback: 'none' } }
const a = control.renderMermaidSVGWithReceipt(source, options)
const b = candidate.renderMermaidSVGWithReceipt(source, options)
writeFileSync(new URL('FIRST-PUBLIC-COMPARE-PRODUCTS.json',import.meta.url), JSON.stringify({control:a,candidate:b}))
const omit = value => { const {layoutCertification,...rest} = value.receipt; return rest }
console.log(JSON.stringify({svgExact:a.svg===b.svg,noncertExact:JSON.stringify(omit(a))===JSON.stringify(omit(b)),actualShapes,
 control:a.receipt.layoutCertification,candidate:b.receipt.layoutCertification}))
