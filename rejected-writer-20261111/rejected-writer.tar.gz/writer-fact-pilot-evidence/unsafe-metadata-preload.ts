import { plugin } from 'bun'
import { readFileSync } from 'node:fs'
plugin({name:'retained-unsafe-metadata-draft',setup(build){build.onLoad({filter:/native-paint-emission\.ts$/},args=>({contents:readFileSync(args.path,'utf8').replaceAll('const metadata = { __proto__: null, ...submittedMetadata }','const metadata = { ...submittedMetadata }').replaceAll('closed !== metadata || textPaintProto(metadata) !== null','closed !== metadata'),loader:'ts'}))}})
