import { plugin } from 'bun'
import { readFileSync } from 'node:fs'
plugin({name:'retained-unsafe-actual-rect-guard',setup(build){build.onLoad({filter:/scene\/svg-writer\.ts$/},args=>({contents:readFileSync(args.path,'utf8').replace('if (this.#actualPaintInputs && !actualValid) return','if (false) return'),loader:'ts'}))}})
