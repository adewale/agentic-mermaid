p='src/scene/actual-write-records.ts';s=open(p).read().replace('ScenePoint, ShapeMark','ScenePoint, ShapeMark, TextMark')
fields=['kind','id','role','identity','owner','visibility','accessibility','channels','transform','attributes','text','fontSize','fontWeight','letterSpacing','display','prepared','measurement','textLayout','anchor','dominantBaseline','fontStyle','textDecoration','spans','pageFill']
s+="\nexport type WrittenTextMetadata = Omit<TextMark, 'paint' | 'block' | 'preparedLines'>\nclass WrittenText implements TextMark {\n"
for f in fields+['x','y','baselineShift','paint','block','preparedLines']:s+=f"  declare readonly {f}: TextMark['{f}']\n"
s+='  readonly #metadata: WrittenTextMetadata\n  readonly #paint: MarkPaint\n  readonly #block: NonNullable<TextMark[\'block\']>\n  readonly #x: number\n  readonly #y: number\n  readonly #baselineShift: number\n'
s+="  constructor(token: object, metadata: WrittenTextMetadata, paint: MarkPaint, block: NonNullable<TextMark['block']>, x: number, y: number, baselineShift: number) {\n    if (token !== issuer) throw new TypeError('Actual values require their writer')\n    this.#metadata=metadata; this.#paint=paint; this.#block=block; this.#x=x; this.#y=y; this.#baselineShift=baselineShift\n    closeInstance(this, WrittenText.prototype, WrittenTextReady)\n  }\n"
for f in fields:s+=f"  static {f}(value: WrittenText): TextMark['{f}'] {{ return value.#metadata.{f} }}\n"
for f in ['x','y','baselineShift','paint','block']:s+=f"  static {f}(value: WrittenText): TextMark['{f}'] {{ return value.#{f} }}\n"
s+="  static preparedLines(value: WrittenText): undefined { return undefined }\n  static owns(value: unknown): value is WrittenText { return !!value && typeof value === 'object' && #metadata in value }\n}\n"
for f in fields+['x','y','baselineShift','paint','block','preparedLines']:s+=f'const readWrittenText{f} = WrittenText.{f}\n'
s+='const ownsWrittenText = WrittenText.owns\nconst WrittenTextReady = closePrototype(WrittenText.prototype, {\n'
for f in fields+['x','y','baselineShift','paint','block','preparedLines']:s+=f'  {f}: function(this: WrittenText) {{ return readWrittenText{f}(this) }},\n'
s+='})\nexport function isWrittenText(value: unknown): value is TextMark { return ownsWrittenText(value) }\n'
s+="export function createWrittenText(metadata: WrittenTextMetadata, paint: MarkPaint, block: NonNullable<TextMark['block']>, x: number, y: number, baselineShift: number): TextMark | undefined {\n  try { return new WrittenText(issuer, metadata, paint, block, x, y, baselineShift) } catch { return undefined }\n}\n"
open(p,'w').write(s)
p='src/scene/marks.ts';s=open(p).read();s=s.replace('}): TextMark {\n  const { block, ...semantic }', '}, privateConstruction = false): TextMark {\n  const { block, ...semantic }',1)
s=s.replace("...(block ? { prepared: true, preparedLines: legacyPreparedRuns(block) } : {}),", "...(block ? { prepared: true, ...(!privateConstruction ? { preparedLines: legacyPreparedRuns(block) } : {}) } : {}),",1)
s=s.replace('consume: (node: TextMark) => T): T { return consume(normalizeText(fields)) }', "consume: (node: TextMark, fallback: () => TextMark) => T): T { const node = normalizeText(fields, true); return consume(node, () => { if (fields.block) node.preparedLines = legacyPreparedRuns(fields.block); return admitWritableSceneNode(node) }) }")
open(p,'w').write(s)
p='src/scene/native-paint-emission.ts';s=open(p).read().replace('createWrittenShape, isWrittenShape','createWrittenShape, isWrittenShape, createWrittenText, isWrittenText',1)
s=s.replace('isOwnedPixelTextPart }','isOwnedPixelTextPart, isRetainedPixelText }',1)
s=s.replace("!isWrittenShape(node) && !Object.hasOwn(node, 'transform')", "!isWrittenShape(node) && !isWrittenText(node) && !Object.hasOwn(node, 'transform')",1)
needle='    constructedShape(node:';pos=s.index(needle)
s=s[:pos]+'''    constructedText(node: Extract<Leaf, { kind: 'text' }>, write: (node: typeof node) => SvgXmlWrite) {
      const block = node.block
      if (!closeLeaves || node.measurement !== 'prepared' || !block || !isOwnedPixelTextPart(block) || !isRetainedPixelText(block)
        || block.lineBlocks.length !== 1 || node.transform || node.spans || node.fontStyle || node.textDecoration || node.dominantBaseline) return undefined
      const { block: _block, paint: _paint, preparedLines: _preparedLines, ...metadata } = node
      let closed: typeof metadata
      try { closed = copy(metadata, 0, new Set(), undefined, true) as typeof metadata } catch { return undefined }
      if (closed !== metadata) return undefined
      const written = withSvgActualPaintInputs(xml, () => write(node)), record = xml.read(written, node)
      if (!record) throw new TypeError('Constructed text lost its actual write')
      const inputs = readSvgActualInputs(xml, written, node), prepared = inputs?.prepared
      const sameLiteral = (name: string, expected: string | undefined): boolean => {
        const actual = inputs?.attribute(name)
        return pay(2 + (expected?.length ?? 0) + (actual?.length ?? 0)) && actual === expected
      }
      const identity = metadata.identity, domIdentity = identity && hasDomSvgIdentityRole(identity.role)
      let bound = !!inputs && !!prepared && pay(12)
        && sameLiteral('transform', undefined)
        && sameLiteral('data-id', domIdentity ? identity.id : undefined) && sameLiteral('data-role', domIdentity ? identity.role : undefined)
        && sameLiteral('class', metadata.attributes?.className || undefined)
        && sameLiteral('font-family', block.fontFamily || undefined) && sameLiteral('text-anchor', metadata.anchor)
        && +(inputs.attribute('font-size') ?? '') === block.fontSize && +(inputs.attribute('font-weight') ?? '') === block.fontWeight
        && +(inputs.attribute('letter-spacing') ?? '0') === block.letterSpacing
      const x = prepared ? +prepared[0] : NaN, y = prepared ? +prepared[1] : NaN, shift = prepared ? +prepared[2] / block.fontSize : NaN
      // A retained measured line is reused only when its current actual text
      // and fitted advance agree; the late XML check still owns UTF16/syntax.
      if (bound) {
        const content = prepared![4], text = block.text
        bound = pay(content.length + text.length + 4) && content === text && +prepared![3] === block.width
          && x >= -SCENE_VALIDATION_LIMITS.maxExtent && x <= SCENE_VALIDATION_LIMITS.maxExtent
          && y >= -SCENE_VALIDATION_LIMITS.maxExtent && y <= SCENE_VALIDATION_LIMITS.maxExtent && shift === shift
      }
      const paintNode = bound && pay(7) ? createWrittenText(metadata, inputs!.paint, block, x, y, shift) : undefined
      if (paintNode && pay()) capturedLeaves.set(paintNode, paintNode)
      return { node, paintNode: paintNode ?? node, svg: record.svg, xmlWrite: written, conditional: !paintNode }
    },
'''+s[pos:]
# Limits are already imported indirectly only; add exact existing limits leaf.
s="import { SCENE_VALIDATION_LIMITS } from './scene-validation-limits.ts'\n"+s
open(p,'w').write(s)
p='src/scene/native-drawing.ts';s=open(p).read().replace('text: fields => leaf(marks.text(fields)),',"""text: fields => closeLeaves ? marks.constructNativeText(fields, (node, fallback) => {
      const captured = emission.constructedText(node, source => validator.writeConstructed(source, xml))
      if (!captured) return leaf(fallback())
      return ownFragment({ kind: 'leaf', node: captured.paintNode, svg: captured.svg, xmlWrite: captured.xmlWrite,
        conditional: captured.conditional, nodeCount: 1, depth: 0, prepared: true })
    }) : leaf(marks.text(fields)),""",1);open(p,'w').write(s)
