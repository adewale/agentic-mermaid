p='src/scene/actual-write-records.ts';s=open(p).read().replace('SceneNodeBase, SceneOwner, MarkAttributes','SceneNodeBase, SceneOwner, MarkAttributes, ConnectorMark, ConnectorRoute, ConnectorStroke, ConnectorHitGeometry, ConnectorEndpoints, ConnectorEndpointAnchor, ConnectorTerminalProjection, ConnectorContourSemantics')
s=s.replace("import type { SvgSemanticAccessibility }", "import type { SvgRelationSemantics, SvgSemanticAccessibility }")
s="import { deriveConnectorTerminalProjection } from './connector-terminal.ts'\n"+s
# Accessibility carries its complete typed relation too.
s=s.replace("class WrittenAccessibility implements SvgSemanticAccessibility {", "class WrittenAccessibility implements SvgSemanticAccessibility {\n  declare readonly relation: SvgRelationSemantics\n  readonly #relation: SvgRelationSemantics")
s=s.replace("constructor(token: object, role: SvgSemanticAccessibility['role'], roleDescription: SvgSemanticAccessibility['roleDescription'], label: SvgSemanticAccessibility['label'])", "constructor(token: object, role: SvgSemanticAccessibility['role'], roleDescription: SvgSemanticAccessibility['roleDescription'], label: SvgSemanticAccessibility['label'], relation: SvgRelationSemantics)")
s=s.replace('    this.#roleDescription = roleDescription\n    this.#label = label', '    this.#roleDescription = roleDescription\n    this.#label = label\n    this.#relation = relation',1)
s=s.replace("  static role(value: WrittenAccessibility)", "  static relation(value: WrittenAccessibility): SvgRelationSemantics { return value.#relation }\n  static role(value: WrittenAccessibility)",1)
s=s.replace('const readWrittenAccessibilityrole =', 'const readWrittenAccessibilityrelation = WrittenAccessibility.relation\nconst readWrittenAccessibilityrole =',1)
s=s.replace('const WrittenAccessibilityReady = closePrototype(WrittenAccessibility.prototype, {', 'const WrittenAccessibilityReady = closePrototype(WrittenAccessibility.prototype, {\n  relation: function(this: WrittenAccessibility) { return readWrittenAccessibilityrelation(this) },',1)
s=s.replace('const role = c?.role, roleDescription = c?.roleDescription, label = c?.label', 'const role = c?.role, roleDescription = c?.roleDescription, label = c?.label\n  const relationFrom = c?.relation.from, relationTo = c?.relation.to, relationLabel = c?.relation.label')
s=s.replace("typeof label !== 'string')) return undefined", "typeof label !== 'string' || typeof relationFrom !== 'string' || typeof relationTo !== 'string' || relationLabel !== undefined && typeof relationLabel !== 'string')) return undefined")
s=s.replace('new WrittenAccessibility(issuer, role!, roleDescription!, label!)','new WrittenAccessibility(issuer, role!, roleDescription!, label!, new WrittenRelation(issuer, relationFrom!, relationTo!, relationLabel))')
# All these are direct implementations of existing interfaces, not schemas.
def cls(name,typ,fields,empty=[]):
 global s
 s+=f'\nclass {name} implements {typ} {{\n'
 for f in fields+empty:s+=f"  declare readonly {f}: {typ}['{f}']\n"
 for f in fields:s+=f"  readonly #{f}: {typ}['{f}']\n"
 args=', '.join(f"{f}: {typ}['{f}']" for f in fields)
 s+=f"  constructor(token: object, {args}) {{\n    if (token !== issuer) throw new TypeError('Actual values require their writer')\n"
 for f in fields:s+=f'    this.#{f} = {f}\n'
 s+=f'    closeInstance(this, {name}.prototype, {name}Ready)\n  }}\n'
 for f in fields:s+=f"  static {f}(value: {name}): {typ}['{f}'] {{ return value.#{f} }}\n"
 for f in empty:s+=f'  static {f}(value: {name}): undefined {{ return undefined }}\n'
 s+='}\n'
 for f in fields+empty:s+=f'const read{name}{f} = {name}.{f}\n'
 s+=f'const {name}Ready = closePrototype({name}.prototype, {{\n'
 for f in fields+empty:s+=f'  {f}: function(this: {name}) {{ return read{name}{f}(this) }},\n'
 s+='})\n'
cls('WrittenRelation','SvgRelationSemantics',['from','to','label'])
cls('WrittenEndpoint','ConnectorEndpointAnchor',['point'],['id','owner','portId'])
cls('WrittenEndpoints','ConnectorEndpoints',['from','to','start','end'])
cls('WrittenRoute','ConnectorRoute',['geometry','ownership','closed','bendRadius','contours','startTangent','endTangent','labelAnchors'])
cls('WrittenStroke','ConnectorStroke',['color','width','opacity','dash','lineCap','lineJoin','miterLimit','pathLength','paintOrder','mixBlendMode','nonScaling','encodesValue'])
cls('WrittenHit','ConnectorHitGeometry',['geometry','closed','strokeWidth','pointerEvents'])
s+="\ntype WrittenDashValues = NonNullable<ConnectorStroke['dash']>\n"
cls('WrittenDash','WrittenDashValues',['array','offset'])
s+='''
export function createWrittenConnectorOperands(geometry: ConnectorMark['route']['geometry'], contours: readonly ConnectorContourSemantics[], ownership: ConnectorRoute['ownership'], paint: MarkPaint,
  from: string | undefined, to: string | undefined, hitWidth: number, pointerEvents: ConnectorHitGeometry['pointerEvents'], markers: ConnectorMark['markers'], labels: ConnectorMark['labels'],
  dash: string | undefined, dashOffset: string | undefined, pathLength: number | undefined, blend: ConnectorStroke['mixBlendMode'], encodesValue: boolean | undefined) {
  try {
    const start = contours[0]?.start, end = contours[contours.length - 1]?.end
    if (!start || !end || !paint.stroke || !paint.strokeWidth) return undefined
    const endpoints = new WrittenEndpoints(issuer, from, to, new WrittenEndpoint(issuer, start), new WrittenEndpoint(issuer, end))
    const route = new WrittenRoute(issuer, geometry, ownership, false, 0, contours, contours[0]?.startTangent, contours[contours.length - 1]?.endTangent, labels as readonly ScenePoint[])
    const stroke = new WrittenStroke(issuer, paint.stroke, paint.strokeWidth, paint.strokeOpacity, dash === undefined ? undefined : new WrittenDash(issuer, dash, dashOffset),
      paint.strokeLinecap ?? 'butt', paint.strokeLinejoin ?? 'miter', +(paint.strokeMiterlimit ?? '4'), pathLength, paint.paintOrder, blend, paint.vectorEffect === 'non-scaling-stroke', encodesValue)
    const hit = new WrittenHit(issuer, geometry, false, hitWidth, pointerEvents)
    return { endpoints, route, stroke, hit, markers, labels }
  } catch { return undefined }
}
'''
# Do not borrow label arrays as another interface; a checked fresh empty anchor list is passed separately.
s=s.replace("labels: ConnectorMark['labels'],\n  dash", "labels: ConnectorMark['labels'], anchors: readonly ScenePoint[],\n  dash")
s=s.replace('labels as readonly ScenePoint[]','anchors')
s+="\nexport type WrittenConnectorMetadata = Omit<ConnectorMark, 'endpoints' | 'route' | 'stroke' | 'hit' | 'markers' | 'labels' | 'terminalProjection'>\n"
fields=['kind','id','role','identity','owner','visibility','accessibility','channels','transform','attributes','lineStyle','relationship']
extra=['endpoints','route','stroke','hit','markers','labels']
s+='class WrittenConnector implements ConnectorMark {\n'
for f in fields+extra+['terminalProjection']:s+=f"  declare readonly {f}: ConnectorMark['{f}']\n"
s+='  readonly #metadata: WrittenConnectorMetadata\n'
for f in extra:s+=f"  readonly #{f}: ConnectorMark['{f}']\n"
s+='  constructor(token: object, metadata: WrittenConnectorMetadata, '+', '.join(f"{f}: ConnectorMark['{f}']" for f in extra)+") {\n    if (token !== issuer) throw new TypeError('Actual values require their writer')\n    this.#metadata=metadata\n"
for f in extra:s+=f'    this.#{f}={f}\n'
s+='    closeInstance(this, WrittenConnector.prototype, WrittenConnectorReady)\n  }\n'
for f in fields:s+=f"  static {f}(value: WrittenConnector): ConnectorMark['{f}'] {{ return value.#metadata.{f} }}\n"
for f in extra:s+=f"  static {f}(value: WrittenConnector): ConnectorMark['{f}'] {{ return value.#{f} }}\n"
s+='''  static terminalProjection(value: WrittenConnector): ConnectorTerminalProjection {
    return deriveConnectorTerminalProjection({ geometry: value.#route.geometry, lineStyle: value.#metadata.lineStyle, endpoints: value.#endpoints,
      relationship: value.#metadata.relationship, route: value.#route, stroke: value.#stroke, markers: value.#markers, labels: value.#labels, hit: value.#hit }, true)
  }
  static owns(value: unknown): value is WrittenConnector { return !!value && typeof value === 'object' && #metadata in value }
}
'''
for f in fields+extra+['terminalProjection']:s+=f'const readWrittenConnector{f} = WrittenConnector.{f}\n'
s+='const ownsWrittenConnector = WrittenConnector.owns\nconst WrittenConnectorReady = closePrototype(WrittenConnector.prototype, {\n'
for f in fields+extra+['terminalProjection']:s+=f'  {f}: function(this: WrittenConnector) {{ return readWrittenConnector{f}(this) }},\n'
s+='})\nexport function isWrittenConnector(value: unknown): value is ConnectorMark { return ownsWrittenConnector(value) }\n'
s+="export function createWrittenConnector(metadata: WrittenConnectorMetadata, operands: NonNullable<ReturnType<typeof createWrittenConnectorOperands>>): ConnectorMark | undefined {\n  try { return new WrittenConnector(issuer, metadata, operands.endpoints, operands.route, operands.stroke, operands.hit, operands.markers, operands.labels) } catch { return undefined }\n}\n"
open(p,'w').write(s)
p='src/scene/native-paint-emission.ts';s=open(p).read().replace("write: (node: typeof node) => SvgXmlWrite", "write: (source: Extract<Leaf, { kind: 'text' }>) => SvgXmlWrite",1);open(p,'w').write(s)
p='src/scene/scene-validation-core.ts';s=open(p).read().replace('state.native.constructed === value || deferredTerminalProjectionInput(value)', '(state.native.constructed as object | undefined) === value || deferredTerminalProjectionInput(value)',1);open(p,'w').write(s)
