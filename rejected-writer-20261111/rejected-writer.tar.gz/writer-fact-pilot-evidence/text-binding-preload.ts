import { plugin } from 'bun'
import { readFileSync } from 'node:fs'
plugin({name:'actual-text-binding-observation',setup(build){build.onLoad({filter:/native-paint-emission\.ts$/},args=>{
const source=readFileSync(args.path,'utf8').replace('const x = prepared ? +prepared[0]',`console.error(JSON.stringify({textBinding:{node:metadata.id,inputs:!!inputs,prepared,block:{text:block.text,width:block.width,fontSize:block.fontSize,fontWeight:block.fontWeight,letterSpacing:block.letterSpacing,fontFamily:block.fontFamily},attrs:inputs&&Object.fromEntries(['font-family','font-size','font-weight','letter-spacing','text-anchor','class','data-id','data-role'].map(key=>[key,inputs.attribute(key)]))}})); const x = prepared ? +prepared[0]`)
return{contents:source,loader:'ts'}
})}})
