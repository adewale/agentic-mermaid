import { readFileSync,writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const close=Object.preventExtensions
const actual={WrittenShape:0,WrittenText:0,WrittenConnector:0}
Object.preventExtensions=function(value){const key=value?.constructor?.name;if(Object.hasOwn(actual,key))actual[key]++;return close(value)}
const candidate=await import('../writer-fact-pilot/src/index.ts')
const control=await import('../consumer-package-order-repair/candidate/src/index.ts')
const cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/shared-four-fixes-20261111/task1/inplace-closure-ceiling/capacity/EXISTING-CASES.json','utf8'))
const rows=[]
const omit=value=>{const {layoutCertification,...rest}=value.receipt;return rest}
for(const entry of cases)for(const backend of ['agentic','elk']){
 const products={}
 const count={}
 for(const [arm,api]of[['control',control],['candidate',candidate]]){
  for(const key of Object.keys(actual))actual[key]=0
  try{products[arm]=api.renderMermaidSVGWithReceipt(entry.source,{graphLayout:{backend,fallback:'none'}})}catch(error){products[arm]={error:String(error?.stack??error)}}
  count[arm]={...actual}
 }
 writeFileSync(new URL(`capacity-bounds-${entry.name}-${backend}.json.gz`,import.meta.url),gzipSync(JSON.stringify(products)))
 const a=products.control,b=products.candidate
 const summarize=value=>value.error?value:{status:value.receipt.layoutCertification.status,coverage:value.receipt.layoutCertification.coverage,checks:value.receipt.layoutCertification.checks,issues:value.receipt.layoutCertification.issues,digest:value.receipt.layoutCertification.outputDigest}
 const row={name:entry.name,backend,svgExact:!a.error&&!b.error&&a.svg===b.svg,noncertExact:!a.error&&!b.error&&JSON.stringify(omit(a))===JSON.stringify(omit(b)),counts:count,control:summarize(a),candidate:summarize(b)}
 rows.push(row);console.log(JSON.stringify(row));writeFileSync(new URL('CAPACITY-BOUNDS-BRIDGED.json',import.meta.url),JSON.stringify(rows,null,2))
}
