import type { Geometry, MarkPaint, ScenePoint } from './ir.ts'
// Internal implementations of the existing paint/geometry interfaces. Values
// live in private slots, never in mutable receiver fields exposed to a helper.
const issuer = { __proto__: null }
const seal = Object.preventExtensions, proto = Object.getPrototypeOf, extensible = Object.isExtensible, keys = Reflect.ownKeys
const define = Object.defineProperties, freeze = Object.freeze, descriptor = Object.getOwnPropertyDescriptor
function closePrototype(value: object, fields: Record<string, () => unknown>): boolean {
  const expected = { __proto__: null, ...fields } as unknown as Record<string, () => unknown>
  const slots = { __proto__: null } as unknown as PropertyDescriptorMap
  for (const key in expected) slots[key] = { __proto__: null, get: expected[key], enumerable: true, configurable: false } as PropertyDescriptor
  define(value, slots)
  freeze(value)
  if (extensible(value)) return false
  for (const key in expected) { const slot = descriptor(value, key); if (!slot || slot.get !== expected[key] || slot.set !== undefined || slot.configurable) return false }
  return true
}
function closeInstance(value: object, expectedPrototype: object, ready: boolean): void {
  if (!ready || seal(value) !== value || extensible(value) || proto(value) !== expectedPrototype || keys(value).length !== 0) throw new TypeError('Actual writer receiver could not be closed')
}

class WrittenPoint implements ScenePoint {
  declare readonly x: number
  declare readonly y: number
  readonly #x: number
  readonly #y: number
  constructor(token: object, x: number, y: number) {
    if (token !== issuer) throw new TypeError('Actual values require their writer')
    this.#x = x
    this.#y = y
    closeInstance(this, WrittenPoint.prototype, WrittenPointReady)
  }
  static x(value: WrittenPoint): number { return value.#x }
  static y(value: WrittenPoint): number { return value.#y }
  static owns(value: unknown): value is WrittenPoint { return !!value && typeof value === 'object' && #x in value }
}
const readWrittenPointx = WrittenPoint.x
const readWrittenPointy = WrittenPoint.y
const ownsWrittenPoint = WrittenPoint.owns
const WrittenPointReady = closePrototype(WrittenPoint.prototype, {
  x: function(this: WrittenPoint) { return readWrittenPointx(this) },
  y: function(this: WrittenPoint) { return readWrittenPointy(this) },
})
export function isWrittenPoint(value: unknown): value is ScenePoint { return ownsWrittenPoint(value) }
export function createWrittenPoint(x: number, y: number): ScenePoint | undefined {
  try { return new WrittenPoint(issuer, x, y) } catch { return undefined }
}

class WrittenLine implements Extract<Geometry, { kind: 'line' }> {
  declare readonly kind: 'line'
  declare readonly x1: number
  declare readonly y1: number
  declare readonly x2: number
  declare readonly y2: number
  readonly #x1: number
  readonly #y1: number
  readonly #x2: number
  readonly #y2: number
  constructor(token: object, x1: number, y1: number, x2: number, y2: number) {
    if (token !== issuer) throw new TypeError('Actual values require their writer')
    this.#x1 = x1
    this.#y1 = y1
    this.#x2 = x2
    this.#y2 = y2
    closeInstance(this, WrittenLine.prototype, WrittenLineReady)
  }
  static kind(value: WrittenLine): 'line' { return 'line' }
  static x1(value: WrittenLine): number { return value.#x1 }
  static y1(value: WrittenLine): number { return value.#y1 }
  static x2(value: WrittenLine): number { return value.#x2 }
  static y2(value: WrittenLine): number { return value.#y2 }
  static owns(value: unknown): value is WrittenLine { return !!value && typeof value === 'object' && #x1 in value }
}
const readWrittenLinekind = WrittenLine.kind
const readWrittenLinex1 = WrittenLine.x1
const readWrittenLiney1 = WrittenLine.y1
const readWrittenLinex2 = WrittenLine.x2
const readWrittenLiney2 = WrittenLine.y2
const ownsWrittenLine = WrittenLine.owns
const WrittenLineReady = closePrototype(WrittenLine.prototype, {
  kind: function(this: WrittenLine) { return readWrittenLinekind(this) },
  x1: function(this: WrittenLine) { return readWrittenLinex1(this) },
  y1: function(this: WrittenLine) { return readWrittenLiney1(this) },
  x2: function(this: WrittenLine) { return readWrittenLinex2(this) },
  y2: function(this: WrittenLine) { return readWrittenLiney2(this) },
})
export function isWrittenLine(value: unknown): value is Extract<Geometry, { kind: 'line' }> { return ownsWrittenLine(value) }
export function createWrittenLine(x1: number, y1: number, x2: number, y2: number): Extract<Geometry, { kind: 'line' }> | undefined {
  try { return new WrittenLine(issuer, x1, y1, x2, y2) } catch { return undefined }
}

class WrittenRect implements Extract<Geometry, { kind: 'rect' }> {
  declare readonly kind: 'rect'
  declare readonly x: number
  declare readonly y: number
  declare readonly width: number
  declare readonly height: number
  declare readonly rx: number | undefined
  declare readonly ry: number | undefined
  readonly #x: number
  readonly #y: number
  readonly #width: number
  readonly #height: number
  readonly #rx: number | undefined
  readonly #ry: number | undefined
  constructor(token: object, x: number, y: number, width: number, height: number, rx: number | undefined, ry: number | undefined) {
    if (token !== issuer) throw new TypeError('Actual values require their writer')
    this.#x = x
    this.#y = y
    this.#width = width
    this.#height = height
    this.#rx = rx
    this.#ry = ry
    closeInstance(this, WrittenRect.prototype, WrittenRectReady)
  }
  static kind(value: WrittenRect): 'rect' { return 'rect' }
  static x(value: WrittenRect): number { return value.#x }
  static y(value: WrittenRect): number { return value.#y }
  static width(value: WrittenRect): number { return value.#width }
  static height(value: WrittenRect): number { return value.#height }
  static rx(value: WrittenRect): number | undefined { return value.#rx }
  static ry(value: WrittenRect): number | undefined { return value.#ry }
  static owns(value: unknown): value is WrittenRect { return !!value && typeof value === 'object' && #x in value }
}
const readWrittenRectkind = WrittenRect.kind
const readWrittenRectx = WrittenRect.x
const readWrittenRecty = WrittenRect.y
const readWrittenRectwidth = WrittenRect.width
const readWrittenRectheight = WrittenRect.height
const readWrittenRectrx = WrittenRect.rx
const readWrittenRectry = WrittenRect.ry
const ownsWrittenRect = WrittenRect.owns
const WrittenRectReady = closePrototype(WrittenRect.prototype, {
  kind: function(this: WrittenRect) { return readWrittenRectkind(this) },
  x: function(this: WrittenRect) { return readWrittenRectx(this) },
  y: function(this: WrittenRect) { return readWrittenRecty(this) },
  width: function(this: WrittenRect) { return readWrittenRectwidth(this) },
  height: function(this: WrittenRect) { return readWrittenRectheight(this) },
  rx: function(this: WrittenRect) { return readWrittenRectrx(this) },
  ry: function(this: WrittenRect) { return readWrittenRectry(this) },
})
export function isWrittenRect(value: unknown): value is Extract<Geometry, { kind: 'rect' }> { return ownsWrittenRect(value) }
export function createWrittenRect(x: number, y: number, width: number, height: number, rx: number | undefined, ry: number | undefined): Extract<Geometry, { kind: 'rect' }> | undefined {
  try { return new WrittenRect(issuer, x, y, width, height, rx, ry) } catch { return undefined }
}

class WrittenPaint implements MarkPaint {
  declare readonly fill: string | undefined
  declare readonly fillOpacity: string | undefined
  declare readonly stroke: string | undefined
  declare readonly strokeOpacity: string | undefined
  declare readonly strokeWidth: string | undefined
  declare readonly strokeDasharray: string | undefined
  declare readonly strokeDashoffset: string | undefined
  declare readonly strokeLinecap: string | undefined
  declare readonly strokeLinejoin: string | undefined
  declare readonly strokeMiterlimit: string | undefined
  declare readonly vectorEffect: string | undefined
  declare readonly paintOrder: string | undefined
  declare readonly opacity: string | undefined
  readonly #fill: string | undefined
  readonly #fillOpacity: string | undefined
  readonly #stroke: string | undefined
  readonly #strokeOpacity: string | undefined
  readonly #strokeWidth: string | undefined
  readonly #strokeDasharray: string | undefined
  readonly #strokeDashoffset: string | undefined
  readonly #strokeLinecap: string | undefined
  readonly #strokeLinejoin: string | undefined
  readonly #strokeMiterlimit: string | undefined
  readonly #vectorEffect: string | undefined
  readonly #paintOrder: string | undefined
  readonly #opacity: string | undefined
  constructor(token: object, fill: string | undefined, fillOpacity: string | undefined, stroke: string | undefined, strokeOpacity: string | undefined, strokeWidth: string | undefined, strokeDasharray: string | undefined, strokeDashoffset: string | undefined, strokeLinecap: string | undefined, strokeLinejoin: string | undefined, strokeMiterlimit: string | undefined, vectorEffect: string | undefined, paintOrder: string | undefined, opacity: string | undefined) {
    if (token !== issuer) throw new TypeError('Actual values require their writer')
    this.#fill = fill
    this.#fillOpacity = fillOpacity
    this.#stroke = stroke
    this.#strokeOpacity = strokeOpacity
    this.#strokeWidth = strokeWidth
    this.#strokeDasharray = strokeDasharray
    this.#strokeDashoffset = strokeDashoffset
    this.#strokeLinecap = strokeLinecap
    this.#strokeLinejoin = strokeLinejoin
    this.#strokeMiterlimit = strokeMiterlimit
    this.#vectorEffect = vectorEffect
    this.#paintOrder = paintOrder
    this.#opacity = opacity
    closeInstance(this, WrittenPaint.prototype, WrittenPaintReady)
  }
  static fill(value: WrittenPaint): string | undefined { return value.#fill }
  static fillOpacity(value: WrittenPaint): string | undefined { return value.#fillOpacity }
  static stroke(value: WrittenPaint): string | undefined { return value.#stroke }
  static strokeOpacity(value: WrittenPaint): string | undefined { return value.#strokeOpacity }
  static strokeWidth(value: WrittenPaint): string | undefined { return value.#strokeWidth }
  static strokeDasharray(value: WrittenPaint): string | undefined { return value.#strokeDasharray }
  static strokeDashoffset(value: WrittenPaint): string | undefined { return value.#strokeDashoffset }
  static strokeLinecap(value: WrittenPaint): string | undefined { return value.#strokeLinecap }
  static strokeLinejoin(value: WrittenPaint): string | undefined { return value.#strokeLinejoin }
  static strokeMiterlimit(value: WrittenPaint): string | undefined { return value.#strokeMiterlimit }
  static vectorEffect(value: WrittenPaint): string | undefined { return value.#vectorEffect }
  static paintOrder(value: WrittenPaint): string | undefined { return value.#paintOrder }
  static opacity(value: WrittenPaint): string | undefined { return value.#opacity }
  static owns(value: unknown): value is WrittenPaint { return !!value && typeof value === 'object' && #fill in value }
}
const readWrittenPaintfill = WrittenPaint.fill
const readWrittenPaintfillOpacity = WrittenPaint.fillOpacity
const readWrittenPaintstroke = WrittenPaint.stroke
const readWrittenPaintstrokeOpacity = WrittenPaint.strokeOpacity
const readWrittenPaintstrokeWidth = WrittenPaint.strokeWidth
const readWrittenPaintstrokeDasharray = WrittenPaint.strokeDasharray
const readWrittenPaintstrokeDashoffset = WrittenPaint.strokeDashoffset
const readWrittenPaintstrokeLinecap = WrittenPaint.strokeLinecap
const readWrittenPaintstrokeLinejoin = WrittenPaint.strokeLinejoin
const readWrittenPaintstrokeMiterlimit = WrittenPaint.strokeMiterlimit
const readWrittenPaintvectorEffect = WrittenPaint.vectorEffect
const readWrittenPaintpaintOrder = WrittenPaint.paintOrder
const readWrittenPaintopacity = WrittenPaint.opacity
const ownsWrittenPaint = WrittenPaint.owns
const WrittenPaintReady = closePrototype(WrittenPaint.prototype, {
  fill: function(this: WrittenPaint) { return readWrittenPaintfill(this) },
  fillOpacity: function(this: WrittenPaint) { return readWrittenPaintfillOpacity(this) },
  stroke: function(this: WrittenPaint) { return readWrittenPaintstroke(this) },
  strokeOpacity: function(this: WrittenPaint) { return readWrittenPaintstrokeOpacity(this) },
  strokeWidth: function(this: WrittenPaint) { return readWrittenPaintstrokeWidth(this) },
  strokeDasharray: function(this: WrittenPaint) { return readWrittenPaintstrokeDasharray(this) },
  strokeDashoffset: function(this: WrittenPaint) { return readWrittenPaintstrokeDashoffset(this) },
  strokeLinecap: function(this: WrittenPaint) { return readWrittenPaintstrokeLinecap(this) },
  strokeLinejoin: function(this: WrittenPaint) { return readWrittenPaintstrokeLinejoin(this) },
  strokeMiterlimit: function(this: WrittenPaint) { return readWrittenPaintstrokeMiterlimit(this) },
  vectorEffect: function(this: WrittenPaint) { return readWrittenPaintvectorEffect(this) },
  paintOrder: function(this: WrittenPaint) { return readWrittenPaintpaintOrder(this) },
  opacity: function(this: WrittenPaint) { return readWrittenPaintopacity(this) },
})
export function isWrittenPaint(value: unknown): value is MarkPaint { return ownsWrittenPaint(value) }
export function createWrittenPaint(fill: string | undefined, fillOpacity: string | undefined, stroke: string | undefined, strokeOpacity: string | undefined, strokeWidth: string | undefined, strokeDasharray: string | undefined, strokeDashoffset: string | undefined, strokeLinecap: string | undefined, strokeLinejoin: string | undefined, strokeMiterlimit: string | undefined, vectorEffect: string | undefined, paintOrder: string | undefined, opacity: string | undefined): MarkPaint | undefined {
  try { return new WrittenPaint(issuer, fill, fillOpacity, stroke, strokeOpacity, strokeWidth, strokeDasharray, strokeDashoffset, strokeLinecap, strokeLinejoin, strokeMiterlimit, vectorEffect, paintOrder, opacity) } catch { return undefined }
}
