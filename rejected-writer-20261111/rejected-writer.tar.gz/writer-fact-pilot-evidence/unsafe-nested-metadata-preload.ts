import { plugin } from 'bun'
import { readFileSync } from 'node:fs'
plugin({name:'retained-unsafe-nested-metadata',setup(build){build.onLoad({filter:/actual-write-records\.ts$/},args=>({contents:readFileSync(args.path,'utf8').replace('export function prepareWrittenMetadata<T extends SceneNodeBase>(metadata: T) {','export function prepareWrittenMetadata<T extends SceneNodeBase>(metadata: T) { return metadata;'),loader:'ts'}))}})
