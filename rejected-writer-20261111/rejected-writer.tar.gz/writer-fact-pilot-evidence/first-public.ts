import { renderMermaidSVGWithReceipt } from '../writer-fact-pilot/src/index.ts'
try {
  const value = renderMermaidSVGWithReceipt('flowchart TD\n A --> B', { graphLayout: { backend: 'agentic', fallback: 'none' } })
  console.log(JSON.stringify({status:'returned', svg:value.svg, proof:value.receipt.layoutCertification}))
} catch(error) { console.log(JSON.stringify({status:'failed', name:error?.constructor?.name, message:String(error?.message), stack:error?.stack})); process.exitCode=1 }
