p='src/scene/actual-write-records.ts';s=open(p).read().replace('ShapeMark, TextMark','ShapeMark, TextMark, SceneNodeBase, SceneOwner, MarkAttributes')
s="import type { SvgSemanticIdentity } from './identity.ts'\nimport type { SvgSemanticAccessibility } from './accessibility.ts'\n"+s
specs=[('WrittenIdentity','SvgSemanticIdentity',['id','role','from','to'],['classNames']),('WrittenOwner','SceneOwner',['id','role'],[]),('WrittenAttributes','MarkAttributes',['className','ariaHidden','tabIndex','ariaLabel'],['data']),('WrittenAccessibility','SvgSemanticAccessibility',['role','roleDescription','label'],[])]
for name,typ,fields,empty in specs:
 s+=f'\nclass {name} implements {typ} {{\n'
 for f in fields+empty:s+=f"  declare readonly {f}: {typ}['{f}']\n"
 for f in fields:s+=f"  readonly #{f}: {typ}['{f}']\n"
 args=', '.join(f"{f}: {typ}['{f}']" for f in fields)
 s+=f"  constructor(token: object, {args}) {{\n    if (token !== issuer) throw new TypeError('Actual values require their writer')\n"
 for f in fields:s+=f'    this.#{f} = {f}\n'
 s+=f'    closeInstance(this, {name}.prototype, {name}Ready)\n  }}\n'
 for f in fields:s+=f"  static {f}(value: {name}): {typ}['{f}'] {{ return value.#{f} }}\n"
 for f in empty:s+=f'  static {f}(value: {name}): undefined {{ return undefined }}\n'
 s+='}\n'
 for f in fields+empty:s+=f'const read{name}{f} = {name}.{f}\n'
 s+=f'const {name}Ready = closePrototype({name}.prototype, {{\n'
 for f in fields+empty:s+=f'  {f}: function(this: {name}) {{ return read{name}{f}(this) }},\n'
 s+='})\n'
s+='''
/** Snapshot all semantic scalars before exposing any new receiver to a sealing
 * helper. Only proof-relevant metadata survives in this private projection;
 * the full original node remains the actual writer/SDK receiver. */
export function prepareWrittenMetadata<T extends SceneNodeBase>(metadata: T) {
  const i = metadata.identity, o = metadata.owner, a = metadata.attributes, c = metadata.accessibility
  const iid = i?.id, irole = i?.role, from = i?.from, to = i?.to
  const oid = o?.id, orole = o?.role
  const className = a?.className, ariaHidden = a?.ariaHidden, tabIndex = a?.tabIndex, ariaLabel = a?.ariaLabel
  const role = c?.role, roleDescription = c?.roleDescription, label = c?.label
  if (i && (typeof iid !== 'string' || typeof irole !== 'string' || from !== undefined && typeof from !== 'string' || to !== undefined && typeof to !== 'string')
    || o && (typeof oid !== 'string' || typeof orole !== 'string')
    || a && (className !== undefined && typeof className !== 'string' || ariaHidden !== undefined && ariaHidden !== true || tabIndex !== undefined && tabIndex !== 0 || ariaLabel !== undefined && typeof ariaLabel !== 'string')
    || c && (typeof role !== 'string' || typeof roleDescription !== 'string' || typeof label !== 'string')) return undefined
  try {
    return { __proto__: null, ...metadata, channels: undefined,
      identity: i ? new WrittenIdentity(issuer, iid!, irole!, from, to) : undefined,
      owner: o ? new WrittenOwner(issuer, oid!, orole!) : undefined,
      attributes: a ? new WrittenAttributes(issuer, className, ariaHidden, tabIndex, ariaLabel) : undefined,
      accessibility: c ? new WrittenAccessibility(issuer, role!, roleDescription!, label!) : undefined }
  } catch { return undefined }
}
'''
open(p,'w').write(s)
p='src/scene/native-paint-emission.ts';s=open(p).read().replace('createWrittenShape, isWrittenShape,','prepareWrittenMetadata, createWrittenShape, isWrittenShape,',1)
s=s.replace("const metadata = { __proto__: null, ...submittedMetadata }", "const submitted = { __proto__: null, ...submittedMetadata }\n      let metadata = submitted",2)
s=s.replace("if (closed !== metadata || textPaintProto(metadata) !== null) return undefined", "if (closed !== metadata || textPaintProto(metadata) !== null || !pay(27)) return undefined\n      const preparedMetadata = prepareWrittenMetadata(metadata)\n      if (!preparedMetadata) return undefined\n      metadata = preparedMetadata",2)
open(p,'w').write(s)
