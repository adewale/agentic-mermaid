p='src/scene/actual-write-records.ts'
s=open(p).read().replace("Geometry, MarkPaint, ScenePoint", "Geometry, MarkPaint, ScenePoint, ShapeMark")
fields=['kind','id','role','identity','owner','visibility','accessibility','channels','transform','attributes','childPaints','conditionalPaint','surfaceFragment']
s+='\nexport type WrittenShapeMetadata = Omit<ShapeMark, \'geometry\' | \'paint\'>\n'
s+='class WrittenShape implements ShapeMark {\n'
for f in fields+['geometry','paint']:s+=f"  declare readonly {f}: ShapeMark['{f}']\n"
s+='  readonly #metadata: WrittenShapeMetadata\n  readonly #geometry: Geometry\n  readonly #paint: MarkPaint\n'
s+='  constructor(token: object, metadata: WrittenShapeMetadata, geometry: Geometry, paint: MarkPaint) {\n    if (token !== issuer) throw new TypeError(\'Actual values require their writer\')\n    this.#metadata = metadata; this.#geometry = geometry; this.#paint = paint\n    closeInstance(this, WrittenShape.prototype, WrittenShapeReady)\n  }\n'
for f in fields:s+=f"  static {f}(value: WrittenShape): ShapeMark['{f}'] {{ return value.#metadata.{f} }}\n"
s+="  static geometry(value: WrittenShape): Geometry { return value.#geometry }\n  static paint(value: WrittenShape): MarkPaint { return value.#paint }\n  static owns(value: unknown): value is WrittenShape { return !!value && typeof value === 'object' && #metadata in value }\n}\n"
for f in fields+['geometry','paint']:s+=f'const readWrittenShape{f} = WrittenShape.{f}\n'
s+='const ownsWrittenShape = WrittenShape.owns\nconst WrittenShapeReady = closePrototype(WrittenShape.prototype, {\n'
for f in fields+['geometry','paint']:s+=f'  {f}: function(this: WrittenShape) {{ return readWrittenShape{f}(this) }},\n'
s+='})\nexport function isWrittenShape(value: unknown): value is ShapeMark { return ownsWrittenShape(value) }\n'
s+='export function createWrittenShape(metadata: WrittenShapeMetadata, geometry: Geometry, paint: MarkPaint): ShapeMark | undefined {\n  try { return new WrittenShape(issuer, metadata, geometry, paint) } catch { return undefined }\n}\n'
open(p,'w').write(s)
p='src/scene/marks.ts';s=open(p).read();s=s.replace('consume: (node: ShapeMark) => T): T { return consume(normalizeShape(fields)) }', 'consume: (node: ShapeMark, fallback: () => ShapeMark) => T): T { const node = normalizeShape(fields); return consume(node, () => admitWritableSceneNode(node)) }');open(p,'w').write(s)
p='src/scene/native-paint-emission.ts';s=open(p).read();s="import { createWrittenShape, isWrittenShape } from './actual-write-records.ts'\nimport { hasDomSvgIdentityRole } from './identity.ts'\n"+s
s=s.replace('import { createNativeXmlWork,','import { withSvgActualPaintInputs, readSvgActualInputs, createNativeXmlWork,',1)
s=s.replace("else if (!Object.hasOwn(node, 'transform') && 'transform' in node) uncertain = true", "else if (!isWrittenShape(node) && !Object.hasOwn(node, 'transform') && 'transform' in node) uncertain = true",1)
needle='    leaf(node: Leaf, write:';pos=s.index(needle)
s=s[:pos]+'''    constructedShape(node: ShapeMark, write: (node: ShapeMark) => SvgXmlWrite) {
      if (!closeLeaves || node.geometry.kind !== 'rect' || node.transform || node.childPaints || node.conditionalPaint) return undefined
      const { geometry: _geometry, paint: _paint, ...metadata } = node
      let closed: typeof metadata
      try { closed = copy(metadata, 0, new Set(), undefined, true) as typeof metadata } catch { return undefined }
      if (closed !== metadata) return undefined
      const written = withSvgActualPaintInputs(xml, () => write(node))
      const record = xml.read(written, node)
      if (!record) throw new TypeError('Constructed shape lost its actual write')
      const geometry = readSvgRectangleWrite(xml, written, node, node.geometry), inputs = readSvgActualInputs(xml, written, node)
      const identity = metadata.identity, domIdentity = identity && hasDomSvgIdentityRole(identity.role)
      let bound = !!geometry && !!inputs && geometry.width > 0 && geometry.height > 0 && (geometry.rx ?? 0) === 0 && (geometry.ry ?? 0) === 0
      if (bound) {
        bound = pay(8) && inputs!.attribute('transform') === undefined
          && inputs!.attribute('data-id') === (domIdentity ? identity.id : undefined)
          && inputs!.attribute('data-role') === (domIdentity ? identity.role : undefined)
          && inputs!.attribute('data-from') === (domIdentity ? identity.from : undefined)
          && inputs!.attribute('data-to') === (domIdentity ? identity.to : undefined)
          && inputs!.attribute('class') === (metadata.attributes?.className || undefined)
      }
      const paintNode = bound && pay(4) ? createWrittenShape(metadata, geometry!, inputs!.paint) : undefined
      if (paintNode && pay()) capturedLeaves.set(paintNode, paintNode)
      return { node, paintNode: paintNode ?? node, svg: record.svg, xmlWrite: written, conditional: !paintNode }
    },
'''+s[pos:];open(p,'w').write(s)
p='src/scene/native-drawing.ts';s=open(p).read()
s=s.replace("shape: fields => closeLeaves ? marks.constructNativeShape(fields, constructedLeaf) : leaf(marks.shape(fields)),", """shape: fields => closeLeaves ? marks.constructNativeShape(fields, (node, fallback) => {
      const captured = emission.constructedShape(node, source => validator.writeConstructed(source, xml))
      if (!captured) return leaf(fallback())
      return ownFragment({ kind: 'leaf', node: captured.paintNode, svg: captured.svg, xmlWrite: captured.xmlWrite,
        conditional: captured.conditional, nodeCount: 1, depth: 0, prepared: true })
    }) : leaf(marks.shape(fields)),""")
s=s.replace("text: fields => closeLeaves ? marks.constructNativeText(fields, constructedLeaf) : leaf(marks.text(fields)),", "text: fields => leaf(marks.text(fields)),")
s=s.replace("connector: fields => closeLeaves ? marks.constructNativeConnector(fields, constructedLeaf) : leaf(marks.connector(fields)),", "connector: fields => leaf(marks.connector(fields)),")
# Keep the first failing diagnostic as evidence, remove it from the runnable path.
a=s.index('  // Runnable construction pilot:');b=s.index('  const factory: DrawingFactory<Fragment>',a);s=s[:a]+s[b:]
open(p,'w').write(s)
