# Trinity stage4: independent kernel safety/value review

Read-only review of the current uncommitted kernel, neutral/boundary/fitting
changes, shared channel change and owning assertions. No source edits, tests,
builds, profiles, agents or external actions. This review establishes source
findings, not a shipped/public Trinity result.

## Findings to resolve or narrow explicitly

1. **Capacity currently bounds center pitch, not full endpoint support.** In
   trinity.ts117–123, the end margin is max(8, radius + half border), independent
   of the endpoint span. A cross-size16 fixed rectangle with a single100px
   endpoint support passes required16. With two24px supports, the current growth
   formula admits48px: centers are8px from either end, while their half-support
   is12px. The owning test asserts48px/32px center separation and therefore does
   not catch4px of end-support overhang. The loop capacity formula has the same
   end-margin issue. Incorporate the actual end support/contact-domain allowance
   in capacity, or decline the oversized-support domain. Do not advertise this
   as complete physical port capacity while only center spacing is established.

2. **Long self-loop minimum span is accepted and unused.** Edges validate any
   positive integer minSpan. Loops are removed from the rank propagation, and
   the loop sizing/routing branch never reads their minSpan. A minSpan2 loop
   therefore has the same reserved layout as minSpan1. Existing Native loop
   expansion propagated that demand to helper spokes. If long self-loop demand
   is outside this first slice, a typed capability decline is smaller and more
   honest than silently dropping it.

3. **Unknown paint/support defaults need an explicit admission meaning.** The
   kernel substitutes1px for absent maximumEdgeStrokeWidth/node paint width,
   16px for absent minimumTerminalLead and8px demand for absent endpoint spans.
   These are numerical legacy-style defaults, not measured physical bounds.
   The neutral interface currently does not establish that omission authorizes
   those exact paint/resource bounds for a new solver. Either require known
   captured demands for this slice, or document/enforce a producer-authorized
   default domain. Missing metadata cannot stand for an arbitrary unknown thick
   shaft or marker. This is especially relevant before claiming actual marker
   safety from final shaft/body admission: that pass checks shafts and labels,
   not independently emitted marker artwork.

4. **Supplied-ledger exhaustion is indistinguishable from capability decline.**
   spend/arc/order exhaustion all throw GraphLayoutUnsupportedError. When a
   future public adapter enters existing fallback policy, that error permits
   ELK fallback just like the local64/128 support limit. If the passed ChannelWork
   is the cumulative shared hard allowance promised by the specification, that
   classification is wrong; fallback must not turn an exhausted shared owner
   into fresh work. If it is intentionally a backend-local optional allowance,
   make that distinction explicit at its owning adapter and preserve the outer
   hard ledger. The current source has no public registration, so this is not
   a claim of an observed public fallback/reset.

## Preserved boundaries and remaining scope

The adapter retains the caller's ledger object across attempts and has no cache.
It allocates fresh result coordinates/routes and does not mutate measured node
sizes; returned dimensions express growth only for minimum-size bodies. The
common result boundary now rejects nonfinite node/group/route/label geometry
and enforces returned body-size policy. Fitting preserves actual returned sizes.
SCC orientation swaps endpoint span demand through backward-edge lookup and
restores authored point direction. The existing shared channel behavior is
algebraically unchanged when terminalMargins is absent; the new branch is used
only when explicitly requested.

The kernel explicitly declines compounds, ordering/partition constraints,
shared fans, unknown contact domains, rounded-route paint, invisible constraints
and unsupported marker/boundary metadata. It does not silently flatten those
constraints. Placement avoids route materialization/final validation but still
performs rank/dummy/channel reservation work; do not describe it as routing-free.
The current budget accounting is selective (for example, some scratch setup and
endpoint sorts are not charged), and row-sort comparison charges use host
Array.sort. Do not claim a complete host-invariant work-cost model from the
presence of three decrementing fields alone.

## Value interpretation

The Requirement candidate's roughly5.5%area reduction versus current ELK is a
real bounded geometry observation, with material costs: TB wire1054versusELK963
and Native671, bends18versus10/8, area243367versusELK257555 and Native230692.
Current Native already beats this TB area. The historical+9.53%gap does not
reproduce and cannot be called closed. The candidate is not a demonstrated
across-metric improvement or completed retained-ink repair.

Written-SVG/Chromium inspection is useful, but shared Trident enum/marker
vocabulary errors do not prove either lane lost meaning. Keep original failed
observations and pending canonical supplemental observations separate. There is
no public Trinity option/full receipt, no equivalent-work Trident speed result
and no adoption claim. Resolve or honestly decline the concrete unsupported
physical constraints above before using a smaller area as evidence of safety.

## Targeted follow-up: four original findings

Re-read current source after the coordinator's fixes; no tests, builds, profiles
or production edits by this reviewer. Original findings above are retained as
historical review evidence, not assertions that the old code is still present.

- **Endpoint capacity:** resolved in source. Nonloop face-end margin now includes
  corner bound + node half-stroke + maximum endpoint half-support; loop side-face
  capacity includes the corresponding loop support. The single100px support
  witness now declines a fixed16px body and the minimum-size path reserves its
  full interval. Rounded-loop assertions independently bound both support ends
  outside the corner region. This corrects the original center-pitch-only rule.
- **Long loops:** resolved by a specific minSpan!=1 self-loop capability decline.
  Ordinary long-edge ranking still consumes its declared span. This is an honest
  narrowed slice, not an unimplemented loop constraint silently accepted.
- **Unknown demands:** resolved for the reported defaults. Node stroke, maximum
  shaft width, track spacing, terminal lead and both endpoint supports must now
  be explicit. Missing values decline; malformed supplied numbers remain
  TypeErrors. The neutral comments now define symmetric endpoint support and a
  rounded radius bound that the producer must keep valid after permitted size
  growth. That is a producer obligation, not proof that every future rounded
  family has supplied a valid bound.
- **Exhaustion:** resolved in the inspected fallback path. Pair/arc/swap depletion
  throws LayoutWorkLimitError, a RangeError distinct from capability decline and
  certification rejection. The shared channel-helper callback inspects depleted
  resources and maps them to that error. Existing runMeasuredGraphBackend cannot
  catch it as a permitted ELK fallback. The same ledger remains live across
  solves and is not reset. This fixes classification, not complete operation or
  allocation accounting: selective charging and host Array.sort comparison
  counts still must not be advertised as a host-invariant cost model.

One additional constraint-classification issue remains in the re-read source:
`trinity.ts:62` compares every endpoint span with graph-wide
maximumEdgeStrokeWidth and calls a smaller span malformed. A valid2px-support
edge beside an unrelated10px shaft can therefore throw TypeError, although the
2px support fully bounds its own shaft. The common field means a graph maximum,
not each edge's width. Conservatively reserve at least the graph maximum during
capacity, or explicitly decline that heterogeneous domain; do not describe
faithful per-edge metadata as invalid. The uniform-width Requirement fixture
cannot expose this distinction.

Returned dimensions still obey fixed/minimum policy before family consumption,
and fitting preserves them. Explicit stroke-aware canvas padding and row/band
space are conservative reservations, not a substitute for physical writer proof.
There is still no public Trinity option or full receipt, and arbitrary caller
accessor graphs are outside the owned-measured-input premise.

The reported corrected canonical observer establishes the declared13criteria on
four direct-family Trinity SVGs. The retained original enum/triangle-vocabulary
failures and Native/ELK label-owner unknowns must remain separate. Neither that
bounded result nor area establishes general Trinity superiority, historical gap
closure, equivalent-work speed, full receipt behavior or adoption readiness.
