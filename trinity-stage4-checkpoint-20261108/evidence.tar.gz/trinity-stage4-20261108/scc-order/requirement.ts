import '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import { readFileSync,writeFileSync } from 'node:fs'
import { parseRequirementDiagram } from '/tmp/pr449-main-integration-20261029-762/src/requirement/parser.ts'
import { layoutRequirementDiagram } from '/tmp/pr449-main-integration-20261029-762/src/requirement/layout.ts'
import { renderRequirementSvg } from '/tmp/pr449-main-integration-20261029-762/src/requirement/renderer.ts'
import { requirementContainsPortSpan,requirementArrow,requirementContains,requirementMarkerTerminal } from '/tmp/pr449-main-integration-20261029-762/src/requirement/markers.ts'
import { resolveRenderRequest,resolvedFamilyRenderContextOf } from '/tmp/pr449-main-integration-20261029-762/src/render-contract.ts'
import { trinityMeasuredAdapter } from '/tmp/pr449-main-integration-20261029-762/src/layout/trinity.ts'
import { solveMeasuredLayout } from '/tmp/pr449-main-integration-20261029-762/src/layout/measured-backend.ts'
const root='/tmp/pr449-week-comparison-20261101/trinity-stage4-20261108/scc-order'
const original=readFileSync('/tmp/pr449-main-integration-20261029-762/eval/layout-compare/fixtures/requirement-backends.mmd','utf8'), results=[]
for(const direction of ['TB','BT','LR','RL']) {
 const source=original.replace('direction TB',`direction ${direction}`), model=parseRequirementDiagram(source), before=layoutRequirementDiagram(model,{graphLayout:{backend:'elk',fallback:'none'}})
 const indices=new Map(before.nodes.map((node,i)=>[node.id,i])), style=before.style
 const graph={nodes:before.nodes.map(node=>({id:node.id,width:node.width,height:node.height,contact:(style.cornerRadius?'rounded-rectangle':'rectangle') as 'rectangle'|'rounded-rectangle',paintCornerRadius:Math.min(style.cornerRadius??0,node.width/2,node.height/2),paintStrokeWidth:Number.parseFloat(node.style['stroke-width']??String(style.nodeLineWidth)),sizePolicy:'minimum' as const,minimumPortSpacing:requirementContainsPortSpan})),
 edges:before.edges.map(edge=>({source:indices.get(edge.src)!,target:indices.get(edge.dst)!,minSpan:1,label:{width:edge.label.width+16,height:edge.label.height+10},...(edge.type==='contains'?{sourcePortSpan:requirementContainsPortSpan}:{})})),direction:model.direction,padding:32,nodeSpacing:40,layerSpacing:72,edgeSpacing:Math.max(6,style.lineWidth+4),minimumTerminalLead:Math.max(requirementMarkerTerminal(requirementArrow.id,style.lineWidth,'end'),requirementMarkerTerminal(requirementContains.id,style.lineWidth,'start'))+style.edgeBendRadius,maximumEdgeStrokeWidth:style.lineWidth}
 let phase='kernel-solve'
 const work={pairs:1_000_000,arcs:65536,swaps:1_000_000}
 try {
  const geometry=solveMeasuredLayout({role:'routed',graph},trinityMeasuredAdapter(work)), positioned={...before,width:geometry.width,height:geometry.height,nodes:before.nodes.map((node,i)=>({...node,...geometry.nodes[i]})),edges:before.edges.map((edge,i)=>({...edge,...geometry.edges[i]}))}
  phase='family-render'
  const request=resolveRenderRequest(source,{embedFontImport:false},'svg'), svg=renderRequirementSvg({positioned,colors:request.appearance.colors,resolved:resolvedFamilyRenderContextOf(request)})
  writeFileSync(root+`/trinity-${direction}.svg`,svg);writeFileSync(root+`/trinity-${direction}.json`,JSON.stringify(positioned));writeFileSync(root+`/elk-${direction}.json`,JSON.stringify(before))
  results.push({direction,status:'returned-family-svg',elkArea:before.width*before.height,trinityArea:positioned.width*positioned.height,elkSize:[before.width,before.height],trinitySize:[positioned.width,positioned.height],remaining:work,svgBytes:Buffer.byteLength(svg),scope:'Existing ELK family output supplies measurements only. Direct family completion/scene renderer, not a public Trinity option or full receipt. No runtime ratio; prior ELK solve is outside a timed lane.'})
 }catch(error){results.push({direction,status:phase==='kernel-solve' && (error as any)?.code==='GRAPH_LAYOUT_UNSUPPORTED'?'unsupported':'error',phase,error:String(error),remaining:work})}
}
writeFileSync(root+'/REQUIREMENT.json',JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results))
