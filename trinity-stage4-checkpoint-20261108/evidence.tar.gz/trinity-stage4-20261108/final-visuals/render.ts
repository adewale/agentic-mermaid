import{readFileSync,writeFileSync}from'node:fs'
import{chromium}from'/tmp/pr449-main-integration-20261029-762/node_modules/playwright/index.mjs'
import{HOSTED_FONT_RESOURCES}from'/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import{inlineFontVarForRaster}from'/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import{createHash}from'node:crypto'
import{inspectFidelityPaint}from'/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/fidelity/paint.ts'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/trinity-stage4-20261108'
// Authored expectations from the retained fixture, independent of all solvers.
const expected={labels:['fast','suite','report','performance-1','Respond quickly with retained measured fields','high','test','bench suite','artifact','verifies','traces','derives','satisfies','refines'],nodes:[{id:'fast',label:'fast'},{id:'suite',label:'suite'},{id:'report',label:'report'}],edges:[['suite','fast','verifies'],['suite','fast','traces'],['fast','report','derives'],['report','fast','satisfies'],['fast','fast','refines']].map(([source,target,label])=>({source:source!,target:target!,label:label!,directed:true,startMarker:'none',endMarker:'arrow'}))}
// Use the already retained authored-observer ledgers; render only review images.
const faces=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const bytes=readFileSync(root+'/'+f.path);if(createHash('sha256').update(bytes).digest('hex')!==f.sha256)throw Error('font mismatch');return `@font-face{font-family:Inter;src:url(data:font/woff2;base64,${bytes.toString('base64')}) format('woff2');font-weight:100 900}`}).join('\n')
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium'});const rows=[]
try{const context=await browser.newContext({viewport:{width:1400,height:1100},deviceScaleFactor:2});const page=await context.newPage();await page.route('**/*',r=>r.abort());
for(const direction of ['TB'])for(const backend of ['elk','agentic','trinity']){
 const path=backend==='trinity'?out+`/reviewed-demand/trinity-${direction}.svg`:out+`/baseline-${backend}-${direction}.svg`
 const svg=inlineFontVarForRaster(readFileSync(path,'utf8'));await page.setContent(`<style>html,body{margin:0;background:white}${faces}</style>${svg}`);await page.evaluate(()=>document.fonts.ready)
 await page.screenshot({path:out+`/final-visuals/${backend}-${direction}.png`,clip:{x:0,y:0,width:Math.ceil(Number((await page.locator('svg').getAttribute('width'))!.replace('px',''))),height:Math.ceil(Number((await page.locator('svg').getAttribute('height'))!.replace('px','')))}})
 console.log(backend)
}

}finally{await browser.close()}
