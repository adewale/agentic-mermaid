import{readFileSync,writeFileSync}from'node:fs'
import{chromium}from'/tmp/pr449-main-integration-20261029-762/node_modules/playwright/index.mjs'
import{HOSTED_FONT_RESOURCES}from'/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import{inlineFontVarForRaster}from'/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import{createHash}from'node:crypto'
import{inspectFidelityPaint}from'/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/fidelity/paint.ts'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/trinity-stage4-20261108'
// Authored expectations from the retained fixture, independent of all solvers.
const expected={labels:['fast','suite','report','performance-1','Respond quickly with retained measured fields','high','test','bench suite','artifact','verifies','traces','derives','satisfies','refines'],nodes:[{id:'fast',label:'fast'},{id:'suite',label:'suite'},{id:'report',label:'report'}],edges:[['suite','fast','verifies'],['suite','fast','traces'],['fast','report','derives'],['report','fast','satisfies'],['fast','fast','refines']].map(([source,target,label])=>({source:source!,target:target!,label:label!,directed:true,startMarker:'none',endMarker:'arrow'}))}
writeFileSync(out+'/AUTHORED-EXPECTATIONS.json',JSON.stringify(expected,null,2)+'\n')
const faces=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const bytes=readFileSync(root+'/'+f.path);if(createHash('sha256').update(bytes).digest('hex')!==f.sha256)throw Error('font mismatch');return `@font-face{font-family:Inter;src:url(data:font/woff2;base64,${bytes.toString('base64')}) format('woff2');font-weight:100 900}`}).join('\n')
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium'});const rows=[]
try{const context=await browser.newContext({viewport:{width:1400,height:1100},deviceScaleFactor:2});const page=await context.newPage();await page.route('**/*',r=>r.abort());
for(const direction of ['TB','BT','LR','RL'])for(const backend of ['elk','agentic','trinity']){
 const path=backend==='trinity'?out+`/producer-channels/trinity-${direction}.svg`:out+`/baseline-${backend}-${direction}.svg`
 const svg=inlineFontVarForRaster(readFileSync(path,'utf8'));await page.setContent(`<style>html,body{margin:0;background:white}${faces}</style>${svg}`);await page.evaluate(()=>document.fonts.ready)
 const paint=await page.evaluate(inspectFidelityPaint,{family:'requirement',expected})
 rows.push({direction,backend,paint,scope:'Unmodified Trident browser observer of actual final SVG. Trinity is direct family lowering, not a public option or receipt. Unknown clipping/ownership/marker criteria remain unavailable.'});writeFileSync(out+'/INK.json',JSON.stringify(rows,null,2)+'\n')
 await page.screenshot({path:out+`/${backend}-${direction}.png`,clip:{x:0,y:0,width:Math.ceil(Number((await page.locator('svg').getAttribute('width'))!.replace('px',''))),height:Math.ceil(Number((await page.locator('svg').getAttribute('height'))!.replace('px','')))}})
 console.log(JSON.stringify({direction,backend,passed:paint.checks.filter(c=>c.status==='passed').length,failed:paint.checks.filter(c=>c.status==='failed').map(c=>c.criterion),unavailable:paint.checks.filter(c=>c.status==='unavailable').map(c=>c.criterion)}))
}
writeFileSync(out+'/BROWSER.json',JSON.stringify({version:browser.version(),fonts:'Manifest-verified Inter WOFF2, data URIs; requests blocked',observer:'Unmodified Trident f080278e31e4202ca89d524e4ee9e4cf3cbff038 inspectFidelityPaint',scope:'12 outputs of one retained fixture, four directions and3backends; direct-family Trinity versus public Native/ELK. No full-receipt or general ink-parity conclusion.'},null,2)+'\n')
}finally{await browser.close()}
