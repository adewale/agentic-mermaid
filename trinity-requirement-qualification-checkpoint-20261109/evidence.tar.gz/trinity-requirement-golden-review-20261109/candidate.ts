import { writeFileSync,readFileSync } from 'node:fs'
import { buildSectionBBrandEvidence } from '/tmp/pr449-main-integration-20261029-762/scripts/pr-assets/section-b-brand-evidence.ts'
import { renderMermaidSVG, renderMermaidSVGWithReceipt } from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const root='/tmp/pr449-main-integration-20261029-762', out='/tmp/pr449-week-comparison-20261101/trinity-requirement-golden-review-20261109'
const source=readFileSync(root+'/eval/layout-compare/fixtures/requirement-basic.mmd','utf8')
writeFileSync(out+'/candidate-watercolor.svg',renderMermaidSVG(source,{style:'watercolor'}))
const product=renderMermaidSVGWithReceipt(source,{embedFontImport:false})
writeFileSync(out+'/current-basic.svg',product.svg)
writeFileSync(out+'/current-basic.receipt.json',JSON.stringify(product.receipt,null,2))
writeFileSync(out+'/candidate-sheet.png',buildSectionBBrandEvidence())
