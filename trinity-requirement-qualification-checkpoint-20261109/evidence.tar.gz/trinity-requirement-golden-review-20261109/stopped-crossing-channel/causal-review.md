# Trinity TB fan: bounded return-channel diagnosis

Source reviewed: `705db8562` (compound behavior unchanged from `0597`). Read-only production. One instrumented full TB call located the emitting stage; it returns/proof-passes and retains the 29-crossing geometry. One captured-geometry arithmetic counterfactual was checked using existing helpers. No production candidate, new framework, cap change, cache, or performance claim.

**Conclusion: a strictly better local route exists inside the current geometric bounds, but it is absent from the existing sparse candidate graph. No sufficiently justified small production intervention follows yet. Stop here rather than convert this into a new postprocessing repair or reopen header/source-order/port probes.**

## Prior falsifiers remain stopped

Read `../README.md`, `causal-review.md`, `header-review.md` and the source-order result. The header trial introduces Native LR/Trinity TB resource refusals; source ordering improves TB29→22 but worsens BT10→21 and LR/RL9→14. Global neighbor-port projection also remains stopped. The subsequent Native pending-stub trial now refuses expansion under original caps and is not part of this proposal.

The retained Trinity TB/ELK comparison is a tradeoff: 29 versus 13 proper carrier crossings, but Trinity area293,974.2948 versus ELK509,478.8339 and wire4,742.624 versus5,878.856. The prior intersection study found 9 Trinity crossings above labels and20 below, with no crossing centers masked by halos or nodes. That is targeted geometric/mask evidence, not a complete new ink certification.

## First responsible stage for one specific pair

Edges2 and3 are a1→b2 and a2→b2. Their target ports remain ordered at x262.584 and280.852 on b2's south face. The two extra below-label intersections are at `(123.869,393.8)` and `(262.584,393.8)`.

Fresh `trace/TRACE.jsonl` identifies the producer, rather than guessing from final paths:

- Edge2 primary declines self-contact after expanded7,114→23,046. Ordinary sparse target graph2 selects a bottom return at **y418.55**, then publishes that route.
- Edge3 primary declines its virtual expansion eligibility before searching. Ordinary sparse target graph4 selects a target suffix through **y393.8**, then a closed excursion through y418.55. `removeClosedExcursions` removes the excursion; the two crossings are already present in the unshortened suffix. They are not introduced by that cleanup.
- `createEndpointSparseVisibilityGraph`, `compound-sparse-visibility.ts:100–105`, crops both target graphs at frame.bottom +2*clearance = **418.55**. Edge2's chosen return is exactly that boundary. Edge3's y393.8 is a solid-obstacle boundary (the taller b4's expanded bottom), not a globally allocated channel level.
- Sparse point generation at `:175–193,257–288,315–342` uses obstacle/terminal/anchor coordinates and selected ray intersections; it deliberately does not form the full Cartesian grid. These ordinary graphs have `interiorChannels=false`.
- A* at `:449–455,539–541` minimizes length plus bend penalty and terminal preference. `peerLease.guard` excludes illegal contact but permits proper crossings. `compound-boundary-routes.ts:296,338,874` reduces the exact crossing scorer to defined/undefined; `:1085–1105` commits the first admissible complete joined path. Crossing count is not its selection objective.

Thus this pair is a **sparse candidate-domain and objective distinction**, not a mistaken order in a shared return-channel allocator. No such allocator emits these levels.

## One checked same-bounds counterfactual

Simply placing edge3 below edge2 would require y>418.55, outside its current endpoint search bounds, although still inside the root canvas. Even expanding that crop would not make the longer path preferable under the present objective. Do not recommend crop expansion alone.

A smaller continuous-domain witness instead raises **edge2's existing bottom return**. Preserve all other paths, both moved segment x coordinates, every endpoint/dock, frame, node, label and reserved label shaft. Its minimum terminal-lead boundary is377.35+13.375=390.725; edge3's horizontal peer is at393.8. The midpoint **y392.2625** leaves the terminal lead intact and separates the two horizontal shafts. Only edge2's two return-corner y values change.

`geometry-probe.ts` / `GEOMETRY-COUNTERFACTUAL.json` establish:

- Existing crossing helper: **29→27**.
- Wire delta: **−52.575**; bend count, node/frame placement and all other routes unchanged.
- The changed segments clear all captured solid body/header/label obstacles. The sole full-path solid-box intersection is the unchanged traversal through edge2's own reserved label box; it is not a newly allowed foreign label crossing.
- Existing complete measured peer/marker contact scorer returns a finite score for the changed route and for every route against the changed complete snapshot. No contact rejection is ignored.
- The candidate remains within both the original target graph rectangle and the original root canvas.
- **392.2625 is absent from the graph's seed/projection coordinate domain.** With interior channels off, projection preserves an existing seed coordinate or lands on a solid/bounds boundary. Consequently this particular path was not an alternative that the existing A* could merely select differently.

The diagnostic predicates account for2,617 charges and192 support reservations, but those are isolated helper work, not a rendering cost or proof-budget qualification. No candidate SVG was emitted; no fresh output, meaning or raster certification is claimed.

## Why this does not yet justify a small runtime patch

The safe midpoint was derived from the *finished* edge3 peer, which does not exist when edge2 is routed. Baking that coordinate into edge2's graph would use future geometry; applying it afterwards would introduce a new route-repair phase. Adding arbitrary midpoints or all ray intersections would expand the candidate domain and charged storage. An objective change alone cannot select a missing route. Expanding the endpoint crop alone does not address its preference for shorter crossing paths. None of those is a one-line correction at a demonstrated mistaken allocator.

The rational next design question is whether bounded compound routing should have an explicit quality objective and a small, owned domain of clearance-critical return channels, or whether its current first-admissible/compact tradeoff is acceptable. That needs a scoped contract before implementation; this witness alone does not justify a general route search or postprocessor. It closes only2 of the16-crossing gap to ELK and provides no all-direction dominance claim.

Any future narrow proposal must preserve and disprove against ordinary one-target fans, reciprocal edges, unequal-height cards, physical marker spans and labels, plus all four directions of this named fan. Its actual producer must establish channel eligibility using currently owned geometry; final checks must preserve endpoint occurrence identity, minimum leads, complete body/header/label clearance, proper-versus-illegal peer contact, and original ledgers. A new refusal, hidden marker/label ink, loss of authored meaning, or adverse direction tradeoff falsifies it. The isolated finite scorer is insufficient as final acceptance evidence.

Evidence remains under this directory: actual trace/returned SVG+receipt, trace source override/job, captured-geometry probe and JSON. Original historical data is untouched.
