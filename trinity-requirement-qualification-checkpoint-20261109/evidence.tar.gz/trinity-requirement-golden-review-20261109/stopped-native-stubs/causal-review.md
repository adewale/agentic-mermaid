# Native TB compound fan: provisional endpoint obstacles

Revision: baseline `0597c632ffed2ae04909c13193635bf524d89d18`. Coordinator subsequently committed `705db` with flat-root-only Trinity projection; the compound source owner inspected here is unchanged. No production modifications. This is a bounded diagnostic, not a delivered fix or performance result.

## Reproduction and first expensive failure

The exact eight-labelled-edge, two-group K2,4 source and options are in `BASELINE.json`. Actual Bun 1.4.4 Native/fallback-none reproduces `agentic local cross-hierarchy visibility-arc limit`. Instrumented Node 24 independently reproduces the same failure; both Node traces finish with identical final ledgers. Existing BT refusal is a separate no-clear-corridor result, not diagnosed or repaired here.

The final throw is `compound-sparse-visibility.ts:528`, called through `compound-boundary-routes.ts:1119,1144`: edge 7, a2→b4, late source search. Its graph has 82 points/246 axis states; construction leaves 12 arc units and the thirteenth neighbor check refuses. Remaining comparison budget is 369,189, expanded vertices 29,771 < 32,768, and swap budget 840,982. This is genuinely the shared arc limit, not expansion or comparison exhaustion.

The earlier causal expenditure is at the *first/source* primary query on edges 1 and 2:

| Edge | Cartesian cells | Admissible roots | Popped axis states | Neighbor arc checks | Segment-cache capacity | Other arc capacity | Query total arcs |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 a2→b1 | 3,000 (75×40) | 9 | 3,692 | 14,768 | 5,592 | 278 | 20,638 |
| 2 a1→b2 | 3,680 (80×46) | 6 | 4,332 | 17,328 | 7,008 | 320 | 24,656 |

Both exhaust their reachable component and decline `no bounded clear corridor`. Including the one-unit label charge before each query, their primary phases consume **45,296 arc units**. Their queries also reserve 10,368/12,544 expansion units. No budget is refunded. Later direct/sparse strategies find routes for both edges; the shared budget eventually fails on edge 7. These counts are work accounting, not removable CPU or a measured speedup.

Owners: `compound-lazy-visibility.ts:47` Cartesian coordinates; `:52–71` charged segment-cache pages; `:91–105` private query-state pages; `:168–177` roots; `:184–226` A* traversal and failed exhaustion. The relevant grid obstacles number 40/46. Later sparse graphs are small (82–173 points); a blanket sparse-graph size diagnosis would miss the dominant preceding expenditure.

## Geometric witness; blocked-neighbor hypothesis rejected

`GOAL-COMPONENTS.json` and `analyze-components.py` apply the original strict point/segment predicates to the captured finite grids. The goals `(306.999,144.9)` and `(314.999,144.9)` belong to disconnected components of 199 and 279 cells, respectively. Neither component contains a source stub. **All four immediate goal neighbors are clear**, so a four-neighbor or blocked-anchor preflight would not avoid either search. There are admissible terminal roots, so a no-root preflight would not help either.

The component fences combine completed peer shafts, pending quotient shafts, labels, and the destination-group header. For edge 1, for example, completed edge 0 contributes an upper bar `[295.999,324.999] × [130.9,136.9]`; pending edge 2's ancestor-end segment contributes `[311.999,317.999] × [133.9,165.275]`. Their overlap closes the top/right exit. This is not an isolated goal cell. Do not add a general connectivity pass on the strength of this offline analysis.

## First ownership mismatch and smallest defensible counterfactual

At `compound-boundary-routes.ts:771–775`, the primary obstacle producer treats *all* other quotient shaft segments as hard rectangles. It excludes the current edge, invisible edges and ancestor-plan connections, but does **not** distinguish a pending lifted route from a completed leaf route.

That distinction already exists and is explicit elsewhere:

- `:738–747` constructs the route core; ancestor endpoint stubs are replaced by leaf connections. The ordinary Native core begins/ends at `escape`, with distance `min(clearance, segmentLength/2)`.
- `:847–849` says pending quotients still terminate on ancestor frames and hides them from sparse final-peer contact checking until their leaf routes are finalized.
- `:1167–1173` preserves the label corridor, replaces the placed points and adds the occurrence to `completed`.
- `:1181–1182` publishes the completed geometry to the peer owner; `compound-peer-geometry.ts:90–99` initially loads only visible, noncurrent peers.

**Do not drop whole provisional routes.** Native retains their interior quotient core and reserved label shaft; calling all quotient ink disposable would be wrong.

The narrow counterfactual is to trim **only pending lifted peers' ancestor endpoint→escape stubs** from their primary obstacle rectangles, retaining every interior/core segment, every label box, every completed route, all nodes and headers. Nonlifted peers retain their full routes. Use the same pending occurrence's endpoint ownership and escape arithmetic as the route-core producer. This is a producer-state correction, not a strategy-order change.

`PROVISIONAL-STUB-GEOMETRY.json` and `analyze-provisional-stubs.py` verify exactly that restricted counterfactual offline. On the *unchanged original coordinate grid*:

| Captured query | Original goal component / reachable admissible source terminals | Trim only replaced pending stubs |
|---|---|---|
| Edge 1 | 199 cells / 0 | 2,190 cells / 9 |
| Edge 2 | 279 cells / 0 | 2,409 cells / 3 |

The retained coordinate grid supplies actual orthogonal connectivity witnesses; no new routing coordinates, caps or caches were introduced. This analysis is unmetered offline geometry, **not** a shipping preflight, layout result, proof receipt, or claim of saving all 45,296 units.

## Falsifiers and limits

The next bounded trial belongs at the primary **shaft-obstacle producer**, not the visibility search. Preserve all charged work for actual produced geometry and every original cap. Preserve occurrence identity, reserve labels before filtering shaft pieces, and use `lifted` plus `completed` rather than assuming array order implies finality. Only trim an end that really crosses a hierarchy boundary; clamp short first/last segments exactly as the existing core producer does. A single-segment route needs both endpoint clips applied coherently, including the coincident-middle case. Ancestor plans and physical label-shaft specialization must retain their existing contracts.

Disprove the proposal if the actual original-cap TB call still refuses, if it merely shifts the failure to another resource, or if any finalized route loses its label/endpoint/header/body/peer obligations. The offline result does not establish BT recovery, all-direction recovery, quality, visible correctness or timing. Actual final SVG/meaning/contact checks remain necessary, including new leaf connections versus earlier completed peers and overlapping core/label reservations. Keep current contact and marker validators unchanged; do not rely on primary success alone. In Native, the final contact-closure call at `:1242` is conditional on rescued routes or physical metadata, so a trial that changes all-primary/all-rescued composition requires particular care and cannot treat the final receipt as its only ink oracle.

If a full render falsifies this precise ownership correction, retain the evidence and stop; do not escalate to removing reserved core shafts, resetting the shared ledger, raising caps, header changes or strategy-order retries.

Evidence: `BASELINE.json`, `trace/TRACE.jsonl`, `lazy-trace/TRACE.jsonl`, source-loader/trace scripts, `GOAL-COMPONENTS.json`, `PROVISIONAL-STUB-GEOMETRY.json`. No measured timing claim; no source changes.
