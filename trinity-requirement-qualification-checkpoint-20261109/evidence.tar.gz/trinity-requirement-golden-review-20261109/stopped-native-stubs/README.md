# Native compound provisional-stub trial

Source 705db8562b7b9729e71e78ebf0da94e6991342f0. No production change.

Exact labelled K2,4 Native TB baseline refuses at the shared visibility-arc limit. Offline connectivity supported trimming only pending lifted ancestor endpoint stubs. The actual isolated source-overlay trial, with original ledgers and caps, still refuses twice at the visibility-expansion limit. The proposal is falsified as a delivery repair and stopped. Reserved cores, headers and labels were not removed; no cap, strategy-order, cache or production changes ship.

The existing Node24/V8 collector first profiled three baseline refusals (cache0). The third collector slot is unchanged source, not an authored edit. Wall times 131.93/107.75/111.00ms; process CPU464.65/350.91/291.66ms includes other process threads. No complete SVG/receipt exists for these refusals and no completed-work comparison or expected speedup follows.

| Frame, original location | Self / inclusive elapsed sample-delta ms per attempt |
| --- | ---: |
| less, layout/compound-lazy-visibility.ts:129 | 11.643 / 18.525 |
| route, layout/compound-lazy-visibility.ts:91 | 9.119 / 67.221 |
| pop, layout/compound-lazy-visibility.ts:153 | 7.293 / 35.270 |
| heap, layout/compound-lazy-visibility.ts:113 | 7.191 / 7.191 |
| swap, layout/compound-lazy-visibility.ts:133 | 6.161 / 13.828 |

Inclusive values overlap, and elapsed sampling weights are not exclusive CPU or removable wall time. Inspector stop gaps56.96–103.93ms remain outside mapped project samples. Source-map and1/2/5ms sensitivity results are retained. These are the existing sparse typed state/heap pages, not a new cache discovery; the earlier array-directory trial remains stopped for mixed whole costs and inherited-descriptor behavior.

Evidence: BASELINE.json, causal-review.md, captured ledgers/grids, before and trimmed source overlays, trimmed-job.json, trimmed-TB/RESULT.json, profile-before raw profiles and analysis. No visible output or correctness gain claimed. Next investigation is Trinity compound crossing quality, independently of this failed Native delivery repair.
