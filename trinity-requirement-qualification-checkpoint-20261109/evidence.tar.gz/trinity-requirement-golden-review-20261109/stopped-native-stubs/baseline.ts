import { readFileSync, writeFileSync } from 'node:fs'
import { renderMermaidSVGWithReceipt } from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const root='/tmp/pr449-week-comparison-20261101/trinity-compound-native-cause-20261109'
const rows=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trinity-requirement-detours-20261109/fanin-before/DIRECTIONS.json','utf8'))
const prior=rows.find((r:any)=>r.backend==='agentic'&&r.direction==='TB')
const options={graphLayout:{backend:'agentic' as const,fallback:'none' as const},embedFontImport:false}
let result
try { const p=renderMermaidSVGWithReceipt(prior.source,options); result={status:'returned',svg:p.svg,receipt:p.receipt} }
catch(error){result={status:'error',error:String(error),stack:(error as Error).stack}}
writeFileSync(root+'/BASELINE.json',JSON.stringify({runtime:Bun.version,source:prior.source,options,priorStatus:prior.status,priorError:prior.error,result},null,2)+'\n')
console.log(JSON.stringify(result,null,2))
