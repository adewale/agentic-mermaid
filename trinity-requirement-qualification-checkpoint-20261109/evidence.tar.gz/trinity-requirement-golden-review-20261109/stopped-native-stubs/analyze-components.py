import json
from pathlib import Path
from collections import deque
p=Path('/tmp/pr449-week-comparison-20261101/trinity-compound-native-cause-20261109')
events=[json.loads(l) for l in (p/'lazy-trace/TRACE.jsonl').read_text().splitlines()]
result=[]
for g in [e for e in events if e['event']=='lazy-graph' and e['edge'] in [1,2]]:
 q=next(e for e in events if e['event']=='lazy-query-start' and e['graph']==g['graph']);x,y,boxes=g['x'],g['y'],g['relevant'];n=len(x)
 def xy(i):return x[i%n],y[i//n]
 def contains(i):
  px,py=xy(i);return [j for j,b in enumerate(boxes) if b['x']<px<b['x']+b['width'] and b['y']<py<b['y']+b['height']]
 def enters(a,b):
  ax,ay=xy(a);bx,by=xy(b)
  return [j for j,r in enumerate(boxes) if (r['x']<ax<r['x']+r['width'] and max(ay,by)>r['y'] and min(ay,by)<r['y']+r['height'])] if ax==bx else [j for j,r in enumerate(boxes) if (r['y']<ay<r['y']+r['height'] and max(ax,bx)>r['x'] and min(ax,bx)<r['x']+r['width'])]
 def neighbors(a):
  c,r=a%n,a//n
  return [b for b in [a-1 if c else -1,a+1 if c+1<n else -1,a-n if r else -1,a+n if r+1<len(y) else -1] if b>=0]
 target=y.index(q['goal']['y'])*n+x.index(q['goal']['x']);todo=deque([target]);seen={target};boundary=[]
 while todo:
  a=todo.popleft()
  for b in neighbors(a):
   block=sorted(set(contains(b)+enters(a,b)))
   if block: boundary.append({'a':xy(a),'b':xy(b),'boxes':block})
   elif b not in seen: seen.add(b);todo.append(b)
 row={'edge':g['edge'],'target':q['goal'],'componentSize':len(seen),'component':[xy(i) for i in sorted(seen)],'neighbors':[{'point':xy(b),'contains':contains(b),'enters':enters(target,b)} for b in neighbors(target)],'boundary':boundary,'blockingBoxes':{str(j):boxes[j] for j in sorted({j for a in boundary for j in a['boxes']})},'starts':[{'stub':s['stub'],'component':y.index(s['stub']['y'])*n+x.index(s['stub']['x']) in seen,'blocked':contains(y.index(s['stub']['y'])*n+x.index(s['stub']['x']))} for s in q['starts']]}
 result.append(row)
(p/'GOAL-COMPONENTS.json').write_text(json.dumps(result,indent=2)+'\n')
for r in result: print(json.dumps(r,indent=2))
