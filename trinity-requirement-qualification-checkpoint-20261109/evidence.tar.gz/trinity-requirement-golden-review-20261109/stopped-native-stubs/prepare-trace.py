from pathlib import Path
import json
repo=Path('/tmp/pr449-main-integration-20261029-762'); out=Path('/tmp/pr449-week-comparison-20261101/trinity-compound-native-cause-20261109')
def replace(s,a,b):
    if s.count(a)!=1: raise RuntimeError((a[:100],s.count(a)))
    return s.replace(a,b)
pre='const __trace=(value:unknown):void=>{(globalThis as any).__compoundTrace?.(value)}\n'
s=(repo/'src/layout/compound-boundary-routes.ts').read_text()
s=replace(s,'  const leafCount = input.nodes.length, frames = placed.groups!, groups = input.groups!', '''  const __outerFail=fail
  fail=(reason:string):never=>{__trace({event:'fatal',reason,work:{...work}});return __outerFail(reason)}
  __trace({event:'entry',input,placed,owners:[...owners],work:{...work},expansionLimit})
  const leafCount = input.nodes.length, frames = placed.groups!, groups = input.groups!''')
s=replace(s,'    let peerLease: PeerLease | undefined', '''    ;(globalThis as any).__compoundEdge=index
    __trace({event:'edge-start',index,paddingAttempt,expanded,primaryVirtual,work:{...work}})
    let peerLease: PeerLease | undefined''')
s=replace(s,'      let points: Point[] | undefined', '''      __trace({event:'obstacles',index,nodes,frames,obstacles,solidObstacles,bounds,sources,targets,start,end,core,raw,widthProof:widthProof??null,work:{...work}})
      let points: Point[] | undefined''')
s=replace(s,'      if (!points) {\n        const probes', '''      __trace({event:'primary-end',index,decline,returned:!!points,expanded,primaryVirtual,work:{...work}})
      if (!points) {
        const probes''')
s=replace(s,'          const attempt = (route: () => void): boolean => {', '''          __trace({event:'sparse-start',index,decline,starts,ends,routeStart,routeEnd,routeCore,expanded,work:{...work}})
          const attempt = (route: () => void): boolean => {''')
s=replace(s,'      // Old source/target/guided graphs and nested callbacks end BEFORE release.', '''      __trace({event:'edge-end',index,paddingAttempt,publishPeer,expanded,primaryVirtual,work:{...work}})
      // Old source/target/guided graphs and nested callbacks end BEFORE release.''')
(out/'compound-boundary-routes.trace.ts').write_text(pre+s)
s=(repo/'src/layout/compound-sparse-visibility.ts').read_text()
s=replace(s,'  const right = bounds.x + bounds.width, bottom = bounds.y + bounds.height', '''  const __gid=((globalThis as any).__compoundGraph=((globalThis as any).__compoundGraph??0)+1)
  const __edge=(globalThis as any).__compoundEdge
  const __before={...work}
  __trace({event:'graph-start',graph:__gid,edge:__edge,bounds,obstacles,terminals,anchors,interiorChannels,guides:guideRails?.length??0,work:{...work}})
  const right = bounds.x + bounds.width, bottom = bounds.y + bounds.height''')
s=replace(s,'    let retired = false, activeQueries = 0', '''    __trace({event:'graph-built',graph:__gid,edge:__edge,points:points.length,states,relevant:relevant.length,allocatedVertices,work:{...work},arcCost:__before.arcs-work.arcs,pairCost:__before.pairs-work.pairs})
    let retired = false, activeQueries = 0''')
s=replace(s,'      activeQueries++', '''      const __qid=((globalThis as any).__compoundQuery=((globalThis as any).__compoundQuery??0)+1)
      const __queryBefore={...work};let __pops=0,__arcChecks=0,__goals=0,__accepts=0
      __trace({event:'query-start',query:__qid,graph:__gid,edge:__edge,starts:starts.length,goal,work:{...work}})
      activeQueries++''')
s=replace(s,'            const state = pop(), id = Math.floor(state / 3), axis = state % 3','            __pops++;const state = pop(), id = Math.floor(state / 3), axis = state % 3')
s=replace(s,'              if (accept(candidate)) return candidate', '''              __goals++
              const __accepted=accept(candidate)
              __trace({event:'goal',query:__qid,graph:__gid,edge:__edge,candidate,accepted:__accepted,work:{...work}})
              if (__accepted) {__accepts++;return candidate}''')
s=replace(s,"              if (--work.arcs < 0) fail('agentic local cross-hierarchy visibility-arc limit')", "              __arcChecks++;if (--work.arcs < 0) fail('agentic local cross-hierarchy visibility-arc limit')")
s=replace(s,'      } finally { activeQueries-- }', '''      } finally { activeQueries--;__trace({event:'query-end',query:__qid,graph:__gid,edge:__edge,pops:__pops,arcChecks:__arcChecks,goals:__goals,accepts:__accepts,arcDelta:__queryBefore.arcs-work.arcs,pairDelta:__queryBefore.pairs-work.pairs,work:{...work}}) }''')
(out/'compound-sparse-visibility.trace.ts').write_text(pre+s)
runner=Path('/tmp/pr449-week-comparison-20261101/trinity-requirement-detours-20261109/run-diagnostic.mjs').read_text()
runner=replace(runner,"const {renderMermaidSVGWithReceipt}=await import(pathToFileURL(root+'/src/index.ts'));", "globalThis.__compoundTrace=value=>fs.appendFileSync(out+'/TRACE.jsonl',JSON.stringify(value)+'\\n');\nconst {renderMermaidSVGWithReceipt}=await import(pathToFileURL(root+'/src/index.ts'));")
runner=replace(runner,'call<2','call<1')
(out/'run-trace.mjs').write_text(runner)
baseline=json.loads((out/'BASELINE.json').read_text())
job={'source':baseline['source'],'options':baseline['options'],'moduleOverrides':{str(repo/'src/layout/compound-boundary-routes.ts'):str(out/'compound-boundary-routes.trace.ts'),str(repo/'src/layout/compound-sparse-visibility.ts'):str(out/'compound-sparse-visibility.trace.ts')}}
(out/'trace-job.json').write_text(json.dumps(job,indent=2)+'\n')
