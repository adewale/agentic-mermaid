import json,math
from pathlib import Path
from collections import deque
p=Path('/tmp/pr449-week-comparison-20261101/trinity-compound-native-cause-20261109');ev=[json.loads(l) for l in (p/'lazy-trace/TRACE.jsonl').read_text().splitlines()];entry=next(e for e in ev if e['event']=='entry')
def box(a,b):return {'x':min(a['x'],b['x'])-3,'y':min(a['y'],b['y'])-3,'width':abs(a['x']-b['x'])+6,'height':abs(a['y']-b['y'])+6}
def esc(a,b):
 d=min(8,(abs(a['x']-b['x'])+abs(a['y']-b['y']))/2);return {'x':a['x']+((b['x']>a['x'])-(b['x']<a['x']))*d,'y':a['y']+((b['y']>a['y'])-(b['y']<a['y']))*d}
def equal(a,b):return all(abs(a[k]-b[k])<1e-8 for k in a)
results=[]
for g in [e for e in ev if e['event']=='lazy-graph' and e['edge'] in [1,2]]:
 q=next(e for e in ev if e['event']=='lazy-query-start' and e['graph']==g['graph']);original=g['relevant'];changed=[dict(b) for b in original];edits=[]
 for other,r in enumerate(entry['placed']['edges']):
  if other<=g['edge']:continue
  pp=r['points'];new=[dict(a) for a in pp];new[0]=esc(pp[0],pp[1]);new[-1]=esc(pp[-1],pp[-2])
  for seg in sorted(set([0,len(pp)-2])):
   old=box(pp[seg],pp[seg+1]);ids=[i for i,b in enumerate(original) if equal(old,b)];assert len(ids)==1,(other,seg,ids)
   i=ids[0];replacement=box(new[seg],new[seg+1]);changed[i]=replacement;edits.append({'other':other,'segment':seg,'obstacle':i,'old':old,'new':replacement})
 x,y=g['x'],g['y'];n=len(x)
 def xy(i):return x[i%n],y[i//n]
 def blocked(boxes,a,b):
  ax,ay=a;bx,by=b
  return any((r['x']<ax<r['x']+r['width'] and max(ay,by)>r['y'] and min(ay,by)<r['y']+r['height']) if ax==bx else (r['y']<ay<r['y']+r['height'] and max(ax,bx)>r['x'] and min(ax,bx)<r['x']+r['width']) for r in boxes)
 def pointblocked(boxes,p):return any(b['x']<p[0]<b['x']+b['width'] and b['y']<p[1]<b['y']+b['height'] for b in boxes)
 def connected(boxes):
  goal=y.index(q['goal']['y'])*n+x.index(q['goal']['x']);todo=deque([goal]);seen={goal}
  while todo:
   a=todo.popleft();c,r=a%n,a//n
   for b in [a-1 if c else -1,a+1 if c+1<n else -1,a-n if r else -1,a+n if r+1<len(y) else -1]:
    if b<0 or b in seen or pointblocked(boxes,xy(b)) or blocked(boxes,xy(a),xy(b)):continue
    seen.add(b);todo.append(b)
  roots=[]
  for i,s in enumerate(q['starts']):
   stub=(s['stub']['x'],s['stub']['y']);port=(s['port']['x'],s['port']['y']);j=y.index(stub[1])*n+x.index(stub[0]);
   if j in seen and not pointblocked(boxes,stub) and not blocked(boxes,port,stub):roots.append(i)
  return {'componentCells':len(seen),'reachableAdmissibleTerminalOrdinals':roots}
 results.append({'edge':g['edge'],'note':'Offline geometry counterfactual; original coordinate grid held fixed. No layout, proof or runtime result.', 'original':connected(original),'trimOnlyReplacedAncestorStubs':connected(changed),'edits':edits})
(p/'PROVISIONAL-STUB-GEOMETRY.json').write_text(json.dumps(results,indent=2)+'\n')
for r in results:print({k:v for k,v in r.items() if k!='edits'})
