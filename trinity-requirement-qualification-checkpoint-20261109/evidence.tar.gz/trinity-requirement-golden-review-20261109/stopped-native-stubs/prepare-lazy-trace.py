from pathlib import Path
import json
repo=Path('/tmp/pr449-main-integration-20261029-762'); out=Path('/tmp/pr449-week-comparison-20261101/trinity-compound-native-cause-20261109')
s=(repo/'src/layout/compound-lazy-visibility.ts').read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a))
 s=s.replace(a,b)
rep('  let allocated = 0', '''  const __gid=((globalThis as any).__lazyGraph=((globalThis as any).__lazyGraph??0)+1),__edge=(globalThis as any).__compoundEdge
  let __segmentSlots=0
  let allocated = 0''')
rep('  // Parent and heap entries', "  __trace({event:'lazy-graph',graph:__gid,edge:__edge,x,y,cells,relevant,terminals,anchors})\n  // Parent and heap entries")
rep('            work.arcs -= count','            __segmentSlots+=count;work.arcs -= count')
rep('route(starts, goal) {','''route(starts, goal) {
    const __before={...work},__allocated=allocated,__slots=__segmentSlots;let __pops=0,__checks=0,__roots=0,__returned=false
    __trace({event:'lazy-query-start',graph:__gid,edge:__edge,starts,goal,work:{...work}})
    try {''')
rep('        page.distance[offset] = value; page.roots[offset] = index; enqueue(state)','        __roots++;page.distance[offset] = value; page.roots[offset] = index; enqueue(state)')
rep('      const state = pop(), id = Math.floor(state / 3), axis = state % 3','      __pops++;const state = pop(), id = Math.floor(state / 3), axis = state % 3')
rep('        return result','        __returned=true;return result')
rep("        if (--work.arcs < 0) fail('agentic local cross-hierarchy visibility-arc limit')", "        __checks++;if (--work.arcs < 0) fail('agentic local cross-hierarchy visibility-arc limit')")
rep("    return fail('cross-hierarchy route has no bounded clear corridor')\n  } }", """    return fail('cross-hierarchy route has no bounded clear corridor')
    } finally {__trace({event:'lazy-query-end',graph:__gid,edge:__edge,goal,returned:__returned,pops:__pops,checks:__checks,roots:__roots,segmentSlots:__segmentSlots-__slots,allocated:allocated-__allocated,arcCost:__before.arcs-work.arcs,pairCost:__before.pairs-work.pairs,work:{...work}})}
  } }""")
(out/'compound-lazy-visibility.trace.ts').write_text('const __trace=(value:unknown):void=>{(globalThis as any).__compoundTrace?.(value)}\n'+s)
job=json.loads((out/'trace-job.json').read_text());job['moduleOverrides'][str(repo/'src/layout/compound-lazy-visibility.ts')]=str(out/'compound-lazy-visibility.trace.ts');(out/'lazy-job.json').write_text(json.dumps(job,indent=2)+'\n')
