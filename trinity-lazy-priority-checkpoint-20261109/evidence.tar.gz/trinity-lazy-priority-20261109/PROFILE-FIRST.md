# Profile before local heap/priority reuse

Source ec7583e83547bc95d8d39a5076672bb6a97668a4. Existing complete Node24/V8 collector: one unprofiled warmup and three profiled full SVG+entire receipt calls (two repeats, one existing authored label edit), cache0. All three return/proof-pass; no refused shortcut substitutes for completed work.

| Frame / source | Self / inclusive elapsed sample-weight ms per call |
| --- | ---: |
| heap, src/layout/compound-lazy-visibility.ts:113 | 5.697 / 5.697 |
| less, src/layout/compound-lazy-visibility.ts:129 | 4.736 / 8.424 |
| ensure, src/layout/compound-lazy-visibility.ts:96 | 4.665 / 4.665 |
| pop, src/layout/compound-lazy-visibility.ts:153 | 4.629 / 18.561 |
| route, src/layout/compound-lazy-visibility.ts:91 | 4.564 / 52.407 |

Inclusive weights overlap. Sampling gaps/JIT/native/GC/scheduling remain in raw profiles and1/2/5ms sensitivity; weights are not exclusive CPU or removable wall time. Wall146.20/137.33/111.42ms, process CPU350.01/281.68/233.45ms.

Matching case: hot hash lookups in current query-owned typed SoA pages/heap. The stopped array-directory rewrite remains stopped. Test only duplicate operand loads: priority currently recomputed when the first comparison is false; swap rereads states that it just wrote. Local scalar reuse adds no cache, array, representation or heap ordering change. All work charges and caps stay identical. Expected whole-product speedup is unmeasured, not estimated from inclusive weights. No independent await exists and no AoS-to-SoA rewrite is relevant.

Existing cache inventory remains in docs/design/system/layout-0.6-performance-review.md. These query pages are work storage, not cross-request result caches; no new slow-design cache attribution is established by this profile. Cache0 disables the existing layout cache; other derived caches remain live.

Falsify shipment if any complete product/order/work-limit outcome changes, an ownership/mutable/getter protocol regresses, or the small intervention has no convincing complete-product value. Eight serial fresh source processes in existing ABBA/BAAB order consume40complete SVG+receipt calls, with import/writes/compression/GC outside render timing. Preserve adverse phase, heap/RSS and payload effects. No source production edit has been made.
