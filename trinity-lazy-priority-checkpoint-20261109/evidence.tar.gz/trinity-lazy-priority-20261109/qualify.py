from pathlib import Path
import json,gzip,statistics,collections
p=Path(__file__).parent;profile=json.load(open(p/'analysis.json'));runs=json.load(open(p/'ABBA-RUNS.json'))['runs'];groups={};refs={};allExact=True;states=collections.Counter();result=[]
for run in runs:
 d=p/run['directory'];x=json.loads(gzip.decompress((d/'RESULT.json.gz').read_bytes()));groups.setdefault(run['variant'],[]).append(x)
 for row in x['rows']:states[(row['status'],row.get('proof',{}).get('status'))]+=1
 for phase in ['warmup','repeat1','repeat2','edit','edit2']:
  value=tuple(gzip.decompress((d/(phase+suffix+'.gz')).read_bytes()) for suffix in ['.svg','.receipt.json']);key='edit' if phase.startswith('edit') else 'original';refs.setdefault(key,value);allExact &= value==refs[key]
 result.append({'run':run,'rows':x['rows']})
report={'source':'ec7583e83547bc95d8d39a5076672bb6a97668a4','completeCalls':sum(states.values()),'outcomes':[{'status':a,'proof':b,'count':n} for (a,b),n in states.items()],'allWholeSVGAndReceiptExact':allExact,'runs':result,'decision':'External local-scalar reuse trial. Decision pending measured complete-product costs; no production change.'}
(p/'ABBA-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
metrics=[]
for phase in ['cold-render','repeat1','repeat2','edit','edit2']:
 vals={k:[next(r for r in x['rows'] if r['phase']==phase) for x in v] for k,v in groups.items()}
 item={'phase':phase}
 for variant,rr in vals.items():
  item[variant]={key:{'median':statistics.median(row[key] for row in rr),'min':min(row[key] for row in rr),'max':max(row[key] for row in rr),'all':[row[key] for row in rr]} for key in ['wallMs','cpuMs','peakRssKiB']}
 metrics.append(item)
(p/'COST-SUMMARY.json').write_text(json.dumps({'outcomes':report['outcomes'],'exact':allExact,'metrics':metrics},indent=2)+'\n')
for item in metrics:
 print(item['phase'],{v:{k:round(item[v][k]['median'],3) for k in ['wallMs','cpuMs','peakRssKiB']} for v in ['baseline','local']})
print(report['outcomes'], 'entire product exact',allExact)
