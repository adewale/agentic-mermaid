# Flowchart SVG layout observations

Raw geometry measurements, not correctness verdicts or an overall quality ranking. Each metric compares the same assessed cases across every selected project. Counts of zero apply only to measured geometry; unassessed cases remain explicit.

Observer policy: `flowchart-svg-layout-v2`.

Sampled node/group/filled-marker contours and edge centerlines; measured text layout bounds; CSS pixels. Stroke width, self-crossings, marker-mid and pixel occlusion are not measured.

Crossings are transverse contacts between different edge centerlines; shared endpoints and tangencies are excluded. Shared and crowded parallel paths count edge pairs. Other overlap metrics count object pairs. Endpoint-node intersections exclude only the first/last 8 pixels of the route at the corresponding node. Parallel sections need at least 8 pixels of projected span and a gap below 7 pixels; shared-node terminal fans are exempt. Group containment and ordinary edge/frame crossings are allowed. Label overlaps concern text layout bounds, not pixel-level occlusion. Curves and node contours use bounded sampling; differences below the published tolerance are unresolved.

| Metric | Project | Version | Assessed / selected | Common cases | Count on common cases |
| --- | --- | --- | --- | --- | --- |
| crossings | adewale/agentic-mermaid | 0.5.7 | 63 / 72 | 63 | 3 |
| sharedPaths | adewale/agentic-mermaid | 0.5.7 | 63 / 72 | 63 | 15 |
| crowdedParallelPaths | adewale/agentic-mermaid | 0.5.7 | 63 / 72 | 63 | 0 |
| nodeOverlaps | adewale/agentic-mermaid | 0.5.7 | 68 / 72 | 68 | 0 |
| edgeNodeIntersections | adewale/agentic-mermaid | 0.5.7 | 63 / 72 | 63 | 0 |
| edgeEndpointNodeIntersections | adewale/agentic-mermaid | 0.5.7 | 63 / 72 | 63 | 0 |
| labelOverlaps | adewale/agentic-mermaid | 0.5.7 | 60 / 72 | 60 | 0 |
| edgeLabelIntersections | adewale/agentic-mermaid | 0.5.7 | 55 / 72 | 55 | 0 |
| labelNodeOverlaps | adewale/agentic-mermaid | 0.5.7 | 59 / 72 | 59 | 0 |
| edgeGroupTitleIntersections | adewale/agentic-mermaid | 0.5.7 | 63 / 72 | 63 | 0 |
| labelGroupBorderIntersections | adewale/agentic-mermaid | 0.5.7 | 60 / 72 | 60 | 0 |
| nodeGroupBorderIntersections | adewale/agentic-mermaid | 0.5.7 | 68 / 72 | 68 | 0 |
| labelMarkerOverlaps | adewale/agentic-mermaid | 0.5.7 | 55 / 72 | 55 | 0 |

Per-case contours, route samples, collision locations, observed partial counts and gap reasons are retained in `results.json`. Per-metric common case IDs are listed there. Compare the same observer policy, viewport and case selection; a lower count alone does not establish better semantics or a universally better layout.
