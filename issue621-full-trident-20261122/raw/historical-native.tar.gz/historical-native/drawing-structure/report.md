# Rendered structure diagnostics

Counts are passed / failed / unassessed / not applicable. The profile covers flowchart, class, state, ER and sequence topology, plus SVG quadrant point/caption box clearance. Other families and representations remain explicit gaps. These axes do not change the existing overall score.

| Project | Version | Format | Topology | Layout constraints |
| --- | --- | --- | --- | --- |
| adewale/agentic-mermaid | 0.5.7 | svg | 43 / 3 / 69 / 12 | 88 / 3 / 35 / 1 |
| adewale/agentic-mermaid | 0.5.7 | terminal | 65 / 2 / 48 / 12 | 29 / 1 / 96 / 1 |
