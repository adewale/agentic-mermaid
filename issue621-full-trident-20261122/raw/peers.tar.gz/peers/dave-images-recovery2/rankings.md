# DaveBench rankings

1342 examples per format; three runs after 30 warm-ups. Outputs are discarded without assessment.

- More completed examples is better; use the minimum completion count across three complete runs.
- For equal completion counts, when every tied row uses the same boundary kind (fresh process or persistent API), lower median total render/export time ranks first, but only when the three-run time ranges [min, max] do not overlap: differences inside run-to-run spread are not evidence.
- Identical completion counts share a rank when their boundary kinds differ, when a time is missing, or when their three-run time ranges overlap. Sorted by median, a row whose range overlaps the row above it takes that row's rank, so overlapping ranges chain into one shared rank.
- Rank SVG, PNG and terminal text separately through the declared public execution paths. Native CLI time includes per-example process startup.
- Fewer than three complete runs, or mixed versions/boundaries, remain unranked.

## SVG

| Rank | Project | Version | Completed | Failed | Median total seconds | Path |
|---:|---|---|---:|---:|---:|---|
| 1 | mermaid-js/mermaid | 12.3.0 | 1338 | 4 | 35.381 | Browser API |
| 2 | obsidianmd/pele | 1.13.0 | 1306 | 36 | 0.571 | Browser API |
| 3 | Dicklesworthstone/frankenmermaid | 0.6.0 | 1181 | 161 | 1.115 | Browser API |
| 4 | dfadler/zombie-mermaid | 5.18.0 | 1120 | 222 | 1.866 | Browser API |
| 5 | lukilabs/beautiful-mermaid | 1.1.3 | 513 | 829 | 1.163 | Browser API |

## PNG

| Rank | Project | Version | Completed | Failed | Median total seconds | Path |
|---:|---|---|---:|---:|---:|---|
| 1 | mermaid-js/mermaid | 12.3.0 | 1338 | 4 | 55.086 | Browser API; Trident PNG conversion of its SVG |
| 2 | obsidianmd/pele | 1.13.0 | 1306 | 36 | 7.470 | Browser API; Trident PNG conversion of its SVG |
| 3 | Dicklesworthstone/frankenmermaid | 0.6.0 | 1177 | 165 | 15.700 | Browser API; Trident PNG conversion of its SVG |
| 4 | dfadler/zombie-mermaid | 5.18.0 | 1120 | 222 | 9.474 | Browser API; Trident PNG conversion of its SVG |
| 5 | lukilabs/beautiful-mermaid | 1.1.3 | 513 | 829 | 3.416 | Browser API; Trident PNG conversion of its SVG |

