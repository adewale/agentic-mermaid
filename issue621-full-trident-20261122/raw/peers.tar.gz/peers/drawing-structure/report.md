# Rendered structure diagnostics

Counts are passed / failed / unassessed / not applicable. The profile covers flowchart, class, state, ER and sequence topology, plus SVG quadrant point/caption box clearance. Other families and representations remain explicit gaps. These axes do not change the existing overall score.

| Project | Version | Format | Topology | Layout constraints |
| --- | --- | --- | --- | --- |
| dfadler/zombie-mermaid | 5.18.0 | svg | 56 / 10 / 49 / 12 | 88 / 5 / 33 / 1 |
| dfadler/zombie-mermaid | 5.18.0 | terminal | 58 / 13 / 44 / 12 | 26 / 3 / 97 / 1 |
| Dicklesworthstone/frankenmermaid | 0.6.0 | svg | 0 / 16 / 99 / 12 | 80 / 1 / 45 / 1 |
| Dicklesworthstone/frankenmermaid | 0.6.0 | terminal | 0 / 1 / 114 / 12 | 0 / 0 / 126 / 1 |
| lukilabs/beautiful-mermaid | 1.1.3 | svg | 37 / 30 / 48 / 12 | 81 / 33 / 12 / 1 |
| lukilabs/beautiful-mermaid | 1.1.3 | terminal | 41 / 36 / 38 / 12 | 21 / 31 / 74 / 1 |
| mermaid-js/mermaid | 12.3.0 | svg | 70 / 3 / 42 / 12 | 88 / 3 / 35 / 1 |
| obsidianmd/pele | 1.13.0 | svg | 67 / 2 / 46 / 12 | 90 / 1 / 35 / 1 |
