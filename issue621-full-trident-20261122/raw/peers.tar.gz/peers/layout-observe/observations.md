# Flowchart SVG layout observations

Raw geometry measurements, not correctness verdicts or an overall quality ranking. Each metric compares the same assessed cases across every selected project. Counts of zero apply only to measured geometry; unassessed cases remain explicit.

Observer policy: `flowchart-svg-layout-v2`.

Sampled node/group/filled-marker contours and edge centerlines; measured text layout bounds; CSS pixels. Stroke width, self-crossings, marker-mid and pixel occlusion are not measured.

Crossings are transverse contacts between different edge centerlines; shared endpoints and tangencies are excluded. Shared and crowded parallel paths count edge pairs. Other overlap metrics count object pairs. Endpoint-node intersections exclude only the first/last 8 pixels of the route at the corresponding node. Parallel sections need at least 8 pixels of projected span and a gap below 7 pixels; shared-node terminal fans are exempt. Group containment and ordinary edge/frame crossings are allowed. Label overlaps concern text layout bounds, not pixel-level occlusion. Curves and node contours use bounded sampling; differences below the published tolerance are unresolved.

| Metric | Project | Version | Assessed / selected | Common cases | Count on common cases |
| --- | --- | --- | --- | --- | --- |
| crossings | Dicklesworthstone/frankenmermaid | 0.6.0 | 34 / 72 | 31 | 1 |
| crossings | dfadler/zombie-mermaid | 5.18.0 | 60 / 72 | 31 | 1 |
| crossings | lukilabs/beautiful-mermaid | 1.1.3 | 57 / 72 | 31 | 0 |
| crossings | mermaid-js/mermaid | 12.3.0 | 59 / 72 | 31 | 1 |
| crossings | obsidianmd/pele | 1.13.0 | 61 / 72 | 31 | 1 |
| sharedPaths | Dicklesworthstone/frankenmermaid | 0.6.0 | 34 / 72 | 31 | 4 |
| sharedPaths | dfadler/zombie-mermaid | 5.18.0 | 60 / 72 | 31 | 0 |
| sharedPaths | lukilabs/beautiful-mermaid | 1.1.3 | 57 / 72 | 31 | 10 |
| sharedPaths | mermaid-js/mermaid | 12.3.0 | 59 / 72 | 31 | 0 |
| sharedPaths | obsidianmd/pele | 1.13.0 | 61 / 72 | 31 | 0 |
| crowdedParallelPaths | Dicklesworthstone/frankenmermaid | 0.6.0 | 34 / 72 | 31 | 0 |
| crowdedParallelPaths | dfadler/zombie-mermaid | 5.18.0 | 60 / 72 | 31 | 0 |
| crowdedParallelPaths | lukilabs/beautiful-mermaid | 1.1.3 | 57 / 72 | 31 | 0 |
| crowdedParallelPaths | mermaid-js/mermaid | 12.3.0 | 59 / 72 | 31 | 0 |
| crowdedParallelPaths | obsidianmd/pele | 1.13.0 | 61 / 72 | 31 | 0 |
| nodeOverlaps | Dicklesworthstone/frankenmermaid | 0.6.0 | 57 / 72 | 51 | 0 |
| nodeOverlaps | dfadler/zombie-mermaid | 5.18.0 | 67 / 72 | 51 | 0 |
| nodeOverlaps | lukilabs/beautiful-mermaid | 1.1.3 | 62 / 72 | 51 | 0 |
| nodeOverlaps | mermaid-js/mermaid | 12.3.0 | 64 / 72 | 51 | 0 |
| nodeOverlaps | obsidianmd/pele | 1.13.0 | 67 / 72 | 51 | 0 |
| edgeNodeIntersections | Dicklesworthstone/frankenmermaid | 0.6.0 | 34 / 72 | 31 | 0 |
| edgeNodeIntersections | dfadler/zombie-mermaid | 5.18.0 | 60 / 72 | 31 | 0 |
| edgeNodeIntersections | lukilabs/beautiful-mermaid | 1.1.3 | 57 / 72 | 31 | 0 |
| edgeNodeIntersections | mermaid-js/mermaid | 12.3.0 | 59 / 72 | 31 | 0 |
| edgeNodeIntersections | obsidianmd/pele | 1.13.0 | 61 / 72 | 31 | 0 |
| edgeEndpointNodeIntersections | Dicklesworthstone/frankenmermaid | 0.6.0 | 34 / 72 | 31 | 0 |
| edgeEndpointNodeIntersections | dfadler/zombie-mermaid | 5.18.0 | 60 / 72 | 31 | 0 |
| edgeEndpointNodeIntersections | lukilabs/beautiful-mermaid | 1.1.3 | 57 / 72 | 31 | 0 |
| edgeEndpointNodeIntersections | mermaid-js/mermaid | 12.3.0 | 59 / 72 | 31 | 0 |
| edgeEndpointNodeIntersections | obsidianmd/pele | 1.13.0 | 61 / 72 | 31 | 0 |
| labelOverlaps | Dicklesworthstone/frankenmermaid | 0.6.0 | 41 / 72 | 34 | 0 |
| labelOverlaps | dfadler/zombie-mermaid | 5.18.0 | 53 / 72 | 34 | 0 |
| labelOverlaps | lukilabs/beautiful-mermaid | 1.1.3 | 54 / 72 | 34 | 0 |
| labelOverlaps | mermaid-js/mermaid | 12.3.0 | 59 / 72 | 34 | 0 |
| labelOverlaps | obsidianmd/pele | 1.13.0 | 57 / 72 | 34 | 0 |
| edgeLabelIntersections | Dicklesworthstone/frankenmermaid | 0.6.0 | 26 / 72 | 24 | 0 |
| edgeLabelIntersections | dfadler/zombie-mermaid | 5.18.0 | 48 / 72 | 24 | 0 |
| edgeLabelIntersections | lukilabs/beautiful-mermaid | 1.1.3 | 50 / 72 | 24 | 0 |
| edgeLabelIntersections | mermaid-js/mermaid | 12.3.0 | 52 / 72 | 24 | 0 |
| edgeLabelIntersections | obsidianmd/pele | 1.13.0 | 51 / 72 | 24 | 0 |
| labelNodeOverlaps | Dicklesworthstone/frankenmermaid | 0.6.0 | 39 / 72 | 34 | 0 |
| labelNodeOverlaps | dfadler/zombie-mermaid | 5.18.0 | 53 / 72 | 34 | 0 |
| labelNodeOverlaps | lukilabs/beautiful-mermaid | 1.1.3 | 54 / 72 | 34 | 0 |
| labelNodeOverlaps | mermaid-js/mermaid | 12.3.0 | 57 / 72 | 34 | 0 |
| labelNodeOverlaps | obsidianmd/pele | 1.13.0 | 56 / 72 | 34 | 0 |
| edgeGroupTitleIntersections | Dicklesworthstone/frankenmermaid | 0.6.0 | 32 / 72 | 29 | 0 |
| edgeGroupTitleIntersections | dfadler/zombie-mermaid | 5.18.0 | 59 / 72 | 29 | 0 |
| edgeGroupTitleIntersections | lukilabs/beautiful-mermaid | 1.1.3 | 56 / 72 | 29 | 0 |
| edgeGroupTitleIntersections | mermaid-js/mermaid | 12.3.0 | 59 / 72 | 29 | 0 |
| edgeGroupTitleIntersections | obsidianmd/pele | 1.13.0 | 60 / 72 | 29 | 0 |
| labelGroupBorderIntersections | Dicklesworthstone/frankenmermaid | 0.6.0 | 41 / 72 | 34 | 0 |
| labelGroupBorderIntersections | dfadler/zombie-mermaid | 5.18.0 | 53 / 72 | 34 | 0 |
| labelGroupBorderIntersections | lukilabs/beautiful-mermaid | 1.1.3 | 54 / 72 | 34 | 0 |
| labelGroupBorderIntersections | mermaid-js/mermaid | 12.3.0 | 59 / 72 | 34 | 0 |
| labelGroupBorderIntersections | obsidianmd/pele | 1.13.0 | 57 / 72 | 34 | 0 |
| nodeGroupBorderIntersections | Dicklesworthstone/frankenmermaid | 0.6.0 | 52 / 72 | 46 | 0 |
| nodeGroupBorderIntersections | dfadler/zombie-mermaid | 5.18.0 | 66 / 72 | 46 | 0 |
| nodeGroupBorderIntersections | lukilabs/beautiful-mermaid | 1.1.3 | 61 / 72 | 46 | 0 |
| nodeGroupBorderIntersections | mermaid-js/mermaid | 12.3.0 | 64 / 72 | 46 | 0 |
| nodeGroupBorderIntersections | obsidianmd/pele | 1.13.0 | 66 / 72 | 46 | 0 |
| labelMarkerOverlaps | Dicklesworthstone/frankenmermaid | 0.6.0 | 26 / 72 | 2 | 0 |
| labelMarkerOverlaps | dfadler/zombie-mermaid | 5.18.0 | 4 / 72 | 2 | 0 |
| labelMarkerOverlaps | lukilabs/beautiful-mermaid | 1.1.3 | 4 / 72 | 2 | 0 |
| labelMarkerOverlaps | mermaid-js/mermaid | 12.3.0 | 52 / 72 | 2 | 0 |
| labelMarkerOverlaps | obsidianmd/pele | 1.13.0 | 5 / 72 | 2 | 0 |

Per-case contours, route samples, collision locations, observed partial counts and gap reasons are retained in `results.json`. Per-metric common case IDs are listed there. Compare the same observer policy, viewport and case selection; a lower count alone does not establish better semantics or a universally better layout.
