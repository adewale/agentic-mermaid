# DaveBench rankings

1342 examples per format; three runs after 30 warm-ups. Outputs are discarded without assessment.

- More completed examples is better; use the minimum completion count across three complete runs.
- For equal completion counts, when every tied row uses the same boundary kind (fresh process or persistent API), lower median total render/export time ranks first, but only when the three-run time ranges [min, max] do not overlap: differences inside run-to-run spread are not evidence.
- Identical completion counts share a rank when their boundary kinds differ, when a time is missing, or when their three-run time ranges overlap. Sorted by median, a row whose range overlaps the row above it takes that row's rank, so overlapping ranges chain into one shared rank.
- Rank SVG, PNG and terminal text separately through the declared public execution paths. Native CLI time includes per-example process startup.
- Fewer than three complete runs, or mixed versions/boundaries, remain unranked.

## SVG

| Rank | Project | Version | Completed | Failed | Median total seconds | Path |
|---:|---|---|---:|---:|---:|---|
| 1 | adewale/agentic-mermaid | 0.5.7 | 1332 | 10 | 4.512 | Browser API |

## PNG

| Rank | Project | Version | Completed | Failed | Median total seconds | Path |
|---:|---|---|---:|---:|---:|---|
| 1 | adewale/agentic-mermaid | 0.5.7 | 1332 | 10 | 14.813 | Browser API; Trident PNG conversion of its SVG |

