import{readFileSync,writeFileSync,mkdirSync}from'node:fs'
const root='/tmp/pr449-main-integration-20261029-762',out=import.meta.dir,arm=process.env.BASELINE==='1'?'before':'after'
if(arm==='before'){const files=JSON.parse(readFileSync(out+'/BASELINE-OVERRIDES.json','utf8'));Bun.plugin({name:'frozen-existing-source',setup(build){build.onLoad({filter:/\.ts$/},({path})=>({contents:readFileSync(files[path]??path,'utf8'),loader:'ts'}))}})}
const{renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts'),{layoutMermaidWithReceipt}=await import(root+'/src/agent/core.ts'),{measureQuality}=await import(root+'/src/agent/quality.ts')
mkdirSync(out+'/nesting-products',{recursive:true});const rows=[]
for(const direction of ['TB','BT','LR','RL'])for(const nested of[false,true]){
 const source=`flowchart ${direction}\n${nested?'subgraph Outer[Outer]\n':''}subgraph Inner[Inner]\na[A]\nb[B]\nend\n${nested?'c[C]\nend\n':''}a -->${nested?'|handoff|':''} c${nested?'':'[C]'}\nc --> b`
 for(const backend of arm==='before'?['agentic']:['agentic','elk']){const id=[direction,nested?'nested':'one',backend,arm].join('-'),options={graphLayout:{backend,fallback:'none'},font:'Inter',embedFontImport:false,seed:60131};let row
 try{const product=renderMermaidSVGWithReceipt(source,options),result=layoutMermaidWithReceipt(source,options),quality=measureQuality(result.layout);writeFileSync(out+'/nesting-products/'+id+'.svg',product.svg);writeFileSync(out+'/nesting-products/'+id+'.receipt.json',JSON.stringify(product.receipt));writeFileSync(out+'/nesting-products/'+id+'.layout.json',JSON.stringify(result));const nodes=result.layout.nodes;const get=(id:string)=>nodes.find((n:any)=>n.id===id)!;const a=get('a'),b=get('b'),c=get('c'),h=direction==='LR'||direction==='RL',rev=direction==='BT'||direction==='RL';const at=(n:any)=>n.bounds??n;const precedes=(aa:any,bb:any)=>{const a=at(aa),b=at(bb);return rev?(h?a.x:a.y)>=(h?b.x+b.w:b.y+b.h)-1e-6:(h?a.x+a.w:a.y+a.h)<=(h?b.x:b.y)+1e-6};row={id,source,direction,nested,backend,arm,delivery:'returned',proof:product.receipt.layoutCertification?.status,flow:precedes(a,c)&&precedes(c,b),quality}}
 catch(e:any){row={id,source,direction,nested,backend,arm,delivery:'error',error:String(e),stack:e.stack}}
 rows.push(row);writeFileSync(out+'/NESTING-'+arm+'.json',JSON.stringify(rows,null,2))
 }
}
console.log(JSON.stringify(rows.map(({id,delivery,proof,flow,error,quality}:any)=>({id,delivery,proof,flow,error,geometry:quality?.routeGeometry,crossings:quality?.edgeCrossings,labelConflicts:quality?.labelConflicts}))))
