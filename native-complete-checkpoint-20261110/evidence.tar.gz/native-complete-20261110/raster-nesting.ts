import {readFileSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import {prepareResvgMarkerOrientation} from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const repo='/tmp/pr449-main-integration-20261029-762',root='/tmp/pr449-week-comparison-20261101/native-complete-20261110/nesting-products'
const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const p=repo+'/'+f.path;if(createHash('sha256').update(readFileSync(p)).digest('hex')!==f.sha256)throw Error('font mismatch');return p})
for(const dir of ['TB','BT','LR','RL'])for(const nested of ['one','nested'])for(const arm of ['before','after','elk']){const path=root+'/'+dir+'-'+nested+'-'+(arm==='elk'?'elk-after':'agentic-'+arm);let svg:string;try{svg=readFileSync(path+'.svg','utf8')}catch{continue}const result=new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(svg)),{background:'#fff',fitTo:{mode:'zoom',value:2},font:{fontFiles:fonts,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();writeFileSync(path+'.png',result.asPng())}
console.log('Actual same-input public SVG rasters; manifest-verified Inter; system fonts off')
