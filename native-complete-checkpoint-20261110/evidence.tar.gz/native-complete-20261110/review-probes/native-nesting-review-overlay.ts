Bun.plugin({name:'review-overlay', setup(build){build.onLoad({filter:/compound-boundary-routes\.ts$/},async ({path})=>{
let contents=await Bun.file(path).text();
contents=contents.replace("const fractions = [...new Set([(ordinal + 1) / (degree + 1), .5, .25, .75])]",`const box=subjects[endpoint]!, port=endpoint===edge.source?raw.points[0]!:raw.points.at(-1)!, rawFraction=port.x===box.x||port.x===box.x+box.width?(port.y-box.y)/box.height:(port.x-box.x)/box.width;
const fractions = [...new Set([...(leafPaths?[rawFraction]:[]),(ordinal + 1) / (degree + 1), .5, .25, .75])]`);
contents=contents.replace("const leafPathClear = (path: readonly Point[]): boolean => {",`const leafPathClear = (path: readonly Point[]): boolean => {
if(!ownReservedLabel){for(let cursor=1;cursor<path.length;cursor++){const a=path[cursor-1]!,b=path[cursor]!;if(solidQueries().entersSegment(a.x,a.y,b.x,b.y))return false;}return true;}`);
return {contents,loader:'ts'};
});}});
await import('/tmp/native-nesting-review.ts');
await import('/tmp/native-nesting-review96.ts');
