Bun.plugin({name:'sibling-bucket-review',setup(build){build.onLoad({filter:/native-nesting\.ts$/},async({path})=>{let contents=await Bun.file(path).text();contents=contents.replace('if (internal) { if (actual >= 0) key[v] = entry[actual]! + .5 }','if (internal) { key[v] = slot }');return{contents,loader:'ts'};});}});
await import('/tmp/native-sibling-nested-review.ts');
