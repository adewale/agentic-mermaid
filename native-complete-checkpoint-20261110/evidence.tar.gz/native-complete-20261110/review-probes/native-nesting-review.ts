import {layoutLayeredGraph} from '/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts';
import {layoutCompoundGraph} from '/tmp/pr449-main-integration-20261029-762/src/layout/agentic-compound-core.ts';
import {layoutMeasuredForest} from '/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts';
import {crossingPoint,countPolylineCrossings} from '/tmp/pr449-main-integration-20261029-762/src/shared/edge-crossings.ts';
const fail=(s:string):never=>{throw new Error(s)},budget=()=>({pairs:1000000,arcs:65536,swaps:1000000});
const groups=Array.from({length:4},(_,i)=>({id:`group${i}`,minWidth:120,headerHeight:28,padding:{top:44,right:20,bottom:20,left:20}}));
const nodes=Array.from({length:80},(_,i)=>({id:`node${i}`,parent:Math.floor(i/20),width:80,height:36}));
const edges=nodes.flatMap((_,i)=>i%20?[{source:i,target:i-1,minSpan:1}]:[]);for(let g=1;g<4;g++)edges.push({source:g*20-1,target:g*20,minSpan:1});
const input={direction:'LR' as const,padding:40,nodeSpacing:40,layerSpacing:80,nodes,groups,edges};
for(const mode of ['raw','global','recursive']) { const work=budget();const x=mode==='recursive'?layoutCompoundGraph(input,flat=>layoutLayeredGraph(flat,layoutMeasuredForest,fail,work),fail,32768,work):layoutLayeredGraph({...input,...(mode==='raw'?{placementOnly:true}:{})},layoutMeasuredForest,fail,work);console.log(mode,{work,w:x.width,h:x.height,crossings:countPolylineCrossings(x.edges),groups:x.groups});for(let a=0;a<x.edges.length;a++)for(let b=a+1;b<x.edges.length;b++){if(countPolylineCrossings([x.edges[a]!,x.edges[b]!]))console.log('pair',a,b,edges[a],edges[b],x.edges[a],x.edges[b]);}console.log('focus',JSON.stringify({edge77:x.edges[77],edge38:x.edges[38],nodes:[39,40,41].map(i=>({i,...nodes[i],...x.nodes[i]}))}));}
