import { ownedPixelTextShape, transferRetainedPixelText } from '../shared/prepared-text.ts'

const operandObject = Object, operandWeakSet = WeakSet, operandNumber = Number, operandWeakMap = WeakMap, operandSetConstructor = Set, operandArrayConstructor = Array
const operandSafeInteger = Number.isSafeInteger
const operandGet = WeakMap.prototype.get, operandSet = WeakMap.prototype.set
const operandDescriptor = Object.getOwnPropertyDescriptor, operandOwn = Object.hasOwn, operandFreeze = Object.freeze
const operandDefine = Object.defineProperty, operandPrototype = Object.getPrototypeOf, operandNames = Object.getOwnPropertyNames
const operandPreventExtensions = Object.preventExtensions, operandArray = Array.isArray
const operandWeakHas = WeakSet.prototype.has, operandWeakAdd = WeakSet.prototype.add, operandWeakDelete = WeakSet.prototype.delete
const operandMapHas = WeakMap.prototype.has, operandMapDelete = WeakMap.prototype.delete
const operandSetHas = Set.prototype.has, operandSetAdd = Set.prototype.add, operandSetDelete = Set.prototype.delete
const failed = Symbol('unsupported-owned-text')
type Pay = (operations: number) => boolean

/** Constructor-qualified numeric operands supply one fresh ordinary receiver
 * graph. TextMark construction, source fallbacks and actual writing stay with
 * their existing owners. No retained clone or cross-render cache is created. */
export function captureOwnedPixelTextPart(value: object, depth: number, pay: Pay): object | undefined {
  const shape = ownedPixelTextShape(value)
  if (shape <= 1 || !ordinaryConstruction()) return undefined
  return materialize(value, depth, pay, shape) as object
}

/** No public helper callback can observe a partially materialized receiver.
 * Observable overrides retain the original descriptor-copy implementation. */
function ordinaryConstruction(): boolean {
  const data = (owner: object, key: PropertyKey, expected: unknown): boolean => {
    const descriptor = operandDescriptor(owner, key)
    return !!descriptor && operandOwn(descriptor, 'value') && descriptor.value === expected
  }
  if (!data(globalThis, 'Object', operandObject) || !data(globalThis, 'Array', operandArrayConstructor) || !data(globalThis, 'WeakSet', operandWeakSet) || !data(globalThis, 'Number', operandNumber) || !data(globalThis, 'WeakMap', operandWeakMap) || !data(globalThis, 'Set', operandSetConstructor)
    || !data(operandNumber, 'isSafeInteger', operandSafeInteger)
    || !data(operandObject, 'getOwnPropertyDescriptor', operandDescriptor) || !data(operandObject, 'hasOwn', operandOwn)
    || !data(operandObject, 'freeze', operandFreeze) || !data(operandObject, 'defineProperty', operandDefine)
    || !data(operandObject, 'getPrototypeOf', operandPrototype) || !data(operandObject, 'getOwnPropertyNames', operandNames)
    || !data(operandObject, 'preventExtensions', operandPreventExtensions) || !data(operandArrayConstructor, 'isArray', operandArray)
    || !data(operandWeakSet.prototype, 'has', operandWeakHas) || !data(operandWeakSet.prototype, 'add', operandWeakAdd) || !data(operandWeakSet.prototype, 'delete', operandWeakDelete)
    || !data(operandWeakMap.prototype, 'get', operandGet) || !data(operandWeakMap.prototype, 'set', operandSet) || !data(operandWeakMap.prototype, 'has', operandMapHas) || !data(operandWeakMap.prototype, 'delete', operandMapDelete)
    || !data(operandSetConstructor.prototype, 'has', operandSetHas) || !data(operandSetConstructor.prototype, 'add', operandSetAdd) || !data(operandSetConstructor.prototype, 'delete', operandSetDelete)
    || operandDescriptor(operandObject.prototype, 'get') || operandDescriptor(operandObject.prototype, 'set')) return false
  return true
}

function materialize(value: unknown, depth: number, pay: Pay, retainedShape?: number): unknown {
  if (depth > 64) throw failed
  if (value === null || value === undefined || typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') return value
  if (typeof value !== 'object') throw failed
  const shape = retainedShape ?? ownedPixelTextShape(value), kind = shape & 255
  if (kind <= 1 || !pay(1)) throw failed
  const source = value as Record<string, any>
  let result: object
  switch (kind) {
    case 2: {
      const length = (value as unknown[]).length
      if (!pay(length + 1)) throw failed
      const array: unknown[] = []
      for (let i = 0; i < length; i++) operandDefine(array, i, { __proto__: null, value: materialize((value as unknown[])[i], depth + 1, pay), enumerable: true, writable: false, configurable: false } as PropertyDescriptor)
      operandDefine(array, 'length', { __proto__: null, value: length, writable: false } as PropertyDescriptor)
      result = operandFreeze(array)
      break
    }
    case 3:
      if (!pay(3) || depth >= 64) throw failed
      result = operandFreeze({ text: source.text, sourceStart: source.sourceStart, sourceEnd: source.sourceEnd })
      break
    case 4:
      if (!pay(8) || depth >= 64) throw failed
      result = operandFreeze({ text: source.text, bold: source.bold, italic: source.italic, underline: source.underline, strikethrough: source.strikethrough, sourceStart: source.sourceStart, sourceEnd: source.sourceEnd, clusters: materialize(source.clusters, depth + 1, pay) })
      break
    case 5:
      if (!pay(4) || depth >= 64) throw failed
      result = operandFreeze({ source: source.source, display: source.display, lines: materialize(source.lines, depth + 1, pay), lineStarts: materialize(source.lineStarts, depth + 1, pay) })
      break
    case 6:
      if (!pay(5) || depth >= 64) throw failed
      result = operandFreeze({ runs: materialize(source.runs, depth + 1, pay), text: source.text, width: source.width, baseline: source.baseline, originX: source.originX })
      break
    case 7:
      if (!pay(shape & 256 ? 15 : 14) || depth >= 64) throw failed
      result = operandFreeze({ unit: source.unit, prepared: materialize(source.prepared, depth + 1, pay), text: source.text, lines: materialize(source.lines, depth + 1, pay), lineBlocks: materialize(source.lineBlocks, depth + 1, pay), breaks: materialize(source.breaks, depth + 1, pay), width: source.width, height: source.height, lineHeight: source.lineHeight, fontSize: source.fontSize, fontWeight: source.fontWeight, letterSpacing: source.letterSpacing, monospace: source.monospace, safeFont: source.safeFont, ...(shape & 256 ? { fontFamily: source.fontFamily } : {}) })
      break
    case 8:
      if (!pay(shape & 256 ? 3 : 2) || depth >= 64) throw failed
      result = operandFreeze({ kind: source.kind, sourceOffset: source.sourceOffset, ...(shape & 256 ? { replacedText: source.replacedText } : {}) })
      break
    default: throw failed
  }
  transferRetainedPixelText(value, result)
  return result
}

