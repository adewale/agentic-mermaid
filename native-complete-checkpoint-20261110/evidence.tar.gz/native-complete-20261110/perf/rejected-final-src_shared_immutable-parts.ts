/** Qualify at existing constructor freeze sites, bottom-up. Unknown mutable
 * fields and accessors cannot become authority through a shallow freeze. */
const immutableSet = WeakSet, immutableMap = WeakMap, immutableApply = Reflect.apply
const immutableGet = WeakMap.prototype.get, immutablePut = WeakMap.prototype.set
const immutableArray = Array.isArray, immutablePrototype = Object.getPrototypeOf
const immutableHas = WeakSet.prototype.has, immutableAdd = WeakSet.prototype.add
const immutableFreeze = Object.freeze, immutableFrozen = Object.isFrozen, immutableKeys = Reflect.ownKeys
const immutableDescriptor = Object.getOwnPropertyDescriptor, immutableOwn = Object.hasOwn

/** Constructor-owned receiver schemas. Unknown remains owned, but cannot use
 * packed emission. These numeric operands replace the existing ownership bit. */
const shapeKeys = [
  [], [], [],
  ['text', 'sourceStart', 'sourceEnd'],
  ['text', 'bold', 'italic', 'underline', 'strikethrough', 'sourceStart', 'sourceEnd', 'clusters'],
  ['source', 'display', 'lines', 'lineStarts'],
  ['runs', 'text', 'width', 'baseline', 'originX'],
  ['unit', 'prepared', 'text', 'lines', 'lineBlocks', 'breaks', 'width', 'height', 'lineHeight', 'fontSize', 'fontWeight', 'letterSpacing', 'monospace', 'safeFont'],
  ['kind', 'sourceOffset'],
] as const
const shapeChildren = [0, 0, 0, 0, 1 << 7, (1 << 2) | (1 << 3), 1, (1 << 1) | (1 << 3) | (1 << 4) | (1 << 5), 0]
function packedShape(value: object, keys: readonly PropertyKey[], objectSlots: number): number {
  const prototype = immutablePrototype(value)
  if (immutableArray(value)) {
    if (prototype !== Array.prototype || keys.length !== (value as unknown[]).length + 1 || keys[keys.length - 1] !== 'length') return 1
    for (let i = 0; i < keys.length - 1; i++) if (keys[i] !== `${i}`) return 1
    return 2
  }
  if (prototype !== Object.prototype && prototype !== null) return 1
  for (let shape = 3; shape < shapeKeys.length; shape++) {
    const expected = shapeKeys[shape]!
    const optional = shape === 7 ? 'fontFamily' : shape === 8 ? 'replacedText' : undefined
    const extended = optional !== undefined && keys.length === expected.length + 1 && keys[keys.length - 1] === optional
    if (keys.length !== expected.length && !extended || objectSlots & ~shapeChildren[shape]!) continue
    let matches = true
    for (let i = 0; i < expected.length; i++) if (keys[i] !== expected[i]) { matches = false; break }
    if (matches) return shape | (extended ? 256 : 0)
  }
  return 1
}

export function createImmutableParts(known: (value: object) => boolean = () => false, knownOwned: (value: object) => boolean = () => false, knownShape: (value: object) => number = () => 0) {
  const parts = new immutableSet<object>(), ownedParts = new immutableMap<object, number>()
  const has = (value: object): boolean => immutableApply(immutableHas, parts, [value]) || known(value)
  const shapeOf = (value: object): number => immutableApply(immutableGet, ownedParts, [value]) ?? knownShape(value)
  const hasOwned = (value: object): boolean => shapeOf(value) !== 0 || knownOwned(value)
  const qualify = <T extends object>(value: T, allocationOwned: boolean): Readonly<T> => {
    Object.freeze(value)
    // A caller can interpose the freeze operation. Reuse needs the actual
    // sealed data, rather than the operation's name or its returned value.
    if (!immutableFrozen(value)) return value
    let owned = allocationOwned, packed = allocationOwned, objectSlots = 0
    const keys = immutableKeys(value)
    const array = immutableArray(value)
    for (let index = 0; index < keys.length; index++) {
      const key = keys[index]!
      const descriptor = immutableDescriptor(value, key)
      if (!descriptor || !immutableOwn(descriptor, 'value')) return value
      const child = descriptor.value
      const scalar = child === null || typeof child !== 'object' && typeof child !== 'function'
      const childShape = !scalar && owned ? shapeOf(child) : 0
      if (owned && !scalar && childShape === 0 && !knownOwned(child)) owned = false
      if (!scalar && !has(child)) return value
      if (packed) {
        if (!owned || typeof key !== 'string' || !descriptor.enumerable && !(array && key === 'length')) packed = false
        else if (scalar) { if (typeof child === 'symbol' || typeof child === 'bigint') packed = false }
        else {
          if (childShape <= 1 || !array && index >= 31) packed = false
          if (!array) objectSlots |= 1 << index
        }
      }
    }
    immutableApply(immutableAdd, parts, [value])
    if (owned) immutableApply(immutablePut, ownedParts, [value, packed ? packedShape(value, keys, objectSlots) : 1])
    return value
  }
  const freeze = <T extends object>(value: T): Readonly<T> => qualify(value, false)
  // Only call at a known local allocation. Caller-dispatched map results and
  // other supplied objects may use freeze, but cannot mint this provenance.
  const freezeOwned = <T extends object>(value: T): Readonly<T> => qualify(value, true)
  // Exact scalar spans are private literal allocations, frozen before their
  // constructor-owned shape is recorded. Hidden/interposed fields stay generic.
  const sourceSpan = (text: string, sourceStart: number, sourceEnd: number) => {
    if (typeof text !== 'string' || typeof sourceStart !== 'number' || typeof sourceEnd !== 'number') throw new TypeError('Source spans require scalar text and offsets')
    const span = immutableFreeze({ text, sourceStart, sourceEnd })
    if (immutableFrozen(span)) {
      immutableApply(immutableAdd, parts, [span])
      const keys = immutableKeys(span)
      let packed = keys.length === 3
      for (let i = 0; i < keys.length && packed; i++) {
        const descriptor = immutableDescriptor(span, keys[i]!)
        if (!descriptor || !immutableOwn(descriptor, 'value') || !descriptor.enumerable
          || descriptor.value !== (i === 0 ? text : i === 1 ? sourceStart : sourceEnd)) packed = false
      }
      immutableApply(immutablePut, ownedParts, [span, packed ? packedShape(span, keys, 0) : 1])
    }
    return span
  }
  return { has, freeze, hasOwned, shapeOf, freezeOwned, sourceSpan }
}
