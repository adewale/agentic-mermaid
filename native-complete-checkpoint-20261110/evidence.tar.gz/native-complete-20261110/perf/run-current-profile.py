import pathlib,subprocess,json,os
r=pathlib.Path('/tmp/pr449-main-integration-20261029-762');o=pathlib.Path('/tmp/pr449-week-comparison-20261101/native-complete-20261110/perf');old=o.parent.parent/'native-only-20261109'
changed=subprocess.check_output(['git','diff','--name-only'],cwd=r).decode().splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r).decode().splitlines()
overrides={}
for f in changed:
 if f.endswith('.ts') and f.startswith('src/') and '/__tests__/' not in f:
  p=o/('profilejoint-'+f.replace('/','_'));p.write_text((r/f).read_text());overrides[str(r/f)]=str(p)
s=(r/'src/scene/svg-writer.ts').read_text();a=s.index('  const literal = (value: string, attribute: boolean): boolean => {');b=s.index('\n  const name =',a)
s=s[:a]+'''  // UNSAFE DIAGNOSTIC LOWER BOUND ONLY: no literal validation or fees.
  const literal = (value: string, attribute: boolean): boolean => true
'''+s[b:]
p=o/'UNSAFE-literal-noop-svg-writer.ts';p.write_text(s)
for case in ['chain100','fanin100']:
 j=json.loads((old/(case+'-profile-job.json')).read_text());j['phases']=['repeat1','repeat2','edit','edit2'];j['moduleOverrides']=overrides
 (o/(case+'-current-profile-job.json')).write_text(json.dumps(j))
j=json.loads((old/'chain100-cost-job.json').read_text());j['phases']=['repeat1','repeat2','edit','edit2'];j['moduleOverrides']={**overrides,str(r/'src/scene/svg-writer.ts'):str(p)}
(o/'chain100-UNSAFE-literal-noop-job.json').write_text(json.dumps(j))
env=dict(os.environ,AGENTIC_MERMAID_ELK_CACHE='0')
for name in ['chain100-current-profile','fanin100-current-profile','chain100-UNSAFE-literal-noop']:
 with (o/(name+'.log')).open('w') as log:
  subprocess.run(['node','--expose-gc',str(old/'worker.mjs'),str(o/name),str(o/(name+'-job.json'))],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
