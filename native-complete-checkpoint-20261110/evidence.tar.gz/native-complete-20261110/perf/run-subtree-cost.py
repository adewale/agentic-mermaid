import pathlib,subprocess,json,os
r=pathlib.Path('/tmp/pr449-main-integration-20261029-762');o=pathlib.Path('/tmp/pr449-week-comparison-20261101/native-complete-20261110/perf');old=o.parent.parent/'native-only-20261109'
files=['src/scene/native-paint-emission.ts','src/shared/immutable-parts.ts','src/shared/display-text.ts','src/shared/prepared-text.ts']
changed=subprocess.check_output(['git','diff','--name-only'],cwd=r).decode().splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r).decode().splitlines()
shared={}
for f in changed:
 if f.endswith('.ts') and f.startswith('src/') and f not in files and f!='src/scene/native-text-operands.ts' and '/__tests__/' not in f:
  p=o/('joint-'+f.replace('/','_'));p.write_text((r/f).read_text());shared[str(r/f)]=str(p)
variants={'subtree-before':dict(shared),'subtree-after':dict(shared)}
for f in files:
 for variant,source in [('subtree-before',subprocess.check_output(['git','show','HEAD:'+f],cwd=r).decode()),('subtree-after',(r/f).read_text())]:
  p=o/(variant+'-'+f.replace('/','_'));p.write_text(source);variants[variant][str(r/f)]=str(p)
p=o/'subtree-after-native-text-operands.ts';p.write_text((r/'src/scene/native-text-operands.ts').read_text());variants['subtree-after'][str(r/'src/scene/native-text-operands.ts')]=str(p)
for case in ['chain100','forest100','fanin100']:
 for variant,overrides in variants.items():
  job=json.loads((old/(case+'-cost-job.json')).read_text());job['moduleOverrides']=overrides;job['phases']=['repeat1','repeat2','edit','edit2'];(o/(case+'-'+variant+'-job.json')).write_text(json.dumps(job))
env=dict(os.environ,AGENTIC_MERMAID_ELK_CACHE='0')
for case in ['chain100','forest100','fanin100']:
 for variant,rep in [('before',0),('after',1),('after',2),('before',3)]:
  name=case+'-subtree-'+variant+'-r'+str(rep)
  with (o/(name+'.log')).open('w') as log:
   subprocess.run(['node','--expose-gc',str(old/'worker.mjs'),str(o/name),str(o/(case+'-subtree-'+variant+'-job.json'))],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
