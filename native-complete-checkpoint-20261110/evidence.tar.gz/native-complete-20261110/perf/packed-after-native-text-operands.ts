import type { DrawingFactory } from './drawing.ts'
import type { TextMark } from './ir.ts'
import { ownedPixelTextShape, transferRetainedPixelText, type PixelTextBlock } from '../shared/prepared-text.ts'
import { admitWritableSceneNode } from './serialization.ts'
import { text as textMark } from './marks.ts'

const operandObject = Object, operandWeakSet = WeakSet
const operandMap = WeakMap, operandGet = WeakMap.prototype.get, operandSet = WeakMap.prototype.set, operandApply = Reflect.apply
const operandDescriptor = Object.getOwnPropertyDescriptor, operandOwn = Object.hasOwn, operandFreeze = Object.freeze
const operandDefine = Object.defineProperty, operandPrototype = Object.getPrototypeOf, operandNames = Object.getOwnPropertyNames
const operandPreventExtensions = Object.preventExtensions, operandArray = Array.isArray
const operandWeakHas = WeakSet.prototype.has, operandWeakAdd = WeakSet.prototype.add
const operandArrayMap = Array.prototype.map, operandArrayConstructor = Array
const operandSpecies = operandDescriptor(Array, Symbol.species)?.get
const factories = new operandMap<object, (operands: NativeTextOperands) => unknown>()
const failed = Symbol('unsupported-owned-text')
type Pay = (operations: number) => boolean

/** The scalar lowering has no borrowed attribute or paint records. Its private
 * token is consumed by the same capture which validates and writes the leaf. */
class NativeTextOperands {
  #used = false
  readonly #id: string
  readonly #text: string
  readonly #block: PixelTextBlock
  readonly #x: number
  readonly #y: number
  readonly #fontSize: number
  readonly #fill: string
  constructor(id: string, text: string, block: PixelTextBlock, x: number, y: number, fontSize: number, fill: string) {
    this.#id = id; this.#text = text; this.#block = block; this.#x = x; this.#y = y; this.#fontSize = fontSize; this.#fill = fill
  }
  static consume(value: unknown, pay: Pay): { node: TextMark; captured: boolean } | undefined {
    if (!value || typeof value !== 'object' || !(#used in value)) return undefined
    if (value.#used) throw new TypeError('Native text operands already consumed')
    value.#used = true
    // The exact shape is authenticated at construction, not by a caller flag.
    // Every source occurrence still gets its own ordinary immutable receivers.
    try {
    const block = materialize(value.#block, 1, pay) as PixelTextBlock
    if (!pay(32)) throw failed
    const lines = block.lines.length
    const firstDy = (lines === 1 ? 0 : -((lines - 1) / 2) * block.lineHeight) + value.#fontSize * 0.35
    const offsetY = firstDy + (lines - 1) * block.lineHeight / 2 - value.#fontSize * 0.35
    const node: TextMark = operandFreeze({
      kind: 'text', id: value.#id, role: 'label', text: value.#text, x: value.#x, y: value.#y,
      fontSize: value.#fontSize, anchor: 'middle', paint: operandFreeze({ fill: value.#fill }),
      identity: operandFreeze({ id: value.#id, role: 'label' }), accessibility: undefined,
      block, measurement: 'prepared', prepared: true, preparedLines: undefined,
      fontWeight: block.fontWeight, letterSpacing: block.letterSpacing, display: block.prepared.display,
      textLayout: operandFreeze({ width: block.width, height: block.height, lineHeight: block.lineHeight, offsetY }),
    })
    return { node: admitWritableSceneNode(node), captured: true }
    } catch {
      return { node: textMark({ id: value.#id, role: 'label', text: value.#text, block: value.#block, x: value.#x, y: value.#y, fontSize: value.#fontSize, anchor: 'middle', paint: { fill: value.#fill } }), captured: false }
    }
  }
}

/** Private construction stays callback-free. Observable namespace overrides and
 * descriptor hooks retain the existing mutable mark/snapshot route. */
function ordinaryConstruction(): boolean {
  const data = (owner: object, key: PropertyKey, expected: unknown): boolean => {
    const descriptor = operandDescriptor(owner, key)
    return !!descriptor && operandOwn(descriptor, 'value') && descriptor.value === expected
  }
  if (!data(globalThis, 'Object', operandObject) || !data(globalThis, 'Array', operandArrayConstructor) || !data(globalThis, 'WeakSet', operandWeakSet)
    || !data(operandObject, 'getOwnPropertyDescriptor', operandDescriptor) || !data(operandObject, 'hasOwn', operandOwn)
    || !data(operandObject, 'freeze', operandFreeze) || !data(operandObject, 'defineProperty', operandDefine)
    || !data(operandObject, 'getPrototypeOf', operandPrototype) || !data(operandObject, 'getOwnPropertyNames', operandNames)
    || !data(operandObject, 'preventExtensions', operandPreventExtensions) || !data(operandArrayConstructor, 'isArray', operandArray)
    || !data(operandWeakSet.prototype, 'has', operandWeakHas) || !data(operandWeakSet.prototype, 'add', operandWeakAdd)
    || !data(operandArrayConstructor.prototype, 'map', operandArrayMap) || !data(operandArrayConstructor.prototype, 'constructor', operandArrayConstructor)
    || operandDescriptor(operandObject.prototype, 'get') || operandDescriptor(operandObject.prototype, 'set')) return false
  const species = operandDescriptor(operandArrayConstructor, Symbol.species)
  return !!species && !operandOwn(species, 'value') && species.get === operandSpecies
}

function materialize(value: unknown, depth: number, pay: Pay): unknown {
  if (depth > 64) throw failed
  if (value === null || value === undefined || typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') return value
  if (typeof value !== 'object') throw failed
  const shape = ownedPixelTextShape(value), kind = shape & 255
  if (kind <= 1 || !pay(1)) throw failed
  const source = value as Record<string, any>
  const child = (part: unknown): any => materialize(part, depth + 1, pay)
  let result: object
  switch (kind) {
    case 2: {
      const length = (value as unknown[]).length
      if (!pay(length + 1)) throw failed
      const array: unknown[] = []
      for (let i = 0; i < length; i++) operandDefine(array, i, { __proto__: null, value: child((value as unknown[])[i]), enumerable: true, writable: false, configurable: false } as PropertyDescriptor)
      operandDefine(array, 'length', { __proto__: null, value: length, writable: false } as PropertyDescriptor)
      result = operandFreeze(array)
      break
    }
    case 3:
      if (!pay(3) || depth >= 64) throw failed
      result = operandFreeze({ text: source.text, sourceStart: source.sourceStart, sourceEnd: source.sourceEnd })
      break
    case 4:
      if (!pay(8) || depth >= 64) throw failed
      result = operandFreeze({ text: source.text, bold: source.bold, italic: source.italic, underline: source.underline, strikethrough: source.strikethrough, sourceStart: source.sourceStart, sourceEnd: source.sourceEnd, clusters: child(source.clusters) })
      break
    case 5:
      if (!pay(4) || depth >= 64) throw failed
      result = operandFreeze({ source: source.source, display: source.display, lines: child(source.lines), lineStarts: child(source.lineStarts) })
      break
    case 6:
      if (!pay(5) || depth >= 64) throw failed
      result = operandFreeze({ runs: child(source.runs), text: source.text, width: source.width, baseline: source.baseline, originX: source.originX })
      break
    case 7:
      if (!pay(shape & 256 ? 15 : 14) || depth >= 64) throw failed
      result = operandFreeze({ unit: source.unit, prepared: child(source.prepared), text: source.text, lines: child(source.lines), lineBlocks: child(source.lineBlocks), breaks: child(source.breaks), width: source.width, height: source.height, lineHeight: source.lineHeight, fontSize: source.fontSize, fontWeight: source.fontWeight, letterSpacing: source.letterSpacing, monospace: source.monospace, safeFont: source.safeFont, ...(shape & 256 ? { fontFamily: source.fontFamily } : {}) })
      break
    case 8:
      if (!pay(shape & 256 ? 3 : 2) || depth >= 64) throw failed
      result = operandFreeze({ kind: source.kind, sourceOffset: source.sourceOffset, ...(shape & 256 ? { replacedText: source.replacedText } : {}) })
      break
    default: throw failed
  }
  transferRetainedPixelText(value, result)
  return result
}

export function registerNativeTextOperands<T>(factory: DrawingFactory<T>, emit: (operands: NativeTextOperands) => T): void {
  operandApply(operandSet, factories, [factory, emit])
}

export function consumeNativeTextOperands(value: unknown, pay: Pay): { node: TextMark; captured: boolean } | undefined { return NativeTextOperands.consume(value, pay) }

/** Built-in graph labels enter through scalar operands; custom factories and
 * unsupported prepared data retain the ordinary public DrawingFactory call. */
export function drawNativeNodeText<T>(factory: DrawingFactory<T>, id: string, text: string, block: PixelTextBlock, x: number, y: number, fontSize: number, fill: string): T {
  const emit = operandApply(operandGet, factories, [factory]) as ((operands: NativeTextOperands) => T) | undefined
  if (emit && ordinaryConstruction() && (ownedPixelTextShape(block) & 255) === 7
    && block.fontSize === fontSize && block.text === text && operandPrototype(block.lineBlocks) === Array.prototype
    && !operandDescriptor(block.lineBlocks, 'map') && !operandDescriptor(block.lineBlocks, 'constructor')) {
    return emit(new NativeTextOperands(id, text, block, x, y, fontSize, fill))
  }
  return factory.text({ id, role: 'label', text, block, x, y, fontSize, anchor: 'middle', paint: { fill } })
}
