# Native compound and production-contract milestone

Source `ce65ff5b65f8532509f3f7f4038d9fc95e63e015`; before `10253d29dba24554008fc61c178abcf7cc0a47cf`; integrated main remains `e7cb05baa7f68154942a9ce9c6e9aaaee163dc94`. Native is the sole replacement candidate. Trinity feature development remains frozen; its public compatibility path remains. No new backend, default/version/cap change, PR, issue or automation.

## What changed

Native production now enters the existing neutral role/correspondence/size-policy validator without losing its private search and work-ledger identity. Canonical wide rectangular/rounded endpoint faces use the existing early physical capacity planner. Fixed inadequate bodies decline before routing; permitted growth reaches the emitted body. Existing weighted thin-port and confluent-fan policies remain.

Common-direction acyclic leaf compounds now rank leaves globally with a nesting graph, top/bottom constraints and linked side-border variables. Authored-only adjacency owns port capacity. Long-edge subdivisions traverse source ancestors, their lowest common ancestor, then target ancestors; aligned channel segments preserve their order across ranks. Connected direct siblings remain contiguous beside unrelated child containers. Frames derive from the border coordinates. The boundary consumer checks actual full leaf paths, reuses its owned obstacle index, retains clear allocated paths and preserves labelled source prefixes when repairing a lifted target.

Recursive compatibility remains for authored leaf cycles/loops, container endpoints, differing local directions, explicit rank/model ordering, empty groups and oversized explicit rank spans. These are retained supported contracts, not new claims that global nesting handles them.

## Demonstrated result and costs

The authored a→c→b chain, with a/b in one group and c outside that group, previously inherited a false lifted cycle. This is a flow-quality defect; the previous arrows still represented both relationships. Eight public inputs cover four directions and one/two nesting levels, with labels in the nested variant. Both engines receive identical sources and options. All final SVGs, complete receipts, public layouts and font-bound rasters are retained.

| Observation | Before Native | Current Native | Current ELK |
| --- | ---: | ---: | ---: |
| Delivered / selected eight | 7/8 | 8/8 | 8/8 |
| Passed actual SVG receipt / delivered | 7/7 | 8/8 | 8/8 |
| Monotone authored leaf flow / eight | 0/8 | 8/8 | 0/8 |
| Crossings / returned example | 0 | 0 | 0 |
| Label conflicts / returned example | 0 | 0 | 0 |
| TB one-level area | 61828 | 97162 | 101421.3915 |
| TB one-level wire | 130 | 355 | 571.45 |
| TB one-level bends | 4 | 8 | 4 |
| LR one-level area | 61900.8 | 100347 | 84370.05 |
| LR one-level wire | 124.225 | 284.8 | 507.3 |

The old nested BT refusal was `cross-hierarchy route has no bounded clear corridor`. It now delivers with a passed receipt. Monotone flow is the requested layout property, not a claim that ELK loses authored meaning. Area and some wire/bend costs grow versus the old compressed Native diagram; horizontal Native area also exceeds ELK. No metric difference is erased or treated as a universal correctness rule. This does not reproduce the missing screenshot or identify the earlier five compound declines.

The changed Architecture consumers also improve on their enrolled inputs: family area76704→74100 and wire56→36; branching area151076→114784, wire358→276 and bends4→2. Reset/edit variants retain the same direction of change. All four actual SVG receipts remain passed. No additional delivery/proof gain is attributed to those four rows.

## Qualification

- 984 owning tests pass across measured layout, compounds, public graph selection, route/marker contracts, feedback and Native cache isolation. Core/repository typechecks and Biome lint pass. The independent review found and removed fake-port counting, uncharged variable storage/scans, lost labelled prefixes and sibling-component/frame collisions.
- New ownership coverage includes nested labelled false cycles, short/long unrelated child frames in all four directions, fixed16 singleton capacity, and actual painted host padding in both authored directions. Original quotas remain.
- Frozen30 × three backends retains84 delivered products (27 proof-passed plus one raster-unverified per backend) and six shared invalid-option errors, with no delivery/proof transition. Four Native Architecture SVGs change as above; the other80 SVGs remain exact;79 complete receipts remain exact. The unchanged Class namespace SVG has an adverse proof-work change56378→57380 operations, with status passed unchanged. Unchanged rows are validation only.
- Existing Trident actual-browser qualification passes all13 selected inputs for each of the three adapters. Requests remain ELK43, Native49, Trinity50. This is the fixed portfolio, not a workload-wide fidelity claim. Replacement24 remains sealed; original2dad baseline and pinned Mermaid/Pele runtime comparison remain unavailable.
- Actual fetched product bytes, adapter binding separate: ELK gzip9=862860 / Brotli11=692551; Native495583 /424995; Trinity484734 /415265. Versus the previous source milestone, gzip grows8/3479/103 bytes respectively; Brotli grows123/3263/220. These are adverse distribution costs, not startup or feature-equivalent replacement ratios.

## Performance result

No performance experiment from this run ships. The owned text lookup, whole-mark bypass, typed pixel-subtree and scalar-copy trials were rejected and reverted; complete patches, reviews, sources, timings, RSS/heap, profiles and50 paired whole-product comparisons remain in `perf/`. The last trial has mixed warm/cache0 results: chain171.9–196.2ms, forest176.9–209.8ms, fan217.1–269.6ms. All60 measured calls return unverified at the original400000 capture limit, before geometric occlusion. These are not correctness passes or shipped speedups.

The current profile's chain placement is0.61ms while complete layout is35.65ms, drawing136.23ms and security10.35ms (instrumented repeat2; not additive sampled estimates). Fan placement0.98ms is likewise small. Shared capture alone consumes271288 operations; resource/context finish reaches376552 before XML projection completes. Even unsafe removal of every text-literal validation/fee cannot close the proof deficit. Independently, removing all legacy Native completion in a source-only counterfactual still produces163.53–199.75ms warm results and unverified400000 receipts. Neither shortcut ships.

`perf/REPORT.md` reports five source hotspots with self/inclusive distinction, exact sources/jobs, active-gap sensitivity and the existing cache inventory. Inclusive weights overlap. No expected safe speedup, full-response improvement or memory reduction is invented. The100-node<100ms full-product target and shared capture proof deficit remain unresolved. Marker indexing from the preceding source milestone remains shipped, with no whole-product speedup established.

The next useful performance change must remove actual duplicate producer/consumer work across capture, resource/context and XML projection together while retaining external mutable/getter/prototype/CSS/definition/UTF16 isolation. Repeating the stopped text-only, literal-only or legacy-completion shortcuts would not be progress. CI is push-triggered and remains a separate requirement; local checks do not make this PR ready.
