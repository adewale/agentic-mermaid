# Preserve authored curves outside Native orthogonal capacity admission

Current parent02eb9e8d17a1761bd6daa0726b6ab3fa4be14cb9 reproduces four existing failures: Native public curved projection loses the natural joins; stock curves in native/scene/strict execution expand the viewBox from248 to289. The receipt still reports passed, so it cannot replace the actual path/ink owners.

A producer-only module override from10253d29dba24554008fc61c178abcf7cc0a47cf restores the original248 viewBox and three natural cubics. The new early physical-capacity metadata had been applied to authored curve legs even though that request only describes translated orthogonal routes.

The only production diff gates `nativeCapacity` on every edge having `curve === undefined`. This preserves the existing semantic producer and legacy curve completion, including explicit linear curves and mixed shared-node graphs. The graph still renders; the capacity optimization declines this domain. Original caps and test expectations are unchanged.

Verification:

- Four existing failures become green; full curved-connector-projection + measured-backend owners92P/0F.
- Stock curves across Native/ELK and native/scene/strict execution6P/0F, including actual final SVG ink checks.
- Existing four-direction Native wide-face capacity owners remain passing.
- Repaired whole SVG and entire serialized receipt exactly equal the102 producer-only override (`product-comparison.json`).
- Biome owning file passes; canonical typecheck log retained in `typecheck.log`.

`curved-before.log` and `paint-before.log` preserve red behavior. `curved-measured-after.log`, `paint-after.log`, source override, exact jobs and complete returned products preserve green evidence. No performance claim follows from these non-isolated reproduction calls; all performance experiments remain reverted. No commit or push by this agent.
