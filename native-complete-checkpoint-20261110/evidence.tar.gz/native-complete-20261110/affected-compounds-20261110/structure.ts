import { readFileSync, writeFileSync } from 'node:fs'
import { layoutCompoundGraph } from '/tmp/pr449-main-integration-20261029-762/src/layout/agentic-compound-core.ts'
import { parseRegisteredMermaid } from '/tmp/pr449-main-integration-20261029-762/src/agent/core.ts'
const out = import.meta.dir
const before = JSON.parse(readFileSync(out + '/baseline102-all.json', 'utf8')).samples
const after = JSON.parse(readFileSync(out + '/current-all.json', 'utf8')).samples
const summaries = new Map(JSON.parse(readFileSync(out + '/SUMMARY.json', 'utf8')).map((x: any) => [x.id, x]))
const normalize = (direction: string) => direction === 'TD' ? 'TB' : direction
function acyclic(count: number, edges: any[]) {
  const degree = Array(count).fill(0), peers = Array.from({ length: count }, () => [] as number[]), queue: number[] = []
  for (const e of edges) { degree[e.target]++; peers[e.source].push(e.target) }
  for (let i = 0; i < count; i++) if (!degree[i]) queue.push(i)
  for (let i = 0; i < queue.length; i++) for (const target of peers[queue[i]]) if (--degree[target] === 0) queue.push(target)
  return queue.length === count
}
function directions(sample: any) {
  const parsed = parseRegisteredMermaid(sample.source), groups = new Map<string, string>()
  const body: any = parsed.ok ? parsed.value.body : undefined
  let root = normalize(body?.kind === 'flowchart' ? body.graph.direction : body?.kind === 'state' ? body.direction ?? 'TB' : sample.source.match(/^\s*(?:flowchart|graph|direction)\s+(TB|TD|BT|LR|RL)\b/m)?.[1] ?? 'TB')
  if (body?.kind === 'flowchart') {
    const visit = (rows: any[], direction: string) => { for (const g of rows) { const actual = normalize(g.direction ?? direction); groups.set(g.id, actual); visit(g.children, actual) } }
    visit(body.graph.subgraphs, root)
  }
  if (body?.kind === 'state') {
    const visit = (rows: any[], direction: string) => { for (const s of rows) { const actual = normalize(s.direction ?? direction); groups.set(s.id, actual); visit(s.states ?? [], actual); for (const region of s.regions ?? []) visit(region.states, normalize(region.direction ?? actual)) } }
    visit(body.states, root)
  }
  return { root, groups, opaque: body?.kind === 'opaque' }
}
function classify(sample: any) {
  const layout = sample.layout, n = layout.nodes.length, names = [...layout.nodes.map((x: any) => x.id), ...layout.groups.map((x: any) => x.id)], positions = new Map(names.map((id: string, i: number) => [id, i]))
  const groupIndex = new Map(layout.groups.map((g: any, i: number) => [g.id, i])), owner = new Map<string, string>()
  for (const group of layout.groups) for (const id of group.members) owner.set(id, group.id)
  const dir = directions(sample)
  const nodes = layout.nodes.map((node: any) => ({ id: node.id, width: Math.max(1, node.w), height: Math.max(1, node.h), ...(owner.has(node.id) ? { parent: groupIndex.get(owner.get(node.id)) } : {}) }))
  const groups = layout.groups.map((g: any) => ({ id: g.id, ...(g.parentId === undefined ? {} : { parent: groupIndex.get(g.parentId) }), minWidth: 0, padding: { top: 0, bottom: 0, left: 0, right: 0 }, direction: dir.groups.get(g.id) ?? dir.root }))
  const edges = layout.edges.map((edge: any, index: number) => {
    const source = positions.get(edge.from), target = positions.get(edge.to)
    if (source === undefined || target === undefined) throw Error(sample.id + ': retained endpoint missing')
    return { source, target, minSpan: 1, originalIndex: index }
  })
  const input: any = { nodes, groups, edges, direction: dir.root, padding: 0, nodeSpacing: 0, layerSpacing: 0 }
  let model: any
  // Reuse the actual compound owner's validated parent/LCA/lifting algorithm.
  // The global callback returns immediately: no placement or rendering occurs.
  layoutCompoundGraph(input, () => { throw Error('Diagnostic must not place scopes') }, reason => { throw Error(reason) }, 1_000_000, { pairs: 1_000_000, arcs: 65536, swaps: 1_000_000 }, (owners, children, lifted) => {
    const ancestorEdges = edges.filter((e: any, i: number) => owners[e.source] !== owners[e.target] && !lifted.has(i)).map((e: any) => e.originalIndex)
    const liftedRows = [...lifted].map(([index, e]) => ({ index, source: e.source, target: e.target, host: e.host }))
    const quotient = edges.flatMap((e: any, i: number) => ancestorEdges.includes(i) ? [] : [{ ...(lifted.get(i) ?? e), index: i }])
    const leafEdges = edges.filter((e: any) => e.source < n && e.target < n)
    const leafDag = acyclic(n, leafEdges), frameEdges = edges.filter((e: any) => e.source >= n || e.target >= n).map((e: any) => e.originalIndex)
    const localDirections = groups.filter((g: any) => g.direction !== dir.root).map((g: any) => ({ id: g.id, direction: g.direction }))
    const emptyGroups = groups.filter((_g: any, i: number) => !children[i + 1].length).map((g: any) => g.id)
    const leafPeers = Array.from({ length: n }, () => [] as number[])
    for (const e of leafEdges) leafPeers[e.source].push(e.target)
    const reaches = (start: number, end: number) => { const queue = [start], seen = new Set<number>(); for (let i = 0; i < queue.length; i++) { const node = queue[i]; if (node === end) return true; if (seen.has(node)) continue; seen.add(node); queue.push(...leafPeers[node]) } return false }
    const cycleEdges = leafEdges.filter((e: any) => reaches(e.target, e.source)).map((e: any) => e.originalIndex)
    const skipped: any[] = [], checked: any[] = [], backward: any[] = [], backwardRoute: any[] = []
    for (const e of edges) {
      const actual = layout.edges[e.originalIndex]
      const reason = e.source >= n || e.target >= n ? 'authored frame endpoint' : cycleEdges.includes(e.originalIndex) ? 'authored leaf cycle' : sample.family === 'architecture' || actual.route?.invariant === 'side-anchored' ? 'explicit port directions' : actual.visibility === 'hidden' ? 'hidden structural route' : undefined
      if (reason) { skipped.push({ id: actual.id, reason }); continue }
      let host = owners[e.source]
      const ancestors = new Set<number>([-1])
      for (let parent = host; parent >= 0; parent = owners[n + parent]) ancestors.add(parent)
      host = owners[e.target]
      while (!ancestors.has(host)) host = owners[n + host]
      const direction = host < 0 ? dir.root : groups[host].direction
      const horizontal = direction === 'LR' || direction === 'RL', sign = direction === 'RL' || direction === 'BT' ? -1 : 1
      const a = layout.nodes[e.source], b = layout.nodes[e.target]
      const centerDelta = sign * (horizontal ? b.x + b.w / 2 - a.x - a.w / 2 : b.y + b.h / 2 - a.y - a.h / 2)
      const path = actual.path, routeDelta = sign * (path.at(-1)[horizontal ? 0 : 1] - path[0][horizontal ? 0 : 1])
      const row = { id: actual.id, from: actual.from, to: actual.to, scope: host < 0 ? 'root' : groups[host].id, direction, centerDelta, routeDelta }
      checked.push(row); if (centerDelta < -1e-6) backward.push(row); if (routeDelta < -1e-6) backwardRoute.push(row)
    }
    const quotientDag = acyclic(n + groups.length, quotient), liftedOnlyDag = acyclic(n + groups.length, liftedRows)
    model = { nodeIds: nodes.map((x: any) => x.id), parents: names.map((id, i) => ({ id, parent: owners[i] < 0 ? null : groups[owners[i]].id })), edgeIds: layout.edges.map((e: any) => ({ id: e.id, from: e.from, to: e.to })),
      leafDag, authoredSubjectDag: acyclic(n + groups.length, edges), quotientDag, liftedOnlyDag, falseQuotientCycle: leafDag && !quotientDag,
      eligibleLeafOnlyFalseCycle: leafDag && !quotientDag && !frameEdges.length && !localDirections.length && !emptyGroups.length,
      frameEdges: frameEdges.map((i: number) => layout.edges[i].id), ancestorEdges: ancestorEdges.map((i: number) => layout.edges[i].id), localDirections, emptyGroups,
      lifted: liftedRows.map((e: any) => ({ edge: layout.edges[e.index].id, source: names[e.source], target: names[e.target], host: e.host < 0 ? 'root' : groups[e.host].id })),
      quotient: quotient.map((e: any) => ({ edge: layout.edges[e.index].id, source: names[e.source], target: names[e.target] })),
      backwardCount: backward.length, backwardRouteCount: backwardRoute.length, checkedLeafEdges: checked, skippedEdges: skipped, backward, backwardRoute,
      directionRoot: dir.root, opaqueDirectionInferredFromSource: dir.opaque,
    }
    return { width: 0, height: 0, nodes: [], groups: [], edges: [], topology: 'layered' }
  })
  return model
}
const rows = before.map((sample: any) => {
  const current = after.find((x: any) => x.id === sample.id), a = classify(sample), b = classify(current)
  const topologyExact = JSON.stringify([a.nodeIds, a.parents, a.edgeIds]) === JSON.stringify([b.nodeIds, b.parents, b.edgeIds])
  return { id: sample.id, family: sample.family, verdict: (summaries.get(sample.id) as any).verdict, topologyExact, before: a, after: b }
})
writeFileSync(out + '/STRUCTURE.json', JSON.stringify(rows, null, 2) + '\n')
console.log(JSON.stringify(rows.map((r: any) => ({ id: r.id, family: r.family, topologyExact: r.topologyExact, leafDag: r.before.leafDag, quotientDag: r.before.quotientDag, liftedOnlyDag: r.before.liftedOnlyDag, eligibleLeafOnlyFalseCycle: r.before.eligibleLeafOnlyFalseCycle, backwards: [r.before.backwardCount, r.after.backwardCount], backwardRoutes: [r.before.backwardRouteCount, r.after.backwardRouteCount], excluded: r.before.skippedEdges.length, frameEdges: r.before.frameEdges.length, localDirections: r.before.localDirections })), null, 2))
