import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { parseRegisteredMermaid } from '/tmp/pr449-main-integration-20261029-762/src/agent/core.ts'
const root = '/tmp/pr449-main-integration-20261029-762', evidence = '/tmp/pr449-week-comparison-20261101', out = import.meta.dir
const enrollment = JSON.parse(readFileSync(evidence + '/native-thin-weighted-20261109/COHORT-JOBS.json', 'utf8'))
const selected: any[] = [], inspected: any[] = [], jobs: any[] = []
const flowCount = (groups: any[]): number => groups.reduce((n, g) => n + 1 + flowCount(g.children ?? []), 0)
const stateCount = (states: any[]): number => states.reduce((n, s) => n + (s.states !== undefined || s.regions !== undefined ? 1 : 0) + stateCount(s.states ?? []) + (s.regions ?? []).reduce((m: number, r: any) => m + 1 + stateCount(r.states), 0), 0)
for (const item of enrollment) {
  const previous = JSON.parse(readFileSync(item.job, 'utf8')), snapshot = JSON.parse(readFileSync(previous.baseline, 'utf8')), indices: number[] = []
  for (const [index, sample] of snapshot.samples.entries()) {
    if (!['flowchart', 'state', 'class', 'architecture'].includes(sample.family)) continue
    const parsed = parseRegisteredMermaid(sample.source)
    let groups = 0
    if (parsed.ok) {
      const body: any = parsed.value.body
      groups = body.kind === 'flowchart' ? flowCount(body.graph.subgraphs) : body.kind === 'state' ? stateCount(body.states) : body.kind === 'class' ? body.namespaces?.length ?? 0 : body.kind === 'architecture' ? body.groups.length : 0
    }
    const failedCompound = (!parsed.ok || parsed.value.body.kind === 'opaque') && /subgraph|namespace|^\s*group\s+|state\s+.*\{/m.test(sample.source)
    inspected.push({ cohort: item.cohort, index, id: sample.id, family: sample.family, parserAccepted: parsed.ok, groups, failedCompound })
    if (groups > 0 || failedCompound) {
      indices.push(index)
      selected.push({ cohort: item.cohort, index, id: sample.id, family: sample.family, groups, parserAccepted: parsed.ok, source: sample.source, ...(parsed.ok ? {} : { parserError: parsed.error }) })
    }
  }
  if (indices.length) jobs.push({ cohort: item.cohort, baseline: previous.baseline, caseIndices: indices })
}
writeFileSync(out + '/ENROLLMENT.json', JSON.stringify({ scope: 'Read-only selection from the existing874 Native enrollment; current typed container declarations plus retained compound parse failures. Qualification uses the unmodified existing collector.', selected, inspected, jobs }, null, 2) + '\n')
console.log(JSON.stringify({ selected: selected.length, families: Object.fromEntries(['flowchart','state','class','architecture'].map(family => [family, selected.filter(x => x.family === family).length])), jobs, ids: selected.map(x => x.id) }, null, 2))
