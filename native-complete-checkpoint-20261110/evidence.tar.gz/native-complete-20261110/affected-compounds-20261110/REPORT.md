# Affected compound cohort — controlled Native comparison

This bounded comparison finds **nine new adverse geometry verdicts** under the existing revision comparator. It does not demonstrate a broad benefit from global nesting. Both arms retain24 passed and one unverified SVG/layout receipt; no input loses delivery or proof status.

The existing874-case enrollment and unchanged `trinity-ordinary-circle-20261109/snapshot-selected.mjs` collector were reused. Only25 affected compound sources were rendered: Flowchart9, State5, Class6, Architecture5. No unchanged flat cohort was replayed. Typed container declarations selected24; source-declared compound `corpus/flowchart/99` is represented as opaque by the public typed parser and was conservatively retained as the25th input. It renders successfully in both arms and must not be silently discarded.

The baseline uses exactly the coordinator's frozen10253 five-file overrides from `BASELINE-OVERRIDES.json`. The current arm freezes those five current files plus `native-nesting.ts` into the accompanying `current-*` snapshots, on parent02eb9e8d17a1761bd6daa0726b6ab3fa4be14cb9 with its pending followup. Remaining sources/options are common to both arms. This is a controlled producer comparison, not a complete10253 checkout or final-head qualification. Jobs preserve original cohort1 indices and id prefixes, Native backend and fallback none. No production file was edited.

The collector captures complete public layout, metrics, SVG, ASCII, layout receipt and SVG receipt. All25 return on all these surfaces in both arms; there are zero retained surface exceptions/refusals in this particular subset. `fixture/stress/flowchart-subgraphs-12x8.mmd` remains unverified with `OUTPUT_SCOPE` and `CHECK_BUDGET` in both arms. Its uncertainty is not a correctness pass. Complete products/receipts and source are retained in `baseline102-all.json.gz` and `current-all.json.gz`, beside plaintext originals. These are artifact archives, not network compression measurements.

`compareSnapshots` is unmodified, in revision mode:12 unchanged,2 changed,2 improvement,9 regression. Twelve whole SVGs and ten entire SVG receipts are byte-exact. Architecture0 and5 have identical SVGs but changed receipts. No timing or general performance claim is made.

| Input | New adverse geometry versus the frozen producer |
|---|---|
| corpus/class/17 | crossings0→2; wire462→740; area220990→258720 |
| corpus/class/18 | crossings0→2; wire470→720; area191064→223896 |
| corpus/class/19 | bends6→12; wire618→756; area220248→253368 |
| fixture/class-compound-backends.mmd | bends0→16; wire616→1873; area579204→730701 |
| corpus/architecture/1 | wire336→459; area146780→151434 |
| corpus/architecture/3 | wire1436→1614; area improves349932→325398 |
| corpus/flowchart/94 | area148954.8→154175.4; bends7→4 and wire560.025→495.3 improve |
| corpus/flowchart/99 | wire257.69→300.387; area166268.322→174681.814 |
| fixture/stress/flowchart-subgraphs-12x8.mmd | area2208333.273→2607082.916; wire25945.073→21517.524 improves; proof remains unverified |

The two improvements are Flowchart95 (shorter wire/smaller area) and architecture-basic (bends4→2, wire313→229, area201196→153988). Class15/16 change SVG bytes without a measured geometric verdict. State's five enrolled compounds are unchanged validation, not new coverage.

## Structural classification requested after these outcomes

No further rendering was needed. `structure.ts` reuses the actual `layoutCompoundGraph` owner/ancestor/lifting callback on the retained typed parents and endpoint identities, and returns immediately without placement. Parent hierarchy, node IDs and authored endpoint identities are exact between arms for all25. Typed source directions supply root/local main axes; Flowchart99's root LR direction is retained from source because its typed body is opaque.

- 24 have acyclic leaf graphs. State14 contains genuine authored leaf cycles.
- The complete per-scope quotient, including ordinary hosted edges, is cyclic only for Flowchart96 and State14.
- Flowchart96 has three authored frame-endpoint edges, so the current leaf-only global strategy already declines it. State14 is a real leaf cycle and also declines.
- Therefore **zero of these25 inputs is an eligible acyclic-leaf/cyclic-quotient case** needing the new global strategy.
- Class17/18 and class-compound—the strongest new adverse cases—have acyclic leaf graphs and acyclic quotients. There is no false-cycle repair benefit to trade against their added crossings/bends here.
- The existing lifted-only Kahn graph is acyclic for all25. It omits ordinary same-scope hosted edges. A predicate intended to detect the complete quotient must include those edges too; lifted-only is a weaker condition. Flowchart96 demonstrates the distinction, although frame endpoints already make that case ineligible.

Across144 noncyclic leaf links, backward node-center main-axis progress is0→0 and retained route-end main-axis progress is0→0. The analysis excludes17 Architecture links with explicit port directions,23 authored frame-endpoint links, and six edges internal to authored leaf cycles. It retains every excluded edge and reason. Per-edge directions/deltas, full quotient edges and eligibility reasons are in `STRUCTURE.json`; this is structural compatibility evidence, not a pixel proof.

The cohort supports restricting global placement to the false-quotient-cycle domain while retaining recursive placement elsewhere. It supplies no positive eligible example of that domain; the owning false-cycle regressions must continue to qualify the positive branch independently. A subsequent production change requires affected requalification rather than treating these pre-change outcomes as final.

Evidence: `ENROLLMENT.json`, both jobs and module snapshots, complete compressed/plain products, `COMPARISON.json` from the existing comparator, `SUMMARY.json`, and `STRUCTURE.json`. No cap, expected value or qualifier was weakened.

A structural counterexample outside this enrolled cohort illustrates the missing hosted-edge condition: root leaves A→B, B→x1, x2→A, with x1/x2 in G. The leaf graph x2→A→B→x1 is acyclic; the complete root quotient A→B→G→A is cyclic, while lifted-only B→G→A is acyclic. All endpoints are leaves. This is a model argument, not a rendered qualification in this report. Both any false-cycle admission predicate and an acyclic-quotient border-precedence rule must consider the complete quotient.
