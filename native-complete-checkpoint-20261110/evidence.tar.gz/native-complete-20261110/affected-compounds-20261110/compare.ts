import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import { compareSnapshots } from '/tmp/pr449-main-integration-20261029-762/eval/layout-compare/run.ts'
const out = import.meta.dir
const read = (name: string) => JSON.parse(readFileSync(out + '/' + name + '/snapshot.json', 'utf8'))
const before = read('baseline102'), after = read('current')
for (const [snapshot, suffix] of [[before, 'baseline102-opaque'], [after, 'current-opaque']] as const) {
  snapshot.samples.push(...read(suffix).samples)
  snapshot.samples.sort((a: any, b: any) => a.id.localeCompare(b.id))
}
for (const [name, snapshot] of [['baseline102-all', before], ['current-all', after]] as const) {
  const bytes = JSON.stringify(snapshot)
  writeFileSync(out + '/' + name + '.json', bytes)
  writeFileSync(out + '/' + name + '.json.gz', gzipSync(bytes, { level: 9 }))
}
const comparisons = compareSnapshots(before, after)
writeFileSync(out + '/COMPARISON.json', JSON.stringify(comparisons, null, 2) + '\n')
const rows = comparisons.map((row: any) => ({ id: row.id, family: row.family, verdict: row.verdict, notes: row.notes,
  beforeOk: row.before.ok, afterOk: row.after.ok,
  beforeProof: row.before.svgReceipt?.layoutCertification?.status ?? 'unavailable', afterProof: row.after.svgReceipt?.layoutCertification?.status ?? 'unavailable',
  svgExact: row.before.svg === row.after.svg, entireSvgReceiptExact: JSON.stringify(row.before.svgReceipt) === JSON.stringify(row.after.svgReceipt),
  beforeGeometry: row.before.metrics?.routeGeometry, afterGeometry: row.after.metrics?.routeGeometry,
  beforeFailure: row.before.failures, afterFailure: row.after.failures,
  beforeIssues: row.before.svgReceipt?.layoutCertification?.issues, afterIssues: row.after.svgReceipt?.layoutCertification?.issues,
}))
writeFileSync(out + '/SUMMARY.json', JSON.stringify(rows, null, 2) + '\n')
console.log(JSON.stringify(rows.map(({ beforeFailure, afterFailure, ...row }: any) => row), null, 2))
