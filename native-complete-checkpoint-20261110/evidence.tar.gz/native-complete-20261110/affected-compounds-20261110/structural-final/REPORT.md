# Structural final affected-compound qualification

**All nine previously observed regressions are removed.** The existing comparator reports25 unchanged, zero regressions, zero improvements and zero changed verdicts against the frozen10253 producer baseline.

The same25 source cases and original indices were enrolled, including opaque typed-parser case Flowchart99: Flowchart9, State5, Class6, Architecture5. This acquisition runs both arms in original index order through the unchanged existing `snapshot-selected.mjs` collector. No production files were edited. The prior broad-global results and all adverse artifacts remain intact in the parent evidence directory.

Both arms use Native with fallback none and the same existing caller options. Baseline module overrides are the coordinator's frozen10253 five files. Current source is frozen in the accompanying six `current-*` files after the full-quotient-cycle admission predicate. This binds the producer candidate under review; it is not an exact-head CI/readiness claim.

- 25/25 complete SVGs and25/25 entire serialized SVG receipts are byte-exact.
- 25/25 layouts, layout receipts, complete quality metrics and ASCII outputs are equal (`FULL-PRODUCT-EQUALITY.json`).
- All25 inputs return every enrolled surface in both arms, with no exceptions/refusals.
- SVG and layout proof classifications remain24 passed/one unverified.
- The retained unverified case is `fixture/stress/flowchart-subgraphs-12x8.mmd`, still carrying `OUTPUT_SCOPE` and `CHECK_BUDGET`. Its uncertainty is preserved rather than counted as a correctness pass.
- The fresh baseline acquisition also matches all25 products/entire SVG receipts from the earlier baseline, so including opaque99 at its original source order did not alter the control products.

Class17/18 crossings return to0; Class19 bends return to6; the compound Class fixture returns to0 bends/wire616/area579204. Architecture and Flowchart products likewise return exactly to their control geometry, removing every earlier adverse wire/area change. The prior two improvements are also absent: this cohort is compatibility validation of the narrower model domain, not new positive coverage.

Complete source, public layout, SVG, ASCII, metrics and both receipts are retained in `baseline102-all.json.gz` and `current-all.json.gz` and plaintext copies. `COMPARISON.json` is produced by the existing `compareSnapshots`; `SUMMARY.json` retains delivery/proof/issues and geometry details. No timing or memory claim is made.

This25-case cohort contains no eligible leaf-DAG/cyclic-quotient input; the positive false-cycle branch remains the responsibility of its independent owning regression cases. Their successful qualification cannot be inferred from these unchanged products.
