import fs from 'node:fs';
import path from 'node:path';
import inspector from 'node:inspector';
import {promisify} from 'node:util';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {registerHooks,stripTypeScriptTypes} from 'node:module';
import {gzipSync,gunzipSync} from 'node:zlib';
const root='/tmp/pr449-main-integration-20261029-762',out=process.argv[2],job=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
fs.mkdirSync(out,{recursive:true});
const maps={};
registerHooks({
 resolve(specifier,context,next){
  if(specifier.startsWith('.')&&(context.parentURL?.startsWith(pathToFileURL(root+'/').href)||context.parentURL?.includes('/node_modules/roughjs/bin/'))){
   const p=new URL(specifier,context.parentURL);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.ts'))return next(p.href+'.ts',context);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.js'))return next(p.href+'.js',context);
  }
  if(specifier.startsWith('roughjs/bin/')&&!path.extname(specifier))return next(specifier+'.js',context);
  return next(specifier,context);
 },
 load(url,context,next){
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.json'))return{format:'json',shortCircuit:true,source:fs.readFileSync(fileURLToPath(url),'utf8')};
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.ts')){
   const original=fs.readFileSync(job.moduleOverrides?.[fileURLToPath(url)] ?? fileURLToPath(url),'utf8');
   const source=stripTypeScriptTypes(original,{mode:'transform',sourceMap:job.profile !== false,sourceUrl:url});
   const m=source.match(/sourceMappingURL=data:application\/json;base64,([^\s]+)/);
   if(m)maps[url]=JSON.parse(Buffer.from(m[1],'base64').toString());
   return{format:'module',shortCircuit:true,source};
  }
  return next(url,context);
 }
});
const gz=(name,value)=>fs.writeFileSync(out+'/'+name+'.gz',gzipSync(typeof value==='string'?value:JSON.stringify(value)));
const {createLazyVisibilityGrid}=await import(pathToFileURL(root+'/src/layout/compound-lazy-visibility.ts'));
const work={pairs:1000000,arcs:65536,swaps:1000000};let inheritedReads=0,result;
const old=Object.getOwnPropertyDescriptor(Object.prototype,'get');
Object.defineProperty(Object.prototype,'get',{__proto__:null,configurable:true,get(){inheritedReads++;throw new Error('inherited descriptor get observed')}});
try{const grid=createLazyVisibilityGrid({x:0,y:0,width:48,height:48},[],[{port:{x:0,y:4},stub:{x:8,y:4},penalty:0}],[{x:40,y:40}],8,work,32768,reason=>{throw new Error(reason)});const points=grid.route([{port:{x:0,y:4},stub:{x:8,y:4},penalty:0}],{x:40,y:40});result={status:'returned',points,vertices:grid.vertices,inheritedReads,work};}
catch(e){result={status:'error',message:e.message,inheritedReads,work};}
finally{delete Object.prototype.get;if(old)Object.defineProperty(Object.prototype,'get',old);}
fs.writeFileSync(out+'/RESULT.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
