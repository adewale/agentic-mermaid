from pathlib import Path
import os,subprocess,json
out=Path(__file__).parent;rows=[]
for i,variant in enumerate(['baseline','owned-heap','owned-heap','baseline','owned-heap','baseline','baseline','owned-heap']):
 name=f'abba-{i}-{variant}';p=out/name
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(['node','--expose-gc',str(out/'measure.mjs'),str(p),str(out/f'trinity-{variant}-job.json')],env={**os.environ,'AGENTIC_MERMAID_ELK_CACHE':'0'},stdout=log,stderr=subprocess.STDOUT)
 rows.append({'index':i,'variant':variant,'directory':name,'exit':r.returncode});print(rows[-1],flush=True)
 if r.returncode:break
(out/'ABBA-RUNS.json').write_text(json.dumps({'source':'d951d78360d45c0260779c8d63207dbe92a85c1b','runs':rows,'scope':'Existing source API collector,40fullSVG+entirereceipt attempts in8serialfreshNode24processes; cache0; baseline/candidate ABBA order. No concurrentprofile/build/tests. No speedup assumed; diagnostic sourceoverride outsideproduction.'},indent=2)+'\n')
