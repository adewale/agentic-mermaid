# Independent owned-heap directory review

Read-only comparison of `compound-lazy-visibility.owned-heap.ts` against production `src/layout/compound-lazy-visibility.ts` at the stated d951 baseline. Inspected the small diff and heap enqueue/swap/pop consumers only. No tests, renders, profiles, builds or production edits.

## One concrete correction before adoption

The new page publication uses `Object.defineProperty(heapPages, page, { value: data, writable: true, enumerable: true, configurable: true })`. That descriptor has the ordinary Object prototype. JavaScript's ToPropertyDescriptor reads inherited `get` and `set` fields as well as own fields. Thus an inherited Object.prototype `get` or `set` value can turn this into an invalid mixed data/accessor descriptor and throw; an inherited accessor for either field can also run. The old Map page publication did not perform this descriptor conversion.

Use a null-prototype descriptor, e.g. `{ __proto__: null, value: data, writable: true, enumerable: true, configurable: true }`, to preserve the intended own-data publication and avoid that new prototype observation. This is distinct from arbitrary replacement of builtin functions; it is normal inherited-field behavior of the newly introduced descriptor. No runtime counterexample was executed, per the requested scope.

## Directory and allocation invariants

Otherwise no blocker found. Fresh heap indices are appended at `heapSize`; enqueue publishes the slot before any heap read of it. Swaps overwrite existing valid indices. Pop reads the old last slot, decreases size and overwrites index zero only when the heap remains nonempty. None creates a hole in the range of previously allocated heap pages. Retained pages are never removed. Consequently `page < heapPages.length` implies that the page is an owned entry, and a new page occurs exactly at the current directory length. The length guard avoids reading an absent inherited numeric property, while defining an own numeric property avoids inherited numeric setters, including inherited nonwritable numeric data properties. The direct `heap` read also addresses an already-created page under these invariants.

State IDs remain bounded by the existing signed Int32 check; heap slot indices cannot exceed the number of discovered states. The change neither packs IDs nor changes comparisons, priority calculations, tie breaks, child selection or publication order. It leaves sparse state/point/segment maps untouched. All data are query-private; no caller array, Proxy or getter supplies this directory. There are no added caller-input reads or cache keys.

`reserve(count)` still runs before allocating the Int32 page and publishing its directory entry. Page sizes and final partial-page arithmetic are unchanged, failed reservations are not refunded, and the array is grown only when a previously absent heap page would have been inserted into the Map. The existing page-capacity accounting therefore bounds this dense directory without allocating up to the sparse state-ID envelope. No ledger or global cap was enlarged. I found no new negative-index, sparse-array or page-range path in the inspected heap operations.

## Value and evidence limit

Replacing only the directory for dense heap slots is appropriately narrow for the supplied current-delivery profile. It avoids imposing a dense allocation on the sparse state/point/segment domains and preserves the algorithm. The reported 6.902 ms heap lookup time motivates the trial but is not an attainable end-to-end saving by itself; direct array access, descriptor publication and runtime effects must be included in the coordinator's serial full-product comparison. The earlier refusal profile cannot establish this candidate's value. No performance or final-product equivalence claim is made by this static review.
