import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import {layoutMermaidWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/agent/core.ts'
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
const out=import.meta.dir+'/labelled-before',source='flowchart LR\nT[Target]\n'+Array.from({length:10},(_,i)=>`s${i}[S${i}] -->|Message ${i}| T`).join('\n'),rows=[]
mkdirSync(out,{recursive:true});writeFileSync(out+'/CASE.mmd',source)
for(const backend of['elk','agentic','trinity']as const){try{const options={graphLayout:{backend,fallback:'none' as const},embedFontImport:false};const p=renderMermaidSVGWithReceipt(source,options);JSON.stringify(p.receipt);const layout=layoutMermaidWithReceipt(source,options).layout;writeFileSync(out+'/'+backend+'.svg',p.svg);writeFileSync(out+'/'+backend+'.receipt.json',JSON.stringify(p.receipt,null,2));writeFileSync(out+'/'+backend+'.layout.json',JSON.stringify(layout,null,2));rows.push({backend,delivery:'returned',proof:p.receipt.layoutCertification?.status,target:layout.nodes.find(n=>n.id==='T'),decision:p.receipt.layoutDecisions?.[0]})}catch(e:any){rows.push({backend,delivery:'error',error:e.message,name:e.name,proof:e.certification})}}
writeFileSync(out+'/BEFORE.json',JSON.stringify(rows,null,2));console.log(rows)
