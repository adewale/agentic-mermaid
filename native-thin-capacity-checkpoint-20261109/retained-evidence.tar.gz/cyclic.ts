import {readFileSync} from 'node:fs'
import {dirname} from 'node:path'
if(process.argv[2]==='before') Bun.plugin({name:'existing-producer-before-capacity',setup(build){build.onLoad({filter:/\/layout\/measured-graph-producer\.ts$/},args=>({contents:readFileSync(import.meta.dir+'/measured-graph-producer.before.ts','utf8'),loader:'ts',resolveDir:dirname(args.path)}))}})
await import('./run-cyclic.ts')
