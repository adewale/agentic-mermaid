from pathlib import Path
import json
r=Path('/tmp/pr449-main-integration-20261029-762');p=Path(__file__).parent
for rel in ['layout/measured-graph-producer.ts','layout/trinity.ts']:(p/Path(rel).name.replace('.ts','.before.ts')).write_text((r/'src'/rel).read_text())
s=(r/'src/layout/measured-graph-producer.ts').read_text().replace("import { shapeOutline }", "import { paintedStrokeExtent } from '../scene/bounds.ts'\nimport { shapeOutline }")
s=s.replace("node.shape !== 'rounded' && !pseudo", "node.shape !== 'rounded' && node.shape !== 'diamond' && !pseudo")
s=s.replace("    if (graph.edges.some(edge => edge.curve", "    if (graph.subgraphs.length && [...graph.nodes.values()].some(node => node.shape === 'diamond')) bindings.unsupported('diamond compound contacts are outside the measured slice')\n    if (graph.edges.some(edge => edge.curve")
s=s.replace("return { source, target, ...endpointSpans,", "return { source, target, ...(physical && graph.nodes.get(nodes[source]!.id)?.shape === 'diamond' ? { sourceMarkerPresent: Boolean(edge.hasArrowStart) } : {}), ...(physical && graph.nodes.get(nodes[target]!.id)?.shape === 'diamond' ? { targetMarkerPresent: Boolean(edge.hasArrowEnd) } : {}), ...endpointSpans,")
needle="        if (authored.shape === 'state-start' || authored.shape === 'state-end') {"
insert="""        if (authored.shape === 'diamond') {
          pay(96, 64)
          const outline = shapeOutline({ ...authored, ...node, x: 0, y: 0 }, { fill: 'var(--_node-fill)', stroke: 'var(--_node-stroke)', strokeWidth: String(width) }, style.cornerRadius)
          const extent = paintedStrokeExtent(outline.paint, true)
          if (outline.routing.kind !== 'polygon' || outline.routing.points.length !== 4 || extent === undefined || extent <= 0) bindings.unsupported('diamond needs measured polygon stroke support')
          node.contact = 'diamond'; node.contactDiamond = { strokeExtent: extent }; node.paintStrokeWidth = width; node.paintCornerRadius = 0
          node.sizePolicy = options.nodeSizes?.has(id) ? 'fixed' : 'minimum'
          continue
        }
"""
assert needle in s;s=s.replace(needle,insert+needle);(p/'measured-graph-producer.prototype.ts').write_text(s)
s=(r/'src/layout/trinity.ts').read_text();s="import { shapeOutline, pointOnRoutingBoundary } from '../shape-outline.ts'\n"+s
s=s.replace("  const widths: number[] = [], heights: number[] = []", "  const widths: number[] = [], heights: number[] = []\n  let diamond: { cross: Float64Array; main: Float64Array; outset: Float64Array } | undefined")
s=s.replace("node.contact !== 'ellipse') decline", "node.contact !== 'ellipse' && node.contact !== 'diamond') decline")
needle="    widths.push(horizontal ? node.height : node.width); heights.push(horizontal ? node.width : node.height)"
replace="""    if (node.contact === 'diamond') {
      const extent = node.contactDiamond?.strokeExtent
      if (!size(extent, true) || extent < node.paintStrokeWidth! / 2 || node.paintCornerRadius) throw new TypeError('Invalid measured diamond paint support')
      if (!diamond) { spend(n * 3 + 4); work.arcs -= n * 3; assertTrinityWork(work); diamond = { cross: new Float64Array(n), main: new Float64Array(n), outset: new Float64Array(n) } }
      const i = widths.length; diamond.outset[i] = extent; diamond.cross[i] = horizontal ? node.height : node.width; diamond.main[i] = horizontal ? node.width : node.height
      widths.push(diamond.cross[i]! + 2 * extent); heights.push(diamond.main[i]! + 2 * extent)
    } else {
      if (node.contactDiamond !== undefined) throw new TypeError('Diamond support requires a diamond contact')
      widths.push(horizontal ? node.height : node.width); heights.push(horizontal ? node.width : node.height)
    }"""
assert needle in s;s=s.replace(needle,replace)
needle="    if (edge.source === edge.target) loops[edge.source]!.push(e)"
insert="""    for (const [subject, marker] of [[edge.source, edge.sourceMarkerPresent], [edge.target, edge.targetMarkerPresent]] as const) if (input.nodes[subject]!.contact === 'diamond') {
      spend(4)
      if (typeof marker !== 'boolean') decline('diamond endpoints require explicit marker presence')
      if (edge.source === edge.target) decline('diamond loops are outside the contact slice')
    }
"""
assert needle in s;s=s.replace(needle,insert+needle)
needle="    const cornerMargin = (body.paintCornerRadius ?? 0) + body.paintStrokeWidth! / 2"
s=s.replace(needle,"    const cornerMargin = (body.paintCornerRadius ?? 0) + (body.contact === 'diamond' ? body.contactDiamond!.strokeExtent : body.paintStrokeWidth! / 2)")
needle="    const required = count > 1 ?"
insert="""    if (body.contact === 'diamond') for (const peers of [forward[node]!, incoming[node]!]) for (const e of peers) {
      spend(3)
      const edge = input.edges[e]!, marked = edge.source === node ? edge.sourceMarkerPresent : edge.targetMarkerPresent
      if (marked && peers.length !== 1) decline('marked diamond contacts require singleton cardinal seating')
    }
"""
assert needle in s;s=s.replace(needle,insert+needle,1)
needle="  const paths: number[][] = []"
insert="""  if (diamond) for (let i = 0; i < n; i++) if (input.nodes[i]!.contact === 'diamond') {
    spend(8)
    const inset = diamond.outset[i]!, original = horizontal ? input.nodes[i]!.height : input.nodes[i]!.width
    diamond.cross[i] = widths[i] === original + 2 * inset ? original : Math.max(original, widths[i]! - 2 * inset)
    widths[i] = diamond.cross[i]! + 2 * inset
  }
"""
assert needle in s;s=s.replace(needle,insert+needle)
needle="      let previous = -Infinity"
insert="""      if (input.nodes[node]!.contact === 'diamond' && peers.some(e => { const edge = input.edges[e]!; return edge.source === node ? edge.sourceMarkerPresent : edge.targetMarkerPresent })) continue
"""
assert needle in s;s=s.replace(needle,insert+needle)
needle="      const node = { x: cross[i]!, y: reverse ? main[i]! + heights[i]! : main[i]!, width: horizontal ? heights[i]! : widths[i]!, height: horizontal ? widths[i]! : heights[i]! }"
replace="""      const d = input.nodes[i]!.contact === 'diamond', inset = d ? diamond!.outset[i]! : 0
      const bodyCross = d ? diamond!.cross[i]! : widths[i]!, bodyMain = d ? diamond!.main[i]! : heights[i]!
      const node = { x: cross[i]! + inset, y: reverse ? main[i]! + heights[i]! - inset : main[i]! + inset, width: horizontal ? bodyMain : bodyCross, height: horizontal ? bodyCross : bodyMain }"""
assert needle in s;s=s.replace(needle,replace)
needle="      append(ax, main[a]! + heights[a]! - sourceInset); append(ax, track)"
replace="""      const facet = (node: number, coordinate: number, positive: boolean): number | undefined => {
        if (input.nodes[node]?.contact !== 'diamond') return undefined
        spend(96); work.arcs -= 32; assertTrinityWork(work)
        const inset = diamond!.outset[node]!, outline = shapeOutline({ id: input.nodes[node]!.id, label: '', shape: 'diamond', x: cross[node]! + inset, y: main[node]! + inset, width: diamond!.cross[node]!, height: diamond!.main[node]! }, { fill: 'black', stroke: 'black', strokeWidth: '1' })
        const at = pointOnRoutingBoundary(outline.routing, positive ? 'S' : 'N', coordinate)
        if (!at) decline('diamond contact is outside its measured facet')
        return at.y
      }
      append(ax, (i === 1 ? facet(a, ax, true) : undefined) ?? main[a]! + heights[a]! - sourceInset); append(ax, track)"""
assert needle in s;s=s.replace(needle,replace)
needle="      append(bx, main[b]! + targetInset)"
replace="      append(bx, (i + 1 === path.length ? facet(b, bx, false) : undefined) ?? main[b]! + targetInset)"
assert needle in s;s=s.replace(needle,replace)
s=s.replace("input.nodes[node]!.paintStrokeWidth! / 2)) decline('caption overlaps", "(input.nodes[node]!.contact === 'diamond' ? 0 : input.nodes[node]!.paintStrokeWidth! / 2))) decline('caption overlaps")
s=s.replace("const pad = clearance + (input.nodes[vertex]!.paintStrokeWidth ?? 1) / 2", "const pad = clearance + (input.nodes[vertex]!.contact === 'diamond' ? 0 : (input.nodes[vertex]!.paintStrokeWidth ?? 1) / 2)")
(p/'trinity.prototype.ts').write_text(s)
(p/'prototype-preload.ts').write_text("import{plugin}from'bun';import{readFileSync}from'node:fs';const files=new Map("+json.dumps([[str(r/'src/layout/measured-graph-producer.ts'),str(p/'measured-graph-producer.prototype.ts')],[str(r/'src/layout/trinity.ts'),str(p/'trinity.prototype.ts')]])+");plugin({name:'diamond-contact-prototype',setup(b){b.onLoad({filter:/(?:measured-graph-producer|trinity)\\.ts$/},a=>{const f=files.get(a.path);if(f)return{contents:readFileSync(f,'utf8'),loader:'ts'}})}})")
s=(p/'baseline.ts').read_text().replace("'.before.svg'","'.prototype.svg'").replace("'.before.receipt.json'","'.prototype.receipt.json'").replace("'/BASELINE.json'","'/PROTOTYPE.json'");(p/'prototype.ts').write_text(s)
