from pathlib import Path
r=Path('/tmp/pr449-main-integration-20261029-762');p=Path(__file__).parent;b=p/'production-before';b.mkdir(exist_ok=True)
files=['src/shape-outline.ts','src/layout/measured-graph.ts','src/layout/measured-graph-producer.ts','src/layout/trinity.ts','src/layout/agentic-layered-core.ts','src/layout/elk-measured-adapter.ts','src/layout/trinity-compound.ts']
for rel in files:
 f=r/rel;(b/f.name).write_text(f.read_text())
s=(r/'src/shape-outline.ts').read_text();type_start=s.index('/** Boundary consumed by routing.');type_end=s.index('export interface RenderedShapeOutline',type_start);types=s[type_start:type_end]
ops_start=s.index('function routingBounds(');ops_end=s.index('function boxCardinalPorts(',ops_start);ops=s[ops_start:ops_end].replace('function routingBounds(', 'export function routingBounds(').replace('function boundaryIntersection(', 'export function boundaryIntersection(')
point_start=s.index('/** Exact boundary intersection, independent of preferred attachment policies. */');point_end=s.index('/** Exact point on a declared attachment side',point_start);point=s[point_start:point_end]
leaf="import type { Point, PortSide } from '../types.ts'\n\n"+types+'''/** Maximum vertex reserve shared with the shape owner's dynamic-side policy. */
export const DIAMOND_VERTEX_MARGIN = 10

/** The canonical painted polygon; retain its established arithmetic order. */
export function cardinalDiamondPoints(cx: number, cy: number, width: number, height: number): Point[] {
  return [
    { x: cx, y: cy - height / 2 }, { x: cx + width / 2, y: cy },
    { x: cx, y: cy + height / 2 }, { x: cx - width / 2, y: cy },
  ]
}

'''+point+ops
(r/'src/shared/shape-routing-boundary.ts').write_text(leaf)
s=s[:ops_start]+s[ops_end:];s=s[:point_start]+s[point_end:];s=s[:type_start]+s[type_end:]
s="import { boundaryIntersection, routingBounds, pointOnRoutingBoundary, cardinalDiamondPoints, DIAMOND_VERTEX_MARGIN, type ShapeRoutingBoundary } from './shared/shape-routing-boundary.ts'\nexport { pointOnRoutingBoundary, type ShapeRoutingBoundary } from './shared/shape-routing-boundary.ts'\n"+s
old="""      return polygon([
        { x: cx, y: cy - h / 2 }, { x: cx + w / 2, y: cy },
        { x: cx, y: cy + h / 2 }, { x: cx - w / 2, y: cy },
      ], paint)"""
assert old in s;s=s.replace(old,"      return polygon(cardinalDiamondPoints(cx, cy, w, h), paint)",1).replace('size <= 40 ? size / 4 : 10','size <= 40 ? size / 4 : DIAMOND_VERTEX_MARGIN');(r/'src/shape-outline.ts').write_text(s)
s=(r/'src/layout/measured-graph.ts').read_text().replace("contact?: 'rectangle' | 'rounded-rectangle' | 'ellipse';", "contact?: 'rectangle' | 'rounded-rectangle' | 'ellipse' | 'diamond'; /** Canonical cardinal diamond; bounds its actual joined stroke after permitted growth. */ contactDiamond?: { strokeExtent: number };")
s=s.replace('sourcePortSpan?: number; targetPortSpan?: number;', 'sourcePortSpan?: number; targetPortSpan?: number; /** Explicit marker-roster facts for diamond contacts; false proves shaft-only. */ sourceMarkerPresent?: boolean; targetMarkerPresent?: boolean;');(r/'src/layout/measured-graph.ts').write_text(s)
s=(p/'measured-graph-producer.prototype.ts').read_text();s=s.replace("  const physical = purpose === 'owned-routed'", "  const physical = purpose === 'owned-routed'\n  let diamondContacts = false")
s=s.replace("      const pseudo = node.shape === 'state-start'", "      if (node.shape === 'diamond') diamondContacts = true\n      const pseudo = node.shape === 'state-start'")
s=s.replace("if (graph.subgraphs.length && [...graph.nodes.values()].some(node => node.shape === 'diamond'))", "if (diamondContacts && graph.subgraphs.length)")
s=s.replace("only measured rectangular, rounded and State circle contacts are supported", "only measured rectangular, rounded, diamond and State circle contacts are supported")
s=s.replace("boundaryCount: number }", "boundaryCount: number; startPresent?: boolean; endPresent?: boolean }")
s=s.replace("          for (const marker of markers) {", "          let startPresent = false, endPresent = false\n          for (const marker of markers) {")
s=s.replace("            const box = marker.bounds", "            if (diamondContacts) { pay(2); if (marker.position === 'start') startPresent = true; if (marker.position === 'end') endPresent = true }\n            const box = marker.bounds")
s=s.replace("          pay(0, 9)\n          footprint = { start, end, startSpan, endSpan, span, boundaryInset, boundaryHeight, boundaryCount }", "          pay(diamondContacts ? 2 : 0, diamondContacts ? 13 : 9)\n          footprint = { start, end, startSpan, endSpan, span, boundaryInset, boundaryHeight, boundaryCount, ...(diamondContacts ? { startPresent, endPresent } : undefined) }")
s=s.replace("{ sourceMarkerPresent: Boolean(edge.hasArrowStart) }", "{ sourceMarkerPresent: footprint ? footprint.startPresent : false }").replace("{ targetMarkerPresent: Boolean(edge.hasArrowEnd) }", "{ targetMarkerPresent: footprint ? footprint.endPresent : false }")
s=s.replace("const outline = shapeOutline({ ...authored, ...node, x: 0, y: 0 }, { fill: 'var(--_node-fill)', stroke: 'var(--_node-stroke)', strokeWidth: String(width) }, style.cornerRadius)\n          const extent", "const inline = resolveNodeInlineStyle(id, graph)\n          const outline = shapeOutline({ ...authored, ...node, x: 0, y: 0 }, { fill: inline?.fill ?? style.nodeFillColor ?? 'var(--_node-fill)', stroke: inline?.stroke ?? style.nodeBorderColor ?? 'var(--_node-stroke)', strokeWidth: inline?.['stroke-width'] ?? String(style.nodeLineWidth) }, style.cornerRadius)\n          const extent")
s=s.replace("extent === undefined || extent <= 0", "extent === undefined || !Number.isFinite(extent) || extent < 0").replace("node.paintStrokeWidth = width; node.paintCornerRadius = 0", "node.paintStrokeWidth = extent === 0 ? 0 : width; node.paintCornerRadius = 0")
(r/'src/layout/measured-graph-producer.ts').write_text(s)
s=(p/'trinity.prototype.ts').read_text().replace("import { shapeOutline, pointOnRoutingBoundary } from '../shape-outline.ts'", "import { cardinalDiamondPoints, pointOnRoutingBoundary, DIAMOND_VERTEX_MARGIN } from '../shared/shape-routing-boundary.ts'")
s=s.replace("size(node.paintStrokeWidth!, node.contact !== 'ellipse')", "size(node.paintStrokeWidth!, node.contact !== 'ellipse' && node.contact !== 'diamond')")
s=s.replace("if (!size(extent, true)", "if (extent === undefined || !size(extent)")
s=s.replace("      widths.push(diamond.cross[i]! + 2 * extent); heights.push(diamond.main[i]! + 2 * extent)", "      const crossSize = diamond.cross[i]! + 2 * extent, mainSize = diamond.main[i]! + 2 * extent\n      if (!size(crossSize, true) || !size(mainSize, true)) throw new TypeError('Diamond paint bounds overflow')\n      widths.push(crossSize); heights.push(mainSize)")
a="    for (const [subject, marker] of [[edge.source, edge.sourceMarkerPresent], [edge.target, edge.targetMarkerPresent]] as const) if (input.nodes[subject]!.contact === 'diamond') {"
bb="    if (input.nodes[edge.source]!.contact === 'diamond' || input.nodes[edge.target]!.contact === 'diamond') for (const [subject, marker] of [[edge.source, edge.sourceMarkerPresent], [edge.target, edge.targetMarkerPresent]] as const) if (input.nodes[subject]!.contact === 'diamond') {"
assert a in s;s=s.replace(a,bb)
s=s.replace("    margin[node] = Math.max(8, cornerMargin)", "    margin[node] = Math.max(8, cornerMargin, body.contact === 'diamond' ? body.contactDiamond!.strokeExtent + DIAMOND_VERTEX_MARGIN : 0)")
# One shared numeric query per diamond endpoint; no shape factory or closure per ordinary segment.
start=s.index('      const facet = (node: number, coordinate: number, positive: boolean): number | undefined => {');end=s.index('      append(ax,',start);block=s[start:end]
s=s[:start]+s[end:]
block=block.replace('      const facet', '  const facet').replace('        ', '    ').replace('      }\n', '  }\n')
old="    const inset = diamond!.outset[node]!, outline = shapeOutline({ id: input.nodes[node]!.id, label: '', shape: 'diamond', x: cross[node]! + inset, y: main[node]! + inset, width: diamond!.cross[node]!, height: diamond!.main[node]! }, { fill: 'black', stroke: 'black', strokeWidth: '1' })\n    const at = pointOnRoutingBoundary(outline.routing, positive ? 'S' : 'N', coordinate)"
new="    const inset = diamond!.outset[node]!, width = diamond!.cross[node]!, height = diamond!.main[node]!\n    const boundary = { kind: 'polygon' as const, points: cardinalDiamondPoints(cross[node]! + inset + width / 2, main[node]! + inset + height / 2, width, height) }\n    const at = pointOnRoutingBoundary(boundary, positive ? 'S' : 'N', coordinate)"
assert old in block;block=block.replace(old,new).replace('work.arcs -= 32','work.arcs -= 48')
needle="  const routes: MeasuredRoutes['edges'] = []";assert needle in s;s=s.replace(needle,block+needle)
# Marked singleton faces are identified during already paid capacity iteration.
s=s.replace("  let diamond: { cross: Float64Array; main: Float64Array; outset: Float64Array } | undefined", "  let diamond: { cross: Float64Array; main: Float64Array; outset: Float64Array; sourceCardinal: Uint8Array; targetCardinal: Uint8Array } | undefined")
s=s.replace('spend(n * 3 + 4); work.arcs -= n * 3','spend(n * 5 + 6); work.arcs -= n * 5').replace('outset: new Float64Array(n) }','outset: new Float64Array(n), sourceCardinal: new Uint8Array(n), targetCardinal: new Uint8Array(n) }')
s=s.replace("for (const peers of [forward[node]!, incoming[node]!]) for (const e of peers)", "for (const [peers, cardinal] of [[forward[node]!, diamond!.sourceCardinal], [incoming[node]!, diamond!.targetCardinal]] as const) for (const e of peers)")
s=s.replace("      if (marked && peers.length !== 1) decline('marked diamond contacts require singleton cardinal seating')", "      if (marked && peers.length !== 1) decline('marked diamond contacts require singleton cardinal seating')\n      if (marked) cardinal[node] = 1")
s=s.replace("      if (input.nodes[node]!.contact === 'diamond' && peers.some(e => { const edge = input.edges[e]!; return edge.source === node ? edge.sourceMarkerPresent : edge.targetMarkerPresent })) continue", "      if (input.nodes[node]!.contact === 'diamond' && (source ? diamond!.sourceCardinal[node] : diamond!.targetCardinal[node])) continue")
(r/'src/layout/trinity.ts').write_text(s)
s=(r/'src/layout/agentic-layered-core.ts').read_text();a="  for (const node of input.nodes) if (node.paintStrokeWidth !== undefined && !finiteSize(node.paintStrokeWidth,true)) throw new TypeError('Invalid measured node paint stroke')";bb="  for (const node of input.nodes) {\n    if (!input.placementOnly && node.contact === 'diamond') unsupported('diamond measured contacts require the owning family adapter')\n    if (node.paintStrokeWidth !== undefined && !finiteSize(node.paintStrokeWidth,true)) throw new TypeError('Invalid measured node paint stroke')\n  }";assert a in s;s=s.replace(a,bb);(r/'src/layout/agentic-layered-core.ts').write_text(s)
s=(r/'src/layout/elk-measured-adapter.ts').read_text().replace("input.nodes.some(n => n.parent !== undefined", "input.nodes.some(n => n.contact === 'diamond' || n.parent !== undefined");(r/'src/layout/elk-measured-adapter.ts').write_text(s)
s=(r/'src/layout/trinity-compound.ts').read_text().replace("const leaves = new Map(input.nodes.map(node => [node.id, node]))", "const leaves = new Map(input.nodes.map(node => {\n    if (node.contact === 'diamond') unsupported('diamond compound contacts are outside the measured slice')\n    return [node.id, node] as const\n  }))");(r/'src/layout/trinity-compound.ts').write_text(s)
