import { plugin } from 'bun'
import { readFileSync } from 'node:fs'
const overrides = new Map(JSON.parse(readFileSync(import.meta.dir + '/BASELINE-OVERRIDES.json', 'utf8')).map(entry => [entry.module, entry.override]))
plugin({ name: 'exact-7b95-before', setup(builder) {
  builder.onLoad({ filter: /(?:requirement\/layout|elk-measured-adapter|agentic-layered-core)\.ts$/ }, args => {
    const file = overrides.get(args.path)
    if (file) return { contents: readFileSync(file, 'utf8'), loader: 'ts' }
  })
} })
