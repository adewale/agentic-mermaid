# Installed ELK translation review — Requirement physical measured slice

Read-only implementation inspection against source checkpoint 7b95 and installed `elkjs` **0.11.1**, resolved at `/tmp/pr449-tools-20261106/elkjs-0.11.1`. No renderer, layout call, test, build, network acquisition or production edit was performed. This report establishes API/runtime-source behavior, not experimentally validated output of a proposed bridge.

Installed file identities:

- `lib/elk-worker.js`: SHA256 `c93ae799ceb15b94b19272307b5bfde46e7dde6f274a2fb78afeba2ac0393f77`.
- `lib/elk.bundled.js`: SHA256 `20dd2114d683ce758b3ce19bcc56e28a504a617b0d280f760407c37314631d0e`.

The application loads `elk.bundled.js` through its existing synchronous dispatcher (`src/elk-instance.ts`). Line references below to the worker are the installed package's readable generated implementation; the bundled application artifact contains the packaged minified worker. No independent equivalence test between those builds was run here.

## Recommendation

A real, bounded translation is plausible. Do not simply remove the physical-field gate. Add a physical-request branch to `elkMeasuredAdapter`, initially qualified through the existing Requirement interaction owner. Keep the old unmeasured adapter path intact while qualifying this branch. Use explicit per-occurrence ports, permitted node growth, physical clearance options and complete output projection. Reuse the same Requirement producer/finalizer once the branch has behavioral evidence.

The proposed common request should retain authored measured dimensions, contact type/radius/stroke, fixed/minimum size policy, source and target support spans, edge spacing, terminal lead, shaft maximum and complete label envelopes. Requirement's rich producer already supplies these at `src/requirement/layout.ts:124–142`. There is no generic edge-weight field in this IR; do not invent a weighting correspondence. Prepared text/font weight and actual marker factories remain family-owned.

## Source-supported API and options

All worker references are `node_modules/elkjs/lib/elk-worker.js`.

| Concern | Installed source evidence | Translation and limit |
| --- | --- | --- |
| Explicit ports | `elk-api.d.ts:33–42,70–84`; worker `32242–32260` copies each port's dimensions, position and anchor | Give every edge occurrence its own source and target port IDs; use port IDs in `sources`/`targets`. Do not merge reciprocal or duplicate authored edges. |
| Tangential capacity | Worker `22957–22965`, `23984–23997`, `23815–23819`, `23907–23911` sums port sizes plus gaps when sizing/placing a side | Nonzero dimensions really reserve side space. A zero-size point plus an unrelated option does not represent heterogeneous endpoint supports. |
| Exact connection anchor | Worker `30631–30658` reads explicit `port.anchor`; `31323–31346` preserves it when a port changes side | Default anchors lie on the outer port face. Specify an explicit center anchor for the proposed square support port. |
| Border offset | Option metadata `68710`; placement `23818,23909` | A square port of side `s`, anchor `(s/2,s/2)` and `port.borderOffset=-s/2` has its anchor on the logical node boundary on all four sides. This follows the placement equations. End-to-end routing, reflection and self-loop restoration still require a probe. |
| Free sides | `30608–30658`; layered option registration `47094–47095` | Start with `portConstraints=FREE`; physical measurements do not authorize inventing authored fixed side/order constraints. The explicit center anchor avoids default-anchor changes as ELK selects sides. |
| Minimum body growth | `22773–22822`, `23147–23165`; options `68699–68701`; enums `69403–69408` | For `sizePolicy:minimum`, use `nodeSize.constraints=[PORTS, MINIMUM_SIZE]` and `nodeSize.minimum=(measuredWidth,measuredHeight)`. Returned dimensions must be published. Fixed policy needs unchanged dimensions and an honest capacity check, never silent growth. |
| Dangerous fixed capacity | `23784–23791`, `23876–23883` | When available space is inadequate and growth is unavailable, ELK can reduce gaps, including into overlap. Merely setting port sizes does **not** prove separation. Do not enable `PORTS_OVERHANG` as a substitute. |
| Corner reserves | `22904–22909`, `23992–23997`; metadata `68688` | `spacing.portsSurrounding` reserves space before/after the set of ports. Use at least the canonical rounded radius plus half node stroke as corner reserve; support-port half-width then supplies the additional endpoint half-span. A graph-wide maximum is conservative and simpler for the first bounded slice. |
| Spacing inheritance trap | `71309–71317`, `47752–47760`; `22576–22579` | These consumers read `spacing.individual` or the parent graph. Do not assume setting arbitrary plain node-level `spacing.portsSurrounding`/`spacing.portPort` reaches them. Root-level maxima avoid that uncertainty. |
| Routing spacing | Layered registrations `47045–47058`; orthogonal router `55872–55905` | Set both ordinary `spacing.edgeEdge` and `layered.spacing.edgeEdgeBetweenLayers`; likewise both edge-node variants. The actual between-layer router uses these values to position tracks. This is not a blanket proof for every same-layer/self-loop segment. |
| Edge thickness | Layered registration `47147`; consumers include `36738`, `36810`, `37930` | `edge.thickness` exists and some phases consume it. Do not assume it alone adds painted clearance to every orthogonal route: the main between-layer router directly consumes the spacing options. |

Use full option IDs where practical to avoid ambiguous suffix resolution. Margin strings are parsed as `[top=...,right=...,bottom=...,left=...]` (`30950–30971`). Vector/enum-set encodings still need binding in the root's actual API probe; do not treat an untested string accepted by TypeScript as a working runtime option.

## Smallest conservative physical representation

For an endpoint, start from `support = max(endpointSpan, maximumEdgeStrokeWidth)`, matching Trinity's conservative support interpretation (`src/layout/trinity.ts:79–82`). A square of that size is side-independent. Where `minimumPortSpacing` imposes a larger center pitch, it must also be represented: a straightforward conservative choice is to raise each incident square side to at least that minimum, then use the requested edge spacing as inter-port gap. This may overreserve compared with an optimal heterogeneous pack, but it does not silently drop the constraint. The existing Trinity allocator itself uses maximum incident support/minimum pitch plus edge spacing (`trinity.ts:142–151`). Do not claim the two allocators then produce identical packing.

Set the parent corner reserve to the maximum `paintCornerRadius + paintStrokeWidth/2` over admitted cards. With square ports, the anchor sits a further half-square from the corner. This keeps contacts on the straight sides of canonical rounded cards. ELK has no knowledge of our renderer's rounded contour, stroke or CSS; the adapter supplies this reservation, and final canonical geometry/paint remains authoritative. Reject unknown/relative stroke values at the existing producer boundary; no parseFloat-only promotion to a physical measurement.

For foreign shaft/body clearance, use a conservative graph-wide bound `nodeClearance + maxNodeHalfStroke + maximumEdgeStrokeWidth/2`, and do not make either edge-node spacing less than that bound or the required terminal lead. Preserve the existing family policy's larger edge-node minimum if applicable. Root node-node/layer separation and outer padding also need to retain painted stroke extents; relying on logical body sizes alone is insufficient. These conservative formulas are proposed mappings, **not measured guarantees** of every ELK routing phase. The acceptance probe must inspect actual output, especially feedback routes and self-loops.

Set `layered.mergeEdges=false` explicitly for this semantic slice. Still recover output by synthetic edge ID, not assumed output array order. Keep authored IDs outside the ELK-generated namespace; return geometry in original input order. Explicit endpoints must map to their intended synthetic ports after ELK's private cycle reversal. Do not concatenate arbitrary multi-section/hyperedge routes without validating connectivity and orientation; this slice supplies one source and target per occurrence.

## Output/finalizer changes that cannot be omitted

The current ELK adapter retains only child `x/y` (`src/layout/elk-measured-adapter.ts:29–30`). A growing-node branch must return `width/height` as well. `solveMeasuredLayout` already checks fixed/minimum size policy (`src/layout/measured-backend.ts`). Requirement currently publishes growth only within the Trinity callback (`src/requirement/layout.ts:144–147`); move successful-result publication to the shared family path, preserving declined-attempt isolation and the measured request. Do not mutate the input request while handing ELK its private graph.

Continue through the canonical Requirement finalizer (`requirement/layout.ts:150–169`) and renderer. Endpoint resources are start containment versus end arrow (`requirement/renderer.ts:64`); they cannot be replaced with generic arrows. Label reservation is text+16/+10 whereas actual background is text+12/+8 (`requirement/renderer.ts:81`), already conservative. Do not add Flow's halo a second time or transfer its stopped global-halo change. Body text rows, prepared weights, ownership and final receipt remain unchanged in authority.

A new port graph adds two port records per edge and associated option strings. Keep existing graph-work admission/cache ownership intact; do not assume the old request size charges cover new records, introduce a new cache or relax caps. The existing wrapper's serialization must include the actual new port/options payload.

## What must be demonstrated before shipping

1. The installed API actually honors centered anchors plus negative offset in TB/BT/LR/RL, including a feedback edge. Verify literal final first/last points on canonical straight body faces and outward terminal normals.
2. Dense, heterogeneous endpoint supports remain separated. A minimum-size card grows and its **emitted** frame adopts that size; fixed cards either fit unchanged or decline. Verify the original immutable request and fallback isolation.
3. Rounded-radius reservations keep whole marker support away from corners. A large radius, thick stroke and explicit minimum pitch are adverse cases, not merely metadata tests.
4. First/last terminal runs accommodate actual containment/arrow resources. Same-layer and self-loop routing are separate risks: ordinary spacing options alone do not establish those contracts.
5. The existing public Requirement interaction (`src/__tests__/requirement-layout-backends.test.ts:48–70`) retains five distinct authored relationships, including duplicate satisfies, reciprocal derives/traces and source containment; actual labels/markers/cards survive all three backends through the canonical emitter.
6. Passing the shared helper fixture alone is insufficient. Extend the existing conformance table with the **same rich request** and bind the public product to that wiring. Check complete SVG+receipt and actual ink; detect delivery/proof regressions and material area/wire growth.

If the port/anchor prototype does not preserve these contacts, stop that translation rather than silently stripping support metadata. This is contract convergence; no public delivery loss or performance improvement has been established by this review.

## Authorized actual-runtime follow-up

The coordinator subsequently authorized a small temporary probe through **the actual `elkLayoutSync` wrapper**, before production implementation. Scripts and complete returned graphs are retained here; production files were not changed.

- `elk-port-probe.ts`, `ELK-PORT-PROBE.json`, `ELK-PORT-PROBE-SUMMARY.json`: 20 executions on Bun1.4.4 / installed ELK0.11.1. Single edge, eight parallel edges, reciprocal directed cycle, one labelled self-loop, and labelled loops plus a reciprocal pair; each in TB/BT/LR/RL.
- `elk-port-probe-limits.ts`, `ELK-PORT-PROBE-LIMITS.json`, `ELK-PORT-PROBE-LIMITS-SUMMARY.json`: 12 executions adding heterogeneous support sizes and a causal self-loop terminal-lead control. This file retains both pristine input JSON and the mutated private ElkNode graph.

**Validated in these executions:** exact option syntax `'[PORTS, MINIMUM_SIZE]'`, minimum vector `'(80,50)'`, empty size options `'[]'`, root margin string, FREE square ports, explicit center anchors and negative half-size border offset all worked together. Every returned edge had one section, orthogonal geometry, start/end matching the designated port's center on a logical body face, and outward terminal normals. No returned dimension shrank below80×50. Every tested port retained at least the9px tangential corner reserve and every same-side port pair retained its8px gap. This checks canonical logical face placement; the probe did not render rounded paint or markers.

Dense20px ports grew cards to248px along the occupied face in every direction. Heterogeneous ports (effective sizes20–38px after a minimum pitch of20) grew opposite cards to266px/298px along that face; all checked gap/corner/anchor invariants remained satisfied. The extra size beyond a simple pack is ELK's sizing/alignment policy, not an asserted minimum-optimal result. Single LR/RL cards grew50→52px in height, which illustrates that the minimum policy does not promise unchanged roomy bodies.

**Confirmed important missing mapping:** setting both edge-node options to40 did NOT reserve a40px self-loop terminal. All four `loop-lead40` outputs retained20px terminal runs. Adding root `'org.eclipse.elk.spacing.nodeSelfLoop':'40'` produced50px terminal runs in all four `loop-explicit-self-clearance` outputs, with the same valid body-face anchors. Thus the bridge must translate the lead into the self-loop spacing policy too, and still validate actual terminal lengths; a generic edge-node option is insufficient. The source arrays report raw measured lengths rather than automatically classifying this prospective40px contract, so the ordinary `issues` array does not itself flag that demonstrated lead mismatch.

**Private input mutation:** all32 calls mutated their supplied private `ElkNode` graph. Their only listed invariant issue was `input-mutated`. This is not an immutable-MeasuredGraph failure in the proposed bridge if it constructs a fresh private graph with no mutable aliases. Never hand the owned measured request, its point arrays or shared canonical records directly to ELK. Publication of returned dimensions remains necessary.

No final SVG, font/label ownership, real marker separation, final proof, fixed-size capacity behavior, general rounded geometry, budget cost or performance ratio is established by these probes. The existing Requirement public interaction and actual painted-ink checks remain the owning acceptance boundary. These results supplement, rather than retroactively change, the source-only status of the initial review above.
