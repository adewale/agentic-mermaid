This PR repairs Native grouped routing and removes repeated geometry/text processing between capture, SVG writing and paint inspection. Native remains the replacement candidate; Trinity feature work is frozen.

**Draft: the full request remains incomplete.** Native100 latency, Chain300 proof availability and browser payload limits are unresolved. The earlier scalar-capture experiment was withdrawn after adverse final timings; the current private-ledger change improves measured warm latency but remains above target.

Current pushed head: `2525b91c477b9ad1fff162574d12f55c8c4be54e` (parent `31f368fa9eec6128751340f32d969f9bebf87316`). Three actual-writer rect/text variants were rejected after adverse matched timings; their patches and results are retained outside the source diff. It preserves the integration of frozen Main913, browser/XML repairs and parser/schema changes. Defaults, versions and resource caps are unchanged relative to that Main baseline.

## Changes and contracts

- Shared layout dispatch admits backend and fallback once before running a producer. Invalid raw selections reject before any producer or fallback executes; getters and producer callbacks cannot change the selected policy or rewrite its evidence. Retention callbacks and observers receive the same immutable decision. All three current backend names remain accepted.
- Native uses the measured request contract and early endpoint-capacity planning. Source-ordered group cycle handling, bounded global ranks and ancestor routing preserve authored relationships and flow.
- The shared SVG pipeline reuses geometry, text, group and marker operands from their actual writes, bound to the submitted source, capture and written occurrence. Mutable inputs, inherited getters, replacement producers, callbacks, errors, CSS and definitions retain defensive handling.
- Browser dispatch loads the selected canonical Flow or State grammar. Generic parsing retains both. Heavy style schemas load through the existing provider; public schema copies remain fresh.
- Canonical role descriptors now freeze their nested bounds and enum arrays. Previously, borrowed exported references could lower the font-size minimum to zero or append an unknown text transform, causing validation and fresh JSON Schemas to accept the corrupted rules. Both mutations now fail and both invalid inputs reject. Caller StyleSpecs and schema copies remain mutable and isolated.
- Prepared-text data is branded reusable only when its supported prototype remains stable across sealing. Foreign source spans with accessors or custom prototypes retain their returned value but receive no immutable-data authority. Five reproduced failures pass after the fix; the supported null-prototype case remains accepted.
- Private paint-certificate reservation loops now charge a count in one step. Generic work callbacks remain unchanged; operation totals, partial-cap behavior and proof status are preserved.
- Role schema construction creates only applicable property schemas: 240 objects become 114. This removes discarded construction; no end-to-end CPU, payload or retained-memory improvement is claimed for it.

The broader Scene phase refactor was withdrawn: additional authority surfaces and adverse costs were not justified by its extra 1,038 gzip bytes of savings. The scalar-capture optimization was also withdrawn. Their source, negative controls and adverse measurements remain in recovery evidence.

## Verified results and remaining losses

| Metric | Result | Limitation or adverse cost |
| --- | --- | --- |
| Grouped delivery | 10→12/12 frozen replacement inputs; zero crossings, ELK also 12 | Original twelve inputs/image are lost. Illustrated ancestor repair adds 5.56% wire |
| Frozen Main913 comparison | Both return 116/124 portable and 194/198 authored; actual ink failures 2→0 by restoring Main’s omitted image | Raster proof remains unavailable; restored image needs area. ELK Requirement height +6 and nested Unicode Flow width +5 |
| Larger proof suite | 8→10/12 passed; Fan100 passes both engines | Chain300 remains unknown at 400,000 operations on both; caps unchanged |
| Native100 producer work | 270,326→238,786 proof operations | Counters are not CPU speedups; latency target remains open |
| Parser/schema extraction, c6fa vs 2f30 | Mixed payload −31,870 raw / −10,250 gzip / −8,797 Brotli bytes | Budgets still fail; runtime and memory results are mixed |
| State extraction, 9644 vs c6fa | Each engine −13,734 gzip / −12,491 Brotli bytes and one fewer request | Flow pays +309 gzip / +275 Brotli, requests unchanged |
| Role authority, final head vs 9644 | Public SDK corruption witness fixed; owning mutation test fails before and passes after | No visible layout or performance improvement claimed |
| Output qualification at fc4 vs 9644 | All 310 entire SVG/receipt products and 194 authored meaning/Chromium ink/quality vectors match; eight browser products match | Twelve unchanged errors retained. This validates unchanged output, not new visible coverage |
| Current mixed browser payload, at2525 CI | 2,514,987 raw / 782,452 gzip / 622,671 Brotli bytes | Exceeds caps by 84,987 / 20,952 / 4,671 bytes; +65 gzip / +71 Brotli versus31 |

At fc4, browser requests are unchanged from 9644. Post-GC heap changes range from −2,012 to +8,672 bytes across the four observed realms; there is no memory win to claim.

Historical losses remain enrolled: forest wire +16.89% with area −6.43%, Requirement area +9.53%, and implemented Sparse256 area +5.04%. The Sparse256 +0.97% candidate is unshipped. ER256 already passes eight backend/direction lanes; no ER repair is claimed. Original baseline2dad and equivalent pinned Mermaid12.2/Pele1.9 comparisons remain unavailable. Replacement24 stays sealed.

## Current shipping Native / ELK comparison

At `2525b91`, both engines use the same unmodified CI Node SDK, Node 24.19, identical 100-node chain input and cache disabled. Existing Trident runs three serial processes per engine; stock SVG and fully consumed SVG+receipt are separate protocols. Receipts confirm Native and ELK actually selected their requested engine, with no fallback.

| Measured boundary | Native | ELK |
| --- | ---: | ---: |
| Repeated stock SVG | 155.74 ms | Unavailable: worker failures |
| Fully consumed warm response | 163.27 ms | 277.76 ms |
| First full response, excluding import | 421.54 ms | 810.79 ms |
| First edited-source full response | 182.28 ms | 277.33 ms |
| Warm-response RSS | 112.00 MiB | 172.95 MiB |
| Transient after-render heap | 30.12 MiB | 56.09 MiB |

Response timings are medians of three process medians. All 54 full responses returned and all 27 proofs per engine passed within the unchanged 400,000-operation cap. Baseline SVGs are byte-identical across engines: 95,817 UTF8 bytes. Repeated whole SVGs and entire receipts are stable within each engine; edited sources change the SVG. This establishes equivalent consumed output for this input, with no new browser-ink or all-family correctness claim. RSS includes the harness and warmup; after-render heap is not retained memory.

**Native100 remains above 100 ms**: stock process medians are 162.66 / 155.74 / 145.04 ms. All three original ELK stock workers failed before producing completed evidence, coinciding with three cgroup OOM kills. One bounded retry also failed: signal 9, peak RSS 345.82 MiB, one further OOM kill. That arm is locally resource-blocked; no ELK stock timing or speedup ratio is claimed. The completed full-response measurements remain available.

These shipping-build measurements cannot establish a code gain against earlier custom builds. The earlier matched fc4→943 private-ledger experiment observed stock 138.58→124.82 ms and full response 182.77→157.62 ms, with an adverse first edit 194.06→214.29 ms; its complete evidence remains linked below. Later capture and XML variants were rejected after adverse results. Current measurements do not justify another representation rewrite; no cache or cap was added.

## Verification and recovery

The role fix passes its mutation regression, 57 other role/style/config checks and lint; the public schema remains exactly 22,561 bytes with unchanged order. Actual built SDK probes verify both corruption witnesses before and after. An editor-discovery child timeout reproduces on clean control as well as the fix; no timeout was raised. Final CI passes all three unit shards.

Current-head CI [43288474739](https://github.com/adewale/agentic-mermaid/actions/runs/43288474739) completed with **failure; the PR is not ready**. Lint, core/repository types, all three unit shards, canonical portable/Node/browser builds, browser E2E, semantic conformance and platform/installed-consumer checks passed. Browser/website/editor payload budgets and the generated-layout advisory failed.

The selector fix reproduces eight failures before the change and passes34 complete measured-layout owning tests/287assertions plus scoped lint after it. Scoped existing Trident source-Bun qualification returns60/60 products across six graph families, all three current backends and accepted fallbacks; all30 whole SVG and entire-receipt pairs match control31. This validates unchanged output. Local browser ink was not rerun; canonical browser E2E passed in CI. Local Node builds exhausted memory; the verified CI SDK was recovered for the shipping comparison above. No Native100 or payload improvement is claimed for the selector fix.

Previous31 CI [43257566068](https://github.com/adewale/agentic-mermaid/actions/runs/43257566068) completed with **failure; the PR is not ready**. Lint, core/repository types, all three unit shards, actual browser build, browser E2E and platform/consumer checks passed. Browser/website/editor payload budgets and the layout advisory failed. The prepared-part prerequisite passes187 prepared-text/Native owning checks and scoped lint on the clean final source, with five red→green failure witnesses and exact ASCII/Unicode/surrogate SVG controls. No new runtime measurement is claimed for31; its CI payload measurements are shown above.

Previous943 CI [43225853391](https://github.com/adewale/agentic-mermaid/actions/runs/43225853391) completed with failure. Lint, core/repository types, all three unit shards, actual browser build, browser E2E and platform/consumer checks passed. Browser/website/editor payload budgets and the layout advisory failed. Those checks qualify943 only. Its local Sparse32 timeout did not persist in CI; no timeout was changed.

Local browser builds exhausted cgroup/JavaScript heap limits; the subsequent normal CI build succeeded. Current2525 CI mixed payload is shown above. Demo payload is 826,543 raw / 315,769 gzip / 276,446 Brotli bytes against caps 788,000 / 302,500 / 276,000. Standalone editor gzip is 1,380,423 bytes against 1,334,500. The existing per-PR payload-growth check also fails across the families. No caps or approval labels were changed. The qualified Trident observers and943 timing workers are closed; the later actual-writer experiments were rejected and remain outside the source diff. Automations remain off.

Evidence includes commands, inputs, retained compiled artifacts, full outputs, clocks and profiles:

- [Dispatch fix, final2525 CI/package and rejected XML/group trials](https://github.com/adewale/agentic-mermaid/blob/2b255b39cec8760c1b823560e6a37c5c2e01b639/guard-group-recovery-20261112/REPORT.md): 747 files in two verified recovery archives; Trinity removal remains an unapplied proposal.
- [Prepared-part fix and three rejected actual-writer variants](https://github.com/adewale/agentic-mermaid/blob/517981c6aa6cf650e3c00e62abb848feab062f12/actual-write-rejections-20261112/REPORT.md): adverse timings retained; original v1 emitted bundle/maps were overwritten, with its source, outputs and mapped profiles preserved.
- [Rejected later trials, unadopted WIP and final943 CI](https://github.com/adewale/agentic-mermaid/blob/79bcbce9bc58c1e7a8868a00d679a4524bdc6a4a/rejected-trials-and-ci-20261112/REPORT.md)
- [Private-ledger source, 310-output Trident comparison and matched runtime costs](https://github.com/adewale/agentic-mermaid/blob/b85e5bc881fe5d59de90df71d5c7f4eb28779cc6/private-ledger-943-20261112/REPORT.md)
- [Final role fix, Trident qualification and withdrawn performance trials](https://github.com/adewale/agentic-mermaid/blob/4b24e930bc68420b6694b04072ef5b696e7205b1/role-authority-and-withdrawn-perf-20261112/REPORT.md)
- [Frozen Main comparison and five measured self/inclusive hotspots with cache inventory](https://github.com/adewale/agentic-mermaid/blob/f490974f6110ce235634da43ac82a02820315998/current-main-qualified-20261112/REPORT.md)
- [Parser/schema comparison and withdrawn broader refactor](https://github.com/adewale/agentic-mermaid/blob/ccc8b783e0851728b560b47d6f1e967980d196fe/minimal-parser-qualified-20261112/REPORT.md)
- [State extraction, full Trident and per-family costs](https://github.com/adewale/agentic-mermaid/blob/2a300fa133a1ce0e79dea8f615592b8b40d756c7/state-parser-qualified-20261112/REPORT.md)

## Visual evidence

Claim: the labelled ancestor entry/exit retain their authored relationships and A→B flow while removing two route crossings.

Input/fixture: `container-descendant-labelled` in [the fixed source set](https://github.com/adewale/agentic-mermaid/blob/8ec6299d2d1270c189e78c6d1ef79e1d66f3b9a9/native-blockers-checkpoint-20261110/REPLACEMENT-12.json), directionLR, nested Outer/Inner, Outer→A labelled enter, A→B, B→Outer labelled exit. Options/source are identical between arms; production SVG with Inter.

Baseline SHA: `7257faa9299a69948645a7574e185300b7841f75`.
Historical visual head SHA: `17f157fae6a6f97295ebb10f215d2c2326710b6b`.

Regenerate: extract `evidence.tar.gz`, replay the retained correctness collector, then `bun correctness-final/raster-ancestor.ts`. Resvg uses manifest-verified Inter, system fonts off,2× zoom. [Font manifest](https://github.com/adewale/agentic-mermaid/blob/8ec6299d2d1270c189e78c6d1ef79e1d66f3b9a9/native-blockers-checkpoint-20261110/RASTER-FONTS.json), [SVG/PNG/archive hashes](https://github.com/adewale/agentic-mermaid/blob/8ec6299d2d1270c189e78c6d1ef79e1d66f3b9a9/native-blockers-checkpoint-20261110/MANIFEST.json). Owning test: `ancestor-boundary-routes.test.ts`, “ancestor entry and exit preserve the inner chain without crossing”, allfour directions.

| Before | After |
| --- | --- |
| <img alt="Before: the ancestor entry descends across the exit and the inner A-to-B connection" src="https://raw.githubusercontent.com/adewale/agentic-mermaid/8ec6299d2d1270c189e78c6d1ef79e1d66f3b9a9/native-blockers-checkpoint-20261110/ancestor-before.png" width="380"> | <img alt="After: entry and exit use separate corridors and A-to-B stays directed right; wire increases 5.56 percent" src="https://raw.githubusercontent.com/adewale/agentic-mermaid/8ec6299d2d1270c189e78c6d1ef79e1d66f3b9a9/native-blockers-checkpoint-20261110/ancestor-after.png" width="380"> |

Limitation: these renders establish the enrolled fixture's crossing repair, with a wire cost. They do not recover the lost original image, prove every grouped graph correct or establish ELK replacement readiness.

