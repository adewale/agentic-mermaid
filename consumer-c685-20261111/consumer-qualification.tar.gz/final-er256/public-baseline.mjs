const entry = process.argv[2]; if (!entry) throw new Error('Pass the frozen final emitted entry');
const { renderMermaidSVGWithReceipt } = await import(entry)
import { createRequire } from 'node:module'
import { writeFileSync, readFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
const { JSDOM } = createRequire('/tmp/pr449-main-integration-20261029-762/package.json')('jsdom')
const out = new URL('./', import.meta.url).pathname
const sha = s => createHash('sha256').update(s).digest('hex')
const rows = []
for (const backend of ['agentic', 'elk']) for (const direction of ['TB', 'BT', 'LR', 'RL']) {
 const source = `erDiagram\ndirection ${direction}\n` + Array.from({length:255}, (_,i) => `N${i} ||--o{ N${i+1} : owns`).join('\n')
 const options = { embedFontImport: false, graphLayout: { backend, fallback: 'none' } }
 const row = { backend, direction, source, options, artifactSha256: sha(readFileSync(entry)) }
 try {
  const product = renderMermaidSVGWithReceipt(source, options)
  const encoded = JSON.stringify(product)
  row.svgSha256 = sha(product.svg); row.entireProductSha256 = sha(encoded); row.svgBytes = Buffer.byteLength(product.svg)
  writeFileSync(out + `${backend}-${direction}.product.json.gz`, gzipSync(encoded))
  const dom = new JSDOM(product.svg, {contentType:'image/svg+xml'})
  try {
   const doc=dom.window.document
   const entities=[...doc.querySelectorAll('.entity')]
   assert.deepEqual(entities.map(e=>e.getAttribute('data-id')), Array.from({length:256},(_,i)=>`N${i}`))
   assert.deepEqual(entities.map(e=>e.querySelector('text')?.textContent), Array.from({length:256},(_,i)=>`N${i}`))
   const relationships=[...doc.querySelectorAll('.er-relationship')]
   assert.deepEqual(relationships.map(e=>['data-from','data-to','data-cardinality1','data-cardinality2','data-identifying','data-label'].map(n=>e.getAttribute(n))),Array.from({length:255},(_,i)=>[`N${i}`,`N${i+1}`,'one','zero-many','true','owns']))
   assert.equal([...doc.querySelectorAll('text')].filter(e=>e.textContent==='owns').length,255)
   const glyphs=[...doc.querySelectorAll('[data-role="cardinality"]')]
   assert.equal(glyphs.length,510)
   row.entityCount=entities.length; row.relationshipCount=relationships.length;row.cardinalityCount=glyphs.length
   row.glyphPieceCounts={}
   for(const glyph of glyphs) {
    const pieces=[...glyph.querySelectorAll('line,path,circle,polyline')]
    assert.ok(pieces.length>0)
    for(const piece of pieces) { row.glyphPieceCounts[piece.tagName]=(row.glyphPieceCounts[piece.tagName]??0)+1; assert.ok(!piece.hasAttribute('display')||piece.getAttribute('display')!=='none') }
   }
  } finally {dom.window.close()}
  row.delivered=true;row.certification=product.receipt.layoutCertification;row.layoutDecisions=product.receipt.layoutDecisions
 } catch(error) { row.delivered=false; row.error={name:error.name,message:error.message,stack:error.stack} }
 rows.push(row); console.log(JSON.stringify({backend,direction,delivered:row.delivered,proof:row.certification?.status,error:row.error}))
 writeFileSync(out+'PUBLIC-BASELINE.json',JSON.stringify({sourceRevision:process.env.SOURCE_REVISION??'uncommitted-final-candidate',emittedEntry:entry,runtime:process.version,rows},null,2))
}
