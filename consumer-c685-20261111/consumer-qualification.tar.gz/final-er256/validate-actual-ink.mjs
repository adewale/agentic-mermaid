import {readFileSync,writeFileSync} from 'node:fs'
import {gunzipSync} from 'node:zlib'
import {createRequire} from 'node:module'
import assert from 'node:assert/strict'
const {JSDOM}=createRequire('/tmp/pr449-main-integration-20261029-762/package.json')('jsdom')
const out=new URL('./',import.meta.url).pathname, baseline=JSON.parse(readFileSync(out+'PUBLIC-BASELINE.json'))
const reports=[]
const n=(e,k)=>{const v=Number(e.getAttribute(k));assert.ok(Number.isFinite(v));return v}
const overlaps=(a,b)=>a.x0 < b.x1-1e-7 && a.x1>b.x0+1e-7 && a.y0<b.y1-1e-7 && a.y1>b.y0+1e-7
const box=(x0,y0,x1,y1)=>({x0,y0,x1,y1})
for (const row of baseline.rows) {
 const product=JSON.parse(gunzipSync(readFileSync(out+`${row.backend}-${row.direction}.product.json.gz`)))
 const dom=new JSDOM(product.svg,{contentType:'image/svg+xml'}), doc=dom.window.document
 const rects=[...doc.querySelectorAll('g.entity > rect')], cards=new Map(rects.map(e=>[e.getAttribute('data-id').slice(12),{x:n(e,'x'),y:n(e,'y'),width:n(e,'width'),height:n(e,'height'),half:n(e,'stroke-width')/2}]))
 const cardInk=[...cards].map(([id,c])=>({id,...box(c.x-c.half,c.y-c.half,c.x+c.width+c.half,c.y+c.height+c.half)}))
 const carriers=[...doc.querySelectorAll('.er-relationship')]
 const paths=carriers.map(e=>e.getAttribute('points').trim().split(/\s+/).map(p=>p.split(',').map(Number)))
 const normal=(p,q,c)=>Math.abs(p[0]-c.x)<1e-7&&q[0]<p[0]&&q[1]===p[1]||Math.abs(p[0]-c.x-c.width)<1e-7&&q[0]>p[0]&&q[1]===p[1]||Math.abs(p[1]-c.y)<1e-7&&q[1]<p[1]&&q[0]===p[0]||Math.abs(p[1]-c.y-c.height)<1e-7&&q[1]>p[1]&&q[0]===p[0]
 let normals=0, pieces=0
 const glyphs=[...doc.querySelectorAll('g[data-role="cardinality"]')].map((g,index)=>{
  const relationship=Math.floor(index/2),end=index%2,owner=carriers[relationship].getAttribute('data-id'),endpoint=`N${relationship+end}`
  assert.equal(g.getAttribute('data-owner-id'),owner); assert.equal(g.getAttribute('data-endpoint'),endpoint);assert.equal(g.getAttribute('data-end'),end?'end':'start')
  assert.equal(g.getAttribute('data-id'),`card:${owner.slice(4)}:${end+1}`)
  const children=[...g.children];assert.equal(children.length,end?4:2)
  assert.deepEqual(children.map(e=>e.localName),end?['line','line','line','circle']:['line','line'])
  const bounds=children.map(e=>{
   pieces++; assert.ok(n(e,'stroke-width')>0);assert.ok(e.getAttribute('stroke')!=='none')
   const h=n(e,'stroke-width')/2
   if(e.localName==='circle'){assert.ok(n(e,'r')>0);const r=n(e,'r')+h;return box(n(e,'cx')-r,n(e,'cy')-r,n(e,'cx')+r,n(e,'cy')+r)}
   const a=[n(e,'x1'),n(e,'y1')],b=[n(e,'x2'),n(e,'y2')],length=Math.hypot(b[0]-a[0],b[1]-a[1]);assert.ok(length>0)
   assert.ok(!e.hasAttribute('stroke-linecap')||e.getAttribute('stroke-linecap')==='butt')
   const nx=-(b[1]-a[1])/length*h,ny=(b[0]-a[0])/length*h
   return box(Math.min(a[0],b[0])-Math.abs(nx),Math.min(a[1],b[1])-Math.abs(ny),Math.max(a[0],b[0])+Math.abs(nx),Math.max(a[1],b[1])+Math.abs(ny))
  })
  return {relationship,bounds}
 })
 const shafts=[]
 for(let i=0;i<paths.length;i++){
  const path=paths[i],c=carriers[i];assert.ok(path.length>=2)
  assert.ok(normal(path[0],path[1],cards.get(`N${i}`)));assert.ok(normal(path.at(-1),path.at(-2),cards.get(`N${i+1}`)));normals+=2
  const h=n(c,'stroke-width')/2;assert.ok(h>0)
  for(let j=1;j<path.length;j++){
   const a=path[j-1],b=path[j];assert.ok(a.every(Number.isFinite)&&b.every(Number.isFinite));assert.ok(a[0]===b[0]||a[1]===b[1])
   const s=box(Math.min(a[0],b[0])-(a[0]===b[0]?h:0),Math.min(a[1],b[1])-(a[1]===b[1]?h:0),Math.max(a[0],b[0])+(a[0]===b[0]?h:0),Math.max(a[1],b[1])+(a[1]===b[1]?h:0))
   for(const card of cardInk)if(card.id!==`N${i}`&&card.id!==`N${i+1}`)assert.ok(!overlaps(s,card))
   shafts.push({relationship:i,...s})
  }
 }
 for(let i=0;i<glyphs.length;i++)for(const b of glyphs[i].bounds){
  for(const c of cardInk)assert.ok(!overlaps(b,c))
  for(let j=0;j<i;j++)for(const a of glyphs[j].bounds)assert.ok(!overlaps(b,a))
  for(const shaft of shafts)if(shaft.relationship!==glyphs[i].relationship)assert.ok(!overlaps(b,shaft))
 }
 const captions=[...doc.querySelectorAll('text')].filter(e=>e.textContent==='owns').map(e=>{const r=e.previousElementSibling;assert.equal(r.localName,'rect');const h=n(r,'stroke-width')/2;return box(n(r,'x')-h,n(r,'y')-h,n(r,'x')+n(r,'width')+h,n(r,'y')+n(r,'height')+h)})
 assert.equal(captions.length,255)
 for(let i=0;i<captions.length;i++){
  for(const c of cardInk)assert.ok(!overlaps(captions[i],c))
  for(const g of glyphs)for(const p of g.bounds)assert.ok(!overlaps(captions[i],p))
  for(let j=0;j<i;j++)assert.ok(!overlaps(captions[i],captions[j]))
  for(const s of shafts)if(s.relationship!==i)assert.ok(!overlaps(captions[i],s))
 }
 reports.push({backend:row.backend,direction:row.direction,svgSha256:row.svgSha256,entities:cards.size,normalContacts:normals,cardinalityCarriers:glyphs.length,physicalCardinalityPrimitives:pieces,clearCaptionPills:captions.length,nonownerShaftAndGlyphContact:false,proof:product.receipt.layoutCertification.status,proofOperations:product.receipt.layoutCertification.checks.operations,maxProofOperations:product.receipt.layoutCertification.checks.maxOperations})
 dom.window.close()
 console.log(JSON.stringify(reports.at(-1)))
}
writeFileSync(out+'ACTUAL-INK.json',JSON.stringify({scope:'Actual complete SVG primitive coordinates, stroke widths and ownership. Independent axis/butt-stroke envelopes; no runtime helper instrumentation.',limitations:['No whole-diagram font raster/readability claim.','Published proof work is separate from the internal ER geometry ledger; no geometry work count inferred.'],reports},null,2))
