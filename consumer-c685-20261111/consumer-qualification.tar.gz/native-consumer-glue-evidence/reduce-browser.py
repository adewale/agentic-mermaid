from pathlib import Path
import json,gzip,collections
b=Path('/dev/shm/pr449-four-final-20261111');out=b/'native-consumer-glue-evidence'
def compare(new,old,styled=False):
 n=json.load(open(b/new/'browser/RESULTS.json'));o=json.load(open(b/old/'browser/RESULTS.json'));rows=[]
 for r in n:
  key=lambda x:(x['family'],x['backend'],x.get('style'))
  a=next(x for x in o if key(x)==key(r));stem='candidate-'+r['backend']+('-'+r['style'] if styled else '');pn=b/new/'browser'/stem/r['family'];po=b/old/'browser'/stem/r['family'];products=[]
  for c in [1,2]:
   x=gzip.decompress((pn/f'call{c}.product.json.gz').read_bytes());y=gzip.decompress((po/f'call{c}.product.json.gz').read_bytes());xx=json.loads(x);yy=json.loads(y);px=xx['receipt'].get('layoutCertification');py=yy['receipt'].get('layoutCertification');xx['receipt'].pop('layoutCertification',None);yy['receipt'].pop('layoutCertification',None);products.append({'call':c,'wholeExact':x==y,'noncertExact':xx==yy,'proofExact':px==py,'proofStatus':(px or {}).get('status'),'proofChecks':(px or {}).get('checks')})
  h=lambda x:x.get('heap',{}).get('metrics',{}).get('jsHeapUsedBytes')
  rows.append({'family':r['family'],'backend':r['backend'],'style':r.get('style'),'status':r['status'],'baselineRequests':a['requests'],'requests':r['requests'],'delta':{**{k:r['product'][k]-a['product'][k] for k in ['raw','gzip9','brotli11']},'requests':r['requests']-a['requests'],'heap':h(r)-h(a) if h(r)!=None and h(a)!=None else None},'product':r['product'],'heap':h(r),'products':products,'observerErrors':r['observerErrors'],'error':r.get('error'),'remoteRequestsBlocked':r.get('remoteRequestsBlocked',[])})
 return rows
rows=compare('native-consumer-glue-browser','browser-marker-operand');styles=compare('native-consumer-glue-styled','browser-marker-operand-styled',True)
summary={'baseline':'30006080d71efd0eac1f6759449ad1333a048f92 actual retained frozen browser bytes','candidateManifest':str(out/'SOURCE.json'),'rows':rows,'styles':styles,'denominators':{'familyObservations':len(rows),'familyWholeProducts':sum(len(r['products']) for r in rows),'styleObservations':len(styles),'styleWholeProducts':sum(len(r['products']) for r in styles)},'wholeExact':sum(p['wholeExact'] for r in rows+styles for p in r['products']),'noncertExact':sum(p['noncertExact'] for r in rows+styles for p in r['products']),'proofExact':sum(p['proofExact'] for r in rows+styles for p in r['products']),'statusCounts':dict(collections.Counter(r['status'] for r in rows+styles)),'unknownHeap':sum(r['delta']['heap']==None for r in rows+styles),'remainingBudget':{'mixedForestElkYaml':{'raw':2526257,'gzip9':785071,'brotli11':625421},'caps':{'raw':2430000,'gzip9':761500,'brotli11':618000},'gzipGap':23571},'qualification':'Unchanged Tridentf080 full public WithReceipt protocol, mandatory support probe plus enrolled case, same family sources and real layout arms; offline gzip9/Br11 actual fetched module bytes; binding separate; heap JS not RSS; no API timing or full-meaning claim.'}
(out/'BROWSER-COMPARISON.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['rows','styles']},indent=2))
for backend in ['agentic','elk']:
 rs=[r for r in rows if r['backend']==backend];print(backend,{k:[min(r['delta'][k] for r in rs),max(r['delta'][k] for r in rs)] for k in ['raw','gzip9','brotli11','requests','heap']})
for r in styles:print('STYLE',r['style'],r['delta'])
