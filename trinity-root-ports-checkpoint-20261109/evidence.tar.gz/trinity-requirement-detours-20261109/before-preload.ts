import { plugin } from 'bun'
import { readFileSync } from 'node:fs'
const overrides = new Map(Object.entries(JSON.parse(readFileSync(import.meta.dir + '/BEFORE-OVERRIDES.json', 'utf8'))))
plugin({ name: 'exact-0597-before', setup(builder) {
  builder.onLoad({ filter: /(?:trinity|channel-tracks|agentic-layered-core)\.ts$/ }, args => {
    const file = overrides.get(args.path)
    if (file) return { contents: readFileSync(file, 'utf8'), loader: 'ts' }
  })
} })
