# Requirement detours: bounded port-allocation diagnosis

Source0597; read-only source and retained `trinity-trace.jsonl` inspection. No render, test, profile, new agent or production edit.

## Demonstrated first cause

The four non-loop edges have six written points/four bends each in the retained solved trace. Their occupied label lanes are x71.025,185.699,300.967,420.393. Trinity assigns centered, equally pitched endpoint offsets before coordinate placement (`src/layout/trinity.ts:216–222`), uses those offsets in the cross-coordinate sweeps (`:243–245`), then retains them when constructing channel steps and route points (`:269,:323`). There is no final projection of endpoint positions onto already available adjacent dummy lanes.

The first responsible choice is therefore endpoint allocation, not label measurement, body size or a later emitter repair. This specific fixture's existing physical face bounds leave room for the following counterfactual:

| Edge | Current endpoint x values, authored order | Same-face projected x values | Bend removal predicted from literal polyline geometry |
| --- | --- | --- | --- |
| suite→fast verifies | 121.362→219.021 | 71.025→93.04 | 2 |
| suite→fast traces | 135.362→236.021 | 185.699→185.699 | 4 |
| fast→report derives | 253.021→352.18 | 300.967→300.967 | 4 |
| report→fast satisfies | 369.18→270.021 | 420.393→396.002 | 2 |

All suite/report proposed ports fit their existing8px-margin faces. Fast's x extent is85.04..404.002, hence safe center interval93.04..396.002. Its four ordered targets retain more than the existing17px pitch. The outer two label lanes lie outside fast's allowed face and still require a jog; do not force them straight. The separate right-side loop remains unchanged with two bends. Thus18→6 bends is a geometry-only causal prediction under retained placements/tracks, **not an acquired final-product result**.

## Smallest justified trial

After cross coordinates are settled, project ordinary ordered ports toward the adjacent occupied dummy centers using the already established face margins and pitch. The existing Native scalar mechanism is `src/layout/agentic-layered-core.ts:714–720`: clamp the desired coordinate into its slot's feasible interval, then perform a forward minimum-separation pass. Reuse only this numeric operation, not Native's solver or completion pipeline.

A conservative initial scope is a rectangular/rounded face whose incident non-loop paths all have an adjacent private dummy (`paths[e][1]` or `paths[e].at(-2) >= n`). This fixture satisfies it. It avoids coupling directly adjacent real-node ports, touching the stopped fixed-dock forest strategy, or requiring a second endpoint fixed-point iteration. Faces with mixed direct/dummy neighbors can retain their existing allocation until separately justified; merely holding one peer's desired value does not guarantee a forward projection will leave that peer fixed.

Use `left = cross[node]+margin[node]`, `right = cross[node]+widths[node]-margin[node]`, `separation = pitch[node]`, and desired `cross[dummy]+widths[dummy]/2`. Preserve the current deterministic neighbor order/tie behavior. Store the result as an offset from the unchanged real-node center. Do not shrink the existing margin or pitch to obtain an improvement.

Extracting a tiny pure bounded ordered-coordinate helper is reasonable if both Native's existing branch and Trinity call it. The helper should accept numeric desired centers/bounds/separation, with no graph, style, callback or backend imports. Each caller owns its existing scratch/work charges. Native uses center-based coordinates whereas Trinity's `cross` is a left edge; normalize in the caller. Do not reuse `port-coordinate-placement.ts`: it moves vertices and invokes broader alignment search, exceeding this task.

## Placement caveat

There is a meaningful sequencing constraint. Updating endpoint offsets before `assignChannelTracks` (`trinity.ts:266–283`) retains cross coordinates and body dimensions, but can reduce channel heights and therefore change main-axis node and label positions. It is inaccurate to call that all-placement-preserving. If literal x/y equality is required for the causal trial, preserve the captured main/gap geometry as well. A shippable implementation must reconcile channel assignments with the new endpoint intervals; keeping stale channel constraints without checking the new routes is not a proof. Do not add a duplicate global repair/allocator pass merely to claim unchanged placement.

## Necessary disproofs

- **Physical support:** retain `margin` derived from rounded radius, node half-stroke and maximum incident endpoint half-support, and `pitch` derived from true oriented spans/global shaft envelope (`:142–151`). Native's8px default alone is not a substitute. Mixed widths and source containment markers remain adverse cases.
- **Feedback identity:** `backward` swaps which authored endpoint support belongs on the private face. Preserve the existing oriented arrays and final reversal (`:335`); do not reinterpret source offsets as always authored sources.
- **Ellipse and loops:** leave ellipse singleton offsets centered, since their contact projection assumes cardinal support. Leave loop ports/ordinal/stride untouched (`:313–319`); primary-face movement must not enter rounded corners adjacent to the loop side.
- **Caption ownership:** aim at the existing occupied dummy center, retaining its label dimensions and position. Do not move labels, pass through a foreign label, or treat labels as zero-size points. Existing foreign-body/label checks (`:339–373`) and final actual marker/halo proof remain mandatory.
- **Channels:** port movement changes interval overlap and possibly escape requirements. Check target escapes, terminal lead, route crossings and parallel identities after rebuilding the appropriate channel geometry; bends alone are insufficient.
- **Resources and value:** pay for projection/scratch through the existing ledger. Stop if a named improvement causes new refusal, P→U, visible contact, or a meaningful quality regression on a previously good product. No runtime saving follows from the bend prediction.

This is a narrow use of unused face capacity after immutable dummy placement, not a rerun of the stopped forest shortest-path, group ordering or broad port-aware coordinate trials.
