import { plugin } from 'bun'
import { readFileSync } from 'node:fs'
import { gunzipSync } from 'node:zlib'
const root = '/dev/shm/pr449-four-final-20261111/node-drawing-consumer-evidence/frozen-corrected/'
plugin({ name: 'retained-rejected-private-guards', setup(build) {
  build.onLoad({ filter: /node-drawing-consumer-pilot\/src\/(?:scene\/backend|graphical-render)\.ts$/ }, args => {
    const relative = args.path.split('/node-drawing-consumer-pilot/')[1]!
    return { loader: 'ts', contents: gunzipSync(readFileSync(root + relative + '.gz')).toString() }
  })
} })
