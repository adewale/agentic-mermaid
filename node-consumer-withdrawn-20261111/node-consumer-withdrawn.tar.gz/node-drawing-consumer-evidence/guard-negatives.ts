import assert from 'node:assert/strict'
const mode = process.argv[2]
const source = 'flowchart TD\n A --> B'
const options = { graphLayout: { backend: 'agentic', fallback: 'none' } }
let leakedClaims
if (mode === 'claims') {
  const freeze = Object.freeze
  Object.freeze = value => {
    if (Array.isArray(value) && value[0]?.target === 'backend:default') { leakedClaims = value; return value }
    return freeze(value)
  }
  try { await import(process.cwd() + '/src/scene/default-drawing-consumer.ts') }
  finally { Object.freeze = freeze }
  assert.ok(leakedClaims)
  assert.equal(Object.isFrozen(leakedClaims), false)
}
const api = await import(process.cwd() + '/src/index.ts')
const { DefaultBackend } = api
const expected = (mode === 'claims' ? api.createMermaidRenderer() : api).renderMermaidSVGWithReceipt(source, options)
assert.equal(expected.receipt.layoutCertification.status, 'passed')
let hits = 0, getterReads = 0
const sentinel = new Error('private guard observed caller hook')
if (mode === 'iterator' || mode === 'descriptor') {
  const iterator = Array.prototype[Symbol.iterator], descriptor = Object.getOwnPropertyDescriptor
  const fields = value => value.length === 4 && value[0] === 'id' && value[1] === 'capabilities' && value[2] === 'drawNode' && value[3] === 'render'
  const hookedOptions = { get graphLayout() {
    getterReads++
    if (mode === 'iterator') Array.prototype[Symbol.iterator] = function() {
      if (fields(this)) { hits++; throw sentinel }
      return Reflect.apply(iterator, this, [])
    }
    else Object.getOwnPropertyDescriptor = function(receiver, key) {
      if (receiver === DefaultBackend && (key === 'id' || key === 'capabilities' || key === 'drawNode' || key === 'render')) { hits++; throw sentinel }
      return descriptor(receiver, key)
    }
    return options.graphLayout
  } }
  try { assert.deepEqual(api.renderMermaidSVGWithReceipt(source, hookedOptions), expected) }
  finally { Array.prototype[Symbol.iterator] = iterator; Object.getOwnPropertyDescriptor = descriptor }
  assert.equal(getterReads, 1)
  assert.equal(hits, 0)
} else if (mode === 'inherited-selector') {
  const focused = await import(process.cwd() + '/src/svg-api.ts')
  const host = api.createMermaidRenderer()
  const focusedExpected = focused.renderMermaidSVGWithReceipt(source, options), hostExpected = host.renderMermaidSVGWithReceipt(source, options)
  Object.defineProperty(Object.prototype, 'drawingConsumer', { configurable: true, get() { hits++; throw sentinel } })
  try {
    assert.deepEqual(focused.renderMermaidSVGWithReceipt(source, options), focusedExpected)
    assert.deepEqual(host.renderMermaidSVGWithReceipt(source, options), hostExpected)
  } finally { delete Object.prototype.drawingConsumer }
  assert.equal(hits, 0)
} else if (mode === 'claims') {
  leakedClaims.length = 0
  assert.deepEqual(api.renderMermaidSVGWithReceipt(source, options), expected)
  const { isOriginalEnrolledDefaultBackend } = await import(process.cwd() + '/src/scene/backend.ts')
  if (process.env.ASSERT_CANDIDATE) assert.equal(isOriginalEnrolledDefaultBackend(DefaultBackend), false)
}
console.log(JSON.stringify({ mode, hits, getterReads, proof: expected.receipt.layoutCertification.status, wholeProductExact: true }))
