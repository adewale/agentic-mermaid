import assert from 'node:assert/strict'
Error.stackTraceLimit = 100
const rows=[],products=[]
for (const root of ['consumer-package-order-repair/candidate', 'node-drawing-consumer-pilot']) {
  const api=await import(`../${root}/src/index.ts`), {getFamily}=await import(`../${root}/src/agent/families.ts`),{sceneLowering,inheritNativeDrawing,nativeDrawingOf}=await import(`../${root}/src/scene/drawing.ts`)
  const lower=getFamily('sequence').lowerScene,original=nativeDrawingOf(lower),events=[]
  let phase='original',calls=0
  globalThis[Symbol.for('agentic-mermaid.performance-observer.v1')]=event=>{
    if(event.owner==='svg-inspection'&&event.detail==='final-security')events.push({phase,fixture:new Error().stack.includes('backend-conformance.ts')})
  }
  const source='sequenceDiagram\n ProducerA->>ProducerB: ownership interval'
  const warm=api.renderMermaidSVGWithReceipt(source)
  phase='changed'
  inheritNativeDrawing(sceneLowering((factory,context)=>{calls++;return original(factory,context)}),lower)
  const changed=api.renderMermaidSVGWithReceipt(source)
  delete globalThis[Symbol.for('agentic-mermaid.performance-observer.v1')]
  inheritNativeDrawing(sceneLowering(original),lower)
  assert.equal(calls,1)
  for(const phase of ['original','changed'])assert.equal(events.filter(x=>x.phase===phase&&!x.fixture).length,1)
  rows.push({root,events,calls});products.push(changed)
}
assert.deepEqual(products[0],products[1])
console.log(JSON.stringify({wholeChangedProductsExact:true,rows}))
