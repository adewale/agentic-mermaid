import { readFileSync, writeFileSync } from 'node:fs'
import { brotliCompressSync, constants } from 'node:zlib'
import { minifyBrowserRuntime } from './scripts/build/runtime-minify.ts'
const root='/tmp/pr449-week-comparison-20261101/standalone-payload-63a'; const input=readFileSync(`${root}/worker-bun.js`,'utf8');const start=performance.now();
const source=await minifyBrowserRuntime(input);const minifyMs=performance.now()-start;writeFileSync(`${root}/worker-swc.js`,source);
const packed=brotliCompressSync(source,{params:{[constants.BROTLI_PARAM_QUALITY]:11,[constants.BROTLI_PARAM_MODE]:constants.BROTLI_MODE_TEXT,[constants.BROTLI_PARAM_LGWIN]:22}});
const result={inputBytes:Buffer.byteLength(input),outputBytes:Buffer.byteLength(source),minifyMs,packedBytes:packed.length,wallMs:performance.now()-start};writeFileSync(`${root}/swc-probe.json`,JSON.stringify(result,null,2)+'\n');console.log(result);
