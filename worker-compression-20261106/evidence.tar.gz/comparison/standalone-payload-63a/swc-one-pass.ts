import { readFileSync, writeFileSync } from 'node:fs'
import { brotliCompressSync, constants } from 'node:zlib'
import { minifyBrowserRuntime } from '/tmp/pr449-main-integration-20261029-762/scripts/build/runtime-minify.ts'
const root='/tmp/pr449-week-comparison-20261101/standalone-payload-63a'; const input=readFileSync(`${root}/worker-bun.js`,'utf8');const start=performance.now();
const {minify}=await import('/workspace/agentic-mermaid/node_modules/@swc/core/index.js');const result=await minify(input,{ecma:2022,module:true,mangle:true,compress:{defaults:true,ecma:2022,toplevel:true,unsafe:false,pure_getters:false,keep_fargs:true,reduce_funcs:false,inline:3,passes:1},format:{comments:'some',inlineScript:true}});const source=result.code!;const minifyMs=performance.now()-start;writeFileSync(`${root}/worker-swc-one.js`,source);
const packed=brotliCompressSync(source,{params:{[constants.BROTLI_PARAM_QUALITY]:11,[constants.BROTLI_PARAM_MODE]:constants.BROTLI_MODE_TEXT,[constants.BROTLI_PARAM_LGWIN]:22}});
const metrics={inputBytes:Buffer.byteLength(input),outputBytes:Buffer.byteLength(source),minifyMs,packedBytes:packed.length,wallMs:performance.now()-start};writeFileSync(`${root}/swc-one-pass.json`,JSON.stringify(metrics,null,2)+'\n');console.log(metrics);
