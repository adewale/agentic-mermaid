import subprocess,time,resource,json,os,pathlib,gzip
repo=pathlib.Path('/tmp/pr449-main-integration-20261029-762');out=pathlib.Path(__file__).parent;entry=repo/'scripts/site/editor.ts';candidate=entry.read_bytes();control=subprocess.check_output(['git','show','HEAD:scripts/site/editor.ts'],cwd=repo)
rows=[]
try:
 for arm,data in [('control',control),('candidate',candidate)]:
  entry.write_bytes(data);start=time.monotonic();env=dict(os.environ,NODE_ENV='production',AGENTIC_MERMAID_SCENE_ASSERTIONS='0',AM_EDITOR_BUILD_METAFILE=str(out/(arm+'-metafile.json')))
  with open(out/(arm+'-paired-build.log'),'w') as log:
   p=subprocess.Popen(['/tmp/pr449-tools-20261106/package/bin/bun','run','scripts/site/editor.ts'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
   deadline=start+55;timedout=False
   while True:
    pid,status,usage=os.wait4(p.pid,os.WNOHANG)
    if pid:break
    if time.monotonic()>deadline:p.kill();timedout=True;pid,status,usage=os.wait4(p.pid,0);break
    time.sleep(.1)
   code=os.waitstatus_to_exitcode(status);p.returncode=code
  row={'arm':arm,'exitCode':code,'wallSeconds':time.monotonic()-start,'peakRssKiB':usage.ru_maxrss,'userCpuSeconds':usage.ru_utime,'systemCpuSeconds':usage.ru_stime,'timeout':timedout}
  rows.append(row)
  if code or timedout:raise RuntimeError(str(row))
  html=(repo/'editor.html').read_bytes();(out/(arm+'-production.html.gz')).write_bytes(gzip.compress(html))
finally:
 entry.write_bytes(candidate)
 (out/'paired-build-resource.json').write_text(json.dumps({'rows':rows,'sourceRestoredByteExact':entry.read_bytes()==candidate,'scope':'One complete production build per arm with same Bun1.4.4/deps/env. 55-second existing child deadline retained. No execution speed ratio.'},indent=2)+'\n')
print(rows)
