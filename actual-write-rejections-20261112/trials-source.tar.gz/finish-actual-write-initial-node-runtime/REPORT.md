# Actual-write rect/text slice v1 — rejected

Clean31 control and candidate use the same seven-entry/maps Node build; connector capture unchanged. New reduced writer removes full mark capture for100rectangles+100preparedtexts, but adds per-attribute dictionaries/pinning and metadata closure. Existing173writer/Nativeowners pass.

All27wholeSVGs exact. Receipt differences only operations238786→243586 (+4800); this is an adverse cap distribution, not proof progress. No broad cap/Trident qualification undertaken for this slower candidate.

Stock process repeat medians control149.58/156.62/140.29ms versus candidate165.44/162.32/176.15ms. Cold/full/edit distributions and RSS/heap in SUMMARY.json retain all adverse samples. This does not meet100ms. No performance ratio or causal gain is claimed.

Mapped200us profiler traces show new NativeLeafOperands pin/finish, projector close and root pin as added work; profiler inflates entire response heavily and its raw times are not unprofiled cost estimates. Next causal intervention: consume into private flat primitive storage, close once, reuse actual paint record; no expanded-mark walk and no repeated paint mapping/validation.

Not shipped. Actual-data-on-exhaustion correctness and v2 storage continue separately. CurrentPR31 remains unchanged.
