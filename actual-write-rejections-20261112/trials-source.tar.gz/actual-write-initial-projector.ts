import { decodeXML } from 'entities'
import type { ConnectorEndpoints, ConnectorMark, ConnectorRoute, Geometry, MarkPaint, SceneNode, SceneOwner, SceneRole, ShapeMark, TextMark } from './ir.ts'
import type { SvgWrittenNativeLeaf } from './svg-writer.ts'
import { isOwnedPixelTextPart } from '../shared/prepared-text.ts'
import { rectanglePaintFields } from './written-geometry.ts'
import { connectorContourSemantics } from './connector-geometry.ts'

// Only the first-party constructor consumer uses this projection. Scene/SDK
// callers retain their full defensive capture. Painted operands come from the
// actual writer; these small, independent metadata operands retain ownership.
export type NativeWrittenSource = ShapeMark | TextMark | ConnectorMark
interface BaseMetadata { readonly id: string; readonly role: SceneRole; readonly owner?: SceneOwner }
export type NativeWriteMetadata = { readonly kind: 'shape'; readonly base: BaseMetadata }
  | { readonly kind: 'text'; readonly base: BaseMetadata; readonly text: string; readonly textLayout: NonNullable<TextMark['textLayout']>; readonly display: TextMark['display']; readonly measurement: TextMark['measurement'] }
  | { readonly kind: 'connector'; readonly base: BaseMetadata; readonly lineStyle: ConnectorMark['lineStyle']; readonly endpoints: ConnectorEndpoints; readonly route: Omit<ConnectorRoute, 'geometry'>; readonly hit: Omit<ConnectorMark['hit'], 'geometry'>; readonly markers: ConnectorMark['markers'] }
const nativeDescriptor = Object.getOwnPropertyDescriptor, nativeOwn = Object.hasOwn
const nativeFreeze = Object.freeze, nativeKeys = Reflect.ownKeys, nativeExtensible = Object.isExtensible, nativeSame = Object.is
const nativePrototype = Object.getPrototypeOf, nativeDefine = Object.defineProperty
const unsupported = { __proto__: null }
type Pay = (count?: number) => boolean
function data(source: object, key: string): unknown {
  const field = nativeDescriptor(source, key)
  if (!field) { if (key in source) throw unsupported; return undefined }
  if (!nativeOwn(field, 'value')) throw unsupported
  return field.value
}
function string(source: object, key: string, optional = false): string | undefined {
  const value = data(source, key)
  if (optional && value === undefined) return undefined
  if (typeof value !== 'string') throw unsupported
  return value
}
function object(value: unknown): object {
  if (!value || typeof value !== 'object') throw unsupported
  return value
}
function close<T extends object>(value: T, pay: Pay): T {
  const prototype = nativePrototype(value), keys = nativeKeys(value)
  if (!pay(1) || !pay(keys.length * 2)) throw unsupported
  // Private literal expectations cannot be replaced by a sealing callback.
  const expected = { __proto__: null } as Record<PropertyKey, unknown>
  for (let index = 0; index < keys.length; index++) {
    const key = keys[index]!, field = nativeDescriptor(value, key)
    if (!field || !nativeOwn(field, 'value')) throw unsupported
    expected[key] = field.value
  }
  if (nativeFreeze(value) !== value || nativeExtensible(value) || nativePrototype(value) !== prototype) throw unsupported
  const closedKeys = nativeKeys(value)
  if (closedKeys.length !== keys.length) throw unsupported
  for (let index = 0; index < keys.length; index++) {
    const key = keys[index]!, field = nativeDescriptor(value, key)
    if (closedKeys[index] !== key || !field || !nativeOwn(field, 'value') || field.writable || field.configurable || !nativeSame(field.value, expected[key])) throw unsupported
  }
  return value
}
function owner(value: unknown, pay: Pay): SceneOwner | undefined {
  if (value === undefined) return undefined
  const input = object(value), id = string(input, 'id')!, role = string(input, 'role')! as SceneRole
  return close({ id, role }, pay)
}
function point(value: unknown, pay: Pay): { x: number; y: number } | undefined {
  if (value === undefined) return undefined
  const input = object(value), x = data(input, 'x'), y = data(input, 'y')
  if (typeof x !== 'number' || typeof y !== 'number') throw unsupported
  return close({ x, y }, pay)
}
function endpoint(value: unknown, pay: Pay): ConnectorEndpoints['start'] {
  if (value === undefined) return undefined
  const input = object(value), id = string(input, 'id', true), portId = string(input, 'portId', true), own = owner(data(input, 'owner'), pay), at = point(data(input, 'point'), pay)
  return close({ ...(at ? { point: at } : {}), ...(id === undefined ? {} : { id }), ...(portId === undefined ? {} : { portId }), ...(own ? { owner: own } : {}) }, pay)
}
function empty(value: unknown, pay: Pay): readonly [] {
  const input = object(value), length = data(input, 'length')
  if (!Array.isArray(input) || length !== 0 || nativeKeys(input).length !== 1) throw unsupported
  return close([], pay) as readonly []
}
function absent(source: object, keys: readonly string[]): void { for (let index = 0; index < keys.length; index++) if (data(source, keys[index]!) !== undefined) throw unsupported }

/** Read only the narrow first-party domain before choosing the actual writer.
 * Unsupported shapes/features keep their original defensive write, so a failed
 * post-write receipt never causes another serialization of mutable inputs. */
export function captureNativeWriteMetadata(source: NativeWrittenSource, markerOwned: (marker: object) => boolean, pay: Pay): NativeWriteMetadata | undefined {
  try {
    absent(source, ['channels', 'transform', 'visibility', 'conditionalPaint', 'surfaceFragment', 'childPaints'])
    const base = (): BaseMetadata => {
      const id = string(source, 'id')!, role = string(source, 'role')! as SceneRole, own = owner(data(source, 'owner'), pay)
      return close({ id, role, ...(own ? { owner: own } : {}) }, pay)
    }
    if (source.kind === 'shape') {
      const geometry = object(data(source, 'geometry'))
      if (data(geometry, 'kind') !== 'rect') return undefined
      const rx = data(geometry, 'rx'), ry = data(geometry, 'ry')
      if (rx !== undefined && rx !== 0 || ry !== undefined && ry !== 0) return undefined
      return { kind: 'shape', base: base() }
    }
    if (source.kind === 'text') {
      absent(source, ['spans', 'dominantBaseline', 'fontStyle', 'textDecoration'])
      const block = object(data(source, 'block')) as NonNullable<TextMark['block']>
      if (!isOwnedPixelTextPart(block) || block.lineBlocks.length !== 1 || data(source, 'measurement') !== 'prepared') return undefined
      const layout = object(data(source, 'textLayout'))
      const width = data(layout, 'width'), height = data(layout, 'height'), lineHeight = data(layout, 'lineHeight'), offsetY = data(layout, 'offsetY')
      if (typeof width !== 'number' || typeof height !== 'number' || typeof lineHeight !== 'number' || typeof offsetY !== 'number') return undefined
      const textLayout = close({ width, height, lineHeight, offsetY }, pay)
      const display = data(source, 'display') as TextMark['display']
      return { kind: 'text', base: base(), text: string(source, 'text')!, textLayout, display, measurement: 'prepared' }
    }
    absent(object(data(source, 'stroke')), ['mixBlendMode', 'encodesValue'])
    const route = object(data(source, 'route')), geometry = object(data(route, 'geometry'))
    const kind = data(geometry, 'kind')
    if (kind !== 'line' && kind !== 'polyline' || data(route, 'closed') !== false || data(source, 'lineStyle') === 'invisible') return undefined
    empty(data(source, 'labels'), pay)
    const markers = object(data(source, 'markers')), mid = empty(data(markers, 'mid'), pay)
    const start = data(markers, 'start') as ConnectorMark['markers']['start'], end = data(markers, 'end') as ConnectorMark['markers']['end']
    if (start && !markerOwned(start) || end && !markerOwned(end)) return undefined
    const endpoints = object(data(source, 'endpoints')), from = string(endpoints, 'from', true), to = string(endpoints, 'to', true)
    const startEndpoint = endpoint(data(endpoints, 'start'), pay), endEndpoint = endpoint(data(endpoints, 'end'), pay)
    const closedEndpoints = close({ ...(from === undefined ? {} : { from }), ...(to === undefined ? {} : { to }), ...(startEndpoint ? { start: startEndpoint } : {}), ...(endEndpoint ? { end: endEndpoint } : {}) }, pay)
    const labelAnchors = empty(data(route, 'labelAnchors'), pay)
    const contours = object(data(route, 'contours')) as ConnectorRoute['contours']
    if (!Array.isArray(contours) || data(contours, 'length') !== 1) return undefined
    const contour = object(data(contours, '0')), contourStart = point(data(contour, 'start'), pay)!, contourEnd = point(data(contour, 'end'), pay)!
    const startTangent = point(data(contour, 'startTangent'), pay), endTangent = point(data(contour, 'endTangent'), pay)
    const closedContour = close({ start: contourStart, end: contourEnd, closed: data(contour, 'closed') as boolean, ...(startTangent ? { startTangent } : {}), ...(endTangent ? { endTangent } : {}) }, pay)
    const closedContours = close([closedContour], pay)
    const rawStartTangent = point(data(route, 'startTangent'), pay), rawEndTangent = point(data(route, 'endTangent'), pay)
    const ownership = string(route, 'ownership')! as ConnectorRoute['ownership'], bendRadius = data(route, 'bendRadius')
    if (typeof bendRadius !== 'number') return undefined
    const routeMetadata = close({ ownership, closed: false, bendRadius, contours: closedContours, labelAnchors, ...(rawStartTangent ? { startTangent: rawStartTangent } : {}), ...(rawEndTangent ? { endTangent: rawEndTangent } : {}) }, pay)
    const hit = object(data(source, 'hit'))
    if (data(hit, 'geometry') !== geometry || data(hit, 'closed') !== false) return undefined
    const strokeWidth = data(hit, 'strokeWidth'), pointerEvents = data(hit, 'pointerEvents') as ConnectorMark['hit']['pointerEvents']
    if (typeof strokeWidth !== 'number') return undefined
    return { kind: 'connector', base: base(), lineStyle: string(source, 'lineStyle')! as ConnectorMark['lineStyle'], endpoints: closedEndpoints, route: routeMetadata,
      hit: close({ closed: false, strokeWidth, pointerEvents }, pay), markers: close({ ...(start ? { start } : {}), mid, ...(end ? { end } : {}) }, pay) }
  } catch { return undefined }
}

const paintNames = ['fill', 'fillOpacity', 'stroke', 'strokeOpacity', 'strokeWidth', 'strokeDasharray', 'strokeDashoffset', 'strokeLinecap', 'strokeLinejoin', 'strokeMiterlimit', 'vectorEffect', 'paintOrder', 'opacity'] as const
function painted(attributes: Readonly<Record<string, string>>, pay: Pay): MarkPaint {
  const paint = { __proto__: null } as MarkPaint
  for (let index = 0; index < paintNames.length; index++) {
    const field = paintNames[index]!, literal = attributes[rectanglePaintFields[field].attribute]
    if (literal !== undefined) paint[field] = literal
  }
  return close(paint, pay)
}
function baseNode(metadata: NativeWriteMetadata, written: SvgWrittenNativeLeaf, pay: Pay) {
  const attributes = written.attributes
  const identity = attributes['data-id'] === undefined ? undefined : close({ id: attributes['data-id']!, role: attributes['data-role'] as SceneRole,
    ...(attributes['data-from'] === undefined ? {} : { from: attributes['data-from'] }), ...(attributes['data-to'] === undefined ? {} : { to: attributes['data-to'] }) }, pay)
  const dataAttributes = { __proto__: null } as Record<string, string>
  const keys = nativeKeys(attributes)
  for (let index = 0; index < keys.length; index++) {
    const key = keys[index]!
    if (typeof key === 'string' && key.startsWith('data-') && !['data-id','data-role','data-from','data-to','data-relationship','data-direction','data-prepared-text','data-font-metrics'].includes(key)) dataAttributes[key.slice(5)] = attributes[key]!
  }
  close(dataAttributes, pay)
  const hooks = close({ ...(attributes.class === undefined ? {} : { className: attributes.class }), ...(nativeKeys(dataAttributes).length ? { data: dataAttributes } : {}),
    ...(attributes['aria-hidden'] === undefined ? {} : { ariaHidden: attributes['aria-hidden'] === 'true' as true }), ...(attributes.tabindex === undefined ? {} : { tabIndex: 0 as const }), ...(attributes['aria-label'] === undefined ? {} : { ariaLabel: attributes['aria-label'] }) }, pay)
  return { ...metadata.base, ...(identity ? { identity } : {}), attributes: hooks }
}
export interface NativeWrittenProjection { readonly validationNode: NativeWrittenSource; readonly paintNode: NativeWrittenSource; readonly conditional: boolean }
export function projectNativeWrittenLeaf(metadata: NativeWriteMetadata, written: SvgWrittenNativeLeaf, pay: Pay): NativeWrittenProjection | undefined {
  try {
    if (written.kind !== metadata.kind) return undefined
    const writtenKeys = nativeKeys(written.attributes)
    for (let index = 0; index < writtenKeys.length; index++) {
      const key = writtenKeys[index]!
      if (typeof key !== 'string') return undefined
      const literal = written.attributes[key], escaped = written.escapedAttributes[key]
      if (typeof literal !== 'string' || typeof escaped !== 'string' || escaped !== literal && decodeXML(escaped) !== literal) return undefined
    }
    const base = baseNode(metadata, written, pay), attributes = written.attributes
    if (metadata.kind === 'shape') {
      if (written.geometry?.kind !== 'rect' || written.rawGeometry?.kind !== 'rect') return undefined
      const paint = painted(attributes, pay)
      const validationNode = close({ kind: 'shape' as const, ...base, geometry: written.rawGeometry, paint }, pay)
      const paintNode = close({ ...validationNode, geometry: written.geometry }, pay)
      return { validationNode, paintNode, conditional: !(written.geometry.width > 0 && written.geometry.height > 0) }
    }
    if (metadata.kind === 'text') {
      const prepared = written.prepared
      if (!prepared) return undefined
      const node = close({ kind: 'text' as const, ...base, text: metadata.text, paint: painted(attributes,pay), x: prepared.x, y: prepared.y, fontSize: prepared.fontSize,
        fontWeight: written.numericAttributes['font-weight'] ?? prepared.block.fontWeight, letterSpacing: written.numericAttributes['letter-spacing'] ?? 0,
        display: metadata.display, measurement: metadata.measurement, block: prepared.block, anchor: prepared.anchor as TextMark['anchor'], baselineShift: prepared.baselineShift,
        textLayout: metadata.textLayout, prepared: true }, pay)
      return { validationNode: node, paintNode: node, conditional: written.numericAttributes['font-size'] !== prepared.fontSize || (attributes['text-anchor'] ?? 'middle') !== prepared.anchor }
    }
    const geometry = written.geometry, rawGeometry = written.rawGeometry
    if (!geometry || !rawGeometry || (geometry.kind !== 'line' && geometry.kind !== 'polyline') || (rawGeometry.kind !== 'line' && rawGeometry.kind !== 'polyline')) return undefined
    for (const position of ['start','end'] as const) {
      const marker = metadata.markers[position], actual = attributes[`marker-${position}`]
      if ((marker ? `url(#${marker.id})` : undefined) !== actual) return undefined
    }
    const stroke = close({ color: attributes.stroke!, width: attributes['stroke-width']!, lineCap: (attributes['stroke-linecap'] ?? 'butt') as ConnectorMark['stroke']['lineCap'],
      lineJoin: (attributes['stroke-linejoin'] ?? 'miter') as ConnectorMark['stroke']['lineJoin'], miterLimit: written.numericAttributes['stroke-miterlimit'] ?? 4,
      nonScaling: attributes['vector-effect'] === 'non-scaling-stroke', ...(attributes['stroke-opacity'] === undefined ? {} : { opacity: attributes['stroke-opacity'] }),
      ...(attributes['stroke-dasharray'] === undefined ? {} : { dash: close({ array: attributes['stroke-dasharray'], ...(attributes['stroke-dashoffset'] === undefined ? {} : { offset: attributes['stroke-dashoffset'] }) }, pay) }),
      ...(attributes.pathLength === undefined ? {} : { pathLength: attributes.pathLength }), ...(attributes['paint-order'] === undefined ? {} : { paintOrder: attributes['paint-order'] }) }, pay)
    const relationship = close({ kind: attributes['data-relationship']!, direction: attributes['data-direction'] as ConnectorMark['relationship']['direction'] }, pay)
    const route = close({ ...metadata.route, geometry: rawGeometry }, pay), hit = close({ ...metadata.hit, pointerEvents: attributes['pointer-events'] === 'none' ? 'none' as const : 'stroke' as const, geometry: rawGeometry }, pay)
    const node = { kind: 'connector' as const, ...base, lineStyle: metadata.lineStyle, endpoints: metadata.endpoints, route, stroke, markers: metadata.markers, relationship,
      hit, labels: close([], pay), terminalProjection: undefined as unknown as ConnectorMark['terminalProjection'] }
    // The existing registered deferred getter retains the independent semantic
    // contract; the original first-party constructor supplies it during admission.
    const validationNode = close(node as ConnectorMark, pay)
    const contours = written.projection?.contours ?? connectorContourSemantics(geometry, false)
    if (!written.projection) for (let index = 0; index < contours.length; index++) {
      const contour = contours[index]!
      close(contour.start, pay); close(contour.end, pay)
      if (contour.startTangent) close(contour.startTangent, pay)
      if (contour.endTangent) close(contour.endTangent, pay)
      close(contour, pay)
    }
    const paintRoute = close({ ...route, geometry, contours: written.projection ? contours : close(contours, pay), startTangent: contours[0]?.startTangent, endTangent: contours[contours.length-1]?.endTangent }, pay)
    const paintNode = close({ ...node, route: paintRoute }, pay)
    return { validationNode, paintNode, conditional: contours.length === 0 || !contours[0]?.startTangent }
  } catch { return undefined }
}

/** Bind the completed write operands to the SAME private constructor node.
 * No raw descendant survives for later inspection and no mutable input is
 * reread after the actual write. Public marks never call this consumer. */
export function retainNativeWrittenSource(source: NativeWrittenSource, painted: NativeWrittenSource, pay: Pay): boolean {
  try {
    const prototype = nativePrototype(source), keys = nativeKeys(painted)
    if (!pay(keys.length * 2 + 4)) return false
    const original = nativeKeys(source)
    for (let index = 0; index < original.length; index++) {
      const key = original[index]!
      if (!nativeOwn(painted, key) && !Reflect.deleteProperty(source, key)) return false
    }
    for (let index = 0; index < keys.length; index++) {
      const key = keys[index]!, field = nativeDescriptor(painted, key)
      if (!field || !nativeOwn(field, 'value')) return false
      nativeDefine(source, key, { __proto__: null, value: field.value, enumerable: field.enumerable, writable: false, configurable: false } as PropertyDescriptor)
    }
    if (nativeFreeze(source) !== source || nativeExtensible(source) || nativePrototype(source) !== prototype) return false
    const actual = nativeKeys(source)
    if (actual.length !== keys.length) return false
    for (let index = 0; index < keys.length; index++) {
      const key = keys[index]!, field = nativeDescriptor(source, key), expected = nativeDescriptor(painted, key)
      if (!nativeOwn(source, key) || !field || !expected || !nativeOwn(field, 'value') || field.writable || field.configurable || !nativeSame(field.value, expected.value)) return false
    }
    return true
  } catch { return false }
}
