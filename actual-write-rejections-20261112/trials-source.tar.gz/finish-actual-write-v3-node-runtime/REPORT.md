# Actual-write single-node rect/text slice v3 — rejected

Clean31 matching seven-entry/maps Node control. Stock process repeat medians171.47/144.06/128.92ms control versus147.79/198.26/150.35ms candidate; freshsource113.21/111.37/108.57 versus112.15/122.88/105.17ms. Mixed/adverse,100ms unmet. No performance ratio or causal win. All27wholeSVGs exact; raw receipt delta comparison plusfull/cold/edit/resources retained in SUMMARY.json/rawworkers.

This version removes validationNode+paintNode+sourcepin: the same existing writer occurrence owns one closed node consumed by bothvalidation andinspection; originalsource only bindswrite. No extraauthoritymap. Partial rect/text construction still has not repaidcost. Stop this hypothesis; no sourceadoption/broadTrident.

Postmeasurement owner found closeddata/funded is insufficient for XMLproof. Genuine NULLid can yield closednode/fundedtrue/conditionalfalse yetactualleafXMLclosefalse.18assertsP coverfix using existing private actualwriterbinding+XMLcomplete/check, data remainsavailable. This is a proofgatecounterexample, not a reproducedpublicfalsePASS. FixedWIP is not the measuredartifact.

Exact measuredv3 emittedfiles retained ../actual-write-v3-original-dist. Current sourceWIP/sourcepatch also retained; no claimits changed XMLgate was benchmarked.
