import config from './tsup.config.ts'
export default { ...config, entry: Object.fromEntries(Object.entries(config.entry).filter(([key]) => ['index','agent-core','elk-constructor','builtin-font-metrics','builtin-font-metrics.node','layout-optimization','layout-optimization.node'].includes(key))), dts: false }
