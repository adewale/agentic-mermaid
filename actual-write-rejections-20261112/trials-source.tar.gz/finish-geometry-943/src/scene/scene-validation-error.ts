/** Shared identity for lightweight actual-write and full Scene failures. */
export type SceneValidationDiagnosticCode =
  | 'SCENE_DOCUMENT'
  | 'SCENE_FINITE'
  | 'SCENE_BOUNDS'
  | 'SCENE_ID'
  | 'SCENE_ROLE'
  | 'SCENE_PAINT'
  | 'SCENE_MARKER'
  | 'SCENE_REFERENCE'
  | 'SCENE_SECURITY'
  | 'SCENE_FIDELITY'
  | 'SCENE_PRIMITIVE_CLAIM'
  | 'SCENE_CHANNEL_CLAIM'

export interface SceneValidationDiagnostic {
  readonly code: SceneValidationDiagnosticCode
  readonly path: string
  readonly message: string
}


export class SceneValidationError extends Error {
  readonly code = 'SCENE_VALIDATION_FAILED'

  constructor(readonly diagnostics: readonly SceneValidationDiagnostic[]) {
    super(`Scene validation failed: ${diagnostics.map(item => `${item.path}: ${item.message}`).join('; ')}`)
    this.name = 'SceneValidationError'
  }
}

