import { SCENE_VALIDATION_LIMITS } from './scene-validation-limits.ts'
import type { SceneValidationDiagnostic } from './scene-validation-error.ts'
const MAX_SCENE_EXTENT = SCENE_VALIDATION_LIMITS.maxExtent

/** The canonical scalar geometry/typography admission, shared with actual writes. */
export function finiteSceneNumber(
  value: unknown,
  path: string,
  diagnostics: SceneValidationDiagnostic[],
  options: { positive?: boolean; nonNegative?: boolean } = {},
): value is number {
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    diagnostics.push({ code: 'SCENE_FINITE', path, message: 'must be a finite number' })
    return false
  }
  if (options.positive && value <= 0) diagnostics.push({ code: 'SCENE_BOUNDS', path, message: 'must be positive' })
  if (options.nonNegative && value < 0) diagnostics.push({ code: 'SCENE_BOUNDS', path, message: 'must be non-negative' })
  if (Math.abs(value) > MAX_SCENE_EXTENT) diagnostics.push({ code: 'SCENE_BOUNDS', path, message: `must not exceed ${MAX_SCENE_EXTENT} user units` })
  return true
}

