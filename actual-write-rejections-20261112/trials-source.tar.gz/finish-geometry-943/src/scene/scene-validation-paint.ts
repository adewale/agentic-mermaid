import { safeCssPaint } from '../shared/css-color.ts'
import type { SceneValidationDiagnostic, SceneValidationDiagnosticCode } from './scene-validation-error.ts'
export const SAFE_DASH = /^(?:none|[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?(?:[\s,]+[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)*)$/
export const NUMERIC_CSS_LENGTH = /^([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)(?:px)?$/
export const NUMERIC_CSS_VALUE = /^([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)$/
export const NUMERIC_CSS_REFERENCE = /^var\(--[a-z0-9_-]+(?:,\s*[-+]?\d*\.?\d+)?\)$/i
const PAINT_FIELDS = [
  'fill', 'stroke', 'strokeWidth', 'strokeDasharray', 'strokeDashoffset',
  'strokeLinecap', 'strokeLinejoin', 'strokeMiterlimit', 'vectorEffect',
  'paintOrder', 'opacity',
] as const

type MutableDiagnostic = SceneValidationDiagnostic
function record(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
function add(diagnostics: MutableDiagnostic[], code: SceneValidationDiagnosticCode, path: string, message: string): void {
  diagnostics.push({ code, path, message })
}
function rejectUnknownKeys(value: Record<string, unknown>, allowed: readonly string[], path: string, diagnostics: MutableDiagnostic[]): void {
  const allow = new Set(allowed)
  for (const key of Object.keys(value)) {
    if (!allow.has(key)) add(diagnostics, 'SCENE_DOCUMENT', `${path}.${key}`, 'is not part of the external Scene contract')
  }
}
export function numericCss(
  value: unknown,
  path: string,
  diagnostics: MutableDiagnostic[],
  options: { nonNegative?: boolean; unitInterval?: boolean; length?: boolean } = {},
): void {
  if (value === undefined) return
  if (typeof value !== 'string' && typeof value !== 'number') {
    add(diagnostics, 'SCENE_PAINT', path, 'must be a finite numeric value')
    return
  }
  const text = typeof value === 'string' ? value.trim() : undefined
  const numericMatch = text?.match(options.length ? NUMERIC_CSS_LENGTH : NUMERIC_CSS_VALUE)
  const parsed = typeof value === 'number' ? value : numericMatch ? Number(numericMatch[1]) : Number.NaN
  if (!Number.isFinite(parsed)) {
    if (typeof value === 'string' && NUMERIC_CSS_REFERENCE.test(value.trim())) return
    add(diagnostics, 'SCENE_PAINT', path, `must be a finite number or safe numeric custom-property reference (received ${JSON.stringify(value)})`)
  } else if (options.nonNegative && parsed < 0) {
    add(diagnostics, 'SCENE_PAINT', path, 'must be non-negative')
  } else if (options.unitInterval && (parsed < 0 || parsed > 1)) {
    add(diagnostics, 'SCENE_PAINT', path, 'must be in [0,1]')
  }
}

export function validatePaint(
  value: unknown,
  path: string,
  diagnostics: MutableDiagnostic[],
  external = false,
): void {
  if (!record(value)) {
    add(diagnostics, 'SCENE_PAINT', path, 'must be a paint object')
    return
  }
  if (external) rejectUnknownKeys(value, PAINT_FIELDS, path, diagnostics)
  for (const key of ['fill', 'stroke'] as const) {
    const paint = value[key]
    const localResource = localPaintResourceId(paint)
    if (paint !== undefined && safeCssPaint(paint) === undefined && (external || !localResource)) {
      add(diagnostics, 'SCENE_PAINT', `${path}.${key}`, 'must be a safe non-fetching CSS paint')
    }
  }
  numericCss(value.strokeWidth, `${path}.strokeWidth`, diagnostics, { nonNegative: true, length: true })
  numericCss(value.strokeDashoffset, `${path}.strokeDashoffset`, diagnostics, { length: true })
  numericCss(value.strokeMiterlimit, `${path}.strokeMiterlimit`, diagnostics, { nonNegative: true })
  numericCss(value.opacity, `${path}.opacity`, diagnostics, { unitInterval: true })
  numericCss(value.fillOpacity, `${path}.fillOpacity`, diagnostics, { unitInterval: true })
  numericCss(value.strokeOpacity, `${path}.strokeOpacity`, diagnostics, { unitInterval: true })
  if (value.strokeDasharray !== undefined && (typeof value.strokeDasharray !== 'string' || !SAFE_DASH.test(value.strokeDasharray.trim()))) {
    add(diagnostics, 'SCENE_PAINT', `${path}.strokeDasharray`, 'must be "none" or a finite numeric dash list')
  }
  if (value.strokeLinecap !== undefined && !['butt', 'round', 'square'].includes(String(value.strokeLinecap))) {
    add(diagnostics, 'SCENE_PAINT', `${path}.strokeLinecap`, 'must be butt, round, or square')
  }
  if (value.strokeLinejoin !== undefined && !['arcs', 'bevel', 'miter', 'miter-clip', 'round'].includes(String(value.strokeLinejoin))) {
    add(diagnostics, 'SCENE_PAINT', `${path}.strokeLinejoin`, 'must be arcs, bevel, miter, miter-clip, or round')
  }
  if (value.vectorEffect !== undefined && !['none', 'non-scaling-stroke'].includes(String(value.vectorEffect))) {
    add(diagnostics, 'SCENE_PAINT', `${path}.vectorEffect`, 'must be none or non-scaling-stroke')
  }
  if (value.paintOrder !== undefined) {
    const tokens = typeof value.paintOrder === 'string'
      ? value.paintOrder.trim().split(/\s+/).filter(Boolean).map(token => token.toLowerCase())
      : []
    const valid = (tokens.length === 1 && tokens[0] === 'normal')
      || (tokens.length >= 1
        && tokens.length <= 3
        && new Set(tokens).size === tokens.length
        && tokens.every(token => ['fill', 'stroke', 'markers'].includes(token)))
    if (!valid) add(diagnostics, 'SCENE_PAINT', `${path}.paintOrder`, 'must be normal or one to three unique fill, stroke, and markers keywords')
  }
}

export function localPaintResourceId(value: unknown): string | undefined {
  const match = typeof value === 'string'
    ? /^url\(#([A-Za-z_][A-Za-z0-9_.:-]*)\)$/.exec(value.trim())
    : null
  return match?.[1]
}

