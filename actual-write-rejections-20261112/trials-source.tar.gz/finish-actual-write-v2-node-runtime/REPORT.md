# Actual-write rect/text flat-data slice v2 — rejected

Clean31 matching seven-entry/maps Node control. Stock process repeat medians149.59/150.74/119.98ms control versus165.66/513.21/159.50ms candidate; middle-process adverse spike retained. Full/cold/edit distributions in raw outputs likewise give no target benefit. No performance ratio or causal win claimed. All27SVGs exact; complete receipt comparison exceptworkunits in SUMMARY.json.

New writer uses private flat attribute storage and one actual closed paint record; actual consumed data remains available after proof funding exhaustion. Existing proofreaders stay gated. This corrects an earlier unsafe raw-getter fallback premise, but is not a performance success. No broadTrident/capqualification or sourceadoption.

Exact v2 emitted files preserved in ../actual-write-v2-node-dist.tgz; source patch and projector snapshot retained outside source tree. Original v1 emitted files were overwritten by tsup clean; v1 retained source/results/profiles are not original binaries.

Next intervention removes three record constructions/closure walks: writer produces one closed node inside its existing bound occurrence artifact; validation and actual-ink inspection consume that same node, originalsource only binds the XMLwrite. No newauthorityregistry.
