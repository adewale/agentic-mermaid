import { plugin } from 'bun'
const preload = '/dev/shm/pr449-four-final-20261111/ownership-detachment-regression-preload.ts'
plugin({ name: 'historical-public-positioned-detachment-regression', setup(build) {
  build.onLoad({ filter: /position-cache-ownership\.test\.ts$/ }, async args => {
    const source = await Bun.file(args.path).text()
    return { contents: source.replaceAll("runChild(process.execPath, ['-e',", `runChild(process.execPath, ['--preload', '${preload}', '-e',`), loader: 'ts' }
  })
  build.onLoad({ filter: /\/src\/positioning\.ts$/ }, async args => {
    const source = await Bun.file(args.path).text()
    const before = 'return borrowedNativeProducers.has(layout) ? clonePositioned(layout.positioned, true) : layout.positioned'
    if (!source.includes(before)) throw Error('Expected public detachment was not found')
    return { contents: source.replace(before, 'return layout.positioned'), loader: 'ts' }
  })
} })
