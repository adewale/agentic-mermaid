from pathlib import Path
import json,gzip,csv,hashlib,statistics,os
base=Path(__file__).parent;out=base/'browser';rows=json.loads((out/'RESULTS.json').read_text());identity=json.loads((base/'IDENTITY.json').read_text());histdir=Path('/tmp/pr449-week-comparison-20261101/trident-main-20261110/browser');hist=json.loads((histdir/'RESULTS.json').read_text());index={(r['target'],r['backend'],r['family']):r for r in rows};hindex={(r['target'],r['backend'],r['family']):r for r in hist};families=list(dict.fromkeys(r['family'] for r in rows));metrics=['raw','gzip9','brotli11'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();heap=lambda r:r.get('heap',{}).get('metrics',{}).get('jsHeapUsedBytes');deltas=[];products=[];allunknowns=[];errors=[];hardlinks=[];baselinefiles={};helpers=[]
for arm in ['control','candidate']:
 for backend in ['agentic','elk']:
  artifact=json.loads((out/f'{arm}-{backend}-ARTIFACT.json').read_text());root=Path(artifact['peer']['browser']['root']);src=Path(artifact['sourceRoot'])/'dist/browser-lazy';count=0
  for f in src.rglob('*'):
   if f.is_file():
    view=root/'browser-lazy'/f.relative_to(src);assert f.stat().st_ino==view.stat().st_ino and f.stat().st_dev==view.stat().st_dev;count+=1
  hardlinks.append({'target':arm,'backend':backend,'files':count,'source':str(src),'view':str(root),'sameDeviceInode':True});helpers.append(sha(Path(artifact['peer']['browser']['qualificationHelper'])))
for r in rows:
 key=(r['target'],r['backend'],r['family']);
 if r['status']!='passed' or r.get('error') or r.get('observerErrors') or any(f.get('error') for f in r['fetched']):errors.append(r)
 for p in r['publicProducts']:
  if p.get('proof',{}).get('status')!='passed':allunknowns.append({'target':r['target'],'backend':r['backend'],'family':r['family'],'call':p['call'],'status':p.get('proof',{}).get('status'),'proof':p.get('proof'),'error':p.get('error')})
 if r['target']!='candidate':continue
 for label,comparison,priorroot in [('control',index[('control',r['backend'],r['family'])],out),('pr599',hindex[('pr',r['backend'],r['family'])],histdir),('main426',hindex[('main',r['backend'],r['family'])],histdir)]:
  delta={'family':r['family'],'backend':r['backend'],'against':label,'requests':r['requests']-comparison['requests'],**{m:r['product'][m]-comparison['product'][m] for m in metrics},'heap':None if heap(r) is None or heap(comparison) is None else heap(r)-heap(comparison)};deltas.append(delta)
  for a,b in zip(r['publicProducts'],comparison['publicProducts']):
   stem=f"call{a['call']}.product.json.gz";pa=json.loads(gzip.decompress((out/f"candidate-{r['backend']}"/r['family']/stem).read_bytes()));pb=json.loads(gzip.decompress((priorroot/f"{comparison['target']}-{r['backend']}"/r['family']/stem).read_bytes()));ac=pa['receipt'].copy();bc=pb['receipt'].copy();ac.pop('layoutCertification',None);bc.pop('layoutCertification',None)
   products.append({'against':label,'family':r['family'],'backend':r['backend'],'call':a['call'],'role':a['role'],'sameSourceRole':a['source']==b['source'] and a['role']==b['role'],'svgExact':pa['svg']==pb['svg'],'receiptExact':pa['receipt']==pb['receipt'],'wholeExact':pa==pb,'nonCertificationReceiptExact':ac==bc,'proofStatusExact':a.get('proof',{}).get('status')==b.get('proof',{}).get('status'),'layoutDecisionsExact':a.get('layoutDecisions')==b.get('layoutDecisions')})
  if label!='control':
   art=json.loads((histdir/f"{comparison['target']}-{r['backend']}-ARTIFACT.json").read_text());hroot=Path(art['peer']['browser']['root']);helpers.append(sha(Path(art['peer']['browser']['qualificationHelper'])))
   for f in comparison['fetched']:
    if f.get('error'):continue
    from urllib.parse import unquote
    p=hroot/unquote(f['url']).lstrip('/');actual=sha(p);assert actual==f['actualSha256'];baselinefiles[str(p)]=actual
assert len(set(helpers))==1
summary={'sources':identity['sources'],'trident':identity['trident'],'count':{'observations':len(rows),'qualified':sum(r['status']=='passed' for r in rows),'products':sum(p['status']=='returned' for r in rows for p in r['publicProducts']),'expectedObservations':132,'expectedProducts':264},'closed':json.loads((out/'CLOSED.json').read_text()),'errors':errors,'unknowns':allunknowns,'proofStatuses':{arm:{status:sum(p.get('proof',{}).get('status')==status for r in rows if r['target']==arm for p in r['publicProducts']) for status in ['passed','unverified','failed']} for arm in ['control','candidate']},'noRecordedLayoutDecision':{arm:{backend:[r['family'] for r in rows if r['target']==arm and r['backend']==backend and all(not p.get('layoutDecisions') for p in r['publicProducts'])] for backend in ['agentic','elk']} for arm in ['control','candidate']},'comparisons':{},'hardlinks':hardlinks,'historicalByteIdentity':{'manifestSha256':sha(histdir/'RESULTS.json'),'uniqueFetchedFilesChecked':len(baselinefiles),'helperSha256':helpers[0],'sourceIdentity':str(histdir.parent/'IDENTITY.json'),'sourcesReplayed':False},'scope':'Fresh realms with mandatory support probe plus enrolled source; full public WithReceiptAsync products retained. Actual fetched module bytes independently compressed per file at gzip9/Brotli11; binding separated. Heap is forced-GC JS heap, not RSS/native/WASM/leak evidence. No API timing or complete authored meaning/all-goals claim. Historical comparison is retained same-byte baseline module/product evidence, no rerun.'}
for label in ['control','pr599','main426']:
 pr=[p for p in products if p['against']==label];summary['comparisons'][label]={'products':len(pr),**{k:sum(p[k] for p in pr) for k in ['sameSourceRole','svgExact','receiptExact','wholeExact','nonCertificationReceiptExact','proofStatusExact','layoutDecisionsExact']},'ranges':{}}
 for backend in ['agentic','elk']:
  ds=[r for r in deltas if r['against']==label and r['backend']==backend];summary['comparisons'][label]['ranges'][backend]={k:{'min':min(v),'median':statistics.median(v),'max':max(v),'lower':sum(x<0 for x in v),'equal':sum(x==0 for x in v),'higher':sum(x>0 for x in v)} for k in ['requests',*metrics,'heap'] if (v:=[r[k] for r in ds if r[k] is not None])}
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');(out/'PRODUCT-COMPARISON.json').write_text(json.dumps(products,indent=2)+'\n')
with (out/'NET-COMPARISON.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(deltas[0]));w.writeheader();w.writerows(deltas)
with (out/'FAMILY-PAYLOAD.csv').open('w') as f:
 fields=['target','backend','family','status','requests',*metrics,'heap','bindingRaw','bindingGzip9','bindingBrotli11'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({'target':r['target'],'backend':r['backend'],'family':r['family'],'status':r['status'],'requests':r['requests'],**r['product'],'heap':heap(r),'bindingRaw':r['adapter']['raw'],'bindingGzip9':r['adapter']['gzip9'],'bindingBrotli11':r['adapter']['brotli11']} for r in rows)
lines=['# Frozen final lazy-browser observation','',f"Control `{identity['sources']['control']}`; candidate `{identity['sources']['candidate']}`; Trident `{identity['trident']}`.",'',f"{summary['count']['qualified']}/{len(rows)} observations qualify; {summary['count']['products']} full public products retained. {summary['closed']['browserClosed']} browsers closed, {summary['closed']['openBrowsers']} open. Errors: {len(errors)}.",'',summary['scope'],'',f"Paint proof statuses per arm: {summary['proofStatuses']}. Full unknown proofs/issues retained in SUMMARY.json. No recorded graph-layout decisions for {len(summary['noRecordedLayoutDecision']['candidate']['agentic'])} families; requested backend alone does not establish application.",'','Candidate versus control: '+str(summary['comparisons']['control']),'','Candidate versus retained PR599: '+str(summary['comparisons']['pr599']),'','Candidate versus retained Main426: '+str(summary['comparisons']['main426']),'','Each table cell: requests / raw KiB / gzip9 KiB / Brotli11 KiB / post-GC JS heap MiB. Binding excluded from product bytes and separately recorded in CSV. Do not sum fresh-family closures as a warm portfolio.','','|Family|Control Native|Final Native|Control ELK|Final ELK|','|---|---|---|---|---|']
for family in families:
 cells=[]
 for backend in ['agentic','elk']:
  for arm in ['control','candidate']:
   r=index[(arm,backend,family)];cells.append(f"{r['requests']} / {r['product']['raw']/1024:.1f} / {r['product']['gzip9']/1024:.1f} / {r['product']['brotli11']/1024:.1f} / {heap(r)/1048576:.2f}")
 lines.append('|'+family+'|'+'|'.join(cells)+'|')
lines+=['','All immutable engine module views checked for identical device/inode to the actual frozen build; helper SHA256 identical to historical qualifier. Retained historical fetched module hashes checked against unchanged files before comparison. Source/API roles checked for each paired product. All adverse deltas, receipt differences, unknowns, and graph decisions remain in JSON/CSV.'];(out/'SUMMARY.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'count':summary['count'],'closed':summary['closed'],'proof':summary['proofStatuses'],'comparisons':summary['comparisons']},indent=2))
