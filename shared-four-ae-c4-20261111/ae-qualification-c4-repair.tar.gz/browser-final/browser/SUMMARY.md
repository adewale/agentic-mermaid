# Frozen final lazy-browser observation

Control `07a51fc9e1c06902fdf851abc1b05b9aa838e531`; candidate `ae1e84c6e2b6bc383fadd848d3e2ef45ec763b8c`; Trident `f080278e31e4202ca89d524e4ee9e4cf3cbff038`.

132/132 observations qualify; 264 full public products retained. 132 browsers closed, 0 open. Errors: 0.

Fresh realms with mandatory support probe plus enrolled source; full public WithReceiptAsync products retained. Actual fetched module bytes independently compressed per file at gzip9/Brotli11; binding separated. Heap is forced-GC JS heap, not RSS/native/WASM/leak evidence. No API timing or complete authored meaning/all-goals claim. Historical comparison is retained same-byte baseline module/product evidence, no rerun.

Paint proof statuses per arm: {'control': {'passed': 124, 'unverified': 8, 'failed': 0}, 'candidate': {'passed': 124, 'unverified': 8, 'failed': 0}}. Full unknown proofs/issues retained in SUMMARY.json. No recorded graph-layout decisions for 25 families; requested backend alone does not establish application.

Candidate versus control: {'products': 132, 'sameSourceRole': 132, 'svgExact': 132, 'receiptExact': 8, 'wholeExact': 8, 'nonCertificationReceiptExact': 132, 'proofStatusExact': 132, 'layoutDecisionsExact': 132, 'ranges': {'agentic': {'requests': {'min': 0, 'median': 0, 'max': 0, 'lower': 0, 'equal': 33, 'higher': 0}, 'raw': {'min': 989, 'median': 1009, 'max': 1014, 'lower': 0, 'equal': 0, 'higher': 33}, 'gzip9': {'min': 290, 'median': 301, 'max': 307, 'lower': 0, 'equal': 0, 'higher': 33}, 'brotli11': {'min': 194, 'median': 262, 'max': 422, 'lower': 0, 'equal': 0, 'higher': 33}, 'heap': {'min': -15760, 'median': -1192, 'max': 7336, 'lower': 23, 'equal': 0, 'higher': 10}}, 'elk': {'requests': {'min': 0, 'median': 0, 'max': 0, 'lower': 0, 'equal': 33, 'higher': 0}, 'raw': {'min': 999, 'median': 1009, 'max': 1024, 'lower': 0, 'equal': 0, 'higher': 33}, 'gzip9': {'min': 299, 'median': 304, 'max': 315, 'lower': 0, 'equal': 0, 'higher': 33}, 'brotli11': {'min': 192, 'median': 252, 'max': 367, 'lower': 0, 'equal': 0, 'higher': 33}, 'heap': {'min': -14836, 'median': -712, 'max': 37656, 'lower': 19, 'equal': 0, 'higher': 14}}}}

Candidate versus retained PR599: {'products': 132, 'sameSourceRole': 132, 'svgExact': 132, 'receiptExact': 8, 'wholeExact': 8, 'nonCertificationReceiptExact': 132, 'proofStatusExact': 132, 'layoutDecisionsExact': 132, 'ranges': {'agentic': {'requests': {'min': 0, 'median': 0, 'max': 0, 'lower': 0, 'equal': 33, 'higher': 0}, 'raw': {'min': -5386, 'median': -5364, 'max': 17413, 'lower': 32, 'equal': 0, 'higher': 1}, 'gzip9': {'min': -1702, 'median': -1692, 'max': 5401, 'lower': 32, 'equal': 0, 'higher': 1}, 'brotli11': {'min': -1292, 'median': -1212, 'max': 4856, 'lower': 32, 'equal': 0, 'higher': 1}, 'heap': {'min': 18512, 'median': 55444, 'max': 96004, 'lower': 0, 'equal': 0, 'higher': 33}}, 'elk': {'requests': {'min': 0, 'median': 0, 'max': 0, 'lower': 0, 'equal': 33, 'higher': 0}, 'raw': {'min': -5371, 'median': -5361, 'max': 17433, 'lower': 32, 'equal': 0, 'higher': 1}, 'gzip9': {'min': -1702, 'median': -1692, 'max': 5407, 'lower': 32, 'equal': 0, 'higher': 1}, 'brotli11': {'min': -1283, 'median': -1211, 'max': 4865, 'lower': 32, 'equal': 0, 'higher': 1}, 'heap': {'min': 15032, 'median': 56800, 'max': 119740, 'lower': 0, 'equal': 0, 'higher': 33}}}}

Candidate versus retained Main426: {'products': 132, 'sameSourceRole': 132, 'svgExact': 124, 'receiptExact': 0, 'wholeExact': 0, 'nonCertificationReceiptExact': 124, 'proofStatusExact': 132, 'layoutDecisionsExact': 132, 'ranges': {'agentic': {'requests': {'min': -1, 'median': -1, 'max': 11, 'lower': 20, 'equal': 2, 'higher': 11}, 'raw': {'min': 128145, 'median': 128180, 'max': 210118, 'lower': 0, 'equal': 0, 'higher': 33}, 'gzip9': {'min': 41617, 'median': 41651, 'max': 70078, 'lower': 0, 'equal': 0, 'higher': 33}, 'brotli11': {'min': 31872, 'median': 31947, 'max': 57956, 'lower': 0, 'equal': 0, 'higher': 33}, 'heap': {'min': 385428, 'median': 511544, 'max': 783600, 'lower': 0, 'equal': 0, 'higher': 33}}, 'elk': {'requests': {'min': -1, 'median': -1, 'max': 9, 'lower': 20, 'equal': 2, 'higher': 11}, 'raw': {'min': 128145, 'median': 128180, 'max': 188255, 'lower': 0, 'equal': 0, 'higher': 33}, 'gzip9': {'min': 41617, 'median': 41651, 'max': 63327, 'lower': 0, 'equal': 0, 'higher': 33}, 'brotli11': {'min': 31872, 'median': 31947, 'max': 52231, 'lower': 0, 'equal': 0, 'higher': 33}, 'heap': {'min': 380380, 'median': 512068, 'max': 753012, 'lower': 0, 'equal': 0, 'higher': 33}}}}

Each table cell: requests / raw KiB / gzip9 KiB / Brotli11 KiB / post-GC JS heap MiB. Binding excluded from product bytes and separately recorded in CSV. Do not sum fresh-family closures as a warm portfolio.

|Family|Control Native|Final Native|Control ELK|Final ELK|
|---|---|---|---|---|
|flowchart|41 / 1166.9 / 387.7 / 330.6 / 5.73|41 / 1167.9 / 388.0 / 330.9 / 5.73|31 / 2383.9 / 737.8 / 584.5 / 10.77|31 / 2384.9 / 738.1 / 584.7 / 10.77|
|sequence|15 / 691.2 / 222.2 / 185.6 / 4.87|15 / 692.2 / 222.5 / 185.8 / 4.88|15 / 691.2 / 222.2 / 185.6 / 4.87|15 / 692.2 / 222.5 / 185.8 / 4.87|
|state|37 / 1165.8 / 386.8 / 329.8 / 5.54|37 / 1166.8 / 387.1 / 330.2 / 5.54|27 / 2382.8 / 736.9 / 583.7 / 10.58|27 / 2383.8 / 737.2 / 583.9 / 10.58|
|class|36 / 958.3 / 316.6 / 267.9 / 5.12|36 / 959.3 / 316.9 / 268.4 / 5.12|23 / 2172.7 / 664.8 / 519.9 / 9.61|23 / 2173.7 / 665.1 / 520.2 / 9.60|
|er|37 / 1056.7 / 350.4 / 297.7 / 5.02|37 / 1057.7 / 350.7 / 298.0 / 5.02|25 / 2265.5 / 696.6 / 548.1 / 9.56|25 / 2266.5 / 696.9 / 548.3 / 9.56|
|timeline|11 / 633.3 / 203.7 / 168.9 / 4.23|11 / 634.2 / 204.0 / 169.2 / 4.24|11 / 633.3 / 203.7 / 168.9 / 4.24|11 / 634.2 / 204.0 / 169.2 / 4.24|
|journey|12 / 653.8 / 210.9 / 175.5 / 5.00|12 / 654.7 / 211.2 / 175.7 / 5.01|12 / 653.8 / 210.9 / 175.5 / 5.01|12 / 654.7 / 211.2 / 175.7 / 5.01|
|architecture|38 / 1146.2 / 378.6 / 322.1 / 5.23|38 / 1147.2 / 378.8 / 322.4 / 5.23|28 / 2363.2 / 728.6 / 576.0 / 10.65|28 / 2364.2 / 729.0 / 576.2 / 10.65|
|xychart|15 / 675.5 / 218.3 / 181.9 / 4.88|15 / 676.5 / 218.6 / 182.1 / 4.86|15 / 675.5 / 218.3 / 181.9 / 4.88|15 / 676.5 / 218.6 / 182.1 / 4.86|
|pie|17 / 645.6 / 210.4 / 174.9 / 4.19|17 / 646.5 / 210.7 / 175.1 / 4.19|17 / 645.6 / 210.4 / 174.9 / 4.19|17 / 646.5 / 210.7 / 175.1 / 4.19|
|quadrant|14 / 642.6 / 208.0 / 172.7 / 4.40|14 / 643.6 / 208.3 / 173.0 / 4.39|14 / 642.6 / 208.0 / 172.7 / 4.40|14 / 643.6 / 208.3 / 173.0 / 4.39|
|gantt|11 / 659.6 / 212.8 / 177.2 / 4.45|11 / 660.6 / 213.1 / 177.4 / 4.44|11 / 659.6 / 212.8 / 177.2 / 4.45|11 / 660.6 / 213.1 / 177.4 / 4.45|
|mindmap|16 / 649.1 / 212.5 / 176.7 / 4.50|16 / 650.1 / 212.7 / 176.9 / 4.50|16 / 649.1 / 212.5 / 176.7 / 4.50|16 / 650.1 / 212.7 / 176.9 / 4.50|
|gitgraph|14 / 648.0 / 210.5 / 174.9 / 4.60|14 / 648.9 / 210.8 / 175.2 / 4.60|14 / 648.0 / 210.5 / 174.9 / 4.60|14 / 648.9 / 210.8 / 175.2 / 4.59|
|radar|16 / 651.8 / 212.2 / 176.5 / 4.35|16 / 652.8 / 212.5 / 176.8 / 4.34|16 / 651.8 / 212.2 / 176.5 / 4.34|16 / 652.8 / 212.5 / 176.8 / 4.34|
|sankey|14 / 652.9 / 211.4 / 175.8 / 4.48|14 / 653.8 / 211.7 / 176.1 / 4.48|14 / 652.9 / 211.4 / 175.8 / 4.48|14 / 653.8 / 211.7 / 176.1 / 4.48|
|c4|22 / 854.9 / 278.1 / 234.3 / 5.42|22 / 855.9 / 278.4 / 234.6 / 5.40|22 / 854.9 / 278.1 / 234.3 / 5.41|22 / 855.9 / 278.4 / 234.6 / 5.44|
|packet|12 / 621.0 / 200.7 / 166.3 / 4.22|12 / 622.0 / 201.0 / 166.5 / 4.22|12 / 621.0 / 200.7 / 166.3 / 4.22|12 / 622.0 / 201.0 / 166.5 / 4.22|
|kanban|13 / 629.4 / 204.1 / 169.3 / 4.33|13 / 630.4 / 204.4 / 169.5 / 4.33|13 / 629.4 / 204.1 / 169.3 / 4.33|13 / 630.4 / 204.4 / 169.5 / 4.33|
|requirement|31 / 873.5 / 289.5 / 244.7 / 5.19|31 / 874.5 / 289.8 / 245.1 / 5.19|16 / 2064.5 / 629.5 / 489.4 / 9.74|16 / 2065.5 / 629.8 / 489.7 / 9.74|
|treemap|14 / 639.5 / 208.5 / 173.3 / 4.25|14 / 640.4 / 208.8 / 173.6 / 4.25|14 / 639.5 / 208.5 / 173.3 / 4.25|14 / 640.4 / 208.8 / 173.6 / 4.25|
|ishikawa|13 / 622.6 / 201.2 / 166.7 / 4.73|13 / 623.5 / 201.5 / 167.0 / 4.73|13 / 622.6 / 201.2 / 166.7 / 4.73|13 / 623.5 / 201.5 / 167.0 / 4.73|
|block|18 / 796.3 / 259.4 / 217.7 / 4.69|18 / 797.3 / 259.7 / 218.0 / 4.69|18 / 796.3 / 259.4 / 217.7 / 4.69|18 / 797.3 / 259.7 / 218.0 / 4.69|
|eventmodeling|11 / 629.7 / 203.2 / 168.5 / 4.86|11 / 630.6 / 203.5 / 168.7 / 4.85|11 / 629.7 / 203.2 / 168.5 / 4.86|11 / 630.6 / 203.5 / 168.7 / 4.85|
|zenuml|14 / 704.9 / 227.3 / 190.2 / 4.89|14 / 705.8 / 227.6 / 190.4 / 4.88|14 / 704.9 / 227.3 / 190.2 / 4.89|14 / 705.8 / 227.6 / 190.4 / 4.88|
|railroad|13 / 637.8 / 206.2 / 171.2 / 4.31|13 / 638.7 / 206.5 / 171.4 / 4.31|13 / 637.8 / 206.2 / 171.2 / 4.31|13 / 638.7 / 206.5 / 171.4 / 4.30|
|cynefin|13 / 625.9 / 202.5 / 167.9 / 4.57|13 / 626.9 / 202.8 / 168.1 / 4.56|13 / 625.9 / 202.5 / 167.9 / 4.57|13 / 626.9 / 202.8 / 168.1 / 4.56|
|agentflow|40 / 1296.3 / 429.2 / 367.4 / 6.12|40 / 1297.3 / 429.5 / 367.8 / 6.12|30 / 2513.3 / 779.3 / 621.3 / 11.21|30 / 2514.3 / 779.6 / 621.5 / 11.21|
|usecase|35 / 1133.0 / 375.5 / 319.5 / 5.54|35 / 1134.0 / 375.8 / 319.8 / 5.54|26 / 2350.3 / 725.8 / 573.6 / 10.52|26 / 2351.3 / 726.1 / 573.8 / 10.52|
|wardley|15 / 653.7 / 211.6 / 176.1 / 4.71|15 / 654.6 / 211.9 / 176.4 / 4.70|15 / 653.7 / 211.6 / 176.1 / 4.71|15 / 654.6 / 211.9 / 176.4 / 4.70|
|venn|12 / 634.7 / 205.9 / 171.0 / 4.17|12 / 635.6 / 206.2 / 171.2 / 4.17|12 / 634.7 / 205.9 / 171.0 / 4.17|12 / 635.6 / 206.2 / 171.2 / 4.17|
|swimlane|38 / 1174.5 / 390.6 / 333.3 / 5.61|38 / 1175.5 / 390.9 / 333.7 / 5.61|38 / 1174.5 / 390.6 / 333.3 / 5.61|38 / 1175.5 / 390.9 / 333.7 / 5.61|
|treeview|14 / 630.4 / 204.7 / 169.7 / 4.14|14 / 631.4 / 205.0 / 170.0 / 4.14|14 / 630.4 / 204.7 / 169.7 / 4.14|14 / 631.4 / 205.0 / 170.0 / 4.14|

All immutable engine module views checked for identical device/inode to the actual frozen build; helper SHA256 identical to historical qualifier. Retained historical fetched module hashes checked against unchanged files before comparison. Source/API roles checked for each paired product. All adverse deltas, receipt differences, unknowns, and graph decisions remain in JSON/CSV.
