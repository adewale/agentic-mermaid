import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
import {createHash} from 'node:crypto'
const root='/tmp/pr449-main-integration-20261029-762',base=import.meta.dir,arm=process.argv[2]!
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const cases=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/shared-four-fixes-20261111/task1/inplace-closure-ceiling/capacity/EXISTING-CASES.json','utf8'))
const rows=[];mkdirSync(base+'/'+arm,{recursive:true})
for(const item of cases)for(const backend of ['agentic','elk']){
 let row:any={case:item.name,backend}
 try{const product=renderMermaidSVGWithReceipt(item.source,{graphLayout:{backend,fallback:'none'}}),json=JSON.stringify(product),proof=product.receipt.layoutCertification;
 row={...row,delivered:true,svgSha256:createHash('sha256').update(product.svg).digest('hex'),proof,wholeBytes:Buffer.byteLength(json)};
 writeFileSync(base+'/'+arm+'/'+item.name+'-'+backend+'.product.json.gz',gzipSync(json))
 }catch(error:any){row={...row,delivered:false,name:error.name,code:error.code,message:error.message,proof:error.certification}}
 rows.push(row);console.log(JSON.stringify({arm,case:item.name,backend,delivered:row.delivered,status:row.proof?.status,checks:row.proof?.checks}));writeFileSync(base+'/'+arm+'/RESULT.json',JSON.stringify(rows,null,2)+'\n')
}
