import {readFileSync} from 'node:fs'
const base='/dev/shm/pr449-four-final-20261111/numeric-producer',root='/tmp/pr449-main-integration-20261029-762'
Bun.plugin({name:'existing-numeric-producer-control',setup(build){
 build.onLoad({filter:/\/src\/(?:shared\/svg-number|scene\/svg-writer)\.ts$/},args=>{
  if(args.path===root+'/src/shared/svg-number.ts')return{contents:readFileSync(base+'/svg-number.control.ts','utf8'),loader:'ts'}
  if(args.path===root+'/src/scene/svg-writer.ts')return{contents:readFileSync(base+'/svg-writer.control.ts','utf8'),loader:'ts'}
 })
}})
