import { plugin } from 'bun'
plugin({ name: 'historical-native-producer-borrow-regression', setup(build) {
  build.onLoad({ filter: /\/src\/positioning\.ts$/ }, async args => {
    const source = await Bun.file(args.path).text()
    const before = '&& !!producer && producer === originalNativeDrawingOf(plan.family.lowerScene) && !sceneAssertionsEnabled(request)'
    if (!source.includes(before)) throw Error('Expected original producer admission was not found')
    return { contents: source.replace(before, '&& !!producer && !sceneAssertionsEnabled(request)'), loader: 'ts' }
  })
} })
