import {readFileSync} from 'node:fs'
import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import {getFamily} from '/tmp/pr449-main-integration-20261029-762/src/agent/families.ts'
import {inheritNativeDrawing,nativeDrawingOf,sceneLowering} from '/tmp/pr449-main-integration-20261029-762/src/scene/drawing.ts'
import {withRenderStageObserver} from '/tmp/pr449-main-integration-20261029-762/src/render-stages.ts'
const source=readFileSync('/tmp/pr449-main-integration-20261029-762/eval/layout-compare/fixtures/c4-basic.mmd','utf8')
const lower=getFamily('c4').lowerScene!,producer=nativeDrawingOf(lower)!,original=sceneLowering(producer)
let installed=false,calls=0,error:any,product:any
const replacement=sceneLowering((factory,context)=>{calls++;return producer(factory,context)})
const plain=renderMermaidSVGWithReceipt(source)
try{product=withRenderStageObserver(sample=>{if(sample.stage==='layout'&&!installed){installed=true;inheritNativeDrawing(replacement,lower)}},()=>renderMermaidSVGWithReceipt(source))}catch(e){error={name:e.name,message:e.message,stack:e.stack}}finally{inheritNativeDrawing(original,lower)}
console.log(JSON.stringify({installed,calls,error,svgEqual:product?.svg===plain.svg,restoredExact:JSON.stringify(renderMermaidSVGWithReceipt(source))===JSON.stringify(plain)},null,2))
