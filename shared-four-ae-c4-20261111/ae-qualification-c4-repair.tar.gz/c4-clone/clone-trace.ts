import {isProxy} from 'node:util/types'
const clone=globalThis.structuredClone
let diagnosed=false
function inspect(value:unknown,path:string,seen=new WeakSet<object>()) {
 if(typeof value==='function'){console.error('UNCLONEABLE-FUNCTION',path);return}
 if(value===null||typeof value!=='object'||seen.has(value))return
 seen.add(value)
 if(isProxy(value)){console.error('UNCLONEABLE-PROXY',path);return}
 if(value instanceof Map){let i=0;for(const [k,v]of value){inspect(k,path+'.mapKey'+i,seen);inspect(v,path+'.mapValue'+i++,seen)}return}
 if(value instanceof Set){let i=0;for(const x of value)inspect(x,path+'.set'+i++,seen);return}
 for(const [k,d]of Object.entries(Object.getOwnPropertyDescriptors(value)))if(d.enumerable){if('value'in d)inspect(d.value,path+'.'+k,seen);else console.error('ACCESSOR',path+'.'+k)}
}
globalThis.structuredClone=function(value,options){try{return clone(value,options)}catch(error){console.error('FIRST-CLONE-FAILURE',new Error().stack);if(!diagnosed){diagnosed=true;inspect(value,'root')}throw error}}
