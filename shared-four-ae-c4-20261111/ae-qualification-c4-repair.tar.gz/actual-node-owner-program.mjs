
      import assert from 'node:assert/strict'
      import { createRequire } from 'node:module'
      const require = createRequire(import.meta.url)
      const elkImplementation = require.resolve('elkjs/lib/elk.bundled.js')
      const loaded = () => { const files = Object.keys(require.cache); return [files.includes(elkImplementation), files.some(path => path.endsWith('/inter-metrics-kernel.cjs')), files.some(path => path.endsWith('/layout-optimization.cjs'))] }
      const { renderMermaidSVG } = await import("/dev/shm/pr449-four-final-20261111/candidate/dist/agent-core.js")
      const { renderMermaidSVGWithReceipt, renderContractDigest } = await import("/dev/shm/pr449-four-final-20261111/candidate/dist/index.js")
      const states = [loaded()]
      renderMermaidSVG('sequenceDiagram\n  A->>B: hi')
      states.push(loaded())
      const native = renderMermaidSVGWithReceipt('flowchart TD\n  A --> B', { graphLayout: { backend: 'agentic', fallback: 'none' } })
      assert.equal(native.receipt.layoutCertification.status, 'passed')
      assert.equal(native.receipt.layoutCertification.coverage.conditional, 0)
      assert.equal(native.receipt.layoutCertification.checks.markers, 1)
      assert.equal(native.receipt.layoutCertification.outputDigest, renderContractDigest(native.svg))
      const edge = native.svg.match(/<(?:polyline|line|path)\b[^>]*data-role="edge"[^>]*>/)?.[0]
      assert.ok(edge, 'Native actual edge must be emitted')
      assert.match(edge, /data-from="A"/)
      assert.match(edge, /data-to="B"/)
      assert.match(edge, /marker-end="url\(#.+\)"/)
      states.push(loaded())
      renderMermaidSVG('flowchart TD\n  A -->|needs ELK| B\n  B --> A', { graphLayout: { backend: 'elk' } })
      states.push(loaded())
      renderMermaidSVG('flowchart TD\n A --> B', { fontMetrics: 'bundled-inter' })
      states.push(loaded())
      renderMermaidSVG('flowchart TD\n A --> B', { graphLayout: { backend: 'elk', quality: 'balanced' } })
      states.push(loaded())
      console.log(JSON.stringify(states))