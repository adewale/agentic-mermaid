import { plugin } from 'bun'
plugin({ name: 'ownership-work-diagnostic', setup(build) {
  build.onLoad({ filter: /position-cache-ownership\.test\.ts$/ }, async args => {
    let contents = await Bun.file(args.path).text()
    contents = contents.replace("const draw = spyOn(drawing, 'drawNative'), certify = spyOn(paint, 'certifyNativePaint')", "const publicDraw = spyOn(drawing, 'drawNative'), privateDraw = spyOn(drawing, 'drawOriginalPositionedNative'), certify = spyOn(paint, 'certifyNativePaint'); const draw = { get mock() { return { calls: [...publicDraw.mock.calls, ...privateDraw.mock.calls] } } }")
    contents = contents.replaceAll("import assert from 'node:assert/strict'", `import strict from 'node:assert/strict'
    const assert = new Proxy(strict, { get(target, key) {
      if (key !== 'deepEqual') return Reflect.get(target, key)
      return (actual, expected, message) => {
        if (actual?.receipt?.layoutCertification && expected?.receipt?.layoutCertification) {
          const left = JSON.parse(JSON.stringify(actual)), right = JSON.parse(JSON.stringify(expected))
          const a = left.receipt.layoutCertification.checks.operations, b = right.receipt.layoutCertification.checks.operations
          strict.ok(Number.isSafeInteger(a) && a >= 0 && a <= 400000)
          strict.ok(Number.isSafeInteger(b) && b >= 0 && b <= 400000)
          delete left.receipt.layoutCertification.checks.operations; delete right.receipt.layoutCertification.checks.operations
          return strict.deepEqual(left, right, message)
        }
        return strict.deepEqual(actual, expected, message)
      }
    } })`)
    return { contents, loader: 'ts' }
  })
} })
