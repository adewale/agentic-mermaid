# Bounded body-gap seat counterfactual

Current source7b95d18053f605ae1574406e377cb8dd29c919b0. Actual Native201+three
n0~~~n7 constraints TB/BT: selected n5→n3 head hidden66/attenuated72 by filled
n6→n2 halo. ELK clears this pair; Trinity shapes unsupported.

Three stopped trials stay separate: alongshaft−3 hits n3body; existingperp−10
hits n5body; global ordinaryNativefullhalo measurement fixes this pair but
introduces actual new head overlap on generated-cyclic13 (0→13hidden/0→22atten).
Overhang eligibility alone leaves originalpair unchanged. No production change.

Measured n5bottom254.025, n3top293.025, labelhaloheight38.3 leave ycenter interval
273.175..273.875; current274.025 misses. Combinedpoint243.15,273.525 passes
unchanged full seat.clear with555321units remaining; no blocker. This confirms
feasible space, not a shipped repair.

Outside-source next prototype: extend existing labelSeatPaintContext with one
optional body-gap proposal. Reuse retained body/header/shaft/marker supports;
peer-label bounds come from existing live label() and current positions. Do not
expose supports or add caches. New scratch uses flat Float64Array intervals.
Choose a cross-axis body gap around the existing anchor within its existing
perpendicular allowance, then subtract ALL active paint supports to find a
longitudinal free interval on the same orthogonal carrier. Prefer an interior
point; unchanged clear() and staged publication remain mandatory.

Run only after all existing rescue work, only for remaining marker/halo contact,
not custom host measurement, curves or self-loops. Keep original1m pay closure
and prepay allocations/visits/arithmetic. No new work counter/cap/solver mode;
optional exhausted work returns no proposal. Existing64 cap is per enumeration
of retained feasible candidates, not attempted checks; do not misreport it.
Baseline products from previous b3e43e checkpoint are exact current7b95 and should
be reused, not replayed as progress. Prototype actual ink first, then owning
red→green tests and affected Native/ELK/Trinity contracts; preserve area/wire/
runtime/memory/bundle adverse effects. Global-fullhalo trial remains unshipped.
