  // Existing repairs retain their full allowance before optional gap proposals.
  if (customTextMeasurementActive() || routeWork <= 0) return
  for (const edge of labeled) {
    if (!pay(16 + edge.points.length)) return
    const rect = rectOf(edge), anchor = edge.labelPosition
    if (!rect || !anchor || !overlapsMarker(rect) || edge.curve || (style.edgeBendRadius ?? 0) !== 0 || edge.source === edge.target) continue
    const segs = orderedLabelSegments(edge, pay)
    if (!segs) return
    paint ??= labelSeatPaintContext(positioned.nodes, positioned.edges, positioned.groups, style, pay)
    if (!paint) return
    const block = edge.labelBlock ?? graphEdgeTextBlock(resolveLabelContent(edge.label!, edge.labelContent), style)
    const pw = block.width + 2 * LABEL_PILL_PADDING, ph = block.height + 2 * LABEL_PILL_PADDING
    for (const segment of segs) {
      if (!pay(24)) return
      const limit = Math.min(ph / 2 + 3, (segment.vertical ? pw : ph) / 2 - 1)
      if (Math.abs(anchor[segment.vertical ? 'x' : 'y'] - segment.a[segment.vertical ? 'x' : 'y']) > limit) continue
      const point = paint.bodyGap(edge, segment.a, segment.b, anchor, limit)
      if (!point) continue
      if (!pay(12)) return
      const positions = new Map<PositionedEdge, Point>([[edge, point]])
      if (!paint.clear(edge, point, positions)) continue
      edge.labelPosition = point
      break
    }
  }
