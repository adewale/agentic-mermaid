import fs from 'node:fs';
import path from 'node:path';
import {gunzipSync,gzipSync,brotliCompressSync,constants} from 'node:zlib';
const packet=process.argv[2];
if(!packet)throw new Error('Packet path required');
const rows=[];
function visit(dir){
 for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
  const file=path.join(dir,entry.name);
  if(entry.isDirectory())visit(file);
  else if(entry.name==='actual.svg.gz'){
   const svg=gunzipSync(fs.readFileSync(file));
   rows.push({sourceSvg:file,rawBytes:svg.length,gzipDefaultLevel6Bytes:gzipSync(svg).length,gzipLevel9Bytes:gzipSync(svg,{level:9}).length,brotliQuality11Bytes:brotliCompressSync(svg,{params:{[constants.BROTLI_PARAM_QUALITY]:11}}).length});
  }
 }
}
visit(packet);
const result={scope:'Offline compression of saved fully consumed actual SVGs; zero public calls; existing capture sizes.svgGzipBytes is Node default level6',runtime:process.version,zlib:process.versions.zlib,brotli:process.versions.brotli,rows};
fs.writeFileSync(path.join(packet,'COMPRESSION.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({packet,actualSvgs:rows.length,publicCalls:0}));
