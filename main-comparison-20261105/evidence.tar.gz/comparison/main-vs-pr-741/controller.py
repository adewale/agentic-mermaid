from pathlib import Path
import os,json,subprocess,gzip,datetime
base=Path('/tmp/pr449-week-comparison-20261101/main-vs-pr-741')
manifest=json.loads((base/'manifest.json').read_text());results=[]
env=dict(os.environ,AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def check(job):
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=job['root'],env=env,text=True).strip()==job['expectedHead'],'Frozen HEAD mismatch'
 dirty=subprocess.check_output(['git','diff','--name-only','HEAD','--','src'],cwd=job['root'],env=env,text=True).splitlines()
 assert not [p for p in dirty if not p.startswith('src/__tests__/')],('Dirty production',dirty)
for index,item in enumerate(manifest['jobs']):
 job=json.loads(Path(item['jobPath']).read_text());check(job);out=Path(item['out']);out.mkdir(parents=True,exist_ok=True)
 assert not (out/'RESULT.json.gz').exists(),'No repeats'
 print(json.dumps({'event':'START','index':index+1,'case':job['caseId'],'revision':job['revision'],'arm':job['arm'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}),flush=True)
 try:
  run=subprocess.run(['node',str(base/'capture.mjs'),str(out),item['jobPath']],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,cwd=job['root'],timeout=180)
  (out/'worker.log.gz').write_bytes(gzip.compress(run.stdout+run.stderr));code=run.returncode
 except subprocess.TimeoutExpired as error:
  (out/'worker.log.gz').write_bytes(gzip.compress((error.stdout or b'')+(error.stderr or b'')));code='timeout'
 if (out/'RESULT.json.gz').exists():result=json.loads(gzip.decompress((out/'RESULT.json.gz').read_bytes()))
 else:
  result={'status':'tool-unavailable','actualPublicCalls':'unknown','stage':'worker-process','exit':code,'job':job};(out/'RESULT.json.gz').write_bytes(gzip.compress(json.dumps(result).encode()))
 check(job)
 entry={**item,'exit':code,'status':result['status'],'actualPublicCalls':result['actualPublicCalls']};results.append(entry)
 (base/'controller.json').write_text(json.dumps({'status':'running','completed':len(results),'callLimit':24,'results':results},indent=2))
 print(json.dumps({'event':'COMPLETE',**entry}),flush=True)
(base/'controller.json').write_text(json.dumps({'status':'complete','completed':len(results),'callLimit':24,'actualPublicCalls':sum(e['actualPublicCalls']for e in results if isinstance(e['actualPublicCalls'],int)),'results':results},indent=2))
