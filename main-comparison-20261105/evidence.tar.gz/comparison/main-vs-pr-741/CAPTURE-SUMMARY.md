# Fixed main → PR741 source comparison

Fixed heads: main f9ec8c115de14020d3c182d5d7f2e7e70bfcdefb; PR741b80dba91c0e1f4feba9a62695f7820bc79a23. Four existing claim fixtures were enrolled in manifest.json before outcomes. Each received one fresh Node24 source public SVG-with-receipt call per revision and lane; no repeated product calls. Every returned whole SVG and entire receipt was consumed and retained.

24 public calls: 21 returned, 3 refused (main ER208 in every lane). Six initial main module-loading failures made zero public calls; they remain under unavailable-before-loader-fix with links from corrected attempts. The only tooling correction was existing roughjs/bin extensionless-relative resolution under a symlinked dependency tree. It changed no library source/API.

| Fixture | Lane | Main → PR delivery/proof | Canvas area main → PR | Proof operations main → PR |
|---|---|---|---:|---:|
| Sparse256-default-gap | omitted | passed → passed | 3,459,200 → 3,459,200 | 102610 → 90857 |
| Sparse256-default-gap | agentic | passed → passed | 15,832,099.72 → 3,633,619.5 | 100190 → 91015 |
| Sparse256-default-gap | elk | passed → passed | 3,459,200 → 3,459,200 | 102610 → 90857 |
| ER208-chain | omitted | ER_ROUTE_WORK_LIMIT → passed | — → 10,012,562.896 | — → 280068 |
| ER208-chain | agentic | ER_ROUTE_WORK_LIMIT → passed | — → 8,140,454.896 | — → 287124 |
| ER208-chain | elk | ER_ROUTE_WORK_LIMIT → passed | — → 10,012,562.896 | — → 280068 |
| raw-fan-circle | omitted | unverified → unverified | 45,086.4 → 45,086.4 | 41687 → 156940 |
| raw-fan-circle | agentic | unverified → unverified | 45,086.4 → 45,086.4 | 41687 → 156940 |
| raw-fan-circle | elk | unverified → unverified | 45,086.4 → 45,086.4 | 41687 → 156940 |
| nonlinear-forest | omitted | passed → passed | 226,466.48 → 165,355.658 | 22851 → 98311 |
| nonlinear-forest | agentic | passed → passed | 226,466.48 → 165,355.658 | 22851 → 98311 |
| nonlinear-forest | elk | passed → passed | 176,727.21 → 176,727.21 | 22817 → 98335 |

Default/opt-in distinction: Sparse256 default and explicit ELK retain area3,459,200; its explicit Native area falls from15,832,099.72 to3,633,619.5 (77.0490% smaller). ER208 default newly delivers where main refused at ER_ROUTE_WORK_LIMIT; there is no before SVG for a geometry comparison. Forest omitted and explicit Native canvases fall from226,466.48 to165,355.6575 (26.9845% smaller); explicit ELK remains176,727.21. Raw-circle canvases remain45,086.4 and proof status stays unverified. Independent value_scope verified current main/PR SVGs exactly match the existing before/after-agentic products, binding their prior0→225 owned-marker-pixel result without new rasters.

Relevant static caps match exactly: ER geometry400,000; ER labels400,000; Native paint400,000; actual receipt occlusion-pair allowance100,000. All nine Scene validation limits also match (CAPS.json). Additional proof operations for forest/raw-circle are retained above; they are bounded work counts, not runtime or CPU measurements.

All six explicit PR prior bindings match both whole SVG and entire receipt exactly (Sparse256, ER208, raw-circle × Agentic/ELK). These PR calls validate existing bindings; the new main calls establish the comparison baseline. Forest had only an existing source/options job, without a prior exact-product binding.

| Fixture | Lane | SVG raw bytes main → PR | gzip9 bytes main → PR | Brotli Q11 bytes main → PR |
|---|---|---:|---:|---:|
| Sparse256-default-gap | omitted | 260767 → 260973 | 12692 → 12747 | 6855 → 6836 |
| Sparse256-default-gap | agentic | 260800 → 265157 | 13124 → 13306 | 7538 → 6638 |
| Sparse256-default-gap | elk | 260767 → 260973 | 12692 → 12747 | 6855 → 6836 |
| ER208-chain | omitted | — → 582524 | — → 39720 | — → 25326 |
| ER208-chain | agentic | — → 579579 | — → 39671 | — → 25193 |
| ER208-chain | elk | — → 582524 | — → 39720 | — → 25326 |
| raw-fan-circle | omitted | 5762 → 5792 | 1267 → 1285 | 1070 → 1087 |
| raw-fan-circle | agentic | 5762 → 5792 | 1267 → 1285 | 1070 → 1087 |
| raw-fan-circle | elk | 5762 → 5792 | 1267 → 1285 | 1070 → 1087 |
| nonlinear-forest | omitted | 8052 → 8047 | 1461 → 1483 | 1212 → 1238 |
| nonlinear-forest | agentic | 8052 → 8047 | 1461 → 1483 | 1212 → 1238 |
| nonlinear-forest | elk | 8069 → 8069 | 1482 → 1482 | 1229 → 1229 |

Compression was derived offline from saved actual SVGs with Node24.19.0, explicit gzip level9 and Brotli quality11. Original capture RESULT sizes.svgGzipBytes is Node default level6 and is retained unchanged. N=1 call wall/CPU/RSS values remain in STATUS.json as descriptive samples only; no runtime ratios or speed claims follow.

Source/options/public products/refusals are frozen. No production edits, tests, builds, layout-only proxies or new raster calls were used. Independent semantic/ink and route geometry findings are separate; these selected claim fixtures do not establish universal workload improvement.

Independent value_scope saved-product readback: forest omitted SVG equals explicit Agentic exactly on each revision. Its default/Native wire is700.0375→436.857166666 (−37.5952%); bends8→8. Explicit ELK wire396.469666666 and bends8 are unchanged, with exact painted leaves. Raw-circle's three mode SVGs are identical within each revision, and the prior selected marker-ink result binds by exact SVG equality. The current forest default/Native PR SVG likewise exactly matches its prior after-final fanout artifact, so the existing selected four-head ink evidence binds without another raster. These are bounded selected ink witnesses, not whole-canvas or universal-font claims.
