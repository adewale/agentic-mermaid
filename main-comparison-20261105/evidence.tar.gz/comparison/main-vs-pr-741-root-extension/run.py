import pathlib,json,subprocess,os,time
root=pathlib.Path('/tmp/pr449-week-comparison-20261101/main-vs-pr-741-root-extension')
worker='/tmp/pr449-week-comparison-20261101/main-vs-pr-741/capture.mjs'
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
manifest=json.loads((root/'manifest.json').read_text());env=os.environ.copy();env.update(AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0')
records=[]
for i,job in enumerate(manifest['jobs']):
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=job['root'],text=True).strip()==job['expectedHead']
 out=root/job['caseId']/job['arm']/job['backend'];out.mkdir(parents=True,exist_ok=True)
 assert not (out/'RESULT.json.gz').exists(),'Retained outcome must not be overwritten'
 (out/'job.json').write_text(json.dumps(job,indent=2)+'\n')
 started=time.monotonic()
 with open(out/'worker.log','w') as log:
  try:r=subprocess.run([node,worker,str(out),str(out/'job.json')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90);status={'exitCode':r.returncode}
  except subprocess.TimeoutExpired:status={'timeoutSeconds':90,'status':'unknown-timeout'}
 status.update(caseId=job['caseId'],arm=job['arm'],backend=job['backend'],workerSeconds=time.monotonic()-started)
 (out/'WORKER-STATUS.json').write_text(json.dumps(status,indent=2)+'\n');records.append(status)
 (root/'CONTROLLER-STATUS.json').write_text(json.dumps({'complete':len(records)==12,'jobs':records,'limit':12},indent=2)+'\n')
 print(json.dumps(status),flush=True)
