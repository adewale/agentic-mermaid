import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync, brotliCompressSync, constants } from 'node:zlib'
const paths = {
  main: '/tmp/pr449-main-ci-base-f9ec8c115/editor.html',
  pr: '/tmp/pr449-main-integration-20261029-762/editor.html',
}
const rows = Object.entries(paths).map(([arm, path]) => {
  const bytes = readFileSync(path)
  return { arm, path, rawBytes: bytes.length, gzip9: gzipSync(bytes, { level: 9 }).length, brotli11: brotliCompressSync(bytes, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } }).length }
})
const result = { runtime: process.versions, publicCalls: 0, builds: 0, sourceRevisions: { main: 'f9ec8c115de14020d3c182d5d7f2e7e70bfcdefb', pr: '741b80dba91c0e1f4feba9a62695f7820bc79a23' }, rows, scope: 'Offline compression of retained actual full standalone editor products built by each revision with Bun1.4.4 and the same installed dependencies. PR HTML runtime is69af, unchanged by741 expectedPNG/docs. No build/runtime speed ratio; no new render.' }
writeFileSync('/tmp/pr449-week-comparison-20261101/main-vs-pr-741-root-extension/STANDALONE-COST.json', JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify(rows))
