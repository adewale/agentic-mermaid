import { readFileSync, writeFileSync } from 'node:fs'
import { gunzipSync, gzipSync, brotliCompressSync, constants } from 'node:zlib'
const dir = '/tmp/pr449-week-comparison-20261101/main-vs-pr-741-root-extension/production-builds'
const rows = ['main', 'pr'].map(arm => {
  const bytes = gunzipSync(readFileSync(`${dir}/${arm}-production.html.gz`))
  const prior = gunzipSync(readFileSync(`${dir}/${arm}-prior-browser-product.html.gz`))
  return { arm, raw: bytes.length, gzip9: gzipSync(bytes, { level: 9 }).length, brotli11: brotliCompressSync(bytes, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } }).length, exactPriorBrowserBytes: bytes.equals(prior) }
})
const result = { builds: JSON.parse(readFileSync(`${dir}/STATUS.json`, 'utf8')), compression: 'Bun1.4.4 node:zlib; gzip9/BrotliQ11 on complete actual HTML bytes', publicRenderCalls: 0, rows, delta: Object.fromEntries(['raw', 'gzip9', 'brotli11'].map(key => [key, rows[1]![key] - rows[0]![key]])), scope: 'Equivalent full production build products; no runtime or build-speed ratio. Both exceed existing standalone gzip ceiling1334500; only PR actual CI status was followed.' }
writeFileSync(`${dir}/COMPARISON.json`, JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({ rows, delta: result.delta }))
