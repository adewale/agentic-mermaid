import pathlib,subprocess,os,json,gzip,time
out=pathlib.Path('/tmp/pr449-week-comparison-20261101/main-vs-pr-741-root-extension/production-builds');out.mkdir(exist_ok=True)
rows=[]
for arm,root,revision in [('main','/tmp/pr449-main-ci-base-f9ec8c115','f9ec8c115de14020d3c182d5d7f2e7e70bfcdefb'),('pr','/tmp/pr449-main-integration-20261029-762','741b80dba91c0e1f4feba9a62695f7820bc79a23')]:
 repo=pathlib.Path(root);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==revision
 html=repo/'editor.html';original=html.read_bytes();(out/(arm+'-prior-browser-product.html.gz')).write_bytes(gzip.compress(original))
 env=os.environ.copy();env.update(PATH='/tmp/pr449-campaign-bin:'+env['PATH'],NODE_ENV='production',AGENTIC_MERMAID_SCENE_ASSERTIONS='0',AM_EDITOR_BUILD_METAFILE=str(out/(arm+'-metafile.json')))
 env.pop('AM_EDITOR_RUNTIME_DIR',None);env.pop('AM_EDITOR_FONT_PREFIX',None)
 started=time.monotonic();result=None
 try:
  with open(out/(arm+'-build.log'),'w') as log:result=subprocess.run(['bun','run','scripts/site/editor.ts'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  if result.returncode:raise RuntimeError(arm+' build failed; retained log')
  (out/(arm+'-production.html.gz')).write_bytes(gzip.compress(html.read_bytes()))
 finally:
  html.write_bytes(original);assert html.read_bytes()==original
 rows.append({'arm':arm,'revision':revision,'exitCode':result.returncode if result else None,'wallSeconds':time.monotonic()-started,'priorHtmlRestoredByteExact':True})
(out/'STATUS.json').write_text(json.dumps({'rows':rows,'publicRenderCalls':0,'buildCalls':2,'commonEnv':{'NODE_ENV':'production','AGENTIC_MERMAID_SCENE_ASSERTIONS':'0','Bun':'1.4.4','runtimeDirectory':'unset','fontPrefix':'default'},'scope':'Same existing complete standalone build command and installed dependencies on each fixed source revision. No runtime/build-speed ratio.'},indent=2)+'\n')
print(json.dumps(rows))
