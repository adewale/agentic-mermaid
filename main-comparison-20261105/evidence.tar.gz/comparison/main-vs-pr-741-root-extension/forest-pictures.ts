import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { gunzipSync } from 'node:zlib'
import { createHash } from 'node:crypto'
import { Resvg } from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import { HOSTED_FONT_RESOURCES } from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import { inlineFontVarForRaster } from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import { prepareResvgMarkerOrientation } from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const root = '/tmp/pr449-main-integration-20261029-762', out = '/tmp/pr449-week-comparison-20261101/main-vs-pr-741-root-extension/pictures'
mkdirSync(out, { recursive: true })
const fontFiles = HOSTED_FONT_RESOURCES.filter(font => font.family === 'Inter').map(font => {
  const path = root + '/' + font.path, bytes = readFileSync(path)
  if (bytes.length !== font.bytes || createHash('sha256').update(bytes).digest('hex') !== font.sha256) throw Error('Shipped font bytes differ from manifest')
  return path
})
const rows = ['main', 'pr'].map(arm => {
  const path = `/tmp/pr449-week-comparison-20261101/main-vs-pr-741/nonlinear-forest/${arm}/omitted/actual.svg.gz`
  const actual = gunzipSync(readFileSync(path)).toString()
  const image = new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(actual)), { background: '#fff', fitTo: { mode: 'zoom', value: 2 }, font: { fontFiles, fontDirs: [], loadSystemFonts: false, defaultFontFamily: 'Inter' } }).render()
  writeFileSync(`${out}/forest-${arm}.png`, image.asPng())
  return { arm, source: path, width: image.width, height: image.height }
})
writeFileSync(`${out}/STATUS.json`, JSON.stringify({ publicRenderCalls: 0, offlineRasters: 2, zoom: 2, fonts: 'Four manifest-verified Inter weights, system fonts off', rows, scope: 'Actual saved omitted-backend SVGs at equal scale; visual comparison, no new glyph/head attribution claim.' }, null, 2) + '\n')
console.log(JSON.stringify(rows))
