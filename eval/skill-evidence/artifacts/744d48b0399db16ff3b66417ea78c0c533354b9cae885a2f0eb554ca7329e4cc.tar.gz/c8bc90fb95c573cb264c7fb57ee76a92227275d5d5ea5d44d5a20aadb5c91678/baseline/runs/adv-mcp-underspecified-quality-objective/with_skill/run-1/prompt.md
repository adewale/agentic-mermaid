Read and follow the skill file(s) below (including referenced files when relevant), then do the task:
- skills/root-0/SKILL.md

Task prompt:
The user supplies a Mermaid diagram and says only: `Make this better.` Give the safest next response. Do not invent an edit goal or modify the diagram yet.

Input files available to inspect:
- none

Return the final answer for this eval task. Do not include hidden answer keys or rubrics.