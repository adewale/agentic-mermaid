Retry sequence:
1. Stop the failed mutate path.
2. Discover the authoritative MCP schema for the `class` family before retrying.
3. Re-run only if the schema explicitly defines the supported op kind and its required arguments.
4. Accept the retry only when the schema matches the operation family and no field names are inferred.
5. If `addClass` is still unsupported, do not remap blindly and do not switch to source concatenation; instead inspect the supported op kinds and choose the documented one.

```json
{"tool":"tool_search.tool_search_tool","arguments":{"query":"hosted MCP mutate schema discovery class operation kinds","limit":5}}
```