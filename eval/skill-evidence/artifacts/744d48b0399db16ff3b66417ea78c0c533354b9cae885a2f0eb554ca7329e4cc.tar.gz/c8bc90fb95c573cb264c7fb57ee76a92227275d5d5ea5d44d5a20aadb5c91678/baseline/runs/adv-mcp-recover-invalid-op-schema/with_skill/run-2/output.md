Retry sequence:
1. Stop using the failed op as-is.
2. Discover the live registry first.
3. Identify the exact family that models the target edit.
4. Read that family’s mutation schema.
5. Rebuild the op strictly from the schema, with no guessed field names.
6. Retry `mutate`.
7. Accept only if the retry returns `ok:true` and the follow-up verification passes; otherwise discard the candidate and re-discover before trying again.

```json
{"tool":"am capabilities --json","arguments":{}}
```