Use the class-family schema instead of guessing.

Retry sequence:
1. Do not reissue `mutate` with `addClass`; that op kind is not valid in the current registry.
2. Call schema discovery for the class family only.
3. Inspect the returned operation names, discriminators, and required fields.
4. Retry `mutate` using the exact schema-defined op kind and field names.
5. Accept the edit only if the post-mutate verification passes; otherwise revert and stop.

Acceptance sequence:
1. Schema matches the live class family entry.
2. The op is explicitly listed by the schema.
3. The op object uses the documented discriminator and fields exactly.
4. `verify` or equivalent structural validation returns `ok: true`.
5. Only then serialize or proceed.

```json
{"tool":"describe_sdk","arguments":{"family":"class"}}
```