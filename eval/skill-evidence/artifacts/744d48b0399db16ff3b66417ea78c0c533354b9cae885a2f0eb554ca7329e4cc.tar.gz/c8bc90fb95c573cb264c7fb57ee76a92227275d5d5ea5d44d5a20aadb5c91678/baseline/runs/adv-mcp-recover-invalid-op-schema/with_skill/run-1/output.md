Retry and acceptance sequence:

1. Treat the failure as a schema mismatch, not a data error. `unknown op kind addClass` means the current mutate payload used an op name the hosted MCP does not recognize for that family.
2. Do not rename fields by guesswork and do not fall back to source concatenation.
3. Discover the live schema for the `class` family first.
4. Rebuild the mutation using only the discovered op kind and its exact argument shape.
5. Retry `mutate`.
6. Accept only if the retry returns `ok:true`.
7. Then run verification before any serialization or downstream use.

```json
{"tool":"describe_sdk","arguments":{"family":"class"}}
```