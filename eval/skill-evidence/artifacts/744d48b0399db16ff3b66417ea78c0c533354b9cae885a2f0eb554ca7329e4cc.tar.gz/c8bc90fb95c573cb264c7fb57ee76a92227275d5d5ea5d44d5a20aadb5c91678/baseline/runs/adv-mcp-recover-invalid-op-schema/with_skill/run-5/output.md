Retry sequence:
1. Re-run schema discovery for the `class` family with the hosted MCP `describe_sdk` call.
2. Read the returned mutation schema and accept only the documented op `kind` values for that family.
3. Retry `mutate` using one documented op at a time, preserving the existing source and avoiding any source concatenation.
4. Accept the retry only if the call returns `ok: true`; otherwise stop and re-discover before changing anything else.

Acceptance sequence:
1. `describe_sdk` returns a schema for `family: "class"`.
2. The op you choose is present in that schema.
3. The `mutate` retry returns `ok: true`.
4. If `ok` is false, do not infer field names or alternate op kinds.

```json
{"tool":"describe_sdk","arguments":{"family":"class"}}
```