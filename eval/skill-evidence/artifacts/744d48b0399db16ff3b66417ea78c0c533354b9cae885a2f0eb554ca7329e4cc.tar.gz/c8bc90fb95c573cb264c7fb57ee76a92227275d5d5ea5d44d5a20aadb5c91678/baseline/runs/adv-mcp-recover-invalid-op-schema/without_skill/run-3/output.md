Retry sequence:
1. Treat the failure as a schema mismatch, not a transient transport error.
2. Discover the mutate operation schema first.
3. Rebuild the request from the discovered schema only.
4. Retry with a single, minimal op that is explicitly listed by the schema.
5. Accept only a response that returns `ok: true` and no `error`; otherwise stop and rediscover rather than guessing field names or concatenating source.

Acceptance sequence:
1. Confirm the schema exposes the op kind you intend to use.
2. Confirm required fields and nesting from the schema, not from prior assumptions.
3. Send one op only.
4. Accept the result only if the server acknowledges it without an error payload.
5. If the op kind is absent or rejected, do not improvise a fallback shape.

```json
{"tool":"tool_search","arguments":{"query":"hosted MCP mutate schema discover op kinds class addClass unknown op kind"}}