Retry sequence:

1. Treat the failure as an op-schema mismatch for the `class` family, not as a bad payload to patch by guessing.
2. Do not retry `mutate` with invented fields or fall back to source concatenation.
3. Discover the live mutation schema for the `class` family first.
4. Rebuild the op strictly from the discovered schema.
5. Retry `mutate`.
6. Accept only if the returned result is `ok:true`, then run verification/serialization as applicable.

Acceptance sequence:

1. `mutate` returns `ok:true`.
2. Structural verification passes.
3. Only then serialize or emit downstream output.

```json
{"tool":"describe_sdk","arguments":{"family":"class"}}
```