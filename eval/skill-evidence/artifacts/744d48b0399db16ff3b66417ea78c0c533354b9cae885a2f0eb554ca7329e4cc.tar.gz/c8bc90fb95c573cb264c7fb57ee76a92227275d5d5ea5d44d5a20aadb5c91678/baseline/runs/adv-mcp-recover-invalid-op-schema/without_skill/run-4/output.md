Retry sequence:
1. Treat the failure as a schema mismatch, not a content error.
2. Do not infer or rename fields, and do not switch to source concatenation.
3. Ask the hosted MCP layer for the mutation schema or op-kind registry first.
4. Only retry the mutate call after confirming the supported op kind and exact payload shape.
5. Accept the retry only if the schema-discovery result explicitly includes the valid class-op kind and its required arguments, and the next mutate call returns `ok: true` without fallback coercion.

```json
{"tool":"tool_search.tool_search_tool","arguments":{"query":"hosted MCP mutate schema discovery supported op kinds class addClass unknown op kind"}}