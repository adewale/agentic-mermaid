Retry sequence:
1. Stop the failed mutate path immediately.
2. Perform schema discovery for the hosted MCP mutate tool, with no assumptions about op names or field names.
3. Confirm whether `addClass` exists in the supported op kinds.
4. If it does not exist, do not synthesize a replacement or concatenate source; instead, wait for the documented op name and required argument schema.
5. Re-issue the mutate call only after the schema is verified.

Acceptance sequence:
1. The schema-discovery call returns the exact mutate contract.
2. The supported op kind is explicitly listed.
3. All required fields are present in the schema, with no inferred names.
4. The retry passes validation or dry-run, if available.
5. The mutate call returns `ok:true` and the resulting state matches the intended change.

```json
{"tool":"tool_search_tool","arguments":{"query":"hosted MCP mutate schema op kinds addClass unknown op kind"}}