Retry and acceptance sequence:

1. Re-discover the MCP schema for the mutate family before changing anything.
2. Confirm the exact supported operation kind names from the schema, and do not infer `addClass` or any field names.
3. Retry the mutate call only with a schema-confirmed op kind and payload shape.
4. Accept only a response with `ok:true`; if it still fails, stop and re-discover rather than guessing or concatenating source.

```json
{"tool":"tool_search.tool_search_tool","arguments":{"query":"MCP mutate schema discovery operation kinds class family","limit":5}}
```