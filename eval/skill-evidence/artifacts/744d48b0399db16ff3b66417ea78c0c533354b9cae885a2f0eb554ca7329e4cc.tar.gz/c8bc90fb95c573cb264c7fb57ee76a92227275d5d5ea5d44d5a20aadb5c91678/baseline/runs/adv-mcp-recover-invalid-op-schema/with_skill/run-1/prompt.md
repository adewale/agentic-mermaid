Read and follow the skill file(s) below (including referenced files when relevant), then do the task:
- skills/root-0/SKILL.md

Task prompt:
A hosted MCP mutate call failed with `{ ok:false, family:'class', opIndex:0, error:'unknown op kind addClass' }`. Recover safely without guessing field names or switching to source concatenation. State the retry and acceptance sequence. End with one fenced JSON object containing exactly `{"tool": <next tool>, "arguments": <argument object>}` for the immediate schema-discovery call.

Input files available to inspect:
- none

Return the final answer for this eval task. Do not include hidden answer keys or rubrics.