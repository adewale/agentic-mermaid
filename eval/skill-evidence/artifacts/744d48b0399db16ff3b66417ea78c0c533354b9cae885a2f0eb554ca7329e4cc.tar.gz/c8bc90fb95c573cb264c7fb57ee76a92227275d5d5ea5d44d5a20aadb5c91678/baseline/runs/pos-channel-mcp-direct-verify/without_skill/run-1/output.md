The hosted Agentic Mermaid MCP server was not available in the tool registry here, so I could not run validation and I will not claim it ran.

Cheapest direct request, if the server were available, would be a single validation call with only the Mermaid source text:
- `flowchart TD\n  API --> DB`

No response fields were returned, so there are no actual `family` or diagnostics fields to cite. If the server had responded, the fields I would look for are the ones that explicitly report the detected diagram family and any validation diagnostics or errors.

```json
{"tool":"unavailable","arguments":{"reason":"Hosted Agentic Mermaid MCP server was not exposed in this workspace's tool registry, so no validation request could be issued."}}
```