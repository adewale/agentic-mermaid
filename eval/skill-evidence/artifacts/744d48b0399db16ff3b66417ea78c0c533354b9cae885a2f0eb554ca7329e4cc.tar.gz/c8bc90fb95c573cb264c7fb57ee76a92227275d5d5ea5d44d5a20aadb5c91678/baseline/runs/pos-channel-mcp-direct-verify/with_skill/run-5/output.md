I could not actually reach the hosted Agentic Mermaid MCP server from this environment, so I am not claiming a successful validation run.

Cheapest direct request, if the server is available, is a single `verify` call on the source:
- `source: "flowchart TD\n  API --> DB"`

For the result, the fields to inspect are:
- `family` or `kind` for the detected diagram family
- `ok` and `warnings` for diagnostics

If the server is unavailable, the correct outcome is to report that unavailability rather than inventing a verification result.

```json
{"tool":"verify","arguments":{"source":"flowchart TD\n  API --> DB"}}
```