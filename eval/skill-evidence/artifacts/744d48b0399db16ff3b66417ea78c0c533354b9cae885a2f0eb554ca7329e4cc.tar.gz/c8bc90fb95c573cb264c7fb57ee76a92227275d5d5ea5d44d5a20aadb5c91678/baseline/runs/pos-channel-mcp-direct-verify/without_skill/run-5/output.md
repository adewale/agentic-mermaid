The hosted Agentic Mermaid MCP server is not available in this workspace, so I cannot make the validation call or report real response fields.

Cheapest direct request, if the server were available, would be a single validation call with only the Mermaid source:
```json
{"tool":"<unavailable>","arguments":{"source":"flowchart TD\n  API --> DB"}}
```

