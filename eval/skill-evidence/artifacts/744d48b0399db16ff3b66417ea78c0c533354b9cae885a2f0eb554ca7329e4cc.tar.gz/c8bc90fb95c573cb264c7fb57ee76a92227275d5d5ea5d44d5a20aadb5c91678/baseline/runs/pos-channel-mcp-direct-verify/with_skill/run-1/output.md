I could not actually call the hosted Agentic Mermaid MCP server from this environment, so I am not claiming a live validation result.

Cheapest direct request, if the server is available, is a single `verify` call on the source:

- Tool: `verify`
- Arguments: `{"source":"flowchart TD\n  API --> DB"}`

The fields that establish the result are:

- Family detection: the parsed diagram’s family field, typically `kind` on the returned diagram object
- Diagnostics: `ok` and `warnings`
- If present, `layout` is additional structural output, not the primary diagnostic signal

```json
{"tool":"verify","arguments":{"source":"flowchart TD\n  API --> DB"}}
```