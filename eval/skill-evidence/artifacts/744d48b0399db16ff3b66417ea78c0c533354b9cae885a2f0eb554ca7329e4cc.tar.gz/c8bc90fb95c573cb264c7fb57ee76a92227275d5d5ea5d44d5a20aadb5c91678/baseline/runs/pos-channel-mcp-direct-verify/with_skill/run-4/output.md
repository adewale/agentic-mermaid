I couldn’t directly execute the hosted Agentic Mermaid MCP server from this environment, so I’m not going to claim a successful run.

For this snippet, the cheapest direct request would be a single `verify` call against the source:
- `flowchart TD
  API --> DB`

If the server responds, the fields that establish what you asked for are:
- Detected family: `kind` or `family` on the parsed diagram result
- Diagnostics: `ok` plus `warnings` from the verification result

```json
{"tool":"verify","arguments":{"source":"flowchart TD\n  API --> DB"}}
```