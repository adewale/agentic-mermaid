No callable Mermaid MCP tool was available in this session, so I could not run the validation request and I will not claim the server ran.

The cheapest direct request, if the hosted Agentic Mermaid MCP server were exposed, would be the minimal validation call with the raw diagram text only:
- diagram: `flowchart TD\n  API --> DB`

Because the server was unavailable here, there is no response to inspect, so I cannot identify actual family or diagnostic fields from execution. If the tool had been available, I would have looked for the returned fields that explicitly name the detected family and any diagnostics list or error/warning payload.

```json
{"tool":"unavailable","arguments":{"diagram":"flowchart TD\n  API --> DB"}}
```