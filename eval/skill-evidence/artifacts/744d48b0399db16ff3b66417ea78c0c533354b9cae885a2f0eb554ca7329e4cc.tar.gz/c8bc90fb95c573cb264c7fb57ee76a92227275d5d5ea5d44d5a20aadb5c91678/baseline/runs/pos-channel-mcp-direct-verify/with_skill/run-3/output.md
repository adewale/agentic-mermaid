I couldn’t confirm the hosted Agentic Mermaid MCP server from this environment, so I did not claim execution.

Cheapest direct validation request:
- Tool: `verify`
- Arguments: the raw Mermaid source only

Fields to look for in the response:
- `family`: the detected diagram family
- `ok` and `warnings`: the diagnostics for a structurally valid result
- `error`: the diagnostics if parsing or validation fails

```json
{"tool":"verify","arguments":{"source":"flowchart TD\n  API --> DB"}}
```