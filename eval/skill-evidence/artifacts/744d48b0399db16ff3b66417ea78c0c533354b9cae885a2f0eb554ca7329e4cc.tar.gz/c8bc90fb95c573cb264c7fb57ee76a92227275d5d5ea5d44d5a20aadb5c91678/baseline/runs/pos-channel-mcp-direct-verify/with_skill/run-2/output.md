I could not confirm access to the hosted Agentic Mermaid MCP server from this environment, so I am not claiming it ran.

The cheapest direct request is `verify` with the source only. The response fields to look at are:
- `kind` or `family` for the detected diagram family, depending on the server’s envelope
- `ok` and `warnings` for diagnostics

```json
{"tool":"verify","arguments":{"source":"flowchart TD\n  API --> DB"}}
```