Accept the returned source only if these embedded verification fields pass: `parse.ok == true`, `mutate.ok == true`, and `verify.ok == true` for the structured result.

```json
{"tool":"mutate","arguments":{"source":"stateDiagram-v2\n  [*] --> Idle\n  Idle --> Processing: start\n  Processing --> Complete: done\n  Complete --> [*]\n","operations":[{"kind":"add_node","id":"Failed","label":"Failed"},{"kind":"add_edge","from":"Processing","to":"Failed"}]}}
```