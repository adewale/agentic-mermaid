I can’t actually invoke a hosted Agentic Mermaid MCP tool from the available workspace tools here, so I can’t claim execution or returned source. The embedded verification fields that should pass before accepting any returned source are the diagram-level checks for:
- `stateDiagram-v2` syntax validity
- presence of `Processing --> Failed`
- `Failed` being terminal, with a terminal marker path from that state
- preservation of the existing `Idle`, `Processing`, and `Complete` flow

```json
{"tool":"unavailable","arguments":{"source":"stateDiagram-v2\n  [*] --> Idle\n  Idle --> Processing: start\n  Processing --> Complete: done\n  Processing --> Failed: fail\n  Complete --> [*]\n  Failed --> [*]","verification":["stateDiagram-v2 syntax valid","includes Processing-->Failed transition","Failed is terminal","existing states and transitions preserved"]}}
```