I cannot honestly name a hosted Agentic Mermaid MCP tool from the tools exposed in this session, so I’m not fabricating one. The requested source change is:

- add `Failed` as an unsuccessful terminal state
- add a failure transition from `Processing` to `Failed`
- if terminality is represented explicitly in this diagram style, `Failed --> [*]` should also be present

The returned source should be accepted only if the embedded verification fields confirm:
- the diagram remains `stateDiagram-v2`
- `Failed` exists as a state
- a `Processing` to `Failed` transition exists
- the existing `Idle`, `Processing`, and `Complete` paths are preserved
- the output source is structurally valid Mermaid for the same diagram type

```json
{"tool":"UNAVAILABLE_IN_THIS_SESSION","arguments":{"sourceFile":"inputs/input.mmd","edits":[{"type":"add_state","name":"Failed","terminal":true},{"type":"add_transition","from":"Processing","to":"Failed","label":"fail"}],"verification":{"mustContain":["stateDiagram-v2","Failed","Processing --> Failed"],"mustPreserve":["[*] --> Idle","Idle --> Processing: start","Processing --> Complete: done","Complete --> [*]"],"mustBeValidMermaid":true}}}
```