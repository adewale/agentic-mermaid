Verification fields that must pass before accepting returned source:
- `stateDiagram-v2` remains the diagram type.
- A terminal state `Failed` is present.
- A transition `Processing --> Failed` is present.
- Existing states/transitions `Idle`, `Processing`, `Complete`, and the terminal end `Complete --> [*]` remain intact.

```json
{"tool":"agentic_mermaid_mcp","arguments":{"source_path":"inputs/input.mmd","edits":[{"type":"add_state","id":"Failed","terminal":true},{"type":"add_transition","from":"Processing","to":"Failed"}],"verification":{"must_contain":["stateDiagram-v2","Failed","Processing --> Failed","Complete --> [*]"],"must_preserve":["Idle --> Processing: start","Processing --> Complete: done","[*] --> Idle","Complete --> [*]"]}}}
```