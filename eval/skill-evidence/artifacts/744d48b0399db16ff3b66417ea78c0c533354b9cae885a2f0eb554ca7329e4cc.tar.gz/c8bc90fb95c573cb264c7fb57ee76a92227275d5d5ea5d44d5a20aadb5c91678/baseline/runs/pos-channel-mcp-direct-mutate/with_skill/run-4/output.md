Accept only if the returned `verify` payload satisfies all of these embedded checks:

- `ok === true`
- `warnings.length === 0`
- `layout` is present

Requested edit:
- add state `Failed`
- add transition `Processing --> Failed`

```json
{"tool":"mutate","arguments":{"source":"stateDiagram-v2\n  [*] --> Idle\n  Idle --> Processing: start\n  Processing --> Complete: done\n  Complete --> [*]","ops":[{"kind":"add_node","id":"Failed","label":"Failed"},{"kind":"add_edge","from":"Processing","to":"Failed"}]}}
```