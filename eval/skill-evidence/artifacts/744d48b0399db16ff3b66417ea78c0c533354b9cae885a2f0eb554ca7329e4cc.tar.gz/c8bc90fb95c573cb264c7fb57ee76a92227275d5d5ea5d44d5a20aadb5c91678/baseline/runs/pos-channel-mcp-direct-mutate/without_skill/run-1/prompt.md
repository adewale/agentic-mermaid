Do not use any skill. No skill files are present in this workspace.

Task prompt:
Use the attached state-diagram source. On hosted Agentic Mermaid MCP, add an unsuccessful terminal state named Failed and a failure transition from Processing into it in one structured request. This uses known fields and no custom control flow. Show which embedded verification fields must pass before accepting returned source; do not fabricate a response. End with one fenced JSON object containing exactly `{"tool": <selected tool>, "arguments": <argument object>}`.

Input files available to inspect:
- inputs/input.mmd

Return the final answer for this eval task. Do not include hidden answer keys or rubrics.