The hosted Mermaid MCP tool itself is not exposed in this workspace, so I can only provide the structured request envelope, not a fabricated tool response.

Embedded verification fields that should pass before accepting returned source:
- `sourceIncludesNode: "Failed"`
- `sourceIncludesTransition: "Processing --> Failed"`
- `sourcePreservesNode: "Complete"`
- `sourcePreservesTransition: "Processing --> Complete: done"`
- `sourcePreservesStartEnd: true`

```json
{"tool":"agentic-mermaid-mcp.update_source","arguments":{"source":"stateDiagram-v2\n  [*] --> Idle\n  Idle --> Processing: start\n  Processing --> Complete: done\n  Processing --> Failed\n  Complete --> [*]\n  Failed --> [*]","verification":{"sourceIncludesNode":"Failed","sourceIncludesTransition":"Processing --> Failed","sourcePreservesNode":"Complete","sourcePreservesTransition":"Processing --> Complete: done","sourcePreservesStartEnd":true}}}
```