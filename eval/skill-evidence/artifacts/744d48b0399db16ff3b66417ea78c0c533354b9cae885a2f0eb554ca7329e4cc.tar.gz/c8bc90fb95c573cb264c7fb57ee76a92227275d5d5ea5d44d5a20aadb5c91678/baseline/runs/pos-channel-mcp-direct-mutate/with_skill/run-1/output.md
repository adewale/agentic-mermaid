Accept the returned source only if `verify.ok === true`. Also inspect `verify.warnings` and `verify.layout` before accepting the serialization.

```json
{"tool":"mutate","arguments":{"source":"stateDiagram-v2\n  [*] --> Idle\n  Idle --> Processing: start\n  Processing --> Complete: done\n  Complete --> [*]","op":{"kind":"add_state","id":"Failed"},"ops":[{"kind":"add_transition","from":"Processing","to":"Failed","label":"failure"},{"kind":"add_transition","from":"Failed","to":"[*]"}]}}
```