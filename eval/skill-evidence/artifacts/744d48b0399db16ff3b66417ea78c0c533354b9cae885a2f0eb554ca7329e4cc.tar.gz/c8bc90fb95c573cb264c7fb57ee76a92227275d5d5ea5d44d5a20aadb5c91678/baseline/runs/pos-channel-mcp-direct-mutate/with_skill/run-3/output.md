Required verification gates before accepting returned source:
- `parseRegisteredMermaid(...).ok` must be `true`
- `mutate(...).ok` must be `true`
- `verifyMermaid(...).ok` must be `true`

Selected tool: `execute`

```json
{"tool":"execute","arguments":{"code":"const source = `stateDiagram-v2\n  [*] --> Idle\n  Idle --> Processing: start\n  Processing --> Complete: done\n  Complete --> [*]`\nconst parsed = mermaid.parseRegisteredMermaid(source)\nif (!parsed.ok) return { phase: 'parse', errors: parsed.error }\nconst state = mermaid.asState(parsed.value)\nif (!state) return { phase: 'narrow', kind: parsed.value.kind }\nconst op = { kind: 'add_node', id: 'Failed', label: 'Failed', terminal: true }\nconst next1 = mermaid.mutate(state, op)\nif (!next1.ok) return { phase: 'mutate', op, error: next1.error }\nconst next2 = mermaid.mutate(next1.value, { kind: 'add_edge', from: 'Processing', to: 'Failed', label: 'failure' })\nif (!next2.ok) return { phase: 'mutate', op: { kind: 'add_edge', from: 'Processing', to: 'Failed', label: 'failure' }, error: next2.error }\nconst verify = mermaid.verifyMermaid(next2.value)\nif (!verify.ok) return { phase: 'verify', warnings: verify.warnings, layout: verify.layout }\nreturn { source: mermaid.serializeMermaid(next2.value), verify }"}}}
```