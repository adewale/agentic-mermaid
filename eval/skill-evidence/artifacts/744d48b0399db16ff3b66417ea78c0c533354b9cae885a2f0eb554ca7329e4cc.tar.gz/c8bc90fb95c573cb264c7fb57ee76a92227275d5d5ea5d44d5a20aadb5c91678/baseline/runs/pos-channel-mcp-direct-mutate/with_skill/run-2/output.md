Accept the returned source only if embedded verification reports `ok: true`, with no blocking items in `warnings`, and a populated `layout`.

```json
{"tool":"hosted-agentic-mermaid-mcp.mutate","arguments":{"source":"stateDiagram-v2\n  [*] --> Idle\n  Idle --> Processing: start\n  Processing --> Complete: done\n  Complete --> [*]","ops":[{"kind":"add_state","id":"Failed","label":"Failed","terminal":true},{"kind":"add_transition","from":"Processing","to":"Failed","label":"failure"}]}}
```