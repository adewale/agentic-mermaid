Do not use any skill. No skill files are present in this workspace.

Task prompt:
Help me write a small TypeScript function that orders a list of users by their most recent sign-in timestamp, newest first. This task has no diagrams, no Mermaid, and no live editor work. Answer without using any Agentic Mermaid-specific workflow.

Input files available to inspect:
- none

Return the final answer for this eval task. Do not include hidden answer keys or rubrics.