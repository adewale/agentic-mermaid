```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | number | Date;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort(
    (a, b) =>
      new Date(b.lastSignInAt).getTime() - new Date(a.lastSignInAt).getTime()
  );
}
```

If you want `null` or `undefined` timestamps to go last, use this version:

```ts
type User = {
  id: string;
  name: string;
  lastSignInAt?: string | number | Date | null;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : -Infinity;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : -Infinity;
    return bTime - aTime;
  });
}
```

Example:

```ts
const ordered = orderUsersByMostRecentSignIn([
  { id: "1", name: "Ada", lastSignInAt: "2026-07-27T10:00:00Z" },
  { id: "2", name: "Ben", lastSignInAt: "2026-07-28T09:00:00Z" },
  { id: "3", name: "Cleo", lastSignInAt: "2026-07-26T12:00:00Z" },
]);
```

`ordered` will be `Ben`, `Ada`, `Cleo`.