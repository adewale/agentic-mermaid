```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | Date | null;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : 0;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : 0;
    return bTime - aTime;
  });
}
```

Example:

```ts
const users = [
  { id: "1", name: "Ava", lastSignInAt: "2026-07-20T10:15:00Z" },
  { id: "2", name: "Ben", lastSignInAt: "2026-07-25T08:30:00Z" },
  { id: "3", name: "Chen", lastSignInAt: null },
];

const sorted = orderUsersByMostRecentSignIn(users);
// Ben, Ava, Chen
```

If you want, I can also give you:
1. a version that treats missing timestamps as `undefined`
2. a generic comparator you can reuse elsewhere