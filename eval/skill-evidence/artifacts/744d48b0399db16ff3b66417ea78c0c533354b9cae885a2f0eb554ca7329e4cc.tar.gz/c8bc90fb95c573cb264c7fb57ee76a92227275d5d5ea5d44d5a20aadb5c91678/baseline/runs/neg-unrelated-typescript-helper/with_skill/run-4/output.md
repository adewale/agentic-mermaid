```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | Date | null;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : 0;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : 0;
    return bTime - aTime;
  });
}
```

Example:

```ts
const users = [
  { id: "1", name: "Alice", lastSignInAt: "2026-07-20T10:00:00Z" },
  { id: "2", name: "Bob", lastSignInAt: "2026-07-28T09:30:00Z" },
  { id: "3", name: "Cara", lastSignInAt: null },
];

const sorted = orderUsersByMostRecentSignIn(users);
// Bob, Alice, Cara
```

If you want, I can also give you a version that is:
1. strongly typed for your exact user shape
2. safe against invalid date strings
3. written as an in-place sort instead of returning a copy