```ts
type User = {
  id: string;
  name: string;
  lastSignIn: string | Date | null;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignIn ? new Date(a.lastSignIn).getTime() : -Infinity;
    const bTime = b.lastSignIn ? new Date(b.lastSignIn).getTime() : -Infinity;
    return bTime - aTime;
  });
}
```

This returns a new array sorted newest first. Users with no sign-in timestamp are placed at the end.

If you want, I can also provide:
1. a version that handles invalid dates safely
2. a generic comparator version
3. a mutation-in-place version using `users.sort(...)`