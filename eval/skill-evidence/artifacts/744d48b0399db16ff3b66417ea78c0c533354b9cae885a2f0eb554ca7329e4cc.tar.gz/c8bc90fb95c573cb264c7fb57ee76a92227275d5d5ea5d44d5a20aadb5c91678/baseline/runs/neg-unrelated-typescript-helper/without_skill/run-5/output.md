```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | null;
};

export function orderUsersByRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? Date.parse(a.lastSignInAt) : -Infinity;
    const bTime = b.lastSignInAt ? Date.parse(b.lastSignInAt) : -Infinity;
    return bTime - aTime; // newest first
  });
}
```

If you want, I can also give you:
1. a version that handles invalid timestamps safely,
2. a generic version for any object shape,
3. a version that sorts in place instead of returning a copy.