```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | null; // ISO timestamp or null
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? Date.parse(a.lastSignInAt) : -Infinity;
    const bTime = b.lastSignInAt ? Date.parse(b.lastSignInAt) : -Infinity;
    return bTime - aTime; // newest first
  });
}
```

If you want to handle invalid timestamps more defensively, use a helper:

```ts
type User = {
  id: string;
  name: string;
  lastSignInAt?: string | null;
};

function toTime(value?: string | null): number {
  if (!value) return -Infinity;
  const time = Date.parse(value);
  return Number.isFinite(time) ? time : -Infinity;
}

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => toTime(b.lastSignInAt) - toTime(a.lastSignInAt));
}
```

This returns a new array and leaves the input unchanged.