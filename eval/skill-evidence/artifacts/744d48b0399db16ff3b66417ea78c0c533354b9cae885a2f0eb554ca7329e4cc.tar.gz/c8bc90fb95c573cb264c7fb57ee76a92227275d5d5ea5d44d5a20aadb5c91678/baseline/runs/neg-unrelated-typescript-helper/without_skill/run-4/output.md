```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | number | Date | null;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const timeA = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : -Infinity;
    const timeB = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : -Infinity;
    return timeB - timeA;
  });
}
```

Notes:
- Returns a new array and does not mutate the input.
- Sorts newest first.
- Users with `null` or missing sign-in times go to the end.

If you want, I can also give you:
1. a version that works with a different user shape
2. a version that handles invalid dates explicitly
3. a tiny unit test for this function