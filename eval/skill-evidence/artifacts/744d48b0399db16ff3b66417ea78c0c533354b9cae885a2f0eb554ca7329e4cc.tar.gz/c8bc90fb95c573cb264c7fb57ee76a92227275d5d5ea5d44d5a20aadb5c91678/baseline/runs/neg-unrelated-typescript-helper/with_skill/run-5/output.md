```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | Date | null;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : 0;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : 0;
    return bTime - aTime; // newest first
  });
}
```

Example:

```ts
const ordered = orderUsersByMostRecentSignIn([
  { id: "1", name: "Ava", lastSignInAt: "2026-07-27T10:00:00Z" },
  { id: "2", name: "Ben", lastSignInAt: "2026-07-28T09:00:00Z" },
  { id: "3", name: "Cam", lastSignInAt: null },
]);
```

If you want, I can also give you a version that handles invalid dates explicitly instead of treating missing timestamps as oldest.