Use the local filesystem-backed Agentic Mermaid surface, not the hosted MCP surface.

Why:
- The hosted MCP endpoint cannot accept a 90 KB Mermaid payload reliably.
- It also cannot write arbitrary files on the user’s machine, so it is the wrong execution surface for this task.

Fallback:
- Generate or edit the Mermaid diagram locally in the workspace using the local file-writing path, then write the full diagram directly to the target file on disk.
- If that surface is unavailable, the task is blocked at the tooling layer, not by the diagram itself. The correct fallback is local file I/O, not splitting the diagram across multiple remote calls.