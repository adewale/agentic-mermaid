Use the **CLI surface**.

Reason: the hosted MCP endpoint has a **64 KB input cap** and is not suitable for a **90 KB Mermaid source**, and it also cannot write arbitrary files on the user’s machine. The skill’s routing says that when you have shell access, the correct fallback is **`agentic-mermaid` CLI** (`references/cli.md`), which works locally and can write the diagram directly to a file.

Fallback plan:
- Use the local CLI to read the Mermaid source from disk or stdin.
- Run local parse/verify/render steps as needed.
- Write the final `.mmd` file on the user’s machine from the local process.

Do **not** try to split the diagram across multiple hosted MCP calls.