Read and follow the skill file(s) below (including referenced files when relevant), then do the task:
- skills/root-0/SKILL.md

Task prompt:
You must edit and write a 90 KB Mermaid diagram to a file on the user's machine. The hosted MCP endpoint rejects an input that large and cannot write arbitrary files. Choose the correct Agentic Mermaid surface and explain the fallback; do not suggest splitting the diagram across remote calls.

Input files available to inspect:
- none

Return the final answer for this eval task. Do not include hidden answer keys or rubrics.