Use the **CLI** surface, not hosted MCP.

Why:
- The hosted MCP endpoint has a **64 KB input cap**, so a **90 KB Mermaid diagram will be rejected**.
- It is also **stateless** and **cannot write arbitrary files** on the user’s machine.
- The skill explicitly says that when you have shell access, the correct fallback is **CLI**.

Fallback:
- Run the diagram work locally with `am` on the user’s machine, then write the result directly to the target file.
- Keep the full diagram source local and process it in one shot; **do not split it across remote calls**.

A practical local flow is:
- load or author the full Mermaid source locally
- verify/render with `am`
- write the output file directly from the local environment

If you want, I can give the exact `am` command sequence for a 90 KB source file.