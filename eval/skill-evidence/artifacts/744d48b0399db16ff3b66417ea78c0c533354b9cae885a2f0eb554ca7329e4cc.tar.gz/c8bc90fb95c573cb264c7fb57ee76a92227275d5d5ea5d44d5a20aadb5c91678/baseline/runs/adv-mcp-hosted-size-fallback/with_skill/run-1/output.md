Use the **local Agentic Mermaid surface**, not the hosted MCP endpoint.

- **Best choice:** `CLI` if you only need shell access, or the `library` if you can run JS/TS locally.
- **Why:** the hosted MCP at `https://agentic-mermaid.dev/mcp` has a **64 KB input cap** and cannot write arbitrary files, so it is the wrong surface for a **90 KB** diagram that must be written to the user’s machine.
- **Fallback:** do the edit and file write **locally** with `am` or the SDK, then verify/render from that local file. Keep the diagram in one local artifact and avoid remote round-tripping.

If you want the most direct path, use:
1. local file write of the full Mermaid source,
2. local `am` parse/verify/render,
3. local save of the final `.mmd` file.

I am not suggesting splitting the diagram across remote calls, because that would fail the size constraint and is not needed here.