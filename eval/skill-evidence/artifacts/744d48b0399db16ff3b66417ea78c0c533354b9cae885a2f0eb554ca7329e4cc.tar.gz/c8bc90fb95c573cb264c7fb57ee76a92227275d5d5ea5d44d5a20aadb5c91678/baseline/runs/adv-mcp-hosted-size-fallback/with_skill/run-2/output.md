Use the local **Agentic Mermaid CLI** surface, not the hosted MCP endpoint.

Reason:
- The hosted MCP endpoint is capped at **64 KB input**, so a **90 KB** Mermaid source payload will be rejected.
- You also need to **write to a file on the user’s machine**, which hosted MCP cannot do directly.
- The correct fallback is the **local CLI** surface, which can work with local files and avoids the hosted input cap.

Fallback path:
- Put the full Mermaid source in a local `.mmd` file.
- Run the local Agentic Mermaid CLI against that file for verify/render/edit.
- Write the result back to the file on disk locally.

I am not suggesting splitting the diagram across remote calls, because that would not solve the hosted MCP size limit and would not satisfy the local file write requirement.