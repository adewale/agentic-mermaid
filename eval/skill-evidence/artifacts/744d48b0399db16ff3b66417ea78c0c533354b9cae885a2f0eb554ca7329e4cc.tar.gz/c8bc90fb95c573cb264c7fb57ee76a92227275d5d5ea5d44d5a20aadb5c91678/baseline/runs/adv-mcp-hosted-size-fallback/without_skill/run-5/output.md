Use the local code-editing surface, not the hosted MCP Mermaid endpoint.

Reason:
- The hosted MCP endpoint rejects payloads around 90 KB and cannot write arbitrary files.
- The correct fallback is a filesystem-backed agentic edit on the user’s machine, where the diagram can be written directly to a local file.

Fallback plan:
- Open or create the target file locally.
- Apply the Mermaid content with a local file edit tool or shell write on the workspace filesystem.
- Verify the resulting file on disk.

I would not split this across remote calls. The remote surface is simply the wrong transport for a 90 KB diagram with a file-write requirement.