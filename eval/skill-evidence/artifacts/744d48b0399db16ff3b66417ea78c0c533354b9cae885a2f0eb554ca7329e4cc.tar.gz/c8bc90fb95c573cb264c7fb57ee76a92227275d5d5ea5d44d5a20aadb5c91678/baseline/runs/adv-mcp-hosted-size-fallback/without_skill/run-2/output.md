Use the local file-editing surface, not the hosted MCP Mermaid endpoint.

Reason:
- The hosted MCP endpoint rejects inputs around 90 KB and cannot write arbitrary files.
- The correct fallback is to write the diagram directly to a file on the user’s machine using the local workspace filesystem, then edit it there as a normal file operation.
- I would not split the diagram across remote calls, since that does not solve the endpoint limit and would still leave you unable to create the final file cleanly.

If you want, I can proceed with the local-file approach once you provide the Mermaid content or the target path.