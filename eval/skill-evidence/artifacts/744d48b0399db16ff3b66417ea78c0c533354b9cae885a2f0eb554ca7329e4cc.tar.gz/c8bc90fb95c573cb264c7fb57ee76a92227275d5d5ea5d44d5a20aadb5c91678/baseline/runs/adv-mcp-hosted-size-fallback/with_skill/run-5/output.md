Use the **local CLI surface** for this case, not the hosted MCP.

Reason:
- The hosted MCP endpoint has a **64 KB input cap**, so a 90 KB Mermaid diagram will be rejected.
- It also **cannot write arbitrary files** on the user’s machine.
- The correct fallback is the **Agentic Mermaid CLI** running locally, which can read the diagram from disk, process it, and write the result back to a file directly.

Recommended fallback path:
- Use `am` locally from shell.
- Treat the diagram as a file-based artifact, not a remote payload.
- Do the edit/serialize/write entirely on the local filesystem.

What not to do:
- Do **not** split the diagram across multiple remote MCP calls.
- Do **not** try to force it through hosted MCP `mutate` / `build` with the full 90 KB source.

If you want the exact operational choice in one line: **local CLI with file-based editing and output writing** is the correct Agentic Mermaid surface for a 90 KB diagram.