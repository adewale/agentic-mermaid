Use the local filesystem-backed Agentic Mermaid surface, not the hosted MCP endpoint.

Why:
- The hosted MCP path rejects a 90 KB input.
- It also cannot write arbitrary files on the user’s machine.
- A local editor/filesystem surface can write the diagram directly to a file in the workspace.

Fallback:
- Write the Mermaid source directly to a local file on the machine via the workspace-editing path.
- Do not split the diagram across multiple remote calls; that just moves the same size problem around and still leaves you without a direct file write.

If you need the exact implementation choice in one line: pick the surface that has direct local file write access, and avoid any remote-only Mermaid execution path.