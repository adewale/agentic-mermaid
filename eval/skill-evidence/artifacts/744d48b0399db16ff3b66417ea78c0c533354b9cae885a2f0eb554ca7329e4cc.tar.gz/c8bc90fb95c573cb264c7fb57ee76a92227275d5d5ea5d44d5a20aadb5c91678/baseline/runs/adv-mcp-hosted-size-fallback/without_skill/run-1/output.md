Use the local filesystem edit surface, not the hosted MCP endpoint.

Fallback:
- The hosted MCP route is the wrong surface here because it rejects ~90 KB inputs and cannot write arbitrary files.
- The correct approach is to write the Mermaid diagram directly to a local file on the user’s machine through the agent’s filesystem-editing path, in one local write operation.
- Do not split the diagram across remote calls.

I can’t perform the actual write in this run because the workspace is read-only and no target file was provided, but the surface choice is the local file-edit path, not hosted MCP.