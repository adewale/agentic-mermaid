I could not access a hosted Agentic Mermaid MCP tool in this environment, so I did not receive any semantic fact lines to relay.

```json
{"tool":"agentic-mermaid-mcp","arguments":{"input":"sequenceDiagram\n  Alice->>Bob: Hi","output":"compact deterministic semantic fact lines","preserve_input":true,"render":false}}
```