No hosted Mermaid MCP callable was exposed in the available toolset, so I could not actually send the request.

```json
{"tool":"unavailable","arguments":{"diagram":"sequenceDiagram\n  Alice->>Bob: Hi","request":"compact deterministic semantic fact lines","change_diagram":false,"render":false}}
```