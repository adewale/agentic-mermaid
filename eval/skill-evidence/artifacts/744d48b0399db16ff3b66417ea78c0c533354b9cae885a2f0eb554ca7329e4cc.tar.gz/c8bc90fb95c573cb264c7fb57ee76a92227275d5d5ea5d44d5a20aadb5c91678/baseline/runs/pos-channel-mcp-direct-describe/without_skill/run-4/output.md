I could not access a hosted Agentic Mermaid MCP tool from this workspace, so I did not request or receive semantic fact lines.

```json
{"tool":"hosted Agentic Mermaid MCP","arguments":{"input":"sequenceDiagram\n  Alice->>Bob: Hi","mode":"compact-deterministic-semantic-fact-lines"}}
```