Read and follow the skill file(s) below (including referenced files when relevant), then do the task:
- skills/root-0/SKILL.md

Task prompt:
Using hosted Agentic Mermaid MCP, request compact deterministic semantic fact lines for `sequenceDiagram\n  Alice->>Bob: Hi`. Do not change or render it, and do not claim a response you did not receive. End with one fenced JSON object containing exactly `{"tool": <selected tool>, "arguments": <argument object>}`.

Input files available to inspect:
- none

Return the final answer for this eval task. Do not include hidden answer keys or rubrics.