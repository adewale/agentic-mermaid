```json
{"tool":"execute","arguments":{"code":"const r0 = mermaid.parseRegisteredMermaid('sequenceDiagram\\n  Alice->>Bob: Hi')\nif (!r0.ok) return { errors: r0.error }\nreturn { facts: mermaid.describeMermaidFacts(r0.value) }"}}
```