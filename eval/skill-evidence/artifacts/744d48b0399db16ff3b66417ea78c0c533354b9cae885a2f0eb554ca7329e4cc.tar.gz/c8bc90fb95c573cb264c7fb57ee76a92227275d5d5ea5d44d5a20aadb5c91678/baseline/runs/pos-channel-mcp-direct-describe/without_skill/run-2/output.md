```json
{"tool":"semantic_fact_lines","arguments":{"diagram":"sequenceDiagram\n  Alice->>Bob: Hi","compact":true,"deterministic":true}}
```