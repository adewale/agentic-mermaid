```json
{"tool":"describe","arguments":{"source":"sequenceDiagram\n  Alice->>Bob: Hi","format":"facts"}}
```