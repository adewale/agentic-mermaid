Read and follow the skill file(s) below (including referenced files when relevant), then do the task:
- skills/root-0/SKILL.md

Task prompt:
Through hosted Agentic Mermaid MCP, author a new class diagram containing Customer and Account with an association from Customer to Account. Use structured operations; there is no existing source or custom control flow. Show which embedded verification fields must pass before accepting returned source; do not fabricate a response. End with one fenced JSON object containing exactly `{"tool": <selected tool>, "arguments": <argument object>}`.

Input files available to inspect:
- none

Return the final answer for this eval task. Do not include hidden answer keys or rubrics.