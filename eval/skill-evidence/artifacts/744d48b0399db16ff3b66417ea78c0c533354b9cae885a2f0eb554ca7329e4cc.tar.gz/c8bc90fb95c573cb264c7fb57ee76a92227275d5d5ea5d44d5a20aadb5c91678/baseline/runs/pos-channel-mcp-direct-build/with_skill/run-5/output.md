```json
{"tool":"build","arguments":{"family":"classDiagram","source":"classDiagram\n    class Customer\n    class Account\n    Customer --> Account","verification":{"must_pass":["verify.ok == true","verify.warnings is empty","verify.layout is present"],"accept_only_when":"returned source matches the built class diagram without fallback or fabricated content"}}}
```