No Mermaid MCP tool surfaced in the available connectors, so I cannot author the diagram through a hosted Agentic Mermaid MCP from this workspace without inventing a tool.

```json
{"tool":"none","arguments":{"reason":"No Mermaid MCP tool was available to the agent in this session."}}
```