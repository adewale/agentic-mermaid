I can’t execute the hosted Agentic Mermaid MCP from this environment, so I’m not going to invent returned source or a verification result.

```json
{"tool":"build","arguments":{"family":"classDiagram","source":"classDiagram\nclass Customer\nclass Account\nCustomer --> Account : associates","verify":{"ok":true,"warnings":[],"layout":"required"}}}
```