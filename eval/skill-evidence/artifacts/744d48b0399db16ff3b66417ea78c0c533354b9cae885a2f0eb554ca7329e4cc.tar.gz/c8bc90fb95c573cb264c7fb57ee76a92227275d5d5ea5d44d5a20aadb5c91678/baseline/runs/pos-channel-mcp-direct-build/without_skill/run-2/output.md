```json
{"tool":"unavailable","arguments":{"reason":"No hosted Agentic Mermaid MCP tool is exposed in this workspace, so I cannot author or verify the class diagram through that service without fabricating a tool call."}}
```