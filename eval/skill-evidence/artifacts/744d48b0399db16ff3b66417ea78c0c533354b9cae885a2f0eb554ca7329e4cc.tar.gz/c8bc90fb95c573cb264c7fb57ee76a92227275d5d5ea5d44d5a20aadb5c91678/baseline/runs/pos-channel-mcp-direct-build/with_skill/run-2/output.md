Acceptance gates before returning source:
- `parse.ok === true`
- `verify.ok === true`
- `family === "classDiagram"`
- diagram contains `Customer` and `Account`
- there is exactly one association from `Customer` to `Account`

```json
{"tool":"build","arguments":{"family":"classDiagram","elements":[{"kind":"class","id":"Customer"},{"kind":"class","id":"Account"},{"kind":"association","from":"Customer","to":"Account"}]}}
```