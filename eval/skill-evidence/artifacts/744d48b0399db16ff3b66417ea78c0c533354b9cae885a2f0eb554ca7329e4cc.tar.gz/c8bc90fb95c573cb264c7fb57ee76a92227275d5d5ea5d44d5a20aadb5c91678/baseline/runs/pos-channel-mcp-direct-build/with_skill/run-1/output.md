```json
{"tool":"build","arguments":{"family":"classDiagram","source":"classDiagram\nclass Customer\nclass Account\nCustomer --> Account","verification":{"mustPass":["ok"],"mustBeEmpty":["warnings"],"requiredLayoutFields":["nodes","edges"]}}}
```