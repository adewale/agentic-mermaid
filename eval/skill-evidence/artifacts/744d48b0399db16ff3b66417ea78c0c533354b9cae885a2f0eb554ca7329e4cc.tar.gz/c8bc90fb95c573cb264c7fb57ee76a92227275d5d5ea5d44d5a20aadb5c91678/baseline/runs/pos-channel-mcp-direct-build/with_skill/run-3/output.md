```json
{"tool":"build","arguments":{"family":"classDiagram","ops":[{"kind":"add_class","id":"Customer"},{"kind":"add_class","id":"Account"},{"kind":"add_association","from":"Customer","to":"Account"}],"verification":["ok","warnings","layout"]}}
```