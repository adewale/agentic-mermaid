# Skill evals

This directory contains the `skill-eval-harness` manifest for the repository’s agent-agnostic skills under [`../skills/`](../skills/).

## Coverage matrix

The public tune split now includes:

- Diagram families: every registry-declared built-in, via the manifest's
  `family:*` tags (enforced by the doc-sync test rather than copied here).
- Channels: library, CLI, hosted MCP direct tools, and MCP Code Mode.
- Hosted MCP routing: direct `verify`/`describe`/`mutate`/`build` cases whose
  proposed JSON requests are executed locally against the production tool
  schemas and mutation core,
  schema-error recovery through `describe_sdk`, and local fallback for inputs
  beyond the hosted limit. A separate repository-grounding case requires scope
  claims to cite inspected implementation files rather than generic MCP lore.
- Negative/no-trigger rows for unrelated work.
- Adversarial rows for source concatenation, skipping verify, editing generated
  `editor.html`, using `type` instead of `kind`, underspecified quality goals,
  and oversized hosted inputs.
- Fixture-backed artifact rows under [`fixtures/`](./fixtures/) that require changed Mermaid/source plus `verifyMermaid` evidence.
- Every case is tagged by domain, difficulty, trigger type, and success goal so
  aggregate pass rates can be sliced instead of hiding regressions in one
  overall mean. Script oracles and regex checks replace keyword matching where
  a structural or executable contract matters.

The manifest also contains private `prompt_ref` stubs for `holdout` and `holdback`. Those paths are intentionally under ignored `skill-evals/private/`; real hidden prompts and answer keys must stay out of public commits. Public stubs contain no `expected_behavior`, `assertions`, or `review_rubric`, because an unpublished prompt with a published answer key is not a holdback.

## Harness

Install/run with:

```bash
uvx --from git+https://github.com/adewale/skill-eval-harness.git@v0.4.0 skill-benchmark --help
```

Validate and audit the public manifest:

```bash
skill-benchmark validate skill-evals/shared-benchmark.json
skill-benchmark audit-manifest skill-evals/shared-benchmark.json --format markdown --out /tmp/agentic-mermaid-skill-audit.md
```

Create an ignored `skill-evals/private/cases.json` conforming to
[`private-bundle.schema.json`](./private-bundle.schema.json), add the referenced
prompt files, hydrate, then use strict validation:

```bash
bun run eval:skill:hydrate
skill-benchmark validate skill-evals/private/hydrated-benchmark.json --strict-holdback
```

Hydration fails on a missing/extra private case, a missing prompt, or any answer
key leaked into a public hidden stub. It also resolves skill, fixture, and prompt
paths absolutely so moving the hydrated file cannot silently retarget inputs.

Prepare visible tune tasks with repeated runs:

```bash
skill-benchmark prepare skill-evals/shared-benchmark.json \
  --split tune \
  --runs-per-variant 5 \
  --out /tmp/agentic-mermaid-skill-tasks.jsonl
```

Use 3 runs per variant for iteration and 5 for pre-merge/release evidence. Before
execution, run `eval:skill:prepare-evidence`. It treats the model workspace, the
fixture checkout, and the treatment skill checkout as three separate inputs.
This permits a skill-only A/B: both arms use one neutral workspace and frozen
fixture tree while only `--skill-checkout` changes. `--skills` removes unrelated
skills from the forced-load input, `without_skill` rows carry no skill paths,
and `--seed` creates one reproducible shuffled schedule.

For the hosted-MCP cohort, prepare the baseline and candidate from the same
source tasks like this:

```bash
bun run eval:skill:prepare-evidence \
  --tasks /tmp/agentic-mermaid-skill-tasks.jsonl \
  --workspace /tmp/agentic-mermaid-neutral-workspace \
  --fixture-checkout /tmp/agentic-mermaid-frozen-fixtures \
  --skill-checkout /tmp/agentic-mermaid-baseline \
  --skills agentic-mermaid-diagram-workflow \
  --cases pos-channel-mcp-direct-verify,pos-channel-mcp-direct-describe,pos-channel-mcp-direct-mutate,pos-channel-mcp-direct-build,adv-mcp-recover-invalid-op-schema,adv-mcp-hosted-size-fallback,adv-mcp-underspecified-quality-objective,neg-unrelated-typescript-helper \
  --seed agentic-mermaid-hosted-mcp-v2 \
  --runs-root /tmp/eval-before/runs \
  --out /tmp/eval-before/tasks.jsonl \
  --receipt /tmp/eval-before/preparation.json
```

Repeat with the candidate skill checkout and candidate output paths. The
preparation receipt hashes the selected skill tree, fixtures, stimuli, and run
schedule. The comparison gate rejects identical treatments, changed prompts or
fixtures, different schedules, and different workspaces. For repository-editing
cases that genuinely need a checkout, use one shared immutable workspace; do
not compare two repository roots and call the result a skill effect.

The preparer also rewrites requested `outputs/...` paths into the matching run
directory. Without that rewrite, an agent can produce the right artifact in the
repository while `file_exists` grades an unrelated run folder.

Run autonomous trigger/no-trigger checks separately:

```bash
skill-pi-trigger-eval skill-evals/shared-benchmark.json \
  --split tune \
  --runs-per-query 5 \
  --out /tmp/agentic-mermaid-trigger-report.json
```

After running the prepared tasks with a coding-agent runner, grade with:

```bash
bun run eval:skill:materialize-codex-output \
  --runs /tmp/agentic-mermaid-skill-runs \
  --receipt /tmp/agentic-mermaid-output-materialization.json

skill-benchmark benchmark skill-evals/shared-benchmark.json \
  --runs /tmp/agentic-mermaid-skill-runs \
  --split tune \
  --allow-scripts \
  --out /tmp/agentic-mermaid-skill-benchmark.json
```

Run materialization before grading Codex JSONL. Harness 0.4.0 normalizes a
message through a 500-character summary and can therefore cut a valid final
JSON block in half. The materializer reads the last complete `agent_message`
from the immutable trace, replaces `output.md` only when the harness artifact
is its exact prefix, preserves that artifact as `output.harness.md`, and emits
content digests. A non-prefix mismatch fails closed.

`--allow-scripts` runs repository-owned deterministic oracles. The hosted-MCP
oracle extracts the final `{tool, arguments}` JSON block, validates it against
the exact advertised schema, and executes verify/describe/mutate/build requests
through the production core. Soft judge rows separately evaluate semantic
interpretation and honesty; literal assertions are not a substitute for that
review.

## Latest causal hosted result

The content-addressed [2026-07-28 hosted MCP receipt](../eval/skill-evidence/hosted-mcp-causal-2026-07-28.json)
records 96 full-matrix and 9 focused Codex executions. With the neutral
workspace, frozen fixtures, prompts, schedule, manifest, and treatment paths
held constant, the candidate raised mean objective pass rate from 81.94% to
93.06% and whole-task pass rate from 66.67% to 83.33%; the isolated control was
unchanged. Focused follow-ups then closed the remaining class-build and
state-mutation schema failures at 3/3 each. The receipt explicitly distinguishes
the complete candidate matrix from those later focused treatment refinements.

## Latest smoke result

Runner: Pi CLI, one run per variant, tune split only, model reported by Pi as `gpt-5.5` / `openai-codex`.

| Variant | Cases | Runs | Mean objective pass rate |
|---|---:|---:|---:|
| `with_skill` | 2 | 2 | 1.00 |
| `without_skill` | 2 | 2 | 0.00 |

That older result is only a runner smoke signal: one run cannot estimate
variance, the two-case sample predates the MCP cohort, and it has no slice,
whole-task, trigger-classification, latency, or cost report. Do not cite it as
benchmark or release evidence.

## Evidence gate

[`../eval/skill-evidence/release-cohort.json`](../eval/skill-evidence/release-cohort.json)
pins the skill-only comparison design, behavior cohort, surface-specific model
identity, repetition policy, trigger repetition, pricing source, and required
report fields. A behavior run
is not complete unless both variants have the exact expected run count and zero
missing outputs/timeouts. Run autonomous trigger/no-trigger evals separately;
good answers to forcibly loaded skills do not prove routing precision.

After grading both pinned checkouts, summarize only complete run matrices:

```bash
bun run eval:skill:summarize-evidence \
  --before /tmp/eval-before/report.json \
  --after /tmp/eval-after/report.json \
  --before-manifest skill-evals/shared-benchmark.json \
  --after-manifest skill-evals/shared-benchmark.json \
  --before-receipt /tmp/eval-before/preparation.json \
  --after-receipt /tmp/eval-after/preparation.json \
  --before-output-receipt /tmp/eval-before/output-materialization.json \
  --after-output-receipt /tmp/eval-after/output-materialization.json \
  --out /tmp/skill-evidence-comparison.json
```

The summary refuses duplicate or missing case/variant/run cells, ungraded rows,
missing outputs, timeouts, incomplete output-materialization receipts, identical
skill trees, or any causal-receipt mismatch.
It emits mean-assertion and whole-task pass rates, absolute and
headroom-normalized treatment gains, per-case and taxonomy slices, imperfect
positive rows, negative-behavior violations, latency, token usage, and
price-source-backed cost estimates. Reserve false-positive/false-negative
language for the separate autonomous trigger classifier, where those terms have
their standard meaning.

The deterministic preflight is:

```bash
bun run eval:skill:sabotage
bun run eval:family-portfolio:check
skill-benchmark audit-manifest skill-evals/shared-benchmark.json --format markdown
```

The sabotage lane feeds known-good controls and targeted bad outputs through
every deterministic text assertion type. It must prove the control passes and
each mutation fails; otherwise the evaluator is not sensitive to the fault it
claims to detect. The balanced portfolio is a separate 4 × 15 registry-derived
input set for family-macro reporting; retain the 271-example documentation
corpus for syntax breadth and report both views.
