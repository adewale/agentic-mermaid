Review this SQL query for an index-friendly way to fetch the ten most recent successful invoices per customer. Explain the query plan trade-offs. Do not create a diagram.
