Retry sequence:
1. Do not retry the failed mutate payload as-is.
2. Run schema discovery for the hosted MCP mutate surface first.
3. Accept only an explicit schema result that names the supported op kinds and required fields for `family: class`.
4. Rebuild the mutate request strictly from that schema.
5. If the schema does not expose `addClass`, treat that op kind as unsupported and stop rather than guessing or concatenating source.

Acceptance sequence:
1. Schema must explicitly list the operation kind.
2. Schema must explicitly list every required argument.
3. The rebuilt request must validate against that schema before any mutate attempt.
4. Only then issue the retry.

```json
{"tool":"tool_search_tool","arguments":{"query":"hosted MCP mutate schema discovery for class family supported op kinds"}}