Retry and acceptance sequence:

1. Treat the failure as a schema mismatch, not a content error, because `opIndex: 0` failed with `unknown op kind addClass`.
2. Do not guess the next field names and do not switch to source concatenation.
3. Discover the exact mutation schema for the `class` family with a schema-discovery call.
4. Retry the mutation using only the returned `kind` and fields.
5. Accept the mutation only if the response has top-level `ok: true`, top-level `family` is the expected family, `verify.ok: true`, and the `verify.warnings` set is inspected before committing.

```json
{"tool":"describe_sdk","arguments":{"family":"class","detail":"fields"}}
```