Retry and acceptance sequence:

1. Treat the failure as a schema mismatch, not a content error.
2. Do not retry the same mutate payload.
3. Discover the authoritative MCP schema for the target session/tool first.
4. Inspect the allowed op kinds and exact field shapes.
5. Rebuild the request strictly from the discovered schema.
6. Retry only after schema confirmation.
7. Accept the retry only if the response matches the schema and no new unknown-op error appears.

```json
{"tool":"tool_search_tool","arguments":{"query":"Codex Document Control get_document_tool_schemas schema discovery mutate op kinds addClass unknown op kind","limit":5}}
```