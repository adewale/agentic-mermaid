Retry sequence:
1. Do not resend the mutate call.
2. Discover the authoritative schema for the hosted MCP `class` family operation.
3. Verify the permitted op kinds and required argument shape from schema, not from guesswork.
4. Retry the mutate only after the schema is confirmed.
5. Accept the result only if the tool returns `ok:true` and no validation or op-kind errors.

Acceptance sequence:
1. Schema discovery succeeds.
2. The discovered schema explicitly includes the intended operation kind.
3. The retry payload matches the schema exactly.
4. The mutate call returns success with no `unknown op kind` or field-shape errors.

```json
{"tool":"tool_search_tool","arguments":{"query":"hosted MCP mutate schema discovery class family op kind allowed operations addClass"}}