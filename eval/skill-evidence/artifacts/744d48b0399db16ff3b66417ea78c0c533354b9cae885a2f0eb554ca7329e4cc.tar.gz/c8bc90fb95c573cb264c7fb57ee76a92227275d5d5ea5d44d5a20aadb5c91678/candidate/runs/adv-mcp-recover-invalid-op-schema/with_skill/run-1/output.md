The safe recovery is:

1. Treat the failed mutate as non-committal because `ok:false`.
2. Use the error metadata to target discovery at `family:'class'` and `opIndex:0`.
3. Do not guess a replacement op kind like `addClass`.
4. Do not switch to source concatenation.
5. Call schema discovery for that family with `detail:'fields'`.
6. Retry the mutation only with the exact `kind` and fields returned by the schema.
7. Accept the result only when top-level `ok` is true, `family` matches, `verify.ok` is true, and `verify.warnings` have been inspected.

```json
{"tool":"describe_sdk","arguments":{"family":"class","detail":"fields"}}
```