Recovery sequence:

1. Treat `addClass` as unmodeled for the current hosted family schema.
2. Do not retry `mutate` with a guessed replacement or source concatenation.
3. Call schema discovery for the family reported by the failure: `describe_sdk({ family: 'class', detail: 'fields' })`.
4. Rebuild the retry from the returned schema only, using the exact `kind` and fields it advertises.
5. Accept the result only if top-level `ok` is `true`, top-level `family` matches, `verify.ok` is `true`, and `verify.warnings` are inspected before commit.

```json
{"tool":"describe_sdk","arguments":{"family":"class","detail":"fields"}}
```