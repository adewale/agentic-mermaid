Retry sequence:
1. Do not reissue `addClass`.
2. Perform schema discovery for the hosted MCP mutate surface.
3. Read the discovered enum or op registry and map the failed operation to the canonical supported op name.
4. Retry the mutate call with only schema-confirmed fields.
5. Stop if the response still returns an unknown-op or validation error.

Acceptance sequence:
1. Response is `ok:true`.
2. No `unknown op kind` error remains.
3. The returned mutation payload matches the discovered schema exactly.
4. If the schema does not expose a class-adding op, treat the path as unsupported and do not invent a replacement.

```json
{"tool":"tool_search.tool_search_tool","arguments":{"query":"hosted MCP mutate schema discovery op kinds class add operation", "limit": 8}}
```