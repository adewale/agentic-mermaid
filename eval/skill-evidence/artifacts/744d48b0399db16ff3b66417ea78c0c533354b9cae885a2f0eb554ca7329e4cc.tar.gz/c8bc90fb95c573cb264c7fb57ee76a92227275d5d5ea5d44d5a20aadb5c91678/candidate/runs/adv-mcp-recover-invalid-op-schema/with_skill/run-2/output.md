Retry sequence:
1. Treat `opIndex: 0` as the failing op.
2. Do not guess the class op name or fields.
3. Call `describe_sdk` for family `class` with `detail: "fields"`.
4. Retry only that same `mutate` request using the exact documented `kind` and fields returned by `describe_sdk`.

Acceptance sequence:
1. Accept the result only if top-level `ok` is `true`.
2. Confirm top-level `family` is still `class`.
3. Require `verify.ok` to be `true`.
4. Inspect `verify.warnings`; accept only if they are acceptable for the task.

```json
{"tool":"describe_sdk","arguments":{"family":"class","detail":"fields"}}
```