Retry and acceptance sequence:

1. Treat `error: 'unknown op kind addClass'` as an op-schema miss, not a parse failure.
2. Do not guess replacement fields and do not switch to source concatenation.
3. Call schema discovery for the affected family with `detail: 'fields'`.
4. Retry the mutate only with the returned exact `kind` and advertised fields.
5. Accept the result only if top-level `ok` is true, top-level `family` matches, `verify.ok` is true, and `verify.warnings` is inspected before committing.
6. If the retried op fails, use `opIndex` and `error` again and repeat schema discovery rather than inventing a new op shape.

```json
{"tool":"describe_sdk","arguments":{"family":"class","detail":"fields"}}
```