Retry and acceptance sequence:

1. Do not retry the failed mutate with a guessed `addClass` shape.
2. First perform schema discovery for the hosted MCP mutation surface.
3. Inspect the returned op-kind enum and field requirements for the class-family mutate path.
4. Retry only with an exact, schema-backed op kind and exact field names.
5. Accept the result only if the schema explicitly supports the intended class mutation and the server returns a successful mutation response.
6. If schema discovery does not expose a supported class op, stop rather than switching to source concatenation or inventing fields.

```json
{"tool":"tool_search.tool_search_tool","arguments":{"query":"hosted MCP mutate schema discovery class family op kinds add class unknown op kind addClass"}}