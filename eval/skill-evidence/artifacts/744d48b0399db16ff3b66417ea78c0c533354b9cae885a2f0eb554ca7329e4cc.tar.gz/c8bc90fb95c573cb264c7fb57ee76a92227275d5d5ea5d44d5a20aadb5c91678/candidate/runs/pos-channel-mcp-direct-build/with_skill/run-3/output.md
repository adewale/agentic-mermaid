Accept returned source only when top-level `ok` is true, top-level `family` is `class`, `verify.ok` is true, and `verify.warnings` has been inspected.

```json
{"tool":"build","arguments":{"family":"class","ops":[{"kind":"add_class","id":"Customer"},{"kind":"add_class","id":"Account"},{"kind":"add_relation","from":"Customer","to":"Account","relKind":"association"}]}}
```