No hosted Agentic Mermaid MCP tool is exposed in this workspace, so I cannot author the class diagram or inspect returned-source verification fields here without fabricating a tool response.

```json
{"tool":"unavailable","arguments":{"reason":"No Mermaid MCP tool is available in the current workspace tool registry; cannot create or verify returned source."}}
```