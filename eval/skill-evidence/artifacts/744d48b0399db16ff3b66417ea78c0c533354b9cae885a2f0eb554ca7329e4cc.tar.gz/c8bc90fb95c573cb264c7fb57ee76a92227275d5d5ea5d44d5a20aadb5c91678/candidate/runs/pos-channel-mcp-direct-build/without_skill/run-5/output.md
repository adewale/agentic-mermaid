```json
{"tool":"hosted-agentic-mermaid-mcp","arguments":{"operation":"create_source","diagram_type":"classDiagram","source":"classDiagram\nclass Customer\nclass Account\nCustomer --> Account","verification":{"must_pass":["non_empty_source","diagram_type_is_classDiagram","contains_class_customer","contains_class_account","contains_association_customer_to_account"]}}}
```