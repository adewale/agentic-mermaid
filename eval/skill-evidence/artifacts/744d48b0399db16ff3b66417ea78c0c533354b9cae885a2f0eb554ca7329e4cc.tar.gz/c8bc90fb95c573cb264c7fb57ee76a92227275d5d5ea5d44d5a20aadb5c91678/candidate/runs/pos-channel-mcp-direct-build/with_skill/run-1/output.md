Accept the returned source only if top-level `ok` is true, top-level `family` is `class`, `verify.ok` is true, and you inspect `verify.warnings` before accepting it.

```json
{"tool":"build","arguments":{"family":"class","ops":[{"kind":"add_class","id":"Customer"},{"kind":"add_class","id":"Account"},{"kind":"add_relation","from":"Customer","to":"Account","relKind":"association"}]}}
```