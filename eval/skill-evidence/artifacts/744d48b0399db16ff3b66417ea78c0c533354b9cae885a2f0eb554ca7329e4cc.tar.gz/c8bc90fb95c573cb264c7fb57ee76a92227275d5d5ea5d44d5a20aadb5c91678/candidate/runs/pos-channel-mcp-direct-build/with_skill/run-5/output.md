Accept returned source only if `ok` is true, `family` is `class`, `verify.ok` is true, and `verify.warnings` is inspected.

```json
{"tool":"build","arguments":{"family":"class","ops":[{"kind":"add_class","id":"Customer"},{"kind":"add_class","id":"Account"},{"kind":"add_relation","from":"Customer","to":"Account","relKind":"association"}]}}
```