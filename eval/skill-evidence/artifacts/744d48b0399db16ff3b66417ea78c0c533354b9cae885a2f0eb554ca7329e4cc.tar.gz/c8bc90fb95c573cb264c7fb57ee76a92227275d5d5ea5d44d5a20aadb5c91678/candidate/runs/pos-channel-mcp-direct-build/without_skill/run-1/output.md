No hosted Agentic Mermaid MCP tool was surfaced in this workspace, so I cannot author the diagram here without inventing a tool response. The returned source should only be accepted if the embedded verification fields confirm parse success, semantic validity, and the required `Customer -> Account` association.

```json
{"tool":"unavailable","arguments":{"reason":"No Mermaid MCP authoring tool was exposed by tool discovery in this workspace.","required_verification_fields":["parse_ok","schema_valid","contains_class_Customer","contains_class_Account","contains_association_Customer_to_Account"]}}
```