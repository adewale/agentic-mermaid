I could not validate `flowchart TD\n  API --> DB` because no Agentic Mermaid MCP tool was exposed in this environment, so I did not run anything.

Cheapest direct request, if the server were available, would be the single validation call that accepts the Mermaid source only, with no render or edit options.

The response fields that would establish the result are the ones that report:
- the detected family, typically a top-level family/classification field
- diagnostics, typically a validation diagnostics array or object with errors/warnings

```json
{"tool":"unavailable","arguments":{"mermaid":"flowchart TD\n  API --> DB","reason":"Agentic Mermaid MCP server/tool not exposed in this environment, so no request was run"}}
```