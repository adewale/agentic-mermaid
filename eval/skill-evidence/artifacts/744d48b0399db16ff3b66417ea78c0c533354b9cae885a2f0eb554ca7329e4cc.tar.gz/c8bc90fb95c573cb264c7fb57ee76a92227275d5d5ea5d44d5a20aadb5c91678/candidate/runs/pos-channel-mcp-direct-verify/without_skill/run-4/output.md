The hosted Agentic Mermaid MCP server was not available to me here, so I did not run validation and I am not claiming a server result.

Cheapest direct request: a single validation call with the raw Mermaid text and no rendering/editing options.

The response fields that would establish the detected family and diagnostics are the family discriminator field and the diagnostics list, but I could not confirm their exact shapes because the server was unavailable.

```json
{"tool":"validate","arguments":{"diagram":"flowchart TD\n  API --> DB"}}
```