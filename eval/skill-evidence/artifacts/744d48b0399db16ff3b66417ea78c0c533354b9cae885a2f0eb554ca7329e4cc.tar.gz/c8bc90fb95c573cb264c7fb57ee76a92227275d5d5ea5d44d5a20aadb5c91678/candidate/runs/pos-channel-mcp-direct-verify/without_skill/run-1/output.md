The hosted Agentic Mermaid MCP server was not available through the tools exposed in this session, so I could not run or validate `flowchart TD\n  API --> DB`.

Because there was no server response, there are no response fields to cite for detected family or diagnostics. If the server were reachable, the fields to look for would be the ones carrying the parsed diagram family and the validation issues, typically a family field plus a diagnostics/errors collection.

```json
{"tool":"unavailable","arguments":{"diagram":"flowchart TD\n  API --> DB","reason":"hosted Agentic Mermaid MCP server not exposed in available tools"}}
```