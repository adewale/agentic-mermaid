I could not execute the hosted MCP call from this environment, so I am not claiming the server ran.

The cheapest direct request is `verify` with only `source`. In the `verify` response, the fields that establish detection and diagnostics are:
- `family` for the detected diagram family
- `ok` for structural validity
- `warnings` for diagnostics
- `summary` and layout counts if present, but they are secondary

```json
{"tool":"verify","arguments":{"source":"flowchart TD\n  API --> DB"}}
```