The hosted Agentic Mermaid MCP server was not available in the tool surface here, so I could not run `flowchart TD\n  API --> DB` and I should not pretend it executed.

If it were available, the cheapest direct request would be the server’s validate-only call with the diagram text as input, and the response fields to look for would be:
- `family` or equivalent family-detection field
- `diagnostics` or equivalent validation findings field

```json
{"tool":"unavailable","arguments":{}}
```