The cheapest direct hosted MCP request for this validation is `verify`, with only the source payload. I could not actually run the hosted Agentic Mermaid MCP server from this workspace, so I cannot claim a result or identify live response fields from an execution. If it were available, the response fields that establish family and diagnostics are `family`, `ok`, `verify.ok`, and `verify.warnings` for the commit check path described in the skill, but I am not asserting those came back here.

```json
{"tool":"verify","arguments":{"source":"flowchart TD\n  API --> DB"}}
```