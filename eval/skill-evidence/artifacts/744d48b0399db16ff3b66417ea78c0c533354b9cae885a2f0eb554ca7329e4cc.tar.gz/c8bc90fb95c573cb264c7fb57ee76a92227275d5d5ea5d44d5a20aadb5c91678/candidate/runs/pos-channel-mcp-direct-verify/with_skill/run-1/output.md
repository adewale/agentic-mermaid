Cheapest direct request: `verify` with just the source, since it returns structural validity, detected family, warnings, and layout counts.

The response fields that establish detection and diagnostics are:
- `family` for the detected diagram family
- `ok` for top-level success
- `verify.ok` for embedded verification success
- `verify.warnings` for diagnostics

I cannot claim the hosted server ran here because I do not have a live MCP client connection in this environment.

```json
{"tool":"verify","arguments":{"source":"flowchart TD\n  API --> DB"}}
```