I could not find a callable Agentic Mermaid MCP tool in the surfaced toolset, so I did not run validation and cannot claim the server ran.

If the server were available, the cheapest direct request would be the single validate call with the diagram text only. The response fields that would establish the detected family and diagnostics are the top-level family discriminator and the diagnostics collection returned by the validator.

```json
{"tool":"unavailable","arguments":{"diagram":"flowchart TD\n  API --> DB"}}
```