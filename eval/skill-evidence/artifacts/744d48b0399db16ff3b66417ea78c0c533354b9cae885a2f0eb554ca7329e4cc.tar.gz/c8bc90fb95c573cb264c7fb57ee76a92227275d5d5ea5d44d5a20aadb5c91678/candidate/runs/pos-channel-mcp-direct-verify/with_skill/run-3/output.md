I could not reach the hosted Agentic Mermaid MCP server from this environment, so I did not execute a live validation.

The cheapest direct request for this input is `verify`, because it returns structural validity plus the detected family and diagnostics in one call. The response fields to inspect are `ok` for validity, `family` for the detected diagram family, and `warnings` for diagnostics. `summary` and `layout` are additional context, but they are not the primary validity signals.

```json
{"tool":"verify","arguments":{"source":"flowchart TD\n  API --> DB"}}
```