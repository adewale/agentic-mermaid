I could not reach the hosted Agentic Mermaid MCP server from this environment, so I cannot claim a validation result or quote family/diagnostic fields from an actual response.

Cheapest direct request for the snippet is `verify` with only `source`; if the server were available, the response fields to check would be top-level `ok`, top-level `family`, and `warnings` for diagnostics.

```json
{"tool":"verify","arguments":{"source":"flowchart TD\n  API --> DB"}}
```