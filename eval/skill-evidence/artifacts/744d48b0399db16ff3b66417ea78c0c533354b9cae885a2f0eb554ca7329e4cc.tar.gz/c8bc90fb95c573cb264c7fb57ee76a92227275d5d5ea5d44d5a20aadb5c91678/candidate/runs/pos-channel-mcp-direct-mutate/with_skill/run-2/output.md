Accept the returned source only if these embedded verification fields pass: top-level `ok`, top-level `family`, `verify.ok`, and `verify.warnings`.

```json
{"tool":"mutate","arguments":{"source":"stateDiagram-v2\n  [*] --> Idle\n  Idle --> Processing: start\n  Processing --> Complete: done\n  Complete --> [*]\n","ops":[{"kind":"add_state","id":"Failed","label":"Failed"},{"kind":"add_transition","from":"Processing","to":"Failed","label":"failure"}]}}
```