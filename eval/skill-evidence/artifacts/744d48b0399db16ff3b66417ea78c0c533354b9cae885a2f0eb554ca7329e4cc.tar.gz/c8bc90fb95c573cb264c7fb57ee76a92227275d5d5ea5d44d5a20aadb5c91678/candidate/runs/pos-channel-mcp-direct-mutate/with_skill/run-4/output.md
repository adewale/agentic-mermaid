Accept the returned source only if top-level `ok` is true, top-level `family` matches the state-diagram family, `verify.ok` is true, and `verify.warnings` is inspected.

```json
{"tool":"mutate","arguments":{"source":"stateDiagram-v2\n  [*] --> Idle\n  Idle --> Processing: start\n  Processing --> Complete: done\n  Complete --> [*]\n","ops":[{"kind":"add_state","id":"Failed","label":"Failed"},{"kind":"add_transition","from":"Processing","to":"Failed","label":"failure"}]}}
```