No hosted Mermaid MCP tool is exposed in this workspace, so I can’t execute the edit without inventing a tool name.

Verification fields that must pass on the returned source:
- Parse/syntax success for the Mermaid state diagram
- Presence of terminal state `Failed`
- Presence of transition `Processing --> Failed`

```json
{"tool":"unavailable","arguments":{"source":"stateDiagram-v2\n  [*] --> Idle\n  Idle --> Processing: start\n  Processing --> Complete: done\n  Complete --> [*]\n","edit":{"add_node":"Failed","add_transition":"Processing --> Failed"},"verification":["parse_ok","contains_state:Failed","contains_transition:Processing --> Failed"]}}
```