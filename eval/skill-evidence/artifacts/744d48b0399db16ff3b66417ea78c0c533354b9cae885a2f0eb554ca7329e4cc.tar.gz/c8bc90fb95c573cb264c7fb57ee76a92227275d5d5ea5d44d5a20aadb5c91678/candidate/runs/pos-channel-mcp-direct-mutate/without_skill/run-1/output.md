The embedded verification fields that must pass before accepting the returned source are:

- `success` must be `true`
- `source` must contain the updated Mermaid source
- `validation` must report no errors
- `diagram` must still be a valid `stateDiagram-v2`
- the returned source must include `Failed`
- the returned source must include a transition from `Processing` to `Failed`

```json
{"tool":"Agentic Mermaid MCP","arguments":{"source_file":"inputs/input.mmd","update":{"add_node":{"id":"Failed","kind":"terminal","style":"unsuccessful"},"add_transition":{"from":"Processing","to":"Failed"}},"accept_if":{"success":true,"validation":"no_errors","contains":["Failed","Processing --> Failed"]}}}
```