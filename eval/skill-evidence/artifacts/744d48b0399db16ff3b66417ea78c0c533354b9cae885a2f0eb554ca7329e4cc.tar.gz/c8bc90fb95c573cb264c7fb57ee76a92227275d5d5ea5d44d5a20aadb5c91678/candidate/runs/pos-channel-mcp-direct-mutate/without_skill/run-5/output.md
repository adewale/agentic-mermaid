I cannot identify a callable hosted Agentic Mermaid MCP tool or its schema from the available workspace tools, so I cannot truthfully supply the requested structured edit request or the embedded verification fields without fabricating them.

```json
{"tool":null,"arguments":{}}
```