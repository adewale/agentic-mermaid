I can’t truthfully name a hosted Agentic Mermaid MCP tool here because no Mermaid-specific MCP connector is exposed in this workspace. The only source I can verify is [`inputs/input.mmd`](/private/var/folders/58/zrc_1j8n0f74krswfhmrtkrw0000gn/T/codex-ws-c0fqwh2u/inputs/input.mmd), which currently contains:

```mermaid
stateDiagram-v2
  [*] --> Idle
  Idle --> Processing: start
  Processing --> Complete: done
  Complete --> [*]
```

Before accepting any returned source, the embedded verification should at minimum confirm:
- `Failed` is present as a terminal state
- `Processing --> Failed` exists with the failure label
- Existing states and transitions remain unchanged

```json
{"tool":"unavailable","arguments":{"requested_change":"add terminal state Failed and failure transition from Processing to Failed","source_file":"inputs/input.mmd","verification":["Failed state present","Processing to Failed transition present","existing diagram preserved"]}}
```