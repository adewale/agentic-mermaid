Accept the returned source only if top-level `ok` is true, top-level `family` is `stateDiagram-v2`, `verify.ok` is true, and `verify.warnings` has been inspected.

```json
{"tool":"mutate","arguments":{"source":"stateDiagram-v2\n  [*] --> Idle\n  Idle --> Processing: start\n  Processing --> Complete: done\n  Complete --> [*]\n","ops":[{"kind":"add_state","id":"Failed"},{"kind":"add_transition","from":"Processing","to":"Failed","label":"fail"}]}}
```