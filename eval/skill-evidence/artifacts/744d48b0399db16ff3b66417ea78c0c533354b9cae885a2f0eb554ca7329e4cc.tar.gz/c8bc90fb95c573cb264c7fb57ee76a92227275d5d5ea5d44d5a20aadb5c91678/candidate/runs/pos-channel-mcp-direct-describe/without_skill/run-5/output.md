I couldn’t access a hosted Agentic Mermaid MCP tool in this environment, so I did not receive semantic fact lines to report.

```json
{"tool":"unavailable","arguments":{"diagram":"sequenceDiagram\n  Alice->>Bob: Hi","requested_output":"compact deterministic semantic fact lines","status":"tool_not_exposed_in_environment"}}
```