I couldn’t access a hosted Agentic Mermaid MCP tool from the available connectors in this workspace, so I did not fabricate any semantic fact lines.

```json
{"tool":"unavailable","arguments":{"diagram":"sequenceDiagram\n  Alice->>Bob: Hi"}}
```