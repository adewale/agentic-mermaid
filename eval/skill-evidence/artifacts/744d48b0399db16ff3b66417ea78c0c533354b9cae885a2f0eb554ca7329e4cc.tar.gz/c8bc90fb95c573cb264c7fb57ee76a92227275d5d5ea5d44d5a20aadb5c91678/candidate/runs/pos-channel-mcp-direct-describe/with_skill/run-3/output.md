Use hosted Mermaid MCP `describe` with `format: "facts"`.

```json
{"tool":"describe","arguments":{"source":"sequenceDiagram\n  Alice->>Bob: Hi","format":"facts"}}
```