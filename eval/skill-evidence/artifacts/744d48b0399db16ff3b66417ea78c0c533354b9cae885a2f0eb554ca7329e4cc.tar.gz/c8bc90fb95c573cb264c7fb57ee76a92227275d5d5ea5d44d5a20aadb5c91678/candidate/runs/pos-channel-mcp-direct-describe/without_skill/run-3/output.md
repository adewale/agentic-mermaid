No callable hosted Agentic Mermaid MCP tool surfaced in the available tool set, so I could not request semantic fact lines from it directly.

```json
{"tool":"tool_search.tool_search_tool","arguments":{"query":"hosted Agentic Mermaid MCP semantic fact lines for sequenceDiagram Alice->>Bob: Hi","limit":20}}
```