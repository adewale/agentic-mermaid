I could not access a hosted Agentic Mermaid MCP tool in this environment, so I did not receive any semantic fact lines for the diagram.

```json
{"tool":"tool_search.tool_search_tool","arguments":{"query":"Agentic Mermaid MCP semantic fact lines sequenceDiagram compact deterministic","limit":8}}
```