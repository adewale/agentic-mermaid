The hosted Agentic Mermaid MCP tool was not exposed in the available tool registry, so I could not issue the request or receive a response.

```json
{"tool":"unavailable","arguments":{"requested":"compact deterministic semantic fact lines","input":"sequenceDiagram\n  Alice->>Bob: Hi","status":"no Mermaid MCP tool surfaced"}}
```