```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | Date | null;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : -Infinity;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : -Infinity;
    return bTime - aTime; // newest first
  });
}
```

If you want, I can also give you:
1. a version that treats invalid dates explicitly
2. a generic version that works with any object shape
3. a version that sorts in place instead of returning a copy