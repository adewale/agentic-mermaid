```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | number | Date | null | undefined;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : -Infinity;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : -Infinity;
    return bTime - aTime;
  });
}
```

Example:

```ts
const sorted = orderUsersByMostRecentSignIn([
  { id: "1", name: "Ada", lastSignInAt: "2026-07-27T10:00:00Z" },
  { id: "2", name: "Ben", lastSignInAt: "2026-07-28T09:30:00Z" },
  { id: "3", name: "Cia", lastSignInAt: null },
]);

// Ben, Ada, Cia
```

If you want, I can also give you a version that:
1. treats invalid timestamps as oldest, or
2. sorts the array in place instead of returning a copy.