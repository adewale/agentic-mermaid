```ts
type User = {
  id: string
  name: string
  lastSignInAt: string | Date | null
}

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : -Infinity
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : -Infinity
    return bTime - aTime
  })
}
```

This returns a new array sorted newest first.

If you want, I can also give you:
1. a version that keeps `null` sign-ins at the end explicitly,
2. a generic comparator function,
3. a version typed for your existing user model.