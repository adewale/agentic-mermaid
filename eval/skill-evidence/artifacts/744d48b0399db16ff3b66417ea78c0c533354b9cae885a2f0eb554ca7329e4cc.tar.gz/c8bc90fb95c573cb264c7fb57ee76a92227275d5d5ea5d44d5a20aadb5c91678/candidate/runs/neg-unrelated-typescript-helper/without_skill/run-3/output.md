```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | Date | null;
};

export function orderByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : 0;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : 0;
    return bTime - aTime;
  });
}
```

This returns a new array sorted newest first. Users with no sign-in timestamp are placed last.

If you want, I can also give you:
1. a version that handles invalid dates safely
2. a generic version for any object shape
3. a one-liner comparator you can pass directly to `Array.prototype.sort()`