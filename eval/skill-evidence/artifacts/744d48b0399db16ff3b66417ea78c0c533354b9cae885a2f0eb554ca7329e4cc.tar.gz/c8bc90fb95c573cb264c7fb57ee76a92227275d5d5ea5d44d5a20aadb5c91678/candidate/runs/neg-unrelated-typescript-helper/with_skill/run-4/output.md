```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | number | Date | null;
};

export function orderUsersByRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : 0;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : 0;
    return bTime - aTime;
  });
}
```

This returns a new array ordered newest first.

If you want `null`/missing timestamps to sort last, this already does that by treating them as `0`. If your timestamps are already numeric epoch milliseconds, you can simplify the conversion.