```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | number | Date | null;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : 0;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : 0;
    return bTime - aTime;
  });
}
```

Example:

```ts
const users = [
  { id: "1", name: "Ada", lastSignInAt: "2026-07-20T10:00:00Z" },
  { id: "2", name: "Ben", lastSignInAt: "2026-07-25T08:30:00Z" },
  { id: "3", name: "Cia", lastSignInAt: null },
];

const ordered = orderUsersByMostRecentSignIn(users);
// Ben, Ada, Cia
```

If you want, I can also give you a version that:
1. keeps users with missing sign-ins at the end explicitly, or
2. handles invalid timestamps defensively.