```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | Date | null;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : 0;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : 0;

    return bTime - aTime;
  });
}
```

If you want missing sign-ins to always sort last, this does that by treating `null` as `0`.

Example:

```ts
const users = [
  { id: "1", name: "Ava", lastSignInAt: "2026-07-20T10:00:00Z" },
  { id: "2", name: "Ben", lastSignInAt: "2026-07-25T09:30:00Z" },
  { id: "3", name: "Chloe", lastSignInAt: null },
];

const sorted = orderUsersByMostRecentSignIn(users);
// Ben, Ava, Chloe
```

If you want, I can also give you a version that preserves the input array type more strictly or handles invalid dates explicitly.