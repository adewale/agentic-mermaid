```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string; // ISO timestamp
};

export function orderByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort(
    (a, b) =>
      new Date(b.lastSignInAt).getTime() - new Date(a.lastSignInAt).getTime()
  );
}
```

Example:

```ts
const users = [
  { id: "1", name: "Ava", lastSignInAt: "2026-07-27T10:15:00Z" },
  { id: "2", name: "Ben", lastSignInAt: "2026-07-28T08:30:00Z" },
  { id: "3", name: "Cara", lastSignInAt: "2026-07-26T18:00:00Z" },
];

const sorted = orderByMostRecentSignIn(users);
// Ben, Ava, Cara
```

If you want, I can also make it handle missing timestamps safely.