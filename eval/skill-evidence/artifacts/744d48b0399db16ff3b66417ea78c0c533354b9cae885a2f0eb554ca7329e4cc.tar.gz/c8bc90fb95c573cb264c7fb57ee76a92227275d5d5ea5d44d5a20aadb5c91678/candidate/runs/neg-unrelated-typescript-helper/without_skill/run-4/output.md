```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | Date | null;
};

export function orderUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : -Infinity;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : -Infinity;
    return bTime - aTime;
  });
}
```

Example:

```ts
const users = [
  { id: "1", name: "Ada", lastSignInAt: "2026-07-20T10:15:00Z" },
  { id: "2", name: "Ben", lastSignInAt: "2026-07-27T08:30:00Z" },
  { id: "3", name: "Cleo", lastSignInAt: null },
];

const ordered = orderUsersByMostRecentSignIn(users);
// Ben, Ada, Cleo
```

If you want, I can also give you:
1. a version that sorts in place
2. a version typed for your exact user shape
3. a version that treats invalid dates explicitly