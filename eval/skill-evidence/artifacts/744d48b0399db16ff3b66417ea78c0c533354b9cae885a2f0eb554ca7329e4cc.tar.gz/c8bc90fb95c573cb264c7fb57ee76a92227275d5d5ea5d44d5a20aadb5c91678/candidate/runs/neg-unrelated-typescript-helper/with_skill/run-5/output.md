```ts
type User = {
  id: string;
  name: string;
  lastSignInAt: string | Date | null;
};

export function sortUsersByMostRecentSignIn(users: User[]): User[] {
  return [...users].sort((a, b) => {
    const aTime = a.lastSignInAt ? new Date(a.lastSignInAt).getTime() : -Infinity;
    const bTime = b.lastSignInAt ? new Date(b.lastSignInAt).getTime() : -Infinity;
    return bTime - aTime;
  });
}
```

Example:

```ts
const users = [
  { id: "1", name: "Ava", lastSignInAt: "2026-07-20T10:00:00Z" },
  { id: "2", name: "Ben", lastSignInAt: "2026-07-25T09:30:00Z" },
  { id: "3", name: "Cara", lastSignInAt: null },
];

const ordered = sortUsersByMostRecentSignIn(users);
// Ben, Ava, Cara
```

If you want, I can also give you a version that handles invalid timestamps explicitly instead of treating them as oldest.