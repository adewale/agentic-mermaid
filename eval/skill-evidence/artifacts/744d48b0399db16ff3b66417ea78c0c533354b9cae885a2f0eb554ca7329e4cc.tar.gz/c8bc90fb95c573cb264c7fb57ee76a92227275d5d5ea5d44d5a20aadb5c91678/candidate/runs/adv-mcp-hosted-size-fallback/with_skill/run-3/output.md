Use the **CLI surface**.

Reason: the hosted MCP endpoint has a **64 KB input cap** and is **stateless**; it also cannot write arbitrary local files. A 90 KB Mermaid diagram exceeds that limit, so the correct fallback is to use the **local CLI** on the user’s machine, which can handle the full source and write the file directly.

Fallback path:
- Use `am` via the **CLI** surface.
- Read the diagram locally.
- Write the output file locally.
- Avoid hosted MCP for this task entirely.

I would not split the diagram across multiple remote calls. The right fix is to switch surfaces to the local CLI.