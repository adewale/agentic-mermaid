Use the local **CLI surface** for this task, not hosted MCP.

Reason:
- The diagram is about **90 KB**, and hosted MCP has a **64 KB input cap**.
- Hosted MCP also cannot do **arbitrary local file I/O**, which you need because the task requires writing the diagram to a file on the user’s machine.

Fallback:
- Use the **Agentic Mermaid CLI** on the local machine to edit/render/write the Mermaid source directly to the target file.
- If a local JS/TS environment is already available, the **library** surface would also work, but for a file-write task the CLI is the correct default fallback.

I would not split the diagram across remote calls.