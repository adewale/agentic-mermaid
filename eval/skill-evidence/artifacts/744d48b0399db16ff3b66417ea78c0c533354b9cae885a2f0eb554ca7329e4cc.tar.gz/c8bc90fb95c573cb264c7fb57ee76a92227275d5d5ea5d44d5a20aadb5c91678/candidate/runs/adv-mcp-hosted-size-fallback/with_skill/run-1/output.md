Use the **CLI surface**, not hosted MCP.

Reason:
- Hosted MCP is stateless and has a **64 KB input cap**.
- It also cannot do **arbitrary local file I/O**.
- A 90 KB Mermaid diagram therefore needs to stay local, where the CLI can read, verify, mutate, and write files on the user’s machine.

Fallback:
- Use `am` locally, for example:
  - `am verify <file.mmd>`
  - `am mutate <file.mmd> --ops <ops.json>` for structured edits
  - `am format <file.mmd>` if you only need canonicalization
- If you need the final artifact written to disk, have the local CLI or local library handle it directly.

Do **not** split the diagram across multiple hosted calls. The hosted endpoint is the wrong surface for this task because the payload is larger than its limit and the write target is a local file.