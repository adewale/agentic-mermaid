Use the local filesystem-backed coding agent surface, not the hosted MCP endpoint.

Why:
- The diagram is about 90 KB, which is too large for the hosted MCP input limit.
- The hosted MCP endpoint also cannot write arbitrary files, so it is the wrong surface for this task.

Fallback:
- Write the Mermaid source directly to a file on the user’s machine from the local workspace using file-editing tooling.
- Keep the whole diagram in one local write operation.
- Do not split the diagram across remote calls.

In this environment I cannot perform the write because the workspace is read-only and there are no input files to inspect, but the correct operational choice is still the local file-writing surface rather than hosted MCP.