Use the **CLI surface** (`am`) for this task.

Reason:
- The hosted MCP surface has a **64 KB input cap**, so a **90 KB Mermaid diagram will be rejected** there.
- The hosted surface also cannot write arbitrary files on the user’s machine.
- The correct fallback is the **local CLI**, which can take the full diagram source and write it directly to a local file.

Fallback choice:
- **Hosted MCP**: not suitable here because of the size limit and file-write limitation.
- **CLI**: suitable because it runs locally and can handle the full 90 KB diagram without splitting it across remote calls.

If you want the concrete write command pattern, it is the local `am` workflow, not a hosted request.