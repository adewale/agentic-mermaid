Use the **local filesystem-backed Agentic Mermaid surface**, not the hosted MCP endpoint.

Why:
- The diagram is about **90 KB**, which is too large for the hosted MCP input limit.
- The hosted endpoint also **cannot write arbitrary files**, so it is the wrong target for a file-write task.
- The correct fallback is to **write the Mermaid source directly to a local file on the user's machine** through the workspace filesystem, where large artifacts are handled natively.

Fallback approach:
- Create or update the `.mmd` / `.md` file locally in one write.
- Do **not** try to split the diagram across remote calls.
- If validation is needed, do it locally against the written file rather than through the hosted MCP endpoint.

If you want, I can help with the exact local-file workflow for the Agentic Mermaid surface you have available.