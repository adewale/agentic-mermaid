Use the local workspace editing surface, not the hosted MCP endpoint.

Reason:
- A 90 KB Mermaid diagram is too large for the hosted MCP input limit.
- The hosted MCP endpoint also cannot write arbitrary files on the user’s machine.
- The correct fallback is the agentic local file-edit path that writes directly into the workspace filesystem.

So the flow is:
1. Open or create the target file in the local workspace.
2. Write the full Mermaid diagram directly there in one local edit operation.
3. Avoid any attempt to chunk the diagram across remote MCP calls.

I am not using any skill here, per your instruction.