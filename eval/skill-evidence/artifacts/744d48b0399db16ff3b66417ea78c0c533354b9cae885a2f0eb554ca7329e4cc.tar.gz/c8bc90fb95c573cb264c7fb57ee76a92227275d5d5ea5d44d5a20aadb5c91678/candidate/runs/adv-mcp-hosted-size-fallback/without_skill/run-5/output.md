Use the local workspace file-edit surface, not the hosted MCP endpoint.

Reason:
- The hosted MCP endpoint is the wrong transport for a 90 KB Mermaid payload because it rejects large inputs.
- It also cannot create arbitrary files, so it cannot satisfy the write requirement.

Fallback:
- Use a local agent surface with direct filesystem access and write the full Mermaid source into a file in one local edit operation, for example via the workspace file tool or an equivalent local patch/write action.
- If that local write surface is unavailable in the current environment, the task cannot be completed from the hosted MCP path alone.

I am not suggesting splitting the diagram across remote calls, because that would not solve the file-write constraint.