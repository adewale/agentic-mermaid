Use the **local CLI surface** for this task, not hosted MCP.

Reason:
- The hosted MCP service has a **64 KB input cap**.
- Your Mermaid source is **about 90 KB**, so it will be rejected there.
- You also need **arbitrary local file I/O**, which hosted MCP does not provide.

Fallback:
- Use the **CLI** or the **library/stdio MCP** path to read the file locally, edit it in place, verify/render, and write it back on the user’s machine.
- Do **not** try to split the diagram across remote calls. The correct recovery is to move the whole file to a local surface that can handle the full source and file writes.

I can’t write the file from this session because the workspace is read-only, but the correct Agentic Mermaid choice is still **CLI/local library**, with hosted MCP only as a non-starter for this size.