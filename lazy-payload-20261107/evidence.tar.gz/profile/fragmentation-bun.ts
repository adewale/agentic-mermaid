import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {gzipSync} from 'node:zlib';
const evidence='/tmp/pr449-week-comparison-20261101/lazy-payload-bbda';
const result={compressor:'Bun1.4.4 node:zlib gzipSync(level9), same as existing reporter', caveat:'Compression-only concatenation is not executable ESM or a bound on all possible bundle rewrites.'};
for(const [label,root] of [['main','/tmp/pr449-current-main-39a-20261107'],['pr','/tmp/pr449-main-integration-20261029-762']]){
 const m=JSON.parse(readFileSync(join(evidence,label+'-metafile-normalized.json'),'utf8')), out=m.outputs;
 const entry=Object.keys(out).find(k=>out[k].entryPoint==='src/browser-lazy.ts');
 const dynamic=out[entry].imports.filter(i=>i.kind==='dynamic-import').map(i=>i.path);
 const core=dynamic.find(x=>x.includes('/render-core-')), packet=dynamic.find(x=>x.includes('/packet-'));
 const seen=new Set();function visit(k){if(seen.has(k))return;seen.add(k);for(const i of out[k].imports)if(i.kind!=='dynamic-import')visit(i.path)}
 for(const k of [entry,core,packet])visit(k);
 const files=[...seen].sort().map(k=>({path:k,bytes:readFileSync(join(root,k))}));
 const sum=files.reduce((n,f)=>n+gzipSync(f.bytes,{level:9}).byteLength,0);
 const concat=gzipSync(Buffer.concat(files.flatMap((f,i)=>i?[Buffer.from('\n'),f.bytes]:[f.bytes])),{level:9}).byteLength;
 result[label]={files:files.length,sum_gzip9:sum,concatenated_gzip9:concat,fragmentation_saving:sum-concat,raw:files.reduce((n,f)=>n+f.bytes.length,0)};
}
result.remaining_pr_concat_vs_main_sum=result.pr.concatenated_gzip9-result.main.sum_gzip9;
writeFileSync(join(evidence,'fragmentation-bun.json'),JSON.stringify(result,null,2)+'\n');console.log(result);

