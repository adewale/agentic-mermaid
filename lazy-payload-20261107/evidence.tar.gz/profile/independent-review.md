# Independent lazy payload scope/value review

Read-only review of renderer source `bbda2112af8d791d8628a3769c86084e4cb962b3`
against main `39a500425f6b74eb486b9add9e90d538fab6a914`. Current
`c9dabb20c67aa18587063ea0268fa4e5ebdf7c40` and its preceding
`aae654e5b135532a37caa8bc14806fa68edc3afd` add worklog text only. No source
changes, builds or repeated public probes were performed by this reviewer.

The paired metafiles locate substantial added emission/ownership code, including
paint-certification +33,674, emission-context +14,557, serialization +14,341,
native-paint-emission +13,249 and svg-writer +12,655 bytes. These are esbuild-stage
module contributions, not gzip or CPU attribution. Receipts, strict refusals,
viewport repair and actual-write custody consume this machinery; removing it
because the lazy entry renders SVG would change observable behavior. Styled
backends and internal Scene fallback remain reachable despite source-only input.

No substantive safe producer subtraction was identified. Terminal projection is
a poor causal target: connector-terminal and deferred-terminal-projection total
4,969 raw PR bytes, versus 4,911 on main. Removing them also crosses constructors,
deferred capture, immutable admission and path/mid-marker fidelity validation.
A broader rewrite is not justified by these contribution counts.

`fragmentation-bun.json` uses Bun1.4.4 node:zlib gzipSync(level9), matching the
existing transfer reporter. The selected packet static closure is main 21 files /
164,917 summed gzip9 bytes and PR 12 files / 199,406. Concatenating the PR files
without deleting bytes gives 196,990 bytes, a 2,416-byte reduction, still 32,073
above actual main. This measured concatenation hypothesis is insufficient to
close the 34,489-byte gap. Concatenation is not
executable ESM, and this result is not a lower bound on all possible bundling
rewrites. Module identity, side effects and complete request closures would still
need qualification for an implementation.

`main-transfer.json` / `pr-transfer.json` confirm those exact static raw and gzip
totals; budgeted packet plus YAML is 196,160 -> 230,648 gzip bytes. The earlier
`fragmentation-counterfactual.json` used Python gzip.compress and is retained as
predecessor evidence only; its absolute counts are not mixed with this final Bun
comparison. The reports show growth despite fewer requests. The existing owning budget gate
still fails; no ceiling was changed. Initial transfer falls 5,919 -> 5,854 gzip
bytes, which does not establish an improvement in consumed family transfer.

This cycle establishes a bounded negative result for the measured concatenation
probe and a clearer cost location. It delivers no payload implementation,
execution speedup, ownership relaxation or readiness claim. Keep the other
campaign gaps and stopped experiments separate.
