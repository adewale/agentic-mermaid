import {readFileSync,writeFileSync}from'node:fs'
import{gunzipSync}from'node:zlib'
import{scanSvgStartTagsFresh}from'/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts'
import{countPolylineCrossings}from'/tmp/pr449-main-integration-20261029-762/src/shared/edge-crossings.ts'
const root='/tmp/pr449-week-comparison-20261101/ranked-losses-ce15/crossing276', rows=[]
for(const arm of process.argv.slice(2)){
 const svg=arm==='elk'?readFileSync(root+'/elk.svg','utf8'):gunzipSync(readFileSync(root+'/'+arm+'/actual.svg.gz')).toString()
 const tags=scanSvgStartTagsFresh(svg).map(t=>({name:t.name,...Object.fromEntries(t.attributes.map(a=>[a.name,a.value]))}))as Array<Record<string,string>>
 const edges=tags.filter(t=>t['data-role']==='edge'&&t.name==='polyline').map(t=>({source:t['data-from'],target:t['data-to'],points:t.points!.trim().split(/\s+/).map(s=>{const[x,y]=s.split(',').map(Number);return{x:x!,y:y!}})}))
 const row={arm,crossings:countPolylineCrossings(edges),edges:edges.length,bends:edges.reduce((n,e)=>n+e.points.length-2,0),wire:edges.reduce((n,e)=>n+e.points.slice(1).reduce((m,p,i)=>m+Math.hypot(p.x-e.points[i]!.x,p.y-e.points[i]!.y),0),0),viewport:tags.find(t=>t.name==='svg')!.viewBox}
 rows.push(row);console.log(JSON.stringify(row))
}
writeFileSync(root+'/VECTORS-'+process.argv.slice(2).join('-')+'.json',JSON.stringify(rows,null,2)+'\n')
