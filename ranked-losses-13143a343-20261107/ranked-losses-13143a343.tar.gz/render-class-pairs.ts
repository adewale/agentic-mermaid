import {readFileSync,writeFileSync} from 'node:fs'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js'
const p='/tmp/pr449-week-comparison-20261101',before=JSON.parse(readFileSync(p+'/compare-rebase-433b/agentic.json','utf8')),after=JSON.parse(readFileSync(p+'/ranked-losses-ce15/class-after.json','utf8'));
for(const n of [2,29])for(const [arm,rows]of [['before',before.samples],['after',after.samples]] as const){const s=rows.find((s:any)=>s.id===`corpus/class/${n}`);writeFileSync(p+`/ranked-losses-ce15/class${n}-${arm}.svg`,s.svg);writeFileSync(p+`/ranked-losses-ce15/class${n}-${arm}.png`,new Resvg(s.svg).render().asPng())}
