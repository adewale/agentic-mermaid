import{LAYOUT_PIPELINE}from'/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts';import{renderMermaidSVG}from'/tmp/pr449-main-integration-20261029-762/src/index.ts';
const pass=LAYOUT_PIPELINE.find(p=>p.id==='equalizePeerNodeDimensions')!,before=pass.run;
(pass as any).run=(c:any)=>{console.log('RUN-EQUALIZE',!!c.elkResult,c.mergeEdges);return before(c)};
console.log('enable',pass.enabled?.({elkResult:undefined,mergeEdges:true}as any),String(pass.enabled));
const svg=renderMermaidSVG('flowchart TD\nA[a<br/>b<br/>c<br/>d<br/>e<br/>f<br/>g<br/>h] --> B[Short]\nA --> C[Short]\nD[Root] --> E[a<br/>b<br/>c<br/>d<br/>e<br/>f<br/>g<br/>h]\nD --> F[Short]',{graphLayout:{backend:'agentic',fallback:'none'}});console.log(svg.match(/<rect[^>]+data-id="node-shape:F"[^>]*>/)?.[0]);
