import {readFileSync,writeFileSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
import {snapshotSample} from '/tmp/pr449-main-integration-20261029-762/eval/layout-compare/run.ts'
const root='/tmp/pr449-week-comparison-20261101',p=process.argv[2]??root+'/ranked-losses-ce15';
const old=JSON.parse(readFileSync(root+'/compare-rebase-433b/agentic.json','utf8'));
const cohorts=JSON.parse(readFileSync(root+'/compare-rebase-433b/PAIRED-CURRENT.json','utf8')).cohorts;
let offset=0;const rows=[];
for(const cohort of cohorts){for(let i=0;i<cohort.count;i++){
 const before=old.samples[offset+i],after=snapshotSample(before,`lc${i}-`,{graphLayout:{backend:'agentic'}},{includeAscii:before.ascii!==undefined});
 rows.push(after);
 if(!after.ok||after.svgReceipt?.layoutCertification?.status!==before.svgReceipt?.layoutCertification?.status)console.log('outcome',before.id,before.ok,after.ok,before.svgReceipt?.layoutCertification?.status,after.svgReceipt?.layoutCertification?.status,after.error);
 if(rows.length%100===0)console.log('completed',rows.length);
}offset+=cohort.count}
writeFileSync(p+'/native-after.json.gz',gzipSync(JSON.stringify({...old,label:'Native component packing candidate atce15',dirty:true,samples:rows}),{level:9}));
const summary=rows.map((s:any,i:number)=>({id:s.id,before:old.samples[i].metrics?.routeGeometry,after:s.metrics?.routeGeometry,beforeProof:old.samples[i].svgReceipt?.layoutCertification?.status,afterProof:s.svgReceipt?.layoutCertification?.status,beforeOk:old.samples[i].ok,afterOk:s.ok,svgExact:s.svg===old.samples[i].svg,metrics:s.metrics,failures:s.failures}));
writeFileSync(p+'/REQUALIFICATION.json',JSON.stringify(summary,null,2));console.log('saved',rows.length)
