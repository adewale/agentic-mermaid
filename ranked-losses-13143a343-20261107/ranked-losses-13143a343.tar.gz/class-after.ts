import {readFileSync,writeFileSync} from 'node:fs'
import {snapshotSample} from '/tmp/pr449-main-integration-20261029-762/eval/layout-compare/run.ts'
const root='/tmp/pr449-week-comparison-20261101';
const old=JSON.parse(readFileSync(root+'/compare-rebase-433b/agentic.json','utf8'));
const samples=old.samples.filter((s:any)=>s.family==='class').map((s:any)=>{const p=s.svgReceipt.renderOptions?.idPrefix??s.svgReceipt.effectiveOptions?.idPrefix??'ranked-';return snapshotSample(s,p,{embedFontImport:false,graphLayout:{backend:'agentic',fallback:'none'}},{includeAscii:false})});
writeFileSync(root+'/ranked-losses-ce15/class-after.json',JSON.stringify({label:'Class packing candidate',rev:'ce15 plus measured-forest change',dirty:true,samples}));
for(const s of samples){const b=old.samples.find((x:any)=>x.id===s.id);const a=s.metrics?.routeGeometry,o=b.metrics?.routeGeometry;console.log(JSON.stringify({id:s.id,ok:s.ok,before:o,after:a,proof:[b.svgReceipt?.layoutCertification?.status,s.svgReceipt?.layoutCertification?.status],failures:s.failures}))}
