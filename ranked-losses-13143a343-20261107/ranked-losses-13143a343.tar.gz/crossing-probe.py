from pathlib import Path
import json
p=Path('/tmp/pr449-week-comparison-20261101/ranked-losses-ce15');d=p/'crossing276';d.mkdir(exist_ok=True)
s=Path('/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts').read_text();old='  let best = first, before = score(first)';assert old in s
s=s.replace(old,"  let best = first, before = score(first); console.log('CANDIDATE',JSON.stringify({strategy:'primary',score:before}))")
s=s.replace('    const after = score(other)','    const after = score(other); console.log(\'CANDIDATE\',JSON.stringify({strategy:candidate.strategy,score:after}))')
(d/'producer-trace.ts').write_text(s)
x=json.load(open(p.parent/'compare-rebase-433b/agentic.json'));row=next(s for s in x['samples']if s['id']=='generated-cyclic:276');j={'root':'/tmp/pr449-main-integration-20261029-762','revision':'ce15 with scoped component packing','source':row['source'],'options':{'graphLayout':{'backend':'agentic','fallback':'none'}},'moduleOverrides':{'/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts':str(d/'producer-trace.ts')}};(d/'job.json').write_text(json.dumps(j,indent=2)+'\n')
