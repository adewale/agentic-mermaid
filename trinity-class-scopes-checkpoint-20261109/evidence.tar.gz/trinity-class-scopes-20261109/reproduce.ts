import{readFileSync,writeFileSync}from'node:fs'
import{renderMermaidSVGWithReceipt}from'/tmp/pr449-main-integration-20261029-762/src/index.ts'
const out=import.meta.dir,c=JSON.parse(readFileSync(out+'/CASE.json','utf8')),rows=[]
for(const backend of ['elk','agentic','trinity']){try{const p=renderMermaidSVGWithReceipt(c.source,{graphLayout:{backend:backend as 'elk',fallback:'none'},embedFontImport:false});JSON.stringify(p.receipt);writeFileSync(out+'/before-'+backend+'.svg',p.svg);writeFileSync(out+'/before-'+backend+'.receipt.json',JSON.stringify(p.receipt,null,2));rows.push({backend,status:'returned',proof:p.receipt.layoutCertification?.status})}catch(e:any){rows.push({backend,status:e.code==='GRAPH_LAYOUT_UNSUPPORTED'?'unsupported':'error',message:e.message})}}
writeFileSync(out+'/BEFORE.json',JSON.stringify({sourceRevision:'96d10ff9551f88178c4262acda5219e11926ccdf',source:c.source,rows},null,2));console.log(rows)
