from pathlib import Path
import json,subprocess
out=Path(__file__).parent;p=json.load(open(out/'PERFORMANCE.json'));m=json.load(open(out/'SVG-METRICS.json'));b=json.load(open(out/'browser/DELIVERY-COMPARISON.json'));head=subprocess.check_output(['git','rev-parse','HEAD'],text=True,cwd='/tmp/pr449-main-integration-20261029-762').strip()
s=f'''# Trinity Class scopes and family-owned annotations

Runtime **4db8570d389246bb5f1eede8c5b1899fe6cd687e**; report/source head **{head}**; baseline **96d10ff9551f88178c4262acda5219e11926ccdf**. Work remains on existing draft PR602. Deadline9 November2026 at20:00UTC. Old automations remain off; this was a bounded run, not continuous execution.

## Demonstrated loss and intervention

The frozen `features:class:namespace-members-cardinality` input combines a Domain frame, User members/method, Store, labelled relationship, endpoint cardinalities and an attached note. Native/ELK return/proof-pass; Trinity refuses its blanket admission guard. Exact source and independent authored expectations are in CASE.json; baseline products/errors in BEFORE.json and before-*.

Existing Class measurement already supplies namespace ancestry, title minima/header bands, canonical frame paint, actual card dimensions and endpoint marker spans. Existing shared completion owns note seats, annotation/cardinality placement, header repairs, final contacts and marker meaning. Removing the already-translated namespace/note/cardinality veto reaches that machinery with real Trinity local solves. Interfaces and custom paint remain unsupported. Early class/edge limits plus combined classes+flattened-frames admission preserve64 total routed subjects and128 relationships. No new solver/cache, no Native geometry borrowing, no work reset, no default/version/cap change.

The admission-only diagnostic returns five full products. A harder existing nested fixture with multiple marker kinds, cardinalities, notes and a self-loop also returns/proof-passes in all four directions. Reverting only the producer makes five new owners fail. The final full Class file has156passed/0failed. Nearby owners record79passed/5sandbox child-stdin EPERM failures; targeted outside-sandbox retries10passed cover all five. Core/repo types, lint, actual editor/lazy builds pass. Independent read-only causal and scope/value reviews found no blocker. Unsupported interface/fallback and hard work errors remain tested.

## Delivery and independently observed output

Frozen30 delivery: Trinity26→27 returned/proof-passed, unsupported2→1, two shared input errors unchanged. Native/ELK each return28 and retain two errors. Existing613-criterion ledger: Trinity549→564passed,34→19unsupported,28blocked/2failed unchanged; Native576/6unsupported/28blocked/3failed, ELK575/6/29/3 unchanged. Common parser/prelude credit is not selected-solver delivery.

All15 affected Class products were reacquired:14 prior SVGs byte-exact and one new Trinity SVG. Existing Tridentf080 independent authored-meaning and actual finalSVG paint/quantitative observers are reused, without new qualification criteria. All15 returned Class products have no failed observer checks; unknowns elsewhere remain in the complete ledgers. Tests independently inspect emitted parent/member IDs, note ownership, captions/cardinality occurrences, marker resources and physical carrier contacts. Proof availability alone is not visible correctness.

The sole frozen Trinity unsupported input is controlled image. **The other backends' returned image products are not correct-image controls:** retained Trident `embedded-images` checks fail for both Native and ELK because their actual image list is empty. They draw an explicitly warned placeholder. Return counts must not be described as28 completely correct cases. A gate-only Trinity change cannot fix that shared product deficit.

## Actual Class SVG quality and output bytes

Computed from the actual SVG relationship carriers and viewport with existing helpers. Note tethers are annotations, not authored graph relationships in the wire vector. Notes still contribute to the final viewport and independent ink checks.

| Backend | Area | Relationship wire | Bends / crossings / parallel / opposing | SVG raw / gzip9 / Brotli11 |
| --- | ---: | ---: | ---: | ---: |
'''
for r in m:s+=f"|{r['backend']}|{r['area']:.2f}|{r['wire']:.2f}|{r['bends']} / {r['crossings']} / {r['parallelOverlaps']} / {r['opposingOverlaps']}|{r['svgBytes']} / {r['gzip9']} / {r['brotli11']}|\n"
s+='''
Trinity's SVG compression is slightly worse than controls despite its smaller area/wire. Keep the adverse bytes; this single input does not establish broad layout-quality superiority.

## Complete-product runtime and memory

Twelve serial fresh Node24 processes: one frozen Class input ×three backends ×two cache settings ×two replicas. Sixty complete SVG+entire receipt calls, all returned/proof-passed. Originals repeat byte-exact; the authored note edit changes output and repeats exactly. Imports, explicit GC, compression and artifacts outside render windows; sampling/observers off. Cache0 retains existing derived caches. Two process replicas do not establish a general ratio, percentile, throughput, memory superiority or application startup result.

| Cache | Backend | Cold / repeat2 / edit2 wall median ms | Process CPU median ms |
| --- | --- | --- | --- |
'''
for r in p['rows']:
 ks=['cold-render','repeat2','edit2'];wall='/'.join(f"{r['phases'][k]['wallMs']['median']:.2f}" for k in ks);cpu='/'.join(f"{r['phases'][k]['cpuMs']['median']:.2f}" for k in ks);s+=f"|{r['cache']}|{r['backend']}|{wall}|{cpu}|\n"
s+='''
Cached repeat costs are adverse for Trinity:23.33ms versus Native19.75 and ELK20.61. Process CPU includes all threads and can exceed wall time. Before-Trinity refusal is not comparable completed work, so no before/after optimization ratio is claimed.

| Cache | Backend | Process peak RSS KiB range | Heap-used-after snapshot MB range |
| --- | --- | ---: | ---: |
'''
for r in p['rows']:
 vals=r['phases'].values();lo=min(v['peakRssKiB']['range'][0] for v in vals);hi=max(v['peakRssKiB']['range'][1] for v in vals);hl=min(v['heapUsedAfter']['range'][0] for v in vals)/1e6;hh=max(v['heapUsedAfter']['range'][1] for v in vals)/1e6;s+=f"|{r['cache']}|{r['backend']}|{lo}–{hi}|{hl:.2f}–{hh:.2f}|\n"
s+='''
RSS includes source-loader/harness/imports and retained artifacts. Snapshots are not heap peaks, allocation rate, settled retention or leak evidence. Raw deltas/ranges remain in PERFORMANCE.json.

Actual original SVG+entire receipt JSON, Node24 gzip9/Brotli11:

| Backend | Raw / gzip9 / Brotli11 bytes |
| --- | ---: |
'''
for r in p['rows']:
 if r['cache']=='0':
  w=r['wholeProduct'][0];s+=f"|{r['backend']}|{w['raw']} / {w['gzip9']} / {w['brotli11']}|\n"
s+='''
## Actual fetched browser products and editor budget

Thirteen equal family/feature inputs per backend include the newly admitted Class scope case. All three browser lanes pass through the actual lazy API, consuming the SVG and full receipt. This adds one input to the earlier12-input union; do not call the whole cross-run delta a code-only saving. Real raw request files, compressed after observation with Node24 gzip9/Brotli11; not compressed network transfer/startup latency.

| Backend | Product raw / gzip9 / Brotli11 bytes | Requests including binding |
| --- | ---: | ---: |
'''
for r in b:
 w=r['product'];s+=f"|{r['backend']}|{w['raw']} / {w['gzip9']} / {w['brotli11']}|{r['requests']}|\n"
s+='''
Binding bytes are reported separately. Matched Bun1.4.4 editor gzip1342154→1342694 (+540), Brotli1281810→1282743 (+933). The original1334500 gzip ceiling still fails8194. No limit was raised. Browser/source timings, server transfer and monolithic editor bytes are distinct products.

## Limits, decision and next intervention

Retain ELK. Public local routed admission remains64subjects/128edges; broad capacity/readability/edit displacement, allocation/leaks and package-wide startup are unqualified. Controlled-image fidelity, adverse crossings from the separate fan-in case, original editor/lazy/website budgets, Sparse32 and exact-head CI readiness remain unresolved. Replacement24 stays sealed. Original2dad and equivalent pinnedPele runtime comparisons remain unavailable. Existing profiler/caches review binds its own recorded sources; this change is delivery admission, not a performance rewrite or a new cache.

The next intervention should reproduce the shared controlled-image omission and establish a bounded shared measurement/emission contract. Do not count placeholder parity as actual PNG delivery. A separate read-only review records that distinction in `trinity-controlled-image-20261109/causal-review.md`; it is not an implementation or an independent image decode experiment.

## Reproduction and recovery

Use the existing Bun1.4.4 at `/tmp/pr449-tools-20261106/package/bin/bun` from the worktree. `reproduce.ts` binds the baseline; `admission-only-job.json`/`layout-admission-only.ts` retain the nonshipping source override; `nested-*-job.json` exercises the harder source. `requalify.ts`, `observe-cohort.ts` and `complete-ledger.ts` reuse existing Trident tools/criteria. Actual screenshots accompany full SVG/receipts. `run-cost.py` and `summarize-cost.mjs` reuse the existing fully consumed collector and retain every phase. No new framework, source-tree fingerprint, PR or issue.

The recovery archive contains actual products, logs, diagnostic overlays, expected meaning, ledgers, source-mapped prior research pointers, built bytes and failed checks/retries. Its member bytes are verified; nothing retained was deleted. Source and report are pushed to existing PR602; readiness remains separate from successful local owners.
'''
(out/'README.md').write_text(s)
