import pathlib,subprocess,os,json
p=pathlib.Path(__file__).parent;rows=[]
for cache in [0,1]:
 for replica in [0,1]:
  order=[['elk','trinity','agentic'],['agentic','trinity','elk']][(cache+replica)%2]
  for backend in order:
   name=f'class-cache{cache}-r{replica}-{backend}';env={**os.environ,'AGENTIC_MERMAID_ELK_CACHE':str(cache)};out=p/'measurements'/name;out.parent.mkdir(exist_ok=True)
   with (out.parent/(name+'.log')).open('w') as log:r=subprocess.run(['node','--expose-gc',str(p/'measure.mjs'),str(out),str(p/f'class-{backend}-job.json')],env=env,stdout=log,stderr=subprocess.STDOUT)
   row={'name':name,'case':'class','cache':cache,'replica':replica,'backend':backend,'exit':r.returncode};rows.append(row);print(row,flush=True)
   if r.returncode:raise SystemExit(r.returncode)
(p/'MEASUREMENT-RUNS.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runs':rows,'scope':'12 serial fresh Node24 processes,one Class case x3backends x2cache settings x2replicas;60 complete SVG+receipt calls,cold/repeat/edit separately. No concurrent build/profile/browser.'},indent=2)+'\n')
