import {readFileSync,writeFileSync,mkdirSync,cpSync,readdirSync} from 'node:fs'
import {join,relative} from 'node:path'
import {createHash} from 'node:crypto'
import {brotliCompressSync,gzipSync,constants} from 'node:zlib'
import {assertMermaidOracle} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/portable/mermaid-oracle.ts'
import {runCommunityBrowserSuite,prepareCommunityBrowsers} from '/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/unified/community-browser.ts'
const out=import.meta.dir
readFileSync(join(out,'MEASUREMENT-RUNS.json')) // Never overlap browser with Node timings.
process.env.MERMAID_REFERENCE_DIR='/tmp/pr449-main-integration-20261029-762';assertMermaidOracle()
const artifactSource='/tmp/pr449-week-comparison-20261101/trinity-class-20261108/dist-final/browser-lazy'
const hash=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex'),directory=join(out,'browser');mkdirSync(directory,{recursive:true})
await prepareCommunityBrowsers([],{root:'/tmp/pr449-main-integration-20261029-762',harnessRoot:'/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident',out:directory,rounds:1,profile:'full',communityQualificationAssetDir:join(directory,'qualification')})
const helperFiles=readdirSync(join(directory,'qualification')).filter(f=>f.endsWith('.js'));if(helperFiles.length!==1)throw Error('Expected one standard Trident qualification helper');const helper=join(directory,'qualification',helperFiles[0]!)
const inputs=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-native-elk-df133-20261108/CASES.json','utf8')).selected.filter((c:any)=>['family:requirement','family:flowchart','family:state','family:class'].includes(c.id))
const featureInputs=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/trident-native-elk-df133-20261108/FIDELITY-CASES.json','utf8')).selected.filter((c:any)=>['features:state:initial-final-pseudostates','features:class:inheritance-composition-dependency'].includes(c.id))
const workloads=[...inputs,...featureInputs].map((c:any)=>({id:c.id,family:c.family,source:c.source,expectedLabels:c.expected.labels,features:['portable-family-closure'],provenance:'Original pinned Trident portable family case; no case/source changes'}))
writeFileSync(join(directory,'WORKLOADS.json'),JSON.stringify(workloads,null,2)+'\n')
const lanes:any[]=[]
for(const backend of ['agentic','elk','trinity']){
 const root=join(directory,'engines',backend);mkdirSync(root,{recursive:true});cpSync(artifactSource,join(root,'browser-lazy'),{recursive:true})
 cpSync('/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident/unified/declared-adapter.mjs',join(root,'declared-adapter.mjs'))
 const binding={export:'renderConsumed',options:{graphLayout:{backend,fallback:'none'}}}
 writeFileSync(join(root,'entry.mjs'),`import * as original from './browser-lazy/index.js';\nconst api={renderConsumed:async(source,options)=>{const product=await original.renderMermaidSVGWithReceiptAsync(source,options);JSON.stringify(product.receipt);return product.svg}};\nimport {declaredRenderer} from './declared-adapter.mjs';\nexport async function createRenderer(){return declaredRenderer(api,${JSON.stringify(binding)},'svg')}\nglobalThis.unifiedMermaid={createRenderer};\n`)
 const walk=(dir:string):any[]=>readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(dir,e.name)):[{path:join(dir,e.name),sha256:hash(readFileSync(join(dir,e.name)))}]).sort((a,b)=>a.path.localeCompare(b.path))
 const files=walk(root), artifactSha256=hash(Buffer.from(JSON.stringify(files.map(f=>({path:relative(root,f.path),sha256:f.sha256})))))
 const peer={node:{id:'adewale/agentic-mermaid',roles:['renderer'],outputs:['svg'],packages:[{registry:'npm',name:'agentic-mermaid',version:'0.5.7'}],benchmark:{adapter:'declared',outputs:['svg'],api:{svg:binding}}},artifact:{kind:'node',module:join(root,'browser-lazy/index.js'),root:'/tmp/pr449-main-integration-20261029-762',version:'0.5.7',candidate:{revision:'a67632464'}},browserStatus:'prepared',browser:{root,entry:'entry.mjs',kind:'extra',global:'unifiedMermaid',scriptType:'module',qualificationHelper:helper,version:'0.5.7',revision:'a67632464',artifactSha256,output:'svg',apiBoundary:'Actual public lazy SVG+entire receipt consumed by binding, with explicit backend/fallbacknone via unchanged Trident declaredRenderer; binding bytes separated from product bytes.',files}}
 const laneOut=join(directory,backend);mkdirSync(laneOut,{recursive:true});writeFileSync(join(laneOut,'PREPARED.json'),JSON.stringify({backend,peer,scope:'Current public lazy product with flat Class and fixed State circles. Built product modules copied byte-exact into observer asset root with standard Trident binding, not rebuilt or synthetic model/product workspace.'},null,2)+'\n')
 const result=await runCommunityBrowserSuite([peer] as any,workloads,{root:'/tmp/pr449-main-integration-20261029-762',harnessRoot:'/tmp/pr449-week-comparison-20261101/trident-elk-research-20261107/trident',out:laneOut,rounds:1,profile:'full',executable:'/usr/bin/chromium',communityCoverageOnce:true,communityOutputs:['svg']})
 writeFileSync(join(laneOut,'RESULT.json'),JSON.stringify(result,null,2)+'\n')
 const rounds=JSON.parse(readFileSync(join(laneOut,'community-browser-rounds.json'),'utf8')),observed=rounds.flatMap((r:any)=>r.payload?.files??[])
 const totals={raw:0,gzip9:0,brotli11:0},product={...totals},adapter={...totals}
 const fetched=observed.map((f:any)=>{const path=join(root,decodeURIComponent(f.url).replace(/^\//,'')),b=readFileSync(path),cost={raw:b.length,gzip9:gzipSync(b,{level:9}).length,brotli11:brotliCompressSync(b,{params:{[constants.BROTLI_PARAM_QUALITY]:11}}).length},isAdapter=['entry.mjs','declared-adapter.mjs'].includes(relative(root,path));for(const k of Object.keys(totals)as(keyof typeof totals)[]){totals[k]+=cost[k];(isAdapter?adapter:product)[k]+=cost[k]};return {...f,...cost,kind:isAdapter?'Trident binding':'actual product module',actualSha256:hash(b)}})
 const modified=files.filter(f=>hash(readFileSync(f.path))!==f.sha256);if(modified.length)throw Error('Browser artifact changed during collection')
 const summary={backend,status:result.status,requests:fetched.length,totals,product,adapter,fetched,scope:'Actual observed same-four-family public-product request union in fresh browser; gzip9/Brotli11 compressed actual fetched bytes after timing. Raw local server responses, not claimed compressed wire transfer. Standard Trident binding overhead shown separately. One round; no startup/performance qualification.'};writeFileSync(join(laneOut,'DELIVERY.json'),JSON.stringify(summary,null,2)+'\n');lanes.push(summary);console.log(JSON.stringify({backend,status:result.status,requests:fetched.length,totals,product,adapter}))
}
writeFileSync(join(directory,'DELIVERY-COMPARISON.json'),JSON.stringify(lanes,null,2)+'\n');writeFileSync(join(out,'BROWSER-COMPLETED.json'),JSON.stringify({lanes:lanes.map(({backend,status,requests,totals,product,adapter})=>({backend,status,requests,totals,product,adapter}))},null,2)+'\n')
