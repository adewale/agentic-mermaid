import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import {layoutMermaidWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/agent/core.ts'
import {measureQuality} from '/tmp/pr449-main-integration-20261029-762/src/agent/quality.ts'
import {missingSvgLabels} from '/tmp/pr449-main-integration-20261029-762/src/__tests__/helpers/svg-labels.ts'
const root=import.meta.dir,arm=process.argv[2],out=root+'/cohort-'+arm,rows=[];mkdirSync(out,{recursive:true})
const cases=[]
for(const direction of ['LR','RL','TB','BT']) {
 for(const count of [6,10,16]) for(const end of ['end','start']) cases.push({id:`labelled-${end}-${direction}-${count}`,direction,count,end,kind:'labelled'})
 for(const kind of ['plain','mixed','unrelated'])cases.push({id:`${kind}-${direction}-10`,direction,count:10,end:'end',kind})
}
for(const c of cases.filter(c=>c.end!=='start')) {
 const source=`flowchart ${c.direction}\nT[Target]\n`+Array.from({length:c.count},(_,i)=>c.end==='start'?`T <--|Message ${i}| s${i}[S${i}]`:`s${i}[S${i}] ${c.kind==='mixed'&&i>=5?'--o':'-->'}${c.kind==='labelled'?`|Message ${i}|`:''} T`).join('\n')+(c.kind==='unrelated'?'\nX[X] -->|Other| Y[Y]':'')
 writeFileSync(out+'/'+c.id+'.mmd',source)
 for(const backend of ['elk','agentic','trinity'] as const) {
  const stem=c.id+'-'+backend,options={embedFontImport:false,graphLayout:{backend,fallback:'none' as const}}
  try {
   const p=renderMermaidSVGWithReceipt(source,options),receiptJSON=JSON.stringify(p.receipt),layout=layoutMermaidWithReceipt(source,options).layout,q=measureQuality(layout)
   writeFileSync(out+'/'+stem+'.svg.gz',gzipSync(p.svg));writeFileSync(out+'/'+stem+'.receipt.json.gz',gzipSync(receiptJSON))
   const labels=['Target',...Array.from({length:c.count},(_,i)=>'S'+i),...(c.kind==='labelled'||c.end==='start'?Array.from({length:c.count},(_,i)=>'Message '+i):[]),...(c.kind==='unrelated'?['X','Y','Other']:[])]
   const missing=missingSvgLabels(p.svg,labels)
   rows.push({...c,backend,stem,delivery:'returned',proof:p.receipt.layoutCertification?.status,missing,target:layout.nodes.find(n=>n.id==='T'),quality:q,svgBytes:Buffer.byteLength(p.svg),receiptBytes:Buffer.byteLength(receiptJSON)})
  } catch(e:any){ rows.push({...c,backend,stem,delivery:e.code==='GRAPH_LAYOUT_UNSUPPORTED'?'unsupported':'error',error:String(e),code:e.code}) }
 }
}
writeFileSync(out+'/RESULTS.json',JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify({arm,cells:rows.length,outcomes:rows.reduce((o:any,r)=>{const k=r.delivery+':'+r.proof;o[k]=(o[k]??0)+1;return o},{}),missing:rows.filter(r=>r.missing?.length),errors:rows.filter(r=>r.delivery!=='returned')}))
