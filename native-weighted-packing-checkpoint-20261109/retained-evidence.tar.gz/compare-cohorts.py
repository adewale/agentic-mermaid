import json,pathlib,collections
r=pathlib.Path(__file__).parent
rows=[];totals=collections.Counter();before=collections.Counter();after=collections.Counter();pending=[]
def proof(s):return s.get('svgReceipt',{}).get('layoutCertification',{}).get('status','not-returned')
for cohort in range(8):
 bp=pathlib.Path('/tmp/pr449-week-comparison-20261101/native-current-halo-201-20261109')/f'cohort-{cohort}-agentic-after/snapshot.json';ap=r/f'cohort-{cohort}-after/snapshot.json'
 if not bp.exists() or not ap.exists():pending.append(cohort);continue
 b=json.load(open(bp));a=json.load(open(ap));assert b['renderOptions']==a['renderOptions'];assert len(b['samples'])==len(a['samples'])
 for old,new in zip(b['samples'],a['samples']):
  assert all(old[k]==new[k] for k in ['id','family','source']);totals['enrolled']+=1
  pb,pa=proof(old),proof(new);before[pb]+=1;after[pa]+=1
  receiptChanged=old.get('svgReceipt')!=new.get('svgReceipt');totals['entireReceiptChanged']+=receiptChanged;svg=old.get('svg')!=new.get('svg');delivery=old['ok']!=new['ok'];changedProof=pb!=pa
  totals['SVGChanged']+=svg;totals['deliveryChanged']+=delivery;totals['proofChanged']+=changedProof
  if pb=='passed' and pa!='passed':totals['passedToOther']+=1
  if pb!='passed' and pa=='passed':totals['otherToPassed']+=1
  if svg or delivery or changedProof:
   rows.append({'cohort':cohort,'id':old['id'],'family':old['family'],'ok':[old['ok'],new['ok']],'proof':[pb,pa],'SVGChanged':svg,'before':old.get('metrics'),'after':new.get('metrics'),'errors':[old.get('failures'),new.get('failures')]})
result={'scope':'Currentfc099cea9 runtime products vs thinheadweightedpackingrestored, existing874 enrolled Native sources/options and snapshotSample consumer; unchanged replays validate, not progress. Costs are charged without cap changes. All snapshots retained.','totals':dict(totals),'beforeProof':dict(before),'afterProof':dict(after),'pendingCohorts':pending,'changed':rows}
(r/'COHORT-COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['changed','scope']}));
