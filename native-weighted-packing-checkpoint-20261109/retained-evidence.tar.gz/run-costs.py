from pathlib import Path
import os,subprocess,json
p=Path(__file__).parent;runs=[]
for direction in ['LOSS','FAN']:
 for cache in ['0','1']:
  for replica in range(2):
   lanes = ['agentic-before','agentic-after','elk-after','trinity-after'] if direction=='FAN' else ['agentic-before','agentic-after']
   for lane in (lanes if replica==0 else list(reversed(lanes))):
    backend,arm=lane.split('-')
    name=f'{direction}-{lane}-cache{cache}-{replica}'
    with (p/(name+'.log')).open('w') as log:
     r=subprocess.run(['node','--expose-gc',str(p/'measure.mjs'),str(p/name),str(p/(direction+'-'+lane+'-cost-job.json'))],env={**os.environ,'AGENTIC_MERMAID_ELK_CACHE':cache},stdout=log,stderr=subprocess.STDOUT)
    runs.append({'direction':direction,'backend':backend,'arm':arm,'cache':cache,'replica':replica,'directory':name,'exit':r.returncode});print(runs[-1],flush=True)
    if r.returncode: raise RuntimeError(name)
(p/'COST-RUNS.json').write_text(json.dumps({'runs':runs,'scope':'Currentall3 deliveredstar plusoldNativefc099; cyclic353beforeU/afterPseparate.24serialfreshprocesses120attempts.; fullSVG+entireReceipt; cache0/1 separate; two serial fresh Node24 replicas/cell, opposite-order replicas. First target excludes import; no timing ratios against former placeholder/refusal; Nativecyclic353beforeU/afterP: changedproductwork, no performance-speedup claim. No concurrent tests/build/browser/profile.'},indent=2)+'\n')
