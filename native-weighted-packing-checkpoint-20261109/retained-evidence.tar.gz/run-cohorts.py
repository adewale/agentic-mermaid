import pathlib,json,subprocess,time
r=pathlib.Path(__file__).parent;rows=[]
for j in json.load(open(r/'COHORT-JOBS.json')):
 start=time.time()
 with open(r/f"cohort-{j['cohort']}.log",'w')as log:result=subprocess.run(['node',str(r/'snapshot-selected.mjs'),j['out'],j['job']],stdout=log,stderr=subprocess.STDOUT)
 rows.append({**j,'exit':result.returncode,'acquisitionSeconds':time.time()-start});(r/'COHORT-RUNS.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
 if result.returncode:raise SystemExit(result.returncode)
