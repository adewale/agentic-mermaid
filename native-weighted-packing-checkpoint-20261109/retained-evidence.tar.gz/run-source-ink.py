from pathlib import Path
import subprocess,json,os
r=Path(__file__).parent;rows=[]
for i in range(10):
 with open(r/f'ink-source-{i}.log','w')as log: result=subprocess.run(['/tmp/pr449-tools-20261106/package/bin/bun',str(r/'ink-source-single.ts'),'source',str(i)],stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:raise SystemExit(result.returncode)
 rows.extend(json.load(open(r/f'ink-source-{i}.json'))['rows'])
(r/'SOURCE-ALL-HEADS-INK.json').write_text(json.dumps({'font':'manifest-verifiedInter/systemfontsoff','zoom':3,'scope':'All10Nativesourceheads currentproductionwithgrowthretainedandweightedpackingreenabled; eachselectedcontribution fourmasksactualSVG. Freshserialprocess/head preventsbufferaccumulation.','rows':rows},indent=2)+'\n');print({'heads':len(rows),'hidden':sum(x['hidden']for x in rows),'attenuated':sum(x['attenuated']for x in rows)})
