from pathlib import Path
import json,gzip,statistics,collections
p=Path(__file__).parent;runs=json.load(open(p/'COST-RUNS.json'))['runs'];groups={};refs={};rows=[];outcomes=collections.Counter();exact=True
for run in runs:
 x=json.loads(gzip.decompress((p/run['directory']/'RESULT.json.gz').read_bytes()));key=run['direction']+':'+run['backend']+':'+run['arm']+':cache'+run['cache'];groups.setdefault(key,[]).append(x)
 for r in x['rows']:
  outcomes[(r['status'],(r.get('proof')or{}).get('status'))]+=1
  if r['status']!='returned':continue
  stem='warmup' if r['phase']=='cold-render' else r['phase'];prod=tuple(gzip.decompress((p/run['directory']/(stem+s+'.gz')).read_bytes()) for s in ['.svg','.receipt.json']);scope=(run['direction'],run['backend'],run['arm'],'edit' if stem.startswith('edit') else 'original');refs.setdefault(scope,prod);exact &= refs[scope]==prod
 rows.append({'run':run,'rows':x['rows'],'importMs':x['importMs']})
metrics={}
for key,values in groups.items():
 metrics[key]={}
 for phase in ['cold-render','repeat1','repeat2','edit','edit2']:
  rr=[next(r for r in x['rows'] if r['phase']==phase) for x in values];v={}
  for metric in ['wallMs','cpuMs','peakRssKiB']:
   a=[r[metric] for r in rr];v[metric]={'median':statistics.median(a),'range':[min(a),max(a)]}
  for metric in ['heapUsed','rss']:
   a=[r['after'][metric] for r in rr];v[metric]={'median':statistics.median(a),'range':[min(a),max(a)]}
  metrics[key][phase]=v
report={'calls':sum(outcomes.values()),'processes':len(runs),'outcomes':[{'delivery':a,'proof':b,'count':n}for(a,b),n in outcomes.items()],'allWholeProductsExactWithinArmAndAcrossCacheStates':exact,'metrics':metrics,'runs':rows,'scope':'All3 current fullSVG+entireReceipt. Nativecyclic353before U/after P; deliveredstar all3separate. Cache setting/layoutcache only, other derivedcaches remain does different geometry/proof work: no speedup ratio.2 serial fresh Node24 replicas/cell; import separate; no concurrent checks/build. Existing layoutcache0/1, no newcache. RSS includes harness/import/compression lifetime; n too smallforgeneral/p95/memorywinner.'}
(p/'COST-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n');print(report['outcomes'],'exact',exact)
for phase in ['cold-render','repeat2','edit','edit2']:
 print(phase,{k:{m:round(v[phase][m]['median'],2) for m in ['wallMs','cpuMs','peakRssKiB']}for k,v in metrics.items()})
