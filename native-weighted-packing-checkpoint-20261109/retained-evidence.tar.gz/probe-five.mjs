import fs from 'node:fs';
import path from 'node:path';


import {pathToFileURL,fileURLToPath} from 'node:url';
import {registerHooks,stripTypeScriptTypes} from 'node:module';
import {gzipSync,brotliCompressSync} from 'node:zlib';
const out=process.argv[2],job=JSON.parse(fs.readFileSync(process.argv[3],'utf8')),root=job.root;
fs.mkdirSync(out,{recursive:true});
const maps={};
registerHooks({
 resolve(specifier,context,next){
  if(specifier.startsWith('.')&&(context.parentURL?.startsWith(pathToFileURL(root+'/').href)||context.parentURL?.includes('/node_modules/roughjs/bin/'))){
   const p=new URL(specifier,context.parentURL);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.ts'))return next(p.href+'.ts',context);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.js'))return next(p.href+'.js',context);
  }
  if(specifier.startsWith('roughjs/bin/')&&!path.extname(specifier))return next(specifier+'.js',context);
  return next(specifier,context);
 },
 load(url,context,next){
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.json'))return{format:'json',shortCircuit:true,source:fs.readFileSync(fileURLToPath(url),'utf8')};
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.ts')){
   const original=fs.readFileSync(job.moduleOverrides?.[fileURLToPath(url)] ?? fileURLToPath(url),'utf8').replaceAll('import.meta.dir',JSON.stringify(path.dirname(fileURLToPath(url))));
   const source=stripTypeScriptTypes(original,{mode:'transform',sourceMap:true,sourceUrl:url});
   const m=source.match(/sourceMappingURL=data:application\/json;base64,([^\s]+)/);
   if(m)maps[url]=JSON.parse(Buffer.from(m[1],'base64').toString());
   return{format:'module',shortCircuit:true,source};
  }
  return next(url,context);
 }
});
const {renderMermaidSVGWithReceipt}=await import(pathToFileURL(root+'/src/index.ts'));
const cases=JSON.parse(fs.readFileSync(job.cases,'utf8')); const rows=[];
for(let i=0;i<cases.length;i++){const c=cases[i];const options=job.oldOptions?c.oldOptions:c.newOptions;try{const p=renderMermaidSVGWithReceipt(c.source,options);fs.writeFileSync(out+'/'+i+'.svg',p.svg);fs.writeFileSync(out+'/'+i+'.receipt.json',JSON.stringify(p.receipt));rows.push({id:c.id,proof:p.receipt.layoutCertification?.status,issues:p.receipt.layoutCertification?.issues});}catch(e){rows.push({id:c.id,error:String(e)});}}
fs.writeFileSync(out+'/RESULT.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
