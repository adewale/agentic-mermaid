import {readFileSync,writeFileSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
import {createHash} from 'node:crypto'
import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const root='/tmp/pr449-week-comparison-20261101/native-thin-weighted-20261109'
const job=JSON.parse(readFileSync(root+'/JOB.json','utf8')), rows=[]
for(const backend of ['agentic','elk','trinity'] as const){let prior:string|undefined;for(let call=0;call<2;call++){try{const p=renderMermaidSVGWithReceipt(job.source.replace('flowchart LR','flowchart '+process.argv[2]),{...job.options,graphLayout:{...job.options.graphLayout,backend,fallback:'none'}});const product=JSON.stringify(p);writeFileSync(root+'/'+process.argv[2]+'-'+backend+call+'.svg.gz',gzipSync(p.svg));writeFileSync(root+'/'+process.argv[2]+'-'+backend+call+'.receipt.json.gz',gzipSync(JSON.stringify(p.receipt)));rows.push({backend,call,status:'returned',proof:p.receipt.layoutCertification?.status,issues:p.receipt.layoutCertification?.issues,sha256:createHash('sha256').update(p.svg).digest('hex'),repeatExact:prior===undefined?null:prior===product});prior=product}catch(e){rows.push({backend,call,status:'error',error:String(e)})}}}
writeFileSync(root+'/'+process.argv[2]+'-RESULT.json',JSON.stringify({head:'fc099cea9+weighted',runtime:Bun.version,rows},null,2)+'\n');console.log(JSON.stringify(rows))
