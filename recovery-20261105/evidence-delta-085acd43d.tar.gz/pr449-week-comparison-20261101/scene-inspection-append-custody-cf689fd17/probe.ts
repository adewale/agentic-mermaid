import { writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import * as marks from '/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts'
import { preparePixelText } from '/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts'
import { admitSceneDocument } from '/tmp/pr449-main-integration-20261029-762/src/scene/external-data-snapshot.ts'
import { createSceneWriteCapture } from '/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts'
import { inspectScenePaintGeometry } from '/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts'
import { certifyScenePaint } from '/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts'
import { MAX_OCCLUSION_OPERATIONS } from '/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts'
import { DefaultBackend } from '/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts'

if (process.argv[2] !== 'GO') throw Error('HOLD: root GO required for the one Scene append-custody probe')
const dir = '/tmp/pr449-week-comparison-20261101/scene-inspection-append-custody-cf689fd17'
const save = (name, value) => writeFileSync(`${dir}/${name}.gz`, gzipSync(typeof value === 'string' ? value : JSON.stringify(value, null, 2)))
const header = { family: 'flowchart' as const, width: 100, height: 80, colors: { bg: '#fff', fg: '#111' }, transparent: false }
const context = { positioned: { width: 100, height: 80 }, colors: header.colors, resolved: { renderOptions: {} } }
const producer = (factory, _context) => ({ ...header, parts: [
  factory.documentOpen({ id: 'root', width: 100, height: 80, colors: header.colors, transparent: false, font: 'Inter', hasMonoFont: false }, '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="80">'),
  factory.text({ id: 'text', role: 'label', text: 'Lost', block: preparePixelText('Lost', { fontSize: 12, fontWeight: 400 }), x: 30, y: 40, fontSize: 12, anchor: 'start', paint: { fill: '#111' } }),
  factory.shape({ id: 'cover', role: 'node', geometry: { kind: 'rect', x: 10, y: 10, width: 70, height: 60 }, paint: { fill: '#fff' } }),
  factory.documentClose(),
] })

// Same Scene arm as the existing drawPaintControl: one admission and write
// receipt, actual DefaultBackend output, inspection, then final certification.
const raw = producer(marks, context)
const capture = createSceneWriteCapture(MAX_OCCLUSION_OPERATIONS)
const admitted = admitSceneDocument(raw, 'internal', true, capture.observe)
const receipt = capture.finish(admitted)
const svg = DefaultBackend.render(admitted, { seed: 0 })
const inspection = inspectScenePaintGeometry(admitted, receipt)
const baseline = { svg, proof: certifyScenePaint(admitted, undefined, { sceneWriteReceipt: receipt }),
  textBounds: inspection.primitives.filter(p => p.kind === 'text').map(p => ({ id: p.id, bounds: p.bounds })) }
save('baseline.svg', svg)
save('baseline.proof.json', baseline.proof)
const pushDescriptor = Object.getOwnPropertyDescriptor(Array.prototype, 'push')!
const push = pushDescriptor.value, apply = Reflect.apply, own = Object.getOwnPropertyDescriptor, define = Object.defineProperty
let hookCount = 0, hookedProof, hookError
const observations = []
try {
  define(Array.prototype, 'push', { ...pushDescriptor, value(...values) {
    const primitive = values.length === 1 ? values[0] : undefined
    if (primitive && typeof primitive === 'object' && own(primitive, 'kind')?.value === 'text'
      && own(primitive, 'id')?.value === 'text' && own(primitive, 'coverage')?.value === 'measured') {
      hookCount++
      observations.push({ omittedId: 'text', receiverLength: this.length, stack: new Error('Measured text primitive append omitted').stack })
      return this.length
    }
    return apply(push, this, values)
  } })
  hookedProof = certifyScenePaint(admitted, undefined, { sceneWriteReceipt: receipt })
} catch (error) {
  hookError = { name: error.name, message: error.message, stack: error.stack }
} finally { define(Array.prototype, 'push', pushDescriptor) }
const hookedSvg = DefaultBackend.render(admitted, { seed: 0 })
const report = {
  sceneAdmissions: 1, sceneCertifications: 2, nativeDraws: 0, publicMermaidCalls: 0, offlineRasters: 0,
  sameAdmittedSceneAndReceipt: true, hookCount, observations, wholeSVGExact: svg === hookedSvg,
  restoredPush: Array.prototype.push === push, baseline, hooked: { svg: hookedSvg, proof: hookedProof, error: hookError },
  confirmedFalsePass: baseline.proof.status === 'failed' && hookedProof?.status === 'passed' && svg === hookedSvg && hookCount > 0,
  scope: 'One fixed Lost text covered by the later opaque white rectangle. Ambient Array.prototype.push hook omits only a measured text primitive with id=text and is installed only for the second certification of the SAME admitted Scene and receipt. The two actual SVG serializations occur outside the hook. No raster or universal ink claim; retain non-P/error/no-hook outcomes unchanged.',
}
save('hooked.svg', hookedSvg)
save('hooked.proof.json', { proof: hookedProof, error: hookError })
save('RESULT.json', report)
console.log(JSON.stringify({ ...report, baseline: { proof: baseline.proof, textBounds: baseline.textBounds }, hooked: { proof: hookedProof, error: hookError } }))
