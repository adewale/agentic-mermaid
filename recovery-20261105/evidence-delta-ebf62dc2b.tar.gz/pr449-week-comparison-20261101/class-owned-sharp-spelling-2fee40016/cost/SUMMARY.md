All 12 fully consumed calls returned passed proofs; no U/refusal/error rows. Four current-only fresh workers, no overlays. Source1585B is identical across engines/modes; edit reuses the final-relation authored revised caption (128 classes/127 relationships retained). No baseline rerenders. Old U400k timing is not comparable completed proof work. Timings are N1 observations, not a speed/memory finding. The separate owner ELK TB20-second timeout remains unresolved despite these shorter calls.

| Engine/cache | Import ms | cold/repeat/edit elapsed ms | peak RSS KiB | post-GC RSS MiB (c/r/e) | post-GC heapUsed MiB (c/r/e) |
|---|---:|---|---:|---|---|
| agentic / 0 | 1327.36 | 1709.05/1034.85/768.11 | 209212 | 140.23/193.68/192.24 | 20.76/26.15/24.45 |
| agentic / 1 | 457.23 | 879.26/303.75/470.75 | 206616 | 143.20/195.16/189.70 | 21.19/25.94/25.26 |
| elk / 0 | 965.67 | 1416.82/571.03/425.04 | 306012 | 215.24/281.71/286.95 | 42.02/48.10/49.86 |
| elk / 1 | 485.11 | 1426.38/345.03/510.15 | 287980 | 213.44/251.84/278.11 | 42.31/47.19/46.81 |

Every worker cold/repeat SVG AND entire receiptJSON is byte-exact. All corresponding phases are also byte-exact across cache modes for each engine. Both engines/modes cold (and repeat) SVG match the retained dated TB before SVG; raw before receipts differ because the old product is U400k/53 markers and current is P388607/127 markers. Edits return P389269/127 markers.

Actual positioned-layout cache events: mode0 bypass throughout; mode1 miss/hit/miss (cold/repeat/edit) for both engines. ELK mode1 miss on cold/edit, with no ELK call-stage on the positioned repeat hit. Native drawing is bypass/fallback owned-scene-geometry; paint cache is miss, detail scene, each phase. Stage callbacks record one scene, paint and backend stage per phase, including repeat hits. These are observer-stage counts, not extra API calls.

The edit input differs, actual SVG revised text occurs once (zero cold/repeat), and every edit SVG changes. No P-only or equality gate hid any outcome.

Cross-engine equality per phase (raw bytes, no normalization):
cache0 cold: SVG=True, ENTIRE receipt=False; differing top-level receipt keys=['sharedRequestDigest', 'layoutDecisions', 'requestDigest'].
cache0 repeat: SVG=True, ENTIRE receipt=False; differing top-level receipt keys=['sharedRequestDigest', 'layoutDecisions', 'requestDigest'].
cache0 edit: SVG=False, ENTIRE receipt=False; differing top-level receipt keys=['graphicalProjectionDigest', 'sharedRequestDigest', 'layoutDecisions', 'layoutCertification', 'requestDigest'].
cache1 cold: SVG=True, ENTIRE receipt=False; differing top-level receipt keys=['sharedRequestDigest', 'layoutDecisions', 'requestDigest'].
cache1 repeat: SVG=True, ENTIRE receipt=False; differing top-level receipt keys=['sharedRequestDigest', 'layoutDecisions', 'requestDigest'].
cache1 edit: SVG=False, ENTIRE receipt=False; differing top-level receipt keys=['graphicalProjectionDigest', 'sharedRequestDigest', 'layoutDecisions', 'layoutCertification', 'requestDigest'].

Memory is the recorded process footprint with imports, observers, three retained products and receiptJSON strings; GC does not establish allocation cost. RSS/heap remain substantial and mixed across phases; all raw pre/post-GC values are in SUMMARY.json. Cache0 AM repeat exceeds1s, all cold calls exceed0.87s, and the ELK cache1 edit is slower than its cache0 observation. These adverse values stay enrolled; no favorable reruns or old/new speed ratios.

The edited backend outputs differ geometrically: AM viewBox200×13976.5, revised caption(100,13848.94999999997); ELK200×14036.5, caption(74.761,13870.94999999997). Both are P389269. This difference is retained, with no cross-engine edit-SVG or meaning-equivalence claim beyond the observed single revised text and counts.

Edited caption glyph ink has not been independently raster-qualified. Original uncaptioned vertical head-ink evidence applies through exact whole-SVG equality only.
