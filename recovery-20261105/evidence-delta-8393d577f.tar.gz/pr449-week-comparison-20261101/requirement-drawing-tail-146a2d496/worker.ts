// Existing recovery-cost.ts consumer, parameterized for the affected ER source/options.
import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
Error.stackTraceLimit=40
if(process.env.PR449_ROOT_GO!=='requirement-drawing-tail-profile')throw new Error('Root GO required; no API calls started')
const job = JSON.parse(readFileSync(Bun.argv[2]!, 'utf8'))
let overlayLoads = 0
const markers:any[]=[]
let activePhase='import'
const mark=(event:string,extra:any={})=>{const value={event,phase:activePhase,performanceMs:performance.now(),timeOriginMs:performance.timeOrigin,epochMs:Date.now(),hrtimeNs:process.hrtime.bigint().toString(),cpu:process.cpuUsage(),memory:process.memoryUsage(),...extra};markers.push(value);process.stdout.write(JSON.stringify(value)+'\n')}
mark('IMPORT_START')
const importStart = performance.now()
const { renderMermaidSVGWithReceipt } = await import(job.root + '/src/index.ts')
const { withRenderStageObserver } = await import(job.root + '/src/render-stages.ts')
const { withPerformanceObserver } = await import(job.root + '/src/performance-observations.ts')
const { apiFailure } = await import(job.root + '/eval/layout-compare/outcomes.ts')
const importMs = performance.now() - importStart
mark('IMPORT_END',{importMs})
const source = readFileSync(job.sourceFile, 'utf8'), edited = readFileSync(job.editFile, 'utf8')
const options = JSON.parse(readFileSync(job.optionsFile, 'utf8'))
const consume = (value: unknown) => {
  const bytes = Buffer.from(JSON.stringify(value), 'utf8')
  return { bytes: bytes.length }
}
const outputs: unknown[] = [], rows: unknown[] = []
let actualPublicCalls = 0
mark('INITIAL_GC_START');Bun.gc(true);mark('INITIAL_GC_END')
const loaded = process.memoryUsage()
for (const [phase, input] of [['cold', source], ['repeat', source], ['edit', edited]]) {
  const stages: unknown[] = [], events: any[] = []
  activePhase=String(phase);mark('PHASE_START')
  const phaseCPUStart=process.cpuUsage()
  process.stdout.write('ACTUAL_PUBLIC_CALL_START\n')
  actualPublicCalls++
  const start = performance.now()
  let row: any
  const phaseCall = phase === 'cold' ? function requirementCold() {
    const result = withPerformanceObserver((event: unknown) => events.push(event), () => withRenderStageObserver((stage: any) => {stages.push(stage);mark('STAGE_END',stage)}, () => renderMermaidSVGWithReceipt(input, options)))
    mark('RENDER_RETURN')
    const consumed = consume(result), receiptJSON = JSON.stringify(result.receipt)
    mark('CONSUME_END')
    row = { phase, status: 'returned', elapsedMs: performance.now() - start, ...consumed, receiptJSON,
      proof: result.receipt.layoutCertification, viewBox: result.svg.match(/viewBox="([^"]+)"/)?.[1] }
    return result
  } : phase === 'repeat' ? function requirementRepeat() {
    const result = withPerformanceObserver((event: unknown) => events.push(event), () => withRenderStageObserver((stage: any) => {stages.push(stage);mark('STAGE_END',stage)}, () => renderMermaidSVGWithReceipt(input, options)))
    mark('RENDER_RETURN')
    const consumed = consume(result), receiptJSON = JSON.stringify(result.receipt)
    mark('CONSUME_END')
    row = { phase, status: 'returned', elapsedMs: performance.now() - start, ...consumed, receiptJSON,
      proof: result.receipt.layoutCertification, viewBox: result.svg.match(/viewBox="([^"]+)"/)?.[1] }
    return result
  } : function requirementEdit() {
    const result = withPerformanceObserver((event: unknown) => events.push(event), () => withRenderStageObserver((stage: any) => {stages.push(stage);mark('STAGE_END',stage)}, () => renderMermaidSVGWithReceipt(input, options)))
    mark('RENDER_RETURN')
    const consumed = consume(result), receiptJSON = JSON.stringify(result.receipt)
    mark('CONSUME_END')
    row = { phase, status: 'returned', elapsedMs: performance.now() - start, ...consumed, receiptJSON,
      proof: result.receipt.layoutCertification, viewBox: result.svg.match(/viewBox="([^"]+)"/)?.[1] }
    return result
  }
  try {
    const result = phaseCall()
    row.phaseCPU=process.cpuUsage(phaseCPUStart)
    outputs.push(result)
    mark('ARTIFACT_START')
    writeFileSync(job.out + '-' + phase + '.svg.gz', gzipSync(result.svg))
    writeFileSync(job.out + '-' + phase + '.receipt.json.gz', gzipSync(row.receiptJSON))
    const reference=job.phaseReferences[phase]
    row.previousFinalWholeSVGExact=Buffer.from(result.svg,'utf8').equals(gunzipSync(readFileSync(reference.svg)))
    row.previousFinalEntireRawReceiptExact=Buffer.from(row.receiptJSON,'utf8').equals(gunzipSync(readFileSync(reference.receipt)))
    row.previousFinalReferences=reference
    mark('ARTIFACT_END')
  } catch (error: any) {
    const failure = { error: apiFailure(error), name: error?.name, message: error?.message, stack: error?.stack, cause: { name: error?.cause?.name, message: error?.cause?.message, stack: error?.cause?.stack } }
    mark('ERROR_CONSUME_START')
    const consumed = consume(failure)
    mark('CONSUME_END',{status:'refused'})
    row = { phase, status: 'refused', elapsedMs: performance.now() - start, consumedError: consumed, failure }
    row.phaseCPU=process.cpuUsage(phaseCPUStart)
    outputs.push(failure)
  }
  row.stages = stages; row.events = events
  row.paintProviderEvents = events.filter(event => event.owner === 'paint-certification')
  row.memoryBeforeGC=process.memoryUsage();mark('PHASE_GC_START')
  Bun.gc(true);mark('PHASE_GC_END')
  row.afterGC = process.memoryUsage()
  rows.push(row)
  mark('PHASE_END',{status:row.status})
  writeFileSync(job.out+'.partial.json.gz',gzipSync(JSON.stringify({actualPublicCalls,rows,markers})))
}
writeFileSync(job.out + '.json.gz', gzipSync(JSON.stringify({ arm: job.arm, count: job.count, backend: job.backend, source, edited, options, actualPublicCalls, overlayLoads, cache: process.env.AGENTIC_MERMAID_ELK_CACHE, importMs, loaded, peakRssKiB: process.resourceUsage().maxRSS, markers, rows })))
