# Requirement drawing-tail investigation

Runtime revision: `1366d4de0ad0aee9b3b90395e1d56bd8ce2d55c5`; observed checkout `146a2d4961e72b55d4329c9eaf8c952f7cf79013` (documentation differs only).

The specific Native repeat drawing tail was not reproduced: 42.599ms in this profile, against the earlier unprofiled 150.368ms stage within a 173.471ms call. This is not a measured improvement: instrumentation differs, and long adverse delays move to other stages. Stop this drawing optimization hypothesis; the earlier timing remains unexplained. No runtime rewrite or expected speedup is supported.

Two fresh Bun CPU-profile processes, cache1, exactly six calls. Each call consumes the complete SVG and entire receipt JSON. All six saved SVGs and entire raw receipts independently match their exact retained cold/repeat/edit counterparts. Both cold/repeat products are identical within each backend. The edit changes only leaf text `Dispatch` to `Dispatch revised`, preserving three authored cards, five ordered contains occurrences and caption ownership. Native cold/repeat U99183, edit U99372; ELK cold/repeat P99199, edit P99393. These different backend proof/geometry outcomes are not interchangeable performance work.

| Backend | Phase | Consumed wall ms | Process CPU ms | Drawing ms | Paint ms | Named samples | Largest sample delta ms |
|---|---|---:|---:|---:|---:|---:|---:|
| agentic | cold | 4669.446 | 3634.168 | 4274.420 | 34.854 | 296 | 2282.494 |
| agentic | repeat | 7992.782 | 8845.893 | 42.599 | 7555.095 | 130 | 3362.882 |
| agentic | edit | 1317.930 | 1730.185 | 1191.757 | 5.716 | 114 | 274.630 |
| elk | cold | 2839.599 | 3115.515 | 373.302 | 18.425 | 617 | 449.570 |
| elk | repeat | 4753.125 | 6513.277 | 4704.920 | 27.657 | 135 | 609.868 |
| elk | edit | 320.170 | 407.978 | 34.527 | 5.203 | 85 | 141.537 |

Process CPU includes profiler/runtime/JIT/background activity and can exceed wall time. It is not exclusive JavaScript function CPU. Stage times are inclusive; nested agentic/ELK time must not be added to layout again.

All six named sample endpoint ranges fall inside their PHASE_START-to-CONSUME_END markers (outside count zero). Artifact compression, saved-product reference reads and explicit GC occur afterward. Consecutive completion intervals also include observer/log overhead and nesting. Native repeat drawing interval 42.646ms has 97.909ms process CPU; its paint interval 7555.456ms has 7718.688ms process CPU. ELK repeat drawing interval 4705.277ms has 6427.583ms process CPU. This locates broad profile-run cost, not a removable source operation.

Raw profiles and per-phase sample-delta tables are retained. They cannot honestly rank five slowest CPU functions: Native cold XML-reference validation has 3276.294ms assigned from only three self samples (largest2282.494ms); Native repeat certifyNativePaint has4551.666ms from eleven (largest3362.882ms); ELK repeat consumeStringBudget has611.166ms from two (largest609.868ms), and one writer leaf has442.187ms from one. Removing the largest gap still does not make the remainder exact CPU time or demonstrate repeated work.

Cache diagnostics: positioned-layout hits on both repeats, while native-drawing and paint-certification miss. Layout stage0.274/1.459ms (Native/ELK) is not this repeat tail. This evidence does not justify a new cache, cache removal, hash-table/flat-array substitution, AoS-to-SoA rewrite or parallel-await change. Expected speedup remains unknown.

Adverse costs remain: Native profile cold/repeat/edit4669/7993/1318ms; ELK2840/4753/320ms. Worker peakRSS109948/145692KiB; outer child peaks110672/149932KiB. Both processes retain all three products plus receipts/events/markers through GC. The profiles include imports, artifacts and GC globally; named successful phase frames exclude artifact work. N1 per backend; no throughput/latency ratio, no performance fix and no new visible-correctness claim. Prior compressed code payloads remain tied to the unchanged runtime; no build or qualification replay was needed.

Independent reviews found no supported small removable work. Preserve these artifacts and the original adverse rows; do not turn sparse sampled leaves into an optimization inventory.
