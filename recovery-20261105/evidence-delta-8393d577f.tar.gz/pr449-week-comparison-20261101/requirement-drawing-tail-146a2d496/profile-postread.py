# Reuses the retained ER profile summarizer's node-parent / exclusive-weight aggregation.
from pathlib import Path
import json,gzip,collections
import sys
O=Path('/tmp/pr449-week-comparison-20261101/requirement-drawing-tail-146a2d496');backend=sys.argv[1];assert backend in ['agentic','elk'];p=json.loads((O/(backend+'.cpuprofile')).read_text());r=json.load(gzip.open(O/(backend+'.json.gz'),'rt'));ns={n['id']:n for n in p['nodes']};parents={c:n['id']for n in p['nodes']for c in n.get('children',[])}
def ancestry(i):
 a=[i]
 while a[-1]in parents:a.append(parents[a[-1]])
 return a
paths={i:ancestry(i)for i in ns}
def key(i):
 f=ns[i]['callFrame'];return(f['functionName']or'<anonymous>',f['url'],f['lineNumber']+1,f['columnNumber']+1)
phaseIds={n['callFrame']['functionName']:n['id']for n in p['nodes']if n['callFrame']['functionName']in ['requirementCold','requirementRepeat','requirementEdit']}
samples=[];cursor=p['startTime']
for leaf,delta in zip(p['samples'],p['timeDeltas']):
 cursor+=delta;phase=next((name for name,id in phaseIds.items()if id in paths[leaf]),None);samples.append({'leaf':leaf,'deltaUs':delta,'phase':phase,'sampleEpochMs':cursor/1000})
def aggregate(selected):
 selfN=collections.Counter();selfUS=collections.Counter();incN=collections.Counter();incUS=collections.Counter();largest=collections.defaultdict(int)
 for x in selected:
  i=x['leaf'];d=x['deltaUs'];k=key(i);selfN[k]+=1;selfUS[k]+=d;largest[k]=max(largest[k],d)
  for k in set(key(j)for j in paths[i]):incN[k]+=1;incUS[k]+=d
 def record(k):return {'function':k[0],'url':k[1],'line':k[2],'column':k[3],'selfSamples':selfN[k],'selfWeightMs':selfUS[k]/1000,'largestSelfSampleMs':largest[k]/1000,'selfWeightWithoutLargestSampleMs':(selfUS[k]-largest[k])/1000,'inclusiveSamples':incN[k],'inclusiveWeightMs':incUS[k]/1000}
 ks=[k for k,n in selfN.items()if '/src/'in k[1]and k[1].startswith('file:///tmp/pr449-main-integration-20261029-762/')]
 top=sorted(ks,key=lambda k:(selfUS[k],selfN[k]),reverse=True)
 biggest=max(selected,key=lambda x:x['deltaUs'])if selected else None
 return {'samples':len(selected),'sampleWeightMs':sum(x['deltaUs']for x in selected)/1000,'sourceSelfSamples':sum(selfN[k]for k in ks),'sourceSelfWeightMs':sum(selfUS[k]for k in ks)/1000,'top5ExclusiveSelfSource':[record(k)for k in top[:5]],'sceneExclusiveSelf':[record(k)for k in top if '/src/scene/'in k[1]][:10],'largestSample':({'weightMs':biggest['deltaUs']/1000,'frame':dict(zip(['function','url','line','column'],key(biggest['leaf']))),'epochMs':biggest['sampleEpochMs'],'ancestry':[dict(zip(['function','url','line','column'],key(i)))for i in paths[biggest['leaf']][:12]]}if biggest else None)}
out={'scope':'One current-only cache1 Requirement fan process; exclusive self delta weights from named ancestry, not measured exclusive CPU duration. Raw whole-process profile includes imports/artifacts/compression/reference reads/GC; named successful API+full-consumption frames exclude those. No old-tail explanation unless reproduced.','backend':backend,'profileSpanMs':(p['endTime']-p['startTime'])/1000,'allSamples':len(samples),'allSampleWeightMs':sum(x['deltaUs']for x in samples)/1000,'combinedNamedPhases':aggregate([x for x in samples if x['phase']]),'phases':{},'measurementRows':r['rows'],'peakRssKiB':r['peakRssKiB'],'cache':r['cache'],'globalLargestSample':max(samples,key=lambda x:x['deltaUs'])if samples else None}
for phase in ['cold','repeat','edit']:
 name={'cold':'requirementCold','repeat':'requirementRepeat','edit':'requirementEdit'}[phase]
 selected=[x for x in samples if x['phase']==name];a=aggregate(selected)
 row=next((x for x in r['rows']if x['phase']==phase),None);a['row']=row;a['namedFramePresent']=name in phaseIds
 markers=[m for m in r['markers']if m['phase']==phase];a['markers']=markers
 # Snapshot differences between completed-stage callbacks include observer/log
 # overhead and nesting. They are process CPU intervals, not exclusive stage CPU.
 prior=next((m for m in markers if m['event']=='PHASE_START'),None);windows=[]
 for marker in [m for m in markers if m['event']=='STAGE_END']:
  if prior:
   windows.append({'endingStage':marker.get('stage'),'reportedStageWallMs':marker.get('ms'),'startPerformanceMs':prior['performanceMs'],'endPerformanceMs':marker['performanceMs'],'intervalWallMs':marker['performanceMs']-prior['performanceMs'],'processCPUUserMs':(marker['cpu']['user']-prior['cpu']['user'])/1000,'processCPUSystemMs':(marker['cpu']['system']-prior['cpu']['system'])/1000,'scope':'Consecutive callback completion interval; nested stages and logging/observer overhead prevent exclusive-stage attribution'})
  prior=marker
 a['stageCompletionCPUWindows']=windows
 start=next((m for m in markers if m['event']=='PHASE_START'),None);end=next((m for m in markers if m['event']=='CONSUME_END'),None)
 epochs=[x['sampleEpochMs']for x in selected]
 a['namedSampleEpochRangeMs']=[min(epochs),max(epochs)]if epochs else None
 a['namedSampleEndOutsideMarkerWindowCount']=sum(not(start['timeOriginMs']+start['performanceMs']-2<=v<=end['timeOriginMs']+end['performanceMs']+2)for v in epochs)if start and end else None
 out['phases'][phase]=a
out['limitations']=['N1 per backend; profiling/markers/GC alter timing and memory. Observer-instrumented diagnostic, not benchmark. No performance ratio or causal savings claim.','timeDeltas are elapsed sample weights, not CPU durations. Per-phase process.cpuUsage and sample counts/largest deltas are retained separately.','Large sample deltas can dominate rankings; largest delta and self weight without it are retained.','Named phase frames may inline or be absent: missing named frames mean unavailable ancestry attribution, not zero phase work or attribution to another phase.','CPU sample gaps/native/JIT/GC/scheduling do not automatically identify CPU or waiting.','Consecutive stage callback CPU windows include nesting/logging and cannot be called exact exclusive stage CPU.','Full three held products plus receipts/events remain rooted through postGC; postGC heap is not independent retained minimum.','Thrown API errors are fully consumed and saved; failure consumption is outside the successful named wrapper and therefore absent from named-ancestry sample buckets.','Whole-process profile contains compression/GC; named wrappers and PHASE_START-to-CONSUME_END successful windows end before artifact/reference processing.']
(O/(backend+'-PROFILE-SUMMARY.json')).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'backend':backend,'profileSpanMs':out['profileSpanMs'],'allSamples':out['allSamples'],'phases':{phase:{'status':a['row'].get('status')if a['row']else None,'elapsedMs':a['row'].get('elapsedMs')if a['row']else None,'phaseCPU':a['row'].get('phaseCPU')if a['row']else None,'namedFramePresent':a['namedFramePresent'],'samples':a['samples'],'elapsedSampleWeightMs':a['sampleWeightMs'],'largestSample':a['largestSample'],'top5ExclusiveSelfSource':a['top5ExclusiveSelfSource']}for phase,a in out['phases'].items()}},indent=2))
