from pathlib import Path
import json
W=Path('/tmp/pr449-week-comparison-20261101');O=W/'requirement-drawing-tail-146a2d496';C=W/'requirement-elk-dock-cost-219a84f61'
O.mkdir(exist_ok=True)
for name in ['source.mmd','edit.mmd','agentic.options.json','elk.options.json']:(O/name).write_bytes((C/name).read_bytes())
s=(W/'sparse256-elk-repeat-profile-30844276e/worker.ts').read_text().replace('sparse256-elk-repeat-profile','requirement-drawing-tail-profile').replace('sparseCold','requirementCold').replace('sparseRepeat','requirementRepeat').replace('sparseEdit','requirementEdit').replace("import { gzipSync }", "import { gzipSync, gunzipSync }")
s=s.replace("  let checksum = 0\n  for (let i = 0; i < bytes.length; i++) checksum = (Math.imul(checksum, 31) + bytes[i]!) >>> 0\n  return { bytes: bytes.length, checksum }", "  return { bytes: bytes.length }")
s=s.replace("    writeFileSync(job.out + '-' + phase + '.svg.gz', gzipSync(result.svg))", "    writeFileSync(job.out + '-' + phase + '.svg.gz', gzipSync(result.svg))\n    writeFileSync(job.out + '-' + phase + '.receipt.json.gz', gzipSync(row.receiptJSON))\n    const reference=job.phaseReferences[phase]\n    row.previousFinalWholeSVGExact=Buffer.from(result.svg,'utf8').equals(gunzipSync(readFileSync(reference.svg)))\n    row.previousFinalEntireRawReceiptExact=Buffer.from(row.receiptJSON,'utf8').equals(gunzipSync(readFileSync(reference.receipt)))\n    row.previousFinalReferences=reference")
s=s.replace("    const consumed = consume(failure)\n", "    mark('ERROR_CONSUME_START')\n    const consumed = consume(failure)\n    mark('CONSUME_END',{status:'refused'})\n")
s=s.replace("  activePhase=String(phase);mark('PHASE_START')", "  activePhase=String(phase);mark('PHASE_START')\n  const phaseCPUStart=process.cpuUsage()")
s=s.replace("    outputs.push(result)\n", "    row.phaseCPU=process.cpuUsage(phaseCPUStart)\n    outputs.push(result)\n")
s=s.replace("    outputs.push(failure)\n", "    row.phaseCPU=process.cpuUsage(phaseCPUStart)\n    outputs.push(failure)\n")
(O/'worker.ts').write_text(s)
jobs=[]
for backend in ['agentic','elk']:
 job={'root':'/tmp/pr449-main-integration-20261029-762','arm':'current-profile','count':'5contains-fan','backend':backend,'expectedCache':1,'expectedHead':'146a2d496','sourceFile':str(O/'source.mmd'),'editFile':str(O/'edit.mmd'),'optionsFile':str(O/(backend+'.options.json')),'out':str(O/backend),'phaseReferences':{phase:{'svg':str(C/f'{backend}-cache1-{phase}.svg.gz'),'receipt':str(C/f'{backend}-cache1-{phase}.receipt.json.gz')}for phase in ['cold','repeat','edit']}}
 name=backend+'.job.json';jobs.append(name);(O/name).write_text(json.dumps(job,indent=2)+'\n')
# Retain the existing ancestry/exclusive-delta aggregator, parameterize its files
# and replace only the prior run's hardcoded narrative/measurements.
post=Path('/tmp/pr449-sparse256-profile-postread.py').read_text().split("out={'scope'")[0]
old="O=Path('/tmp/pr449-week-comparison-20261101/sparse256-elk-repeat-profile-30844276e');p=json.loads((O/'sparse256-elk-repeat.cpuprofile').read_text());r=json.load(gzip.open(O/'current.json.gz','rt'));"
new="import sys\nO=Path('/tmp/pr449-week-comparison-20261101/requirement-drawing-tail-146a2d496');backend=sys.argv[1];assert backend in ['agentic','elk'];p=json.loads((O/(backend+'.cpuprofile')).read_text());r=json.load(gzip.open(O/(backend+'.json.gz'),'rt'));"
assert old in post;post=post.replace(old,new).replace('sparseCold','requirementCold').replace('sparseRepeat','requirementRepeat').replace('sparseEdit','requirementEdit')
post+='''out={'scope':'One current-only cache1 Requirement fan process; exclusive self delta weights from named ancestry, not measured exclusive CPU duration. Raw whole-process profile includes imports/artifacts/compression/reference reads/GC; named successful API+full-consumption frames exclude those. No old-tail explanation unless reproduced.','backend':backend,'profileSpanMs':(p['endTime']-p['startTime'])/1000,'allSamples':len(samples),'allSampleWeightMs':sum(x['deltaUs']for x in samples)/1000,'combinedNamedPhases':aggregate([x for x in samples if x['phase']]),'phases':{},'measurementRows':r['rows'],'peakRssKiB':r['peakRssKiB'],'cache':r['cache'],'globalLargestSample':max(samples,key=lambda x:x['deltaUs'])if samples else None}
for phase in ['cold','repeat','edit']:
 name={'cold':'requirementCold','repeat':'requirementRepeat','edit':'requirementEdit'}[phase]
 selected=[x for x in samples if x['phase']==name];a=aggregate(selected)
 row=next((x for x in r['rows']if x['phase']==phase),None);a['row']=row;a['namedFramePresent']=name in phaseIds
 markers=[m for m in r['markers']if m['phase']==phase];a['markers']=markers
 # Snapshot differences between completed-stage callbacks include observer/log
 # overhead and nesting. They are process CPU intervals, not exclusive stage CPU.
 prior=next((m for m in markers if m['event']=='PHASE_START'),None);windows=[]
 for marker in [m for m in markers if m['event']=='STAGE_END']:
  if prior:
   windows.append({'endingStage':marker.get('stage'),'reportedStageWallMs':marker.get('ms'),'startPerformanceMs':prior['performanceMs'],'endPerformanceMs':marker['performanceMs'],'intervalWallMs':marker['performanceMs']-prior['performanceMs'],'processCPUUserMs':(marker['cpu']['user']-prior['cpu']['user'])/1000,'processCPUSystemMs':(marker['cpu']['system']-prior['cpu']['system'])/1000,'scope':'Consecutive callback completion interval; nested stages and logging/observer overhead prevent exclusive-stage attribution'})
  prior=marker
 a['stageCompletionCPUWindows']=windows
 start=next((m for m in markers if m['event']=='PHASE_START'),None);end=next((m for m in markers if m['event']=='CONSUME_END'),None)
 epochs=[x['sampleEpochMs']for x in selected]
 a['namedSampleEpochRangeMs']=[min(epochs),max(epochs)]if epochs else None
 a['namedSampleEndOutsideMarkerWindowCount']=sum(not(start['timeOriginMs']+start['performanceMs']-2<=v<=end['timeOriginMs']+end['performanceMs']+2)for v in epochs)if start and end else None
 out['phases'][phase]=a
out['limitations']=['N1 per backend; profiling/markers/GC alter timing and memory. Observer-instrumented diagnostic, not benchmark. No performance ratio or causal savings claim.','timeDeltas are elapsed sample weights, not CPU durations. Per-phase process.cpuUsage and sample counts/largest deltas are retained separately.','Large sample deltas can dominate rankings; largest delta and self weight without it are retained.','Named phase frames may inline or be absent: missing named frames mean unavailable ancestry attribution, not zero phase work or attribution to another phase.','CPU sample gaps/native/JIT/GC/scheduling do not automatically identify CPU or waiting.','Consecutive stage callback CPU windows include nesting/logging and cannot be called exact exclusive stage CPU.','Full three held products plus receipts/events remain rooted through postGC; postGC heap is not independent retained minimum.','Thrown API errors are fully consumed and saved; failure consumption is outside the successful named wrapper and therefore absent from named-ancestry sample buckets.','Whole-process profile contains compression/GC; named wrappers and PHASE_START-to-CONSUME_END successful windows end before artifact/reference processing.']
(O/(backend+'-PROFILE-SUMMARY.json')).write_text(json.dumps(out,indent=2)+'\\n')
print(json.dumps({'backend':backend,'profileSpanMs':out['profileSpanMs'],'allSamples':out['allSamples'],'phases':{phase:{'status':a['row'].get('status')if a['row']else None,'elapsedMs':a['row'].get('elapsedMs')if a['row']else None,'phaseCPU':a['row'].get('phaseCPU')if a['row']else None,'namedFramePresent':a['namedFramePresent'],'samples':a['samples'],'elapsedSampleWeightMs':a['sampleWeightMs'],'largestSample':a['largestSample'],'top5ExclusiveSelfSource':a['top5ExclusiveSelfSource']}for phase,a in out['phases'].items()}},indent=2))
'''
(O/'profile-postread.py').write_text(post)
import ast
ast.parse(post)
meta={'status':'HOLD static preparation only; no runtime imports/calls/profiles/builds','reuse':['/tmp/pr449-sparse256-elk-repeat-profile-prepare.py','sparse256-elk-repeat-profile-30844276e/worker.ts','/tmp/pr449-sparse256-profile-postread.py'],'jobs':jobs,'rootGoNamespace':'requirement-drawing-tail-profile','workers':2,'maxPublicCalls':6,'cache':1,'phases':['cold','repeat','edit'],'profile':'Bun --cpu-prof, existing default1ms sampling, one whole-process profile per backend. Named requirementCold/Repeat/Edit wrapper encloses public render+whole-result/ENTIREreceipt consumption and ends before artifacts/compression/reference reads/GC.','markers':'Existing cumulative wall/CPU/memory markers, completed-stage callbacks. Postreader retains weighted self/inclusive/largest-gap summaries and consecutive completed-stage processCPU windows.','references':'Corresponding previous final requirement-elk-dock-cost-219a84f61 backend/cache1/cold-repeat-edit fullSVG+ENTIREreceipt, compared outside phase windows.','namedAdverse':{'nativeRepeatMs':173.47,'nativeRepeatDrawingMs':150.37,'elkRepeatMs':36.39},'retention':'FullSVG.gz+ENTIREreceipt.json.gz per returnedphase, fullerrors, stages/events/phaseCPU/rawmarkers, beforeGC/afterGCmemory/maxRSS, cold/edit/P/U/adverse rows and partial receipts. Three output products retained throughout.','limits':'Current-only N1 diagnostics; cannot explain prior tail unless reproduced; sampling deltas are not CPU durations; stagecompletion CPU windows include nesting/observer/logging. No overlays/checksums/newcaches/framework, artifactcompression outside measured successful phasewindow. ForcedGC occurs betweenphases as existing tool. Root sole CPU.'}
(O/'PREPARED.json').write_text(json.dumps(meta,indent=2)+'\n')
print('STATIC_FILE_PREPARATION_COMPLETE: no runtime imports, calls, profiles or builds')
