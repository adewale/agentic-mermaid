import { readFileSync, writeFileSync, writeSync, mkdirSync, existsSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { dirname, resolve } from 'node:path'
import { gzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
const root='/tmp/pr449-main-integration-20261029-762',fixture='/tmp/pr449-week-comparison-20261101/sparse256-header-seat-8f9',arm='causal-header-seat',out=process.argv[2],candidateFile=process.argv[3],backend='agentic'
Error.stackTraceLimit=40
const sourcePath=fixture+'/source.mmd'
if(!out||!candidateFile||process.env.PR449_ROOT_GO!=='sparse256-header-seat')throw new Error('Held: root GO, output and exact offrepo layout candidate required; zero calls started')
if(existsSync(out+'/RESULT.json.gz'))throw new Error('Refuse to overwrite an existing product')
const modulePath=root+'/src/er/layout.ts',candidatePath=resolve(candidateFile)
if(candidatePath.startsWith(root+'/'))throw new Error('Candidate must remain offrepo')
const sha=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex')
const candidateBytes=readFileSync(candidatePath),baselineBytes=readFileSync(modulePath)
let overlayLoads=0
Bun.plugin({name:'held-exact-er-layout-causal-overlay',setup(build){
 build.onLoad({filter:/\/src\/er\/layout\.ts$/},args=>{
  if(resolve(args.path)!==modulePath)return
  overlayLoads++
  writeSync(1,JSON.stringify({event:'EXACT_LAYOUT_OVERLAY_LOAD',path:args.path,candidatePath,sha256:sha(candidateBytes),overlayLoads})+'\n')
  return {contents:candidateBytes.toString('utf8'),loader:'ts',resolveDir:dirname(modulePath)}
 })
}})
mkdirSync(out,{recursive:true})
const sourceBytes=readFileSync(sourcePath),source=sourceBytes.toString('utf8')
const revision=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8',env:{...process.env,GIT_NO_LAZY_FETCH:'1',GIT_OPTIONAL_LOCKS:'0'}}).trim()
const wallStart=performance.now(),cpuStart=process.cpuUsage()
const log=(value:unknown)=>writeSync(1,JSON.stringify(value)+'\n')
log({event:'IMPORT_START',memory:process.memoryUsage(),cpu:process.cpuUsage()})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const {withRenderStageObserver}=await import(root+'/src/render-stages.ts')
const {withPerformanceObserver}=await import(root+'/src/performance-observations.ts')
const {apiFailure}=await import(root+'/eval/layout-compare/outcomes.ts')
const importMs=performance.now()-wallStart,importCPU=process.cpuUsage(cpuStart)
const optionsFile=fixture+'/agentic.options.json'
const options=JSON.parse(readFileSync(optionsFile,'utf8'))
const stages:any[]=[],events:any[]=[]
const before=process.memoryUsage(),renderCPU=process.cpuUsage(),renderStart=performance.now()
let product:any,row:any
log({event:'ACTUAL_PUBLIC_CALL_START',actualCalls:1,importMs,importCPU,before})
try{
 const artifact=withPerformanceObserver(event=>events.push(event),()=>withRenderStageObserver(stage=>{stages.push(stage);log({event:'STAGE_COMPLETE',...stage})},()=>renderMermaidSVGWithReceipt(source,options)))
 product={svg:artifact.svg,receipt:artifact.receipt}
 const bytes=Buffer.from(JSON.stringify(product))
 writeFileSync(out+'/product.json.gz',gzipSync(bytes))
 writeFileSync(out+'/actual.svg.gz',gzipSync(product.svg));writeFileSync(out+'/actual.receipt.json.gz',gzipSync(JSON.stringify(product.receipt)))
 row={status:'returned',fullyConsumedBytes:bytes.length,proof:product.receipt.layoutCertification}
 const proofJSON=JSON.stringify(product.receipt.layoutCertification)
 if(proofJSON!==undefined)writeFileSync(out+'/actual.proof.json.gz',gzipSync(proofJSON))
}catch(error:any){
 product={normalized:apiFailure(error),name:error?.name,message:error?.message,code:error?.code,stack:error?.stack,cause:error?.cause?{name:error.cause.name,message:error.cause.message,stack:error.cause.stack}:undefined,certification:error?.certification}
 const bytes=Buffer.from(JSON.stringify(product));writeFileSync(out+'/product.json.gz',gzipSync(bytes));row={status:'refused',fullyConsumedErrorBytes:bytes.length,failure:product}
 const proofJSON=JSON.stringify(error?.certification)
 if(proofJSON!==undefined)writeFileSync(out+'/actual.proof.json.gz',gzipSync(proofJSON))
}
const memoryBeforeGC=process.memoryUsage();Bun.gc(true);const postGCMemory=process.memoryUsage()
const report={caseKind:'uncommitted-module-causal-header-seat',causalUncommittedProduct:true,sameInputQualification:false,sameAuthorSourceAndDefaultOptions:true,performanceEvidence:false,sourceChangedFromRetained:false,optionsChangedFromRetained:false,optionsDelta:{},optionsFile,measurementScope:'Single same-author-source/default-options causal attempt under one exact offrepo module overlay; not a committed qualification or performance claim.',runtimeSourceOverlay:{modulePath,candidatePath,candidateSha256:sha(candidateBytes),baselineSha256:sha(baselineBytes),overlayLoads},hypothesis:{onlyMovedIsolate:'N255',headerPaint:{x0:473.098,y0:39.5},body:{x:473.598,y:40},expectedViewport:{width:1831,height:1907.5},other253IsolateSeats:'unchanged',actualResultNotAssumed:true},revision,arm,sourceBytesUnchanged:sourceBytes.equals(readFileSync(sourcePath)),backend,sourcePath,memoryBeforeGC,postGCMemory,actualPublicCalls:1,source,options,importMs,importCPU,renderWallMs:performance.now()-renderStart,renderCPU:process.cpuUsage(renderCPU),totalWallMs:performance.now()-wallStart,totalCPU:process.cpuUsage(cpuStart),loadedMemory:before,afterMemory:process.memoryUsage(),peakRssKiB:process.resourceUsage().maxRSS,row,provider:events.filter(e=>e.owner==='paint-certification'),stages,events,product}
writeFileSync(out+'/RESULT.json.gz',gzipSync(JSON.stringify(report)))
log({event:'ACTUAL_PUBLIC_CALL_COMPLETE',...report,product:undefined,events:undefined})
