Recover the local layout and SVG fixes developed after #449: restore authored text and endpoint ink, deliver previously refused Class/ER cases, and reduce the area of selected Native layouts.

This is a **draft recovery PR**. It targets `review/pr449-recovery-base-3b56da55`, pinned to `3b56da55e6570908beb5d96c25f4c03c1a828a22`, so the diff contains the 90 campaign commits across 60 files. Current `main` is `6996aac89601a436375a052150cbe3cd53c0946b`; integration and qualification against it remain unfinished. The original recovery branch and all local evidence are preserved.

## Changes and observable contract

Authored node identities, parents, relationship occurrences, text and marker ends must survive into the final SVG and contribute the intended ink. Layout delivery, visible correctness and certification status are recorded separately.

- Class caption seating and final coordinate publication restore nested-caption delivery from 6/8 to 8/8 and allow Class128 to certify in all four directions. A broader normalization that caused ten regressions was withdrawn.
- ER endpoint allocation accounts for both cardinality glyphs and their leads. ER208 now completes paint certification; the inward frame-to-leaf witness now renders instead of refusing. The ER256 relationship chain still refuses in both backends.
- Measured forest placement reduces the enrolled forest's area by 26.98% and wire by 33.80% from its earlier Native result. Isolated-card packing reduces sparse-256 area by 52.95% while preserving connected geometry.
- Shared emission preserves closed inline formatting across hard breaks. Private inspection records and emission ownership prevent the reproduced false certification passes caused by mutable data and interposed lookups.
- Requirement ports reserve painted marker pitch and normal terminal clearance. Flowchart solid carriers leave a bounded gap beneath fixed hollow circles, including captured orthogonal STEP paths. The original route, marker resource and attachment point remain intact.

The changes preserve the existing operation/pair/depth limits and retain determinism, UTF16, mutable/getter, CSS, definition and ownership controls. The [revision-by-revision work log](https://github.com/adewale/agentic-mermaid/blob/c74d826ca198f9204f8f79228ae0c3eb3323839c/docs/design/system/layout-0.6-work-log.md) records the evidence and adverse trials.

## Remaining delta from ELK

These are retained same-input campaign measurements. They were not rerun merely to populate this PR, and they do not describe current `main`.

| Workload | Agentic result relative to ELK | Remaining cause or tradeoff |
| --- | --- | --- |
| Sparse-256 cards | Area **+115.35%**; wire lower | Body gaps remain 71px versus 20px after the packing improvement. |
| Nonlinear forest | Wire **+16.89%**; area −6.43% | The current fixed-dock routes are already shortest; a leaf-seating trial increased area by 6.88% and was stopped. |
| Requirement cycle | TB/BT area **+9.53%**; LR/RL area −1.44% | The directional placement loss remains enrolled. |

The ER256 relationship chain is a shared refusal. Sparse32 returns the authored 1,500 text records and 32 contributing markers, but remains unverified at the 400,000-operation cap. The original `campaign-baseline2dadf0dbc2685c8435df541de99f3edce841450d`, Trident and pinned Mermaid12.2/Pele1.9 were unavailable in the recovery environment, so this PR makes no complete peer ranking. Replacement24 remains sealed.

## Visual evidence

Claim: on the latest STEP fan witness, the selected circle is visible where the wide black shaft previously absorbed it.

Input: `step-wide-circle`, with identical source/options at both visual checkpoints:

```mermaid
flowchart LR
    A e1@--o B
    A --> C
e1@{ curve: step }
linkStyle 0 stroke:#000,stroke-width:10px
```

Baseline SHA: `3b56da55e6570908beb5d96c25f4c03c1a828a22`.
Current SHA: `c74d826ca198f9204f8f79228ae0c3eb3323839c`; the runtime is identical to `ca8fb1221f56d5f57fe08972770ebb056a46b30f` because the final commit changes documentation only. The before product was rendered at the PR recovery base. Its complete SVG is byte-identical to the intermediate pre-STEP product, so the existing pinned-font before raster and zero-contribution observation are reused by that byte binding.

| Before | After | Why / what to inspect |
| --- | --- | --- |
| <img alt="Before: the thick A-to-B STEP shaft completely hides its hollow circle at B" src="https://raw.githubusercontent.com/adewale/agentic-mermaid/bcc799ccc362f71d63384eaa31a879d412cd74a2/pr449-step-wide-circle/before.png" width="360"> | <img alt="After: the hollow circle at B is visible and touches the same STEP shaft" src="https://raw.githubusercontent.com/adewale/agentic-mermaid/bcc799ccc362f71d63384eaa31a879d412cd74a2/pr449-step-wide-circle/after.png" width="360"> | Inspect the circle immediately left of B. The A-to-C arrow, all node boxes and all route vertices stay unchanged; only the selected shaft's terminal paint is shortened. |

[Original SVGs, full receipts, source/options and provenance](https://github.com/adewale/agentic-mermaid/tree/bcc799ccc362f71d63384eaa31a879d412cd74a2/pr449-step-wide-circle) are retained on a separate evidence branch, outside this PR's source diff. Images copy the existing pinned-Inter Resvg artifacts without image edits; the [provenance receipt](https://raw.githubusercontent.com/adewale/agentic-mermaid/bcc799ccc362f71d63384eaa31a879d412cd74a2/pr449-step-wide-circle/provenance.json) binds the fresh base SVG to those pixels. The [independent delta record](https://raw.githubusercontent.com/adewale/agentic-mermaid/bcc799ccc362f71d63384eaa31a879d412cd74a2/pr449-step-wide-circle/INDEPENDENT-DELTA-REVIEW.json) establishes that removing only the new dash and reversing the generated class names reconstructs the complete before SVG byte for byte. Both backend SVGs are identical on this witness. Removing only the selected marker changes 0 pixels before and 225 confined pixels after.

Regenerate the owning public/geometry checks with Bun1.4.2:

```sh
bun test src/__tests__/endpoint-marker-contact.test.ts src/__tests__/curved-connector-projection.test.ts --test-name-pattern 'step fan|captured STEP|served arclength' --timeout 60000
```

Independent check: [endpoint-marker-contact.test.ts](https://github.com/adewale/agentic-mermaid/blob/c74d826ca198f9204f8f79228ae0c3eb3323839c/src/__tests__/endpoint-marker-contact.test.ts) checks authored relations, normal contacts, actual marker contribution and shaft-to-ring contact. [curved-connector-projection.test.ts](https://github.com/adewale/agentic-mermaid/blob/c74d826ca198f9204f8f79228ae0c3eb3323839c/src/__tests__/curved-connector-projection.test.ts) covers served arclength, duplicate legs, changing getters and unsafe corner/reversal cases.

Limitation: this pair demonstrates one 10px circle witness with pinned Inter. Both proofs remain **unverified**, with the same potential-occlusion issue; recovery-base work is 158,330 operations and head work is 158,091. It does not establish arbitrary-font readability or general curve/loop visibility; raw multipoint, cubic, closed and insufficient-runway carriers remain outside the latest fix.

## Verification and costs

At the published runtime revision, the relevant seven-file connector/validation/cache milestone passed **287 tests**, the final projection owner passed **61**, and core types and lint passed. Before the STEP runtime patch, the Native public test had zero circle pixels and four projection positives failed. All 18 focused cases passed after it. The first test-type failure and an invalid ELK-turn assumption were corrected and retained in the evidence.

Earlier broad qualification retained **973 passes and the known Sparse32 failure**; the whole repository suite has not been rerun at this final head. Earlier milestones establish only their recorded revisions. Published-head CI has not been qualified, so this draft carries no readiness claim.

The latest STEP commit adds **109 certification operations** relative to its immediate pre-fix checkpoint, 30 raw SVG bytes and 18 bytes under each of Bun's gzip9/Brotli11 compressors. It adds one bounded O(N) scan and temporary strings. Its certification remains unverified. For that latest commit alone, the Flowchart code closures add 551 gzip/507 Brotli bytes for Native and 549/497 for ELK; request counts do not change.

Twelve current-candidate calls consumed the whole SVG and entire receipt. Repeat products were byte-identical and the edited B text was visible. One sample per phase, in milliseconds, after module imports:

| Cache setting | Agentic cold / repeat / edit | ELK cold / repeat / edit |
| --- | --- | --- |
| 0 | 315 / 56 / 61 | 806 / 81 / 60 |
| 1 | 195 / 18 / 40 | 1086 / 110 / 208 |

Imports, compression, RSS and heap are recorded separately. Peak RSS was 106,332/104,888KiB for Native and 143,152/141,576KiB for ELK across cache0/1 workers. These single samples support no causal speedup claim; the slower ELK cache1 observations remain enrolled. Two fresh Node24 source products and two compiled products match the complete SVG and receipt bytes.

The main integration risks are shared emission/validation changes and interaction with changes made on `main` since recovery. ELK remains the default, and this PR changes no version or publication settings.
