# Current cyclic18-cuts saved-SVG comparison

Both final combined owner packets use the exact same retained source/options;
only backend differs (fallback none, embedFontImport:false, spacing/idPrefix omitted).
This is a distinct current comparison for newly enrolled Agentic owner coverage,
not algorithm progress or a before/current implementation improvement.

| Actual final SVG | Area px² | Semantic shaft length px | Bends | Protected circle gap px | Paint proof |
|---|---:|---:|---:|---:|---|
| agentic | 1093800.558592 | 17477.808799 | 90 | 11.000000000 | passed 301282/400000, 38 markers |
| elk | 1539411.366909 | 19196.118806 | 99 | 6.815399562 | passed 308388/400000, 38 markers |

Vectors reuse the existing semantic-polyline method: sum written orthogonal
segment lengths and count direction changes; anonymous marker overlays are
excluded to avoid double-counting semantic shafts. Area is actual SVG width×height.

Protected gap uses the existing owner formula for foreign shaft n0→n13 versus
circle n1: minimum point-to-segment center distance − circle radius − half circle
stroke −2×shaft stroke. Circle radius59.5, circle stroke0.75 and shaft stroke1
in both arms; center distances72.875 (Agentic) and68.690399562 (ELK). These positive
fixed-case margins do not qualify every contact or exact glyph/marker ink.

Both saved arms retain18 authored node names,38 source/target/caption occurrences
(including duplicates) and10 caption owners with exact owned text. This fixed-case
correspondence is separate from paint P. All heads' individually visible ink is
UNKNOWN: no individual-head removal/raster analysis was performed. No font/browser
universal, arbitrary-input, complete-contact, timing or runtime-ratio claim.

Inputs: agentic.combined.RESULT.json.gz and elk.combined.RESULT.json.gz. First
Agentic artifact remains untouched. Offline processing only:0 API/layout calls,
0 rasters,0 builds; independent-summary.json retains exact vectors and scope.
