import { plugin } from 'bun'
import { readFileSync, writeFileSync } from 'node:fs'
const dir='/tmp/pr449-week-comparison-20261101/cyclic18-contact-owner-a36f81d23'
plugin({name:'one new18-cuts owner evidence capture',setup(build){build.onLoad({filter:/\/src\/__tests__\/route-contracts\.test\.ts$/},args=>{
 let source=readFileSync(args.path,'utf8')
 const anchor="const rendered=renderMermaidSVGWithReceipt(source,{graphLayout:{backend,fallback:'none'},embedFontImport:false})"
 if(source.split(anchor).length!==2)throw Error('Expected one owned render anchor')
 source="import {writeFileSync as saveContactOwnerEvidence} from 'node:fs'\nimport {gzipSync as zipContactOwnerEvidence} from 'node:zlib'\n"+source.replace(anchor,anchor+`;saveContactOwnerEvidence('${dir}/'+backend+'.RESULT.json.gz',zipContactOwnerEvidence(JSON.stringify({source,options:{graphLayout:{backend,fallback:'none'},embedFontImport:false},product:rendered})))`)
 writeFileSync(dir+'/captured-owner.ts',source)
 return{contents:source,loader:'ts'}
})}})
