// Disposable saved-SVG comparison, adapted from cyclic19 independent-review.ts.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { gunzipSync, gzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { Resvg } from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import { HOSTED_FONT_RESOURCES } from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import { inlineFontVarForRaster } from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'

if (process.env.PR449_ROOT_GO !== 'sparse256-isolate-offline-ink') throw Error('HOLD: root GO required before SVG reads or raster calls')
const { JSDOM } = createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
const repo = '/tmp/pr449-main-integration-20261029-762', week = '/tmp/pr449-week-comparison-20261101'
const out = week + '/sparse256-isolate-085acd43d'
const paths = {
  before: week + '/scene-inspection-append-node24-68a7d7ce9/agentic/agentic.svg.gz',
  after: out + '/cost/current-cold.svg.gz',
}
type Box = { x0: number; y0: number; x1: number; y1: number }
const report: any = { publicCalls: 0, offlineRasterCalls: 0, rasterLimit: 10, zoom: 1, paths, checks: [], arms: {}, errors: [],
  verificationGitRevision: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim(),
  scope: 'Saved actual SVGs, original viewports, four independently removed objects per arm; fixed manifest-verified Inter with system fonts disabled. No input/SVG hashes, browser/font-universal or whole-ink claim.' }
const save = () => fs.writeFileSync(out + '/offline-ink.json', JSON.stringify(report, null, 2))
const check = (name: string, run: () => unknown) => {
  try { const detail = run(); report.checks.push({ name, status: 'passed', detail }) }
  catch (e: any) { report.checks.push({ name, status: 'failed', message: e.message }); report.errors.push({ name, message: e.message, stack: e.stack }) }
}
const num = (e: any, key: string, fallback?: number): number => {
  const raw = e.getAttribute(key), n = raw === null ? fallback : Number(raw)
  assert(Number.isFinite(n), `Unresolved ${e.localName}.${key}: ${raw}`); return n!
}
const inflate = (b: Box, amount: number): Box => ({ x0: b.x0 - amount, y0: b.y0 - amount, x1: b.x1 + amount, y1: b.y1 + amount })
const overlap = (a: Box, b: Box) => a.x0 < b.x1 && a.x1 > b.x0 && a.y0 < b.y1 && a.y1 > b.y0
const union = (boxes: Box[]): Box => {
  assert(boxes.length > 0); return { x0: Math.min(...boxes.map(b => b.x0)), y0: Math.min(...boxes.map(b => b.y0)), x1: Math.max(...boxes.map(b => b.x1)), y1: Math.max(...boxes.map(b => b.y1)) }
}
// Actual flat cardinality vocabulary and entity/label rectangles; unknowns fail.
const shapeBox = (e: any): Box => {
  assert(!e.hasAttribute('transform'), 'Unexpected transformed actual shape')
  const half = num(e, 'stroke-width', 0) / 2
  if (e.localName === 'rect') {
    const x = num(e, 'x'), y = num(e, 'y'); return inflate({ x0: x, y0: y, x1: x + num(e, 'width'), y1: y + num(e, 'height') }, half)
  }
  assert.equal(e.localName, 'line', 'This witness has one/one tick cardinalities')
  const x1 = num(e, 'x1'), y1 = num(e, 'y1'), x2 = num(e, 'x2'), y2 = num(e, 'y2')
  assert(x1 === x2 || y1 === y2); assert([null, 'butt'].includes(e.getAttribute('stroke-linecap')))
  return { x0: Math.min(x1, x2) - (x1 === x2 ? half : 0), x1: Math.max(x1, x2) + (x1 === x2 ? half : 0), y0: Math.min(y1, y2) - (y1 === y2 ? half : 0), y1: Math.max(y1, y2) + (y1 === y2 ? half : 0) }
}
const rawGroup = (svg: string, id: string): string => {
  const tokens = /<\/?g\b[^>]*>/g
  let found: RegExpExecArray | null, start = -1, depth = 0
  while ((found = tokens.exec(svg))) {
    if (start < 0) { if (!found[0].startsWith('</') && found[0].includes(`data-id="${id}"`)) { start = found.index; depth = 1 } }
    else { depth += found[0].startsWith('</') ? -1 : 1; if (depth === 0) return svg.slice(start, tokens.lastIndex) }
  }
  throw Error('Missing raw group ' + id)
}
const load = (path: string) => {
  const svg = gunzipSync(fs.readFileSync(path)).toString(), dom = new JSDOM(svg, { contentType: 'image/svg+xml' }), d = dom.window.document
  const root = d.documentElement, viewBox = root.getAttribute('viewBox').trim().split(/\s+/).map(Number)
  assert.equal(viewBox.length, 4); assert(viewBox.every(Number.isFinite)); assert.deepEqual(viewBox.slice(0, 2), [0, 0])
  const leaves = [...d.querySelectorAll('text,rect,polyline')], rawLeaves = [...svg.matchAll(/<(?:rect|polyline)\b[^>]*\/>|<text\b[^>]*>[\s\S]*?<\/text>/g)].map(m => m[0])
  assert.equal(leaves.length, rawLeaves.length, 'Actual element order binds raw tags')
  return { svg, dom, d, leaves, rawLeaves, viewport: { width: num(root, 'width'), height: num(root, 'height'), viewBox } }
}
const rawLeaf = (item: ReturnType<typeof load>, e: any): string => {
  const index = item.leaves.indexOf(e); assert(index >= 0, 'Selected actual leaf belongs to this SVG'); return item.rawLeaves[index]!
}
const entityName = (item: ReturnType<typeof load>, id: string): any => {
  const group = item.d.querySelector(`g.entity[data-role="entity"][data-id="${id}"]`); assert(group, 'Actual owning entity ' + id)
  const texts = [...group.querySelectorAll('text')], matches = texts.filter((e: any) => e.textContent === id)
  assert.equal(matches.length, 1, 'One exact owned name ' + id); assert.equal(texts[0], matches[0], 'Entity header is first actual text'); return matches[0]
}
const actualLabelPill = (item: ReturnType<typeof load>): { label: any; pill: any } => {
  const labels = [...item.d.querySelectorAll('text')].filter((e: any) => e.textContent === 'owns'); assert.equal(labels.length, 1, 'One actual relationship label')
  const label = labels[0], pill = label.previousElementSibling; assert.equal(pill?.localName, 'rect', 'Actual preceding relationship pill'); return { label, pill }
}
let before: ReturnType<typeof load> | undefined, after: ReturnType<typeof load> | undefined, scratch: string | undefined
try {
  before = load(paths.before); after = load(paths.after)
  for (const [arm, item] of [['before', before], ['after', after]] as const) {
    report.arms[arm] = { viewport: item.viewport, removals: [] }
    check(arm + ': authored ownership', () => {
      const entities = [...item.d.querySelectorAll('g.entity[data-role="entity"]')], expected = Array.from({ length: 256 }, (_, i) => 'N' + i)
      assert.deepEqual(entities.map((e: any) => e.getAttribute('data-id')), expected)
      for (let i = 0; i < entities.length; i++) assert.equal(entityName(item, expected[i]!).textContent, expected[i])
      const rels = [...item.d.querySelectorAll('polyline.er-relationship')]
      assert.equal(rels.length, 1)
      assert.deepEqual(['data-id', 'data-from', 'data-to', 'data-cardinality1', 'data-cardinality2', 'data-identifying', 'data-label'].map(k => rels[0].getAttribute(k)), ['rel:N0-N1#0', 'N0', 'N1', 'one', 'one', 'true', 'owns'])
      const cards = [...item.d.querySelectorAll('g[data-role="cardinality"]')]
      assert.deepEqual(cards.map((e: any) => [e.getAttribute('data-id'), e.getAttribute('data-owner-id'), e.getAttribute('data-end'), e.getAttribute('data-endpoint')]), [['card:N0-N1#0:1', 'rel:N0-N1#0', 'start', 'N0'], ['card:N0-N1#0:2', 'rel:N0-N1#0', 'end', 'N1']])
      for (const g of cards) { assert.equal(g.children.length, 2); for (const piece of g.children) assert.equal(piece.localName, 'line') }
      return { entityIDsAndOwnedNames: 256, orderedRelationships: 1, individuallyOwnedCardinalities: 2 }
    })
  }
  check('connected actual bytes and resources unchanged', () => {
    for (const id of ['N0', 'N1', 'card:N0-N1#0:1', 'card:N0-N1#0:2']) assert.equal(rawGroup(before!.svg, id), rawGroup(after!.svg, id), id)
    assert.equal(rawLeaf(before!, before!.d.querySelector('polyline.er-relationship')), rawLeaf(after!, after!.d.querySelector('polyline.er-relationship')), 'Actual carrier')
    // These actual label/pill tags have no data-id. Their ordered tail follows
    // the final cardinality group and includes the unchanged document close.
    const cardID = 'card:N0-N1#0:2', bcard = rawGroup(before!.svg, cardID), acard = rawGroup(after!.svg, cardID)
    assert.equal(before!.svg.slice(before!.svg.indexOf(bcard) + bcard.length), after!.svg.slice(after!.svg.indexOf(acard) + acard.length), 'Exact actual label/pill tail')
    const blabel = actualLabelPill(before!), alabel = actualLabelPill(after!)
    assert.equal(rawLeaf(before!, blabel.label), rawLeaf(after!, alabel.label)); assert.equal(rawLeaf(before!, blabel.pill), rawLeaf(after!, alabel.pill))
    for (const name of ['defs', 'style']) {
      const pattern = new RegExp(`<${name}\\b[^>]*>[\\s\\S]*?<\\/${name}>`, 'g')
      assert.deepEqual(before!.svg.match(pattern) ?? [], after!.svg.match(pattern) ?? [], name)
    }
    return { incidentalIDExclusions: 0 }
  })
  check('after: moved isolate bodies clear actual connected ink envelopes', () => {
    const d = after!.d, rel = d.querySelector('polyline.er-relationship'), points = rel.getAttribute('points').trim().split(/\s+/).map((p: string) => p.split(',').map(Number)), half = num(rel, 'stroke-width') / 2
    const obstacles: Box[] = []
    for (let i = 1; i < points.length; i++) {
      const [x1, y1] = points[i - 1], [x2, y2] = points[i]; assert([x1, y1, x2, y2].every(Number.isFinite)); assert(x1 === x2 || y1 === y2)
      obstacles.push({ x0: Math.min(x1, x2) - (x1 === x2 ? half : 0), x1: Math.max(x1, x2) + (x1 === x2 ? half : 0), y0: Math.min(y1, y2) - (y1 === y2 ? half : 0), y1: Math.max(y1, y2) + (y1 === y2 ? half : 0) })
    }
    for (const piece of d.querySelectorAll('g[data-role="cardinality"] > *')) obstacles.push(shapeBox(piece))
    obstacles.push(shapeBox(actualLabelPill(after!).pill))
    for (let i = 2; i < 256; i++) {
      const body = shapeBox(d.querySelector(`g.entity[data-role="entity"][data-id="N${i}"] rect`))
      assert(obstacles.every(box => !overlap(body, box)), `N${i} overlaps unchanged shaft/cardinality/label envelope`)
      assert(body.x0 >= 0 && body.y0 >= 0 && body.x1 <= after!.viewport.viewBox[2] && body.y1 <= after!.viewport.viewBox[3], `N${i} frame outside actual viewport`)
    }
    return { isolatedBodies: 254, connectedInkBoxes: obstacles.length }
  })
  scratch = fs.mkdtempSync('/tmp/pr449-sparse256-ink-fonts-')
  const fonts = HOSTED_FONT_RESOURCES.filter(f => f.family === 'Inter'), fontFiles = fonts.map(f => {
    const bytes = fs.readFileSync(repo + '/' + f.path); assert.equal(bytes.length, f.bytes); assert.equal(createHash('sha256').update(bytes).digest('hex'), f.sha256)
    const path = scratch + '/' + f.file; fs.writeFileSync(path, bytes); return path
  })
  report.fonts = fonts.map(({ file, bytes, sha256 }) => ({ file, bytes, sha256 }))
  const raster = (svg: string) => {
    assert(report.offlineRasterCalls < 10, 'No raster retry/additional variant authorized'); report.offlineRasterCalls++
    return new Resvg(inlineFontVarForRaster(svg), { background: '#fff', fitTo: { mode: 'zoom', value: 1 }, font: { fontFiles, fontDirs: [], loadSystemFonts: false, defaultFontFamily: 'Inter' } }).render()
  }
  for (const [arm, item] of [['before', before], ['after', after]] as const) {
    try {
      const full = raster(item.svg), fullPixels = full.pixels
      fs.writeFileSync(`${out}/ink-${arm}-full.png.gz`, gzipSync(full.asPng()))
      for (const id of ['N0', 'N255', 'card:N0-N1#0:1', 'card:N0-N1#0:2']) {
        try {
          const name = id === 'N0' || id === 'N255', e = name ? entityName(item, id) : item.d.querySelector(`g[data-role="cardinality"][data-id="${id}"]`); assert(e)
          let box: Box, tag: string
          if (name) {
            assert.equal(e.localName, 'text'); const x = num(e, 'x'), y = num(e, 'y') + num(e, 'dy', 0), width = num(e, 'textLength'), size = num(e, 'font-size')
            assert.equal(e.getAttribute('text-anchor'), 'middle'); box = inflate({ x0: x - width / 2, x1: x + width / 2, y0: y - size * 1.5, y1: y + size * .5 }, 2); tag = rawLeaf(item, e)
          } else { box = inflate(union([...e.children].map(shapeBox)), 2); tag = rawGroup(item.svg, id) }
          assert.equal(item.svg.split(tag).length, 2, 'One exact removed object')
          const masked = item.svg.replace(tag, ''), mask = raster(masked), mp = mask.pixels
          assert.equal(mask.width, full.width); assert.equal(mask.height, full.height)
          let changedPixels = 0, darker = 0, lighter = 0, outside = 0
          for (let k = 0; k < fullPixels.length; k += 4) {
            if (![0, 1, 2, 3].some(c => Math.abs(fullPixels[k + c] - mp[k + c]) >= 4)) continue
            changedPixels++; const n = k / 4, x = (n % full.width + .5) * item.viewport.viewBox[2] / full.width, y = (Math.floor(n / full.width) + .5) * item.viewport.viewBox[3] / full.height
            if (x < box.x0 || x > box.x1 || y < box.y0 || y > box.y1) outside++
            if (fullPixels[k] + fullPixels[k + 1] + fullPixels[k + 2] < mp[k] + mp[k + 1] + mp[k + 2]) darker++; else lighter++
          }
          const row = { id, roi: box, changedPixels, darker, lighter, outside, positiveConfinedContribution: darker > 0 && outside === 0 }
          report.arms[arm].removals.push(row)
          fs.writeFileSync(`${out}/ink-${arm}-without-${id.replace(/[^a-zA-Z0-9]/g, '_')}.png.gz`, gzipSync(mask.asPng()))
          assert(row.positiveConfinedContribution, `Missing or unconfined actual contribution ${arm}/${id}`)
        } catch (e: any) { report.errors.push({ arm, id, message: e.message, stack: e.stack }) }
      }
    } catch (e: any) { report.errors.push({ arm, message: e.message, stack: e.stack }) }
    save()
  }
} catch (e: any) { report.errors.push({ message: e.message, stack: e.stack }) }
finally {
  if (scratch) fs.rmSync(scratch, { recursive: true, force: true })
  before?.dom.window.close(); after?.dom.window.close()
  report.status = report.errors.length ? 'failed-or-unresolved' : 'passed-fixed-font-offline-checks'
  save(); console.log(JSON.stringify(report)); if (report.errors.length) process.exitCode = 1
}
