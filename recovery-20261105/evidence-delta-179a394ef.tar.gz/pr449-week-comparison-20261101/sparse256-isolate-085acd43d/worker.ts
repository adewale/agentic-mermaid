import { readFileSync, writeFileSync, writeSync, mkdirSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
const root='/tmp/pr449-main-integration-20261029-762',fixture='/tmp/pr449-week-comparison-20261101/sparse256-isolate-085acd43d',arm=process.argv[2],out=process.argv[3],backend=process.argv[4]??'agentic'
Error.stackTraceLimit=40
const sourcePath=fixture+'/source.mmd'
if(!arm||!out||!['agentic','elk'].includes(backend)||process.env.PR449_ROOT_GO!=='sparse256-isolate')throw new Error('Held: root GO, arm/output and backend required; zero calls started')
mkdirSync(out,{recursive:true})
const sourceBytes=readFileSync(sourcePath),source=sourceBytes.toString('utf8')
const revision=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8',env:{...process.env,GIT_NO_LAZY_FETCH:'1',GIT_OPTIONAL_LOCKS:'0'}}).trim()
const binding=JSON.parse(readFileSync(fixture+'/../scene-inspection-append-node24-68a7d7ce9/bindings-er256cards-node24.json','utf8')).find((b:any)=>b.backend===backend)
const wallStart=performance.now(),cpuStart=process.cpuUsage()
const log=(value:unknown)=>writeSync(1,JSON.stringify(value)+'\n')
log({event:'IMPORT_START',memory:process.memoryUsage(),cpu:process.cpuUsage()})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const {withRenderStageObserver}=await import(root+'/src/render-stages.ts')
const {withPerformanceObserver}=await import(root+'/src/performance-observations.ts')
const {apiFailure}=await import(root+'/eval/layout-compare/outcomes.ts')
const importMs=performance.now()-wallStart,importCPU=process.cpuUsage(cpuStart)
const options=JSON.parse(readFileSync(fixture+'/'+backend+'.options.json','utf8'))
const stages:any[]=[],events:any[]=[]
const before=process.memoryUsage(),renderCPU=process.cpuUsage(),renderStart=performance.now()
let product:any,row:any
log({event:'ACTUAL_PUBLIC_CALL_START',actualCalls:1,importMs,importCPU,before})
try{
 const artifact=withPerformanceObserver(event=>events.push(event),()=>withRenderStageObserver(stage=>{stages.push(stage);log({event:'STAGE_COMPLETE',...stage})},()=>renderMermaidSVGWithReceipt(source,options)))
 product={svg:artifact.svg,receipt:artifact.receipt}
 const bytes=Buffer.from(JSON.stringify(product))
 writeFileSync(out+'/product.json.gz',gzipSync(bytes))
 writeFileSync(out+'/actual.svg.gz',gzipSync(product.svg));writeFileSync(out+'/actual.receipt.json.gz',gzipSync(JSON.stringify(product.receipt)))
 row={status:'returned',fullyConsumedBytes:bytes.length,wholeSVGExactToRetained:product.svg===gunzipSync(readFileSync(binding.svgReference)).toString(),entireRawReceiptExactToRetained:JSON.stringify(product.receipt)===gunzipSync(readFileSync(binding.receiptReference)).toString(),proof:product.receipt.layoutCertification}
}catch(error:any){
 product={normalized:apiFailure(error),name:error?.name,message:error?.message,code:error?.code,stack:error?.stack,cause:error?.cause?{name:error.cause.name,message:error.cause.message,stack:error.cause.stack}:undefined,certification:error?.certification}
 const bytes=Buffer.from(JSON.stringify(product));writeFileSync(out+'/product.json.gz',gzipSync(bytes));row={status:'refused',fullyConsumedErrorBytes:bytes.length,failure:product}
}
const memoryBeforeGC=process.memoryUsage();Bun.gc(true);const postGCMemory=process.memoryUsage()
const report={revision,arm,sourceBytesUnchanged:sourceBytes.equals(readFileSync(sourcePath)),retainedReferenceRevision:binding.sourceHead,backend,sourcePath,memoryBeforeGC,postGCMemory,actualPublicCalls:1,source,options,importMs,importCPU,renderWallMs:performance.now()-renderStart,renderCPU:process.cpuUsage(renderCPU),totalWallMs:performance.now()-wallStart,totalCPU:process.cpuUsage(cpuStart),loadedMemory:before,afterMemory:process.memoryUsage(),peakRssKiB:process.resourceUsage().maxRSS,row,provider:events.filter(e=>e.owner==='paint-certification'),stages,events,product}
writeFileSync(out+'/RESULT.json.gz',gzipSync(JSON.stringify(report)))
log({event:'ACTUAL_PUBLIC_CALL_COMPLETE',...report,product:undefined,events:undefined})
