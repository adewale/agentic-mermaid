// Existing single-public-call sufficiency consumer; UNSAFE NONSHIPPING overlay.
import { readFileSync, writeFileSync, writeSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const root = '/tmp/pr449-main-integration-20261029-762'
const out = '/tmp/pr449-week-comparison-20261101/er256-glyph-union-sufficiency-5aa10b3c0'
let overlayLoads = 0
Bun.plugin({ name: 'NONSHIPPING stable-body plus glyph-union sufficiency', setup(build) {
  build.onLoad({ filter: /\/src\/er\/layout\.ts$/ }, args => {
    if (args.path !== root + '/src/er/layout.ts') return
    overlayLoads++
    return { contents: readFileSync(out + '/NONSHIPPING-layout.ts', 'utf8'), loader: 'ts' }
  })
} })
const importStart = performance.now()
const { renderMermaidSVGWithReceipt } = await import(root + '/src/index.ts')
const { withPerformanceObserver } = await import(root + '/src/performance-observations.ts')
const { withRenderStageObserver } = await import(root + '/src/render-stages.ts')
const { apiFailure } = await import(root + '/eval/layout-compare/outcomes.ts')
const importMs = performance.now() - importStart
const source = readFileSync(out + '/source.mmd', 'utf8'), options = JSON.parse(readFileSync(out + '/options.json', 'utf8'))
const phaseLines = JSON.parse(readFileSync(out + '/phase-lines.json', 'utf8'))
const consume = (value: unknown) => {
  const bytes = Buffer.from(JSON.stringify(value)); let checksum = 0
  for (const byte of bytes) checksum = (Math.imul(checksum, 31) + byte) >>> 0
  return { bytes: bytes.length, checksum }
}
const stages: any[] = [], events: any[] = []
Bun.gc(true)
const beforeMemory = process.memoryUsage(), cpuStart = process.cpuUsage(), start = performance.now()
let actualPublicCalls = 0, product: any, outcome: any
writeSync(1, 'ACTUAL_PUBLIC_CALL_START\n'); actualPublicCalls++
try {
  product = withPerformanceObserver(event => events.push(event), () => withRenderStageObserver(stage => stages.push(stage), () => renderMermaidSVGWithReceipt(source, options)))
  const consumed = consume(product), receiptJSON = JSON.stringify(product.receipt)
  outcome = { status: 'returned', phase: 'delivered-final-svg', elapsedMs: performance.now() - start, cpu: process.cpuUsage(cpuStart), ...consumed, receiptJSON, proof: product.receipt.layoutCertification }
  writeFileSync(out + '/actual.svg.gz', gzipSync(product.svg))
  writeFileSync(out + '/actual.receipt.json.gz', gzipSync(receiptJSON))
} catch (error: any) {
  product = { normalized: apiFailure(error), name: error?.name, message: error?.message, code: error?.code, stack: error?.stack, cause: { name: error?.cause?.name, message: error?.cause?.message, stack: error?.cause?.stack } }
  const consumedError = consume(product)
  const match = /at finishErGeometry .*\/src\/er\/layout\.ts:(\d+):/.exec(error?.stack ?? '')
  const line = match ? Number(match[1]) : undefined
  const phase = line === undefined ? 'unknown-see-full-stack' : phaseLines.filter((row: any) => row.line <= line).at(-1)?.phase ?? 'before-final-geometry-sweep'
  outcome = { status: 'refused', phase, phaseInference: 'Saved overlay source line ranges, not runtime instrumentation', finishErGeometryLine: line, elapsedMs: performance.now() - start, cpu: process.cpuUsage(cpuStart), consumedError, failure: product }
  writeFileSync(out + '/actual.error.json.gz', gzipSync(JSON.stringify(product)))
}
const afterMemory = process.memoryUsage()
Bun.gc(true)
const result = { step: 'UNSAFE_NONSHIPPING_OPTIMISTIC_SUFFICIENCY_FALSIFIER', actualPublicCalls, overlayLoads, source, options, importMs, outcome, stages, events, beforeMemory, afterMemory, afterGC: process.memoryUsage(), peakRssKiB: process.resourceUsage().maxRSS, product, scope: 'Existing stable-body index plus one glyph-union obstacle/shaft query each. Every per-piece exact predicate and all later label checks retained; same400000 cap/fees. Generic mutable/getter inputs UNSAFE. Not production eligibility/qualification, no timing claim.' }
writeFileSync(out + '/RESULT.json.gz', gzipSync(JSON.stringify(result)))
writeSync(1, JSON.stringify({ status: outcome.status, phase: outcome.phase, actualPublicCalls, overlayLoads, proofStatus: outcome.proof?.status, error: outcome.failure?.code, peakRssKiB: result.peakRssKiB }) + '\n')
