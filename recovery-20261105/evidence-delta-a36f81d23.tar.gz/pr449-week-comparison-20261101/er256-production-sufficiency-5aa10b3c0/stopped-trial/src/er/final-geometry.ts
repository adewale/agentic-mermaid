import type { PositionedErDiagram, PositionedErEntity, PositionedErRelationship } from './types.ts'
import type { Point } from '../types.ts'
import type { ResolvedRenderStyle } from '../styles.ts'
import type { Geometry, MarkPaint } from '../scene/ir.ts'
import { isOwnedPixelTextPart } from '../shared/prepared-text.ts'
import { erCardinalityPieces, erCardinalityPieceInk, erLabelPillGeometry, type ErCardinalityPiece } from './cardinality-geometry.ts'

const freeze = Object.freeze,
  define = Object.defineProperty,
  descriptor = Object.getOwnPropertyDescriptor,
  keys = Reflect.ownKeys,
  prototype = Object.getPrototypeOf
const own = Object.hasOwn,
  create = Object.create,
  objectPrototype = Object.prototype
const arrayPrototype = Array.prototype,
  mapPrototype = Map.prototype,
  setPrototype = Set.prototype
const arrayMethods = ['push', 'map', 'flatMap', 'filter', 'sort', 'slice', 'some', 'every', 'reduce', 'at', Symbol.iterator] as const
const arrayOperations = arrayMethods.map(key => descriptor(arrayPrototype, key)?.value)
const mapMethods = ['get', 'set', 'values'] as const,
  mapOperations = mapMethods.map(key => descriptor(mapPrototype, key)?.value)
const setMethods = ['has', 'add', Symbol.iterator] as const,
  setOperations = setMethods.map(key => descriptor(setPrototype, key)?.value)
const MapConstructor = Map,
  SetConstructor = Set,
  objectValues = Object.values
function ordinaryOperations(): boolean {
  if (Map !== MapConstructor || Set !== SetConstructor || Object.values !== objectValues) return false
  for (let i = 0; i < arrayMethods.length; i++) if (descriptor(arrayPrototype, arrayMethods[i]!)?.value !== arrayOperations[i]) return false
  for (let i = 0; i < mapMethods.length; i++) if (descriptor(mapPrototype, mapMethods[i]!)?.value !== mapOperations[i]) return false
  for (let i = 0; i < setMethods.length; i++) if (descriptor(setPrototype, setMethods[i]!)?.value !== setOperations[i]) return false
  return true
}
const operandConstruction = {}
const invalid = Symbol('not-own-data')
type Pay = (units?: number) => void
type Box = { x0: number; y0: number; x1: number; y1: number }
const PointSet = WeakSet,
  pointAdd = WeakSet.prototype.add,
  pointHas = WeakSet.prototype.has,
  apply = Reflect.apply
const entityFields = ['id', 'x', 'y', 'width', 'height', 'headerHeight', 'rowHeight', 'label', 'labelContent', 'attributes', 'attributeBlocks', 'labelBlock', 'emptyAttributeBlock', 'className', 'inlineStyle', 'groupId'] as const
const styleFields = ['lineWidth', 'nodeLineWidth', 'cornerRadius', 'edgeBendRadius'] as const
function data(value: object, key: PropertyKey): unknown {
  const d = descriptor(value, key)
  return d ? (own(d, 'value') ? d.value : invalid) : undefined
}
function shell(value: object, pay?: Pay): boolean {
  const names = keys(value)
  pay?.(names.length + 1)
  for (let i = 0; i < names.length; i++) {
    const d = descriptor(value, names[i]!)
    if (!d || !own(d, 'value')) return false
  }
  return true
}
function absent(value: object, field: string): boolean {
  return data(value, field) === undefined && !descriptor(objectPrototype, field)
}
function slot<T>(array: T[], value: T): void {
  define(array, array.length, { __proto__: null, value, enumerable: true, writable: true, configurable: true } as PropertyDescriptor)
}

export interface ErPreparedEntity {
  readonly row: PositionedErEntity
  readonly geometry: Extract<Geometry, { kind: 'rect' }>
  readonly strokeWidth: number
  readonly headerHeight: number
  readonly rowHeight: number
}
export interface ErPreparedRelationship {
  readonly geometry: Extract<Geometry, { kind: 'polyline' }>
}
interface EntityRow {
  source: PositionedErEntity
  view: ErPreparedEntity
  box: Box
}
interface RelationshipRow {
  source: PositionedErRelationship
  sourcePoints: Point[]
  original: readonly Point[]
  view: ErPreparedRelationship
  fields: readonly unknown[]
  glyphs: Array<{ pieces: readonly ErCardinalityPiece[]; bounds: readonly Box[]; box: Box } | undefined>
  center: Point | undefined
  sourceCenter: Point | undefined
  block: object | undefined
  width: number
  height: number
  pill: Extract<Geometry, { kind: 'rect' }> | undefined
}
const relationFields = ['entity1', 'entity2', 'cardinality1', 'cardinality2', 'label', 'identifying', 'labelBlock', 'labelContent'] as const

class OriginalErSource {
  constructor(source: object) {
    return source
  }
}
class ErRow extends OriginalErSource {
  #owner: ErGeometryOwnership
  #ordinal: number
  #relationship: boolean
  constructor(source: object, owner: ErGeometryOwnership, ordinal: number, relationship: boolean) {
    super(source)
    this.#owner = owner
    this.#ordinal = ordinal
    this.#relationship = relationship
  }
  static index(source: object, owner: ErGeometryOwnership, relationship: boolean): number | undefined {
    return #owner in source && source.#owner === owner && source.#relationship === relationship ? source.#ordinal : undefined
  }
}
/** Factories create the actual public literals; supplied objects cannot enroll. */
export class ErGeometryOwnership {
  #entities: PositionedErEntity[] = []
  #relationships: Array<{ source: PositionedErRelationship; points: Point[]; owned: Point[] | undefined }> = []
  #pay: Pay | undefined
  constructor(pay: Pay) {
    this.#pay = pay
  }
  complete(): void {
    this.#pay = undefined
  }
  #centers: Array<Point | undefined> = []
  #pointRosters = new PointSet<object>()
  #publicEntities: PositionedErEntity[] | undefined
  #publicRelationships: PositionedErRelationship[] | undefined
  #publicGroups: PositionedErDiagram['groups'] | undefined
  entity(fields: PositionedErEntity): PositionedErEntity {
    this.#pay?.()
    const value = { ...fields }
    new ErRow(value, this, this.#entities.length, false)
    slot(this.#entities, value)
    return value
  }
  points(source: readonly Point[]): Point[] {
    const result: Point[] = []
    for (let i = 0; i < source.length; i++) {
      const p = source[i]!
      slot(result, { x: p.x, y: p.y })
      this.#pay?.()
    }
    apply(pointAdd, this.#pointRosters, [result])
    return result
  }
  relationship(fields: PositionedErRelationship): PositionedErRelationship {
    this.#pay?.()
    const source = { ...fields }
    new ErRow(source, this, this.#relationships.length, true)
    slot(this.#relationships, { source, points: source.points, owned: undefined })
    this.route(source, source.points)
    return source
  }
  route(source: PositionedErRelationship, points: Point[]): void {
    const index = ErRow.index(source, this, true)
    if (index === undefined) return
    const row = this.#relationships[index]!
    row.points = points
    row.owned = undefined
    if (!apply(pointHas, this.#pointRosters, [points])) return
    const owned: Point[] = []
    for (let i = 0; i < points.length; i++) slot(owned, points[i]!)
    row.owned = owned
  }
  center = (source: PositionedErRelationship, x: number, y: number): Point => {
    this.#pay?.()
    const point = { x, y }
    const index = ErRow.index(source, this, true)
    if (index !== undefined) define(this.#centers, index, { __proto__: null, value: point, writable: true, enumerable: true, configurable: true } as PropertyDescriptor)
    return point
  }
  root(fields: PositionedErDiagram): PositionedErDiagram {
    const entities: PositionedErEntity[] = fields.entities === this.#publicEntities ? fields.entities : [],
      relationships: PositionedErRelationship[] = fields.relationships === this.#publicRelationships ? fields.relationships : []
    if (entities !== fields.entities) for (let i = 0; i < fields.entities.length; i++) slot(entities, fields.entities[i]!)
    if (relationships !== fields.relationships) for (let i = 0; i < fields.relationships.length; i++) slot(relationships, fields.relationships[i]!)
    const source = { ...fields, entities, relationships }
    this.#publicEntities ??= entities
    this.#publicRelationships ??= relationships
    this.#publicGroups ??= source.groups
    new ErSource(source, this)
    return source
  }
  prepare(source: PositionedErDiagram, style: ResolvedRenderStyle, pay: Pay): ErFinalGeometry | undefined {
    return prepareRows(source, style, pay, this, this.#entities, this.#relationships, this.#centers, this.#publicEntities, this.#publicRelationships, this.#publicGroups)
  }
}
class ErSource extends OriginalErSource {
  #ownership: ErGeometryOwnership
  #operand: ErFinalGeometry | undefined
  constructor(source: PositionedErDiagram, ownership: ErGeometryOwnership) {
    super(source)
    this.#ownership = ownership
  }
  static ownership(source: PositionedErDiagram): ErGeometryOwnership | undefined {
    return #ownership in source ? source.#ownership : undefined
  }
  static get(source: PositionedErDiagram): ErFinalGeometry | undefined {
    return #operand in source ? source.#operand : undefined
  }
  static put(source: PositionedErDiagram, operand: ErFinalGeometry): void {
    if (#operand in source) source.#operand = operand
  }
}
export function inheritErGeometrySource(source: PositionedErDiagram, fields: PositionedErDiagram): PositionedErDiagram {
  const ownership = ErSource.ownership(source)
  return ownership ? ownership.root(fields) : fields
}
export function captureErFinalLabel(source: PositionedErDiagram): ((rel: PositionedErRelationship, x: number, y: number) => Point) | undefined {
  return ordinaryOperations() ? ErSource.ownership(source)?.center : undefined
}
export function releaseErGeometrySource(source: PositionedErDiagram): void {
  ErSource.ownership(source)?.complete()
}
export function erFinalGeometryOf(source: PositionedErDiagram): ErFinalGeometry | undefined {
  return ErSource.get(source)
}
export function prepareErFinalGeometry(source: PositionedErDiagram, style: ResolvedRenderStyle, pay: Pay): ErFinalGeometry | undefined {
  return ErSource.ownership(source)?.prepare(source, style, pay)
}

/** Numeric operands are private; public positioned records remain mutable. */
export type ErFinalGeometry = PreparedErGeometry
class PreparedErGeometry {
  readonly #bodies: readonly EntityRow[]
  readonly #relations: readonly RelationshipRow[]
  readonly #source: PositionedErDiagram
  readonly #entities: PositionedErEntity[]
  readonly #relationships: PositionedErRelationship[]
  readonly #style: readonly unknown[]
  #pay: Pay | undefined
  readonly #ownership: ErGeometryOwnership
  #valid = true
  constructor(capability: object, source: PositionedErDiagram, style: ResolvedRenderStyle, bodies: readonly EntityRow[], relations: readonly RelationshipRow[], pay: Pay, ownership: ErGeometryOwnership) {
    if (capability !== operandConstruction) throw new TypeError('ER geometry operands are producer-owned')
    this.#ownership = ownership
    this.#source = source
    this.#entities = source.entities
    this.#relationships = source.relationships
    const captured: unknown[] = []
    for (let i = 0; i < styleFields.length; i++) slot(captured, data(style, styleFields[i]!))
    this.#style = freeze(captured)
    this.#bodies = bodies
    this.#relations = relations
    this.#pay = pay
  }
  #styleMatches(style: ResolvedRenderStyle): boolean {
    for (let i = 0; i < styleFields.length; i++) if (data(style, styleFields[i]!) !== this.#style[i]) return false
    return true
  }
  #entityLive(row: EntityRow): boolean {
    const source = row.source,
      view = row.view.row
    if (!absent(source, 'inlineStyle') || prototype(source) !== objectPrototype) return false
    for (let i = 0; i < entityFields.length; i++) {
      const field = entityFields[i]!,
        d = descriptor(source, field)
      if (d ? !own(d, 'value') || d.value !== data(view, field) : descriptor(objectPrototype, field) !== undefined) return false
    }
    return true
  }
  #relationLive(row: RelationshipRow): boolean {
    const source = row.source
    if (prototype(source) !== objectPrototype || data(source, 'points') !== row.sourcePoints || row.sourcePoints.length !== row.original.length) return false
    for (let i = 0; i < relationFields.length; i++) if (data(source, relationFields[i]!) !== row.fields[i]) return false
    for (let i = 0; i < row.original.length; i++) {
      const p = data(row.sourcePoints, String(i))
      if (p !== row.original[i]) return false
      const at = p as Point,
        point = row.view.geometry.points[i]!
      if (data(at, 'x') !== point.x || data(at, 'y') !== point.y) return false
    }
    return true
  }
  #matchCost(): number {
    let count = 0
    for (let i = 0; i < this.#relations.length; i++) count += relationFields.length + this.#relations[i]!.original.length * 3 + 2
    return count
  }
  matches(source: PositionedErDiagram, style: ResolvedRenderStyle): boolean {
    this.#pay?.(styleFields.length + this.#bodies.length * (entityFields.length + 1) + this.#matchCost())
    if (source !== this.#source || !this.#styleMatches(style) || data(source, 'entities') !== this.#entities || data(source, 'relationships') !== this.#relationships) return false
    for (let i = 0; i < this.#bodies.length; i++) if (source.entities[i] !== this.#bodies[i]!.source || !this.#entityLive(this.#bodies[i]!)) return false
    for (let i = 0; i < this.#relations.length; i++) if (source.relationships[i] !== this.#relations[i]!.source || !this.#relationLive(this.#relations[i]!)) return false
    return true
  }
  bodyFacts(): readonly { entity: PositionedErEntity; half: number; box: Box }[] {
    const rows: Array<{ entity: PositionedErEntity; half: number; box: Box }> = []
    for (let i = 0; i < this.#bodies.length; i++) {
      const r = this.#bodies[i]!
      slot(rows, freeze({ entity: r.view.row, half: r.view.strokeWidth / 2, box: r.box }))
    }
    this.#pay?.(rows.length)
    return freeze(rows)
  }
  points(index: number): readonly Point[] {
    return this.#relations[index]!.view.geometry.points
  }
  publish(): void {
    for (let i = 0; i < this.#relations.length; i++) freeze(this.#relations[i]!.glyphs)
    this.#pay = undefined
    this.#ownership.complete()
    ErSource.put(this.#source, this)
  }
  entity(source: PositionedErEntity, style: ResolvedRenderStyle): ErPreparedEntity | undefined {
    if (!this.#valid) return
    const i = ErRow.index(source, this.#ownership, false)
    if (i === undefined) return
    {
      const row = this.#bodies[i]!
      if (this.#styleMatches(style) && this.#entityLive(row)) return row.view
      this.#valid = false
      return
    }
  }
  relationship(source: PositionedErRelationship, style: ResolvedRenderStyle, lineWidth = style.lineWidth, bendRadius = style.edgeBendRadius): ErPreparedRelationship | undefined {
    if (!this.#valid) return
    const i = ErRow.index(source, this.#ownership, true)
    if (i === undefined) return
    {
      const row = this.#relations[i]!
      if (this.#styleMatches(style) && lineWidth === this.#style[0] && bendRadius === 0 && this.#relationLive(row)) return row.view
      this.#valid = false
      return
    }
  }
  glyph(index: number, end: number): { pieces: readonly ErCardinalityPiece[]; bounds: readonly Box[]; box: Box } | undefined {
    const row = this.#relations[index]!
    let glyph = row.glyphs[end]
    if (glyph) return glyph
    if (!this.#pay) return
    const points = row.view.geometry.points,
      point = end ? points[points.length - 1]! : points[0]!,
      toward = end ? points[points.length - 2]! : points[1]!
    const paint = freeze({ stroke: '#000', strokeWidth: String((this.#style[0] as number) + 0.25) })
    const pieces = erCardinalityPieces(point, toward, (end ? row.fields[3] : row.fields[2]) as PositionedErRelationship['cardinality1'], paint)
    for (let i = 0; i < pieces.length; i++) {
      freeze(pieces[i]!.geometry)
      freeze(pieces[i]!.paint)
      freeze(pieces[i]!)
    }
    freeze(pieces)
    const bounds = erCardinalityPieceInk(pieces)
    if (!bounds) return
    for (let i = 0; i < bounds.length; i++) freeze(bounds[i]!)
    freeze(bounds)
    this.#pay(2 * pieces.length + 1)
    let x0 = Infinity,
      y0 = Infinity,
      x1 = -Infinity,
      y1 = -Infinity
    for (let i = 0; i < bounds.length; i++) {
      const b = bounds[i]!
      x0 = Math.min(x0, b.x0)
      y0 = Math.min(y0, b.y0)
      x1 = Math.max(x1, b.x1)
      y1 = Math.max(y1, b.y1)
    }
    const box = freeze({ x0, y0, x1, y1 })
    glyph = freeze({ pieces, bounds, box })
    define(row.glyphs, end, { __proto__: null, value: glyph, writable: false, enumerable: true, configurable: false } as PropertyDescriptor)
    return glyph
  }
  cardinality(source: PositionedErRelationship, end: 'start' | 'end', lineWidth: number, paint: MarkPaint): readonly ErCardinalityPiece[] | undefined {
    if (!this.#valid || lineWidth !== this.#style[0]) return
    const i = ErRow.index(source, this.#ownership, true)
    if (i === undefined) return
    {
      const row = this.#relations[i]!
      if (!this.#relationLive(row)) {
        this.#valid = false
        return
      }
      const glyph = this.glyph(i, end === 'end' ? 1 : 0)
      if (!glyph) return
      const result: ErCardinalityPiece[] = []
      for (let j = 0; j < glyph.pieces.length; j++) {
        const piece = glyph.pieces[j]!
        slot(result, { geometry: piece.geometry, paint: data(piece.paint, 'fill') === undefined ? paint : { fill: 'var(--bg)', ...paint } })
      }
      return result
    }
  }
  label(source: PositionedErRelationship, metrics: { width: number; height: number }, mid: Point): { readonly geometry: Extract<Geometry, { kind: 'rect' }>; readonly at: Readonly<Point> } | undefined {
    if (!this.#valid) return
    const i = ErRow.index(source, this.#ownership, true)
    if (i === undefined) return
    {
      const row = this.#relations[i]!
      if (metrics === row.block && mid === row.sourceCenter && this.#relationLive(row) && metrics.width === row.width && metrics.height === row.height && data(mid, 'x') === row.center?.x && data(mid, 'y') === row.center?.y) return row.pill && row.center ? { geometry: row.pill, at: row.center } : undefined
      this.#valid = false
      return
    }
  }
}

freeze(PreparedErGeometry.prototype)

function prepareRows(
  source: PositionedErDiagram,
  style: ResolvedRenderStyle,
  pay: Pay,
  ownership: ErGeometryOwnership,
  entities: PositionedErEntity[],
  relationships: Array<{ source: PositionedErRelationship; points: Point[]; owned: Point[] | undefined }>,
  centers: Array<Point | undefined>,
  publicEntities: PositionedErEntity[] | undefined,
  publicRelationships: PositionedErRelationship[] | undefined,
  publicGroups: PositionedErDiagram['groups'] | undefined,
): ErFinalGeometry | undefined {
  if (!ordinaryOperations() || !ownership || data(source, 'entities') !== publicEntities || data(source, 'relationships') !== publicRelationships || data(source, 'groups') !== publicGroups || publicGroups!.length || style.edgeBendRadius !== 0 || descriptor(objectPrototype, 'inlineStyle')) return
  const bodies: EntityRow[] = [],
    relations: RelationshipRow[] = []
  if (source.entities.length !== entities.length || source.relationships.length !== relationships.length) return
  for (let i = 0; i < entities.length; i++) {
    const entity = entities[i]!
    if (source.entities[i] !== entity || prototype(entity) !== objectPrototype || !absent(entity, 'inlineStyle') || !shell(entity, pay)) return
    for (const field of entityFields) if (!descriptor(entity, field) && descriptor(objectPrototype, field)) return
    const x = data(entity, 'x'),
      y = data(entity, 'y'),
      width = data(entity, 'width'),
      height = data(entity, 'height'),
      headerHeight = data(entity, 'headerHeight'),
      rowHeight = data(entity, 'rowHeight')
    if (![x, y, width, height, headerHeight, rowHeight].every(v => typeof v === 'number' && Number.isFinite(v))) return
    const geometry = freeze({ kind: 'rect' as const, x: x as number, y: y as number, width: width as number, height: height as number, rx: style.cornerRadius ?? 0, ry: style.cornerRadius ?? 0 })
    const row = create(null) as PositionedErEntity
    for (const key of keys(entity)) {
      const d = descriptor(entity, key)!
      define(row, key, { __proto__: null, value: d.value, enumerable: d.enumerable, writable: false, configurable: false } as PropertyDescriptor)
    }
    freeze(row)
    const half = style.nodeLineWidth / 2
    slot(
      bodies,
      freeze({ source: entity, view: freeze({ row, geometry, strokeWidth: style.nodeLineWidth, headerHeight: headerHeight as number, rowHeight: rowHeight as number }), box: freeze({ x0: geometry.x - half, y0: geometry.y - half, x1: geometry.x + geometry.width + half, y1: geometry.y + geometry.height + half }) }),
    )
    pay(3)
  }
  for (let i = 0; i < relationships.length; i++) {
    const owned = relationships[i]!,
      rel = owned.source,
      points = owned.points
    if (source.relationships[i] !== rel || data(rel, 'points') !== points || prototype(rel) !== objectPrototype || !shell(rel, pay) || !owned.owned || points.length !== owned.owned.length) return
    for (let j = 0; j < relationFields.length; j++) if (!descriptor(rel, relationFields[j]!) && descriptor(objectPrototype, relationFields[j]!)) return
    const copied: Point[] = []
    for (let j = 0; j < points.length; j++) {
      if (data(points, String(j)) !== owned.owned[j]) return
      const point = owned.owned[j]!
      if (!shell(point, pay)) return
      const x = data(point, 'x'),
        y = data(point, 'y')
      if (typeof x !== 'number' || typeof y !== 'number' || !Number.isFinite(x) || !Number.isFinite(y)) return
      slot(copied, freeze({ x, y }))
    }
    freeze(copied)
    let center: Point | undefined
    const sourceCenter = centers[i]
    if (sourceCenter && data(rel, 'finalLabelPosition') === sourceCenter) {
      if (!shell(sourceCenter, pay)) return
      const x = data(sourceCenter, 'x'),
        y = data(sourceCenter, 'y')
      if (typeof x !== 'number' || typeof y !== 'number' || !Number.isFinite(x) || !Number.isFinite(y)) return
      center = freeze({ x, y })
    }
    const block = rel.labelBlock
    if (block && !isOwnedPixelTextPart(block)) return
    if (rel.cardinality1 === 'parent' || rel.cardinality2 === 'parent' || (rel.label && (!center || !block))) return
    const width = block?.width ?? 0,
      height = block?.height ?? 0,
      pill = center ? freeze(erLabelPillGeometry({ width, height }, center)) : undefined
    const fields: unknown[] = []
    for (let j = 0; j < relationFields.length; j++) slot(fields, data(rel, relationFields[j]!))
    slot(relations, freeze({ source: rel, sourcePoints: points, original: freeze(owned.owned!), view: freeze({ geometry: freeze({ kind: 'polyline' as const, points: copied }) }), fields: freeze(fields), glyphs: [], center, sourceCenter, block, width, height, pill }))
    pay(points.length + 3)
  }
  return new PreparedErGeometry(operandConstruction, source, style, freeze(bodies), freeze(relations), pay, ownership)
}
