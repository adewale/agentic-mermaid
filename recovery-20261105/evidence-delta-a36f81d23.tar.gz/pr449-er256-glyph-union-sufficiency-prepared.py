# Reuse the existing single-public-call consumer; no baseline replay or build.
import ast,gzip,json,os,pathlib,subprocess,sys
R=pathlib.Path('/tmp/pr449-main-integration-20261029-762')
O=pathlib.Path('/tmp/pr449-week-comparison-20261101/er256-glyph-union-sufficiency-5aa10b3c0')
H='5aa10b3c09add9713a17a7db75919b0c90fca160'
if sys.argv[1:]==['--prepare']:
 print('STATIC_READY HOLD:ONEordinaryAM256publicSVGcall max; UNSAFENONSHIPPINGstablebodyindex+glyphunionqueries; unchanged400k/fees/perpiecepredicates/laterlabels. Zero calls/builds.');sys.exit()
assert sys.argv[1:]==['--run',H]and os.environ.get('PR449_ROOT_GO')=='er256-glyph-union-sufficiency','Exact head and separate root CPU GO required'
assert not (O/'OUTCOME.json.gz').exists()and not (O/'RESULT.json.gz').exists(),'Existing attempt retained: do not replay'
E=dict(os.environ,PATH='/tmp/pr449-bin:'+os.environ['PATH'],GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0')
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,env=E,text=True).strip()==H,'Frozen HEAD changed'
 dirty=subprocess.check_output(['git','diff','--name-only','HEAD','--','src','tsup.browser-lazy.config.ts','scripts/build'],cwd=R,env=E,text=True).splitlines()
 assert not [p for p in dirty if not p.startswith('src/__tests__/')and '/__tests__/'not in p],'Dirty production/build source'
 assert (R/'src/er/layout.ts').read_bytes()==(O/'layout.original.ts').read_bytes(),'Original ER source changed'
frozen();j={'head':H,'actualPublicCalls':0,'maxPublicCalls':1,'buildCalls':0,'nodeCalls':0,'elkCalls':0,'productionEdits':0,'nonshipping':True,'unsafeGenericDomain':True}
try:
 p=subprocess.run(['/tmp/pr449-bin/bun',str(O/'worker.ts')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 (O/'stdout-stderr.log.gz').write_bytes(gzip.compress(p.stdout+p.stderr,mtime=0));j['actualPublicCalls']=p.stdout.count(b'ACTUAL_PUBLIC_CALL_START');j['exitCode']=p.returncode
 j['familyEndWork']=[json.loads(line.split(b' ',1)[1])for line in p.stdout.splitlines()if line.startswith(b'NONSHIPPING_ER_FAMILY_WORK ')]
 if (O/'RESULT.json.gz').is_file():
  result=json.loads(gzip.decompress((O/'RESULT.json.gz').read_bytes()));j['resultReference']=str(O/'RESULT.json.gz');j['status']=result['outcome']['status'];j['phase']=result['outcome']['phase'];assert result['actualPublicCalls']==j['actualPublicCalls']==1 and result['overlayLoads']==1
 frozen();j['completed']=p.returncode==0 and j['actualPublicCalls']==1 and 'resultReference'in j
except subprocess.TimeoutExpired as error:
 output=(error.stdout or b'')+(error.stderr or b'');(O/'stdout-stderr.log.gz').write_bytes(gzip.compress(output,mtime=0));j['actualPublicCalls']=(error.stdout or b'').count(b'ACTUAL_PUBLIC_CALL_START');j['completed']=False;j['error']=repr(error)
except Exception as error:j['completed']=False;j['error']=repr(error)
finally:
 (O/'OUTCOME.json.gz').write_bytes(gzip.compress(json.dumps(j,separators=(',',':')).encode(),mtime=0));print(json.dumps(j))
