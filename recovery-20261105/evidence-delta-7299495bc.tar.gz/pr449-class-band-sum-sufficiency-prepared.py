# Existing one-call consumer, real production only; retained optimistic comparison.
import ast,gzip,json,os,pathlib,subprocess,sys
R=pathlib.Path('/tmp/pr449-main-integration-20261029-762')
O=pathlib.Path('/tmp/pr449-week-comparison-20261101/class-band-sum-sufficiency-dc7a17838')
B='dc7a1783860d80230f668fdf82061b7181faf2ba'
OPT=pathlib.Path('/tmp/pr449-week-comparison-20261101/class-ledger-f1e/TB')
if sys.argv[1:]==['--prepare']:
 print('STATIC_READY HOLD:ONECURRENTClass128TBordinarypubliccall,NOoverlay; fullproduct/errors/stages/RSSheap; datedcompletebaselinecomparison,noPgate. Zero calls/builds.');sys.exit()
assert len(sys.argv)==3 and sys.argv[1]=='--run'and len(sys.argv[2])==40 and os.environ.get('PR449_ROOT_GO')=='class-band-sum-sufficiency','Frozen HEAD and separate root CPU GO required'
H=sys.argv[2];assert not (O/'OUTCOME.json.gz').exists()and not (O/'RESULT.json.gz').exists(),'Existing attempt retained: do not replay'
E=dict(os.environ,PATH='/tmp/pr449-bin:'+os.environ['PATH'],GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env=E,text=True).strip()
def raw_proof(receipt):
 key='"layoutCertification":';start=receipt.index(key)+len(key);_,end=json.JSONDecoder().raw_decode(receipt,start);return receipt[start:end]
def production(paths):return {p for p in paths.splitlines()if p and not p.startswith('src/__tests__/')and '/__tests__/'not in p}
def changed():return sorted(production(git('diff','--name-only',B,'--','src','tsup.browser-lazy.config.ts','scripts/build'))|production(git('ls-files','--others','--exclude-standard','--','src','tsup.browser-lazy.config.ts','scripts/build')))
assert git('rev-parse','HEAD')==H
paths=changed();assert paths==['src/layout/measured-forest.ts'],'Exact measured-forest-only candidate required';captured={p:(R/p).read_bytes()for p in sorted(set(paths)|{'src/layout/measured-forest.ts'})}
def frozen():
 assert git('rev-parse','HEAD')==H and changed()==paths,'Frozen HEAD/source roster changed'
 assert all((R/p).read_bytes()==data for p,data in captured.items()),'Frozen production bytes changed'
frozen()
for path,data in captured.items():(O/('production-'+path.replace('/','__')+'.gz')).write_bytes(gzip.compress(data,mtime=0))
(O/'candidate.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','--binary',B,'--','src','tsup.browser-lazy.config.ts','scripts/build'],cwd=R,env=E),mtime=0))
j={'step':'CLASS_TB_COMPENSATED_BAND_SUM_SUFFICIENCY','head':H,'baselineHead':B,'actualPublicCalls':0,'maxPublicCalls':1,'buildCalls':0,'nodeCalls':0,'elkCalls':0,'profileCalls':0,'overlayLoads':0,'productionPathsFrozenByLiteralBytes':list(captured),'datedBaselineReference':str(OPT/'RESULT.json.gz')}
try:
 p=subprocess.run(['/tmp/pr449-bin/bun',str(O/'worker.ts')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 (O/'stdout-stderr.log.gz').write_bytes(gzip.compress(p.stdout+p.stderr,mtime=0));j['actualPublicCalls']=p.stdout.count(b'ACTUAL_PUBLIC_CALL_START');j['exitCode']=p.returncode
 if (O/'RESULT.json.gz').is_file():
  result=json.loads(gzip.decompress((O/'RESULT.json.gz').read_bytes()));j['resultReference']=str(O/'RESULT.json.gz');j['status']=result['row']['status'];assert result['actualPublicCalls']==j['actualPublicCalls']==1 and result['overlayLoads']==0
  if result['row']['status']=='returned':j['datedNominalComparison']={k:result['row'][k]for k in ['baselineReference','baselineBinding','wholeSVGExactToDated','entireRawReceiptExactToDated','proof','namedFailure']}
 frozen();j['sourceUnchanged']=True;j['completed']=p.returncode==0 and j['actualPublicCalls']==1 and 'resultReference'in j
except subprocess.TimeoutExpired as error:
 output=(error.stdout or b'')+(error.stderr or b'');(O/'stdout-stderr.log.gz').write_bytes(gzip.compress(output,mtime=0));j['actualPublicCalls']=(error.stdout or b'').count(b'ACTUAL_PUBLIC_CALL_START');j['completed']=False;j['error']=repr(error)
except Exception as error:j['completed']=False;j['error']=repr(error)
finally:
 (O/'OUTCOME.json.gz').write_bytes(gzip.compress(json.dumps(j,separators=(',',':')).encode(),mtime=0));print(json.dumps(j))
