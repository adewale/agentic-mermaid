import { readFileSync, writeFileSync, writeSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/class-band-sum-sufficiency-dc7a17838'
const wallStart=performance.now(),cpuStart=process.cpuUsage()
const log=(value:unknown)=>writeSync(1,JSON.stringify(value)+'\n')
log({event:'IMPORT_START',memory:process.memoryUsage(),cpu:process.cpuUsage()})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const {withRenderStageObserver}=await import(root+'/src/render-stages.ts')
const {withPerformanceObserver}=await import(root+'/src/performance-observations.ts')
const {apiFailure}=await import(root+'/eval/layout-compare/outcomes.ts')
const importMs=performance.now()-wallStart,importCPU=process.cpuUsage(cpuStart)
const source='classDiagram\ndirection TB\n'+Array.from({length:127},(_,i)=>`N${i} --> N${i+1}`).join('\n')
const options={graphLayout:{backend:'agentic' as const,fallback:'none' as const},embedFontImport:false}
const stages:any[]=[],events:any[]=[]
Bun.gc(true)
const before=process.memoryUsage(),renderCPU=process.cpuUsage(),renderStart=performance.now()
let product:any,row:any
log({event:'ACTUAL_PUBLIC_CALL_START',actualCalls:1,importMs,importCPU,before})
try{
 const artifact=withPerformanceObserver(event=>events.push(event),()=>withRenderStageObserver(stage=>{stages.push(stage);log({event:'STAGE_COMPLETE',...stage})},()=>renderMermaidSVGWithReceipt(source,options)))
 product=artifact
 const bytes=Buffer.from(JSON.stringify(product));let checksum=0
 for(const byte of bytes)checksum=(Math.imul(checksum,31)+byte)>>>0
 const baselineReference='/tmp/pr449-week-comparison-20261101/class-ledger-f1e/TB/RESULT.json.gz'
 const historical=JSON.parse(gunzipSync(readFileSync(baselineReference)).toString());if(source!==historical.source||JSON.stringify(options)!==JSON.stringify(historical.options))throw Error('Exact retained ordinary source/options required; no normalization')
 const receiptJSON=JSON.stringify(product.receipt), elapsedMs=performance.now()-renderStart
 writeFileSync(out+'/TB.svg.gz',gzipSync(product.svg));writeFileSync(out+'/TB.receipt.json.gz',gzipSync(JSON.stringify(product.receipt)))
 row={status:'returned',elapsedMs,fullyConsumedBytes:bytes.length,checksum,baselineReference,baselineBinding:'DATEDf1ecompleteproduct; no newdc7abaselinecall',wholeSVGExactToDated:product.svg===historical.product.svg,entireRawReceiptExactToDated:receiptJSON===gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/class-ledger-f1e/TB/TB.receipt.json.gz')).toString(),proof:product.receipt.layoutCertification,namedFailure:'ordinaryClass128TB400k/53markers; status/markersprimary, byteequalitynotgate'}
}catch(error:any){
 product={normalized:apiFailure(error),name:error?.name,message:error?.message,code:error?.code,stack:error?.stack,cause:error?.cause?{name:error.cause.name,message:error.cause.message,stack:error.cause.stack}:undefined,certification:error?.certification}
 const bytes=Buffer.from(JSON.stringify(product));row={status:'refused',fullyConsumedErrorBytes:bytes.length,failure:product}
}
const afterMemory=process.memoryUsage();Bun.gc(true)
const report={step:'currentClassTB-compensated-band-sum-sufficiency',overlayLoads:0,actualPublicCalls:1,afterGC:process.memoryUsage(),source,options,importMs,importCPU,renderWallMs:performance.now()-renderStart,renderCPU:process.cpuUsage(renderCPU),totalWallMs:performance.now()-wallStart,totalCPU:process.cpuUsage(cpuStart),loadedMemory:before,afterMemory,peakRssKiB:process.resourceUsage().maxRSS,row,provider:events.filter(e=>e.owner==='paint-certification'),stages,events,product}
writeFileSync(out+'/RESULT.json.gz',gzipSync(JSON.stringify(report)))
log({event:'ACTUAL_PUBLIC_CALL_COMPLETE',...report,product:undefined,events:undefined})
