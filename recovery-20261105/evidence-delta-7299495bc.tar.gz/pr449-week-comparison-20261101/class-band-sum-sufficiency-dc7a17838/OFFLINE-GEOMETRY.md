# Stopped Class TB compensated-sum trial: offline geometry

One saved current product compared with the dated f1e complete literal product;
no new baseline/API/layout/raster/profiler/build calls. This is failed-trial evidence,
not progress or current-head before/after qualification.

Both retain128 authored names/class boxes,127 exact authored association carriers,
127 matching marker overlays and254 normal docks under the existing owner1e-8
tolerance. Both SVGs already draw those127 carriers/overlays; the receipt's marker
count change53→127 does not mean new marker artwork or complete certification.

Whole SVG differs: dated189921bytes, candidate188650bytes. 104 geometry
attributes differ, including 12 semantic carrier point attributes. Maximum numeric
coordinate/extent delta is 3.092281986027956e-11px,
maximum17 binary64 ULPs. Maximum semantic shaft-coordinate delta is
2.9103830456733704e-11px. Width remains200; height/viewBox height changes
13959.19999999997→13959.2. No raster/visible-ink or broader geometry claim.

Candidate remains U400000 with CHECK_BUDGET and OUTPUT_SCOPE, conditional0,
127 reported markers/1520 pairs. All marker checks are reported but complete bound
proof still U. The public counters do not identify the first exhaustion stage or
quantify the remaining tail; these stay unknown. No retries or additional probes.

OFFLINE-GEOMETRY.json retains every literal changed attribute and numeric delta.
Original/current product, receipt, source and stopped-trial patch remain preserved.
