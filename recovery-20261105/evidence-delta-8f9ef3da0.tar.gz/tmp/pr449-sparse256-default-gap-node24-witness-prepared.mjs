import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { registerHooks, stripTypeScriptTypes } from 'node:module';
import { gzipSync, gunzipSync } from 'node:zlib';
const root='/tmp/pr449-main-integration-20261029-762';
const frozen=process.env.PR449_FINAL_SHA;
if(process.argv[2]==='--prepare'){console.log('STATIC_ONLY_READY HOLD: one fresh Node24 source witness per engine; zero render/build calls');process.exit(0);}
if(process.argv[2]!=='--run'||process.env.PR449_ROOT_GO!=='sparse256-default-gap-node-source'||!frozen?.match(/^[a-f0-9]{40}$/))throw new Error('Separate root GO and exact frozen SHA required');
if(process.env.PR449_CONTROLLER_VERIFIED_HEAD!==frozen)throw new Error('Python controller frozen-head/source-clean preflight required');
if(!process.version.startsWith('v24.'))throw new Error('Resolved Node24 runtime required');
const selectedCase=process.argv[3],selectedBackend=process.argv[4];if(!['sparse256-default-gap'].includes(selectedCase))throw new Error('One exact named case per fresh source process required');if(!['agentic','elk'].includes(selectedBackend))throw new Error('One exact engine per fresh source process required');
const out='/tmp/pr449-week-comparison-20261101/sparse256-default-gap-node24-'+frozen.slice(0,9)+'/'+selectedCase+'-'+selectedBackend;
fs.mkdirSync(out,{recursive:true});
const row={runtime:process.version,actualPublicCalls:0,setupErrors:[],root,loader:'Node built-in registerHooks; stripTypeScriptTypes mode=transform; existing extensionless relative .ts resolution',status:'setup'};
const gz=(name,value)=>fs.writeFileSync(out+'/'+name,gzipSync(typeof value==='string'?value:JSON.stringify(value)));
try {
 registerHooks({
  resolve(specifier,context,nextResolve){
   if(specifier.startsWith('.')&&context.parentURL?.startsWith(pathToFileURL(root+'/').href)){
    const candidate=new URL(specifier,context.parentURL);
    if(!path.extname(candidate.pathname)&&fs.existsSync(fileURLToPath(candidate)+'.ts'))return nextResolve(candidate.href+'.ts',context);
    if(!path.extname(candidate.pathname)&&fs.existsSync(fileURLToPath(candidate)+'.js'))return nextResolve(candidate.href+'.js',context);
   }
   if(specifier.startsWith('roughjs/bin/')&&!path.extname(specifier))return nextResolve(specifier+'.js',context);
   return nextResolve(specifier,context);
  },
  load(url,context,nextLoad){
   if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.json'))return {format:'json',shortCircuit:true,source:fs.readFileSync(fileURLToPath(url),'utf8')};
   if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.ts'))return {format:'module',shortCircuit:true,source:stripTypeScriptTypes(fs.readFileSync(fileURLToPath(url),'utf8'),{mode:'transform',sourceUrl:url})};
   return nextLoad(url,context);
  }
 });
 const bindings=JSON.parse(fs.readFileSync(process.env.PR449_BINDINGS_JSON,'utf8'));
 if(bindings.length!==2||new Set(bindings.map(x=>x.caseId+'-'+x.family+'-'+x.backend)).size!==2)throw new Error('Exactly two ER sparse256-default-gap engine bindings required');
 const reference={'sparse256-default-gap':fs.readFileSync('/tmp/pr449-week-comparison-20261101/sparse256-default-gap-cost-99723bb5d/source.mmd','utf8')};
 const api=await import(pathToFileURL(root+'/src/index.ts').href);
 row.bindings=[];row.renders=[];
 for(const binding of bindings.filter(x=>x.caseId===selectedCase&&x.backend===selectedBackend)){
  if(binding.family!=='er'||!['agentic','elk'].includes(binding.backend)||binding.source!==reference[binding.caseId])throw new Error('Exact authored case source required');
  const options={graphLayout:{backend:binding.backend,fallback:'none'},embedFontImport:false};
  if(JSON.stringify(binding.options)!==JSON.stringify(options))throw new Error('Exact retained options required');
  row.status='calling';process.stdout.write('ACTUAL_PUBLIC_CALL_START\n');row.actualPublicCalls++;
  const resultRow={caseId:binding.caseId,family:binding.family,backend:binding.backend};
  try {
   const result=api.renderMermaidSVGWithReceipt(binding.source,binding.options);
   const bytes=Buffer.from(JSON.stringify(result),'utf8');
   const tag=binding.caseId+'-'+binding.family+'-'+binding.backend,svgName=tag+'.svg.gz',receiptName=tag+'.receipt.json.gz';
   gz(svgName,result.svg);gz(receiptName,JSON.stringify(result.receipt));
   Object.assign(resultRow,{status:'returned',bytes:bytes.length,proof:result.receipt.layoutCertification,wholeSvgExactBunAfter:Buffer.from(result.svg,'utf8').equals(gunzipSync(fs.readFileSync(binding.bunSvgReference))),entireRawReceiptExactBunAfter:Buffer.from(JSON.stringify(result.receipt),'utf8').equals(gunzipSync(fs.readFileSync(binding.bunReceiptReference)))});
   if(binding.previousNativeSvgReference){resultRow.previousFinalNativeWholeSVGExact=Buffer.from(result.svg,'utf8').equals(gunzipSync(fs.readFileSync(binding.previousNativeSvgReference)));resultRow.previousFinalNativeEntireRawReceiptExact=Buffer.from(JSON.stringify(result.receipt),'utf8').equals(gunzipSync(fs.readFileSync(binding.previousNativeReceiptReference)));}
   row.bindings.push({...binding,svgReference:out+'/'+svgName,receiptReference:out+'/'+receiptName,sourceRuntime:process.version,sourceHead:frozen});
  }catch(error){resultRow.status='refused';resultRow.failure={name:error.name,message:error.message,stack:error.stack,cause:{name:error.cause?.name,message:error.cause?.message,stack:error.cause?.stack}};const bytes=Buffer.from(JSON.stringify(resultRow.failure));resultRow.consumedFailure={bytes:bytes.length};}
  row.renders.push(resultRow);
 }
 // Python controller rechecks frozen HEAD and source cleanliness after this child.
 row.status=row.renders.every(x=>x.status==='returned')?'returned':'contains-refusal';
 row.completed=row.actualPublicCalls===1&&row.bindings.length===1&&row.renders.every(value=>value.wholeSvgExactBunAfter===true&&value.entireRawReceiptExactBunAfter===true);
 fs.writeFileSync(out+'/bindings-sparse256-default-gap-node24.json',JSON.stringify(row.bindings));
}catch(error){row.status='setup-error';row.setupErrors.push({name:error.name,message:error.message,stack:error.stack});}
finally{gz('OUTCOME.json.gz',row);process.stdout.write(JSON.stringify({status:row.status,actualPublicCalls:row.actualPublicCalls,setupErrors:row.setupErrors,completed:row.completed,proofs:row.renders?.map(x=>({backend:x.backend,proof:x.proof?.status,operations:x.proof?.checks?.operations}))})+'\n');}
