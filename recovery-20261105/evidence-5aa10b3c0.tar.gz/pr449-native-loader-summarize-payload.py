import pathlib,json,gzip,subprocess
W=pathlib.Path('/tmp/pr449-week-comparison-20261101');B=W/'recovery-payload/native-group-cyclic19-25b6c43b0';C=W/'recovery-payload/native-loader-c323e9fd5';N=W/'native-loader-node24-c323e9fd5';R=pathlib.Path('/tmp/pr449-main-integration-20261029-762')
def read(p):return json.loads(gzip.decompress(p.read_bytes()))
def gz(p,x):p.write_bytes(gzip.compress(json.dumps(x,separators=(',',':')).encode(),mtime=0))
b=read(B/'report.json.gz');c=read(C/'report.json.gz');out=read(C/'OUTCOME.json.gz');nodes=read(N/'OUTCOME.json.gz')
rows={}
def add(name,old,new):
 keys=['requests','raw','gzip','brotli'];rows[name]={'before':{k:old[k]for k in keys},'current':{k:new[k]for k in keys},'delta':{k:new[k]-old[k]for k in keys}}
add('initial',b['initial'],c['initial'])
for f in ['class','flowchart']:
 for label,field in [('agentic','nativeSolver'),('static','static'),('elk',None)]:add(f+'-'+label,b['families'][f][field]if field else b['families'][f],c['families'][f][field]if field else c['families'][f])
for key in ['indexedForest','indexedForestThenElk']:add('omittedLayoutFlowchart-'+key,b['omittedLayoutFlowchart'][key],c['omittedLayoutFlowchart'][key])
# Identify real output nodes and preserve every import edge from relevant Native/legacy/Measured chunks.
graphs={}
for label,O in [('before',B),('current',C)]:
 m=read(O/'metafile-normalized.json.gz');selected={}
 for path,v in m['outputs'].items():
  matches=[k for k in v.get('inputs',{})if any(x in k for x in ['agentic-layered.lazy.ts','forest-loader.lazy.ts','agentic-producer-core.ts','forest-implementation.ts','measured-forest.ts','indexed-forest-core.ts'])]
  if matches:selected[path]={'entryPoint':v.get('entryPoint'),'relevantInputs':matches,'imports':v.get('imports',[])}
 graphs[label]={'metafileReference':str(O/'metafile-normalized.json.gz'),'relevantOutputs':selected}
comparison={'baselineHead':'25b6c43b02926e286d016d21fc701ee1d3663479','preFixHead':'843030a3229fe8533cd4a5486c93e36093fe29f5','candidateHead':out['head'],'baselineReportReference':str(B/'report.json.gz'),'candidateReportReference':str(C/'report.json.gz'),'newBeforeBuilds':0,'candidateBuilds':out['buildCalls'],'closures':rows,'actualModuleGraphs':graphs,'coldDependencyChange':{'before':'Native loader concurrently requests producer C and legacy forest F via Promise.all; measured forest M is emitted inside F','current':'Native loader requests producer C; C statically imports new shared measured-forest M chunk. Legacy forest F statically imports M as well','consequence':'Native request counts unchanged; omitted-layout forest and its ELK fallback add one request. New C→M/F→M cold discovery dependency; actual network latency unmeasured'},'limits':['Transfer sizes and static/dynamic import graph only; no speed or network-latency claim','No timing sweep; packaging-only change','ELK19 Native proof remains unverified400000','All Native and explicit ELK request counts in selected Class/Flowchart closures unchanged']}
prod=subprocess.check_output(['git','diff','--name-only',comparison['baselineHead'],comparison['preFixHead'],'--','src','tsup.browser-lazy.config.ts','scripts/build'],cwd=R,text=True).splitlines();comparison['baselineProductionBuildDifferences']=[p for p in prod if not p.startswith('src/__tests__/')and '/__tests__/'not in p];assert not comparison['baselineProductionBuildDifferences']
gz(C/'BASELINE-COMPARISON.json.gz',comparison)
final={'candidateHead':out['head'],'sourceWitnessCalls':nodes['actualPublicCalls'],'buildCalls':out['buildCalls'],'compiledCalls':out['actualRenderCalls'],'sourceAllCompleted':nodes['completed'],'payloadCompleted':out['completed'],'payloadErrors':out['errors'],'ramRemoved':out['ramRemoved'],'sourceCleanAtBuildComplete':out['sourceCleanAtBuildComplete'],'nodeRuntime':'v24.19.0','bindings':{tag:{'outcome':v['outcome'],'wholeSVGExact':v['wholeSvgExactUnbundledWitness'],'entireRawReceiptExact':v['entireRawReceiptExactUnbundledWitness'],'runtime':v['runtime'],'proof':v['proof']['status'],'operations':v['proof']['checks']['operations'],'layoutDecisions':v.get('layoutDecisions'),'executionDecision':v.get('executionDecision')}for tag,v in out['renders'].items()},'sourceWitnessReference':str(N/'OUTCOME.json.gz'),'payloadReference':str(C/'OUTCOME.json.gz'),'comparisonReference':str(C/'BASELINE-COMPARISON.json.gz'),'graphContextsReference':str(C/'GRAPH-CONTEXTS.json.gz'),'limits':comparison['limits']}
final['observedHeadAfterAnalysis']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();final['observedDirtyProductionBuildPaths']=[p for p in subprocess.check_output(['git','diff','--name-only','HEAD','--','src','tsup.browser-lazy.config.ts','scripts/build'],cwd=R,text=True).splitlines()if not p.startswith('src/__tests__/')and '/__tests__/'not in p];gz(C/'FINAL-EVIDENCE.json.gz',final)
for name,x in rows.items():print(name,'before',x['before'],'current',x['current'],'delta',x['delta'])
print('bindings',json.dumps(final['bindings'],indent=2));print('FINAL',json.dumps({k:v for k,v in final.items()if k not in ['bindings','limits']},indent=2))
