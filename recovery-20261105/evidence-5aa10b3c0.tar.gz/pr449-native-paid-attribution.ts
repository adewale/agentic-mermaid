import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const repo = '/tmp/pr449-main-integration-20261029-762'
const out = '/tmp/pr449-week-comparison-20261101/native-paid-9f519'
mkdirSync(out, {recursive:true})
const instrumentation = `const __site = (new Error().stack ?? '').split('\\n')[2]?.trim() ?? 'unknown'; const __ledger = ((globalThis as any).__nativePaidLedger ??= {sites:{},firstRejected:undefined}); const __row = (__ledger.sites[__site] ??= {requests:0,requested:0,paid:0,rejected:0}); __row.requests++; __row.requested+=count; if (!exhausted && Number.isSafeInteger(count) && count >= 0 && count <= maxOperations - operations) __row.paid+=count; else { __row.rejected++; __ledger.firstRejected ??= {site:__site,count,operations,stack:new Error().stack}; }`
Bun.plugin({name:'temporary-original-pay-attribution',setup(build){build.onLoad({filter:/\/src\/scene\/native-paint-emission\.ts$/},args=>{const source=readFileSync(args.path,'utf8'); const target='const pay = (count = 1): boolean => {';if(source.split(target).length!==2)throw Error('one pay owner required');return{contents:source.replace(target,target+instrumentation),loader:'ts'}})}})
const { renderMermaidSVGWithReceipt }=await import(repo+'/src/index.ts')
for(const family of ['class','er']){
 ;(globalThis as any).__nativePaidLedger=undefined
 const source=family==='class'?'classDiagram\ndirection TB\n'+Array.from({length:127},(_,i)=>`N${i} --> N${i+1}`).join('\n'):'erDiagram\ndirection LR\n'+Array.from({length:191},(_,i)=>`N${i} ||--o{ N${i+1} : owns`).join('\n')
 const options={graphLayout:{backend:'agentic',fallback:'none'},embedFontImport:false}
 const result=renderMermaidSVGWithReceipt(source,options)
 const ledger=(globalThis as any).__nativePaidLedger
 writeFileSync(out+'/'+family+'.json.gz',gzipSync(JSON.stringify({source,options,result,ledger})))
 console.log(JSON.stringify({family,proof:result.receipt.layoutCertification,sites:Object.entries(ledger.sites).map(([site,row])=>({site,...row})).sort((a,b)=>b.paid-a.paid),firstRejected:ledger.firstRejected}))
}
