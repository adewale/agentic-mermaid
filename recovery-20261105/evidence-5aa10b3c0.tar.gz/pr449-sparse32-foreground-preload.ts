import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
const directory = '/tmp/pr449-week-comparison-20261101/sparse32-foreground-f1e'
mkdirSync(directory, { recursive: true })
const traceKey = 'pr449.sparse32.foreground.f1e'
Bun.plugin({ name: 'sparse32-foreground-baseline-counters', setup(build) {
  build.onLoad({ filter: /\/src\/scene\/paint-certification\.ts$/ }, args => {
    let source = readFileSync(args.path, 'utf8')
    writeFileSync(directory + '/paint.before.ts', source)
    const ledger = '  let pairs = 0, operations = (emissionWork?.operations ?? 0) + (sceneWriteWork?.operations ?? 0), exhausted = (emissionWork?.exhausted ?? false) || (sceneWriteWork?.exhausted ?? false)'
    if (source.split(ledger).length !== 2) throw new Error('foreground ledger boundary changed')
    source = source.replace(ledger, ledger + `
  const foregroundTrace = { native: !!emissionWork, sceneWrite: !!sceneWriteWork, initialOperations: operations, initialExhausted: exhausted, nativeInitial: emissionWork?.operations, nativeUncertain: emissionWork?.uncertain, fractionalCircleContext: emissionWork?.fractionalCircleContext, calls: 0, prefixAttempts: 0, prefixPaid: 0, textProgress: [] as unknown[], finalOperations: 0, finalPairs: 0, finalExhausted: false }
  const foregroundTraces = (globalThis as any)[Symbol.for('${traceKey}')] ??= []
  foregroundTraces.push(foregroundTrace)
`)
    const start = '  const checkActualTextForeground = (primitive: ScenePaintPrimitive): void => {'
    const end = '\n  const cylinderContext ='
    const begin = source.indexOf(start), finish = source.indexOf(end, begin)
    if (begin < 0 || finish < 0) throw new Error('foreground function boundary changed')
    let body = source.slice(begin + start.length, finish)
    if (!body.endsWith('\n  }')) throw new Error('foreground body closing boundary changed')
    body = body.slice(0, -4)
    const prefix = '    for (let i = 0; i < primitive.order; i++) {\n      if (!work()) return\n      const earlier = inspection.primitives[i]!'
    if (body.split(prefix).length !== 2) throw new Error('foreground prefix boundary changed')
    body = body.replace(prefix, '    for (let i = 0; i < primitive.order; i++) {\n      foregroundTrace.prefixAttempts++\n      if (!work()) return\n      foregroundTrace.prefixPaid++\n      const earlier = inspection.primitives[i]!')
    const instrumented = start + `
    foregroundTrace.calls++
    const foregroundStart = { id: primitive.id, kind: primitive.kind, order: primitive.order, initialOperations: operations, initialExhausted: exhausted, prefixAttempts: foregroundTrace.prefixAttempts, prefixPaid: foregroundTrace.prefixPaid }
    try {` + body + `
    } finally {
      if (primitive.kind === 'text') foregroundTrace.textProgress.push({ ...foregroundStart, endOperations: operations, endExhausted: exhausted, prefixAttempts: foregroundTrace.prefixAttempts - foregroundStart.prefixAttempts, prefixPaid: foregroundTrace.prefixPaid - foregroundStart.prefixPaid })
    }
  }`
    source = source.slice(0, begin) + instrumented + source.slice(finish)
    const result = "  return Object.freeze({ version: 1, unit: 'px', scope: 'native-scene', status: failed ? 'failed' : unverified ? 'unverified' : 'passed'"
    if (source.split(result).length !== 2) throw new Error('foreground result boundary changed')
    source = source.replace(result, '  foregroundTrace.finalOperations = operations; foregroundTrace.finalPairs = pairs; foregroundTrace.finalExhausted = exhausted\n' + result)
    writeFileSync(directory + '/paint.instrumented.ts', source)
    return { contents: source, loader: 'ts' }
  })
  build.onLoad({ filter: /\/src\/__tests__\/paint-certification\.test\.ts$/ }, args => {
    let source = readFileSync(args.path, 'utf8')
    const table = "test.each([0, 32])('sparse decorative markers preserve completed direct and emitted text proof"
    if (source.split(table).length !== 2) throw new Error('sparse32 owner table changed')
    source = source.replace(table, "test.each([32])('sparse decorative markers preserve completed direct and emitted text proof")
    const check = "  for (const proof of [certifyScenePaint(producer(marks, context)), certifyNativePaint(drawing.header, drawing.paint)]) expect(proof).toMatchObject({ status: 'passed', issues: [] })"
    const begin = source.indexOf(check, source.indexOf("test.each([32])('sparse decorative markers"))
    if (begin < 0) throw new Error('sparse32 proof capture boundary changed')
    const replacement = `  const directScene = producer(marks, context)
  const sparse32Proofs = [certifyScenePaint(directScene), certifyNativePaint(drawing.header, drawing.paint)]
  const sparse32Packet = { markerCount, svg: drawing.svg, header: drawing.header, scene: { family: directScene.family, width: directScene.width, height: directScene.height, transparent: directScene.transparent, colors: directScene.colors }, proofs: sparse32Proofs, traces: (globalThis as any)[Symbol.for('${traceKey}')], scope: 'direct drawNative SVG and raw Scene/Native paint certification; no public SVG security pipeline' }
  saveSparse32Evidence('${directory}/baseline-packet.json', JSON.stringify(sparse32Packet, null, 2))
  saveSparse32Evidence('${directory}/baseline.svg', drawing.svg)
  for (const proof of sparse32Proofs) expect(proof).toMatchObject({ status: 'passed', issues: [] })`
    source = "import { writeFileSync as saveSparse32Evidence } from 'node:fs'\n" + source.slice(0, begin) + replacement + source.slice(begin + check.length)
    writeFileSync(directory + '/owner.instrumented.ts', source)
    return { contents: source, loader: 'ts' }
  })
} })
