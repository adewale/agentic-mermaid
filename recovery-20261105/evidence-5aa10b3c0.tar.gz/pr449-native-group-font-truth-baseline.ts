
const sliceDescriptor = Object.getOwnPropertyDescriptor(String.prototype, 'slice')
const slice = sliceDescriptor.value
const findDescriptor = Object.getOwnPropertyDescriptor(Array.prototype, 'find')
const pushDescriptor = Object.getOwnPropertyDescriptor(Array.prototype, 'push')
let mode, hookCalls = 0
// Install before importing the producer: capturing this method at module load
// cannot turn the callback's substituted token into actual SVG authority.
Object.defineProperty(String.prototype, 'slice', { ...sliceDescriptor, value: function(start, end) {
  const actual = Reflect.apply(slice, this, [start, end])
  if ((mode === 'hooked-mono' || mode === 'validator-slice') && String(this) === '<g class="mono">' && actual === 'mono'
    && new Error().stack?.includes(mode === 'validator-slice' ? 'assertInertGroup' : 'nativeGroup')) { hookCalls++; return 'safe' }
  return actual
} })
Object.defineProperty(Array.prototype, 'find', { ...findDescriptor, value: function(predicate, thisArg) {
 const found = Reflect.apply(findDescriptor.value, this, [predicate, thisArg])
 if (mode === 'hooked-find' && found?.name === 'class' && found.value === 'mono' && typeof found.valueStart === 'number') { hookCalls++; return { ...found, value: 'safe' } }
 return found
} })
Object.defineProperty(Array.prototype, 'push', { ...pushDescriptor, value: function(...values) {
 if (mode === 'hooked-push') for (let i=0;i<values.length;i++) {const value=values[i]; if(value?.name === 'class' && value.value === 'mono' && typeof value.valueStart === 'number') { hookCalls++; values[i]={...value,value:'safe'} }}
 return Reflect.apply(pushDescriptor.value, this, values)
} })
const rows = []
try {
  const { drawNative } = await import('/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts')
  const { certifyNativePaint } = await import('/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts')
  const { preparePixelText, hasPreparedInterTextEnvelope } = await import('/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts')
  const { withTextMeasurementExecution } = await import('/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts')
  const { tipAnchoredArrow, serializeMarkerResource } = await import('/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts')
  const { svgOpenTag, buildStyleBlock } = await import('/tmp/pr449-main-integration-20261029-762/src/theme.ts')
  const width = 200, height = 120, colors = { bg: '#fff', fg: '#111', font: 'Inter' }
  const context = { positioned: { width, height }, colors, resolved: { renderOptions: {} } }
  const block = withTextMeasurementExecution(undefined, () => preparePixelText('Wiii', { fontSize: 20, fontWeight: 400 }), 'Inter')
  const marker = tipAnchoredArrow('font-custody-arrow', { width: 8, height: 5 }, 'end', { fill: '#000' }, 'userSpaceOnUse')
  for (mode of ['safe', 'mono', 'hooked-mono', 'validator-slice', 'hooked-find', 'hooked-push']) {
    const producer = factory => ({ family: 'flowchart', width, height, colors, transparent: false, parts: [
      factory.documentOpen({ id: 'root', width, height, colors, transparent: false, font: 'Inter', hasMonoFont: true }, svgOpenTag(width, height, colors) + '\n' + buildStyleBlock('Inter', true, false, false)),
      factory.definitions({ id: 'markers' }, '<defs>' + serializeMarkerResource(marker) + '</defs>'),
      factory.connector({ id: 'edge', role: 'edge', lineStyle: 'solid', geometry: { kind: 'line', x1: 20, y1: 40, x2: 50, y2: 40 }, paint: { stroke: '#000' }, endpoints: { from: 'outside', to: 'cover' }, markers: { end: marker } }),
      factory.shape({ id: 'cover', role: 'node', geometry: { kind: 'rect', x: 90, y: 10, width: 35, height: 45 }, paint: { fill: '#fff' } }),
      factory.group({ id: 'font-group', role: 'chrome', open: '<g class="' + (mode === 'safe' ? 'safe' : 'mono') + '">', close: '</g>', children: [{ node: factory.text({ id: 'font-text', role: 'label', text: block.text, block, x: 20, y: 90, fontSize: 20, anchor: 'start', paint: { fill: '#111' } }), indent: 2 }] }),
      factory.documentClose(),
    ] })
    const drawing = drawNative(producer, context, 'flowchart')
    rows.push({ mode, hookCalls, svg: drawing.svg, proof: certifyNativePaint(drawing.header, drawing.paint), preparedInter: hasPreparedInterTextEnvelope(block), ownFont: Object.hasOwn(block, 'fontFamily') })
  }
} finally { Object.defineProperty(String.prototype, 'slice', sliceDescriptor); Object.defineProperty(Array.prototype, 'find', findDescriptor); Object.defineProperty(Array.prototype, 'push', pushDescriptor) }
console.log(JSON.stringify({ rows, hookCalls, restored: String.prototype.slice === slice }))
