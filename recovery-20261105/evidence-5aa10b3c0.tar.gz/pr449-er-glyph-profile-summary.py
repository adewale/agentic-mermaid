# Read-only CPU-profile sample attribution; no render/layout/build calls.
import pathlib,json,gzip,collections
O=pathlib.Path('/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5');d=json.loads(gzip.decompress((O/'RESULTS.json.gz').read_bytes()));out={'head':d['head'],'calls':d['calls'],'completed':d['completed'],'errors':d['errors'],'sourceUnchanged':d['sourceUnchanged'],'ramRemoved':d['ramRemoved'],'profiles':[],'measurements':[],'limits':['CPU profiles include imports, two full renders/Native certification, GC, observers, serialization and profiling overhead; not render-only timing','timeDeltas are sampling time weights, not causal timing savings; N=1/profile cell','Direct native find/filter frames merge call sites within finishErGeometry; exact predicate frames give narrower evidence; native filter total is an upper bound for the proposed pair filter','No predicate-count instrumentation, after-cost call, witness or build executed; baseline public-call budget8 is exhausted']}
for r in d['runs']:
 tag=str(r['count'])+'-'+r['backend'];P=O/(tag+'.cpuprofile');p=json.loads(P.read_text());ns={n['id']:n for n in p['nodes']};parents={c:n['id']for n in p['nodes']for c in n.get('children',[])}
 def ancestry(i):
  a=[i]
  while a[-1]in parents:a.append(parents[a[-1]])
  return a
 def key(i):
  f=ns[i]['callFrame'];return(f['functionName']or'<anonymous>',f['url'],f['lineNumber']+1,f['columnNumber']+1)
 paths={i:ancestry(i)for i in ns};selfN=collections.Counter();selfUS=collections.Counter();incN=collections.Counter();incUS=collections.Counter()
 for i,delta in zip(p['samples'],p['timeDeltas']):
  k=key(i);selfN[k]+=1;selfUS[k]+=delta
  for k in set(key(j)for j in paths[i]):incN[k]+=1;incUS[k]+=delta
 def record(k):return {'function':k[0],'url':k[1],'line':k[2],'column':k[3],'selfSamples':selfN[k],'selfMs':selfUS[k]/1000,'inclusiveSamples':incN[k],'inclusiveMs':incUS[k]/1000}
 keys=set(incN);real=lambda k:k[0]not in ['(root)','(program)','(idle)']
 core=lambda k:('/src/'in k[1]and k[0]not in ['<anonymous>','withPerformanceObserver','withRenderStageObserver','withObservedRenderStage','observeRenderStage','withSvgInspectionCache','withTextMeasurementExecution','withGraphLayoutDecisionObserver'])
 stat={'tag':tag,'profileReference':str(P),'samples':len(p['samples']),'sampleWeightMs':sum(p['timeDeltas'])/1000,'profileSpanMs':(p['endTime']-p['startTime'])/1000,'top5Self':[record(k)for k in sorted(filter(real,keys),key=lambda k:selfUS[k],reverse=True)[:5]],'top5Inclusive':[record(k)for k in sorted(filter(real,keys),key=lambda k:incUS[k],reverse=True)[:5]],'top5CoreSelf':[record(k)for k in sorted(filter(core,keys),key=lambda k:selfUS[k],reverse=True)[:5]],'top5CoreInclusive':[record(k)for k in sorted(filter(core,keys),key=lambda k:incUS[k],reverse=True)[:5]],'finishErGeometry':[record(k)for k in keys if k[0]=='finishErGeometry'and k[1].endswith('/er/layout.ts')],'targetPredicates':[record(k)for k in keys if k[1].endswith('/er/layout.ts')and k[2]in [1356,1392,1398,1447]],'directArrayBuiltinsUnderFinish':[],'finishPositionTicks':[]}
 for i,n in ns.items():
  f=n['callFrame'];parent=ns[parents[i]]['callFrame']if i in parents else{}
  if f['functionName']=='finishErGeometry'and f['url'].endswith('/er/layout.ts'):stat['finishPositionTicks'].append({'frameId':i,'ticks':sorted(n.get('positionTicks',[]),key=lambda x:x['ticks'],reverse=True)})
  if f['functionName']in ['find','filter','flatMap','flatIntoArrayWithCallback']and parent.get('functionName')=='finishErGeometry'and parent.get('url','').endswith('/er/layout.ts'):
   sampled=[(leaf,delta)for leaf,delta in zip(p['samples'],p['timeDeltas'])if i in paths[leaf]]
   own=[delta for leaf,delta in zip(p['samples'],p['timeDeltas'])if leaf==i]
   stat['directArrayBuiltinsUnderFinish'].append({'frameId':i,'function':f['functionName'],'selfSamples':len(own),'selfMs':sum(own)/1000,'inclusiveSamples':len(sampled),'inclusiveMs':sum(t for _,t in sampled)/1000,'predicateChildren':[{'frameId':c,**dict(zip(['function','url','line','column'],key(c)))}for c in n.get('children',[])],'callerStack':[record(key(j))for j in paths[i][1:12]]})
 out['profiles'].append(stat)
 rows=r['rows'];out['measurements'].append({'tag':tag,'importMs':r['importMs'],'elapsedMs':[x['elapsedMs']for x in rows],'peakRssKiB':r['peakRssKiB'],'postGC':[x['afterGC']for x in rows],'statuses':[(x['status'],x.get('proof',{}).get('status'),x.get('proof',{}).get('checks',{}).get('operations'))for x in rows],'fullyConsumedBytes':sum(x.get('bytes',0)for x in rows),'coldRepeatSVGExact':pathlib.Path(rows[0]['svgReference']).read_bytes()==pathlib.Path(rows[1]['svgReference']).read_bytes(),'coldRepeatEntireRawReceiptExact':rows[0]['receiptJSON']==rows[1]['receiptJSON'],'stageRows':[x['stages']for x in rows]})
 print('\nPROFILE',tag,'samples',stat['samples'],'sampleWeightMs',stat['sampleWeightMs'])
 for name in ['top5Self','top5Inclusive','top5CoreSelf','top5CoreInclusive','finishErGeometry','targetPredicates']:
  print(name,[(v['function'],v['url'].split('/')[-1],v['line'],v['selfSamples'],round(v['selfMs'],3),v['inclusiveSamples'],round(v['inclusiveMs'],3))for v in stat[name]])
 print('DIRECT BUILTINS',[(v['function'],v['selfSamples'],v['selfMs'],v['inclusiveSamples'],v['inclusiveMs'])for v in stat['directArrayBuiltinsUnderFinish']])
 print('TARGET TICKS',[(t['line'],t['ticks'])for frame in stat['finishPositionTicks']for t in frame['ticks']if 1356<=t['line']<=1455])
 print('MEASUREMENT',out['measurements'][-1]['statuses'],'ms',out['measurements'][-1]['elapsedMs'],'RSSKiB',r['peakRssKiB'],'heapMiB',[round(x['afterGC']['heapUsed']/1048576,2)for x in rows])
(O/'SUMMARY.json.gz').write_bytes(gzip.compress(json.dumps(out,separators=(',',':')).encode(),mtime=0));print('SUMMARY',str(O/'SUMMARY.json.gz'))
