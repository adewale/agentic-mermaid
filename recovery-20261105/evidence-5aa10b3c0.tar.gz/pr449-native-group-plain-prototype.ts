// NONSHIPPING PLAIN-INPUT VALUE PROBE. Known unsafe under conditional primitive hooks.
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {gzipSync,gunzipSync} from 'node:zlib'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/native-group-plain-prototype-9f519'
mkdirSync(out,{recursive:true})
Bun.plugin({name:'nonshipping-singleton-validator-group-parse-handoff',setup(build){
 build.onLoad({filter:/\/src\/scene\/(group-emission|emission-context|native-paint-emission)\.ts$/},args=>{
  let source=readFileSync(args.path,'utf8');const original=source
  if(args.path.endsWith('/group-emission.ts')){
   source=source.replace("import { visitSvgFirstTagAttributes }", "import { scanSvgStartTagsFresh }")
   const start="  const tag = GROUP_OPEN.test(open) ? visitSvgFirstTagAttributes(open, 'g', (name, value) => {"
   const end='  }) : undefined'
   if(!source.includes(start)||!source.includes(end))throw Error('exact first parse')
   source=source.replace(start,`  const parsedTags = GROUP_OPEN.test(open) ? scanSvgStartTagsFresh(open) : undefined
  const tag = parsedTags?.[0]?.name
  if (tag === 'g') for (const {name, value} of parsedTags![0]!.attributes) {`).replace(end,'  }')
   // The callback's early return meant continue to the next attribute.
   source=source.replace("decodeXML(value) === paint[name]) return", "decodeXML(value) === paint[name]) continue")
   const issued="  return { matrix: matrix && Object.freeze(matrix), style: names.has('style') }"
   if(!source.includes(issued))throw Error('parse finish')
   source=source.replace(issued,`  let retentionCost = 4
  for (const parsed of parsedTags!) retentionCost += 8 + parsed.attributes.length * 8
  ;(globalThis as any).__plainLastGroupParse = {open, tags: parsedTags, retentionCost}
  ;(globalThis as any).__plainGroupStats.issued++
`+issued)
  }else if(args.path.endsWith('/emission-context.ts')){
   const target=`      if (!reserve(svg.length * 8 + 28)) return undefined
      const tags = scanSvgStartTagsFresh(svg), tag = tags[0]`
   if(!source.includes(target))throw Error('exact native group parse')
   source=source.replace(target,`      if (!reserve(4)) return undefined
      const handoff = (globalThis as any).__plainLastGroupParse
      const reuse = pinned && handoff?.open === svg
      const retentionCost = reuse ? handoff.retentionCost : 0
      if (!reserve((reuse ? retentionCost : svg.length * 8) + 28)) return undefined
      const tags = reuse ? handoff.tags : scanSvgStartTagsFresh(svg), tag = tags[0]
      ;(globalThis as any).__plainLastGroupParse = undefined
      ;(globalThis as any).__plainGroupStats[reuse ? 'reused' : 'fallback']++
      ;(globalThis as any).__plainGroupStats.retentionPaid += retentionCost
      ;(globalThis as any).__plainGroupStats.bindingPaid += 4`)
  }else{
   const target='if (!Number.isSafeInteger(count) || count < 0 || count > maxOperations - operations) { exhausted = true; return false }'
   if(!source.includes(target))throw Error('original cap branch')
   source=source.replace(target,`if (!Number.isSafeInteger(count) || count < 0 || count > maxOperations - operations) { (globalThis as any).__plainFirstExhaustion ??= {count,operations,stack:new Error().stack}; exhausted = true; return false }`)
  }
  writeFileSync(out+'/'+args.path.split('/').at(-1)+'.prototype.ts',source)
  writeFileSync(out+'/'+args.path.split('/').at(-1)+'.original.ts',original)
  return{contents:source,loader:'ts'}
 })
}})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const {withPerformanceObserver}=await import(root+'/src/performance-observations.ts')
for(const family of ['class','er']){
 const baseline=JSON.parse(gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/native-paid-9f519/'+family+'-sites.json.gz')).toString())
 ;(globalThis as any).__plainGroupStats={issued:0,reused:0,fallback:0,retentionPaid:0,bindingPaid:0}
 ;(globalThis as any).__plainLastGroupParse=undefined;(globalThis as any).__plainFirstExhaustion=undefined
 const events:any[]=[]
 const result=withPerformanceObserver(e=>events.push(e),()=>renderMermaidSVGWithReceipt(baseline.source,baseline.options))
 const serialized=JSON.stringify(result);let consumed=0;for(let i=0;i<serialized.length;i++)consumed+=serialized.charCodeAt(i)
 const record={family,source:baseline.source,options:baseline.options,actualPublicCalls:1,result,stats:(globalThis as any).__plainGroupStats,firstExhaustion:(globalThis as any).__plainFirstExhaustion,byteExactSVG:result.svg===baseline.result.svg,consumed:{utf16Units:serialized.length,sum:consumed},events,scope:'NONSHIPPING plain input only; known unsafe conditional primitive-hook handoff. Exact one actual Native publicSVG call. No qualified proof or promotion claim.'}
 writeFileSync(out+'/'+family+'.json.gz',gzipSync(JSON.stringify(record)))
 console.log(JSON.stringify({family,calls:1,proof:result.receipt.layoutCertification,stats:record.stats,firstExhaustion:record.firstExhaustion,byteExactSVG:record.byteExactSVG,providers:events.filter(e=>e.owner==='paint-certification')}))
}
