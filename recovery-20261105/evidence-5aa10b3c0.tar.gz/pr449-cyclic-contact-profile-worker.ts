// Existing recovery-cost.ts consumer, parameterized for the affected ER source/options.
import { readFileSync, writeFileSync, writeSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const job = JSON.parse(readFileSync(Bun.argv[2]!, 'utf8'))
const timeline: any[] = []
const marker = (event: string, phase?: string) => {
  const item = { event, phase, perfNowMs: performance.now(), timeOriginMs: performance.timeOrigin, epochMs: Date.now(), hrtimeNs: process.hrtime.bigint().toString(), cpu: process.cpuUsage() }
  timeline.push(item); writeSync(1, JSON.stringify({ diagnosticMarker: item }) + '\n'); return item
}
marker('worker-start')
let overlayLoads = 0
if (job.arm === 'before') Bun.plugin({ name: 'paired-cyclic-contact-baseline', setup(build) {
  build.onLoad({ filter: /\/src\/(?:route-contracts|layout-engine)\.ts$/ }, args => {
    overlayLoads++
    return { contents: readFileSync(job.overlays[args.path], 'utf8'), loader: 'ts' }
  })
} })
marker('imports-start')
const importStart = performance.now()
const { renderMermaidSVGWithReceipt } = await import(job.root + '/src/index.ts')
const { withRenderStageObserver } = await import(job.root + '/src/render-stages.ts')
const { withPerformanceObserver } = await import(job.root + '/src/performance-observations.ts')
const { apiFailure } = await import(job.root + '/eval/layout-compare/outcomes.ts')
const importMs = performance.now() - importStart
marker('imports-end')
const source = readFileSync(job.sourceFile, 'utf8'), edited = readFileSync(job.editFile, 'utf8')
const options = JSON.parse(readFileSync(job.optionsFile, 'utf8'))
const consume = (value: unknown, phase: string) => {
  marker('result-stringify-start', phase)
  const serialized = JSON.stringify(value)
  marker('result-stringify-end', phase)
  const bytes = Buffer.from(serialized, 'utf8')
  marker('checksum-start', phase)
  let checksum = 0
  for (let i = 0; i < bytes.length; i++) checksum = (Math.imul(checksum, 31) + bytes[i]!) >>> 0
  marker('checksum-end', phase)
  return { bytes: bytes.length, checksum }
}
const outputs: unknown[] = [], rows: unknown[] = []
let actualPublicCalls = 0
marker('loaded-gc-start')
Bun.gc(true)
marker('loaded-gc-end')
const loaded = process.memoryUsage()
for (const [phase, input] of [['cold', source], ['repeat', source], ['edit', edited]]) {
  const stages: unknown[] = [], events: any[] = []
  process.stdout.write('ACTUAL_PUBLIC_CALL_START\n')
  actualPublicCalls++
  marker('phase-start', phase)
  const start = performance.now()
  const phaseCPUStart = process.cpuUsage()
  let row: any
  try {
    marker('render-start', phase)
    const result = withPerformanceObserver((event: unknown) => events.push(event), () => withRenderStageObserver((stage: unknown) => stages.push(stage), () => renderMermaidSVGWithReceipt(input, options)))
    marker('render-end', phase)
    const consumed = consume(result, phase)
    marker('receipt-stringify-start', phase)
    const receiptJSON = JSON.stringify(result.receipt)
    marker('receipt-stringify-end', phase)
    row = { phase, status: 'returned', elapsedMs: performance.now() - start, ...consumed, receiptJSON,
      proof: result.receipt.layoutCertification, viewBox: result.svg.match(/viewBox="([^"]+)"/)?.[1] }
    row.phaseCPU = process.cpuUsage(phaseCPUStart)
    marker('phase-measured-end', phase)
    outputs.push(result)
    marker('svg-artifact-start', phase)
    writeFileSync(job.out + '-' + phase + '.svg.gz', gzipSync(result.svg))
    marker('svg-artifact-end', phase)
  } catch (error: any) {
    const failure = { error: apiFailure(error), name: error?.name, message: error?.message, stack: error?.stack, cause: { name: error?.cause?.name, message: error?.cause?.message, stack: error?.cause?.stack } }
    const consumed = consume(failure)
    row = { phase, status: 'refused', elapsedMs: performance.now() - start, consumedError: consumed, failure }
    outputs.push(failure)
  }
  row.stages = stages; row.events = events
  row.paintProviderEvents = events.filter(event => event.owner === 'paint-certification')
  marker('phase-gc-start', phase)
  Bun.gc(true)
  marker('phase-gc-end', phase)
  row.afterGC = process.memoryUsage()
  row.phaseCPU ??= process.cpuUsage(phaseCPUStart)
  row.markerReference = 'timeline'
  marker('phase-end', phase)
  rows.push(row)
  if (row.status === 'refused') break
}
marker('worker-results-start')
writeFileSync(job.out + '.json.gz', gzipSync(JSON.stringify({ arm: job.arm, count: job.count, backend: job.backend, source, edited, options, actualPublicCalls, overlayLoads, cache: process.env.AGENTIC_MERMAID_ELK_CACHE, importMs, loaded, timeline, profiler: { kind: 'Bun builtin --cpu-prof', interval: 'default1000us', scope: 'process including imports/render/consumption/artifactGC/markers' }, peakRssKiB: process.resourceUsage().maxRSS, rows })))
