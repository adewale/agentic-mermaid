import pathlib,os,sys,json,gzip,tempfile,subprocess,shutil,ast
R=pathlib.Path('/tmp/pr449-main-integration-20261029-762');W=pathlib.Path('/tmp/pr449-week-comparison-20261101');B='bb7492b44ac5c95a16460fc00ef2c01a558305a1';BUN='/tmp/pr449-bin/bun';PATH='src/er/layout.ts';worker=pathlib.Path('/tmp/pr449-er-terminal-cost-worker.ts')
if sys.argv[1:]==['--prepare']:
 assert worker.is_file();print('STATIC_READY HOLD:8freshworkers/24publicSVGcalls max;ER207+256LR×Agentic/ELK×beforebb749ERmodule/current;geometrycacheOFF;3cold/repeat/lastowns-to-revises calls each;allSVG/ENTIREreceipt or refusalJSON fullyconsumed;provider/cache/stages/RSS/postGC;noP-onlygate/ratios;0calls.');sys.exit()
assert sys.argv[1:]==['--run'],'RootGO+ERownerCPUclear required'
E=dict(os.environ,PATH='/tmp/pr449-bin:'+os.environ['PATH'],GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',NODE_DISABLE_COMPILE_CACHE='1',AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env=E,text=True).strip()
head=git('rev-parse','HEAD');O=W/('er-terminal-cost-'+head[:9]);O.mkdir(exist_ok=True);S=None
j={'beforeERModuleRevision':B,'candidateHead':head,'actualPublicCalls':0,'runs':[],'errors':[],'scope':'Exactly8freshworkers/24publicSVGcalls maximum. Geometrycacheoff only;207+adverse256 LR bothbackend beforebb749ERmodule/currentfrozenmodule. Onecold/repeat/visiblelastcaptionedit each. EntireSVG+rawENTIREreceipt or fullrefusal serialization consumed. All statuses/providers/errors/adverse preserved;noP-onlygate. N1/cell,reverseorders acrosscases notindependentreplication;no ratio/causal/preservation/allocationclaim. RSS/postGC includesimports/overlay/harness/stages/observations/threeheldproducts.'}
def gz(name,v):
 data=v if isinstance(v,bytes)else json.dumps(v,separators=(',',':')).encode();(O/name).write_bytes(gzip.compress(data,compresslevel=9,mtime=0))
def save():gz('RESULTS.json.gz',j)
try:
 before=subprocess.check_output(['git','show',B+':'+PATH],cwd=R,env=E);after=(R/PATH).read_bytes();assert before!=after
 S=pathlib.Path(tempfile.mkdtemp(prefix='pr449-er-terminal-cost-',dir='/dev/shm'));E.update(TMPDIR=str(S),XDG_CACHE_HOME=str(S/'cache'),BUN_RUNTIME_TRANSPILER_CACHE_PATH=str(S/'bun-cache'))
 (S/'before.ts').write_bytes(before);(S/'after.ts').write_bytes(after);(S/'worker.ts').write_bytes(worker.read_bytes());j['cases']={}
 for n in [207,256]:
  source='erDiagram\ndirection LR\n'+'\n'.join(f'N{i} ||--o{{ N{i+1} : owns'for i in range(n-1));last=f'N{n-2} ||--o{{ N{n-1} : owns';assert source.count(last)==1;edited=source.replace(last,last.removesuffix('owns')+'revises')
  (S/(str(n)+'.mmd')).write_text(source);(S/(str(n)+'-edit.mmd')).write_text(edited);j['cases'][str(n)]={'source':source,'edited':edited,'edit':'last relationship owns→revises','counts':{'entities':n,'relationships':n-1}}
 syntax=subprocess.run([BUN,'-e',"new Bun.Transpiler({loader:'ts'}).transformSync(require('node:fs').readFileSync(process.argv[1],'utf8'));console.log('SYNTAX_OK')",str(S/'worker.ts')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert syntax.returncode==0,syntax.stderr.decode();print(syntax.stdout.decode().strip(),flush=True)
 jobs=[(207,'agentic','before'),(207,'agentic','after'),(207,'elk','after'),(207,'elk','before'),(256,'agentic','after'),(256,'agentic','before'),(256,'elk','before'),(256,'elk','after')]
 for i,(count,backend,arm)in enumerate(jobs):
  options={'graphLayout':{'backend':backend,'fallback':'none'}};(S/'options.json').write_text(json.dumps(options));out=S/('w'+str(i));job={'root':str(R),'count':count,'backend':backend,'arm':arm,'overlay':str(S/(arm+'.ts')),'sourceFile':str(S/(str(count)+'.mmd')),'editFile':str(S/(str(count)+'-edit.mmd')),'optionsFile':str(S/'options.json'),'out':str(out)};(S/'job.json').write_text(json.dumps(job))
  p=subprocess.run([BUN,str(S/'worker.ts'),str(S/'job.json')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);actual=p.stdout.decode().count('ACTUAL_PUBLIC_CALL_START');j['actualPublicCalls']+=actual;gz('w'+str(i)+'-stdout-stderr.log.gz',p.stdout+p.stderr)
  if p.returncode:
   j['errors'].append({'worker':i,'count':count,'backend':backend,'arm':arm,'actualCallsObserved':actual,'exitCode':p.returncode,'stderr':p.stderr.decode()});save();continue
  row=json.loads(gzip.decompress(pathlib.Path(str(out)+'.json.gz').read_bytes()));assert row['actualPublicCalls']==actual;row['worker']=i
  for phase in row['rows']:
   if phase['status']=='returned':
    name=f'{count}-{backend}-{arm}-{phase["phase"]}.svg.gz';data=gzip.decompress(pathlib.Path(str(out)+'-'+phase['phase']+'.svg.gz').read_bytes());gz(name,data);phase['svgReference']=str(O/name)
  j['runs'].append(row);save();print('WORKER',i,count,backend,arm,'calls',actual,'RSSKiB',row['peakRssKiB'],[(x['phase'],x['status'],round(x['elapsedMs'],3),x.get('proof',{}).get('status'),[e.get('detail')for e in x['paintProviderEvents']])for x in row['rows']],flush=True)
 j['ERSourceUnchanged']=(R/PATH).read_bytes()==after;j['completed']=j['actualPublicCalls']==24 and len(j['runs'])==8 and not j['errors']and j['ERSourceUnchanged']and all(r['overlayLoads']==1 for r in j['runs'])
except Exception as e:j['error']=repr(e);j['completed']=False
finally:
 if S:shutil.rmtree(S)
 j['ramRemoved']=S is None or not S.exists();save();print('FINAL',json.dumps({k:j.get(k)for k in ['completed','actualPublicCalls','errors','error','ERSourceUnchanged','ramRemoved']}),flush=True)
