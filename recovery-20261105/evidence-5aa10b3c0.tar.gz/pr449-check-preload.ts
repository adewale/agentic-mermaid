(globalThis as any).__preloadProof=1
