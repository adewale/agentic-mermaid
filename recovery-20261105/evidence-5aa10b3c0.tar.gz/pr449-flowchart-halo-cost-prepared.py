# Parameter-only adaptation of the retained ER-prefix cost controller and consumer.
# --prepare does syntax-only preparation; --run requires explicit root GO and frozen HEAD.
import ast, pathlib, sys
base = pathlib.Path('/tmp/pr449-er-prefix-cost-prepared.py')
s = base.read_text()
def swap(old, new):
    global s
    assert old in s, old
    s = s.replace(old, new)
swap('adb4633a0^{commit}', '08336d29a99c540b7928d7a66789baa294b5299f^{commit}')
swap("PATHS=['src/er/layout.ts','src/er/label-layout.ts']", "PATHS=['src/layout/agentic-producer-core.ts']")
swap("O=W/('er-prefix-cost-'+head[:9])", "O=W/('flowchart-fit-cost-'+head[:9])")
swap("prefix='pr449-er-prefix-cost-'", "prefix='pr449-flowchart-fit-cost-'")
swap("'RootGO+ERownerCPUclear required'", "'RootGO+ownerCPUclear required'")
swap("(S/'worker.ts').write_bytes(worker.read_bytes());j['cases']={}", "(S/'worker.ts').write_text(worker.read_text().replace('paired-ER-prefix-source','paired-flowchart-fit-source').replace(" + repr(r'/\/src\/er\/(?:layout|label-layout)\.ts$/') + "," + repr(r'/\/src\/layout\/agentic-producer-core\.ts$/') + "));j['cases']={}")
a = s.index(' for n in [32,208,256]:')
b = s.index(' syntax=subprocess.run', a)
s = s[:a] + ''' retained=json.loads(gzip.decompress((W/'requirement-cycle-25e/before-cyclic-labelled-9-chains.mmd-agentic.json.gz').read_bytes()));cyclic=(R/'eval/layout-compare/fixtures/cyclic-labelled-9-chains.mmd').read_text();assert cyclic==retained['source'];assert cyclic.count('|edge 20 xxxxxx|')==1
 control='flowchart RL\\nA[Source] -->|input| B{Validate}\\nB -->|approved| C[Store]\\nC -->|commit| D[Done]\\nA -->|audit| D'
 cases=[('cyclic9',cyclic,cyclic.replace('|edge 20 xxxxxx|','|edge 20 revised|')),('acyclic4',control,control.replace('|audit|','|audit revised|'))]
 for name,source,edited in cases:
  assert source!=edited
  (S/(name+'.mmd')).write_text(source);(S/(name+'-edit.mmd')).write_text(edited);j['cases'][name]={'source':source,'edited':edited,'edit':'unique visible final caption edit','counts':{'nodes':9 if name=='cyclic9' else 4,'edges':23 if name=='cyclic9' else 4},'direction':'RL'}
''' + s[b:]
a = s.index(' jobs=[')
b = s.index('\n for i,', a)
s = s[:a] + " jobs=[('cyclic9','agentic','before'),('cyclic9','agentic','after'),('cyclic9','elk','after'),('cyclic9','elk','before'),('acyclic4','agentic','after'),('acyclic4','agentic','before'),('acyclic4','elk','before'),('acyclic4','elk','after')]" + s[b:]
swap("options={'graphLayout':{'backend':backend,'fallback':'none'}}", "options={'graphLayout':{'backend':backend,'fallback':'none'},'embedFontImport':False}")
swap("j['actualPublicCalls']==36 and len(j['runs'])==12", "j['actualPublicCalls']==24 and len(j['runs'])==8")
swap("r['overlayLoads']==2", "r['overlayLoads']==1")
swap('ERSourceUnchanged', 'flowchartSourceUnchanged')
a = s.index("'scope':")
b = s.index("}\ndef gz", a)
scope = 'Exactly8freshworkers/24publicSVGcalls maximum. Cyclic9chains RL+acyclic4labelled RL;bothbackends before083/currentonecoremodule. Geometrycacheoff only;onecold/repeat/visiblecaptionedit each. Exactretainedoptions graphLayoutselected/fallbacknone/embedFontImportfalse;spacingomitted. EntireSVG+ENTIRErawreceipt/fullrefusalJSON consumed. Allstatuses/providers/stages/errors/adverse preserved. N1/cell/reversedorderacrosscasesnotreplication;no ratio/causal/preservation/allocationclaim. RSS/postGC includesimports/overlay/harness/observers/threeheldproducts. No build.'
s = s[:a] + "'scope':" + repr(scope) + s[b:]
needle="head=git('rev-parse','HEAD');assert len(sys.argv)==2 or head==sys.argv[2],'Wrong frozenHEAD';"
replacement="""head=git('rev-parse','HEAD');assert len(sys.argv)==3 and head==sys.argv[2],'Exact frozenHEAD required';
def production(paths):return [p for p in paths.splitlines()if p and not p.startswith('src/__tests__/')and '/__tests__/'not in p]
assert not production(git('diff','--name-only','HEAD','--','src')),'Dirty production source'
assert set(production(git('diff','--name-only',B,'HEAD','--','src')))==set(PATHS),'Candidate must change exactly frozen core module; expand overlays if scope changes'
"""
swap(needle,replacement)
a = s.index(" assert worker.is_file();print(")
b = s.index('\nassert len(sys.argv)', a)
s = s[:a] + " assert worker.is_file();print('STATIC_READY HOLD:8freshworkers/24calls;cyclic9chainsRL+acyclic4labelledRL bothengines before083/currentonecoreoverlay;cacheOFF cold/repeat/edit;wholeSVG+ENTIREreceipt/fullerror,stages/providers/RSS/postGC;noPgate;0calls/0build.');sys.exit()" + s[b:]
ast.parse(s)
if sys.argv[1:]==['--prepare']:
    print('AST_ONLY_READY: inherited controller/consumer parameter adaptation; 8 fresh workers / 24 calls after separate root GO; 0 calls / 0 builds.')
else:
    assert len(sys.argv)==3 and sys.argv[1]=='--run', 'Root GO and exact frozen SHA required'
    exec(compile(s, '<retained-flowchart-halo-cost-controller>', 'exec'))
