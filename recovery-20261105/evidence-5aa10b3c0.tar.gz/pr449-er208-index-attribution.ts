import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/er208-index-adb463'
mkdirSync(out,{recursive:true})
const stats={treeBuilds:0,branches:0,sameAxisBranches:0,sameAxisRows:0,sameAxisOrderedChecks:0,allOrderedChecks:0}
;(globalThis as any).__inkStats=stats;let sameAxis=false
;(globalThis as any).__inkSameAxis=false
Bun.plugin({name:'temporary-current-ink-construction-attribution',setup(build){build.onLoad({filter:/\/src\/shared\/ink-index\.ts$/},args=>{
 let s=readFileSync(args.path,'utf8')
 s=s.replace("for (; ordered < items.length; ordered++) { charge();", "for (; ordered < items.length; ordered++) { (globalThis as any).__inkStats.allOrderedChecks++; if((globalThis as any).__inkSameAxis)(globalThis as any).__inkStats.sameAxisOrderedChecks++; charge();")
 s=s.replace('  const build = (rows: T[]): InkTree<T> => {','  ;(globalThis as any).__inkStats.treeBuilds++\n  const build = (rows: T[], parentAxis?: string): InkTree<T> => {')
 const axis="    const axis = box.x1 - box.x0 >= box.y1 - box.y0 ? 'x0' : 'y0'"
 s=s.replace(axis,axis+"\n    ;(globalThis as any).__inkStats.branches++; if(parentAxis===axis){(globalThis as any).__inkStats.sameAxisBranches++;(globalThis as any).__inkStats.sameAxisRows+=rows.length}")
 s=s.replace('    if (charge) chargeInkSort(rows, compare, charge)',"    const previousSameAxis=(globalThis as any).__inkSameAxis;(globalThis as any).__inkSameAxis=parentAxis===axis\n    if (charge) chargeInkSort(rows, compare, charge)")
 s=s.replace('    const middle = Math.floor(rows.length / 2)',"    ;(globalThis as any).__inkSameAxis=previousSameAxis\n    const middle = Math.floor(rows.length / 2)")
 s=s.replace('left: build(rows.slice(0, middle)), right: build(rows.slice(middle))','left: build(rows.slice(0, middle), axis), right: build(rows.slice(middle), axis)')
 writeFileSync(out+'/instrumented-ink-index.ts',s);return{contents:s,loader:'ts'}
})}})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const source='erDiagram\ndirection LR\n'+Array.from({length:207},(_,i)=>`N${i} ||--o{ N${i+1} : owns`).join('\n')
const options={graphLayout:{backend:'elk',fallback:'none'}}
let outcome:any
try{const result=renderMermaidSVGWithReceipt(source,options);outcome={status:'returned',result}}catch(e:any){outcome={status:'refused',error:{name:e.name,message:e.message,stack:e.stack,cause:e.cause&&{name:e.cause.name,message:e.cause.message,stack:e.cause.stack}}}}
writeFileSync(out+'/BASELINE.json.gz',gzipSync(JSON.stringify({source,options,actualPublicCalls:1,stats,outcome})))
console.log(JSON.stringify({stats,outcome:outcome.status,error:outcome.error,scope:'Current sameaxis orderedcheck count only; generic callbacks unchanged, no sortedhint reuse or production change.'}))
