import { readFileSync } from 'node:fs'
Bun.plugin({ name: 'er192-owning-red', setup(build) { build.onLoad({ filter: /\/src\/er\/layout\.ts$/ }, () => ({ contents: readFileSync('/tmp/pr449-week-comparison-20261101/er-terminal-parts-bb749/agentic192/before.ts', 'utf8'), loader: 'ts' })) } })
