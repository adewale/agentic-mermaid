import { appendFileSync, mkdirSync, readFileSync } from 'node:fs'
const arm = process.env.AM_CLASS_SCENE_OWNER_ARM
if (arm !== 'before' && arm !== 'current') throw new Error('explicit Class Scene owner arm required')
const tag = process.env.AM_CLASS_SCENE_OWNER_TAG
if (tag !== 'partial' && tag !== 'paint') throw new Error('explicit fresh Class Scene owner tag required')
const directory = '/tmp/pr449-week-comparison-20261101/class-scene-preference-52a'
mkdirSync(directory, { recursive: true })
Bun.plugin({ name: 'class-scene-preference-owning-replay', setup(build) {
  if (arm === 'before') build.onLoad({ filter: /\/src\/scene\/drawing\.ts$/ }, args => {
    appendFileSync(directory + '/owner-before-' + tag + '-overlay-loads.jsonl', JSON.stringify({ pid: process.pid, argv: process.argv, module: args.path, source: '/tmp/pr449-class-drawing-52a.before.ts' }) + '\n')
    return { contents: readFileSync('/tmp/pr449-class-drawing-52a.before.ts', 'utf8'), loader: 'ts' }
  })
  build.onLoad({ filter: /\/src\/__tests__\/class-layout-backends\.test\.ts$/ }, args => {
    let source = readFileSync(args.path, 'utf8')
    const boundary = 'const { rendered } = JSON.parse(child.stdout)'
    if (source.split(boundary).length !== 2) throw new Error('Class owner packet boundary changed')
    source = "import { writeFileSync as saveClassOwnerPacket } from 'node:fs'\n" + source
    source = source.replace(boundary, `saveClassOwnerPacket('${directory}/owner-${arm}-${tag}-' + direction + '.json', child.stdout)\n    ` + boundary)
    const childResult = "expect({ status: child.status, stderr: child.stderr }).toEqual({ status: 0, stderr: '' })"
    if (source.split(childResult).length !== 2) throw new Error('Class owner child-result boundary changed')
    source = source.replace(childResult, `saveClassOwnerPacket('${directory}/owner-${arm}-${tag}-' + direction + '-child.json', JSON.stringify(child, null, 2))\n    ` + childResult)
    const table = "test.each(['TB', 'BT', 'LR', 'RL'])('renders a long native Class chain"
    if (source.split(table).length !== 2) throw new Error('Class owner table boundary changed')
    source = source.replace(table, arm === 'before' || tag === 'paint' ? "test.each(['LR'])('renders a long native Class chain" : "test.each(['LR', 'RL'])('renders a long native Class chain")
    if (arm === 'before') {
      source = source.replace("runPublicClassChild(process.execPath, ['-e',", "runPublicClassChild(process.execPath, ['--preload', '/tmp/pr449-class-scene-owner-preload.ts', '-e',")
    }
    return { contents: source, loader: 'ts' }
  })
} })
