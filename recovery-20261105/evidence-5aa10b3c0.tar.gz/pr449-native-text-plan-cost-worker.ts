// Existing recovery-cost consumer, adapted to the exact sparse-marker Native owner.
import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const job = JSON.parse(readFileSync(Bun.argv[2]!, 'utf8'))
let overlayLoads = 0
const overlayPathsSeen: string[] = []
Bun.plugin({ name: 'paired-native-text-plan-source', setup(build) {
  build.onLoad({ filter: /\/src\/scene\/native-paint-emission\.ts$/ }, args => {
    overlayLoads++
    overlayPathsSeen.push(args.path)
    return { contents: readFileSync(job.overlays[args.path], 'utf8'), loader: 'ts' }
  })
} })
const importStart = performance.now()
const { drawNative } = await import(job.root + '/src/scene/native-drawing.ts')
const { certifyNativePaint } = await import(job.root + '/src/scene/paint-certification.ts')
const { preparePixelText } = await import(job.root + '/src/shared/prepared-text.ts')
const { tipAnchoredArrow, serializeMarkerResource } = await import(job.root + '/src/scene/marker-resources.ts')
const { withRenderStageObserver } = await import(job.root + '/src/render-stages.ts')
const { withPerformanceObserver } = await import(job.root + '/src/performance-observations.ts')
const importMs = performance.now() - importStart
const setupStart = performance.now()
const width = 200, height = 31000, colors = { bg: '#fff', fg: '#111' }
const block = preparePixelText('x', { fontSize: 12, fontWeight: 400 })
const editedBlock = preparePixelText('y', { fontSize: 12, fontWeight: 400 })
const marker = tipAnchoredArrow('decorative-arrow', { width: 8, height: 5 }, 'end', { fill: '#111', stroke: '#111', strokeWidth: '0.75' }, 'userSpaceOnUse')
const context = { positioned: { width, height }, colors, resolved: { renderOptions: {} } }
const producer = (edited: boolean) => (factory: any) => ({ family: 'flowchart', width, height, colors, transparent: false, parts: [
  factory.documentOpen({ id: 'root', width, height, colors, transparent: false, font: 'Inter', hasMonoFont: false }, `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">`),
  ...(job.count ? [factory.definitions({ id: 'resources' }, `<defs>${serializeMarkerResource(marker)}</defs>`)] : []),
  ...Array.from({ length: job.count }, (_, index) => factory.connector({ id: `chrome:${index}`, role: 'chrome', lineStyle: 'solid', geometry: { kind: 'line', x1: 20, y1: 40 + index * 20, x2: 60, y2: 40 + index * 20 }, paint: { stroke: '#111', strokeWidth: '1' }, markers: { end: marker } })),
  ...Array.from({ length: 1500 }, (_, index) => factory.text({ id: `text:${index}`, role: 'label', text: edited && index === 1499 ? 'y' : 'x', block: edited && index === 1499 ? editedBlock : block, x: 20, y: 1000 + index * 20, fontSize: 12, anchor: 'start', paint: { fill: '#111' } })),
  factory.documentClose(),
] })
const fixtureSetupMs = performance.now() - setupStart
const consume = (value: unknown) => {
  const bytes = Buffer.from(JSON.stringify(value), 'utf8')
  let checksum = 0
  for (let i = 0; i < bytes.length; i++) checksum = (Math.imul(checksum, 31) + bytes[i]!) >>> 0
  return { bytes: bytes.length, checksum }
}
const outputs: unknown[] = [], rows: any[] = []
let actualDrawCalls = 0, actualCertificationCalls = 0
Bun.gc(true)
const loaded = process.memoryUsage()
for (const [phase, edited] of [['cold', false], ['repeat', false], ['edit', true]] as const) {
  const stages: unknown[] = [], events: any[] = []
  const start = performance.now()
  let drawMs: number | undefined, certificationMs: number | undefined
  let row: any
  try {
    const result = withPerformanceObserver((event: unknown) => events.push(event), () => withRenderStageObserver((stage: unknown) => stages.push(stage), () => {
      process.stdout.write('ACTUAL_DRAW_CALL_START\n'); actualDrawCalls++
      const drawStart = performance.now()
      const drawing = drawNative(producer(edited), context, 'flowchart')
      drawMs = performance.now() - drawStart
      process.stdout.write('ACTUAL_CERTIFICATION_CALL_START\n'); actualCertificationCalls++
      const certificationStart = performance.now()
      const proof = certifyNativePaint(drawing.header, drawing.paint)
      certificationMs = performance.now() - certificationStart
      return { svg: drawing.svg, proof }
    }))
    const consumed = consume(result), proofJSON = JSON.stringify(result.proof)
    row = { phase, status: 'returned', elapsedMs: performance.now() - start, ...consumed, proofJSON, proof: result.proof }
    outputs.push(result)
    writeFileSync(job.out + '-' + phase + '.svg.gz', gzipSync(result.svg))
  } catch (error: any) {
    const failure = { name: error?.name, message: error?.message, stack: error?.stack, cause: { name: error?.cause?.name, message: error?.cause?.message, stack: error?.cause?.stack } }
    row = { phase, status: 'refused', elapsedMs: performance.now() - start, consumedError: consume(failure), failure }
    outputs.push(failure)
  }
  row.stages = stages; row.events = events
  row.drawMs = drawMs; row.certificationMs = certificationMs
  Bun.gc(true)
  row.afterGC = process.memoryUsage()
  rows.push(row)
  if (row.status === 'refused') break
}
writeFileSync(job.out + '.json.gz', gzipSync(JSON.stringify({ arm: job.arm, count: job.count, actualDrawCalls, actualCertificationCalls, overlayLoads, overlayPathsSeen, importMs, fixtureSetupMs, loaded, peakRssKiB: process.resourceUsage().maxRSS, rows })))
