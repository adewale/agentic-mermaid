import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/native-paid-9f519'
Bun.plugin({name:'temporary-static-paid-sites',setup(build){
 build.onLoad({filter:/\/src\/scene\/(native-paint-emission|emission-context)\.ts$/},args=>{
 let source=readFileSync(args.path,'utf8');const native=args.path.endsWith('/native-paint-emission.ts');const name=native?'pay':'reserve',wrapper=native?'__tracePay':'__traceReserve'
 source=source.split('\n').map((line,index)=>line.replace(new RegExp('\\b'+name+'\\(', 'g'),`${wrapper}('${native?'native':'context'}:${index+1}',`)).join('\n')
 const wrap=`const ${wrapper}=(tag:string,count=1):boolean=>{const state=(globalThis as any).__paidSiteState;const prior=state.tag;state.tag=tag;try{return ${name}(count)}finally{state.tag=prior}};`
 if(native){
 const original=`if (exhausted) return false\n    if (!Number.isSafeInteger(count) || count < 0 || count > maxOperations - operations) { exhausted = true; return false }\n    operations += count`
 const instrumented=`const __state=(globalThis as any).__paidSiteState;const __site=__state.tag??'callback';const __row=(__state.sites[__site]??={calls:0,requested:0,paid:0,rejected:0});__row.calls++;__row.requested+=count;\n    if (exhausted) {__row.rejected++;return false}\n    if (!Number.isSafeInteger(count) || count < 0 || count > maxOperations - operations) { __row.rejected++;__state.firstRejected??={site:__site,count,operations,stack:new Error().stack};exhausted = true; return false }\n    __row.paid+=count;operations += count`
 if(!source.includes(original))throw Error('originalpayexactmatch');source=source.replace(original,instrumented).replace('  const context = createEmissionContext(pay,',wrap+'\n  const context = createEmissionContext(pay,')
 }else source=source.replace("  const unsupportedFractionalLeaf = Symbol",wrap+"\n  const unsupportedFractionalLeaf = Symbol")
 return{contents:source,loader:'ts'}
 })
}})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
for(const family of ['class','er']){
 const prior=JSON.parse((await import('node:zlib')).gunzipSync(readFileSync(out+'/'+family+'.json.gz')).toString());(globalThis as any).__paidSiteState={sites:{}}
 const result=renderMermaidSVGWithReceipt(prior.source,prior.options);const ledger=(globalThis as any).__paidSiteState
 if(result.svg!==prior.result.svg||JSON.stringify(result.receipt)!==JSON.stringify(prior.result.receipt))throw Error('staticattributionchangedproduct')
 writeFileSync(out+'/'+family+'-sites.json.gz',gzipSync(JSON.stringify({source:prior.source,options:prior.options,result,ledger})))
 console.log(JSON.stringify({family,sites:Object.entries(ledger.sites).map(([site,row])=>({site,...row})).sort((a,b)=>b.paid-a.paid),firstRejected:ledger.firstRejected}))
}
