# Parameter-only adaptation of the retained canonical ER208 payload controller.
# No build, render, git operation or artifact mutation occurs during --prepare.
import ast, pathlib, sys, os
original = pathlib.Path('/tmp/pr449-er208-prefix-payload-prepared.py').read_text()
module = ast.parse(original)
assignment = next(node for node in module.body if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 's' for t in node.targets))
s = ast.literal_eval(assignment.value)
def swap(old, new):
    global s
    assert old in s, old
    s = s.replace(old, new)
swap("recovery-payload/er208-prefix-", "recovery-payload/flowchart-fit-escalated-")
swap("{('er','agentic'),('er','elk')}", "{('flowchart','agentic'),('flowchart','elk')}")
swap("print('ER',j['er'],'INITIAL'", "print('FLOWCHART',j['flowchart'],'INITIAL'")
needle="assert isinstance(x['source'],str)and x['source']"
replacement="""assert isinstance(x['source'],str)and x['source']
  reference=json.loads(gzip.decompress(pathlib.Path('/tmp/pr449-week-comparison-20261101/requirement-cycle-25e/before-cyclic-labelled-9-chains.mmd-agentic.json.gz').read_bytes()))
  assert x['source']==reference['source'],'Exact original cyclic9 cold source required'
  assert x['options']=={'graphLayout':{'backend':x['backend'],'fallback':'none'},'embedFontImport':False},'Exact retained render options required'"""
swap(needle,replacement)
ast.parse(s)
if sys.argv[1:]==['--prepare']:
    print('AST_ONLY_READY HOLD: inherited canonical recipe; ONE RAM lazyJS build + graph closure measure-only report + TWO compiled cyclic9 Flowchart engine bindings against fresh current complete SVG/raw ENTIRE receipt source witnesses; 0 calls / 0 builds. Separate root GO required after source-cost adverse review.')
else:
    assert sys.argv[1:]==['--run'], 'Separate root payload GO required'
    assert os.environ.get('PR449_FINAL_SHA') and os.environ.get('PR449_BINDINGS_JSON'), 'Frozen candidate SHA and fresh two-binding JSON required'
    exec(compile(s, '<retained-flowchart-fit-two-binding-controller>', 'exec'))
