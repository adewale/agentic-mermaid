# Bounded parameter-only reuse of ER full-product worker + existing class128 Bun CPU-prof recipe.
import pathlib,os,sys,json,gzip,tempfile,shutil,subprocess
assert sys.argv[1:]==['--run'],'Explicit root profile GO required'
R=pathlib.Path('/tmp/pr449-main-integration-20261029-762');W=pathlib.Path('/tmp/pr449-week-comparison-20261101');H='3e43badc5ebd110df717273cf952cd4e3dd36142';O=W/'er-glyph-profile-3e43badc5';BUN='/tmp/pr449-bin/bun'
assert not (O/'RESULTS.json.gz').exists(),'Existing profile result; do not duplicate calls';O.mkdir(exist_ok=True)
E=dict(os.environ,PATH='/tmp/pr449-bin:'+os.environ['PATH'],GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',NODE_DISABLE_COMPILE_CACHE='1',AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0')
def git(*a):return subprocess.check_output(['git',*a],cwd=R,env=E,text=True).strip()
def frozen():
 assert git('rev-parse','HEAD')==H,'Frozen HEAD mismatch'
 assert not git('diff','--name-only','HEAD','--','src'),'Dirty source'
frozen();baseline=(R/'src/er/layout.ts').read_bytes();retained=json.loads(gzip.decompress((W/'er-prefix-cost-599bdf978/RESULTS.json.gz').read_bytes()))
worker=pathlib.Path('/tmp/pr449-er-prefix-cost-worker.ts').read_text();a=worker.index('Bun.plugin(');b=worker.index('const importStart',a);worker=worker[:a]+worker[b:];worker=worker.replace("[['cold', source], ['repeat', source], ['edit', edited]]","[['cold', source], ['repeat', source]]")
assert 'Bun.plugin'not in worker and "['edit', edited]"not in worker
(O/'worker.ts').write_text(worker)
j={'head':H,'calls':0,'runs':[],'errors':[],'scope':'Actual unchanged source before-target assessment; exactly8publicSVGcalls max ER208/ER32LR bothbackends cold+repeat cacheoff. FullSVG+ENTIRErawreceipt/errors fully consumed; stages/providers/import/peakRSS/postGC retained. Four fresh workers; CPUprofile includesimports/fullpaint/GC/harness/twoheldproducts. No changed producer, build, witnesses or aftercost. One sample per case/engine, no speed/allocation claim.'}
def gz(p,v):p.write_bytes(gzip.compress(v if isinstance(v,bytes)else json.dumps(v,separators=(',',':')).encode(),mtime=0))
def save():gz(O/'RESULTS.json.gz',j)
S=None
try:
 S=pathlib.Path(tempfile.mkdtemp(prefix='pr449-er-glyph-profile-',dir='/dev/shm'));E.update(TMPDIR=str(S),XDG_CACHE_HOME=str(S/'cache'),BUN_RUNTIME_TRANSPILER_CACHE_PATH=str(S/'bun-cache'))
 for n in [208,32]:
  source='erDiagram\ndirection LR\n'+'\n'.join(f'N{i} ||--o{{ N{i+1} : owns'for i in range(n-1));assert source==retained['cases'][str(n)]['source'];(S/(str(n)+'.mmd')).write_text(source)
 jobs=[(208,'agentic'),(208,'elk'),(32,'elk'),(32,'agentic')]
 for n,backend in jobs:
  frozen();tag=str(n)+'-'+backend;out=S/tag;options={'graphLayout':{'backend':backend,'fallback':'none'}};(S/'options.json').write_text(json.dumps(options));job={'root':str(R),'count':n,'backend':backend,'arm':'unchanged-before3e43','sourceFile':str(S/(str(n)+'.mmd')),'editFile':str(S/(str(n)+'.mmd')),'optionsFile':str(S/'options.json'),'out':str(out)};(S/'job.json').write_text(json.dumps(job))
  command=[BUN,'--cpu-prof','--cpu-prof-md','--cpu-prof-dir='+str(O),'--cpu-prof-name='+tag,str(O/'worker.ts'),str(S/'job.json')]
  p=subprocess.run(command,cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);actual=p.stdout.decode().count('ACTUAL_PUBLIC_CALL_START');j['calls']+=actual;gz(O/(tag+'-stdout-stderr.log.gz'),p.stdout+p.stderr);frozen();assert (R/'src/er/layout.ts').read_bytes()==baseline,'ER source changed during profile'
  if p.returncode:
   j['errors'].append({'tag':tag,'exitCode':p.returncode,'actualCallsObserved':actual,'stderr':p.stderr.decode()});save();break
  row=json.loads(gzip.decompress(pathlib.Path(str(out)+'.json.gz').read_bytes()));assert row['actualPublicCalls']==actual==2 and row['overlayLoads']==0;row['command']=command;row['profiles']=[str(x)for x in O.glob(tag+'*')if x.suffix in ['.cpuprofile','.md']]
  for phase in row['rows']:
   if phase['status']=='returned':
    svgName=f'{tag}-{phase["phase"]}.svg.gz';receiptName=f'{tag}-{phase["phase"]}.receipt.json.gz';gz(O/svgName,gzip.decompress(pathlib.Path(str(out)+'-'+phase['phase']+'.svg.gz').read_bytes()));gz(O/receiptName,phase['receiptJSON'].encode());phase['svgReference']=str(O/svgName);phase['receiptReference']=str(O/receiptName)
  j['runs'].append(row);save();print('WORKER',tag,'calls',actual,'elapsed',[round(x['elapsedMs'],2)for x in row['rows']],'proof',[x.get('proof',{}).get('status')for x in row['rows']],'peakRSSKiB',row['peakRssKiB'],'profiles',row['profiles'],flush=True)
  if any(x['status']=='refused'for x in row['rows']):j['errors'].append({'tag':tag,'stage':'public-family-refusal-stop'});save();break
 j['sourceUnchanged']=(R/'src/er/layout.ts').read_bytes()==baseline;j['completed']=j['calls']==8 and len(j['runs'])==4 and not j['errors']and j['sourceUnchanged']
except Exception as e:j['error']=repr(e);j['completed']=False
finally:
 if S:shutil.rmtree(S)
 j['ramRemoved']=S is None or not S.exists();save();print('FINAL',json.dumps({k:j.get(k)for k in ['completed','calls','errors','error','sourceUnchanged','ramRemoved']}),flush=True)
