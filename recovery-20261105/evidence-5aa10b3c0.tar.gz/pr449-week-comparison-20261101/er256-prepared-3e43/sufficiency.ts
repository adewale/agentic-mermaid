import { plugin } from 'bun'
import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const repo='/tmp/pr449-main-integration-20261029-762', dir='/tmp/pr449-week-comparison-20261101/er256-prepared-3e43'
plugin({name:'NONSHIPPING stable-body capacity sufficiency',setup(build){build.onLoad({filter:/\/src\/er\/layout\.ts$/},args=>{
 let code=readFileSync(args.path,'utf8')
 const anchor='  // Strict body/header interiors apply to every raw segment, including an'
 code=code.replace(anchor,`  // NONSHIPPING: assume stable actual final body custody, solely capacity sufficiency.
  const probeBodies = positioned.entities.map(entity => {
    const authored = Number.parseFloat(entity.inlineStyle?.['stroke-width'] ?? '')
    const half = (Number.isFinite(authored) && authored > 0 ? authored : style.nodeLineWidth) / 2
    return { entity, half, box: {x0:entity.x-half,y0:entity.y-half,x1:entity.x+entity.width+half,y1:entity.y+entity.height+half} }
  })
  charge(probeBodies.length)
  const probeQuery = erInkIndex(probeBodies, row=>row.box, charge, allShafts.length * 2)
`+anchor)
 const raw='    for (const entity of positioned.entities) {\n      charge()\n      if (segmentThroughShape'
 if(!code.includes(raw))throw Error('raw anchor absent')
 code=code.replace(raw,`    const pa=rel.points[i-1]!, pb=rel.points[i]!
    for (const {entity} of probeQuery({x0:Math.min(pa.x,pb.x)-1e-6,y0:Math.min(pa.y,pb.y)-1e-6,x1:Math.max(pa.x,pb.x)+1e-6,y1:Math.max(pa.y,pb.y)+1e-6})) {
      charge()
      if (segmentThroughShape`)
 const painted=`    for (const entity of positioned.entities) {
      const authored = Number.parseFloat(entity.inlineStyle?.['stroke-width'] ?? '')
      const half = (Number.isFinite(authored) && authored > 0 ? authored : style.nodeLineWidth) / 2
      const box = { x0: entity.x - half, y0: entity.y - half, x1: entity.x + entity.width + half, y1: entity.y + entity.height + half }
      if (intersects(shaft.box, box)`
 if(!code.includes(painted))throw Error('painted anchor absent')
 code=code.replace(painted,`    for (const {entity, half, box} of probeQuery(shaft.box)) {
      if (intersects(shaft.box, box)`)
 writeFileSync(dir+'/NONSHIPPING-layout.ts',code)
 return {contents:code,loader:'ts'}
})}})
const {renderMermaidSVGWithReceipt}=await import(repo+'/src/index.ts')
const source='erDiagram\ndirection LR\n'+Array.from({length:255},(_,i)=>`N${i} ||--o{ N${i+1} : owns`).join('\n')
for(const backend of ['elk','agentic'] as const){
 const options={graphLayout:{backend,fallback:'none' as const},embedFontImport:false}
 try {const rendered=renderMermaidSVGWithReceipt(source,options); writeFileSync(`${dir}/NONSHIPPING-${backend}.json.gz`,gzipSync(JSON.stringify({source,options,...rendered})));console.log(JSON.stringify({backend,status:'returned',svgBytes:Buffer.byteLength(rendered.svg),receipt:rendered.receipt}))}
 catch(error){console.log(JSON.stringify({backend,status:'refused',error:{name:error.name,message:error.message,code:error.code,stack:error.stack,cause:error.cause}}))}
}
