// HOLD: root must explicitly invoke GO. Exactly one public SVG call; no layout call.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import { gzipSync, gunzipSync } from 'node:zlib'
const root = '/tmp/pr449-main-integration-20261029-762'
const dir = '/tmp/pr449-week-comparison-20261101/cyclic9-requalification-954248001'
if (process.argv[2] !== 'GO') throw new Error('HOLD: explicit root GO required')
const before = JSON.parse(gunzipSync(fs.readFileSync('/tmp/pr449-week-comparison-20261101/flow-fit-precleanup-7a8c58917/after.json.gz')).toString())
const source = before.source as string
assert.equal(source, fs.readFileSync(`${root}/eval/layout-compare/fixtures/cyclic-labelled-9-chains.mmd`, 'utf8'))
const options = { graphLayout: { backend: 'agentic' as const, fallback: 'none' as const }, embedFontImport: false, idPrefix: 'cycle-check-' }
process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS = '0'
process.env.AGENTIC_MERMAID_ELK_CACHE = '0'
const { renderMermaidSVGWithReceipt } = await import(`${root}/src/index.ts`)
let packet: unknown
try {
  const product = renderMermaidSVGWithReceipt(source, options)
  fs.writeFileSync(`${dir}/after.svg.gz`, gzipSync(product.svg))
  fs.writeFileSync(`${dir}/after.receipt.json.gz`, gzipSync(JSON.stringify(product.receipt)))
  packet = { runtimeRevision: '9542480016e8a203659b413e2024a891da0e3271', coordinationHead: 'ee7136474', source, options, actualPublicSvgCalls: 1, publicLayoutCalls: 0, product, oldWholeSvgEqual: product.svg === before.svg, oldEntireReceiptEqual: JSON.stringify(product.receipt) === JSON.stringify(before.svgReceipt) }
} catch (error) {
  packet = { source, options, actualPublicSvgCalls: 1, publicLayoutCalls: 0, error: { name: error.name, message: error.message, code: error.code, stack: error.stack } }
  process.exitCode = 1
}
const bytes = JSON.stringify(packet)
fs.writeFileSync(`${dir}/RESULT.json.gz`, gzipSync(bytes))
console.log(bytes)
