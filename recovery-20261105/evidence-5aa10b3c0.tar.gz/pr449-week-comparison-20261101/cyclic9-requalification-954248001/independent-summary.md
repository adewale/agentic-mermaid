Affected cyclic9 requalification at runtime954248001 / coordinationhead ee7136474

Root made exactly two public SVG calls (Agentic + matching ELK), zero layout calls, and four Agentic-only offline rasters. Both current arms use the exact retained source and cycle-check- prefix, fallback none and embedFontImport false; only backend differs. Old products remain unchanged. The old Agentic reference is the dated flow-fit-precleanup/after packet; it does not carry a complete-runtime revision and is not falsely treated as an exactfff full-head capture.

Actual SVG checks retain nine authored names/types, all23 ordered source/target occurrences (including duplicates) and six owned captions in both current arms. All23 target references point at the actual arrow resource. These are fixed-source correspondence observations, not a global visual-meaning qualification.

| Actual final SVG | Area px² | Written wire px | Turns | Distinct target tips | Public paint proof |
|---|---:|---:|---:|---:|---|
| Dated Agentic |668671.5759|10804.272154|36|22|P271105/400000;23markers|
| Current Agentic |668671.5759|10783.122154|36|23|P266980/400000;23markers|
| Current ELK |669058.282229|11585.584647|54|22|P267160/400000;23markers|

Current Agentic area/turns equal the dated result; wire falls21.15px (-0.196%). Against matching current ELK, area is0.0578% smaller, wire6.9264% shorter and turns18 fewer. These fixed-case vectors do not establish broader backend preference. The current ELK vectors equal the retained ELK metrics; its public proof above is newly captured at the current runtime.

Five Agentic carrier point attributes change versus the dated SVG; names/cards/captions are retained. Whole SVG and entire receipt differ. Entire-receipt differences are graphicalProjectionDigest, layoutCertification outputDigest, operations271105→266980 and occlusionPairs349→355. The dated runtime spans other fixes, so the operation difference is not attributed solely to route preservation.

The two previously ambiguous source occurrences now have distinct actual tips: edge:n3->n6#0 stays(998.69,170.35); edge:n5->n6#0 moves to(998.69,152.9). Existing pinned-Inter raster controls show123/122 individually attributable darker pixels, with zero differential outside their respective head ROIs. All23 all-head-mask ROIs contain positive ink;6 shared-ROI pixels remain, with0unattributed and0outside-viewport changes. Do not turn shared ROI attribution into missing authored meaning. This requalifies an affected old ambiguity after the already-shipped guard; it is not a new repair or test.

Normal-contact qualification is unavailable from an existing retained owning layout/checker, so no full normal-contact qualification is claimed. An optional strict actual-outline diagnostic found46/46 Agentic contacts and45/46 ELK at1e-6 tolerance. The ELK exception is only0.023px off a rounded rect nominal outline and within its0.375px painted halfstroke; it is not established as a contract/visible failure and must not become a new zero-tolerance gate. Details remain in independent-summary.json. No ELK raster, universal font/browser, original-baseline, timing or capacity-family closure claim.
