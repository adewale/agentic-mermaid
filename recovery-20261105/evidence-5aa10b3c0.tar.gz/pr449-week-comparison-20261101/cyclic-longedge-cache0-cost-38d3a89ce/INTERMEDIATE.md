# Intermediate evidence

These completed measurements and local counters describe the saved array variant.
An inherited numeric-setter gap was subsequently found. The pending safety fix
has not been measured by these calls. No final safety or performance claim.

Original RESULTS, literal before/current module copies and candidate.patch.gz
remain unmodified. Hold all calls/adapters until the final freeze and root GO.
