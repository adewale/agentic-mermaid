// NONSHIPPING optimistic sufficiency probe. Unsafe singleton custody; never production proof.
import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import assert from 'node:assert/strict'
const root = '/tmp/pr449-main-integration-20261029-762'
const retained = '/tmp/pr449-week-comparison-20261101/native-group-plain-prototype-9f519'
const out = '/tmp/pr449-week-comparison-20261101/native-group-cyclic19-b063'
const names = ['native-paint-emission.ts', 'emission-context.ts', 'group-emission.ts']
const bases = names.map(name => {
 const current = readFileSync(root + '/src/scene/' + name)
 const original = readFileSync(retained + '/' + name + '.original.ts')
 assert.deepEqual(current, original, name + ' base bytes')
 return { name, byteIdentical: true, bytes: current.length }
})
writeFileSync(out + '/setup.json', JSON.stringify({ root, head: 'b0633fab9412621efdb50e7effd5c269a75d6728', bases, publicSVGCalls: 0 }, null, 2))
const loaded: string[] = []
Bun.plugin({ name: 'retained-nonshipping-three-module-group-prototype', setup(build) {
 build.onLoad({filter: /\/src\/scene\/(group-emission|emission-context|native-paint-emission)\.ts$/}, args => {
  const name = args.path.split('/').at(-1)!
  assert.ok(names.includes(name))
  assert.deepEqual(readFileSync(args.path), readFileSync(retained + '/' + name + '.original.ts'))
  loaded.push(name)
  return { contents: readFileSync(retained + '/' + name + '.prototype.ts', 'utf8'), loader: 'ts' }
 })
}})
let calls = 0
try {
 const baseline = JSON.parse(gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/cyclic15-19-b063/current-cyclic-labelled-19.mmd-agentic.json.gz')).toString())
 const source = readFileSync(root + '/eval/layout-compare/fixtures/cyclic-labelled-19.mmd', 'utf8')
 assert.equal(source, baseline.source)
 const options = { graphLayout: { backend: 'agentic' as const, fallback: 'none' as const }, embedFontImport: false }
 const { renderMermaidSVGWithReceipt } = await import(root + '/src/index.ts')
 assert.deepEqual([...loaded].sort(), [...names].sort())
 ;(globalThis as any).__plainGroupStats = { issued: 0, reused: 0, fallback: 0, retentionPaid: 0, bindingPaid: 0 }
 ;(globalThis as any).__plainLastGroupParse = undefined
 ;(globalThis as any).__plainFirstExhaustion = undefined
 calls++
 const result = renderMermaidSVGWithReceipt(source, options)
 const serialized = JSON.stringify(result)
 let sum = 0
 for (let i = 0; i < serialized.length; i++) sum += serialized.charCodeAt(i)
 const record = { scope: 'NONSHIPPING optimistic sufficiency only: retained unsafe singleton parse handoff; incomplete new allocation accounting; not a qualified proof or capacity closure.', source, options, publicSVGCalls: calls, publicLayoutCalls: 0, bases, loaded, result, stats: (globalThis as any).__plainGroupStats, firstExhaustion: (globalThis as any).__plainFirstExhaustion ?? null, byteExactSVG: result.svg === baseline.svg, consumed: { utf16Units: serialized.length, utf8Bytes: Buffer.byteLength(serialized), sum }, priorProof: baseline.svgReceipt.layoutCertification }
 writeFileSync(out + '/result.json.gz', gzipSync(JSON.stringify(record)))
 writeFileSync(out + '/raw-receipt.json.gz', gzipSync(JSON.stringify(result.receipt)))
 writeFileSync(out + '/actual.svg.gz', gzipSync(result.svg))
 const summary = { scope: record.scope, publicSVGCalls: calls, publicLayoutCalls: 0, bases, loaded, proof: result.receipt.layoutCertification, stats: record.stats, firstExhaustion: record.firstExhaustion, byteExactSVG: record.byteExactSVG, consumed: record.consumed }
 writeFileSync(out + '/SUMMARY.json', JSON.stringify(summary, null, 2))
 console.log(JSON.stringify(summary))
} catch (error) {
 const failure = { publicSVGCalls: calls, publicLayoutCalls: 0, loaded, error: { name: (error as Error).name, message: (error as Error).message, stack: (error as Error).stack } }
 writeFileSync(out + '/FAILURE.json', JSON.stringify(failure, null, 2))
 console.log(JSON.stringify(failure))
 process.exitCode = 1
}
