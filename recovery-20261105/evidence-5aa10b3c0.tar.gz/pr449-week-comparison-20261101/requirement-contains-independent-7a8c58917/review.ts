import fs from 'node:fs'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {gzipSync,gunzipSync} from 'node:zlib'
import {createRequire} from 'node:module'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const {JSDOM}=createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/requirement-contains-independent-7a8c58917'
const entries=JSON.parse(fs.readFileSync(process.argv[2],'utf8'))
const save=(name,value)=>fs.writeFileSync(`${out}/${name}.gz`,gzipSync(typeof value==='string'||value instanceof Uint8Array?value:JSON.stringify(value,null,2)))
const attrs=e=>Object.fromEntries([...e.attributes].map(a=>[a.name,a.value]))
const near=(a,b)=>Math.abs(a-b)<1e-6
const scratch=fs.mkdtempSync('/tmp/pr449-contains-fonts-')
try {
 const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter'),fontFiles=fonts.map(f=>{const b=fs.readFileSync(`${root}/${f.path}`);assert.equal(b.length,f.bytes);assert.equal(createHash('sha256').update(b).digest('hex'),f.sha256);const p=`${scratch}/${f.file}`;fs.writeFileSync(p,b);return p})
 const vectors=[],rasters=[],seen=new Map()
 for(const entry of entries){
  const raw=entry.path.endsWith('.gz')?gunzipSync(fs.readFileSync(entry.path)).toString():fs.readFileSync(entry.path,'utf8')
  const dom=new JSDOM(raw,{contentType:'image/svg+xml'}),d=dom.window.document
  try {
   const carriers=[...d.querySelectorAll('[data-role="relationship"][data-from]')],contains=carriers.filter(c=>c.getAttribute('data-relationship')==='contains')
   assert.equal(contains.length,1)
   const carrier=contains[0],ca=attrs(carrier)
   assert.equal(ca['data-from'],entry.from);assert.equal(ca['data-to'],entry.to);assert.equal(ca['data-direction'],'forward')
   assert(!carrier.hasAttribute('marker-end'));assert(!carrier.hasAttribute('stroke-dasharray'))
   const id=/^url\(#([^)]*)\)$/.exec(ca['marker-start'])?.[1];assert(id)
   const marker=d.getElementById(id);assert(marker);const ma=attrs(marker)
   assert.equal(marker.tagName,'marker');assert.equal(ma.orient,'auto');assert.equal(ma.markerUnits,'userSpaceOnUse');assert.equal(+ma.refX,0);assert.equal(+ma.refY,6);assert.equal(+ma.markerWidth,12);assert.equal(+ma.markerHeight,12)
   const circles=[...marker.querySelectorAll('circle')],paths=[...marker.querySelectorAll('path')];assert.equal(circles.length,1);assert.equal(paths.length,1)
   const circle=attrs(circles[0]),cross=attrs(paths[0]);assert.equal(+circle.cx,6);assert.equal(+circle.cy,6);assert.equal(+circle.r,5);assert.equal(cross.d.replaceAll(' ',''),'M26H10M62V10')
   const pts=ca.points?.trim().split(/\s+/).map(p=>p.split(',').map(Number));assert(pts&&pts.length>=2)
   const [p,q]=pts,dx=q[0]-p[0],dy=q[1]-p[1],length=Math.hypot(dx,dy);assert(length>0);assert(dx===0||dy===0)
   const source=[...d.querySelectorAll('g.requirement-node')].find(n=>n.getAttribute('data-id')===entry.from)?.querySelector('rect');assert(source)
   const box=attrs(source),x=+box.x,y=+box.y,w=+box.width,h=+box.height
   const normal=dy===0&&p[1]>y&&p[1]<y+h&&(near(p[0],x)&&dx<0||near(p[0],x+w)&&dx>0)||dx===0&&p[0]>x&&p[0]<x+w&&(near(p[1],y)&&dy<0||near(p[1],y+h)&&dy>0);assert(normal)
   const target=[...d.querySelectorAll('g.requirement-node')].find(n=>n.getAttribute('data-id')===entry.to)?.querySelector('rect');assert(target);const tb=attrs(target),tx=+tb.x,ty=+tb.y,tw=+tb.width,th=+tb.height,e=pts.at(-1),before=pts.at(-2),edx=before[0]-e[0],edy=before[1]-e[1];const targetNormal=edy===0&&e[1]>ty&&e[1]<ty+th&&(near(e[0],tx)&&edx<0||near(e[0],tx+tw)&&edx>0)||edx===0&&e[0]>tx&&e[0]<tx+tw&&(near(e[1],ty)&&edy<0||near(e[1],ty+th)&&edy>0);assert(targetNormal);const ux=dx/length,uy=dy/length,cx=p[0]+6*ux,cy=p[1]+6*uy,roi={x0:cx-6.5,y0:cy-6.5,x1:cx+6.5,y1:cy+6.5}
   const caption=[...d.querySelectorAll('g.requirement-edge-label')].find(g=>g.getAttribute('data-edge-id')===ca['data-id']);assert(caption);assert.equal(caption.querySelector('text')?.textContent,'<<contains>>')
   vectors.push({...entry,carrier:ca,marker:ma,circle,cross,sourceFrame:box,start:p,next:q,sourceNormal:true,targetNormal:true,targetFrame:tb,end:e,beforeEnd:before,worldMarkerCenter:[cx,cy],worldMarkerReference:p,resourceRoi:roi})
   const digest=createHash('sha256').update(raw).digest('hex')
   if(seen.has(digest)){rasters.push({name:entry.name,byteIdenticalTo:seen.get(digest)});continue}seen.set(digest,entry.name)
   const outer=attrs(d.documentElement),width=+outer.width,height=+outer.height,margin=10,ew=width+20,eh=height+20,zoom=3
   const expanded=raw.replace(/width="[^"]+"/,`width="${ew}"`).replace(/height="[^"]+"/,`height="${eh}"`).replace(/viewBox="[^"]+"/,`viewBox="-10 -10 ${ew} ${eh}"`)
   const markerXml=marker.outerHTML,circleXml=circles[0].outerHTML,pathXml=paths[0].outerHTML
   const markerStart=raw.indexOf('<marker',raw.indexOf(`id="${id}"`)-10),markerEnd=raw.indexOf('</marker>',markerStart)+9
   assert(markerStart>=0&&markerEnd>markerStart)
   const actualMarker=raw.slice(markerStart,markerEnd)
   const circleMatch=actualMarker.match(/<circle\b[^>]*\/>/)?.[0],crossMatch=actualMarker.match(/<path\b[^>]*\/>/)?.[0];assert(circleMatch&&crossMatch)
   const variants={full:expanded,circle:expanded.replace(actualMarker,actualMarker.replace(circleMatch,'')),horizontal:expanded.replace(actualMarker,actualMarker.replace(crossMatch,crossMatch.replace(/d="[^"]+"/,'d="M6 2V10"'))),vertical:expanded.replace(actualMarker,actualMarker.replace(crossMatch,crossMatch.replace(/d="[^"]+"/,'d="M2 6H10"')))}
   const images={}
   for(const [kind,svg] of Object.entries(variants)){const r=new Resvg(inlineFontVarForRaster(svg),{background:'#ffffff',fitTo:{mode:'zoom',value:zoom},font:{fontFiles,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();images[kind]={width:r.width,height:r.height,pixels:r.pixels};save(`${entry.name}-${kind}.svg`,svg);save(`${entry.name}-${kind}.png`,r.asPng())}
   const full=images.full,controls=[]
   for(const kind of ['circle','horizontal','vertical']){const mask=images[kind];assert.equal(full.width,mask.width);assert.equal(full.height,mask.height);let changed=0,darker=0,lighter=0,outsideRoi=0,outsideViewport=0
    for(let py=0;py<full.height;py++)for(let px=0;px<full.width;px++){const i=(py*full.width+px)*4;if(![0,1,2,3].some(k=>Math.abs(full.pixels[i+k]-mask.pixels[i+k])>=4))continue;changed++;const wx=(px+.5)/zoom-margin,wy=(py+.5)/zoom-margin;if(wx<roi.x0||wx>roi.x1||wy<roi.y0||wy>roi.y1)outsideRoi++;if(wx<0||wx>width||wy<0||wy>height)outsideViewport++;if(full.pixels[i]+full.pixels[i+1]+full.pixels[i+2]<mask.pixels[i]+mask.pixels[i+1]+mask.pixels[i+2])darker++;else lighter++}
    controls.push({kind,changed,darker,lighter,outsideRoi,outsideViewport,observation:darker>0&&outsideRoi===0&&outsideViewport===0?'positive owned component ink':'zero or ambiguous component ink; requires review'})
   }
   rasters.push({name:entry.name,source:entry.path,svgSha256:digest,raster:[full.width,full.height],controls})
  }finally{dom.window.close()}
 }
 const report={publicCalls:0,offlineRasterCalls:seen.size*4,vectors,rasters,fonts:fonts.map(f=>({file:f.file,bytes:f.bytes,sha256:f.sha256})),scope:'Exact saved owning-run SVGs: authored contains endpoints/caption, source normal, explicit start marker resource reference/orientation and circle/cross component differential ink. Offline pinned-Inter raster controls only; no complete Native paint, universal font, browser or family capacity claim.'}
 save('review.json',report);console.log(JSON.stringify({...report,vectors:vectors.map(v=>({name:v.name,from:v.from,to:v.to,start:v.start,worldMarkerCenter:v.worldMarkerCenter,sourceNormal:v.sourceNormal})),fonts:undefined}))
}finally{fs.rmSync(scratch,{recursive:true,force:true})}
