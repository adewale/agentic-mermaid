import { readFileSync, writeFileSync, writeSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import { createHash } from 'node:crypto'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/class-ledger-f1e/'+process.argv[2]
const direction=process.argv[2]
if(!['TB','LR'].includes(direction))throw new Error('Expected TB or LR; no calls started')
let overlayLoads: string[]=[]
Bun.plugin({name:'class-ledger-observation-only',setup(build){
 build.onLoad({filter:/\/src\/scene\/(paint-certification|serialization)\.ts$/},args=>{
  if(!args.path.startsWith(root+'/src/scene/'))return
  const name=args.path.endsWith('/serialization.ts')?'serialization':'paint-certification'
  overlayLoads.push(name)
  return {contents:readFileSync(out+'/../'+name+'.instrumented.ts','utf8'),loader:'ts'}
 })
}})
const wallStart=performance.now(),cpuStart=process.cpuUsage()
const log=(value:unknown)=>writeSync(1,JSON.stringify(value)+'\n')
log({event:'IMPORT_START',memory:process.memoryUsage(),cpu:process.cpuUsage()})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const {withRenderStageObserver}=await import(root+'/src/render-stages.ts')
const {withPerformanceObserver}=await import(root+'/src/performance-observations.ts')
const {apiFailure}=await import(root+'/eval/layout-compare/outcomes.ts')
const importMs=performance.now()-wallStart,importCPU=process.cpuUsage(cpuStart)
const source='classDiagram\ndirection '+direction+'\n'+Array.from({length:127},(_,i)=>`N${i} --> N${i+1}`).join('\n')
const options={graphLayout:{backend:'agentic' as const,fallback:'none' as const},embedFontImport:false}
const stages:any[]=[],events:any[]=[]
const before=process.memoryUsage(),renderCPU=process.cpuUsage(),renderStart=performance.now()
let product:any,row:any
log({event:'ACTUAL_PUBLIC_CALL_START',actualCalls:1,importMs,importCPU,before})
try{
 const artifact=withPerformanceObserver(event=>events.push(event),()=>withRenderStageObserver(stage=>{stages.push(stage);log({event:'STAGE_COMPLETE',...stage})},()=>renderMermaidSVGWithReceipt(source,options)))
 product={svg:artifact.svg,receipt:artifact.receipt}
 const bytes=Buffer.from(JSON.stringify(product));let checksum=0
 for(const byte of bytes)checksum=(Math.imul(checksum,31)+byte)>>>0
 const baseline=direction==='TB'?'/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/TB':'/tmp/pr449-week-comparison-20261101/class-scene-cache0-cost-539407810/class128LR-agentic-after-cold'
 const historical={svg:gunzipSync(readFileSync(baseline+'.svg.gz')).toString(),receipt:gunzipSync(readFileSync(baseline+'.receipt.json.gz')).toString()}
 writeFileSync(out+'/TB.svg.gz',gzipSync(product.svg));writeFileSync(out+'/TB.receipt.json.gz',gzipSync(JSON.stringify(product.receipt)))
 row={status:'returned',fullyConsumedBytes:bytes.length,checksum,svgSha256:createHash('sha256').update(product.svg).digest('hex'),wholeSVGExactToSaved:product.svg===historical.svg,entireRawReceiptBytesExactToSaved:JSON.stringify(product.receipt)===historical.receipt,proof:product.receipt.layoutCertification}
}catch(error:any){
 product={normalized:apiFailure(error),name:error?.name,message:error?.message,code:error?.code,stack:error?.stack,cause:error?.cause?{name:error.cause.name,message:error.cause.message,stack:error.cause.stack}:undefined,certification:error?.certification}
 const bytes=Buffer.from(JSON.stringify(product));row={status:'refused',fullyConsumedErrorBytes:bytes.length,failure:product}
}
const {readObservedPaintLedgers}=await import(root+'/src/scene/paint-certification.ts')
const {readObservedSceneWriteLedgers}=await import(root+'/src/scene/serialization.ts')
const report={direction,overlayLoads,paintLedgers:readObservedPaintLedgers(),sceneWriteLedgers:readObservedSceneWriteLedgers(),actualPublicCalls:1,source,options,importMs,importCPU,renderWallMs:performance.now()-renderStart,renderCPU:process.cpuUsage(renderCPU),totalWallMs:performance.now()-wallStart,totalCPU:process.cpuUsage(cpuStart),loadedMemory:before,afterMemory:process.memoryUsage(),peakRssKiB:process.resourceUsage().maxRSS,row,provider:events.filter(e=>e.owner==='paint-certification'),stages,events,product}
writeFileSync(out+'/RESULT.json.gz',gzipSync(JSON.stringify(report)))
log({event:'ACTUAL_PUBLIC_CALL_COMPLETE',...report,product:undefined,events:undefined})
