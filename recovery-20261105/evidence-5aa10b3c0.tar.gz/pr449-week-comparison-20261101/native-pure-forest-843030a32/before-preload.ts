import fs from 'node:fs'
Bun.plugin({name:'native-follows-legacy-forest-before',setup(build){build.onLoad({filter:/\/src\/layout\/agentic-layered\.lazy\.ts$/},()=>({contents:fs.readFileSync('/tmp/pr449-week-comparison-20261101/native-pure-forest-843030a32/agentic-layered.lazy.before.ts','utf8'),loader:'ts'}))}})
