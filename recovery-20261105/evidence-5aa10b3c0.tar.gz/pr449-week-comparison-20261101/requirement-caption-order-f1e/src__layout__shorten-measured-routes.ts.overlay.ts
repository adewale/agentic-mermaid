import type { AgenticLayout, MeasuredGraph } from './agentic-layered-core.ts'
import type { Point } from '../types.ts'
import { countPolylineCrossings } from '../shared/edge-crossings.ts'
import { type MeasuredBox, segmentEntersMeasuredBox, pointOnMeasuredSegment, measuredBoxesOverlap, scoreMeasuredRouteCrossings } from './measured-route-safety.ts'

function simplify(points: readonly Point[]): Point[] {
  const result: Point[] = []
  for (const point of points) {
    const last = result.at(-1), previous = result.at(-2)
    if (last?.x === point.x && last.y === point.y) continue
    if (previous && last && ((previous.x === last.x && last.x === point.x && (last.y - previous.y) * (point.y - last.y) >= 0)
      || (previous.y === last.y && last.y === point.y && (last.x - previous.x) * (point.x - last.x) >= 0))) result.pop()
    result.push(point)
  }
  return result
}

/** Shortcuts operate only on a completed measured graph. They retain endpoint
 * rays, clear every occupied box, and cannot increase any
 * crossing counts or introduce a shared shaft. Exhaustion leaves feasible routes intact. */
export function shortenMeasuredRoutes(input: MeasuredGraph, placed: AgenticLayout): AgenticLayout {
  if (placed.topology === 'forest' || placed.sharedEdges?.length || input.edges.length > 128
    || placed.edges.reduce((sum, edge) => sum + edge.points.length, 0) > 2048) return placed
  const boxes: MeasuredBox[] = input.nodes.map((node, index) => ({ ...placed.nodes[index]!, width: node.width, height: node.height }))
  const headers = (placed.groups ?? []).map((group, index) => ({ ...group, height: input.groups![index]!.padding.top }))
  const labels = input.edges.map((edge, index) => {
    const p = placed.edges[index]!.labelPosition
    return edge.label && p ? { x: p.x - edge.label.width / 2 - 2, y: p.y - edge.label.height / 2 - 2,
      width: edge.label.width + 4, height: edge.label.height + 4 } : undefined
  })
  const ink = placed.edges.map((edge, index) => ({ points: edge.points, source: String(input.edges[index]!.source), target: String(input.edges[index]!.target),
    style: input.edges[index]!.visible === false ? 'invisible' as const : 'solid' as const }))
  const visibleRoutes = () => ink.map(edge => ({ points: edge.points, visible: edge.style !== 'invisible' }))
  const length = (points: readonly Point[]): number => points.slice(1).reduce((sum, point, index) => sum + Math.abs(point.x - points[index]!.x) + Math.abs(point.y - points[index]!.y), 0)
  const ray = (a: Point, b: Point): string => `${Math.sign(b.x - a.x)},${Math.sign(b.y - a.y)}`
  let attempts = 512, comparisons = 8_000_000
  const chargeContact = (amount: number): boolean => (comparisons -= amount) >= 0
  for (const [index, edge] of input.edges.entries()) {
    if (placed.boundaryRoutes?.includes(index)) continue
    if (edge.source === edge.target || edge.visible === false || ink[index]!.points.length < 5) continue
    let localAttempts = 24
    const occupied = [...boxes, ...headers, ...labels.filter((box, other): box is MeasuredBox => Boolean(box) && other !== index)]
    const involved = new Set([index])
    let crossings: number | undefined
    for (let edit = 0; edit < 4; edit++) {
      const original = ink[index]!.points, anchor = placed.edges[index]!.labelPosition
      const points = [...original]
      let split = -1
      if (anchor) {
        split = points.findIndex(point => point.x === anchor.x && point.y === anchor.y)
        if (split < 0) for (let cursor = 1; cursor < points.length; cursor++) {
          if (pointOnMeasuredSegment(anchor, points[cursor - 1]!, points[cursor]!)) { split = cursor; points.splice(cursor, 0, { ...anchor }); break }
        }
        if (split < 0) break
      }
      const ranges = [[0, points.length - 1], ...(split > 0 && split < points.length - 1 ? [[0, split], [split, points.length - 1]] : [])]
      let changed = false
      search: for (const [lo, hi] of ranges) for (let first = lo!; first + 2 < hi!; first++) {
        for (let last = hi!; last > first + 2; last--) for (const horizontalFirst of [false, true]) {
          comparisons -= points.length
          if (comparisons < 0) return placed
          const a = points[first]!, b = points[last]!
          const corner = horizontalFirst ? { x: b.x, y: a.y } : { x: a.x, y: b.y }
          const candidate = simplify([...points.slice(0, first + 1), corner, ...points.slice(last)])
          if (candidate.length >= original.length || length(candidate) > length(original) + 1e-7
            || ray(candidate[0]!, candidate[1]!) !== ray(original[0]!, original[1]!)
            || ray(candidate.at(-2)!, candidate.at(-1)!) !== ray(original.at(-2)!, original.at(-1)!)) continue
          comparisons -= candidate.length * occupied.length
          if (comparisons < 0) return placed
          if (candidate.slice(1).some((point, cursor) => occupied.some(box => segmentEntersMeasuredBox(candidate[cursor]!, point, box)))) continue
          comparisons -= candidate.length * ink.reduce((sum, route) => sum + route.points.length, 0)
          if (comparisons < 0) return placed
          const count = ink.reduce((sum, route) => sum + route.points.length, 0)
          if (localAttempts-- <= 0) break search
          if (attempts-- <= 0) return placed
          comparisons -= count * count
          if (comparisons < 0) return placed
          const nextCrossings = scoreMeasuredRouteCrossings(candidate, index, ink, input, chargeContact, chargeContact)
          if (comparisons < 0) return placed
          if (nextCrossings === undefined) continue
          let labelPosition = anchor, labelBox = labels[index]
          if (anchor && edge.label && !candidate.slice(1).some((point, cursor) => pointOnMeasuredSegment(anchor, candidate[cursor]!, point))) {
            const positions: Point[] = []
            for (let cursor = 1; cursor < candidate.length; cursor++) {
              const a = candidate[cursor - 1]!, b = candidate[cursor]!, horizontal = a.y === b.y
              const half = (horizontal ? edge.label.width : edge.label.height) / 2 + 2
              const lo = Math.min(horizontal ? a.x : a.y, horizontal ? b.x : b.y) + half
              const hi = Math.max(horizontal ? a.x : a.y, horizontal ? b.x : b.y) - half
              if (lo > hi) continue
              const coord = Math.max(lo, Math.min(hi, horizontal ? anchor.x : anchor.y))
              positions.push(horizontal ? { x: coord, y: a.y } : { x: a.x, y: coord })
              positions.push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 })
            }
            positions.sort((a, b) => Math.abs(a.x - anchor.x) + Math.abs(a.y - anchor.y) - Math.abs(b.x - anchor.x) - Math.abs(b.y - anchor.y))
            labelPosition = undefined
            for (const p of positions) {
              const box = { x: p.x - edge.label.width / 2 - 2, y: p.y - edge.label.height / 2 - 2,
                width: edge.label.width + 4, height: edge.label.height + 4 }
              comparisons -= occupied.length + ink.reduce((sum, route) => sum + route.points.length, 0)
              if (comparisons < 0) return placed
              if (box.x < 0 || box.y < 0 || box.x + box.width > placed.width || box.y + box.height > placed.height
                || occupied.some(other => measuredBoxesOverlap(box, other))) continue
              if (ink.some((route, other) => other !== index && route.style !== 'invisible'
                && route.points.slice(1).some((point, cursor) => segmentEntersMeasuredBox(route.points[cursor]!, point, box)))) continue
              labelPosition = p; labelBox = box
              break
            }
            if (!labelPosition) continue
          }
          crossings ??= countPolylineCrossings(visibleRoutes(), involved)
          ink[index]!.points = candidate
          if (nextCrossings > crossings) { ink[index]!.points = original; continue }
          placed.edges[index]!.points = candidate
          if (labelPosition) placed.edges[index]!.labelPosition = { ...labelPosition }
          labels[index] = labelBox
          crossings = nextCrossings
          changed = true
          break search
        }
      }
      if (!changed) break
    }
  }
  // A caption can retain its carrier yet unnecessarily extend the fitted
  // canvas. Try the existing lane fractions without changing any route.
  if (input.groups?.length || input.nodes.length > 256 || !input.nodes.length) return placed
  const ownValue = (value: object, key: string) => { const d = Object.getOwnPropertyDescriptor(value, key); return d && Object.hasOwn(d, 'value') ? d.value : undefined }
  const stroke = ownValue(input, 'maximumEdgeStrokeWidth')
  if (ownValue(input, 'maximumEdgeBendRadius') !== 0 || !Number.isFinite(stroke) || stroke <= 0) return placed
  comparisons -= 4 * input.nodes.length + 3 * input.edges.length
  if (comparisons < 0) return placed
  const bodies: MeasuredBox[] = []
  for (const [index, node] of input.nodes.entries()) {
    const half = ownValue(node, 'paintStrokeWidth') / 2, box = boxes[index]!
    if (!Number.isFinite(half) || half < 0) return placed
    if (!Number.isFinite(boxes[index]!.width) || !Number.isFinite(boxes[index]!.height) || boxes[index]!.width < 0 || boxes[index]!.height < 0
      || ownValue(node, 'width') !== boxes[index]!.width
      || ownValue(node, 'height') !== boxes[index]!.height) return placed
    bodies.push({ x: box.x - half, y: box.y - half, width: box.width + 2 * half, height: box.height + 2 * half })
  }
  for (const [index, edge] of input.edges.entries()) {
    const label = ownValue(edge, 'label'), box = labels[index]
    if (!label !== !box || label && (!Number.isFinite(box!.width) || !Number.isFinite(box!.height) || box!.width < 4 || box!.height < 4
      || ownValue(label, 'width') !== box!.width - 4
      || ownValue(label, 'height') !== box!.height - 4)) return placed
  }
  const terminals: MeasuredBox[] = []
  for (const [index, edge] of input.edges.entries()) {
    const paint = ownValue(edge, 'markerPaint') as MeasuredGraph['edges'][number]['markerPaint']
    if (!paint) return placed
    for (const [pieces, point] of [[paint.start, ink[index]!.points[0]!], [paint.end, ink[index]!.points.at(-1)!]] as const) {
      let reach = 0
      for (const piece of pieces ?? []) {
        comparisons -= piece.kind === 'circle' ? 4 : 4 * piece.points.length
        if (comparisons < 0) return placed
        if (piece.kind === 'circle') reach = Math.max(reach, Math.hypot(piece.cx, piece.cy) + piece.r)
        else for (const point of piece.points) reach = Math.max(reach, Math.hypot(point.x, point.y))
      }
      if (!Number.isFinite(reach)) return placed
      if (reach) terminals.push({ x: point.x - reach, y: point.y - reach, width: 2 * reach, height: 2 * reach })
    }
  }
  const pointCount = ink.reduce((sum, route) => sum + route.points.length, 0)
  for (const [index, edge] of input.edges.entries()) {
    const anchor = placed.edges[index]!.labelPosition, current = labels[index]
    if (!anchor || !current || edge.source === edge.target || edge.visible === false || placed.boundaryRoutes?.includes(index)) continue
    const width = current.width - 4, height = current.height - 4
    comparisons -= ink[index]!.points.length
    if (comparisons < 0) return placed
    const carrier = ink[index]!.points.findIndex((point, cursor, points) => cursor > 0
      && (point.x === points[cursor - 1]!.x || point.y === points[cursor - 1]!.y)
      && pointOnMeasuredSegment(anchor, points[cursor - 1]!, point))
    if (carrier < 1) continue
    const a = ink[index]!.points[carrier - 1]!, b = ink[index]!.points[carrier]!
    const occupied = [...bodies, ...terminals, ...labels.filter((box, other): box is MeasuredBox => Boolean(box) && other !== index)]
    comparisons -= occupied.length + pointCount + labels.length
    if (comparisons < 0) return placed
    let left = Infinity, top = Infinity, right = -Infinity, bottom = -Infinity
    const include = (x: number, y: number, width = 0, height = 0) => {
      left = Math.min(left, x); top = Math.min(top, y)
      right = Math.max(right, x + width); bottom = Math.max(bottom, y + height)
    }
    for (const box of boxes) include(box.x, box.y, box.width, box.height)
    for (const route of ink) for (const point of route.points) include(point.x, point.y)
    // The safety ledger adds two pixels beyond the measured painted body.
    for (const [other, box] of labels.entries()) if (other !== index && box) include(box.x + 2, box.y + 2, box.width - 4, box.height - 4)
    const bounds = (p: Point) => ({
      left: Math.min(left, p.x - width / 2), top: Math.min(top, p.y - height / 2),
      right: Math.max(right, p.x + width / 2), bottom: Math.max(bottom, p.y + height / 2),
    })
    let best = anchor, extent = bounds(anchor)
    for (const t of [0.5, 1 / 3, 2 / 3, 0.25, 0.75, 1 / 6, 5 / 6]) {
      if (attempts-- <= 0) return placed
      comparisons -= occupied.length + pointCount + 1
      if (comparisons < 0) return placed
      const p = { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t }, next = bounds(p)
      if (next.left < extent.left || next.top < extent.top || next.right > extent.right || next.bottom > extent.bottom
        || next.right - next.left >= extent.right - extent.left && next.bottom - next.top >= extent.bottom - extent.top) continue
      const box = { x: p.x - width / 2 - 2, y: p.y - height / 2 - 2, width: width + 4, height: height + 4 }
      const shaftBox = { x: box.x - stroke / 2, y: box.y - stroke / 2, width: box.width + stroke, height: box.height + stroke }
      if (occupied.some(other => measuredBoxesOverlap(box, other))
        || ink.some((route, other) => other !== index && route.style !== 'invisible'
          && route.points.slice(1).some((point, cursor) => segmentEntersMeasuredBox(route.points[cursor]!, point, shaftBox)))) continue
      best = p; extent = next
    }
    if (best !== anchor) {
      placed.edges[index]!.labelPosition = best
      labels[index] = { x: best.x - width / 2 - 2, y: best.y - height / 2 - 2, width: width + 4, height: height + 4 }
    }
  }
  return placed
}
