# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 1.42s | 665 | 1.0ms | 1114 |

**Top 10:** `anonymous` 18.8%, `_inherits` 6.5%, `decodeBase64` 5.1%, `(anonymous)` 3.9%, `freeze` 2.3%, `add` 1.2%, `map` 1.2%, `stringify` 1.0%, `copyDataProperties` 1.0%, `visit` 0.9%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 18.8% | 269.1ms | 32.2% | 460.1ms | `anonymous` | `[native code]` |
| 6.5% | 92.9ms | 6.5% | 92.9ms | `_inherits` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 5.1% | 73.5ms | 5.1% | 73.5ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:24` |
| 3.9% | 56.9ms | 3.9% | 56.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:204` |
| 2.3% | 33.8ms | 2.3% | 33.8ms | `freeze` | `[native code]` |
| 1.2% | 17.4ms | 1.2% | 17.4ms | `add` | `[native code]` |
| 1.2% | 17.1ms | 23.9% | 342.0ms | `map` | `[native code]` |
| 1.0% | 15.0ms | 1.0% | 15.0ms | `stringify` | `[native code]` |
| 1.0% | 14.3ms | 1.0% | 14.3ms | `copyDataProperties` | `[native code]` |
| 0.9% | 14.2ms | 0.9% | 14.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:220` |
| 0.9% | 14.0ms | 0.9% | 14.0ms | `apply` | `[native code]` |
| 0.9% | 13.4ms | 5.2% | 74.9ms | `filter` | `[native code]` |
| 0.7% | 10.4ms | 0.7% | 10.4ms | `connectorGeometryEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:179` |
| 0.7% | 10.4ms | 1.5% | 21.7ms | `every` | `[native code]` |
| 0.7% | 10.1ms | 0.7% | 10.1ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:30` |
| 0.7% | 10.0ms | 0.7% | 10.0ms | `getOwnPropertyDescriptor` | `[native code]` |
| 0.6% | 8.6ms | 0.6% | 8.6ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:6` |
| 0.5% | 8.4ms | 0.5% | 8.4ms | `get` | `[native code]` |
| 0.5% | 8.2ms | 0.5% | 8.2ms | `typedArrayViewLength` | `[native code]` |
| 0.5% | 7.8ms | 0.5% | 7.8ms | `for` | `[native code]` |
| 0.5% | 7.6ms | 0.5% | 7.6ms | `has` | `[native code]` |
| 0.4% | 6.7ms | 0.4% | 6.7ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` |
| 0.4% | 6.5ms | 0.4% | 6.5ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` |
| 0.4% | 5.9ms | 0.4% | 5.9ms | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:422` |
| 0.4% | 5.8ms | 0.4% | 5.8ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.4% | 5.7ms | 0.4% | 5.7ms | `writeSync` | `[native code]` |
| 0.3% | 5.6ms | 0.3% | 5.6ms | `set` | `[native code]` |
| 0.3% | 5.5ms | 1.9% | 28.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:333` |
| 0.3% | 5.5ms | 0.3% | 5.5ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.3% | 5.2ms | 0.3% | 5.2ms | `flowchartFamilyHooks` | `/tmp/pr449-main-integration-20261029-762/src/agent/families-source-hooks.ts` |
| 0.3% | 5.0ms | 0.4% | 6.4ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:123` |
| 0.3% | 5.0ms | 0.3% | 5.0ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` |
| 0.3% | 4.6ms | 0.3% | 4.6ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` |
| 0.3% | 4.6ms | 0.3% | 4.6ms | `@lazy` | `[native code]` |
| 0.3% | 4.4ms | 0.3% | 4.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:29` |
| 0.3% | 4.4ms | 0.8% | 12.5ms | `some` | `[native code]` |
| 0.3% | 4.3ms | 0.3% | 5.7ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:524` |
| 0.3% | 4.3ms | 0.3% | 5.5ms | `replace` | `[native code]` |
| 0.2% | 4.2ms | 0.3% | 5.5ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:371` |
| 0.2% | 4.2ms | 0.2% | 4.2ms | `imul` | `[native code]` |
| 0.2% | 4.1ms | 0.2% | 4.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.2% | 4.1ms | 0.2% | 4.1ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.2% | 4.0ms | 0.2% | 4.0ms | `parse` | `[native code]` |
| 0.2% | 4.0ms | 24.8% | 354.0ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:221` |
| 0.2% | 3.8ms | 0.2% | 3.8ms | `sourceIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` |
| 0.2% | 3.7ms | 0.3% | 4.9ms | `test` | `[native code]` |
| 0.2% | 3.7ms | 0.2% | 3.7ms | `Map` | `[native code]` |
| 0.2% | 3.6ms | 0.9% | 13.7ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:210` |
| 0.2% | 3.6ms | 0.2% | 3.6ms | `Set` | `[native code]` |
| 0.2% | 3.5ms | 0.2% | 3.5ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.2% | 3.4ms | 0.2% | 3.4ms | `append` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.2% | 3.4ms | 0.2% | 3.4ms | `includes` | `[native code]` |
| 0.2% | 3.4ms | 0.2% | 3.4ms | `indentLines` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:744` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `compound` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:581` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `renderMermaidSVGWithReceipt` | `/tmp/pr449-main-integration-20261029-762/src/index.ts` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `textPaints` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:119` |
| 0.2% | 3.2ms | 0.4% | 5.8ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:95` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1006` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `trim` | `[native code]` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `safeRoleColor` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:296` |
| 0.2% | 3.1ms | 0.2% | 3.1ms | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:606` |
| 0.2% | 3.1ms | 0.2% | 3.1ms | `slice` | `[native code]` |
| 0.1% | 2.8ms | 0.1% | 2.8ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 2.7ms | 0.3% | 4.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:175` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 2.7ms | 0.4% | 6.5ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:232` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `values` | `[native code]` |
| 0.1% | 2.6ms | 0.1% | 2.6ms | `node:crypto` | `node:crypto:99` |
| 0.1% | 2.6ms | 0.1% | 2.6ms | `parseEncodeTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:45` |
| 0.1% | 2.6ms | 0.1% | 2.6ms | `Segmenter` | `[native code]` |
| 0.1% | 2.6ms | 0.1% | 2.6ms | `connectorUnitTangent` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:21` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `max` | `[native code]` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `push` | `[native code]` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:230` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:160` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `join` | `[native code]` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:38` |
| 0.1% | 2.4ms | 0.2% | 3.8ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:151` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `evaluateExtensionCompatibility` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:107` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:317` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `emitted` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:21` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:169` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `originalNativeDrawingOf` | `/tmp/pr449-main-integration-20261029-762/src/scene/drawing.ts` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:83` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `detectsJourneyFamily` | `/tmp/pr449-main-integration-20261029-762/src/shared/builtin-family-detection.ts` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `separatedSharpSupportBounds` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:68` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1854` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `concat` | `[native code]` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:594` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2361` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:324` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:379` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `selfContact` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `writtenPoint` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `emitted` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `emitted` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:22` |
| 0.1% | 1.9ms | 0.2% | 3.3ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:155` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `srgbRelativeLuminance` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:68` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:320` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:529` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:395` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `separatedSharpSupportBounds` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:72` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `writtenDecimalParts` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:31` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `fromEntries` | `[native code]` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `complete` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `checkFamilyConfigColors` | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `endpointRelation` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1628` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `definitions` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `toUpperCase` | `[native code]` |
| 0.1% | 1.7ms | 1.1% | 17.0ms | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:23` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:656` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `layoutClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `repairClassNoteSeats` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `concrete` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1369` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `entries` | `[native code]` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:18` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:157` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:159` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:537` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `fSpan` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/geometry.ts` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `buildStyleBlock` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:373` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `record` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:285` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:624` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:257` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `safeCssPaint` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:129` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:102` |
| 0.1% | 1.6ms | 0.2% | 3.0ms | `rectOverlap` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:164` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `Duplex` | `internal:streams/duplex` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1705` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `sign` | `[native code]` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:590` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `createSketchBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `log` | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `reserve` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `cloneObject` | `[native code]` |
| 0.1% | 1.5ms | 7.4% | 106.0ms | `forEach` | `[native code]` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `sourceTokenAt` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:52` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:496` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `contextLeaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `atan2` | `[native code]` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:355` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `booleanSchema` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.1% | 1.5ms | 0.2% | 2.9ms | `classNativeMarkerMinimums` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:194` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:49` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `create` | `[native code]` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `maxMemberWidth` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `createOwnedMeasuredRouteContactValidator` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `escapeXml` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:93` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `classStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:692` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `assertMarkerPaint` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `assertMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `connectorGeometryEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:180` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:160` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `RegExp` | `[native code]` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `customTextMeasurementActive` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `seatFinalMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:250` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:759` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:988` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:538` |
| 0.1% | 1.4ms | 0.4% | 5.7ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:334` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1093` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `applyFamilyRequestNormalization` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `proofRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:64` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `transformPoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:155` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `makeBitMapDescriptor` | `internal:streams/readable` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `connectorEndpointAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:445` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1990` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:118` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:231` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/c4/config.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `dereferenceSchema` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `record` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `ownKeys` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:325` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `findIndex` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:782` |
| 0.0% | 1.4ms | 0.4% | 7.0ms | `textSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1651` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `updateCarrier` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `unsafeActiveCss` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scoreMeasuredRouteCrossings` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:395` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:473` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `isXmlWhitespace` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.3ms | 0.2% | 2.9ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:96` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:184` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `String` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.3ms | 1.3% | 18.7ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:739` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `unsafeActiveCssScan` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:618` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:193` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1282` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `work` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `normalizedReference` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:579` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `cssPaintDefinitions` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.3ms | 0.7% | 10.0ms | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1501` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:97` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `makeSafe` | `internal:primordials` |
| 0.0% | 1.3ms | 0.1% | 2.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts:9` |
| 0.0% | 1.3ms | 10.4% | 148.5ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:172` |
| 0.0% | 1.3ms | 0.2% | 2.8ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:732` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:369` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:148` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:164` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `createEmissionContext` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `cloneValue` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:389` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `outlineKey` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parseMarkedClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1314` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:143` |
| 0.0% | 1.3ms | 0.1% | 2.7ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1992` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `admitBackendSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/external-data-snapshot.ts:17` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:349` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1465` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `isWhitespace` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:25` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connectorTerminalStrokeLosses` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:87` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:181` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.3ms | 0.5% | 7.7ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:121` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:252` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `repairClassAnnotationSeats` | `/tmp/pr449-main-integration-20261029-762/src/class/annotation-seats.ts` |
| 0.0% | 1.3ms | 0.6% | 9.5ms | `arrayIteratorNextHelper` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:512` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:725` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `registrationIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/requirement/tokens.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `admitRenderContractDigestInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 0.0% | 1.3ms | 0.1% | 2.6ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:156` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1083` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1781` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:162` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `isCombiningMark` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `begin` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:725` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:760` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `canonicalExtensionId` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` |
| 0.0% | 1.2ms | 0.1% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:680` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `primitiveCapabilityClaimKey` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:322` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:462` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts:2165` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:773` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:390` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `min` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `shortenMeasuredRoutes` | `/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:620` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `configSpacing` | `/tmp/pr449-main-integration-20261029-762/src/shared/config-spacing.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1393` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `nodePaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:638` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `extractClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector/labels/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/pathfinder.ts:35` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `hypot` | `[native code]` |
| 0.0% | 1.2ms | 0.5% | 7.7ms | `next` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1755` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pose` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:335` |
| 0.0% | 1.2ms | 0.4% | 6.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1052` |
| 0.0% | 1.2ms | 1.0% | 15.5ms | `find` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:11` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `unsafeCssReferences` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:601` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `classRelationshipTerminalClearance` | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:59` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `positionFamily` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:845` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `createImmutableParts` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:340` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:729` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1231` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1354` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:191` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1091` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `emittedEndpointMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:392` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `mixedChannels` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `semVerSatisfies` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `finalizeClassSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.2ms | 0.1% | 2.3ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:150` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `match` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderPositionedMermaidSVG` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parseProtected` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `createWrittenPolyline` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:33` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:560` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:32` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateAggregateReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1525` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1046` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:621` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `classNativeMarkerMinimums` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `decodeWithTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:442` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:266` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `sceneGroupOpacity` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:108` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1260` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:350` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1787` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `exec` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `inverseMatrix` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:25` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:220` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:520` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:417` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:312` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:58` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `read` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:64` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:776` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:662` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorInlineLabelSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `decodeXmlReferences` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `hasDisplayedText` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `bisector` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:50` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:120` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `descriptorOwnsDetectionLine` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2072` |
| 0.0% | 1.1ms | 0.1% | 2.3ms | `resolveCss` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:728` |
| 0.0% | 1.1ms | 0.1% | 2.4ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `xmlHasColon` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:661` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:386` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorTerminalStrokeLosses` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:85` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `executionCapabilityKey` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.1% | 2.5ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:183` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `sourceSlice` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:55` |
| 0.0% | 1.1ms | 0.2% | 2.9ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:577` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:43` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `document/resources/serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:99` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts:32` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `requiredBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/` | `[native code]` |
| 0.0% | 1.1ms | 0.2% | 3.8ms | `evaluateExtensionCompatibility` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:144` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:138` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `detectsQuadrantFamily` | `/tmp/pr449-main-integration-20261029-762/src/shared/builtin-family-detection.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:126` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.1ms | 0.2% | 3.3ms | `drawn` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:421` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:156` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:284` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `defineProperty` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `compare` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:33` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:286` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `overlaps` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:698` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `createHash` | `node:crypto` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:527` |
| 0.0% | 1.0ms | 0.1% | 2.1ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:656` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `expandInlineNamespaceStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:36` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `isArray` | `[native code]` |
| 0.0% | 1.0ms | 0.1% | 2.3ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:169` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `readDefinitions` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1175` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` |
| 0.0% | 1.0ms | 0.5% | 8.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `snapshotTextMeasurementProfile` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `record` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:261` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `viewportBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `sourceIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `rootMatches` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `receiptOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:757` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:427` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Duplex` | `internal:streams/duplex:16` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `toFinite` | `/tmp/pr449-main-integration-20261029-762/src/agent/types.ts:1604` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:639` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1244` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateUnitVector` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 983us | 0.0% | 983us | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` |
| 0.0% | 981us | 0.0% | 981us | `resolveCss` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:725` |
| 0.0% | 981us | 0.0% | 981us | `get` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` |
| 0.0% | 979us | 0.0% | 979us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 973us | 0.0% | 973us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:426` |
| 0.0% | 970us | 0.1% | 2.4ms | `measureClassCards` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:201` |
| 0.0% | 969us | 0.0% | 969us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1720` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 69.2% | 987.7ms | 0.0% | 0us | `withTextMeasurementExecution` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:135` |
| 54.9% | 783.3ms | 0.0% | 0us | `measureRenderStage` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:30` |
| 53.0% | 756.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:20` |
| 53.0% | 756.5ms | 0.0% | 0us | `withRenderStageObserver` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:20` |
| 53.0% | 756.5ms | 0.0% | 0us | `withPerformanceObserver` | `/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts:42` |
| 52.8% | 753.1ms | 0.0% | 0us | `withSvgInspectionCache` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:20` |
| 49.8% | 711.2ms | 0.0% | 0us | `consumeResolvedGraphicalRequest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:316` |
| 32.2% | 460.1ms | 18.8% | 269.1ms | `anonymous` | `[native code]` |
| 27.3% | 390.4ms | 0.0% | 0us | `bound require` | `[native code]` |
| 27.3% | 390.4ms | 0.0% | 0us | `require` | `[native code]` |
| 24.8% | 354.0ms | 0.2% | 4.0ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:221` |
| 23.9% | 342.0ms | 1.2% | 17.1ms | `map` | `[native code]` |
| 19.8% | 282.8ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:185` |
| 19.5% | 278.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 19.2% | 273.9ms | 0.0% | 0us | `retainedPositionedScene` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:63` |
| 15.9% | 227.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` |
| 15.9% | 227.9ms | 0.0% | 0us | `expandLocalReferences` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` |
| 15.9% | 227.0ms | 0.0% | 0us | `admitFamilyScene` | `/tmp/pr449-main-integration-20261029-762/src/scene/admission.ts:31` |
| 15.8% | 226.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:5` |
| 15.8% | 226.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:3` |
| 15.3% | 219.1ms | 0.0% | 0us | `positionFamilyForNativeRender` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:67` |
| 15.3% | 219.1ms | 0.0% | 0us | `renderResolvedMermaidSVG` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:270` |
| 14.2% | 203.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:123` |
| 14.2% | 203.0ms | 0.0% | 0us | `withGraphLayoutDecisionObserver` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:37` |
| 12.7% | 181.9ms | 0.0% | 0us | `layout` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:25` |
| 11.1% | 159.4ms | 0.0% | 0us | `runMeasuredGraphBackend` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:73` |
| 10.4% | 148.5ms | 0.0% | 1.3ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:172` |
| 9.0% | 129.6ms | 0.0% | 0us | `admitSceneDocumentWith` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:270` |
| 9.0% | 129.6ms | 0.0% | 0us | `assertAdmissibleSceneDoc` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation.ts:247` |
| 8.6% | 123.7ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1621` |
| 7.5% | 108.0ms | 0.0% | 0us | `admitSceneDocumentWith` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:268` |
| 7.4% | 106.0ms | 0.1% | 1.5ms | `forEach` | `[native code]` |
| 7.3% | 104.5ms | 0.0% | 0us | `positionedPaintCertification` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:178` |
| 7.3% | 104.5ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:186` |
| 6.5% | 92.9ms | 0.0% | 0us | `r` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 6.5% | 92.9ms | 6.5% | 92.9ms | `_inherits` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 6.5% | 92.9ms | 0.0% | 0us | `o` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 6.5% | 92.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6572` |
| 6.5% | 92.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6573` |
| 5.2% | 74.9ms | 0.9% | 13.4ms | `filter` | `[native code]` |
| 5.1% | 73.5ms | 5.1% | 73.5ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:24` |
| 5.1% | 73.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/decode-data-html.js:3` |
| 4.9% | 70.8ms | 0.0% | 0us | `walk` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:328` |
| 4.1% | 58.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:208` |
| 4.0% | 58.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:780` |
| 3.9% | 56.9ms | 3.9% | 56.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:204` |
| 3.9% | 56.9ms | 0.0% | 0us | `expandLocalReferences` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:204` |
| 3.9% | 56.2ms | 0.0% | 0us | `inspectOwnedSvgOnce` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:46` |
| 3.8% | 55.0ms | 0.0% | 0us | `applyOutputSecurityPolicy` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:727` |
| 3.7% | 53.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:710` |
| 3.6% | 52.6ms | 0.0% | 0us | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:792` |
| 3.5% | 51.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:678` |
| 3.5% | 51.0ms | 0.0% | 0us | `certifyScenePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1426` |
| 3.5% | 50.3ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:252` |
| 3.4% | 49.7ms | 0.0% | 0us | `inspectScenePaintGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:155` |
| 3.3% | 47.9ms | 0.0% | 0us | `inspectScene` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:344` |
| 3.3% | 47.7ms | 0.0% | 0us | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:702` |
| 3.2% | 46.9ms | 0.0% | 0us | `withDeferredTerminalProjections` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:16` |
| 3.2% | 46.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:64` |
| 3.1% | 45.2ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:575` |
| 3.1% | 44.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/families.ts:8` |
| 2.9% | 42.4ms | 0.0% | 0us | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:791` |
| 2.9% | 42.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:340` |
| 2.9% | 41.9ms | 0.0% | 0us | `executeInspectedGraphicalRequest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:297` |
| 2.6% | 38.2ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:95` |
| 2.5% | 37.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:3` |
| 2.5% | 36.8ms | 0.0% | 0us | `finalizeFlatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:655` |
| 2.4% | 35.3ms | 0.0% | 0us | `seatFinalMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:569` |
| 2.3% | 33.8ms | 2.3% | 33.8ms | `freeze` | `[native code]` |
| 2.1% | 30.9ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:189` |
| 2.1% | 30.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:198` |
| 1.9% | 28.4ms | 0.3% | 5.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:333` |
| 1.9% | 27.5ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:103` |
| 1.7% | 25.2ms | 0.0% | 0us | `finalizeClassSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:824` |
| 1.6% | 23.9ms | 0.0% | 0us | `prove` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:264` |
| 1.6% | 23.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:273` |
| 1.6% | 23.9ms | 0.0% | 0us | `report` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:235` |
| 1.6% | 23.5ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1879` |
| 1.5% | 22.3ms | 0.0% | 0us | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:1026` |
| 1.5% | 22.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:601` |
| 1.5% | 21.7ms | 0.7% | 10.4ms | `every` | `[native code]` |
| 1.4% | 21.3ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:136` |
| 1.4% | 21.1ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1878` |
| 1.4% | 21.1ms | 0.0% | 0us | `layout` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:20` |
| 1.4% | 20.7ms | 0.0% | 0us | `layoutClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:631` |
| 1.4% | 20.6ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:901` |
| 1.4% | 20.6ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:252` |
| 1.4% | 20.1ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1502` |
| 1.3% | 19.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:5` |
| 1.3% | 18.7ms | 0.0% | 0us | `connectorMarkerPaintRegions` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:353` |
| 1.3% | 18.7ms | 0.0% | 1.3ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:739` |
| 1.2% | 18.2ms | 0.0% | 0us | `measureClassCards` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:186` |
| 1.2% | 17.4ms | 1.2% | 17.4ms | `add` | `[native code]` |
| 1.1% | 17.0ms | 0.1% | 1.7ms | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:23` |
| 1.1% | 16.1ms | 0.0% | 0us | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` |
| 1.0% | 15.5ms | 0.0% | 1.2ms | `find` | `[native code]` |
| 1.0% | 15.5ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:565` |
| 1.0% | 15.4ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` |
| 1.0% | 15.0ms | 1.0% | 15.0ms | `stringify` | `[native code]` |
| 1.0% | 14.3ms | 0.0% | 0us | `normalizeMermaidSourceWithOverrides` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:762` |
| 1.0% | 14.3ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1737` |
| 1.0% | 14.3ms | 1.0% | 14.3ms | `copyDataProperties` | `[native code]` |
| 0.9% | 14.2ms | 0.9% | 14.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:220` |
| 0.9% | 14.2ms | 0.0% | 0us | `node:zlib` | `node:zlib:2` |
| 0.9% | 14.2ms | 0.0% | 0us | `node:stream` | `node:stream:2` |
| 0.9% | 14.0ms | 0.9% | 14.0ms | `apply` | `[native code]` |
| 0.9% | 14.0ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:144` |
| 0.9% | 14.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:148` |
| 0.9% | 13.7ms | 0.2% | 3.6ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:210` |
| 0.9% | 13.6ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:411` |
| 0.9% | 13.3ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:218` |
| 0.8% | 12.7ms | 0.0% | 0us | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` |
| 0.8% | 12.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` |
| 0.8% | 12.5ms | 0.3% | 4.4ms | `some` | `[native code]` |
| 0.8% | 12.0ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:725` |
| 0.8% | 11.9ms | 0.0% | 0us | `rendered` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:427` |
| 0.8% | 11.9ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1763` |
| 0.8% | 11.9ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:281` |
| 0.8% | 11.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:8` |
| 0.8% | 11.5ms | 0.0% | 0us | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1041` |
| 0.8% | 11.5ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:89` |
| 0.7% | 10.6ms | 0.0% | 0us | `walk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1749` |
| 0.7% | 10.6ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1031` |
| 0.7% | 10.6ms | 0.0% | 0us | `render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:394` |
| 0.7% | 10.5ms | 0.0% | 0us | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:703` |
| 0.7% | 10.4ms | 0.7% | 10.4ms | `connectorGeometryEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:179` |
| 0.7% | 10.1ms | 0.0% | 0us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:985` |
| 0.7% | 10.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.7% | 10.1ms | 0.0% | 0us | `cloneValue` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.7% | 10.1ms | 0.7% | 10.1ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:30` |
| 0.7% | 10.0ms | 0.7% | 10.0ms | `getOwnPropertyDescriptor` | `[native code]` |
| 0.7% | 10.0ms | 0.0% | 1.3ms | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1501` |
| 0.7% | 9.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:142` |
| 0.6% | 9.8ms | 0.0% | 0us | `internal:stream` | `internal:stream:2` |
| 0.6% | 9.8ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:194` |
| 0.6% | 9.7ms | 0.0% | 0us | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:846` |
| 0.6% | 9.5ms | 0.0% | 1.3ms | `arrayIteratorNextHelper` | `[native code]` |
| 0.6% | 9.2ms | 0.0% | 0us | `registerBuiltInStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:292` |
| 0.6% | 9.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:24` |
| 0.6% | 9.1ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:323` |
| 0.6% | 9.1ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:94` |
| 0.6% | 9.0ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:824` |
| 0.6% | 9.0ms | 0.0% | 0us | `classStatementEnds` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:650` |
| 0.6% | 8.9ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:217` |
| 0.6% | 8.9ms | 0.0% | 0us | `get` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:28` |
| 0.6% | 8.7ms | 0.0% | 0us | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1019` |
| 0.6% | 8.6ms | 0.6% | 8.6ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:6` |
| 0.6% | 8.5ms | 0.0% | 0us | `inlineResolvedColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:636` |
| 0.5% | 8.4ms | 0.0% | 0us | `internal:streams/pipeline` | `internal:streams/pipeline:2` |
| 0.5% | 8.4ms | 0.0% | 0us | `internal:streams/compose` | `internal:streams/compose:2` |
| 0.5% | 8.4ms | 0.5% | 8.4ms | `get` | `[native code]` |
| 0.5% | 8.3ms | 0.0% | 1.0ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` |
| 0.5% | 8.2ms | 0.0% | 0us | `color` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1038` |
| 0.5% | 8.2ms | 0.5% | 8.2ms | `typedArrayViewLength` | `[native code]` |
| 0.5% | 7.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:7` |
| 0.5% | 7.8ms | 0.5% | 7.8ms | `for` | `[native code]` |
| 0.5% | 7.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/identity.js:3` |
| 0.5% | 7.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/directives.js:3` |
| 0.5% | 7.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:4` |
| 0.5% | 7.8ms | 0.0% | 0us | `zlibBufferSync` | `node:zlib:94` |
| 0.5% | 7.7ms | 0.0% | 1.2ms | `next` | `[native code]` |
| 0.5% | 7.7ms | 0.0% | 1.3ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:121` |
| 0.5% | 7.6ms | 0.5% | 7.6ms | `has` | `[native code]` |
| 0.5% | 7.5ms | 0.0% | 0us | `createExtensionIdentity` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:246` |
| 0.5% | 7.5ms | 0.0% | 0us | `prepare` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:353` |
| 0.5% | 7.5ms | 0.0% | 0us | `retainedPositionedScene` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:65` |
| 0.5% | 7.4ms | 0.0% | 0us | `captureFields` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` |
| 0.5% | 7.3ms | 0.0% | 0us | `finalizeClassSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:802` |
| 0.5% | 7.2ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1583` |
| 0.5% | 7.2ms | 0.0% | 0us | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:701` |
| 0.5% | 7.2ms | 0.0% | 0us | `projectSvgCss` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:287` |
| 0.5% | 7.1ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:653` |
| 0.5% | 7.1ms | 0.0% | 0us | `visitSvgFirstTagAttributes` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:106` |
| 0.5% | 7.1ms | 0.0% | 0us | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:39` |
| 0.4% | 7.0ms | 0.0% | 1.4ms | `textSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1651` |
| 0.4% | 7.0ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:100` |
| 0.4% | 6.9ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1052` |
| 0.4% | 6.9ms | 0.0% | 0us | `render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:157` |
| 0.4% | 6.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-doc.js:4` |
| 0.4% | 6.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:8` |
| 0.4% | 6.7ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:800` |
| 0.4% | 6.7ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` |
| 0.4% | 6.7ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:764` |
| 0.4% | 6.7ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:646` |
| 0.4% | 6.7ms | 0.4% | 6.7ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` |
| 0.4% | 6.5ms | 0.4% | 6.5ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` |
| 0.4% | 6.5ms | 0.1% | 2.7ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:232` |
| 0.4% | 6.4ms | 0.0% | 0us | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:330` |
| 0.4% | 6.4ms | 0.3% | 5.0ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:123` |
| 0.4% | 6.0ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:431` |
| 0.4% | 6.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:713` |
| 0.4% | 5.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:787` |
| 0.4% | 5.9ms | 0.4% | 5.9ms | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:422` |
| 0.4% | 5.9ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:420` |
| 0.4% | 5.9ms | 0.0% | 0us | `projectClassPositioned` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:23` |
| 0.4% | 5.8ms | 0.0% | 0us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:992` |
| 0.4% | 5.8ms | 0.4% | 5.8ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.4% | 5.8ms | 0.0% | 0us | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:158` |
| 0.4% | 5.8ms | 0.2% | 3.2ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:95` |
| 0.4% | 5.7ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:2` |
| 0.4% | 5.7ms | 0.0% | 0us | `strokedBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:543` |
| 0.4% | 5.7ms | 0.1% | 1.4ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:334` |
| 0.4% | 5.7ms | 0.0% | 0us | `processChunkSync` | `node:zlib:203` |
| 0.4% | 5.7ms | 0.4% | 5.7ms | `writeSync` | `[native code]` |
| 0.3% | 5.7ms | 0.3% | 4.3ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:524` |
| 0.3% | 5.6ms | 0.0% | 0us | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:711` |
| 0.3% | 5.6ms | 0.0% | 0us | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:130` |
| 0.3% | 5.6ms | 0.3% | 5.6ms | `set` | `[native code]` |
| 0.3% | 5.5ms | 0.0% | 0us | `finalizeClassSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:834` |
| 0.3% | 5.5ms | 0.3% | 4.3ms | `replace` | `[native code]` |
| 0.3% | 5.5ms | 0.3% | 5.5ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.3% | 5.5ms | 0.2% | 4.2ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:371` |
| 0.3% | 5.4ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:195` |
| 0.3% | 5.4ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:131` |
| 0.3% | 5.4ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` |
| 0.3% | 5.3ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1728` |
| 0.3% | 5.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:158` |
| 0.3% | 5.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:185` |
| 0.3% | 5.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:186` |
| 0.3% | 5.2ms | 0.3% | 5.2ms | `flowchartFamilyHooks` | `/tmp/pr449-main-integration-20261029-762/src/agent/families-source-hooks.ts` |
| 0.3% | 5.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/families-source-hooks.ts:142` |
| 0.3% | 5.1ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:817` |
| 0.3% | 5.0ms | 0.3% | 5.0ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` |
| 0.3% | 5.0ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:998` |
| 0.3% | 4.9ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:907` |
| 0.3% | 4.9ms | 0.2% | 3.7ms | `test` | `[native code]` |
| 0.3% | 4.9ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:237` |
| 0.3% | 4.8ms | 0.0% | 0us | `projectClassRectangleContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:163` |
| 0.3% | 4.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:143` |
| 0.3% | 4.8ms | 0.0% | 0us | `assessRenderedLayoutHardViolations` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:211` |
| 0.3% | 4.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:21` |
| 0.3% | 4.7ms | 0.0% | 0us | `get receipt` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:347` |
| 0.3% | 4.7ms | 0.0% | 0us | `resolveSvgColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:758` |
| 0.3% | 4.7ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1637` |
| 0.3% | 4.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:181` |
| 0.3% | 4.7ms | 0.0% | 0us | `createRenderOutputDescriptors` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:171` |
| 0.3% | 4.7ms | 0.0% | 0us | `freezeTransport` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:158` |
| 0.3% | 4.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:191` |
| 0.3% | 4.6ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:403` |
| 0.3% | 4.6ms | 0.3% | 4.6ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` |
| 0.3% | 4.6ms | 0.0% | 0us | `internal:fs/binding` | `internal:fs/binding:3` |
| 0.3% | 4.6ms | 0.0% | 0us | `node:fs` | `node:fs:8` |
| 0.3% | 4.6ms | 0.3% | 4.6ms | `@lazy` | `[native code]` |
| 0.3% | 4.5ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1088` |
| 0.3% | 4.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:974` |
| 0.3% | 4.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:5` |
| 0.3% | 4.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:32` |
| 0.3% | 4.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1841` |
| 0.3% | 4.4ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1841` |
| 0.3% | 4.4ms | 0.3% | 4.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:29` |
| 0.3% | 4.4ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:464` |
| 0.3% | 4.4ms | 0.0% | 0us | `setConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:53` |
| 0.3% | 4.4ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:587` |
| 0.3% | 4.3ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:251` |
| 0.3% | 4.3ms | 0.0% | 0us | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:37` |
| 0.3% | 4.3ms | 0.0% | 0us | `classifyClassStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:536` |
| 0.3% | 4.3ms | 0.0% | 0us | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:354` |
| 0.3% | 4.3ms | 0.0% | 0us | `resolvedColorValue` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:601` |
| 0.3% | 4.2ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1569` |
| 0.3% | 4.2ms | 0.1% | 2.7ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:175` |
| 0.2% | 4.2ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1965` |
| 0.2% | 4.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1215` |
| 0.2% | 4.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:659` |
| 0.2% | 4.2ms | 0.2% | 4.2ms | `imul` | `[native code]` |
| 0.2% | 4.1ms | 0.2% | 4.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.2% | 4.1ms | 0.2% | 4.1ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.2% | 4.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:662` |
| 0.2% | 4.1ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:584` |
| 0.2% | 4.1ms | 0.0% | 0us | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:569` |
| 0.2% | 4.0ms | 0.0% | 0us | `assertFinalClassSharpContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:866` |
| 0.2% | 4.0ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:185` |
| 0.2% | 4.0ms | 0.2% | 4.0ms | `parse` | `[native code]` |
| 0.2% | 4.0ms | 0.0% | 0us | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:753` |
| 0.2% | 4.0ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1765` |
| 0.2% | 3.9ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:617` |
| 0.2% | 3.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:6` |
| 0.2% | 3.9ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:484` |
| 0.2% | 3.8ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:682` |
| 0.2% | 3.8ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:133` |
| 0.2% | 3.8ms | 0.0% | 1.1ms | `evaluateExtensionCompatibility` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:144` |
| 0.2% | 3.8ms | 0.2% | 3.8ms | `sourceIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` |
| 0.2% | 3.8ms | 0.1% | 2.4ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:151` |
| 0.2% | 3.7ms | 0.2% | 3.7ms | `Map` | `[native code]` |
| 0.2% | 3.7ms | 0.0% | 0us | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:353` |
| 0.2% | 3.7ms | 0.0% | 0us | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` |
| 0.2% | 3.6ms | 0.0% | 0us | `markerTerminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:294` |
| 0.2% | 3.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:10` |
| 0.2% | 3.6ms | 0.0% | 0us | `prepareMarkerTerminals` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:9` |
| 0.2% | 3.6ms | 0.0% | 0us | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:362` |
| 0.2% | 3.6ms | 0.2% | 3.6ms | `Set` | `[native code]` |
| 0.2% | 3.6ms | 0.0% | 0us | `snapshotScenePrimitiveCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1541` |
| 0.2% | 3.5ms | 0.2% | 3.5ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.2% | 3.4ms | 0.2% | 3.4ms | `append` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.2% | 3.4ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:276` |
| 0.2% | 3.4ms | 0.0% | 0us | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:245` |
| 0.2% | 3.4ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:542` |
| 0.2% | 3.4ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:322` |
| 0.2% | 3.4ms | 0.2% | 3.4ms | `includes` | `[native code]` |
| 0.2% | 3.4ms | 0.2% | 3.4ms | `indentLines` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:744` |
| 0.2% | 3.3ms | 0.0% | 0us | `resolvedInlineColorAttribute` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:683` |
| 0.2% | 3.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:310` |
| 0.2% | 3.3ms | 0.0% | 0us | `transformSvgCssValues` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:308` |
| 0.2% | 3.3ms | 0.1% | 1.9ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:155` |
| 0.2% | 3.3ms | 0.0% | 1.1ms | `drawn` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:421` |
| 0.2% | 3.3ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1782` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `compound` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.2% | 3.3ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:545` |
| 0.2% | 3.3ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:195` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:581` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `renderMermaidSVGWithReceipt` | `/tmp/pr449-main-integration-20261029-762/src/index.ts` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `textPaints` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:119` |
| 0.2% | 3.3ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1783` |
| 0.2% | 3.2ms | 0.0% | 0us | `color` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1039` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1006` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `trim` | `[native code]` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `safeRoleColor` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:296` |
| 0.2% | 3.2ms | 0.0% | 0us | `validateRoleStyleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:323` |
| 0.2% | 3.2ms | 0.0% | 0us | `validateRoleStyles` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:340` |
| 0.2% | 3.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:810` |
| 0.2% | 3.2ms | 0.0% | 0us | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:453` |
| 0.2% | 3.1ms | 0.2% | 3.1ms | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:606` |
| 0.2% | 3.1ms | 0.0% | 0us | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1372` |
| 0.2% | 3.1ms | 0.0% | 0us | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:694` |
| 0.2% | 3.1ms | 0.0% | 0us | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:476` |
| 0.2% | 3.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:665` |
| 0.2% | 3.1ms | 0.0% | 0us | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:104` |
| 0.2% | 3.1ms | 0.2% | 3.1ms | `slice` | `[native code]` |
| 0.2% | 3.1ms | 0.0% | 0us | `xmlNameCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:87` |
| 0.2% | 3.0ms | 0.0% | 0us | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:266` |
| 0.2% | 3.0ms | 0.1% | 1.6ms | `rectOverlap` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:164` |
| 0.2% | 2.9ms | 0.0% | 1.3ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:96` |
| 0.2% | 2.9ms | 0.0% | 0us | `decodedSvgAttributeValue` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:217` |
| 0.2% | 2.9ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1944` |
| 0.2% | 2.9ms | 0.1% | 1.5ms | `classNativeMarkerMinimums` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:194` |
| 0.2% | 2.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:6` |
| 0.2% | 2.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:555` |
| 0.2% | 2.9ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:593` |
| 0.2% | 2.9ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:825` |
| 0.2% | 2.9ms | 0.0% | 0us | `flatIntoArrayWithCallback` | `[native code]` |
| 0.2% | 2.9ms | 0.0% | 1.1ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:577` |
| 0.2% | 2.8ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:164` |
| 0.2% | 2.8ms | 0.0% | 1.3ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` |
| 0.1% | 2.8ms | 0.0% | 0us | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:41` |
| 0.1% | 2.8ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:605` |
| 0.1% | 2.8ms | 0.1% | 2.8ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 2.7ms | 0.0% | 0us | `reduce` | `[native code]` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 2.7ms | 0.0% | 1.3ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1992` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `values` | `[native code]` |
| 0.1% | 2.7ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts:9` |
| 0.1% | 2.7ms | 0.0% | 0us | `buildClassEndpointMarkerTemplates` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts:9` |
| 0.1% | 2.7ms | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1656` |
| 0.1% | 2.7ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:405` |
| 0.1% | 2.7ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1584` |
| 0.1% | 2.6ms | 0.0% | 0us | `projectClassPositioned` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:9` |
| 0.1% | 2.6ms | 0.0% | 0us | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:511` |
| 0.1% | 2.6ms | 0.0% | 1.3ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:156` |
| 0.1% | 2.6ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:201` |
| 0.1% | 2.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/encode-html.js:10` |
| 0.1% | 2.6ms | 0.1% | 2.6ms | `parseEncodeTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:45` |
| 0.1% | 2.6ms | 0.1% | 2.6ms | `node:crypto` | `node:crypto:99` |
| 0.1% | 2.6ms | 0.0% | 0us | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` |
| 0.1% | 2.6ms | 0.0% | 0us | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:662` |
| 0.1% | 2.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts:3` |
| 0.1% | 2.6ms | 0.1% | 2.6ms | `Segmenter` | `[native code]` |
| 0.1% | 2.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:4` |
| 0.1% | 2.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringifyPair.js:5` |
| 0.1% | 2.6ms | 0.0% | 0us | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:387` |
| 0.1% | 2.6ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:346` |
| 0.1% | 2.6ms | 0.1% | 2.6ms | `connectorUnitTangent` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:21` |
| 0.1% | 2.6ms | 0.0% | 0us | `Zlib` | `node:zlib:298` |
| 0.1% | 2.6ms | 0.0% | 0us | `ZlibBase` | `node:zlib:123` |
| 0.1% | 2.6ms | 0.0% | 0us | `Transform` | `internal:streams/transform:14` |
| 0.1% | 2.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:548` |
| 0.1% | 2.6ms | 0.0% | 0us | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:308` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `max` | `[native code]` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `push` | `[native code]` |
| 0.1% | 2.5ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:941` |
| 0.1% | 2.5ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:680` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:230` |
| 0.1% | 2.5ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:641` |
| 0.1% | 2.5ms | 0.0% | 1.1ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:183` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:160` |
| 0.1% | 2.5ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:777` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `join` | `[native code]` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:38` |
| 0.1% | 2.5ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:174` |
| 0.1% | 2.5ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:407` |
| 0.1% | 2.5ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1267` |
| 0.1% | 2.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:16` |
| 0.1% | 2.4ms | 0.0% | 0us | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:454` |
| 0.1% | 2.4ms | 0.0% | 0us | `sharedRenderOptionsJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:485` |
| 0.1% | 2.4ms | 0.0% | 970us | `measureClassCards` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:201` |
| 0.1% | 2.4ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:107` |
| 0.1% | 2.4ms | 0.0% | 1.1ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` |
| 0.1% | 2.4ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:140` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `evaluateExtensionCompatibility` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:107` |
| 0.1% | 2.4ms | 0.0% | 0us | `classifyClassStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:449` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:317` |
| 0.1% | 2.4ms | 0.0% | 0us | `addClassSvgNumbers` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:60` |
| 0.1% | 2.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:61` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `emitted` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:21` |
| 0.1% | 2.4ms | 0.0% | 0us | `projectClassRectangleContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:164` |
| 0.1% | 2.4ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:207` |
| 0.1% | 2.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:328` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` |
| 0.1% | 2.3ms | 0.0% | 0us | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:13` |
| 0.1% | 2.3ms | 0.0% | 1.1ms | `resolveCss` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:728` |
| 0.1% | 2.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:330` |
| 0.1% | 2.3ms | 0.0% | 0us | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:359` |
| 0.1% | 2.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:5` |
| 0.1% | 2.3ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:222` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:169` |
| 0.1% | 2.3ms | 0.0% | 0us | `snapshotScenePrimitiveCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1548` |
| 0.1% | 2.3ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:619` |
| 0.1% | 2.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:7` |
| 0.1% | 2.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/resolve-block-map.js:8` |
| 0.1% | 2.3ms | 0.0% | 1.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:150` |
| 0.1% | 2.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/builtin-backends.ts:20` |
| 0.1% | 2.3ms | 0.0% | 1.0ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:169` |
| 0.1% | 2.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:3` |
| 0.1% | 2.3ms | 0.0% | 0us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:97` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `originalNativeDrawingOf` | `/tmp/pr449-main-integration-20261029-762/src/scene/drawing.ts` |
| 0.1% | 2.3ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:183` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:83` |
| 0.1% | 2.2ms | 0.0% | 0us | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:176` |
| 0.1% | 2.2ms | 0.0% | 0us | `rejectUnknownKeys` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:152` |
| 0.1% | 2.2ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:181` |
| 0.1% | 2.2ms | 0.0% | 0us | `sort` | `[native code]` |
| 0.1% | 2.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/default-backend.ts:5` |
| 0.1% | 2.2ms | 0.0% | 0us | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:468` |
| 0.1% | 2.2ms | 0.0% | 0us | `validateBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:312` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `detectsJourneyFamily` | `/tmp/pr449-main-integration-20261029-762/src/shared/builtin-family-detection.ts` |
| 0.1% | 2.2ms | 0.0% | 0us | `detectorClaims` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1596` |
| 0.1% | 2.2ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:167` |
| 0.1% | 2.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:9` |
| 0.1% | 2.2ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:803` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `separatedSharpSupportBounds` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:68` |
| 0.1% | 2.1ms | 0.0% | 0us | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:315` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1854` |
| 0.1% | 2.1ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1854` |
| 0.1% | 2.1ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:253` |
| 0.1% | 2.1ms | 0.0% | 0us | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:98` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `concat` | `[native code]` |
| 0.1% | 2.1ms | 0.0% | 1.0ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:656` |
| 0.1% | 2.1ms | 0.0% | 0us | `tree` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:71` |
| 0.1% | 2.1ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1592` |
| 0.1% | 2.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:25` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:594` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2361` |
| 0.1% | 2.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:8` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:324` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:379` |
| 0.1% | 2.0ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:262` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `selfContact` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.1% | 1.9ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:500` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `writtenPoint` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.1% | 1.9ms | 0.0% | 0us | `compareClassSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:54` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `emitted` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.1% | 1.9ms | 0.0% | 0us | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:157` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `emitted` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:22` |
| 0.1% | 1.9ms | 0.0% | 0us | `emittedBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:72` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.1% | 1.9ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:111` |
| 0.1% | 1.9ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1709` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.1% | 1.8ms | 0.0% | 0us | `contrastRatio` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:85` |
| 0.1% | 1.8ms | 0.0% | 0us | `ensureContrast` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:102` |
| 0.1% | 1.8ms | 0.0% | 0us | `legibleOnEvery` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:559` |
| 0.1% | 1.8ms | 0.0% | 0us | `deriveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:505` |
| 0.1% | 1.8ms | 0.0% | 0us | `textTones` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:545` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `srgbRelativeLuminance` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:68` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:320` |
| 0.1% | 1.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:761` |
| 0.1% | 1.8ms | 0.0% | 0us | `resolveCss` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:736` |
| 0.1% | 1.8ms | 0.0% | 0us | `toHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:43` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:529` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:395` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `separatedSharpSupportBounds` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:72` |
| 0.1% | 1.8ms | 0.0% | 0us | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:41` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `writtenDecimalParts` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:31` |
| 0.1% | 1.8ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:271` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `fromEntries` | `[native code]` |
| 0.1% | 1.8ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1986` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` |
| 0.1% | 1.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` |
| 0.1% | 1.7ms | 0.0% | 0us | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `complete` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `checkFamilyConfigColors` | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.1% | 1.7ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1762` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `endpointRelation` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1628` |
| 0.1% | 1.7ms | 0.0% | 0us | `walk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1757` |
| 0.1% | 1.7ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1764` |
| 0.1% | 1.7ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:106` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `definitions` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.1% | 1.7ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:317` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `toUpperCase` | `[native code]` |
| 0.1% | 1.7ms | 0.0% | 0us | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:114` |
| 0.1% | 1.7ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:120` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:656` |
| 0.1% | 1.7ms | 0.0% | 0us | `parseClassRelationEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1339` |
| 0.1% | 1.7ms | 0.0% | 0us | `parseMarkedClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1307` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `layoutClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 1.7ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:778` |
| 0.1% | 1.7ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:701` |
| 0.1% | 1.7ms | 0.0% | 0us | `finalizeClassSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:813` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `repairClassNoteSeats` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.1% | 1.7ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:533` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `concrete` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1369` |
| 0.1% | 1.7ms | 0.0% | 0us | `markerPaintIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1377` |
| 0.1% | 1.7ms | 0.0% | 0us | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:365` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `entries` | `[native code]` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:18` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:157` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:159` |
| 0.1% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:15` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `fSpan` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/geometry.ts` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:537` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `buildStyleBlock` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:373` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `record` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:285` |
| 0.1% | 1.6ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:96` |
| 0.1% | 1.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:182` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:624` |
| 0.1% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:56` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:257` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `safeCssPaint` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:129` |
| 0.1% | 1.6ms | 0.0% | 0us | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:311` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:102` |
| 0.1% | 1.6ms | 0.0% | 0us | `caseInsensitiveKeywordPattern` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:102` |
| 0.1% | 1.6ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:761` |
| 0.1% | 1.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:173` |
| 0.1% | 1.6ms | 0.0% | 0us | `createPngOutputOptionFieldDescriptors` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:105` |
| 0.1% | 1.6ms | 0.0% | 0us | `Gunzip` | `node:zlib:334` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `Duplex` | `internal:streams/duplex` |
| 0.1% | 1.6ms | 0.0% | 0us | `gunzipSync` | `node:zlib:360` |
| 0.1% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:8` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1705` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `sign` | `[native code]` |
| 0.1% | 1.5ms | 0.0% | 0us | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:102` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:590` |
| 0.1% | 1.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:570` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `createSketchBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `log` | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts` |
| 0.1% | 1.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:7` |
| 0.1% | 1.5ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1746` |
| 0.1% | 1.5ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:322` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `reserve` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.1% | 1.5ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:430` |
| 0.1% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:431` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `cloneObject` | `[native code]` |
| 0.1% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:519` |
| 0.1% | 1.5ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:109` |
| 0.1% | 1.5ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:129` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `sourceTokenAt` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:52` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:496` |
| 0.1% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:597` |
| 0.1% | 1.5ms | 0.0% | 0us | `roleStyleJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:496` |
| 0.1% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:191` |
| 0.1% | 1.5ms | 0.0% | 0us | `styleSpecJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:595` |
| 0.1% | 1.5ms | 0.0% | 0us | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:535` |
| 0.1% | 1.5ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:211` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.1% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:12` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `contextLeaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.1% | 1.5ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:588` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `atan2` | `[native code]` |
| 0.1% | 1.5ms | 0.0% | 0us | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:323` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:355` |
| 0.1% | 1.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:273` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `booleanSchema` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.1% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/createNode.js:5` |
| 0.1% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:4` |
| 0.1% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Collection.js:3` |
| 0.1% | 1.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts:47` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:49` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `create` | `[native code]` |
| 0.1% | 1.5ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:206` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `createOwnedMeasuredRouteContactValidator` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `maxMemberWidth` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.1% | 1.4ms | 0.0% | 0us | `assertFinalClassSharpContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:862` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts` |
| 0.1% | 1.4ms | 0.0% | 0us | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:109` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `escapeXml` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:93` |
| 0.1% | 1.4ms | 0.0% | 0us | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:537` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `classStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.1% | 1.4ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:754` |
| 0.1% | 1.4ms | 0.0% | 0us | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:273` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:692` |
| 0.1% | 1.4ms | 0.0% | 0us | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:692` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `assertMarkerPaint` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.1% | 1.4ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:117` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.1% | 1.4ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:95` |
| 0.1% | 1.4ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:426` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `assertMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `connectorGeometryEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:180` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:160` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `RegExp` | `[native code]` |
| 0.1% | 1.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/zenuml/native-parser.ts:14` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `customTextMeasurementActive` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts` |
| 0.1% | 1.4ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:320` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `seatFinalMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:250` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:759` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:988` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:538` |
| 0.1% | 1.4ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:132` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1093` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `applyFamilyRequestNormalization` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` |
| 0.1% | 1.4ms | 0.0% | 0us | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1018` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `proofRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:64` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `transformPoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts` |
| 0.1% | 1.4ms | 0.0% | 0us | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:350` |
| 0.1% | 1.4ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1040` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:155` |
| 0.1% | 1.4ms | 0.0% | 0us | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:543` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `makeBitMapDescriptor` | `internal:streams/readable` |
| 0.1% | 1.4ms | 0.0% | 0us | `internal:streams/readable` | `internal:streams/readable:50` |
| 0.1% | 1.4ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:600` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `connectorEndpointAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:445` |
| 0.1% | 1.4ms | 0.0% | 0us | `rejectUnknownKeys` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:154` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts` |
| 0.1% | 1.4ms | 0.1% | 1.4ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1990` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:118` |
| 0.0% | 1.4ms | 0.0% | 0us | `authoredClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:131` |
| 0.0% | 1.4ms | 0.0% | 0us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:988` |
| 0.0% | 1.4ms | 0.0% | 0us | `add` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:118` |
| 0.0% | 1.4ms | 0.0% | 0us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1199` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:231` |
| 0.0% | 1.4ms | 0.0% | 0us | `schemaMatchesRuntimeKind` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:39` |
| 0.0% | 1.4ms | 0.0% | 0us | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:465` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/c4/config.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `dereferenceSchema` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/c4/config.ts:91` |
| 0.0% | 1.4ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:75` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `record` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `ownKeys` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:325` |
| 0.0% | 1.4ms | 0.0% | 0us | `graphicalBackendCapabilityClaims` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:267` |
| 0.0% | 1.4ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1684` |
| 0.0% | 1.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:140` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `findIndex` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:782` |
| 0.0% | 1.4ms | 0.0% | 0us | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:194` |
| 0.0% | 1.4ms | 0.0% | 0us | `inspectSecurityTail` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:687` |
| 0.0% | 1.4ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1763` |
| 0.0% | 1.4ms | 0.0% | 0us | `refresh` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:169` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `updateCarrier` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `unsafeActiveCss` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scoreMeasuredRouteCrossings` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `applyReplacements` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:242` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:473` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:395` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `isXmlWhitespace` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:413` |
| 0.0% | 1.3ms | 0.0% | 0us | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:24` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:184` |
| 0.0% | 1.3ms | 0.0% | 0us | `hasOwned` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:11` |
| 0.0% | 1.3ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:190` |
| 0.0% | 1.3ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:139` |
| 0.0% | 1.3ms | 0.0% | 0us | `projectClassPositioned` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:22` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `String` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:114` |
| 0.0% | 1.3ms | 0.0% | 0us | `arrowMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:34` |
| 0.0% | 1.3ms | 0.0% | 0us | `flowchartMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:80` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:165` |
| 0.0% | 1.3ms | 0.0% | 0us | `string` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:138` |
| 0.0% | 1.3ms | 0.0% | 0us | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:665` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `unsafeActiveCssScan` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:618` |
| 0.0% | 1.3ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:536` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:193` |
| 0.0% | 1.3ms | 0.0% | 0us | `finalizeFlatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:657` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `assertFinalBoundaryContacts` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:359` |
| 0.0% | 1.3ms | 0.0% | 0us | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:975` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1364` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `normalizedReference` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:579` |
| 0.0% | 1.3ms | 0.0% | 0us | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:989` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `work` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `unsafeCssReferences` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:603` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1282` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:702` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `cssPaintDefinitions` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `receiptOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:762` |
| 0.0% | 1.3ms | 0.0% | 0us | `snapshotCapabilityCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1559` |
| 0.0% | 1.3ms | 0.0% | 0us | `internal:errors` | `internal:errors:2` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `makeSafe` | `internal:primordials` |
| 0.0% | 1.3ms | 0.0% | 0us | `internal:streams/destroy` | `internal:streams/destroy:2` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:97` |
| 0.0% | 1.3ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:76` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1718` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:122` |
| 0.0% | 1.3ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:705` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:732` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:369` |
| 0.0% | 1.3ms | 0.0% | 0us | `renderedSvgDigest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:61` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:148` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:164` |
| 0.0% | 1.3ms | 0.0% | 0us | `retainedPositionedScene` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:61` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `createEmissionContext` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `createSceneWriteCapture` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:129` |
| 0.0% | 1.3ms | 0.0% | 0us | `snapshotCapabilityCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1554` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:813` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:530` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `cloneValue` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:389` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `outlineKey` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parseMarkedClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1314` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:4` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/block/markers.ts:10` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:143` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/common/seq.js:4` |
| 0.0% | 1.3ms | 0.0% | 0us | `render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:145` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:48` |
| 0.0% | 1.3ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1032` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:50` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `admitBackendSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/external-data-snapshot.ts:17` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:349` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1465` |
| 0.0% | 1.3ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:162` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `isWhitespace` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:25` |
| 0.0% | 1.3ms | 0.0% | 0us | `paintAttribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:493` |
| 0.0% | 1.3ms | 0.0% | 0us | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:515` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/addPairToJSMap.js:4` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:5` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:13` |
| 0.0% | 1.3ms | 0.0% | 0us | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:209` |
| 0.0% | 1.3ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:592` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connectorTerminalStrokeLosses` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:87` |
| 0.0% | 1.3ms | 0.0% | 0us | `validatePoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:465` |
| 0.0% | 1.3ms | 0.0% | 0us | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:436` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:181` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:615` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `finalizeClassSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:815` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:252` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `repairClassAnnotationSeats` | `/tmp/pr449-main-integration-20261029-762/src/class/annotation-seats.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:15` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:512` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:725` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `registrationIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `registerCanonicalStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:235` |
| 0.0% | 1.3ms | 0.0% | 0us | `registerBuiltInStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:294` |
| 0.0% | 1.3ms | 0.0% | 0us | `replaceSvgRootStartTag` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:319` |
| 0.0% | 1.3ms | 0.0% | 0us | `svgStyleRanges` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:294` |
| 0.0% | 1.3ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:178` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/requirement/tokens.ts:64` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/requirement/tokens.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `internal:streams/legacy` | `internal:streams/legacy:2` |
| 0.0% | 1.3ms | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1682` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `admitRenderContractDigestInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `renderContractDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1118` |
| 0.0% | 1.3ms | 0.0% | 0us | `markerPaintIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1356` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1781` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1083` |
| 0.0% | 1.3ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:615` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:162` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `isCombiningMark` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `measureText` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:188` |
| 0.0% | 1.3ms | 0.0% | 0us | `measureTextWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:206` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` |
| 0.0% | 1.3ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:420` |
| 0.0% | 1.3ms | 0.0% | 0us | `getCharWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:88` |
| 0.0% | 1.3ms | 0.0% | 0us | `advance` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` |
| 0.0% | 1.3ms | 0.0% | 0us | `inspectScenePaintGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:154` |
| 0.0% | 1.3ms | 0.0% | 0us | `beginSceneWriteInspection` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:114` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `begin` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:526` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:725` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:760` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `canonicalExtensionId` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `registerBuiltInStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:291` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:101` |
| 0.0% | 1.2ms | 0.0% | 0us | `sceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:5` |
| 0.0% | 1.2ms | 0.0% | 0us | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:374` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` |
| 0.0% | 1.2ms | 0.0% | 0us | `relationAccessibility` | `/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/hybrid-backend.ts:193` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `primitiveCapabilityClaimKey` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:322` |
| 0.0% | 1.2ms | 0.0% | 0us | `createSketchBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:547` |
| 0.0% | 1.2ms | 0.0% | 0us | `graphicalBackendCapabilityClaims` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:271` |
| 0.0% | 1.2ms | 0.0% | 0us | `validatePrimitiveCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:333` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:462` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts:2165` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:773` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:390` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `min` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `shortenMeasuredRoutes` | `/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:96` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:620` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `configSpacing` | `/tmp/pr449-main-integration-20261029-762/src/shared/config-spacing.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `normalizeRequest` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:17` |
| 0.0% | 1.2ms | 0.0% | 0us | `applyFamilyRequestNormalization` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1042` |
| 0.0% | 1.2ms | 0.0% | 0us | `resolveClassRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:105` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1393` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1392` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `nodePaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:638` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `extractClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:719` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector/labels/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `lineHasInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:545` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/pathfinder.ts:35` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `hypot` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1989` |
| 0.0% | 1.2ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:314` |
| 0.0% | 1.2ms | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:505` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1755` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pose` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:335` |
| 0.0% | 1.2ms | 0.0% | 0us | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:358` |
| 0.0% | 1.2ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:549` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringifyString.js:4` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringify.js:6` |
| 0.0% | 1.2ms | 0.0% | 0us | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:274` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` |
| 0.0% | 1.2ms | 0.0% | 0us | `verifyNoExternalRefs` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:701` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:11` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `unsafeCssReferences` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:601` |
| 0.0% | 1.2ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:161` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:6` |
| 0.0% | 1.2ms | 0.0% | 0us | `inspectSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:675` |
| 0.0% | 1.2ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1049` |
| 0.0% | 1.2ms | 0.0% | 0us | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:11` |
| 0.0% | 1.2ms | 0.0% | 0us | `classTerminalLead` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:215` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:693` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `classRelationshipTerminalClearance` | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:59` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:106` |
| 0.0% | 1.2ms | 0.0% | 0us | `declareFamilyScenePrimitiveEvidence` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:247` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `positionFamily` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1384` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:845` |
| 0.0% | 1.2ms | 0.0% | 0us | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:470` |
| 0.0% | 1.2ms | 0.0% | 0us | `freezeBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:403` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:6` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:28` |
| 0.0% | 1.2ms | 0.0% | 0us | `snapshotBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:330` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `createImmutableParts` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:340` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:729` |
| 0.0% | 1.2ms | 0.0% | 0us | `terminalMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:60` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1231` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:255` |
| 0.0% | 1.2ms | 0.0% | 0us | `markerPaintIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1360` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1354` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:191` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1091` |
| 0.0% | 1.2ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1973` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `mixedChannels` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `ensureContrast` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:120` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `emittedEndpointMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:392` |
| 0.0% | 1.2ms | 0.0% | 0us | `deriveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:517` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `finalizeClassSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1374` |
| 0.0% | 1.2ms | 0.0% | 0us | `evaluateExtensionCompatibility` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:120` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `semVerSatisfies` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `parseClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1292` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `match` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 0us | `parseClassReference` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:186` |
| 0.0% | 1.2ms | 0.0% | 0us | `parseMarkerlessClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1415` |
| 0.0% | 1.2ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` |
| 0.0% | 1.2ms | 0.0% | 0us | `parseClassInteractionWithAuthored` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:934` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderPositionedMermaidSVG` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parseProtected` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `renderRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:560` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:560` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `createWrittenPolyline` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:33` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:32` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1046` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateAggregateReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1525` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1624` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:621` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `classNativeMarkerMinimums` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:175` |
| 0.0% | 1.2ms | 0.0% | 0us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1190` |
| 0.0% | 1.2ms | 0.0% | 0us | `parseClassInteractionWithAuthored` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:915` |
| 0.0% | 1.2ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:173` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `decodeWithTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:442` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:266` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:214` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1756` |
| 0.0% | 1.2ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:374` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:92` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `sceneGroupOpacity` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:108` |
| 0.0% | 1.2ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:180` |
| 0.0% | 1.2ms | 0.0% | 0us | `possibleShapeFill` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:127` |
| 0.0% | 1.1ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:633` |
| 0.0% | 1.1ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:199` |
| 0.0% | 1.1ms | 0.0% | 0us | `boundedImmutableJsonSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1243` |
| 0.0% | 1.1ms | 0.0% | 0us | `admitRenderOptionsInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1307` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1709` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1260` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:350` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts:257` |
| 0.0% | 1.1ms | 0.0% | 0us | `classRelationshipPaintBoxes` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:343` |
| 0.0% | 1.1ms | 0.0% | 0us | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:689` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1065` |
| 0.0% | 1.1ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:402` |
| 0.0% | 1.1ms | 0.0% | 0us | `has` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:10` |
| 0.0% | 1.1ms | 0.0% | 0us | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:25` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1787` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `exec` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `splitHeaderStatement` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:119` |
| 0.0% | 1.1ms | 0.0% | 0us | `normalizeMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:663` |
| 0.0% | 1.1ms | 0.0% | 0us | `mermaidFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:148` |
| 0.0% | 1.1ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:227` |
| 0.0% | 1.1ms | 0.0% | 0us | `normalizeMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:665` |
| 0.0% | 1.1ms | 0.0% | 0us | `compareCodePointStrings` | `/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts:3` |
| 0.0% | 1.1ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:643` |
| 0.0% | 1.1ms | 0.0% | 0us | `detectRegisteredFamilyDescriptorFromFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2083` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1739` |
| 0.0% | 1.1ms | 0.0% | 0us | `classifyMermaidFamilyDescriptorFromFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/family-detection.ts:39` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `inverseMatrix` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:25` |
| 0.0% | 1.1ms | 0.0% | 0us | `detectInstalledFamilyDescriptorFromFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts:60` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:220` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:520` |
| 0.0% | 1.1ms | 0.0% | 0us | `NativeResults` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:21` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `createMeasuredLayoutCache` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:63` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered.ts:16` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:312` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:417` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:51` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:58` |
| 0.0% | 1.1ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:58` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `read` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:64` |
| 0.0% | 1.1ms | 0.0% | 0us | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:134` |
| 0.0% | 1.1ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:716` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:776` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:662` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorInlineLabelSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1008` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:10` |
| 0.0% | 1.1ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:829` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `decodeXmlReferences` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:661` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `hasDisplayedText` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:3` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:78` |
| 0.0% | 1.1ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:64` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `bisector` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:50` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:5` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:120` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:552` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1856` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `descriptorOwnsDetectionLine` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2072` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `xmlHasColon` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:361` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:15` |
| 0.0% | 1.1ms | 0.0% | 0us | `node:zlib` | `node:zlib:161` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:661` |
| 0.0% | 1.1ms | 0.0% | 0us | `classStatementEnds` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:669` |
| 0.0% | 1.1ms | 0.0% | 0us | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:49` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:386` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorTerminalStrokeLosses` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:85` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1351` |
| 0.0% | 1.1ms | 0.0% | 0us | `executionCapabilityDecision` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1449` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `executionCapabilityKey` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1546` |
| 0.0% | 1.1ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:158` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `sourceSlice` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:55` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1770` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:43` |
| 0.0% | 1.1ms | 0.0% | 0us | `serializeMarkerResource` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:141` |
| 0.0% | 1.1ms | 0.0% | 0us | `geometryElements` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:66` |
| 0.0% | 1.1ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:581` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `document/resources/serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts:32` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:99` |
| 0.0% | 1.1ms | 0.0% | 0us | `hooks` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:507` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `requiredBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1485` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1670` |
| 0.0% | 1.1ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:138` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:138` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `detectsQuadrantFamily` | `/tmp/pr449-main-integration-20261029-762/src/shared/builtin-family-detection.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:96` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:126` |
| 0.0% | 1.1ms | 0.0% | 0us | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:622` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `connector/subpaths/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:660` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:3` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:5` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:156` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:136` |
| 0.0% | 1.0ms | 0.0% | 0us | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:771` |
| 0.0% | 1.0ms | 0.0% | 0us | `retainClassRectangleContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:136` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:284` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `defineProperty` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `compare` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:33` |
| 0.0% | 1.0ms | 0.0% | 0us | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:35` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:286` |
| 0.0% | 1.0ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:127` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `overlaps` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1227` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `createHash` | `node:crypto` |
| 0.0% | 1.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:26` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:698` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:527` |
| 0.0% | 1.0ms | 0.0% | 0us | `hooks` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:508` |
| 0.0% | 1.0ms | 0.0% | 0us | `terminalMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:58` |
| 0.0% | 1.0ms | 0.0% | 0us | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:36` |
| 0.0% | 1.0ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:822` |
| 0.0% | 1.0ms | 0.0% | 0us | `nativeOrEmulated` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:448` |
| 0.0% | 1.0ms | 0.0% | 0us | `transformAttribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:531` |
| 0.0% | 1.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:57` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `expandInlineNamespaceStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:36` |
| 0.0% | 1.0ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:704` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1860` |
| 0.0% | 1.0ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:229` |
| 0.0% | 1.0ms | 0.0% | 0us | `assertKnownConnectorFields` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:158` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `isArray` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `readDefinitions` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:466` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1175` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` |
| 0.0% | 1.0ms | 0.0% | 0us | `createTextMeasurementExecution` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:70` |
| 0.0% | 1.0ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1553` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `snapshotTextMeasurementProfile` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `record` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:261` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `viewportBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1481` |
| 0.0% | 1.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:115` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:336` |
| 0.0% | 1.0ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:578` |
| 0.0% | 1.0ms | 0.0% | 0us | `string` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:140` |
| 0.0% | 1.0ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:678` |
| 0.0% | 1.0ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:556` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `sourceIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `rootPreludeMatches` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:220` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `rootMatches` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:448` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `receiptOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:757` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:427` |
| 0.0% | 1.0ms | 0.0% | 0us | `gzipSync` | `node:zlib:360` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Duplex` | `internal:streams/duplex:16` |
| 0.0% | 1.0ms | 0.0% | 0us | `Gzip` | `node:zlib:328` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:13` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `toFinite` | `/tmp/pr449-main-integration-20261029-762/src/agent/types.ts:1604` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:639` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/omap.js:7` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:14` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1244` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1095` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateUnitVector` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 987us | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:13` |
| 0.0% | 987us | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:4` |
| 0.0% | 983us | 0.0% | 0us | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:285` |
| 0.0% | 983us | 0.0% | 983us | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` |
| 0.0% | 983us | 0.0% | 0us | `escapeDisplayAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:115` |
| 0.0% | 981us | 0.0% | 0us | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:474` |
| 0.0% | 981us | 0.0% | 981us | `get` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` |
| 0.0% | 981us | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:197` |
| 0.0% | 981us | 0.0% | 981us | `resolveCss` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:725` |
| 0.0% | 979us | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:729` |
| 0.0% | 979us | 0.0% | 979us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 973us | 0.0% | 973us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:426` |
| 0.0% | 969us | 0.0% | 969us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1720` |

## Function Details

### `anonymous`
`[native code]` | Self: 18.8% (269.1ms) | Total: 32.2% (460.1ms) | Samples: 32

**Called by:**
- `require` (106)
- `node:stream` (8)
- `node:zlib` (8)
- `internal:stream` (7)
- `internal:streams/compose` (6)
- `internal:streams/pipeline` (6)
- `internal:streams/duplex` (4)
- `node:fs` (1)
- `internal:streams/destroy` (1)
- `internal:streams/legacy` (1)
- `internal:errors` (1)

**Calls:**
- `(anonymous)` (15)
- `(anonymous)` (9)
- `node:stream` (8)
- `internal:stream` (7)
- `(anonymous)` (6)
- `internal:streams/compose` (6)
- `internal:streams/pipeline` (6)
- `internal:streams/duplex` (4)
- `(anonymous)` (4)
- `(anonymous)` (4)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:streams/destroy` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:streams/readable` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:errors` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:primordials` (1)
- `internal:streams/legacy` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:fs/binding` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `_inherits`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 6.5% (92.9ms) | Total: 6.5% (92.9ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `decodeBase64`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:24` | Self: 5.1% (73.5ms) | Total: 5.1% (73.5ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:204` | Self: 3.9% (56.9ms) | Total: 3.9% (56.9ms) | Samples: 3

**Called by:**
- `filter` (3)

### `freeze`
`[native code]` | Self: 2.3% (33.8ms) | Total: 2.3% (33.8ms) | Samples: 22

**Called by:**
- `resolveRenderRequestForExecution` (9)
- `leaf` (3)
- `visit` (2)
- `snapshotScenePrimitiveCell` (2)
- `freezeDescriptor` (1)
- `qualify` (1)
- `geometryAttributes` (1)
- `freezeTransport` (1)
- `finish` (1)
- `visit` (1)

### `add`
`[native code]` | Self: 1.2% (17.4ms) | Total: 1.2% (17.4ms) | Samples: 12

**Called by:**
- `verifyDocumentEnvelope` (9)
- `visit` (3)

### `map`
`[native code]` | Self: 1.2% (17.1ms) | Total: 23.9% (342.0ms) | Samples: 10

**Called by:**
- `expandLocalReferences` (12)
- `writeSceneNode` (10)
- `cloneValue` (9)
- `render` (5)
- `(anonymous)` (4)
- `runBackendConformance` (4)
- `(module)` (3)
- `prepareMarkerTerminals` (3)
- `captureFields` (3)
- `buildClassEndpointMarkerTemplates` (2)
- `transformSvgCssValues` (2)
- `projectClassPositioned` (2)
- `projectClassPositioned` (2)
- `visit` (1)
- `addClassSvgNumbers` (1)
- `flatIntoArrayWithCallback` (1)
- `(module)` (1)
- `roleStyleJsonSchema` (1)
- `caseInsensitiveKeywordPattern` (1)
- `(module)` (1)
- `layoutLayeredGraph` (1)
- `connector` (1)
- `(module)` (1)
- `layoutMeasuredForest` (1)
- `readClassStatements` (1)
- `styleSpecJsonSchema` (1)
- `toHex` (1)
- `deriveConnectorTerminalProjection` (1)
- `writeSceneNode` (1)
- `createPngOutputOptionFieldDescriptors` (1)
- `(module)` (1)
- `(module)` (1)
- `classOwnedSurfaceViolations` (1)
- `createRenderOutputDescriptors` (1)
- `markerBoundsAt` (1)
- `snapshotBackendCapabilities` (1)
- `(anonymous)` (1)
- `compareCodePointStrings` (1)
- `assertFinalBoundaryContacts` (1)
- `pointsBounds` (1)
- `(anonymous)` (1)
- `retainClassRectangleContacts` (1)

**Calls:**
- `(anonymous)` (12)
- `(anonymous)` (10)
- `(anonymous)` (9)
- `(anonymous)` (4)
- `(anonymous)` (4)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `cloneValue` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `indentLines` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `caseInsensitiveKeywordPattern` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `replace` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `stringify`
`[native code]` | Self: 1.0% (15.0ms) | Total: 1.0% (15.0ms) | Samples: 11

**Called by:**
- `include` (3)
- `solidInteriors` (2)
- `validateNode` (1)
- `solidInteriors` (1)
- `renderedSvgDigest` (1)
- `(module)` (1)
- `validateNode` (1)
- `validateNode` (1)

### `copyDataProperties`
`[native code]` | Self: 1.0% (14.3ms) | Total: 1.0% (14.3ms) | Samples: 10

**Called by:**
- `completeBuiltinDescriptor` (2)
- `group` (1)
- `deriveConnectorTerminalProjection` (1)
- `text` (1)
- `leaf` (1)
- `deriveConnectorTerminalProjection` (1)
- `terminalMarker` (1)
- `terminalMarker` (1)
- `receiptOf` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:220` | Self: 0.9% (14.2ms) | Total: 0.9% (14.2ms) | Samples: 7

**Called by:**
- `visit` (7)

### `apply`
`[native code]` | Self: 0.9% (14.0ms) | Total: 0.9% (14.0ms) | Samples: 10

**Called by:**
- `visit` (1)
- `visit` (1)
- `visit` (1)
- `has` (1)
- `visit` (1)
- `string` (1)
- `hasOwned` (1)
- `visit` (1)
- `string` (1)
- `(module)` (1)

### `filter`
`[native code]` | Self: 0.9% (13.4ms) | Total: 5.2% (74.9ms) | Samples: 3

**Called by:**
- `expandLocalReferences` (3)
- `normalizeSource` (2)
- `validateDescriptor` (1)
- `validate` (1)
- `parseClassDiagram` (1)
- `freezeDescriptor` (1)

**Calls:**
- `(anonymous)` (3)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `schemaMatchesRuntimeKind` (1)

### `connectorGeometryEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:179` | Self: 0.7% (10.4ms) | Total: 0.7% (10.4ms) | Samples: 6

**Called by:**
- `connector` (6)

### `every`
`[native code]` | Self: 0.7% (10.4ms) | Total: 1.5% (21.7ms) | Samples: 6

**Called by:**
- `every` (5)
- `finite` (1)
- `validateConnectorProjectionConsistency` (1)
- `renderPositionedWithTextMeasurement` (1)
- `markerBoundsAt` (1)
- `(anonymous)` (1)
- `evaluateExtensionCompatibility` (1)
- `preparePixelText` (1)
- `add` (1)
- `readClassStatements` (1)

**Calls:**
- `every` (5)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:30` | Self: 0.7% (10.1ms) | Total: 0.7% (10.1ms) | Samples: 7

**Called by:**
- `attribute` (7)

### `getOwnPropertyDescriptor`
`[native code]` | Self: 0.7% (10.0ms) | Total: 0.7% (10.0ms) | Samples: 7

**Called by:**
- `visit` (7)

### `boundedUtf8ByteLength`
`/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:6` | Self: 0.6% (8.6ms) | Total: 0.6% (8.6ms) | Samples: 5

**Called by:**
- `visit` (5)

### `get`
`[native code]` | Self: 0.5% (8.4ms) | Total: 0.5% (8.4ms) | Samples: 6

**Called by:**
- `visit` (4)
- `validateNode` (1)
- `(anonymous)` (1)

### `typedArrayViewLength`
`[native code]` | Self: 0.5% (8.2ms) | Total: 0.5% (8.2ms) | Samples: 4

**Called by:**
- `arrayIteratorNextHelper` (4)

### `for`
`[native code]` | Self: 0.5% (7.8ms) | Total: 0.5% (7.8ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `has`
`[native code]` | Self: 0.5% (7.6ms) | Total: 0.5% (7.6ms) | Samples: 6

**Called by:**
- `verifyDocumentEnvelope` (2)
- `inspectAttributeSecurity` (1)
- `rejectUnknownKeys` (1)
- `validateDescriptor` (1)
- `scanStartTags` (1)

### `boundedUtf8ByteLength`
`/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` | Self: 0.4% (6.7ms) | Total: 0.4% (6.7ms) | Samples: 5

**Called by:**
- `validateNodeSerialization` (5)

### `xmlSlice`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` | Self: 0.4% (6.5ms) | Total: 0.4% (6.5ms) | Samples: 3

**Called by:**
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (1)

### `validateStyleSpec`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:422` | Self: 0.4% (5.9ms) | Total: 0.4% (5.9ms) | Samples: 1

**Called by:**
- `registerBuiltInStyle` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.4% (5.8ms) | Total: 0.4% (5.8ms) | Samples: 3

**Called by:**
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (1)

### `writeSync`
`[native code]` | Self: 0.4% (5.7ms) | Total: 0.4% (5.7ms) | Samples: 4

**Called by:**
- `processChunkSync` (4)

### `set`
`[native code]` | Self: 0.3% (5.6ms) | Total: 0.3% (5.6ms) | Samples: 4

**Called by:**
- `visit` (2)
- `visit` (1)
- `leaf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:333` | Self: 0.3% (5.5ms) | Total: 1.9% (28.4ms) | Samples: 3

**Called by:**
- `forEach` (16)

**Calls:**
- `walk` (13)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.3% (5.5ms) | Total: 0.3% (5.5ms) | Samples: 4

**Called by:**
- `positionedPaintCertification` (4)

### `flowchartFamilyHooks`
`/tmp/pr449-main-integration-20261029-762/src/agent/families-source-hooks.ts` | Self: 0.3% (5.2ms) | Total: 0.3% (5.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:123` | Self: 0.3% (5.0ms) | Total: 0.4% (6.4ms) | Samples: 4

**Called by:**
- `visit` (5)

**Calls:**
- `apply` (1)

### `boundedUtf8ByteLength`
`/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` | Self: 0.3% (5.0ms) | Total: 0.3% (5.0ms) | Samples: 3

**Called by:**
- `validateNodeSerialization` (2)
- `visit` (1)

### `xmlAsciiLetter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` | Self: 0.3% (4.6ms) | Total: 0.3% (4.6ms) | Samples: 3

**Called by:**
- `xmlNameCharacter` (2)
- `readXmlNameEnd` (1)

### `@lazy`
`[native code]` | Self: 0.3% (4.6ms) | Total: 0.3% (4.6ms) | Samples: 1

**Called by:**
- `internal:fs/binding` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:29` | Self: 0.3% (4.4ms) | Total: 0.3% (4.4ms) | Samples: 1

**Called by:**
- `map` (1)

### `some`
`[native code]` | Self: 0.3% (4.4ms) | Total: 0.8% (12.5ms) | Samples: 4

**Called by:**
- `validateBackendCapabilities` (2)
- `checkInertGroup` (1)
- `layoutMeasuredForest` (1)
- `nonPainting` (1)
- `some` (1)
- `detectorClaims` (1)
- `validateDescriptor` (1)
- `certifyNativePaint` (1)
- `assertClassMarkerMeaning` (1)

**Calls:**
- `(anonymous)` (1)
- `some` (1)
- `lineHasInk` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:524` | Self: 0.3% (4.3ms) | Total: 0.3% (5.7ms) | Samples: 1

**Called by:**
- `validateNode` (2)

**Calls:**
- `validatePoints` (1)

### `replace`
`[native code]` | Self: 0.3% (4.3ms) | Total: 0.3% (5.5ms) | Samples: 3

**Called by:**
- `map` (1)
- `resolveCss` (1)
- `readClassStatements` (1)
- `group` (1)

**Calls:**
- `(anonymous)` (1)

### `sharpContactsClear`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:371` | Self: 0.2% (4.2ms) | Total: 0.3% (5.5ms) | Samples: 2

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (3)

**Calls:**
- `min` (1)

### `imul`
`[native code]` | Self: 0.2% (4.2ms) | Total: 0.2% (4.2ms) | Samples: 2

**Called by:**
- `(module)` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.2% (4.1ms) | Total: 0.2% (4.1ms) | Samples: 3

**Called by:**
- `validateSceneDocument` (3)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` | Self: 0.2% (4.1ms) | Total: 0.2% (4.1ms) | Samples: 3

**Called by:**
- `layoutLayeredGraph` (3)

### `parse`
`[native code]` | Self: 0.2% (4.0ms) | Total: 0.2% (4.0ms) | Samples: 3

**Called by:**
- `(module)` (3)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:221` | Self: 0.2% (4.0ms) | Total: 24.8% (354.0ms) | Samples: 3

**Called by:**
- `visit` (86)
- `visit` (84)
- `admitSceneDocumentWith` (75)

**Calls:**
- `visit` (102)
- `visit` (86)
- `visit` (7)
- `visit` (5)
- `visit` (5)
- `visit` (5)
- `visit` (5)
- `visit` (3)
- `visit` (3)
- `visit` (3)
- `visit` (2)
- `visit` (2)
- `visit` (2)
- `visit` (2)
- `visit` (2)
- `visit` (1)
- `visit` (1)
- `visit` (1)
- `visit` (1)
- `visit` (1)
- `visit` (1)
- `visit` (1)
- `visit` (1)

### `sourceIndexOf`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` | Self: 0.2% (3.8ms) | Total: 0.2% (3.8ms) | Samples: 3

**Called by:**
- `scanTagEnd` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `test`
`[native code]` | Self: 0.2% (3.7ms) | Total: 0.3% (4.9ms) | Samples: 3

**Called by:**
- `paintedStrokeExtent` (2)
- `(anonymous)` (1)
- `checkInertGroup` (1)

**Calls:**
- `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/` (1)

### `Map`
`[native code]` | Self: 0.2% (3.7ms) | Total: 0.2% (3.7ms) | Samples: 3

**Called by:**
- `projectClassPositioned` (1)
- `visit` (1)
- `declareFamilyScenePrimitiveEvidence` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:210` | Self: 0.2% (3.6ms) | Total: 0.9% (13.7ms) | Samples: 2

**Called by:**
- `visit` (6)
- `visit` (3)

**Calls:**
- `getOwnPropertyDescriptor` (7)

### `Set`
`[native code]` | Self: 0.2% (3.6ms) | Total: 0.2% (3.6ms) | Samples: 3

**Called by:**
- `rejectUnknownKeys` (2)
- `validateDescriptor` (1)

### `xmlSlice`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` | Self: 0.2% (3.5ms) | Total: 0.2% (3.5ms) | Samples: 3

**Called by:**
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (1)

### `append`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.2% (3.4ms) | Total: 0.2% (3.4ms) | Samples: 2

**Called by:**
- `leaf` (2)

### `includes`
`[native code]` | Self: 0.2% (3.4ms) | Total: 0.2% (3.4ms) | Samples: 3

**Called by:**
- `validateNode` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)

### `indentLines`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:744` | Self: 0.2% (3.4ms) | Total: 0.2% (3.4ms) | Samples: 3

**Called by:**
- `(anonymous)` (2)
- `map` (1)

### `compound`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.2% (3.3ms) | Total: 0.2% (3.3ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (2)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:581` | Self: 0.2% (3.3ms) | Total: 0.2% (3.3ms) | Samples: 1

**Called by:**
- `resolvedColorValue` (1)

### `renderMermaidSVGWithReceipt`
`/tmp/pr449-main-integration-20261029-762/src/index.ts` | Self: 0.2% (3.3ms) | Total: 0.2% (3.3ms) | Samples: 1

**Called by:**
- `withRenderStageObserver` (1)

### `textPaints`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:119` | Self: 0.2% (3.3ms) | Total: 0.2% (3.3ms) | Samples: 1

**Called by:**
- `nonPainting` (1)

### `writtenSegmentEntersBox`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:95` | Self: 0.2% (3.2ms) | Total: 0.4% (5.8ms) | Samples: 2

**Called by:**
- `writtenClassRoundedHit` (4)

**Calls:**
- `compareSvgSum` (2)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1006` | Self: 0.2% (3.2ms) | Total: 0.2% (3.2ms) | Samples: 2

**Called by:**
- `certifyNativePaint` (1)
- `assertClassMarkerMeaning` (1)

### `trim`
`[native code]` | Self: 0.2% (3.2ms) | Total: 0.2% (3.2ms) | Samples: 2

**Called by:**
- `parseClassRelationEndpoints` (1)
- `tryParseCssColor` (1)

### `safeRoleColor`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:296` | Self: 0.2% (3.2ms) | Total: 0.2% (3.2ms) | Samples: 1

**Called by:**
- `validateRoleStyleRecord` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:606` | Self: 0.2% (3.1ms) | Total: 0.2% (3.1ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `slice`
`[native code]` | Self: 0.2% (3.1ms) | Total: 0.2% (3.1ms) | Samples: 2

**Called by:**
- `tryParseCssColor` (1)
- `replaceSvgRootStartTag` (1)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.1% (2.8ms) | Total: 0.1% (2.8ms) | Samples: 2

**Called by:**
- `markerBoundsAt` (1)
- `lineStrokeBox` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:175` | Self: 0.1% (2.7ms) | Total: 0.3% (4.2ms) | Samples: 2

**Called by:**
- `visit` (3)

**Calls:**
- `apply` (1)

### `lineStrokeBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.1% (2.7ms) | Total: 0.1% (2.7ms) | Samples: 2

**Called by:**
- `strokedBox` (2)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:232` | Self: 0.1% (2.7ms) | Total: 0.4% (6.5ms) | Samples: 2

**Called by:**
- `visit` (5)

**Calls:**
- `add` (3)

### `values`
`[native code]` | Self: 0.1% (2.7ms) | Total: 0.1% (2.7ms) | Samples: 2

**Called by:**
- `(module)` (1)
- `deepFreeze` (1)

### `node:crypto`
`node:crypto:99` | Self: 0.1% (2.6ms) | Total: 0.1% (2.6ms) | Samples: 1

### `parseEncodeTrie`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:45` | Self: 0.1% (2.6ms) | Total: 0.1% (2.6ms) | Samples: 2

**Called by:**
- `(module)` (2)

### `Segmenter`
`[native code]` | Self: 0.1% (2.6ms) | Total: 0.1% (2.6ms) | Samples: 2

**Called by:**
- `(module)` (2)

### `connectorUnitTangent`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:21` | Self: 0.1% (2.6ms) | Total: 0.1% (2.6ms) | Samples: 1

**Called by:**
- `connectorContourSemantics` (1)

### `max`
`[native code]` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 2

**Called by:**
- `rectOverlap` (1)
- `(anonymous)` (1)

### `push`
`[native code]` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 2

**Called by:**
- `validateNode` (1)
- `applyReplacements` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 2

**Called by:**
- `map` (1)
- `parseClassDiagram` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:230` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 2

**Called by:**
- `visit` (1)
- `visit` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:160` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 2

**Called by:**
- `visit` (2)

### `join`
`[native code]` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 2

**Called by:**
- `deriveConnectorTerminalProjection` (1)
- `serializeSceneNode` (1)

### `compareSvgSum`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:38` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 2

**Called by:**
- `writtenSegmentEntersBox` (2)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:151` | Self: 0.1% (2.4ms) | Total: 0.2% (3.8ms) | Samples: 2

**Called by:**
- `visit` (3)

**Calls:**
- `set` (1)

### `evaluateExtensionCompatibility`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:107` | Self: 0.1% (2.4ms) | Total: 0.1% (2.4ms) | Samples: 2

**Called by:**
- `createExtensionIdentity` (2)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:317` | Self: 0.1% (2.4ms) | Total: 0.1% (2.4ms) | Samples: 2

**Called by:**
- `validateNode` (2)

### `emitted`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:21` | Self: 0.1% (2.4ms) | Total: 0.1% (2.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `escapeAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` | Self: 0.1% (2.4ms) | Total: 0.1% (2.4ms) | Samples: 2

**Called by:**
- `attribute` (2)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:169` | Self: 0.1% (2.3ms) | Total: 0.1% (2.3ms) | Samples: 2

**Called by:**
- `certifyNativePaint` (2)

### `originalNativeDrawingOf`
`/tmp/pr449-main-integration-20261029-762/src/scene/drawing.ts` | Self: 0.1% (2.3ms) | Total: 0.1% (2.3ms) | Samples: 1

**Called by:**
- `retainedNativeDrawing` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:83` | Self: 0.1% (2.2ms) | Total: 0.1% (2.2ms) | Samples: 1

**Called by:**
- `pathBounds` (1)

### `detectsJourneyFamily`
`/tmp/pr449-main-integration-20261029-762/src/shared/builtin-family-detection.ts` | Self: 0.1% (2.2ms) | Total: 0.1% (2.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `scoreMeasuredRouteCrossingsWithAdmission`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 1

**Called by:**
- `validate` (1)

### `separatedSharpSupportBounds`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:68` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 1

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 2

**Called by:**
- `attribute` (1)
- `assertClassMarkerMeaning` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1854` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 1

**Called by:**
- `find` (1)

### `concat`
`[native code]` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 1

**Called by:**
- `zlibBufferSync` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:594` | Self: 0.1% (2.0ms) | Total: 0.1% (2.0ms) | Samples: 1

**Called by:**
- `clear` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2361` | Self: 0.1% (2.0ms) | Total: 0.1% (2.0ms) | Samples: 2

**Called by:**
- `positionedPaintCertification` (2)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:324` | Self: 0.1% (2.0ms) | Total: 0.1% (2.0ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `clear`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:379` | Self: 0.1% (2.0ms) | Total: 0.1% (2.0ms) | Samples: 1

**Called by:**
- `seatMeasuredMarkers` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` | Self: 0.1% (2.0ms) | Total: 0.1% (2.0ms) | Samples: 1

**Called by:**
- `seatFinalMeasuredMarkers` (1)

### `selfContact`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `validate` (1)

### `writtenPoint`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `classOwnedSurfaceViolations` (1)

### `emitted`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `compareClassSvgSum` (1)

### `emitted`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:22` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `emittedBox` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:155` | Self: 0.1% (1.9ms) | Total: 0.2% (3.3ms) | Samples: 1

**Called by:**
- `classOwnedSurfaceViolations` (2)

**Calls:**
- `writtenSegmentEntersBox` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `some` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `filter` (1)

### `srgbRelativeLuminance`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:68` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `contrastRatio` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:320` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `connector` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:529` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:395` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `measureClassCards` (1)

### `separatedSharpSupportBounds`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:72` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `writtenDecimalParts`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:31` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `compareSvgSum` (1)

### `fromEntries`
`[native code]` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `snapshotScenePrimitiveCell` (1)

### `assessFamilyLayout`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `assessRenderedLayoutHardViolations` (1)

### `complete`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `checkFamilyConfigColors`
`/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `endpointRelation`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1628` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `walk` (1)

### `definitions`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `toUpperCase`
`[native code]` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `pathBounds` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:23` | Self: 0.1% (1.7ms) | Total: 1.1% (17.0ms) | Samples: 1

**Calls:**
- `next` (3)
- `arrayIteratorNextHelper` (2)
- `imul` (2)
- `values` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:656` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `color` (1)

### `layoutClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `layout` (1)

### `validateChannels`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `repairClassNoteSeats`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `visitSvgFirstTagAttributes` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `find` (1)

### `concrete`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1369` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `markerPaintIdentity` (1)

### `entries`
`[native code]` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `validateMarkAttributes` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:18` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `prepareDisplayText` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:157` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:159` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `map` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:537` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `fSpan`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/geometry.ts` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `buildStyleBlock`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:373` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `record`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:285` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:624` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:257` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `safeCssPaint`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:129` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:102` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `map` (1)

### `rectOverlap`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:164` | Self: 0.1% (1.6ms) | Total: 0.2% (3.0ms) | Samples: 1

**Called by:**
- `assessFamilyLayout` (2)

**Calls:**
- `max` (1)

### `Duplex`
`internal:streams/duplex` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `Transform` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1705` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `sign`
`[native code]` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `writtenSegmentEntersBox` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:590` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `clear` (1)

### `createSketchBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `log`
`/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `reserve`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `connector` (1)

### `cloneObject`
`[native code]` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `forEach`
`[native code]` | Self: 0.1% (1.5ms) | Total: 7.4% (106.0ms) | Samples: 1

**Called by:**
- `walk` (43)
- `connectorMarkerPaintRegions` (13)
- `lowerClassDrawing` (9)
- `preparePixelText` (1)
- `classRelationshipPaintBoxes` (1)

**Calls:**
- `(anonymous)` (27)
- `(anonymous)` (16)
- `(anonymous)` (9)
- `include` (5)
- `include` (4)
- `qualify` (1)
- `(anonymous)` (1)
- `include` (1)
- `include` (1)
- `include` (1)

### `sourceTokenAt`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:52` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:496` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `map` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `measureClassCards` (1)

### `contextLeaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `atan2`
`[native code]` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `include` (1)

### `sharpContactsClear`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:355` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `booleanSchema`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `classNativeMarkerMinimums`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:194` | Self: 0.1% (1.5ms) | Total: 0.2% (2.9ms) | Samples: 1

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `pay` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:49` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `create`
`[native code]` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `visit` (1)

### `maxMemberWidth`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `measureClassCards` (1)

### `createOwnedMeasuredRouteContactValidator`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `assertFinalClassSharpContacts` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `map` (1)

### `escapeXml`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:93` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `escapeAttr` (1)

### `classStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `readClassStatements` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:692` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `map` (1)

### `assertMarkerPaint`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `reduce` (1)

### `assertMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `shape` (1)

### `connectorGeometryEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:180` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `connector` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:160` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `get` (1)

### `RegExp`
`[native code]` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `customTextMeasurementActive`
`/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `seatFinalMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `finalizeFlatMeasuredMarkers` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:250` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `include` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:759` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:988` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `lineStrokeBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:538` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `strokedBox` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:334` | Self: 0.1% (1.4ms) | Total: 0.4% (5.7ms) | Samples: 1

**Called by:**
- `forEach` (4)

**Calls:**
- `stringify` (3)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1093` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `applyFamilyRequestNormalization`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `resolveAppearance` (1)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `classNativeMarkerMinimums` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `proofRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:64` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `prepareMarkerPolygonInk` (1)

### `transformPoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `include` (1)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:155` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `makeBitMapDescriptor`
`internal:streams/readable` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `internal:streams/readable` (1)

### `connectorEndpointAnchors`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:445` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `connectorPaintBounds` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `map` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.1% (1.4ms) | Total: 0.1% (1.4ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1990` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:118` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `every` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:231` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `visit` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/c4/config.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `dereferenceSchema`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `schemaMatchesRuntimeKind` (1)

### `record`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `ownKeys`
`[native code]` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `visit` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:325` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `findIndex`
`[native code]` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `graphicalBackendCapabilityClaims` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:782` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `textSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1651` | Self: 0.0% (1.4ms) | Total: 0.4% (7.0ms) | Samples: 1

**Called by:**
- `textSurfaces` (4)
- `certifyNativePaint` (1)

**Calls:**
- `textSurfaces` (4)

### `updateCarrier`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `refresh` (1)

### `unsafeActiveCss`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `inspectSecurityTail` (1)

### `scoreMeasuredRouteCrossings`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `validate` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:395` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `transformedBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:473` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `isXmlWhitespace`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `writtenSegmentEntersBox`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:96` | Self: 0.0% (1.3ms) | Total: 0.2% (2.9ms) | Samples: 1

**Called by:**
- `writtenClassRoundedHit` (1)
- `classOwnedSurfaceViolations` (1)

**Calls:**
- `sign` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:184` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `String`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `arrowMarkerResources` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `withDeferredTerminalProjections` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:739` | Self: 0.0% (1.3ms) | Total: 1.3% (18.7ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (12)

**Calls:**
- `writtenClassRoundedHit` (4)
- `writtenClassRoundedHit` (2)
- `writtenClassRoundedHit` (1)
- `writtenClassRoundedHit` (1)
- `writtenClassRoundedHit` (1)
- `writtenSegmentEntersBox` (1)
- `writtenPoint` (1)

### `unsafeActiveCssScan`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:618` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `inspectAttributeSecurity` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:193` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `seatFinalMeasuredMarkers` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1282` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `every` (1)

### `work`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `pay` (1)

### `normalizedReference`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:579` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `unsafeCssReferences` (1)

### `isAsciiXmlNameChar`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `cssPaintDefinitions`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `colorResolution` (1)

### `snapshotDescriptorArray`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1501` | Self: 0.0% (1.3ms) | Total: 0.7% (10.0ms) | Samples: 1

**Called by:**
- `freezeDescriptor` (4)
- `freezeDescriptor` (2)
- `snapshotCapabilityCell` (1)

**Calls:**
- `snapshotScenePrimitiveCell` (2)
- `snapshotScenePrimitiveCell` (2)
- `snapshotCapabilityCell` (1)
- `snapshotCapabilityCell` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:97` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `makeSafe`
`internal:primordials` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `internal:primordials` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts:9` | Self: 0.0% (1.3ms) | Total: 0.1% (2.7ms) | Samples: 1

**Called by:**
- `map` (2)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:172` | Self: 0.0% (1.3ms) | Total: 10.4% (148.5ms) | Samples: 1

**Called by:**
- `visit` (102)
- `visit` (2)

**Calls:**
- `visit` (84)
- `visit` (7)
- `visit` (6)
- `visit` (2)
- `visit` (1)
- `visit` (1)
- `visit` (1)
- `defineProperty` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` | Self: 0.0% (1.3ms) | Total: 0.2% (2.8ms) | Samples: 1

**Called by:**
- `paintedStrokeExtent` (1)
- `color` (1)

**Calls:**
- `trim` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `prepare` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:732` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (1)

### `sharpContactsClear`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:369` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:148` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `classOwnedSurfaceViolations` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:164` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `classOwnedSurfaceViolations` (1)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateGeometry` (1)

### `createEmissionContext`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `createSceneWriteCapture` (1)

### `cloneValue`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:389` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `sharedRenderOptionsJsonSchema` (1)

### `outlineKey`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `solidInteriors` (1)

### `parseMarkedClassRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1314` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `classifyClassStatement` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:143` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `markerBoundsAt` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1992` | Self: 0.0% (1.3ms) | Total: 0.1% (2.7ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (2)

**Calls:**
- `pay` (1)

### `admitBackendSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/external-data-snapshot.ts:17` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `render` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `find` (1)

### `validateMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:349` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1465` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `isWhitespace`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:25` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `sharpContactsClear`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validatePoint` (1)

### `connectorTerminalStrokeLosses`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:87` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `deriveConnectorTerminalProjection` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:181` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:121` | Self: 0.0% (1.3ms) | Total: 0.5% (7.7ms) | Samples: 1

**Called by:**
- `visit` (5)
- `visit` (1)

**Calls:**
- `get` (4)
- `apply` (1)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:252` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateMarker` (1)

### `repairClassAnnotationSeats`
`/tmp/pr449-main-integration-20261029-762/src/class/annotation-seats.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (1)

### `arrayIteratorNextHelper`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.6% (9.5ms) | Samples: 1

**Called by:**
- `next` (3)
- `(module)` (2)

**Calls:**
- `typedArrayViewLength` (4)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:512` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:725` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `registrationIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `registerCanonicalStyle` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/requirement/tokens.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `admitRenderContractDigestInput`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `renderContractDigest` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `markerPaintIdentity` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `admitSceneDocumentWith` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:156` | Self: 0.0% (1.3ms) | Total: 0.1% (2.6ms) | Samples: 1

**Called by:**
- `projectSvgCss` (2)

**Calls:**
- `isAsciiXmlNameChar` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1083` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1781` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:162` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `paintedStrokeExtent` (1)

### `isCombiningMark`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `getCharWidth` (1)

### `begin`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `beginSceneWriteInspection` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:725` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNodeSerialization` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:760` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `canonicalExtensionId`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `registerBuiltInStyle` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `finishClassLayout` (1)

### `finishClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `runMeasuredGraphBackend` (1)

### `resolveSceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `sceneRoleTraits` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:680` | Self: 0.0% (1.2ms) | Total: 0.1% (2.5ms) | Samples: 1

**Called by:**
- `map` (1)
- `measureRenderStage` (1)

**Calls:**
- `map` (1)

### `primitiveCapabilityClaimKey`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:322` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validatePrimitiveCapabilities` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:462` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `renderRelationshipMarkerOverlay`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts:2165` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:773` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `classStatementEnds` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:390` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `min`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `sharpContactsClear` (1)

### `shortenMeasuredRoutes`
`/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:620` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `configSpacing`
`/tmp/pr449-main-integration-20261029-762/src/shared/config-spacing.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `resolveClassRenderOptions` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNodeSerialization` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1393` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `map` (1)

### `nodePaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:638` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `extractClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `connector/labels/render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/ascii/pathfinder.ts:35` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

### `hypot`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `lineHasInk` (1)

### `next`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.5% (7.7ms) | Samples: 1

**Called by:**
- `(module)` (3)
- `prepareDisplayText` (1)

**Calls:**
- `arrayIteratorNextHelper` (3)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1755` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `pose`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:335` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `seatMeasuredMarkers` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1052` | Self: 0.0% (1.2ms) | Total: 0.4% (6.9ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (3)

**Calls:**
- `validateGeometry` (2)

### `find`
`[native code]` | Self: 0.0% (1.2ms) | Total: 1.0% (15.5ms) | Samples: 1

**Called by:**
- `validateDescriptor` (3)
- `decodedSvgAttributeValue` (2)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `assertClassMarkerMeaning` (1)
- `(anonymous)` (1)
- `renderRelationship` (1)
- `validateDescriptor` (1)

**Calls:**
- `(anonymous)` (3)
- `detectorClaims` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateMarker` (1)

### `renderRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:11` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `some` (1)

### `unsafeCssReferences`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:601` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `inspectAttributeSecurity` (1)

### `classRelationshipTerminalClearance`
`/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:59` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `classTerminalLead` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `some` (1)

### `ensureSvgIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `charge`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `seatMeasuredMarkers` (1)

### `positionFamily`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `positionFamilyForNativeRender` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:845` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `createImmutableParts`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:340` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:729` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `replace` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1231` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1354` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `markerPaintIdentity` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:191` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `visit` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1091` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `emittedEndpointMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:392` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `mixedChannels`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `ensureContrast` (1)

### `semVerSatisfies`
`/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `evaluateExtensionCompatibility` (1)

### `finalizeClassSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `finishClassLayout` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:150` | Self: 0.0% (1.2ms) | Total: 0.1% (2.3ms) | Samples: 1

**Called by:**
- `visit` (2)

**Calls:**
- `Map` (1)

### `match`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `parseClassReference` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `filter` (1)

### `renderPositionedMermaidSVG`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `consumeResolvedGraphicalRequest` (1)

### `parseProtected`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `parseClassInteractionWithAuthored` (1)

### `createWrittenPolyline`
`/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:33` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `geometryAttributes` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:560` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `find` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:32` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `scopeSvgStyles` (1)

### `validateAggregateReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1525` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1046` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `writeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:621` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `classNativeMarkerMinimums`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `decodeWithTrie`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:442` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `parseClassInteractionWithAuthored` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:266` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `map` (1)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `ensureSvgIdentity` (1)

### `sceneGroupOpacity`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:108` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `possibleShapeFill` (1)

### `omitUndefinedObjectFields`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `boundedImmutableJsonSnapshot` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1260` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:350` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1787` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `exec`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `splitHeaderStatement` (1)

### `inverseMatrix`
`/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:25` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:220` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:520` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:417` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:312` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `some` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `NativeResults` (1)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:58` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `find` (1)

### `read`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:64` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `pathBounds` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:776` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:662` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `connectorInlineLabelSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `writeConnectorSvg` (1)

### `decodeXmlReferences`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `inspectAttributeSecurity` (1)

### `hasDisplayedText`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `nonPainting` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `include` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (1)

### `bisector`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:50` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:120` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `get` (1)

### `descriptorOwnsDetectionLine`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2072` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `detectorClaims` (1)

### `resolveCss`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:728` | Self: 0.0% (1.1ms) | Total: 0.1% (2.3ms) | Samples: 1

**Called by:**
- `resolvedInlineColorAttribute` (2)

**Calls:**
- `replace` (1)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` | Self: 0.0% (1.1ms) | Total: 0.1% (2.4ms) | Samples: 1

**Called by:**
- `scanStartTags` (2)

**Calls:**
- `sourceIndexOf` (1)

### `xmlHasColon`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `runMeasuredGraphBackend` (1)

### `(anonymous)`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `node:zlib` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:661` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `classStatementEnds` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:386` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `connectorTerminalStrokeLosses`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:85` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `deriveConnectorTerminalProjection` (1)

### `executionCapabilityKey`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `executionCapabilityDecision` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:183` | Self: 0.0% (1.1ms) | Total: 0.1% (2.5ms) | Samples: 1

**Called by:**
- `visit` (2)

**Calls:**
- `ownKeys` (1)

### `sourceSlice`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:55` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:577` | Self: 0.0% (1.1ms) | Total: 0.2% (2.9ms) | Samples: 1

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `complete` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:43` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `geometryElements` (1)

### `document/resources/serialize`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:99` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `renderClassBox` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts:32` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `hooks` (1)

### `requiredBackendCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `resolveExecutionPlan` (1)

### `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `test` (1)

### `evaluateExtensionCompatibility`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:144` | Self: 0.0% (1.1ms) | Total: 0.2% (3.8ms) | Samples: 1

**Called by:**
- `createExtensionIdentity` (2)

**Calls:**
- `every` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:138` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `detectsQuadrantFamily`
`/tmp/pr449-main-integration-20261029-762/src/shared/builtin-family-detection.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:126` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `nonPainting`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `drawn`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:421` | Self: 0.0% (1.1ms) | Total: 0.2% (3.3ms) | Samples: 1

**Called by:**
- `connector/subpaths/render` (1)
- `nativeOrEmulated` (1)
- `runBackendConformance` (1)

**Calls:**
- `serializeSceneNode` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:156` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `visit` (1)

### `charge`
`/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:284` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `defineProperty`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `visit` (1)

### `compareSvgSum`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `projectClassRectangleContacts` (1)

### `compare`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:33` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `sort` (1)

### `registerBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:286` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `overlaps`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `scoreMeasuredRouteCrossingsWithAdmission`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:698` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `createHash`
`node:crypto` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:527` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `renderClassBox` (1)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:656` | Self: 0.0% (1.0ms) | Total: 0.1% (2.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `has` (1)

### `expandInlineNamespaceStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:36` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `readClassStatements` (1)

### `isArray`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `assertKnownConnectorFields` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:169` | Self: 0.0% (1.0ms) | Total: 0.1% (2.3ms) | Samples: 1

**Called by:**
- `preparePixelText` (2)

**Calls:**
- `next` (1)

### `readDefinitions`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `finish` (1)

### `canonicalTextDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1175` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `scopeSvgStyles` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` | Self: 0.0% (1.0ms) | Total: 0.5% (8.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `xmlSlice` (2)
- `xmlSlice` (2)

### `snapshotTextMeasurementProfile`
`/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `createTextMeasurementExecution` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `record`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:261` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `viewportBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `paintedStrokeExtent` (1)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `layout` (1)

### `sourceIndexOf`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `tree` (1)

### `rootMatches`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `rootPreludeMatches` (1)

### `receiptOf`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:757` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:427` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `Duplex`
`internal:streams/duplex:16` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `Transform` (1)

### `toFinite`
`/tmp/pr449-main-integration-20261029-762/src/agent/types.ts:1604` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `renderRelationshipMarkerOverlay`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:639` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1244` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `validateUnitVector`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `sanitizeDisplayLines`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` | Self: 0.0% (983us) | Total: 0.0% (983us) | Samples: 1

**Called by:**
- `escapeDisplayAttr` (1)

### `resolveCss`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:725` | Self: 0.0% (981us) | Total: 0.0% (981us) | Samples: 1

**Called by:**
- `resolvedInlineColorAttribute` (1)

### `get`
`/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` | Self: 0.0% (981us) | Total: 0.0% (981us) | Samples: 1

**Called by:**
- `resolveColors` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` | Self: 0.0% (979us) | Total: 0.0% (979us) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:426` | Self: 0.0% (973us) | Total: 0.0% (973us) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `measureClassCards`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:201` | Self: 0.0% (970us) | Total: 0.1% (2.4ms) | Samples: 1

**Called by:**
- `layoutClassDiagram` (2)

**Calls:**
- `maxMemberWidth` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1720` | Self: 0.0% (969us) | Total: 0.0% (969us) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:16` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `serializeMarkerResource`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:141` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `geometryElements` (1)

### `admitRenderOptionsInput`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1307` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `boundedImmutableJsonSnapshot` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:195` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `renderClassBox` (1)

**Calls:**
- `resolvedColorValue` (1)

### `validateConnectorProjectionConsistency`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1351` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `deriveConnectorTerminalProjection` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:9` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `admitFamilyScene`
`/tmp/pr449-main-integration-20261029-762/src/scene/admission.ts:31` | Self: 0.0% (0us) | Total: 15.9% (227.0ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (161)

**Calls:**
- `admitSceneDocumentWith` (86)
- `admitSceneDocumentWith` (75)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:207` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `visit` (2)

**Calls:**
- `set` (2)

### `markerPaintIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1377` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `concrete` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:330` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `get receipt` (2)

**Calls:**
- `receiptOf` (1)
- `receiptOf` (1)

### `normalizeRequest`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:17` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `applyFamilyRequestNormalization` (1)

**Calls:**
- `resolveClassRenderOptions` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1986` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `prepareMarkerPolygonInk` (1)

### `rejectUnknownKeys`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:154` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `validateMarkAttributes` (1)

**Calls:**
- `has` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:581` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `prepare` (1)

**Calls:**
- `serializeMarkerResource` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:761` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `get` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1765` | Self: 0.0% (0us) | Total: 0.2% (4.0ms) | Samples: 0

**Called by:**
- `measureRenderStage` (3)

**Calls:**
- `resolveAppearance` (2)
- `resolveAppearance` (1)

### `parseMarkedClassRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1307` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `classifyClassStatement` (1)

**Calls:**
- `parseClassRelationEndpoints` (1)

### `measureText`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:188` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureTextWidth` (1)

**Calls:**
- `getCharWidth` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:211` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `every` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:157` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `classOwnedSurfaceViolations` (1)

**Calls:**
- `emittedBox` (1)

### `refresh`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:169` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `seatMeasuredMarkers` (1)

**Calls:**
- `updateCarrier` (1)

### `projectClassPositioned`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:9` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `map` (2)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:222` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (2)

**Calls:**
- `layoutMeasuredForest` (1)
- `layoutMeasuredForest` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:653` | Self: 0.0% (0us) | Total: 0.5% (7.1ms) | Samples: 0

**Called by:**
- `leaf` (3)
- `solidInteriors` (2)

**Calls:**
- `strokedBox` (4)
- `transformedBounds` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:5` | Self: 0.0% (0us) | Total: 0.3% (4.5ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1878` | Self: 0.0% (0us) | Total: 1.4% (21.1ms) | Samples: 0

**Called by:**
- `(module)` (13)

**Calls:**
- `freezeDescriptor` (5)
- `completeBuiltinDescriptor` (2)
- `freezeDescriptor` (2)
- `completeBuiltinDescriptor` (1)
- `freezeDescriptor` (1)
- `completeBuiltinDescriptor` (1)
- `freezeDescriptor` (1)

### `registerCanonicalStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:235` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (1)

**Calls:**
- `registrationIdentity` (1)

### `graphicalBackendCapabilityClaims`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:267` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `findIndex` (1)

### `inspectSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:675` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `inspectAttributeSecurity` (1)

### `sort`
`[native code]` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `detectRegisteredFamilyDescriptorFromFirstLine` (1)
- `build` (1)

**Calls:**
- `compareCodePointStrings` (1)
- `compare` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:109` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:436` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validatePoints` (1)

**Calls:**
- `finite` (1)

### `inlineResolvedColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:636` | Self: 0.0% (0us) | Total: 0.6% (8.5ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (7)

**Calls:**
- `colorResolution` (6)
- `colorResolution` (1)

### `render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:394` | Self: 0.0% (0us) | Total: 0.7% (10.6ms) | Samples: 0

**Called by:**
- `rendered` (9)

**Calls:**
- `admitSceneDocumentWith` (8)
- `admitSceneDocumentWith` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:710` | Self: 0.0% (0us) | Total: 3.7% (53.6ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (37)

**Calls:**
- `verifyDocumentEnvelope` (9)
- `verifyDocumentEnvelope` (5)
- `verifyDocumentEnvelope` (5)
- `verifyDocumentEnvelope` (3)
- `verifyDocumentEnvelope` (3)
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:474` | Self: 0.0% (0us) | Total: 0.0% (981us) | Samples: 0

**Called by:**
- `diagramColorVariables` (1)

**Calls:**
- `get` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:50` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `find` (1)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:465` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `validate` (1)

### `has`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:10` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `qualify` (1)

**Calls:**
- `apply` (1)

### `freezeBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:403` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `registerBuiltInBackend` (1)

**Calls:**
- `snapshotBackendCapabilities` (1)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:725` | Self: 0.0% (0us) | Total: 0.8% (12.0ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (2)

**Calls:**
- `filter` (2)

### `inspectScene`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:344` | Self: 0.0% (0us) | Total: 3.3% (47.9ms) | Samples: 0

**Called by:**
- `inspectScenePaintGeometry` (30)

**Calls:**
- `walk` (30)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:106` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `seatFinalMeasuredMarkers` (1)

**Calls:**
- `charge` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `reduce` (1)

**Calls:**
- `measureTextWidth` (1)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:701` | Self: 0.0% (0us) | Total: 0.5% (7.2ms) | Samples: 0

**Called by:**
- `inlineResolvedColors` (6)

**Calls:**
- `projectSvgCss` (6)

### `projectClassRectangleContacts`
`/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:163` | Self: 0.0% (0us) | Total: 0.3% (4.8ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (3)

**Calls:**
- `compareSvgSum` (1)
- `compareSvgSum` (1)
- `compareClassSvgSum` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1485` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `requiredBackendCapabilities` (1)

### `completeBuiltinDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1384` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `declareFamilyScenePrimitiveEvidence` (1)

### `cloneValue`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` | Self: 0.0% (0us) | Total: 0.7% (10.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)
- `map` (3)
- `sharedRenderOptionsJsonSchema` (1)

**Calls:**
- `map` (9)

### `validatePoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:465` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validateGeometry` (1)

**Calls:**
- `validatePoint` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:336` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `readXmlDataEnd` (1)

### `escapeDisplayAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:115` | Self: 0.0% (0us) | Total: 0.0% (983us) | Samples: 0

**Called by:**
- `renderClassBox` (1)

**Calls:**
- `sanitizeDisplayLines` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:182` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Calls:**
- `apply` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `some` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:361` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `xmlHasColon` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:822` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `transformAttribute` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:350` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `forEach` (1)

**Calls:**
- `transformPoint` (1)

### `internal:streams/duplex`
`internal:streams/duplex:2` | Self: 0.0% (0us) | Total: 0.4% (5.7ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `anonymous` (4)

### `nonPainting`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:130` | Self: 0.0% (0us) | Total: 0.3% (5.6ms) | Samples: 0

**Called by:**
- `leaf` (3)

**Calls:**
- `hasDisplayedText` (1)
- `some` (1)
- `textPaints` (1)

### `authoredClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:131` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (1)

**Calls:**
- `add` (1)

### `schemaMatchesRuntimeKind`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:39` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `filter` (1)

**Calls:**
- `dereferenceSchema` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:3` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:48` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6572` | Self: 0.0% (0us) | Total: 6.5% (92.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `_inherits` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1032` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `report` (1)

**Calls:**
- `rendered` (1)

### `internal:primordials`
`internal:primordials:76` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeSafe` (1)

### `beginSceneWriteInspection`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:114` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `inspectScenePaintGeometry` (1)

**Calls:**
- `begin` (1)

### `clear`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:362` | Self: 0.0% (0us) | Total: 0.2% (3.6ms) | Samples: 0

**Called by:**
- `seatMeasuredMarkers` (2)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:37` | Self: 0.0% (0us) | Total: 0.3% (4.3ms) | Samples: 0

**Called by:**
- `build` (3)
- `tree` (1)

**Calls:**
- `build` (3)
- `build` (1)

### `renderResolvedMermaidSVG`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:270` | Self: 0.0% (0us) | Total: 15.3% (219.1ms) | Samples: 0

**Called by:**
- `consumeResolvedGraphicalRequest` (148)

**Calls:**
- `measureRenderStage` (148)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:95` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `renderClassBox` (1)

**Calls:**
- `assertMarkAttributes` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:245` | Self: 0.0% (0us) | Total: 0.2% (3.4ms) | Samples: 0

**Called by:**
- `connectorPaintBounds` (1)
- `include` (1)
- `markerTerminalDepth` (1)

**Calls:**
- `paintedStrokeExtent` (2)
- `paintedStrokeExtent` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:941` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (2)

**Calls:**
- `validateMarker` (1)
- `validateMarker` (1)

### `node:zlib`
`node:zlib:161` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `executionCapabilityDecision`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1449` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveExecutionPlan` (1)

**Calls:**
- `executionCapabilityKey` (1)

### `compareSvgSum`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:41` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `projectClassRectangleContacts` (1)

**Calls:**
- `writtenDecimalParts` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts:47` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Calls:**
- `map` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:100` | Self: 0.0% (0us) | Total: 0.4% (7.0ms) | Samples: 0

**Called by:**
- `finishClassLayout` (5)

**Calls:**
- `connectorMarkerPaintRegions` (5)

### `detectRegisteredFamilyDescriptorFromFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2083` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `detectInstalledFamilyDescriptorFromFirstLine` (1)

**Calls:**
- `sort` (1)

### `layout`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:25` | Self: 0.0% (0us) | Total: 12.7% (181.9ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (123)

**Calls:**
- `runMeasuredGraphBackend` (108)
- `layoutClassDiagram` (14)
- `layoutClassDiagram` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1684` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `textSurfaces` (1)

### `captureFields`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` | Self: 0.0% (0us) | Total: 0.5% (7.4ms) | Samples: 0

**Called by:**
- `snapshotCapabilityCell` (1)
- `snapshotScenePrimitiveCell` (1)
- `freezeDescriptor` (1)

**Calls:**
- `map` (3)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `stringify` (1)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:36` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `test` (1)

### `styleSpecJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:595` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `map` (1)

### `applyReplacements`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:242` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `resolveSvgColors` (1)

**Calls:**
- `push` (1)

### `rootPreludeMatches`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:220` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `rootMatches` (1)

### `replaceSvgRootStartTag`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:319` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

**Calls:**
- `slice` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:601` | Self: 0.0% (0us) | Total: 1.5% (22.3ms) | Samples: 0

**Called by:**
- `seatMeasuredMarkers` (13)

**Calls:**
- `validate` (9)
- `validate` (1)
- `validate` (1)
- `validate` (1)
- `validate` (1)

### `validateRoleStyleRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:323` | Self: 0.0% (0us) | Total: 0.2% (3.2ms) | Samples: 0

**Called by:**
- `validateRoleStyles` (1)

**Calls:**
- `safeRoleColor` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1737` | Self: 0.0% (0us) | Total: 1.0% (14.3ms) | Samples: 0

**Called by:**
- `measureRenderStage` (4)

**Calls:**
- `normalizeMermaidSourceWithOverrides` (4)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:114` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `toUpperCase` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:704` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `classStatementEnds` (1)

**Calls:**
- `expandInlineNamespaceStatement` (1)

### `layoutClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:631` | Self: 0.0% (0us) | Total: 1.4% (20.7ms) | Samples: 0

**Called by:**
- `layout` (14)

**Calls:**
- `measureClassCards` (12)
- `measureClassCards` (2)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:643` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `inverseMatrix` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:122` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (1)

**Calls:**
- `sourceIndexOf` (1)

### `positionedPaintCertification`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:178` | Self: 0.0% (0us) | Total: 7.3% (104.5ms) | Samples: 0

**Called by:**
- `measureRenderStage` (72)

**Calls:**
- `certifyScenePaint` (32)
- `certifyNativePaint` (15)
- `certifyNativePaint` (4)
- `certifyNativePaint` (3)
- `certifyNativePaint` (2)
- `certifyNativePaint` (2)
- `certifyNativePaint` (2)
- `certifyNativePaint` (2)
- `certifyNativePaint` (2)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:519` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `cloneObject` (1)

### `getCharWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:88` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureText` (1)

**Calls:**
- `isCombiningMark` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:189` | Self: 0.0% (0us) | Total: 2.1% (30.9ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (25)

**Calls:**
- `measureRenderStage` (25)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:615` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `finite` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1502` | Self: 0.0% (0us) | Total: 1.4% (20.1ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (15)

**Calls:**
- `solidInteriors` (4)
- `solidInteriors` (2)
- `solidInteriors` (2)
- `solidInteriors` (2)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:358` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `seatFinalMeasuredMarkers` (1)

**Calls:**
- `pose` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1756` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `includes` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` | Self: 0.0% (0us) | Total: 0.8% (12.7ms) | Samples: 0

**Called by:**
- `map` (10)

**Calls:**
- `serializeSceneNode` (6)
- `indentLines` (2)
- `serializeSceneNode` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1227` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `includes` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/agent/families-source-hooks.ts:142` | Self: 0.0% (0us) | Total: 0.3% (5.2ms) | Samples: 0

**Calls:**
- `flowchartFamilyHooks` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:56` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `formatSvgNumericAttribute` (1)

**Calls:**
- `(anonymous)` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1841` | Self: 0.0% (0us) | Total: 0.3% (4.4ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (3)

**Calls:**
- `find` (3)

### `decodedSvgAttributeValue`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:217` | Self: 0.0% (0us) | Total: 0.2% (2.9ms) | Samples: 0

**Called by:**
- `finish` (1)
- `finish` (1)

**Calls:**
- `find` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:148` | Self: 0.0% (0us) | Total: 0.9% (14.0ms) | Samples: 0

**Called by:**
- `forEach` (9)

**Calls:**
- `connector` (6)
- `renderRelationshipMarkerOverlay` (1)
- `connector` (1)
- `renderRelationshipMarkerOverlay` (1)

### `Gunzip`
`node:zlib:334` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `gunzipSync` (1)

**Calls:**
- `Zlib` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:136` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `charge` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts:3` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Calls:**
- `Segmenter` (2)

### `Gzip`
`node:zlib:328` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `gzipSync` (1)

**Calls:**
- `Zlib` (1)

### `internal:fs/binding`
`internal:fs/binding:3` | Self: 0.0% (0us) | Total: 0.3% (4.6ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `@lazy` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:174` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `visit` (2)

**Calls:**
- `freeze` (2)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:227` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `freeze` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:803` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `hooks` (1)
- `hooks` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:274` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `include` (1)

**Calls:**
- `every` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:198` | Self: 0.0% (0us) | Total: 2.1% (30.9ms) | Samples: 0

**Called by:**
- `measureRenderStage` (25)

**Calls:**
- `(anonymous)` (20)
- `render` (5)

### `assertFinalClassSharpContacts`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:866` | Self: 0.0% (0us) | Total: 0.2% (4.0ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (3)

**Calls:**
- `(anonymous)` (2)
- `(anonymous)` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:536` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validateNodeSerialization` (1)

**Calls:**
- `string` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1762` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `checkFamilyConfigColors` (1)

### `prepareMarkerTerminals`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:9` | Self: 0.0% (0us) | Total: 0.2% (3.6ms) | Samples: 0

**Called by:**
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `map` (3)

### `normalizeMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:663` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `mermaidFirstLine` (1)

### `xmlNameCharacter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:87` | Self: 0.0% (0us) | Total: 0.2% (3.1ms) | Samples: 0

**Called by:**
- `readXmlNameEnd` (2)

**Calls:**
- `xmlAsciiLetter` (2)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:107` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `validateConnectorProjectionConsistency` (1)
- `setConnectorTerminalProjection` (1)

**Calls:**
- `connectorTerminalStrokeLosses` (1)
- `connectorTerminalStrokeLosses` (1)

### `require`
`[native code]` | Self: 0.0% (0us) | Total: 27.3% (390.4ms) | Samples: 0

**Called by:**
- `bound require` (106)

**Calls:**
- `anonymous` (106)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:175` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `get` (1)

**Calls:**
- `join` (1)

### `strokedBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:543` | Self: 0.0% (0us) | Total: 0.4% (5.7ms) | Samples: 0

**Called by:**
- `paintBounds` (4)

**Calls:**
- `lineStrokeBox` (2)
- `lineStrokeBox` (1)
- `lineStrokeBox` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/default-backend.ts:5` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Calls:**
- `registerBuiltInBackend` (1)
- `registerBuiltInBackend` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/c4/config.ts:91` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:273` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `include` (1)

**Calls:**
- `map` (1)

### `parseClassInteractionWithAuthored`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:915` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `classifyClassStatement` (1)

**Calls:**
- `decodeWithTrie` (1)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:661` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `decodeXmlReferences` (1)

### `snapshotScenePrimitiveCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1548` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `snapshotDescriptorArray` (2)

**Calls:**
- `freeze` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `(anonymous)` (1)

### `internal:streams/compose`
`internal:streams/compose:2` | Self: 0.0% (0us) | Total: 0.5% (8.4ms) | Samples: 0

**Called by:**
- `anonymous` (6)

**Calls:**
- `anonymous` (6)

### `resolveSvgColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:758` | Self: 0.0% (0us) | Total: 0.3% (4.7ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (3)

**Calls:**
- `transformSvgCssValues` (2)
- `applyReplacements` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:64` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `formatSvgNumber` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:58` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `find` (1)

### `seatFinalMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:569` | Self: 0.0% (0us) | Total: 2.4% (35.3ms) | Samples: 0

**Called by:**
- `finalizeFlatMeasuredMarkers` (21)

**Calls:**
- `seatMeasuredMarkers` (13)
- `seatMeasuredMarkers` (3)
- `seatMeasuredMarkers` (1)
- `seatMeasuredMarkers` (1)
- `seatMeasuredMarkers` (1)
- `seatMeasuredMarkers` (1)
- `seatMeasuredMarkers` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:191` | Self: 0.0% (0us) | Total: 0.3% (4.7ms) | Samples: 0

**Calls:**
- `createRenderOutputDescriptors` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:729` | Self: 0.0% (0us) | Total: 0.0% (979us) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `renderMultilineText` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1944` | Self: 0.0% (0us) | Total: 0.2% (2.9ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (2)

**Calls:**
- `connectorMarkerPaintRegions` (2)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1783` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `measureRenderStage` (3)

**Calls:**
- `resolveExecutionPlan` (1)
- `resolveExecutionPlan` (1)
- `resolveExecutionPlan` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1739` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `normalizeMermaidSource` (1)

**Calls:**
- `classifyMermaidFamilyDescriptorFromFirstLine` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:4` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `bound require`
`[native code]` | Self: 0.0% (0us) | Total: 27.3% (390.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (21)
- `(anonymous)` (15)
- `(anonymous)` (9)
- `(anonymous)` (6)
- `(anonymous)` (5)
- `(anonymous)` (4)
- `(anonymous)` (4)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

**Calls:**
- `require` (106)

### `deriveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:505` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `resolveColors` (1)

**Calls:**
- `textTones` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:678` | Self: 0.0% (0us) | Total: 3.5% (51.1ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (33)

**Calls:**
- `measureRenderStage` (33)

### `ensureContrast`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:120` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `deriveColors` (1)

**Calls:**
- `mixedChannels` (1)

### `walk`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:328` | Self: 0.0% (0us) | Total: 4.9% (70.8ms) | Samples: 0

**Called by:**
- `inspectScene` (30)
- `(anonymous)` (13)

**Calls:**
- `forEach` (43)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:28` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `createImmutableParts` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1019` | Self: 0.0% (0us) | Total: 0.6% (8.7ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (6)

**Calls:**
- `connectorMarkerPaintRegions` (6)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` | Self: 0.0% (0us) | Total: 0.4% (6.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (4)

**Calls:**
- `nonPainting` (3)
- `nonPainting` (1)

### `inspectSecurityTail`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:687` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `unsafeActiveCss` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:515` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `paintAttribute` (1)

### `writeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` | Self: 0.0% (0us) | Total: 0.8% (12.7ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (10)

**Calls:**
- `map` (10)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:158` | Self: 0.0% (0us) | Total: 0.4% (5.8ms) | Samples: 0

**Called by:**
- `classOwnedSurfaceViolations` (4)

**Calls:**
- `writtenSegmentEntersBox` (4)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:665` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `unsafeActiveCssScan` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:484` | Self: 0.0% (0us) | Total: 0.2% (3.9ms) | Samples: 0

**Called by:**
- `identityAttributes` (1)
- `paintAttribute` (1)
- `transformAttribute` (1)

**Calls:**
- `escapeAttr` (2)
- `escapeAttr` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:407` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `has` (2)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:549` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `prepare` (1)

**Calls:**
- `decodedSvgAttributeValue` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:556` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:662` | Self: 0.0% (0us) | Total: 0.2% (4.1ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (3)

**Calls:**
- `classNativeMarkerMinimums` (2)
- `classNativeMarkerMinimums` (1)

### `add`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:118` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `authoredClassStatements` (1)

**Calls:**
- `every` (1)

### `buildClassEndpointMarkerTemplates`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts:9` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `map` (2)

### `get`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:28` | Self: 0.0% (0us) | Total: 0.6% (8.9ms) | Samples: 0

**Called by:**
- `visit` (7)

**Calls:**
- `deriveConnectorTerminalProjection` (2)
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)

### `node:zlib`
`node:zlib:2` | Self: 0.0% (0us) | Total: 0.9% (14.2ms) | Samples: 0

**Calls:**
- `anonymous` (8)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:195` | Self: 0.0% (0us) | Total: 0.3% (5.4ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (4)

**Calls:**
- `paintBounds` (2)
- `paintBounds` (2)

### `finalizeClassSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:815` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `repairClassAnnotationSeats` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:197` | Self: 0.0% (0us) | Total: 0.0% (981us) | Samples: 0

**Called by:**
- `renderClassBox` (1)

**Calls:**
- `resolvedColorValue` (1)

### `splitHeaderStatement`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:119` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `mermaidFirstLine` (1)

**Calls:**
- `exec` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1584` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (2)

**Calls:**
- `snapshotDescriptorArray` (2)

### `svgStyleRanges`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:294` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `scopeSvgStyles` (1)

**Calls:**
- `scanStartTags` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:641` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (2)

**Calls:**
- `freeze` (1)
- `createWrittenPolyline` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:140` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `svgStyleRanges` (1)
- `projectSvgCss` (1)

**Calls:**
- `scanTagEnd` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6573` | Self: 0.0% (0us) | Total: 6.5% (92.9ms) | Samples: 0

**Called by:**
- `o` (1)

**Calls:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:158` | Self: 0.0% (0us) | Total: 0.3% (5.2ms) | Samples: 0

**Called by:**
- `map` (4)

**Calls:**
- `serializeSceneNode` (2)
- `serializeSceneNode` (2)

### `finishClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:792` | Self: 0.0% (0us) | Total: 3.6% (52.6ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (37)

**Calls:**
- `assertClassMarkerMeaning` (19)
- `assertClassMarkerMeaning` (8)
- `assertClassMarkerMeaning` (5)
- `assertClassMarkerMeaning` (1)
- `assertClassMarkerMeaning` (1)
- `assertClassMarkerMeaning` (1)
- `assertClassMarkerMeaning` (1)
- `assertClassMarkerMeaning` (1)

### `walk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1757` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `walk` (1)

**Calls:**
- `endpointRelation` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/zenuml/native-parser.ts:14` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Calls:**
- `RegExp` (1)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1682` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `renderContractDigest` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/encode-html.js:10` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Calls:**
- `parseEncodeTrie` (2)

### `assessFamilyLayout`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:266` | Self: 0.0% (0us) | Total: 0.2% (3.0ms) | Samples: 0

**Called by:**
- `assessRenderedLayoutHardViolations` (2)

**Calls:**
- `rectOverlap` (2)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:578` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `validateNodeSerialization` (1)

**Calls:**
- `string` (1)

### `admitSceneDocumentWith`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:268` | Self: 0.0% (0us) | Total: 7.5% (108.0ms) | Samples: 0

**Called by:**
- `admitFamilyScene` (75)
- `render` (1)

**Calls:**
- `visit` (75)
- `visit` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:328` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `get receipt` (2)

**Calls:**
- `renderedSvgDigest` (1)
- `canonicalTextDigest` (1)

### `string`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:138` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `apply` (1)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:985` | Self: 0.0% (0us) | Total: 0.7% (10.1ms) | Samples: 0

**Called by:**
- `layout` (8)

**Calls:**
- `classStatementEnds` (7)
- `classStatementEnds` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/hybrid-backend.ts:193` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `createSketchBackend` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:5` | Self: 0.0% (0us) | Total: 1.3% (19.4ms) | Samples: 0

**Called by:**
- `anonymous` (15)

**Calls:**
- `bound require` (15)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:570` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Calls:**
- `createSketchBackend` (1)

### `projectClassPositioned`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:22` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `Map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/addPairToJSMap.js:4` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:25` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Calls:**
- `gzipSync` (1)
- `zlibBufferSync` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/agent/families.ts:8` | Self: 0.0% (0us) | Total: 3.1% (44.7ms) | Samples: 0

**Calls:**
- `installBuiltinFamily` (17)
- `installBuiltinFamily` (13)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:103` | Self: 0.0% (0us) | Total: 1.9% (27.5ms) | Samples: 0

**Called by:**
- `finishClassLayout` (19)

**Calls:**
- `prepareMarkerPolygonInk` (8)
- `prepareMarkerPolygonInk` (6)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:158` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `projectSvgCss` (1)

**Calls:**
- `sourceSlice` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:426` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `measureClassCards` (1)

**Calls:**
- `reduce` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:314` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `text` (1)

### `parseClassReference`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:186` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `parseMarkerlessClassRelationship` (1)

**Calls:**
- `match` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:262` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `copyDataProperties` (1)

### `deriveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:517` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveColors` (1)

**Calls:**
- `ensureContrast` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/decode-data-html.js:3` | Self: 0.0% (0us) | Total: 5.1% (73.5ms) | Samples: 0

**Calls:**
- `decodeBase64` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:167` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (1)
- `projectSvgCss` (1)

**Calls:**
- `sourceIndexOf` (1)
- `sourceIndexOf` (1)

### `runMeasuredGraphBackend`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:73` | Self: 0.0% (0us) | Total: 11.1% (159.4ms) | Samples: 0

**Called by:**
- `layout` (108)

**Calls:**
- `finishClassLayout` (37)
- `(anonymous)` (33)
- `finishClassLayout` (28)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (1)
- `finishClassLayout` (1)
- `finishClassLayout` (1)
- `(anonymous)` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:511` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `connectorPaintBounds` (1)
- `markerBoundsAt` (1)

**Calls:**
- `test` (2)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:138` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `map` (1)

### `markerTerminalDepth`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:294` | Self: 0.0% (0us) | Total: 0.2% (3.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `markerBoundsAt` (2)
- `markerBoundsAt` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/builtin-backends.ts:20` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Calls:**
- `registerBuiltInBackend` (1)
- `registerBuiltInBackend` (1)

### `lineStrokeBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:535` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `strokedBox` (1)

**Calls:**
- `geometryBounds` (1)

### `layout`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:20` | Self: 0.0% (0us) | Total: 1.4% (21.1ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (16)

**Calls:**
- `parseClassDiagram` (8)
- `parseClassDiagram` (4)
- `parseClassDiagram` (1)
- `parseClassDiagram` (1)
- `parseClassDiagram` (1)
- `parseClassDiagram` (1)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:209` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `connectorPaintBounds` (1)

**Calls:**
- `pointsBounds` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:764` | Self: 0.0% (0us) | Total: 0.4% (6.7ms) | Samples: 0

**Called by:**
- `classStatementEnds` (3)
- `parseClassDiagram` (2)

**Calls:**
- `classifyClassStatement` (3)
- `classifyClassStatement` (2)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:7` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Calls:**
- `log` (1)

### `lineHasInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:545` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `some` (1)

**Calls:**
- `hypot` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:64` | Self: 0.0% (0us) | Total: 3.2% (46.9ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (32)

**Calls:**
- `withDeferredTerminalProjections` (32)

### `withGraphLayoutDecisionObserver`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:37` | Self: 0.0% (0us) | Total: 14.2% (203.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (139)

**Calls:**
- `layout` (123)
- `layout` (16)

### `Transform`
`internal:streams/transform:14` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `ZlibBase` (2)

**Calls:**
- `Duplex` (1)
- `Duplex` (1)

### `validateMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:353` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Called by:**
- `validateNode` (3)

**Calls:**
- `rejectUnknownKeys` (2)
- `rejectUnknownKeys` (1)

### `registerBuiltInStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:291` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `canonicalExtensionId` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:10` | Self: 0.0% (0us) | Total: 0.2% (3.6ms) | Samples: 0

**Called by:**
- `map` (3)

**Calls:**
- `markerTerminalDepth` (3)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:120` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `apply` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:94` | Self: 0.0% (0us) | Total: 0.6% (9.1ms) | Samples: 0

**Called by:**
- `measureRenderStage` (7)

**Calls:**
- `layoutLayeredGraph` (3)
- `layoutLayeredGraph` (2)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)

### `addClassSvgNumbers`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:60` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `projectClassRectangleContacts` (1)

**Calls:**
- `map` (1)

### `nativeOrEmulated`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:448` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `drawn` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:253` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `finite` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:229` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (1)

**Calls:**
- `assertKnownConnectorFields` (1)

### `classStatementEnds`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:669` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (1)

**Calls:**
- `visit` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:252` | Self: 0.0% (0us) | Total: 3.5% (50.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (34)

**Calls:**
- `measureRenderStage` (34)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:8` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:20` | Self: 0.0% (0us) | Total: 53.0% (756.5ms) | Samples: 0

**Calls:**
- `withPerformanceObserver` (522)

### `parseClassRelationEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1339` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `parseMarkedClassRelationship` (1)

**Calls:**
- `trim` (1)

### `withRenderStageObserver`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:20` | Self: 0.0% (0us) | Total: 53.0% (756.5ms) | Samples: 0

**Called by:**
- `withPerformanceObserver` (522)

**Calls:**
- `withSvgInspectionCache` (521)
- `renderMermaidSVGWithReceipt` (1)

### `markerPaintIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1356` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `pay` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:505` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `preparePixelText` (1)

### `classRelationshipPaintBoxes`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:343` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `classOwnedSurfaceViolations` (1)

**Calls:**
- `forEach` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:5` | Self: 0.0% (0us) | Total: 15.8% (226.5ms) | Samples: 0

**Calls:**
- `(anonymous)` (5)

### `withPerformanceObserver`
`/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts:42` | Self: 0.0% (0us) | Total: 53.0% (756.5ms) | Samples: 0

**Called by:**
- `(module)` (522)

**Calls:**
- `withRenderStageObserver` (522)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:600` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `connectorEndpointAnchors` (1)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:476` | Self: 0.0% (0us) | Total: 0.2% (3.1ms) | Samples: 0

**Called by:**
- `diagramColorVariables` (2)

**Calls:**
- `deriveColors` (1)
- `deriveColors` (1)

### `createExtensionIdentity`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:246` | Self: 0.0% (0us) | Total: 0.5% (7.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)
- `completeBuiltinDescriptor` (1)
- `validateDescriptor` (1)

**Calls:**
- `evaluateExtensionCompatibility` (2)
- `evaluateExtensionCompatibility` (2)
- `evaluateExtensionCompatibility` (1)

### `completeBuiltinDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1372` | Self: 0.0% (0us) | Total: 0.2% (3.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (2)

**Calls:**
- `copyDataProperties` (2)

### `snapshotCapabilityCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1554` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `snapshotDescriptorArray` (1)

**Calls:**
- `captureFields` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1041` | Self: 0.0% (0us) | Total: 0.8% (11.5ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (8)

**Calls:**
- `color` (6)
- `color` (2)

### `ensureContrast`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:102` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `legibleOnEvery` (1)

**Calls:**
- `contrastRatio` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:185` | Self: 0.0% (0us) | Total: 0.2% (4.0ms) | Samples: 0

**Called by:**
- `preparePixelText` (2)

**Calls:**
- `qualify` (1)
- `qualify` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:689` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (1)

**Calls:**
- `classRelationshipPaintBoxes` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:542` | Self: 0.0% (0us) | Total: 0.2% (3.4ms) | Samples: 0

**Called by:**
- `validateNodeSerialization` (2)

**Calls:**
- `connector` (2)

### `tree`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:71` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (2)

**Calls:**
- `build` (1)
- `build` (1)

### `hooks`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:508` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1965` | Self: 0.0% (0us) | Total: 0.2% (4.2ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (3)

**Calls:**
- `markerPaintIdentity` (1)
- `markerPaintIdentity` (1)
- `markerPaintIdentity` (1)

### `createSceneWriteCapture`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:129` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `retainedPositionedScene` (1)

**Calls:**
- `createEmissionContext` (1)

### `retainedPositionedScene`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:61` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `createSceneWriteCapture` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:633` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `copyDataProperties` (1)

### `applyFamilyRequestNormalization`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1042` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveAppearance` (1)

**Calls:**
- `normalizeRequest` (1)

### `validateRoleStyles`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:340` | Self: 0.0% (0us) | Total: 0.2% (3.2ms) | Samples: 0

**Called by:**
- `validateStyleSpec` (1)

**Calls:**
- `validateRoleStyleRecord` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1879` | Self: 0.0% (0us) | Total: 1.6% (23.5ms) | Samples: 0

**Called by:**
- `(module)` (17)

**Calls:**
- `validateDescriptor` (3)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:96` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `buildStyleBlock` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:989` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (1)

**Calls:**
- `pay` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:584` | Self: 0.0% (0us) | Total: 0.2% (4.1ms) | Samples: 0

**Called by:**
- `validateNodeSerialization` (3)

**Calls:**
- `record` (1)
- `record` (1)
- `record` (1)

### `normalizeMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:665` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `(anonymous)` (1)

### `registerBuiltInStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:292` | Self: 0.0% (0us) | Total: 0.6% (9.2ms) | Samples: 0

**Called by:**
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `validateStyleSpec` (1)
- `validateStyleSpec` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:111` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `some` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:24` | Self: 0.0% (0us) | Total: 0.6% (9.2ms) | Samples: 0

**Calls:**
- `parse` (3)
- `zlibBufferSync` (2)
- `gunzipSync` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:323` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `forEach` (1)

**Calls:**
- `atan2` (1)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:702` | Self: 0.0% (0us) | Total: 3.3% (47.7ms) | Samples: 0

**Called by:**
- `validateNode` (35)

**Calls:**
- `serializeSceneNode` (25)
- `serializeSceneNode` (3)
- `serializeSceneNode` (2)
- `serializeSceneNode` (1)
- `serializeSceneNode` (1)
- `serializeSceneNode` (1)
- `serializeSceneNode` (1)
- `serializeSceneNode` (1)

### `freezeTransport`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:158` | Self: 0.0% (0us) | Total: 0.3% (4.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `freeze` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:21` | Self: 0.0% (0us) | Total: 0.3% (4.7ms) | Samples: 0

**Calls:**
- `get receipt` (4)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:136` | Self: 0.0% (0us) | Total: 1.4% (21.3ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (15)

**Calls:**
- `group` (3)
- `group` (3)
- `renderClassBox` (2)
- `renderClassBox` (2)
- `renderClassBox` (2)
- `renderClassBox` (1)
- `renderClassBox` (1)
- `renderClassBox` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:548` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)
- `registerBuiltInStyle` (1)

### `transformAttribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:531` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `advance`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `reduce` (1)

### `classifyMermaidFamilyDescriptorFromFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/family-detection.ts:39` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `detectInstalledFamilyDescriptorFromFirstLine` (1)

### `finalizeClassSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:824` | Self: 0.0% (0us) | Total: 1.7% (25.2ms) | Samples: 0

**Called by:**
- `finishClassLayout` (17)

**Calls:**
- `classOwnedSurfaceViolations` (12)
- `classOwnedSurfaceViolations` (1)
- `classOwnedSurfaceViolations` (1)
- `classOwnedSurfaceViolations` (1)
- `classOwnedSurfaceViolations` (1)
- `classOwnedSurfaceViolations` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:8` | Self: 0.0% (0us) | Total: 0.4% (6.8ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `bound require` (4)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/identity.js:3` | Self: 0.0% (0us) | Total: 0.5% (7.8ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `for` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1782` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (2)

**Calls:**
- `visit` (1)
- `visit` (1)

### `normalizeMermaidSourceWithOverrides`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:762` | Self: 0.0% (0us) | Total: 1.0% (14.3ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (4)

**Calls:**
- `normalizeSource` (2)
- `normalizeMermaidSource` (1)
- `normalizeMermaidSource` (1)

### `measureRenderStage`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:30` | Self: 0.0% (0us) | Total: 54.9% (783.3ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (200)
- `renderResolvedMermaidSVG` (148)
- `renderPositionedWithTextMeasurement` (72)
- `renderPositionedWithTextMeasurement` (34)
- `(anonymous)` (33)
- `renderPositionedWithTextMeasurement` (25)
- `executeInspectedGraphicalRequest` (25)
- `renderPositionedWithTextMeasurement` (1)

**Calls:**
- `retainedPositionedScene` (193)
- `positionFamilyForNativeRender` (148)
- `positionedPaintCertification` (72)
- `applyOutputSecurityPolicy` (34)
- `(anonymous)` (25)
- `layoutLayeredGraph` (23)
- `resolveRenderRequestForExecution` (9)
- `layoutLayeredGraph` (7)
- `retainedPositionedScene` (6)
- `resolveRenderRequestForExecution` (4)
- `resolveRenderRequestForExecution` (4)
- `resolveRenderRequestForExecution` (3)
- `resolveRenderRequestForExecution` (3)
- `resolveRenderRequestForExecution` (1)
- `(anonymous)` (1)
- `retainedPositionedScene` (1)
- `retainedNativeDrawing` (1)
- `resolveRenderRequestForExecution` (1)
- `(anonymous)` (1)
- `layoutLayeredGraph` (1)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:702` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `inlineResolvedColors` (1)

**Calls:**
- `cssPaintDefinitions` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:975` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `prepareMarkerPolygonInk` (1)

**Calls:**
- `work` (1)

### `validateStyleSpec`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:453` | Self: 0.0% (0us) | Total: 0.2% (3.2ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (1)

**Calls:**
- `validateRoleStyles` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:322` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `reserve` (1)

### `projectClassRectangleContacts`
`/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:164` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (1)

**Calls:**
- `addClassSvgNumbers` (1)

### `validatePrimitiveCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:333` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `graphicalBackendCapabilityClaims` (1)

**Calls:**
- `primitiveCapabilityClaimKey` (1)

### `deepFreeze`
`/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` | Self: 0.0% (0us) | Total: 1.1% (16.1ms) | Samples: 0

**Called by:**
- `deepFreeze` (12)
- `(module)` (1)

**Calls:**
- `deepFreeze` (12)
- `values` (1)

### `contrastRatio`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:85` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `ensureContrast` (1)

**Calls:**
- `srgbRelativeLuminance` (1)

### `registerBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:468` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `validateBackendCapabilities` (2)

### `assertKnownConnectorFields`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:158` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `isArray` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1718` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `Set` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:25` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `forEach` (1)

**Calls:**
- `has` (1)

### `paintAttribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:493` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `paintAttributes` (1)

**Calls:**
- `attribute` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:190` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `qualify` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:162` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (1)

**Calls:**
- `isWhitespace` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1764` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `walk` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:123` | Self: 0.0% (0us) | Total: 14.2% (203.0ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (139)

**Calls:**
- `withGraphLayoutDecisionObserver` (139)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:115` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:75` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `validateSerializableRenderOptions` (1)

**Calls:**
- `filter` (1)

### `assertFinalBoundaryContacts`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:359` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `finalizeFlatMeasuredMarkers` (1)

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `get` (1)

### `reduce`
`[native code]` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)
- `advance` (1)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `parseClassInteractionWithAuthored`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:934` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `classifyClassStatement` (1)

**Calls:**
- `parseProtected` (1)

### `assessRenderedLayoutHardViolations`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:211` | Self: 0.0% (0us) | Total: 0.3% (4.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `assessFamilyLayout` (2)
- `assessFamilyLayout` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:646` | Self: 0.0% (0us) | Total: 0.4% (6.7ms) | Samples: 0

**Called by:**
- `solidInteriors` (2)
- `leaf` (2)

**Calls:**
- `pathBounds` (1)
- `pathBounds` (1)
- `pathBounds` (1)
- `pathBounds` (1)

### `compareClassSvgSum`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:54` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `projectClassRectangleContacts` (1)

**Calls:**
- `emitted` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1040` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `stringify` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1392` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `map` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1728` | Self: 0.0% (0us) | Total: 0.3% (5.3ms) | Samples: 0

**Called by:**
- `measureRenderStage` (4)

**Calls:**
- `validateSerializableRenderOptions` (2)
- `validateSerializableRenderOptions` (1)
- `validateSerializableRenderOptions` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1670` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `createExtensionIdentity` (1)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:178` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

**Calls:**
- `svgStyleRanges` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:201` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (2)

**Calls:**
- `stringify` (2)

### `retainedPositionedScene`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:63` | Self: 0.0% (0us) | Total: 19.2% (273.9ms) | Samples: 0

**Called by:**
- `measureRenderStage` (193)

**Calls:**
- `withTextMeasurementExecution` (193)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:15` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `certifyScenePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1426` | Self: 0.0% (0us) | Total: 3.5% (51.0ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (32)

**Calls:**
- `inspectScenePaintGeometry` (31)
- `inspectScenePaintGeometry` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:214` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `connector` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:464` | Self: 0.0% (0us) | Total: 0.3% (4.4ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (3)

**Calls:**
- `setConnectorTerminalProjection` (3)

### `readXmlNameEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:104` | Self: 0.0% (0us) | Total: 0.2% (3.1ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (2)

**Calls:**
- `xmlNameCharacter` (2)

### `internal:stream`
`internal:stream:2` | Self: 0.0% (0us) | Total: 0.6% (9.8ms) | Samples: 0

**Called by:**
- `anonymous` (7)

**Calls:**
- `anonymous` (7)

### `transformSvgCssValues`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:308` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `resolveSvgColors` (2)

**Calls:**
- `map` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:907` | Self: 0.0% (0us) | Total: 0.3% (4.9ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (4)

**Calls:**
- `checkInertGroup` (2)
- `checkInertGroup` (1)
- `checkInertGroup` (1)

### `internal:streams/readable`
`internal:streams/readable:50` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeBitMapDescriptor` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:537` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:543` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1709` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `filter` (1)

### `hasOwned`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:11` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `qualify` (1)

**Calls:**
- `apply` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:340` | Self: 0.0% (0us) | Total: 2.9% (42.4ms) | Samples: 0

**Called by:**
- `forEach` (27)

**Calls:**
- `leaf` (14)
- `leaf` (4)
- `leaf` (3)
- `leaf` (2)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:185` | Self: 0.0% (0us) | Total: 0.3% (5.2ms) | Samples: 0

**Calls:**
- `map` (3)

### `detectInstalledFamilyDescriptorFromFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts:60` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `classifyMermaidFamilyDescriptorFromFirstLine` (1)

**Calls:**
- `detectRegisteredFamilyDescriptorFromFirstLine` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:593` | Self: 0.0% (0us) | Total: 0.2% (2.9ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `paintedStrokeExtent` (1)
- `paintedStrokeExtent` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:13` | Self: 0.0% (0us) | Total: 0.0% (987us) | Samples: 0

**Calls:**
- `bound require` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:57` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:61` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `emitted` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1569` | Self: 0.0% (0us) | Total: 0.3% (4.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `captureFields` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:825` | Self: 0.0% (0us) | Total: 0.2% (2.9ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `identityAttributes` (1)
- `identityAttributes` (1)

### `finalizeFlatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:657` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `assertFinalBoundaryContacts` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:374` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (1)

**Calls:**
- `shape` (1)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1199` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `filter` (1)

### `o`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 6.5% (92.9ms) | Samples: 0

**Called by:**
- `r` (1)

**Calls:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:317` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `inspectScenePaintGeometry` (1)

**Calls:**
- `freeze` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:565` | Self: 0.0% (0us) | Total: 1.0% (15.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (9)

**Calls:**
- `scoreMeasuredRouteCrossingsWithAdmission` (6)
- `scoreMeasuredRouteCrossingsWithAdmission` (1)
- `scoreMeasuredRouteCrossingsWithAdmission` (1)
- `scoreMeasuredRouteCrossings` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:4` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `finishClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:791` | Self: 0.0% (0us) | Total: 2.9% (42.4ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (28)

**Calls:**
- `finalizeClassSurfaces` (17)
- `finalizeClassSurfaces` (4)
- `finalizeClassSurfaces` (4)
- `finalizeClassSurfaces` (1)
- `finalizeClassSurfaces` (1)
- `finalizeClassSurfaces` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:315` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `validateNode` (1)
- `validateMarker` (1)

**Calls:**
- `numericCss` (1)
- `numericCss` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:15` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `connectorMarkerPaintRegions`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:353` | Self: 0.0% (0us) | Total: 1.3% (18.7ms) | Samples: 0

**Called by:**
- `prepareMarkerPolygonInk` (6)
- `assertClassMarkerMeaning` (5)
- `certifyNativePaint` (2)

**Calls:**
- `forEach` (13)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1770` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `includes` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1008` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `report` (1)

**Calls:**
- `drawn` (1)

### `renderContractDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1118` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `resolveAppearance` (1)

**Calls:**
- `admitRenderContractDigestInput` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:10` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `report`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:235` | Self: 0.0% (0us) | Total: 1.6% (23.9ms) | Samples: 0

**Called by:**
- `prove` (20)

**Calls:**
- `runBackendConformance` (9)
- `runBackendConformance` (4)
- `runBackendConformance` (4)
- `runBackendConformance` (1)
- `runBackendConformance` (1)
- `runBackendConformance` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:114` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `flowchartMarkerResources` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:701` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (1)

**Calls:**
- `replace` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:218` | Self: 0.0% (0us) | Total: 0.9% (13.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (10)

**Calls:**
- `inlineResolvedColors` (7)
- `resolveSvgColors` (3)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:181` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (2)

**Calls:**
- `scopeHash` (1)
- `scopeHash` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:974` | Self: 0.0% (0us) | Total: 0.3% (4.5ms) | Samples: 0

**Called by:**
- `map` (4)

**Calls:**
- `connector/subpaths/render` (1)
- `document/resources/serialize` (1)
- `nativeOrEmulated` (1)
- `connector/labels/render` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:354` | Self: 0.0% (0us) | Total: 0.3% (4.3ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (2)

**Calls:**
- `toneOnFill` (1)
- `toneOnFill` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:7` | Self: 0.0% (0us) | Total: 0.5% (7.9ms) | Samples: 0

**Called by:**
- `anonymous` (6)

**Calls:**
- `bound require` (6)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:127` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `overlaps` (1)

### `geometryElements`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:66` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `serializeMarkerResource` (1)

**Calls:**
- `paintAttributes` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:134` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `read` (1)

### `hooks`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:507` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `rendered`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:427` | Self: 0.0% (0us) | Total: 0.8% (11.9ms) | Samples: 0

**Called by:**
- `runBackendConformance` (9)
- `runBackendConformance` (1)

**Calls:**
- `render` (9)
- `render` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1546` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `executionCapabilityDecision` (1)

### `legibleOnEvery`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:559` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `textTones` (1)

**Calls:**
- `ensureContrast` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:777` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)
- `validateNode` (1)

**Calls:**
- `push` (1)
- `stringify` (1)

### `finishClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:771` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `retainClassRectangleContacts` (1)

### `projectSvgCss`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:287` | Self: 0.0% (0us) | Total: 0.5% (7.2ms) | Samples: 0

**Called by:**
- `colorResolution` (6)

**Calls:**
- `scanStartTags` (2)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `snapshotScenePrimitiveCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1541` | Self: 0.0% (0us) | Total: 0.2% (3.6ms) | Samples: 0

**Called by:**
- `snapshotDescriptorArray` (2)

**Calls:**
- `fromEntries` (1)
- `captureFields` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/resolve-block-map.js:8` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1621` | Self: 0.0% (0us) | Total: 8.6% (123.7ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (89)

**Calls:**
- `validateNode` (39)
- `validateNode` (15)
- `validateNode` (5)
- `validateNode` (4)
- `validateNode` (3)
- `validateNode` (3)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `readXmlNameEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:102` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (1)

**Calls:**
- `xmlAsciiLetter` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:271` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `set` (1)

### `node:stream`
`node:stream:2` | Self: 0.0% (0us) | Total: 0.9% (14.2ms) | Samples: 0

**Called by:**
- `anonymous` (8)

**Calls:**
- `anonymous` (8)

### `inspectScenePaintGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:154` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `certifyScenePaint` (1)

**Calls:**
- `beginSceneWriteInspection` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1989` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `some` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Collection.js:3` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:208` | Self: 0.0% (0us) | Total: 4.1% (58.5ms) | Samples: 0

**Calls:**
- `expandLocalReferences` (3)
- `(anonymous)` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:824` | Self: 0.0% (0us) | Total: 0.6% (9.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (6)

**Calls:**
- `attribute` (6)

### `withDeferredTerminalProjections`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:16` | Self: 0.0% (0us) | Total: 3.2% (46.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (32)

**Calls:**
- `lowerClassDrawing` (15)
- `lowerClassDrawing` (9)
- `lowerClassDrawing` (4)
- `lowerClassDrawing` (1)
- `lowerClassDrawing` (1)
- `lowerClassDrawing` (1)
- `lowerClassDrawing` (1)

### `snapshotBackendCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:330` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `freezeBuiltInBackend` (1)

**Calls:**
- `map` (1)

### `retainClassRectangleContacts`
`/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:136` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:761` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `resolveCss` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:705` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `classStatementEnds` (1)

**Calls:**
- `map` (1)

### `node:fs`
`node:fs:8` | Self: 0.0% (0us) | Total: 0.3% (4.6ms) | Samples: 0

**Calls:**
- `anonymous` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:183` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `measureRenderStage` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:13` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `toFinite` (1)

### `visitSvgFirstTagAttributes`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:106` | Self: 0.0% (0us) | Total: 0.5% (7.1ms) | Samples: 0

**Called by:**
- `checkInertGroup` (5)

**Calls:**
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1215` | Self: 0.0% (0us) | Total: 0.2% (4.2ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (2)

**Calls:**
- `validateMarker` (1)
- `validateMarker` (1)

### `string`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:140` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `apply` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:180` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `possibleShapeFill` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:665` | Self: 0.0% (0us) | Total: 0.2% (3.1ms) | Samples: 0

**Called by:**
- `color` (2)

**Calls:**
- `colorResolution` (2)

### `inspectScenePaintGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:155` | Self: 0.0% (0us) | Total: 3.4% (49.7ms) | Samples: 0

**Called by:**
- `certifyScenePaint` (31)

**Calls:**
- `inspectScene` (30)
- `finish` (1)

### `createRenderOutputDescriptors`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:171` | Self: 0.0% (0us) | Total: 0.3% (4.7ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `map` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:431` | Self: 0.0% (0us) | Total: 0.4% (6.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `(anonymous)` (5)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `color` (1)

**Calls:**
- `slice` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:716` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (1)

**Calls:**
- `every` (1)

### `zlibBufferSync`
`node:zlib:94` | Self: 0.0% (0us) | Total: 0.5% (7.8ms) | Samples: 0

**Called by:**
- `(module)` (2)
- `(module)` (2)
- `(module)` (1)

**Calls:**
- `processChunkSync` (4)
- `concat` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:682` | Self: 0.0% (0us) | Total: 0.2% (3.8ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (3)

**Calls:**
- `paintAttributes` (1)
- `paintAttributes` (1)
- `paintAttributes` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:194` | Self: 0.0% (0us) | Total: 0.6% (9.8ms) | Samples: 0

**Called by:**
- `visit` (5)
- `visit` (1)

**Calls:**
- `boundedUtf8ByteLength` (5)
- `boundedUtf8ByteLength` (1)

### `flowchartMarkerResources`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:80` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `arrowMarkerResources` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:330` | Self: 0.0% (0us) | Total: 0.4% (6.4ms) | Samples: 0

**Called by:**
- `forEach` (5)

**Calls:**
- `markerBoundsAt` (1)
- `markerBoundsAt` (1)
- `markerBoundsAt` (1)
- `markerBoundsAt` (1)
- `markerBoundsAt` (1)

### `parseClassRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1292` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `classifyClassStatement` (1)

**Calls:**
- `parseMarkerlessClassRelationship` (1)

### `resolveCss`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:736` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `toHex` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:35` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `build` (1)

**Calls:**
- `sort` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringifyString.js:4` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:308` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (2)

**Calls:**
- `shape` (1)
- `shape` (1)

### `graphicalBackendCapabilityClaims`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:271` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `createSketchBackend` (1)

**Calls:**
- `validatePrimitiveCapabilities` (1)

### `createMeasuredLayoutCache`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:63` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `NativeResults` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:692` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (1)

**Calls:**
- `map` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:754` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `classStatementEnds` (1)

**Calls:**
- `classStatement` (1)

### `retainedPositionedScene`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:65` | Self: 0.0% (0us) | Total: 0.5% (7.5ms) | Samples: 0

**Called by:**
- `measureRenderStage` (6)

**Calls:**
- `prepare` (6)

### `assertAdmissibleSceneDoc`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation.ts:247` | Self: 0.0% (0us) | Total: 9.0% (129.6ms) | Samples: 0

**Called by:**
- `admitSceneDocumentWith` (94)

**Calls:**
- `validateSceneDocument` (89)
- `validateSceneDocument` (4)
- `validateSceneDocument` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:7` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:217` | Self: 0.0% (0us) | Total: 0.6% (8.9ms) | Samples: 0

**Called by:**
- `visit` (7)

**Calls:**
- `get` (7)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:346` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (1)

**Calls:**
- `connectorContourSemantics` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:1026` | Self: 0.0% (0us) | Total: 1.5% (22.3ms) | Samples: 0

**Called by:**
- `seatFinalMeasuredMarkers` (13)

**Calls:**
- `(anonymous)` (13)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1481` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `viewportBox` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:255` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `deepFreeze` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:191` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `styleSpecJsonSchema` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1763` | Self: 0.0% (0us) | Total: 0.8% (11.9ms) | Samples: 0

**Called by:**
- `measureRenderStage` (9)

**Calls:**
- `freeze` (9)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/common/seq.js:4` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringifyPair.js:5` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:619` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `validateNode` (1)
- `validateNode` (1)

**Calls:**
- `validatePaint` (1)
- `validatePaint` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1860` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `find` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1592` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (2)

**Calls:**
- `tree` (2)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:95` | Self: 0.0% (0us) | Total: 2.6% (38.2ms) | Samples: 0

**Called by:**
- `measureRenderStage` (23)

**Calls:**
- `finalizeFlatMeasuredMarkers` (22)
- `finalizeFlatMeasuredMarkers` (1)

### `prepare`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:353` | Self: 0.0% (0us) | Total: 0.5% (7.5ms) | Samples: 0

**Called by:**
- `retainedPositionedScene` (6)

**Calls:**
- `finish` (1)
- `finish` (1)
- `finish` (1)
- `finish` (1)
- `finish` (1)
- `finish` (1)

### `render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:157` | Self: 0.0% (0us) | Total: 0.4% (6.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `map` (5)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1624` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (1)

**Calls:**
- `validateAggregateReferences` (1)

### `classifyClassStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:536` | Self: 0.0% (0us) | Total: 0.3% (4.3ms) | Samples: 0

**Called by:**
- `readClassStatements` (3)

**Calls:**
- `parseMarkedClassRelationship` (1)
- `parseClassRelationship` (1)
- `parseMarkedClassRelationship` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/block/markers.ts:10` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `scoreMeasuredRouteCrossingsWithAdmission`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:753` | Self: 0.0% (0us) | Total: 0.2% (4.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)
- `validate` (1)

**Calls:**
- `separatedSharpSupportBounds` (1)
- `separatedSharpSupportBounds` (1)

### `processChunkSync`
`node:zlib:203` | Self: 0.0% (0us) | Total: 0.4% (5.7ms) | Samples: 0

**Called by:**
- `zlibBufferSync` (4)

**Calls:**
- `writeSync` (4)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:49` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `some` (1)

### `detectorClaims`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1596` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `find` (2)

**Calls:**
- `descriptorOwnsDetectionLine` (1)
- `some` (1)

### `flatIntoArrayWithCallback`
`[native code]` | Self: 0.0% (0us) | Total: 0.2% (2.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)
- `deriveConnectorTerminalProjection` (1)

**Calls:**
- `map` (1)
- `(anonymous)` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:131` | Self: 0.0% (0us) | Total: 0.3% (5.4ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (4)

**Calls:**
- `renderRelationship` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)

### `expandLocalReferences`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` | Self: 0.0% (0us) | Total: 15.9% (227.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (9)
- `(module)` (3)

**Calls:**
- `map` (12)

### `setConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:53` | Self: 0.0% (0us) | Total: 0.3% (4.4ms) | Samples: 0

**Called by:**
- `connector` (3)

**Calls:**
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:173` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `projectSvgCss` (1)

**Calls:**
- `has` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 19.5% (278.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `(anonymous)` (2)
- `r` (1)

### `finalizeClassSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:802` | Self: 0.0% (0us) | Total: 0.5% (7.3ms) | Samples: 0

**Called by:**
- `finishClassLayout` (4)

**Calls:**
- `projectClassRectangleContacts` (3)
- `projectClassRectangleContacts` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:605` | Self: 0.0% (0us) | Total: 0.1% (2.8ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (2)

**Calls:**
- `attribute` (2)

### `snapshotCapabilityCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1559` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `snapshotDescriptorArray` (1)

**Calls:**
- `snapshotDescriptorArray` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/createNode.js:5` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `relationAccessibility`
`/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `shape` (1)

**Calls:**
- `sceneRoleTraits` (1)

### `possibleShapeFill`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:127` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `solidInteriors` (1)

**Calls:**
- `sceneGroupOpacity` (1)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:98` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `every` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1065` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `validatePoint` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:194` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `seatFinalMeasuredMarkers` (1)

**Calls:**
- `refresh` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts:257` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `map` (1)

### `prove`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:264` | Self: 0.0% (0us) | Total: 1.6% (23.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (20)

**Calls:**
- `report` (20)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/omap.js:7` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:901` | Self: 0.0% (0us) | Total: 1.4% (20.6ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (15)

**Calls:**
- `validateNode` (4)
- `validateNode` (3)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `color`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1039` | Self: 0.0% (0us) | Total: 0.2% (3.2ms) | Samples: 0

**Called by:**
- `prepareMarkerPolygonInk` (2)

**Calls:**
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)

### `internal:streams/pipeline`
`internal:streams/pipeline:2` | Self: 0.0% (0us) | Total: 0.5% (8.4ms) | Samples: 0

**Called by:**
- `anonymous` (6)

**Calls:**
- `anonymous` (6)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1190` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `(anonymous)` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:323` | Self: 0.0% (0us) | Total: 0.6% (9.1ms) | Samples: 0

**Called by:**
- `measureClassCards` (5)
- `text` (1)

**Calls:**
- `prepareDisplayText` (2)
- `prepareDisplayText` (2)
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:403` | Self: 0.0% (0us) | Total: 0.3% (4.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `readXmlNameEnd` (2)
- `readXmlNameEnd` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1746` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `map` (1)

### `sceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `relationAccessibility` (1)

**Calls:**
- `resolveSceneRoleTraits` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:320` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `measureClassCards` (1)

**Calls:**
- `customTextMeasurementActive` (1)

### `withSvgInspectionCache`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:20` | Self: 0.0% (0us) | Total: 52.8% (753.1ms) | Samples: 0

**Called by:**
- `withRenderStageObserver` (521)

**Calls:**
- `consumeResolvedGraphicalRequest` (496)
- `executeInspectedGraphicalRequest` (25)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:662` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)
- `inspectSecurity` (1)

**Calls:**
- `unsafeCssReferences` (1)
- `unsafeCssReferences` (1)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:39` | Self: 0.0% (0us) | Total: 0.5% (7.1ms) | Samples: 0

**Called by:**
- `group` (3)
- `validateNode` (2)

**Calls:**
- `visitSvgFirstTagAttributes` (5)

### `toHex`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:43` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `resolveCss` (1)

**Calls:**
- `map` (1)

### `internal:streams/destroy`
`internal:streams/destroy:2` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:133` | Self: 0.0% (0us) | Total: 0.2% (3.8ms) | Samples: 0

**Called by:**
- `get` (2)
- `setConnectorTerminalProjection` (1)

**Calls:**
- `terminalMarker` (1)
- `terminalMarker` (1)
- `copyDataProperties` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:4` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:237` | Self: 0.0% (0us) | Total: 0.3% (4.9ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (4)

**Calls:**
- `scopeSvgStyles` (2)
- `replaceSvgRootStartTag` (1)
- `scopeSvgStyles` (1)

### `validateConnectorProjectionConsistency`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1364` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `every` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:466` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `prepare` (1)

**Calls:**
- `readDefinitions` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:117` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `assertMarkerPaint` (1)

### `layoutMeasuredForest`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:96` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `map` (1)

### `applyOutputSecurityPolicy`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:727` | Self: 0.0% (0us) | Total: 3.8% (55.0ms) | Samples: 0

**Called by:**
- `measureRenderStage` (34)
- `validateSceneDocument` (4)

**Calls:**
- `inspectOwnedSvgOnce` (38)

### `Zlib`
`node:zlib:298` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `Gunzip` (1)
- `Gzip` (1)

**Calls:**
- `ZlibBase` (2)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:430` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `measureClassCards` (1)

**Calls:**
- `every` (1)

### `registerBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:470` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `freezeBuiltInBackend` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:411` | Self: 0.0% (0us) | Total: 0.9% (13.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (9)

**Calls:**
- `add` (9)

### `completeBuiltinDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1374` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `createExtensionIdentity` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:3` | Self: 0.0% (0us) | Total: 15.8% (226.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `bound require` (5)

### `gzipSync`
`node:zlib:360` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `Gzip` (1)

### `connector/subpaths/render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:660` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `drawn` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:322` | Self: 0.0% (0us) | Total: 0.2% (3.4ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `connector` (1)
- `connector` (1)

### `classifyClassStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:449` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `readClassStatements` (2)

**Calls:**
- `parseClassInteractionWithAuthored` (1)
- `parseClassInteractionWithAuthored` (1)

### `roleStyleJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:496` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:597` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `roleStyleJsonSchema` (1)

### `admitSceneDocumentWith`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:270` | Self: 0.0% (0us) | Total: 9.0% (129.6ms) | Samples: 0

**Called by:**
- `admitFamilyScene` (86)
- `render` (8)

**Calls:**
- `assertAdmissibleSceneDoc` (94)

### `assertFinalClassSharpContacts`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:862` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (1)

**Calls:**
- `createOwnedMeasuredRouteContactValidator` (1)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:454` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (2)

**Calls:**
- `sharedRenderOptionsJsonSchema` (2)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:206` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `create` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:273` | Self: 0.0% (0us) | Total: 1.6% (23.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (20)

**Calls:**
- `prove` (20)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:14` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1583` | Self: 0.0% (0us) | Total: 0.5% (7.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (5)

**Calls:**
- `snapshotDescriptorArray` (4)
- `freeze` (1)

### `r`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 6.5% (92.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `o` (1)

### `renderedSvgDigest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:61` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `stringify` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:32` | Self: 0.0% (0us) | Total: 0.3% (4.5ms) | Samples: 0

**Calls:**
- `zlibBufferSync` (2)
- `stringify` (1)

### `receiptOf`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:762` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `copyDataProperties` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:101` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `renderClassBox` (1)

**Calls:**
- `relationAccessibility` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:311` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `safeCssPaint` (1)

### `declareFamilyScenePrimitiveEvidence`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:247` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `completeBuiltinDescriptor` (1)

**Calls:**
- `Map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `(anonymous)` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1088` | Self: 0.0% (0us) | Total: 0.3% (4.5ms) | Samples: 0

**Called by:**
- `report` (4)

**Calls:**
- `map` (4)

### `inspectOwnedSvgOnce`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:46` | Self: 0.0% (0us) | Total: 3.9% (56.2ms) | Samples: 0

**Called by:**
- `applyOutputSecurityPolicy` (38)
- `verifyNoExternalRefs` (1)

**Calls:**
- `(anonymous)` (37)
- `inspectSecurity` (1)
- `inspectSecurityTail` (1)

### `projectClassPositioned`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:23` | Self: 0.0% (0us) | Total: 0.4% (5.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `map` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:5` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1553` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `createTextMeasurementExecution` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` | Self: 0.0% (0us) | Total: 1.0% (15.4ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (6)
- `geometryAttributes` (2)
- `geometryAttributes` (1)
- `hooks` (1)
- `identityAttributes` (1)

**Calls:**
- `formatSvgNumericAttribute` (7)
- `formatSvgNumericAttribute` (2)
- `formatSvgNumber` (1)
- `formatSvgNumericAttribute` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:186` | Self: 0.0% (0us) | Total: 0.3% (5.2ms) | Samples: 0

**Called by:**
- `map` (3)

**Calls:**
- `createExtensionIdentity` (3)

### `walk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1749` | Self: 0.0% (0us) | Total: 0.7% (10.6ms) | Samples: 0

**Called by:**
- `walk` (5)
- `visit` (1)

**Calls:**
- `walk` (5)
- `walk` (1)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:988` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `authoredClassStatements` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:8` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:15` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `fSpan` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` | Self: 0.0% (0us) | Total: 15.9% (227.9ms) | Samples: 0

**Called by:**
- `map` (12)

**Calls:**
- `expandLocalReferences` (9)
- `expandLocalReferences` (3)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:420` | Self: 0.0% (0us) | Total: 0.4% (5.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `readXmlDataEnd` (2)
- `readXmlDataEnd` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:281` | Self: 0.0% (0us) | Total: 0.8% (11.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (6)
- `lowerClassDrawing` (1)

**Calls:**
- `connectorGeometryEndpoints` (6)
- `connectorGeometryEndpoints` (1)

### `finalizeClassSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:813` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `repairClassNoteSeats` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:413` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `isXmlWhitespace` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:310` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `map` (2)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:402` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `measureClassCards` (1)

**Calls:**
- `forEach` (1)

### `measureClassCards`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:186` | Self: 0.0% (0us) | Total: 1.2% (18.2ms) | Samples: 0

**Called by:**
- `layoutClassDiagram` (12)

**Calls:**
- `preparePixelText` (5)
- `preparePixelText` (1)
- `preparePixelText` (1)
- `preparePixelText` (1)
- `preparePixelText` (1)
- `preparePixelText` (1)
- `preparePixelText` (1)
- `preparePixelText` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:143` | Self: 0.0% (0us) | Total: 0.3% (4.8ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (3)

**Calls:**
- `assessRenderedLayoutHardViolations` (3)

### `validateMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:365` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `entries` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:693` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `classTerminalLead` (1)

### `terminalMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:58` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `deriveConnectorTerminalProjection` (1)

**Calls:**
- `copyDataProperties` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:144` | Self: 0.0% (0us) | Total: 0.9% (14.0ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (9)

**Calls:**
- `forEach` (9)

### `internal:streams/legacy`
`internal:streams/legacy:2` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:140` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Calls:**
- `graphicalBackendCapabilityClaims` (1)

### `createTextMeasurementExecution`
`/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:70` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `resolveExecutionPlan` (1)

**Calls:**
- `snapshotTextMeasurementProfile` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1841` | Self: 0.0% (0us) | Total: 0.3% (4.4ms) | Samples: 0

**Called by:**
- `find` (3)

**Calls:**
- `test` (1)
- `detectsJourneyFamily` (1)
- `detectsQuadrantFamily` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:5` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `sharedRenderOptionsJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:485` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `validateSerializableRenderOptions` (2)

**Calls:**
- `cloneValue` (1)
- `cloneValue` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:12` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1018` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (1)

**Calls:**
- `proofRecord` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:998` | Self: 0.0% (0us) | Total: 0.3% (5.0ms) | Samples: 0

**Called by:**
- `report` (4)

**Calls:**
- `withTextMeasurementExecution` (4)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:552` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `assertFinalClassSharpContacts` (1)

**Calls:**
- `max` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:780` | Self: 0.0% (0us) | Total: 4.0% (58.2ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (39)
- `validateNode` (3)

**Calls:**
- `validateNodeSerialization` (35)
- `validateNodeSerialization` (7)

### `renderRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:560` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (1)

**Calls:**
- `find` (1)

### `gunzipSync`
`node:zlib:360` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `Gunzip` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:6` | Self: 0.0% (0us) | Total: 0.2% (2.9ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `ZlibBase`
`node:zlib:123` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `Zlib` (2)

**Calls:**
- `Transform` (2)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1049` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `report` (1)

**Calls:**
- `verifyNoExternalRefs` (1)

### `resolvedInlineColorAttribute`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:683` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `color` (3)

**Calls:**
- `resolveCss` (2)
- `resolveCss` (1)

### `classStatementEnds`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:650` | Self: 0.0% (0us) | Total: 0.6% (9.0ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (7)

**Calls:**
- `readClassStatements` (3)
- `readClassStatements` (1)
- `readClassStatements` (1)
- `readClassStatements` (1)
- `readClassStatements` (1)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:992` | Self: 0.0% (0us) | Total: 0.4% (5.8ms) | Samples: 0

**Called by:**
- `layout` (4)

**Calls:**
- `readClassStatements` (2)
- `readClassStatements` (1)
- `readClassStatements` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:273` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Calls:**
- `booleanSchema` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:420` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureClassCards` (1)

**Calls:**
- `advance` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:139` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `get` (1)

**Calls:**
- `copyDataProperties` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/requirement/tokens.ts:64` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:251` | Self: 0.0% (0us) | Total: 0.3% (4.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `freeze` (3)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:186` | Self: 0.0% (0us) | Total: 7.3% (104.5ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (72)

**Calls:**
- `measureRenderStage` (72)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:659` | Self: 0.0% (0us) | Total: 0.2% (4.2ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (3)

**Calls:**
- `buildClassEndpointMarkerTemplates` (2)
- `map` (1)

### `unsafeCssReferences`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:603` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `inspectAttributeSecurity` (1)

**Calls:**
- `normalizedReference` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:173` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Calls:**
- `createPngOutputOptionFieldDescriptors` (1)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:41` | Self: 0.0% (0us) | Total: 0.1% (2.8ms) | Samples: 0

**Called by:**
- `attribute` (2)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:145` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `rendered` (1)

**Calls:**
- `admitBackendSceneDocument` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:6` | Self: 0.0% (0us) | Total: 0.2% (3.9ms) | Samples: 0

**Called by:**
- `anonymous` (3)

**Calls:**
- `bound require` (3)

### `measureTextWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:206` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `measureText` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:448` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `prepare` (1)

**Calls:**
- `rootPreludeMatches` (1)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1656` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (2)

**Calls:**
- `applyFamilyRequestNormalization` (1)
- `applyFamilyRequestNormalization` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Called by:**
- `markerBoundsAt` (2)
- `connectorPaintBounds` (1)

**Calls:**
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:185` | Self: 0.0% (0us) | Total: 19.8% (282.8ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (200)

**Calls:**
- `measureRenderStage` (200)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:129` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (1)

**Calls:**
- `sourceTokenAt` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:161` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `renderRelationshipLabels` (1)

### `mermaidFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:148` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `normalizeMermaidSource` (1)

**Calls:**
- `splitHeaderStatement` (1)

### `withTextMeasurementExecution`
`/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:135` | Self: 0.0% (0us) | Total: 69.2% (987.7ms) | Samples: 0

**Called by:**
- `consumeResolvedGraphicalRequest` (347)
- `retainedPositionedScene` (193)
- `positionFamilyForNativeRender` (147)
- `runBackendConformance` (4)

**Calls:**
- `renderPositionedWithTextMeasurement` (200)
- `admitFamilyScene` (161)
- `(anonymous)` (139)
- `renderPositionedWithTextMeasurement` (72)
- `renderPositionedWithTextMeasurement` (34)
- `(anonymous)` (32)
- `renderPositionedWithTextMeasurement` (25)
- `renderPositionedWithTextMeasurement` (10)
- `(anonymous)` (5)
- `renderPositionedWithTextMeasurement` (4)
- `(anonymous)` (3)
- `createFixture` (1)
- `createFixture` (1)
- `renderPositionedWithTextMeasurement` (1)
- `createFixture` (1)
- `renderPositionedWithTextMeasurement` (1)
- `createFixture` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1856` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `find` (1)

### `positionFamilyForNativeRender`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:67` | Self: 0.0% (0us) | Total: 15.3% (219.1ms) | Samples: 0

**Called by:**
- `measureRenderStage` (148)

**Calls:**
- `withTextMeasurementExecution` (147)
- `positionFamily` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:132` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `get` (1)

**Calls:**
- `map` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:615` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `markerBoundsAt` (1)

### `color`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1038` | Self: 0.0% (0us) | Total: 0.5% (8.2ms) | Samples: 0

**Called by:**
- `prepareMarkerPolygonInk` (6)

**Calls:**
- `resolvedInlineColorAttribute` (3)
- `(anonymous)` (2)
- `(anonymous)` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered.ts:16` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `createMeasuredLayoutCache` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` | Self: 0.0% (0us) | Total: 0.7% (10.1ms) | Samples: 0

**Called by:**
- `map` (9)

**Calls:**
- `cloneValue` (5)
- `map` (4)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:813` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `validateGeometry` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:374` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:4` | Self: 0.0% (0us) | Total: 0.0% (987us) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:703` | Self: 0.0% (0us) | Total: 0.7% (10.5ms) | Samples: 0

**Called by:**
- `validateNode` (7)

**Calls:**
- `boundedUtf8ByteLength` (5)
- `boundedUtf8ByteLength` (2)

### `ensureSvgIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:92` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `set` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1854` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `find` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1709` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `admitRenderOptionsInput` (1)

### `connectorContourSemantics`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:387` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `connectorUnitTangent` (1)

### `executeInspectedGraphicalRequest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:297` | Self: 0.0% (0us) | Total: 2.9% (41.9ms) | Samples: 0

**Called by:**
- `withSvgInspectionCache` (25)

**Calls:**
- `measureRenderStage` (25)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:359` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (2)

**Calls:**
- `text` (1)
- `text` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:13` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `prepareDisplayText` (1)

**Calls:**
- `freeze` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:142` | Self: 0.0% (0us) | Total: 0.7% (9.9ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (5)

**Calls:**
- `projectClassPositioned` (2)
- `projectClassPositioned` (2)
- `projectClassPositioned` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:817` | Self: 0.0% (0us) | Total: 0.3% (5.1ms) | Samples: 0

**Called by:**
- `validateNode` (4)

**Calls:**
- `validatePaint` (2)
- `validatePaint` (1)
- `validatePaint` (1)

### `finalizeClassSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:834` | Self: 0.0% (0us) | Total: 0.3% (5.5ms) | Samples: 0

**Called by:**
- `finishClassLayout` (4)

**Calls:**
- `assertFinalClassSharpContacts` (3)
- `assertFinalClassSharpContacts` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:533` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `prepare` (1)

**Calls:**
- `decodedSvgAttributeValue` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:431` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `every` (1)

**Calls:**
- `every` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:787` | Self: 0.0% (0us) | Total: 0.4% (5.9ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:800` | Self: 0.0% (0us) | Total: 0.4% (6.7ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (5)

**Calls:**
- `validateMarkAttributes` (3)
- `validateMarkAttributes` (1)
- `validateMarkAttributes` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1031` | Self: 0.0% (0us) | Total: 0.7% (10.6ms) | Samples: 0

**Called by:**
- `report` (9)

**Calls:**
- `rendered` (9)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts:26` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `createHash` (1)

### `emittedBox`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:72` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `writtenClassRoundedHit` (1)

**Calls:**
- `emitted` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:89` | Self: 0.0% (0us) | Total: 0.8% (11.5ms) | Samples: 0

**Called by:**
- `finishClassLayout` (8)

**Calls:**
- `connector` (3)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)

### `parseMarkerlessClassRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1415` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `parseClassRelationship` (1)

**Calls:**
- `parseClassReference` (1)

### `escapeAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:109` | Self: 0.0% (0us) | Total: 0.1% (1.4ms) | Samples: 0

**Called by:**
- `attribute` (1)

**Calls:**
- `escapeXml` (1)

### `scoreMeasuredRouteCrossingsWithAdmission`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:846` | Self: 0.0% (0us) | Total: 0.6% (9.7ms) | Samples: 0

**Called by:**
- `validate` (6)

**Calls:**
- `sharpContactsClear` (3)
- `sharpContactsClear` (1)
- `sharpContactsClear` (1)
- `sharpContactsClear` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:164` | Self: 0.0% (0us) | Total: 0.2% (2.8ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (2)

**Calls:**
- `stringify` (1)
- `outlineKey` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:276` | Self: 0.0% (0us) | Total: 0.2% (3.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `append` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1095` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `validateUnitVector` (1)

### `validateBackendCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:312` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `registerBuiltInBackend` (2)

**Calls:**
- `some` (2)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:711` | Self: 0.0% (0us) | Total: 0.3% (5.6ms) | Samples: 0

**Called by:**
- `seatFinalMeasuredMarkers` (3)

**Calls:**
- `clear` (2)
- `clear` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:51` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `formatSvgNumericAttribute` (1)

**Calls:**
- `formatSvgNumber` (1)

### `caseInsensitiveKeywordPattern`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:102` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `map` (1)

### `verifyNoExternalRefs`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:701` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `runBackendConformance` (1)

**Calls:**
- `inspectOwnedSvgOnce` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:678` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `geometryAttributes` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringify.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `resolvedColorValue`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:601` | Self: 0.0% (0us) | Total: 0.3% (4.3ms) | Samples: 0

**Called by:**
- `toneOnFill` (1)
- `toneOnFill` (1)

**Calls:**
- `diagramColorVariables` (1)
- `diagramColorVariables` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:530` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `svgPathDataProblem` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-doc.js:4` | Self: 0.0% (0us) | Total: 0.4% (6.8ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `bound require` (4)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:285` | Self: 0.0% (0us) | Total: 0.0% (983us) | Samples: 0

**Called by:**
- `lowerClassDrawing` (1)

**Calls:**
- `escapeDisplayAttr` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:24` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `prepareDisplayText` (1)

**Calls:**
- `hasOwned` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:569` | Self: 0.0% (0us) | Total: 0.2% (4.1ms) | Samples: 0

**Called by:**
- `colorResolution` (2)
- `resolvedColorValue` (1)

**Calls:**
- `resolveColors` (2)
- `resolveColors` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:592` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `geometryBounds` (1)

### `rejectUnknownKeys`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:152` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `validateMarkAttributes` (2)

**Calls:**
- `Set` (2)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:829` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `connectorInlineLabelSvg` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:719` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `extractClassLayout` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:587` | Self: 0.0% (0us) | Total: 0.3% (4.4ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (3)

**Calls:**
- `checkInertGroup` (3)

### `registerBuiltInStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:294` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `registerCanonicalStyle` (1)

### `evaluateExtensionCompatibility`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:120` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `createExtensionIdentity` (1)

**Calls:**
- `semVerSatisfies` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` | Self: 0.0% (0us) | Total: 0.3% (5.4ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (4)

**Calls:**
- `geometryAttributes` (2)
- `geometryAttributes` (2)

### `createSketchBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:547` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `graphicalBackendCapabilityClaims` (1)

### `pointsBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:13` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `geometryBounds` (1)

**Calls:**
- `map` (1)

### `arrowMarkerResources`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:34` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `flowchartMarkerResources` (1)

**Calls:**
- `String` (1)

### `writeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:622` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `map` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:176` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `include` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1763` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `has` (1)

### `consumeResolvedGraphicalRequest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:316` | Self: 0.0% (0us) | Total: 49.8% (711.2ms) | Samples: 0

**Called by:**
- `withSvgInspectionCache` (496)

**Calls:**
- `withTextMeasurementExecution` (347)
- `renderResolvedMermaidSVG` (148)
- `renderPositionedMermaidSVG` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:96` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `shortenMeasuredRoutes` (1)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1637` | Self: 0.0% (0us) | Total: 0.3% (4.7ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (4)

**Calls:**
- `applyOutputSecurityPolicy` (4)

### `markerPaintIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1360` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `pay` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1973` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `emittedEndpointMarker` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:4` | Self: 0.0% (0us) | Total: 0.5% (7.8ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:778` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `validateChannels` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:181` | Self: 0.0% (0us) | Total: 0.3% (4.7ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `freezeTransport` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:78` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `bisector` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `markerTerminalDepth` (2)

**Calls:**
- `geometryBounds` (1)
- `pathBounds` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:617` | Self: 0.0% (0us) | Total: 0.2% (3.9ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (3)

**Calls:**
- `replace` (1)
- `ensureSvgIdentity` (1)
- `ensureSvgIdentity` (1)

### `resolveClassRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:105` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `normalizeRequest` (1)

**Calls:**
- `configSpacing` (1)

### `createPngOutputOptionFieldDescriptors`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:105` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `map` (1)

### `boundedImmutableJsonSnapshot`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1243` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `admitRenderOptionsInput` (1)

**Calls:**
- `omitUndefinedObjectFields` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:588` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `validateNodeSerialization` (1)

**Calls:**
- `contextLeaf` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:526` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `renderClassBox` (1)

**Calls:**
- `copyDataProperties` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:555` | Self: 0.0% (0us) | Total: 0.2% (2.9ms) | Samples: 0

**Called by:**
- `assertFinalClassSharpContacts` (2)

**Calls:**
- `scoreMeasuredRouteCrossingsWithAdmission` (1)
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `classTerminalLead`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:215` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `classRelationshipTerminalClearance` (1)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:694` | Self: 0.0% (0us) | Total: 0.2% (3.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `diagramColorVariables` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:3` | Self: 0.0% (0us) | Total: 2.5% (37.0ms) | Samples: 0

**Calls:**
- `bound require` (21)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:713` | Self: 0.0% (0us) | Total: 0.4% (6.0ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (5)

**Calls:**
- `inspectAttributeSecurity` (2)
- `inspectAttributeSecurity` (1)
- `inspectAttributeSecurity` (1)
- `inspectAttributeSecurity` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:106` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `definitions` (1)

### `internal:errors`
`internal:errors:2` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:252` | Self: 0.0% (0us) | Total: 1.4% (20.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (14)

**Calls:**
- `paintBounds` (3)
- `paintBounds` (2)
- `connectorPaintBounds` (2)
- `nodePaintBounds` (1)
- `paintBounds` (1)
- `paintBounds` (1)
- `connectorPaintBounds` (1)
- `connectorPaintBounds` (1)
- `connectorPaintBounds` (1)
- `connectorPaintBounds` (1)

### `textTones`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:545` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `deriveColors` (1)

**Calls:**
- `legibleOnEvery` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:199` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `group` (1)

### `compareCodePointStrings`
`/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts:3` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `sort` (1)

**Calls:**
- `map` (1)

### `terminalMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:60` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `deriveConnectorTerminalProjection` (1)

**Calls:**
- `copyDataProperties` (1)

### `NativeResults`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:21` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `createMeasuredLayoutCache` (1)

**Calls:**
- `(anonymous)` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:500` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `selfContact` (1)

### `expandLocalReferences`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:204` | Self: 0.0% (0us) | Total: 3.9% (56.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `filter` (3)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:97` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `originalNativeDrawingOf` (1)

### `get receipt`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:347` | Self: 0.0% (0us) | Total: 0.3% (4.7ms) | Samples: 0

**Called by:**
- `(module)` (4)

**Calls:**
- `(anonymous)` (2)
- `(anonymous)` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1267` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (2)

**Calls:**
- `validateConnectorProjectionConsistency` (1)
- `validateConnectorProjectionConsistency` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:575` | Self: 0.0% (0us) | Total: 3.1% (45.2ms) | Samples: 0

**Called by:**
- `validateNodeSerialization` (25)
- `(anonymous)` (6)
- `drawn` (2)
- `(anonymous)` (2)

**Calls:**
- `writeSceneNode` (10)
- `writeConnectorSvg` (6)
- `writeConnectorSvg` (4)
- `writeShapeSvg` (3)
- `writeConnectorSvg` (2)
- `writeConnectorSvg` (2)
- `writeShapeSvg` (1)
- `join` (1)
- `writeTextSvg` (1)
- `writeConnectorSvg` (1)
- `writeSceneNode` (1)
- `writeSceneNode` (1)
- `writeConnectorSvg` (1)
- `writeShapeSvg` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `filter` (1)

### `layoutMeasuredForest`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:11` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `some` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:545` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `compound` (2)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:810` | Self: 0.0% (0us) | Total: 0.2% (3.2ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:405` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `xmlSlice` (1)
- `xmlSlice` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/directives.js:3` | Self: 0.0% (0us) | Total: 0.5% (7.8ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `finalizeFlatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:655` | Self: 0.0% (0us) | Total: 2.5% (36.8ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (22)

**Calls:**
- `seatFinalMeasuredMarkers` (21)
- `seatFinalMeasuredMarkers` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:165` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `apply` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:8` | Self: 0.0% (0us) | Total: 0.8% (11.6ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `bound require` (9)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 38.4% | 548.2ms | `[native code]` |
| 6.5% | 92.9ms | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 5.1% | 73.5ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js` |
| 4.8% | 69.5ms | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 3.5% | 50.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 3.2% | 45.7ms | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 2.8% | 40.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 2.2% | 32.6ms | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 2.0% | 29.0ms | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 1.8% | 25.9ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 1.7% | 24.8ms | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 1.4% | 20.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 1.4% | 20.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` |
| 1.3% | 18.6ms | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 1.1% | 17.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 1.1% | 15.6ms | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 1.0% | 14.9ms | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 1.0% | 14.8ms | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.9% | 13.3ms | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.9% | 12.9ms | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.8% | 12.5ms | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.7% | 11.4ms | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.7% | 10.7ms | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.7% | 10.7ms | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` |
| 0.7% | 10.4ms | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.5% | 8.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.5% | 7.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.5% | 7.5ms | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.4% | 6.8ms | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.4% | 6.8ms | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.4% | 5.9ms | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts` |
| 0.3% | 5.2ms | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.3% | 5.2ms | `/tmp/pr449-main-integration-20261029-762/src/agent/families-source-hooks.ts` |
| 0.3% | 5.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.3% | 5.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.3% | 4.8ms | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.3% | 4.8ms | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.3% | 4.8ms | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts` |
| 0.3% | 4.8ms | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.2% | 4.1ms | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts` |
| 0.2% | 4.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.2% | 3.7ms | `node:crypto` |
| 0.2% | 3.4ms | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` |
| 0.2% | 3.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/builtin-family-detection.ts` |
| 0.2% | 3.3ms | `/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts` |
| 0.2% | 3.3ms | `/tmp/pr449-main-integration-20261029-762/src/index.ts` |
| 0.2% | 2.9ms | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` |
| 0.2% | 2.8ms | `/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts` |
| 0.1% | 2.6ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js` |
| 0.1% | 2.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts` |
| 0.1% | 2.6ms | `internal:streams/duplex` |
| 0.1% | 2.5ms | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts` |
| 0.1% | 2.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.1% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts` |
| 0.1% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.1% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/drawing.ts` |
| 0.1% | 2.2ms | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.1% | 2.1ms | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.1% | 1.7ms | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.1% | 1.6ms | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/geometry.ts` |
| 0.1% | 1.6ms | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts` |
| 0.1% | 1.6ms | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts` |
| 0.1% | 1.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts` |
| 0.1% | 1.4ms | `internal:streams/readable` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/c4/config.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts` |
| 0.0% | 1.3ms | `internal:primordials` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/external-data-snapshot.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/class/annotation-seats.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/requirement/tokens.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/shared/config-spacing.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/ascii/pathfinder.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/agent/types.ts` |
| 0.0% | 983us | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.0% | 981us | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts` |
