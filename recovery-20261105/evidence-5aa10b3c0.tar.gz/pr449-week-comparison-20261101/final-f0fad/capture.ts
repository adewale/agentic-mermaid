import fs from 'node:fs'
import {gzipSync}from'node:zlib'
import{renderMermaidSVGWithReceipt}from'/tmp/pr449-main-integration-20261029-762/src/index.ts'
const root='/tmp/pr449-main-integration-20261029-762',dir='/tmp/pr449-week-comparison-20261101/final-f0fad'
const classSource='classDiagram\ndirection TB\nclass A\nclass B\nclass Sink\nA --> Sink : input\nB --> Sink\nSink --> Sink : retry'
const requirement=fs.readFileSync(root+'/eval/layout-compare/fixtures/requirement-backends.mmd','utf8'),rows=[]
for(const family of ['class','requirement'])for(const direction of family==='class'?['TB']:['TB','BT','LR','RL'])for(const backend of ['agentic','elk'] as const){
 const source=family==='class'?classSource:requirement.replace('direction TB',`direction ${direction}`)
 const options={graphLayout:{backend,fallback:'none' as const},embedFontImport:false,...(family==='requirement'?{idPrefix:'recovery-'}:{})}
 const stem=`${dir}/${family}-${direction}-${backend}`
 try{
  const value=renderMermaidSVGWithReceipt(source,options)
  fs.writeFileSync(stem+'.svg.gz',gzipSync(value.svg));fs.writeFileSync(stem+'.receipt.json.gz',gzipSync(JSON.stringify(value.receipt)))
  fs.writeFileSync(stem+'.result.json.gz',gzipSync(JSON.stringify({source,options,value})))
  if(direction==='TB')rows.push({family,backend,source,options,svgReference:stem+'.svg.gz',receiptReference:stem+'.receipt.json.gz'})
  console.log(JSON.stringify({family,direction,backend,status:'returned',viewBox:value.svg.match(/viewBox="([^"]+)"/)?.[1],proof:value.receipt.layoutCertification?.status}))
 }catch(e:any){fs.writeFileSync(stem+'.error.json',JSON.stringify({source,options,name:e.name,message:e.message}));console.log(JSON.stringify({family,direction,backend,status:'failed',name:e.name,message:e.message}))}
}
fs.writeFileSync(dir+'/bindings.json',JSON.stringify(rows,null,2))
