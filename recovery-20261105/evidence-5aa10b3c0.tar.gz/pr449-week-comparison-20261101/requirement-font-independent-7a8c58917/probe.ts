import assert from 'node:assert/strict'
import {writeFileSync} from 'node:fs'
import {createMermaidRenderer} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import {createRequire} from 'node:module'
const {JSDOM}=createRequire('/tmp/pr449-main-integration-20261029-762/package.json')('jsdom')
const seen=[]
const renderer=createMermaidRenderer({textMeasurement:{id:'test:requirement-selected-font',version:'1.0.0',measure(input){seen.push(input);return [...input.text].length*(input.fontFamily==='Contract Sans'?10:2)}}})
const source='requirementDiagram\ndirection LR\nrequirement source {\ntext: Sender\n}\nrequirement target {\ntext: Receiver\n}\nsource - traces -> target'
const rendered=renderer.renderMermaidSVGWithReceipt(source,{font:'Contract Sans',embedFontImport:false,graphLayout:{backend:'agentic',fallback:'none'}})
writeFileSync(import.meta.dir+'/result.svg',rendered.svg)
writeFileSync(import.meta.dir+'/receipt.json',JSON.stringify(rendered.receipt,null,2))
const dom=new JSDOM(rendered.svg,{contentType:'image/svg+xml'})
try {
const doc=dom.window.document,caption=doc.querySelector('.requirement-edge-label'),text=caption.querySelector('text'),pill=caption.querySelector('rect'),carrier=doc.querySelector('[data-role="relationship"][data-from="source"]')
const result={measurements:seen,caption:text.outerHTML,pill:pill.outerHTML,carrier:carrier.outerHTML,fontDeclaration:rendered.svg.match(/font-family[^;\n<]*/g),cards:[...doc.querySelectorAll('g.requirement-node')].map(card=>({id:card.getAttribute('data-id'),rect:card.querySelector('rect').outerHTML})),layoutCertification:rendered.receipt.layoutCertification}
console.log(JSON.stringify(result,null,2))
assert.equal(text.textContent,'<<traces>>')
assert.equal(text.getAttribute('textLength'),'100')
assert.equal(pill.getAttribute('width'),'112')
assert.equal(carrier.getAttribute('data-to'),'target')
const points=carrier.getAttribute('points').split(/\s+/).map(pair=>pair.split(',').map(Number)),x=Number(text.getAttribute('x')),y=Number(text.getAttribute('y'))
assert(points.some((b,i)=>{const a=points[i-1];return a&&(a[0]===b[0]&&Math.abs(x-a[0])<1e-6&&y>=Math.min(a[1],b[1])&&y<=Math.max(a[1],b[1])||a[1]===b[1]&&Math.abs(y-a[1])<1e-6&&x>=Math.min(a[0],b[0])&&x<=Math.max(a[0],b[0]))}))
console.log('hypothesis-falsified: selected-font caption100px; owned caption on carrier')
} finally {dom.window.close()}
