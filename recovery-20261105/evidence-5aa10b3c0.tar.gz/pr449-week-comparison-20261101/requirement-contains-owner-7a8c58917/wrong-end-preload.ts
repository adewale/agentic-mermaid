import {readFileSync} from 'node:fs'
const preload='/tmp/pr449-week-comparison-20261101/requirement-contains-owner-7a8c58917/wrong-end-preload.ts'
Bun.plugin({name:'contains-wrong-end-control',setup(build){
build.onLoad({filter:/\/src\/requirement\/renderer\.ts$/},args=>({contents:readFileSync(args.path,'utf8').replace("markers: edge.type === 'contains' ? { start: contains }", "markers: edge.type === 'contains' ? { end: contains }"),loader:'ts'}))
build.onLoad({filter:/\/src\/__tests__\/requirement-layout-backends\.test\.ts$/},args=>({contents:readFileSync(args.path,'utf8').replaceAll("['-e',", "['--preload', '"+preload+"', '-e',"),loader:'ts'}))
}})
