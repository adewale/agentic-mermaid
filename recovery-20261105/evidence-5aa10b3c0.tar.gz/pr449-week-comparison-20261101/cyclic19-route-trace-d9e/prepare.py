from pathlib import Path
p=Path('/tmp/pr449-week-comparison-20261101/cyclic19-route-trace-d9e')
s=(p/'route-contracts.original.ts').read_text()
def swap(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a))
 s=s.replace(a,b,1)
helper='''// NONSHIPPING observations only. No route/certificate/admission writes.
export const cyclic19SeatTrace: unknown[] = []
function recordCyclic19Seat(stage: string, edge: PositionedEdge, source?: PositionedNode, target?: PositionedNode): void {
  if (edge.edgeIndex !== 2 && edge.edgeIndex !== 13 && edge.edgeIndex !== 15 && edge.edgeIndex !== 20 && edge.edgeIndex !== 38) return
  const node = (value?: PositionedNode) => value ? { id: value.id, shape: value.shape, semanticShape: value.semanticShape, x: value.x, y: value.y, width: value.width, height: value.height } : undefined
  cyclic19SeatTrace.push({ stage, edgeIndex: edge.edgeIndex, source: edge.source, target: edge.target,
    points: edge.points.map(point => ({ x: point.x, y: point.y })), sourceNode: node(source), targetNode: node(target) })
}

'''
swap('type DraftRouteCertificate =',helper+'type DraftRouteCertificate =')
swap('  let unlabelledContainerRepair: boolean | undefined','''  let unlabelledContainerRepair: boolean | undefined
  const traceSeat = (stage: string, edge: PositionedEdge): void => recordCyclic19Seat(stage, edge, nodeMap.get(edge.source), nodeMap.get(edge.target))
  for (const edge of positioned.edges) traceSeat('applyRouteContracts:incoming', edge)''')
swap("  const attemptStraighten = (edge: PositionedEdge, cert: DraftRouteCertificate): { applied: boolean; mutated: boolean; upgradeable?: boolean } => {", """  const attemptStraighten = (edge: PositionedEdge, cert: DraftRouteCertificate): { applied: boolean; mutated: boolean; upgradeable?: boolean } => {
    traceSeat('attemptStraighten:before', edge)
    try {""")
swap('    return { applied: false, mutated }\n  }\n\n  /** Another terminal',"""    return { applied: false, mutated }
    } finally { traceSeat('attemptStraighten:after', edge) }
  }

  /** Another terminal""")
swap('  function tryCrossSideEntry(edge: PositionedEdge, target: PositionedNode, ctx: LaneContext, axis: Axis): boolean {',"""  function tryCrossSideEntry(edge: PositionedEdge, target: PositionedNode, ctx: LaneContext, axis: Axis): boolean {
    traceSeat('tryCrossSideEntry:before', edge)
    try {""")
swap('    setRoutePoints(ctx, edge, route)\n    return true\n  }\n\n  /**\n   * Try to replace a blocked edge',"""    setRoutePoints(ctx, edge, route)
    return true
    } finally { traceSeat('tryCrossSideEntry:after', edge) }
  }

  /**
   * Try to replace a blocked edge""")
swap('    forcedLanes?: { sourceLane?: number; targetLane?: number; preferSourceJog?: boolean; requireFewerCrossings?: boolean },\n  ): boolean {',"""    forcedLanes?: { sourceLane?: number; targetLane?: number; preferSourceJog?: boolean; requireFewerCrossings?: boolean },
  ): boolean {
    traceSeat('tryZRoute:before', edge)
    try {""")
swap('    return false\n  }\n\n  /**\n   * Last-resort occlusion repair',"""    return false
    } finally { traceSeat('tryZRoute:after', edge) }
  }

  /**
   * Last-resort occlusion repair""")
swap('  return certificates\n}',"  for (const edge of positioned.edges) traceSeat('applyRouteContracts:final', edge)\n  return certificates\n}")
swap('  collapseTinyEndpointSegments(positioned.nodes, positioned.edges, style)\n  return positioned.edges.flatMap',"""  collapseTinyEndpointSegments(positioned.nodes, positioned.edges, style)
  for (const edge of positioned.edges) recordCyclic19Seat('closeRouteContracts:final', edge, positioned.nodes.find(node => node.id === edge.source), positioned.nodes.find(node => node.id === edge.target))
  return positioned.edges.flatMap""")
(p/'route-contracts.trace.ts').write_text(s)
