// Adapted from retained native-group-cyclic19-corrected-b063/probe.ts.
// HOLD: one public SVG call only after parent commit + explicit ROOT GO.
import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import assert from 'node:assert/strict'
const root = '/tmp/pr449-main-integration-20261029-762'
const out = '/tmp/pr449-week-comparison-20261101/cyclic19-route-trace-d9e'
if (process.env.AM_CYCLIC19_TRACE_ROOT_GO !== '1') throw new Error('HOLD: explicit ROOT GO required')
const original = readFileSync(out + '/route-contracts.original.ts')
assert.deepEqual(readFileSync(root + '/src/route-contracts.ts'), original)
let loaded = 0, calls = 0
Bun.plugin({ name: 'nonshipping-cyclic19-route-observation', setup(build) {
  build.onLoad({ filter: /\/src\/route-contracts\.ts$/ }, args => {
    assert.deepEqual(readFileSync(args.path), original)
    loaded++
    return { contents: readFileSync(out + '/route-contracts.trace.ts', 'utf8'), loader: 'ts' }
  })
}})
try {
  const baseline = JSON.parse(gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/cyclic15-19-b063/current-cyclic-labelled-19.mmd-agentic.json.gz')).toString())
  const source = readFileSync(root + '/eval/layout-compare/fixtures/cyclic-labelled-19.mmd', 'utf8')
  assert.equal(source, baseline.source)
  const options = { graphLayout: { backend: 'agentic' as const, fallback: 'none' as const }, embedFontImport: false, idPrefix: 'cycle-check-' }
  const { renderMermaidSVGWithReceipt } = await import(root + '/src/index.ts')
  assert.equal(loaded, 1)
  calls++
  const result = renderMermaidSVGWithReceipt(source, options)
  // All analysis/serialization is outside the public call; this is not timing evidence.
  const { cyclic19SeatTrace } = await import(root + '/src/route-contracts.ts') as any
  const { isOutwardShapeApproach } = await import(root + '/src/shape-clipping.ts')
  const observations = cyclic19SeatTrace.map((row: any) => {
    const p = row.points, first = p[0], second = p[1], last = p.at(-1), previous = p.at(-2)
    return { ...row, sourceOutward: row.sourceNode && first && second ? isOutwardShapeApproach(row.sourceNode, first, second) : null,
      targetOutward: row.targetNode && last && previous ? isOutwardShapeApproach(row.targetNode, last, previous) : null }
  })
  const serialized = JSON.stringify(result)
  let sum = 0
  for (let i = 0; i < serialized.length; i++) sum += serialized.charCodeAt(i)
  const record = { scope: 'NONSHIPPING route observations only; no geometry behavior edits or timing claim', source, options,
    publicSVGCalls: calls, publicLayoutCalls: 0, loaded, result, observations,
    byteExactSVG: result.svg === baseline.svg, consumed: { utf16Units: serialized.length, utf8Bytes: Buffer.byteLength(serialized), sum },
    retainedBaseline: '/tmp/pr449-week-comparison-20261101/cyclic15-19-b063/current-cyclic-labelled-19.mmd-agentic.json.gz' }
  writeFileSync(out + '/result.json.gz', gzipSync(JSON.stringify(record)))
  writeFileSync(out + '/raw-receipt.json.gz', gzipSync(JSON.stringify(result.receipt)))
  writeFileSync(out + '/actual.svg.gz', gzipSync(result.svg))
  writeFileSync(out + '/observations.json', JSON.stringify(observations, null, 2))
  const summary = { scope: record.scope, publicSVGCalls: calls, publicLayoutCalls: 0, loaded,
    proof: result.receipt.layoutCertification, byteExactSVG: record.byteExactSVG, consumed: record.consumed, observations: observations.length }
  writeFileSync(out + '/SUMMARY.json', JSON.stringify(summary, null, 2))
  console.log(JSON.stringify(summary))
  assert.equal(result.svg, baseline.svg, 'whole SVG bytes match retained current snapshot')
} catch (error) {
  const failure = { publicSVGCalls: calls, publicLayoutCalls: 0, loaded, error: { name: (error as Error).name, message: (error as Error).message, stack: (error as Error).stack } }
  writeFileSync(out + '/FAILURE.json', JSON.stringify(failure, null, 2))
  console.log(JSON.stringify(failure)); process.exitCode = 1
}
