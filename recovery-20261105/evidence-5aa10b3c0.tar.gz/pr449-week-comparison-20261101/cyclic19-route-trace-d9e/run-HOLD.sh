#!/bin/bash
set -euo pipefail
: "${AM_CYCLIC19_TRACE_ROOT_GO:?HOLD: root must explicitly authorize execution after commit}"
cd /tmp/pr449-main-integration-20261029-762
PATH=/tmp/pr449-bin:$PATH AGENTIC_MERMAID_ELK_CACHE=0 bun /tmp/pr449-week-comparison-20261101/cyclic19-route-trace-d9e/probe.ts > /tmp/pr449-week-comparison-20261101/cyclic19-route-trace-d9e/run.log 2>&1
