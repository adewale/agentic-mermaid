import fs from 'node:fs'
import assert from 'node:assert/strict'
import {gunzipSync,gzipSync} from 'node:zlib'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
const dir='/tmp/pr449-week-comparison-20261101/native-font-lexer-9f519'
const base='/tmp/pr449-main-integration-20261029-762/assets/fonts/'
const font={fontFiles:[base+'Inter-Regular.ttf',base+'ShareTechMono.ttf'],loadSystemFonts:false,defaultFontFamily:'Inter',sansSerifFamily:'Inter',monospaceFamily:'Share Tech Mono'}
const read=(name:string)=>gunzipSync(fs.readFileSync(`${dir}/${name}.svg.gz`)).toString()
const safe=read('safe'),mono=read('mono'),hooked=read('hook-nativeGroup-mono')
assert.equal(mono,hooked)
const pixels:Record<string,Buffer>={}
const results:any[]=[]
for(const [mode,svg] of Object.entries({safe,mono,hooked})){
  const text=svg.match(/<text\b[^>]*>Wiii<\/text>/g)
  assert.equal(text?.length,1)
  const full=new Resvg(svg,{font,background:'#fff'}).render()
  const absent=new Resvg(svg.replace(text![0],''),{font,background:'#fff'}).render()
  const p=full.pixels,q=absent.pixels
  assert.equal(full.width,200);assert.equal(full.height,120)
  let changed=0,x0=Infinity,x1=-Infinity,y0=Infinity,y1=-Infinity
  for(let i=0;i<p.length;i+=4)if(p[i]!==q[i]||p[i+1]!==q[i+1]||p[i+2]!==q[i+2]||p[i+3]!==q[i+3]){
    changed++;const x=(i/4)%200,y=Math.floor(i/4/200);x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y)
  }
  assert.ok(changed>0)
  pixels[mode]=p
  fs.writeFileSync(`${dir}/${mode}.png.gz`,gzipSync(full.asPng()))
  fs.writeFileSync(`${dir}/${mode}-without-text.png.gz`,gzipSync(absent.asPng()))
  results.push({mode,text,changedTextPixels:changed,changedTextBounds:{x0,y0,x1,y1}})
}
let safeMonoChanged=0,monoHookChanged=0
for(let i=0;i<pixels.safe!.length;i+=4){
  if(pixels.safe![i]!==pixels.mono![i]||pixels.safe![i+1]!==pixels.mono![i+1]||pixels.safe![i+2]!==pixels.mono![i+2]||pixels.safe![i+3]!==pixels.mono![i+3])safeMonoChanged++
  if(pixels.mono![i]!==pixels.hooked![i]||pixels.mono![i+1]!==pixels.hooked![i+1]||pixels.mono![i+2]!==pixels.hooked![i+2]||pixels.mono![i+3]!==pixels.hooked![i+3])monoHookChanged++
}
assert.ok(safeMonoChanged>0);assert.equal(monoHookChanged,0)
const result={font,literalMonoEqualsHookedSvg:true,svgBytes:Buffer.byteLength(mono),safeMonoChangedPixels:safeMonoChanged,monoHookChangedPixels:monoHookChanged,results,limits:'One literal small drawing with bundled Inter and Share Tech Mono; font-scope authority witness, not universal glyph-ink or occlusion completeness.'}
fs.writeFileSync(`${dir}/INK.json`,JSON.stringify(result,null,2));console.log(JSON.stringify(result))
