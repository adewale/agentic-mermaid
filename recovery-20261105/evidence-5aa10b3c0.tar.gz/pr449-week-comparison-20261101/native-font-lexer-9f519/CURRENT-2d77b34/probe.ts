import fs from 'node:fs'
import {gzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
import {drawNative} from '/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts'
import {certifyNativePaint} from '/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts'
import {preparePixelText,hasPreparedInterTextEnvelope} from '/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts'
import {withTextMeasurementExecution} from '/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts'
import {tipAnchoredArrow,serializeMarkerResource} from '/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts'
import {svgOpenTag,buildStyleBlock} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import type {DrawingProducer} from '/tmp/pr449-main-integration-20261029-762/src/scene/drawing.ts'
const dir='/tmp/pr449-week-comparison-20261101/native-font-lexer-9f519/CURRENT-2d77b34'
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:'/tmp/pr449-main-integration-20261029-762',encoding:'utf8'}).trim()
const runtimeDiff=execFileSync('git',['diff'],{cwd:'/tmp/pr449-main-integration-20261029-762',encoding:'utf8'})
fs.writeFileSync(`${dir}/runtime.patch`,runtimeDiff)
const results:any[]=[]
const original=Object.getOwnPropertyDescriptor(String.prototype,'slice')!
const slice=original.value
for(const mode of ['safe','mono','hook-nativeGroup-mono']){
  const colors={bg:'#fff',fg:'#111',font:'Inter'},width=200,height=120
  const context={positioned:{width,height},colors,resolved:{renderOptions:{}}}
  const block=withTextMeasurementExecution(undefined,()=>preparePixelText('Wiii',{fontSize:20,fontWeight:400}), 'Inter')
  const marker=tipAnchoredArrow('font-custody-arrow',{width:8,height:5},'end',{fill:'#000'},'userSpaceOnUse')
  let calls=0;const changes:any[]=[]
  const producer:DrawingProducer=factory=>({family:'flowchart',width,height,colors,transparent:false,parts:[
    factory.documentOpen({id:'root',width,height,colors,transparent:false,font:'Inter',hasMonoFont:true},svgOpenTag(width,height,colors)+'\n'+buildStyleBlock('Inter',true,false,false)),
    factory.definitions({id:'markers'},`<defs>${serializeMarkerResource(marker)}</defs>`),
    factory.connector({id:'edge',role:'edge',lineStyle:'solid',geometry:{kind:'line',x1:20,y1:40,x2:50,y2:40},paint:{stroke:'#000'},endpoints:{from:'outside',to:'cover'},markers:{end:marker}}),
    factory.shape({id:'cover',role:'node',geometry:{kind:'rect',x:90,y:10,width:35,height:45},paint:{fill:'#fff'}}),
    factory.group({id:'font-group',role:'chrome',open:`<g class="${mode==='safe'?'safe':'mono'}">`,close:'</g>',children:[{node:factory.text({id:'font-text',role:'label',text:block.text,block,x:20,y:90,fontSize:20,anchor:'start',paint:{fill:'#111'}}),indent:2}]}),
    factory.documentClose(),
  ]})
  const row:any={mode,head,preparedInter:hasPreparedInterTextEnvelope(block),ownFontFamily:Object.hasOwn(block,'fontFamily')}
  try{
    if(mode==='hook-nativeGroup-mono')Object.defineProperty(String.prototype,'slice',{...original,value:function(this:string,start?:number,end?:number){
      const actual=Reflect.apply(slice,this,[start,end])
      if(actual==='mono'&&String(this).startsWith('<g ')){
        const stack=new Error().stack??''
        if(stack.includes('nativeGroup')){calls++;changes.push({source:String(this),start,end,actual,substituted:'safe',stack});return 'safe'}
      }
      return actual
    }})
    const drawing=drawNative(producer,context,'flowchart')
    const proof=certifyNativePaint(drawing.header,drawing.paint)
    fs.writeFileSync(`${dir}/${mode}.svg.gz`,gzipSync(drawing.svg))
    fs.writeFileSync(`${dir}/${mode}.proof.json`,JSON.stringify(proof,null,2))
    row.proof=proof;row.svg=drawing.svg;row.outcome='returned'
  }catch(e:any){row.outcome='error';row.error={name:e.name,message:e.message,stack:e.stack}}
  finally{Object.defineProperty(String.prototype,'slice',original)}
  row.hookCalls=calls;row.hookChanges=changes
  results.push(row)
  fs.writeFileSync(`${dir}/RESULTS.json`,JSON.stringify({head,runtimeDiff,results},null,2))
  console.log(JSON.stringify({mode,outcome:row.outcome,status:row.proof?.status,issues:row.proof?.issues,hookCalls:calls,preparedInter:row.preparedInter,ownFontFamily:row.ownFontFamily,error:row.error}))
}
