import fs from 'node:fs'
import {gunzipSync} from 'node:zlib'
import assert from 'node:assert/strict'
import {createRequire} from 'node:module'
const sharp=createRequire('/tmp/pr449-main-integration-20261029-762/package.json')('sharp')
const dir='/tmp/pr449-week-comparison-20261101/native-font-lexer-9f519'
const images:Record<string,Buffer>={},results:any[]=[]
for(const mode of ['safe','mono','hooked']){
  const full=await sharp(gunzipSync(fs.readFileSync(`${dir}/${mode}.png.gz`))).raw().toBuffer({resolveWithObject:true})
  const absent=await sharp(gunzipSync(fs.readFileSync(`${dir}/${mode}-without-text.png.gz`))).raw().toBuffer({resolveWithObject:true})
  assert.equal(full.info.width,200);assert.equal(full.info.height,120);assert.equal(full.info.channels,4)
  const p=full.data,q=absent.data
  let changed=0,x0=Infinity,x1=-Infinity,y0=Infinity,y1=-Infinity
  for(let i=0;i<p.length;i+=4)if(p[i]!==q[i]||p[i+1]!==q[i+1]||p[i+2]!==q[i+2]||p[i+3]!==q[i+3]){
    changed++;const x=i/4%200,y=Math.floor(i/4/200);x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y)
  }
  assert.ok(changed>0)
  results.push({mode,changedTextPixels:changed,changedTextBounds:{x0,y0,x1,y1}});images[mode]=p
}
let safeMonoChangedPixels=0,monoHookChangedPixels=0
for(let i=0;i<images.safe!.length;i+=4){
  if(images.safe![i]!==images.mono![i]||images.safe![i+1]!==images.mono![i+1]||images.safe![i+2]!==images.mono![i+2]||images.safe![i+3]!==images.mono![i+3])safeMonoChangedPixels++
  if(images.mono![i]!==images.hooked![i]||images.mono![i+1]!==images.hooked![i+1]||images.mono![i+2]!==images.hooked![i+2]||images.mono![i+3]!==images.hooked![i+3])monoHookChangedPixels++
}
assert.equal(monoHookChangedPixels,0)
const fonts=['Inter-Regular.ttf','ShareTechMono.ttf'].map(name=>({name,path:'/tmp/pr449-main-integration-20261029-762/assets/fonts/'+name,bytes:fs.statSync('/tmp/pr449-main-integration-20261029-762/assets/fonts/'+name).size}))
const result={source:'Existing initial raster files; decoded only, no new render or changed SVG',fonts,fontOptions:{loadSystemFonts:false,defaultFontFamily:'Inter',sansSerifFamily:'Inter',monospaceFamily:'Share Tech Mono'},safeMonoChangedPixels,monoHookChangedPixels,results,limits:'No font substitution or glyph loss observed. Generic monospace resolved to the same pixels in this Resvg configuration. The retained proof discrepancy concerns actual font-scope truth, separately from font-specific ink.'}
fs.writeFileSync(`${dir}/INK-LIMIT.json`,JSON.stringify(result,null,2));console.log(JSON.stringify(result))
fs.renameSync(`${dir}/owner-red.log`,`${dir}/owner-early-green.log`)
