// Lexical-only design experiment. No render imports or public SVG calls.
import assert from 'node:assert/strict'
import { writeFileSync } from 'node:fs'
import { scanSvgStartTagsFresh, visitSvgFirstTagAttributes, decodedSvgAttributeValue, type SvgStartTagToken } from '/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts'
const out='/tmp/pr449-week-comparison-20261101/native-group-cyclic19-corrected-b063'
const raw='<g class="mono">'
const intrinsicSlice=String.prototype.slice
let altered=0
const constructorValues: Array<[string,string]>=[]
let fact: readonly SvgStartTagToken[]
try {
 String.prototype.slice=function(start?:number,end?:number) {
  const actual=intrinsicSlice.call(this,start,end)
  if(String(this)===raw && actual==='mono' && altered===0) {altered++;return 'safe'}
  return actual
 }
 visitSvgFirstTagAttributes(raw,'g',(name,value)=>constructorValues.push([name,value]))
 fact=scanSvgStartTagsFresh(raw)
 assert.equal(constructorValues[0]?.[1],'safe')
 assert.equal(fact[0]?.attributes[0]?.value,'mono')
 assert.equal(scanSvgStartTagsFresh(raw)[0]?.attributes[0]?.value,'mono')
} finally {String.prototype.slice=intrinsicSlice}
// Stand-in for a private primitive-slot plan. Every consumer allocates ordinary
// token and attribute-array receivers; it never receives the plan's records.
function materialize(source: readonly SvgStartTagToken[]): readonly SvgStartTagToken[] {
 const tags: SvgStartTagToken[]=[]
 for(let i=0;i<source.length;i++) {
  const input=source[i]!,attributes: Array<any>=[]
  for(let j=0;j<input.attributes.length;j++) {
   const item=input.attributes[j]!
   const value=Object.freeze({name:item.name,value:item.value,quote:item.quote,nameStart:item.nameStart,valueStart:item.valueStart,valueEnd:item.valueEnd})
   Object.defineProperty(attributes,j,{value,enumerable:true,writable:true,configurable:true})
  }
  const value=Object.freeze({name:input.name,start:input.start,end:input.end,attributes:Object.freeze(attributes),selfClosing:input.selfClosing})
  Object.defineProperty(tags,i,{value,enumerable:true,writable:true,configurable:true})
 }
 return Object.freeze(tags)
}
const first=materialize(fact!),second=materialize(fact!)
assert.deepEqual(first,second)
assert.notEqual(first,second)
assert.notEqual(first[0],second[0])
assert.notEqual(first[0]!.attributes,second[0]!.attributes)
assert.notEqual(first[0]!.attributes[0],second[0]!.attributes[0])
const findDescriptor=Object.getOwnPropertyDescriptor(Array.prototype,'find')!
const ordinaryFind=Array.prototype.find
const visits=new WeakMap<object,number>()
let freshValues: Array<string|undefined>,sharedValues: Array<string|undefined>
try {
 Object.defineProperty(Array.prototype,'find',{configurable:true,get() {
  const receiver=this,n=(visits.get(receiver)??0)+1
  visits.set(receiver,n)
  return function(predicate:any) {
   const found=Reflect.apply(ordinaryFind,receiver,[predicate])
   return found && found.name==='class' ? {...found,value:n===1?'safe':'mono'}:found
  }
 }})
 freshValues=[decodedSvgAttributeValue(first[0]!,'class'),decodedSvgAttributeValue(second[0]!,'class')]
 const shared=materialize(fact!)
 sharedValues=[decodedSvgAttributeValue(shared[0]!,'class'),decodedSvgAttributeValue(shared[0]!,'class')]
 assert.deepEqual(freshValues,['safe','safe'])
 assert.deepEqual(sharedValues,['safe','mono'])
} finally {Object.defineProperty(Array.prototype,'find',findDescriptor)}
const result={publicSVGCalls:0,scope:'Lexical-only necessary-condition experiment; standalone materializer is not shipping custody, accounting or full implementation evidence.',raw,retainedSliceCounterexample:{altered,constructorValues,primitiveProducerValue:fact![0]!.attributes[0]!.value,freshLaterValue:scanSvgStartTagsFresh(raw)[0]!.attributes[0]!.value},receiverCounterexample:{freshValues:freshValues!,sharedValues:sharedValues!,allTokenAndArrayReceiversDistinct:true},checks:'passed'}
writeFileSync(out+'/LEXICAL-DESIGN-CHECK.json',JSON.stringify(result,null,2))
console.log(JSON.stringify(result))
