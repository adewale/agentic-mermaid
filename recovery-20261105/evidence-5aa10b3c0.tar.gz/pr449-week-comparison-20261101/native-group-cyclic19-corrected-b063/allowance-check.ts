import assert from 'node:assert/strict'
import { writeFileSync } from 'node:fs'
import { captureNativeGroupParse, assertInertGroup } from '/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts'
const fields={id:'g',open:'<g class="safe" data-id="x" data-role="node">',close:'</g>',join:'\n'}
let unavailable=0,available=0
for(let allowance=0;allowance<250;allowance++){
 let paid=0,exhausted=false
 const pay=(n:number)=>{if(exhausted||n>allowance-paid){exhausted=true;return false}paid+=n;return true}
 const fact=captureNativeGroupParse(fields,pay)
 if(fact) {available++;fact.materialize(pay)} else unavailable++
 assert.ok(paid<=allowance)
}
for(const open of ['<g-foo class="safe">','<g:foo class="safe">'])assert.throws(()=>captureNativeGroupParse({...fields,open},()=>true))
assert.throws(()=>captureNativeGroupParse({...fields,open:'<g class="safe" class="mono">'},()=>true))
const rows={publicSVGCalls:0,allowances:250,unavailable,available,validDeliveryNeverThrows:true,wrongTagAndDuplicateRejected:true}
writeFileSync('/tmp/pr449-week-comparison-20261101/native-group-cyclic19-corrected-b063/ALLOWANCE-CHECK.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows))
