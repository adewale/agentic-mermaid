import fs from 'node:fs'
Bun.plugin({name:'baseline843-shorten',setup(build){build.onLoad({filter:/\/src\/layout\/shorten-measured-routes\.ts$/},()=>({contents:fs.readFileSync('/tmp/pr449-week-comparison-20261101/requirement-caption-843/shorten-before.ts','utf8'),loader:'ts'}))}})
