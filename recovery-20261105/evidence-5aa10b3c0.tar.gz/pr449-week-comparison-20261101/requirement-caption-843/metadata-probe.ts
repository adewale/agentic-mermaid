import {readFileSync,writeFileSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const root='/tmp/pr449-main-integration-20261029-762',dir='/tmp/pr449-week-comparison-20261101/requirement-caption-843'
const source=readFileSync(root+'/eval/layout-compare/fixtures/requirement-backends.mmd','utf8'), options={graphLayout:{backend:'agentic' as const,fallback:'none' as const},embedFontImport:false,idPrefix:'recovery-'}
let result
try{result={source,options,status:'returned',...renderMermaidSVGWithReceipt(source,options)}}catch(error){result={source,options,status:'refused',error:{name:error.name,message:error.message,stack:error.stack,code:error.code}}}
const raw=JSON.stringify(result);writeFileSync(dir+'/metadata-only-TB-agentic.json.gz',gzipSync(raw))
console.log(JSON.stringify({publicSvgCalls:1,fullyConsumedBytes:Buffer.byteLength(raw),status:result.status,error:result.error,proof:result.receipt?.layoutCertification,viewport:result.svg?.match(/<svg[^>]*>/)?.[0]}))
