import { writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import { renderMermaidSVGWithReceipt } from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import { withRenderStageObserver } from '/tmp/pr449-main-integration-20261029-762/src/render-stages.ts'
const rows = [], outputs = []
for (const direction of ['TB', 'BT', 'LR', 'RL']) {
  const source = `classDiagram\ndirection ${direction}\n` + Array.from({ length: 127 }, (_, i) => `N${i} --> N${i + 1}`).join('\n')
  for (const phase of ['first', 'repeat']) {
    const stages = [], start = performance.now()
    try {
      const result = withRenderStageObserver(stage => stages.push(stage), () => renderMermaidSVGWithReceipt(source, {graphLayout: {backend: 'agentic', fallback: 'none'}, embedFontImport: false}))
      const bytes = Buffer.from(JSON.stringify(result)); let checksum = 0
      for (let i=0; i<bytes.length; i++) checksum = (Math.imul(checksum,31)+bytes[i])>>>0
      rows.push({direction,phase,ms:performance.now()-start,bytes:bytes.length,checksum,proof:result.receipt.layoutCertification,stages})
      outputs.push(result)
    } catch(error) {rows.push({direction,phase,ms:performance.now()-start,error:{name:error.name,message:error.message},stages})}
  }
}
writeFileSync('/tmp/pr449-week-comparison-20261101/class128-profile/outputs.json.gz',gzipSync(JSON.stringify(outputs)))
writeFileSync('/tmp/pr449-week-comparison-20261101/class128-profile/rows.json',JSON.stringify({rows,rss:process.resourceUsage().maxRSS,heap:process.memoryUsage()},null,2))
console.log('Consumed calls:',rows.length)
