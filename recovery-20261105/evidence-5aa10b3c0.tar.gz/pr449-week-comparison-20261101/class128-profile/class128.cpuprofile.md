# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 4.35s | 2065 | 1.0ms | 1698 |

**Top 10:** `bound require` 6.2%, `xmlSlice` 4.2%, `getOwnPropertyDescriptor` 3.5%, `copyInner` 3.0%, `_toPrimitive` 3.0%, `copyDataProperties` 1.9%, `fromEntries` 1.7%, `anonymous` 1.6%, `xmlAsciiLetter` 1.5%, `decodeBase64` 1.4%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 6.2% | 270.4ms | 10.0% | 436.1ms | `bound require` | `[native code]` |
| 4.2% | 184.3ms | 4.2% | 184.3ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:106` |
| 3.5% | 155.5ms | 3.5% | 155.5ms | `getOwnPropertyDescriptor` | `[native code]` |
| 3.0% | 131.2ms | 3.1% | 136.5ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:169` |
| 3.0% | 130.5ms | 3.0% | 130.5ms | `_toPrimitive` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:13` |
| 1.9% | 83.7ms | 1.9% | 83.7ms | `copyDataProperties` | `[native code]` |
| 1.7% | 74.7ms | 1.7% | 74.7ms | `fromEntries` | `[native code]` |
| 1.6% | 71.6ms | 6.2% | 273.1ms | `anonymous` | `[native code]` |
| 1.5% | 66.8ms | 1.5% | 66.8ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:90` |
| 1.4% | 62.4ms | 1.4% | 62.4ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:23` |
| 1.1% | 48.6ms | 1.1% | 48.6ms | `freeze` | `[native code]` |
| 1.0% | 47.7ms | 1.4% | 63.3ms | `stringify` | `[native code]` |
| 1.0% | 44.8ms | 1.0% | 46.3ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` |
| 0.9% | 43.1ms | 0.9% | 43.1ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` |
| 0.9% | 42.5ms | 0.9% | 42.5ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:113` |
| 0.9% | 42.2ms | 1.0% | 45.5ms | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:13` |
| 0.7% | 32.2ms | 0.7% | 33.2ms | `match` | `[native code]` |
| 0.6% | 30.0ms | 0.6% | 30.0ms | `cloneObject` | `[native code]` |
| 0.6% | 29.6ms | 4.3% | 189.4ms | `map` | `[native code]` |
| 0.6% | 27.7ms | 0.6% | 27.7ms | `has` | `[native code]` |
| 0.5% | 25.5ms | 0.5% | 25.5ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:115` |
| 0.5% | 24.8ms | 1.1% | 50.8ms | `some` | `[native code]` |
| 0.5% | 22.3ms | 0.5% | 22.3ms | `hasOwn` | `[native code]` |
| 0.4% | 20.2ms | 0.4% | 20.2ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:105` |
| 0.4% | 19.4ms | 0.8% | 38.1ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:435` |
| 0.4% | 19.2ms | 0.4% | 19.2ms | `set` | `[native code]` |
| 0.4% | 19.0ms | 0.4% | 19.0ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:582` |
| 0.4% | 17.6ms | 0.4% | 19.9ms | `test` | `[native code]` |
| 0.3% | 17.1ms | 0.3% | 17.1ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:473` |
| 0.3% | 16.8ms | 0.3% | 16.8ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:226` |
| 0.3% | 16.7ms | 0.3% | 16.7ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.3% | 16.5ms | 0.3% | 16.5ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:735` |
| 0.3% | 16.2ms | 0.3% | 16.2ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:738` |
| 0.3% | 15.6ms | 0.3% | 15.6ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:102` |
| 0.3% | 15.5ms | 0.4% | 21.4ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:119` |
| 0.3% | 15.4ms | 0.3% | 15.4ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:37` |
| 0.3% | 14.5ms | 0.9% | 41.1ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:158` |
| 0.3% | 14.4ms | 1.6% | 72.9ms | `xmlNameCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:91` |
| 0.3% | 14.2ms | 0.3% | 14.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:463` |
| 0.3% | 13.6ms | 0.3% | 13.6ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:247` |
| 0.2% | 12.8ms | 0.2% | 12.8ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1457` |
| 0.2% | 12.6ms | 0.3% | 15.0ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:91` |
| 0.2% | 12.4ms | 0.2% | 12.4ms | `add` | `[native code]` |
| 0.2% | 12.3ms | 0.4% | 19.6ms | `every` | `[native code]` |
| 0.2% | 11.6ms | 0.2% | 11.6ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:165` |
| 0.2% | 11.1ms | 0.2% | 11.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.2% | 11.1ms | 0.2% | 11.1ms | `preventExtensions` | `[native code]` |
| 0.2% | 10.9ms | 0.2% | 10.9ms | `/acc(?:Title\|Descr)/i` | `[native code]` |
| 0.2% | 10.9ms | 0.2% | 10.9ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:251` |
| 0.2% | 10.8ms | 20.9% | 912.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:160` |
| 0.2% | 10.8ms | 0.2% | 10.8ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:658` |
| 0.2% | 10.7ms | 0.2% | 10.7ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:235` |
| 0.2% | 10.7ms | 0.2% | 10.7ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1171` |
| 0.2% | 10.7ms | 0.2% | 10.7ms | `min` | `[native code]` |
| 0.2% | 10.7ms | 0.2% | 10.7ms | `writeSync` | `[native code]` |
| 0.2% | 10.5ms | 0.2% | 10.5ms | `Number` | `[native code]` |
| 0.2% | 10.1ms | 0.4% | 19.3ms | `replace` | `[native code]` |
| 0.2% | 10.1ms | 0.2% | 10.1ms | `includes` | `[native code]` |
| 0.2% | 9.9ms | 0.3% | 14.1ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:277` |
| 0.2% | 9.9ms | 0.2% | 11.5ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:15` |
| 0.2% | 9.7ms | 0.2% | 9.7ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.2% | 9.7ms | 0.2% | 9.7ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:86` |
| 0.2% | 9.6ms | 0.2% | 9.6ms | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` |
| 0.2% | 9.5ms | 0.2% | 11.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:108` |
| 0.2% | 9.4ms | 0.2% | 11.6ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:93` |
| 0.2% | 9.4ms | 0.2% | 9.4ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:115` |
| 0.2% | 9.3ms | 0.2% | 9.3ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:304` |
| 0.2% | 9.3ms | 1.5% | 65.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:117` |
| 0.2% | 9.2ms | 0.2% | 9.2ms | `connectorSubpaths` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:363` |
| 0.2% | 9.0ms | 0.2% | 11.4ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:496` |
| 0.2% | 9.0ms | 0.2% | 9.0ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:322` |
| 0.2% | 8.9ms | 0.3% | 14.3ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:268` |
| 0.2% | 8.7ms | 10.4% | 455.9ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:631` |
| 0.2% | 8.7ms | 0.2% | 8.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:192` |
| 0.1% | 8.6ms | 0.1% | 8.6ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:733` |
| 0.1% | 8.6ms | 0.1% | 8.6ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:529` |
| 0.1% | 8.6ms | 0.1% | 8.6ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` |
| 0.1% | 8.5ms | 0.1% | 8.5ms | `deferredTerminalProjectionInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.1% | 8.4ms | 0.1% | 8.4ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.1% | 8.3ms | 0.1% | 8.3ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.1% | 8.2ms | 0.1% | 8.2ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:524` |
| 0.1% | 8.2ms | 5.5% | 242.4ms | `forEach` | `[native code]` |
| 0.1% | 8.0ms | 0.2% | 10.4ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:646` |
| 0.1% | 8.0ms | 0.1% | 8.0ms | `push` | `[native code]` |
| 0.1% | 8.0ms | 0.1% | 8.0ms | `arrayIteratorNextHelper` | `[native code]` |
| 0.1% | 7.9ms | 0.4% | 20.6ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:162` |
| 0.1% | 7.9ms | 0.2% | 11.4ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:633` |
| 0.1% | 7.9ms | 0.1% | 7.9ms | `String` | `[native code]` |
| 0.1% | 7.8ms | 0.1% | 7.8ms | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:38` |
| 0.1% | 7.8ms | 0.1% | 7.8ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:338` |
| 0.1% | 7.7ms | 0.4% | 17.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:562` |
| 0.1% | 7.7ms | 0.2% | 12.9ms | `next` | `[native code]` |
| 0.1% | 7.6ms | 0.2% | 11.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:422` |
| 0.1% | 7.6ms | 2.1% | 93.5ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:739` |
| 0.1% | 7.5ms | 0.1% | 7.5ms | `RegExp` | `[native code]` |
| 0.1% | 7.5ms | 0.1% | 7.5ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:30` |
| 0.1% | 7.4ms | 0.1% | 7.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:550` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `compositeCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:277` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:488` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `xmlRange` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:48` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `registrationIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `markerPaintPieces` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:64` |
| 0.1% | 7.2ms | 0.1% | 7.2ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:485` |
| 0.1% | 7.2ms | 0.1% | 7.2ms | `get` | `[native code]` |
| 0.1% | 7.2ms | 0.1% | 7.2ms | `defineProperty` | `[native code]` |
| 0.1% | 7.1ms | 0.4% | 18.1ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:95` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:760` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `appendPrivate` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:55` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `slice` | `[native code]` |
| 0.1% | 6.9ms | 1.3% | 57.3ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:374` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:537` |
| 0.1% | 6.9ms | 0.2% | 9.9ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:274` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `locale_default` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-format/src/locale.js` |
| 0.1% | 6.8ms | 0.1% | 6.8ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:345` |
| 0.1% | 6.8ms | 0.1% | 6.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 6.7ms | 13.1% | 574.0ms | `serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:624` |
| 0.1% | 6.7ms | 0.4% | 19.6ms | `filter` | `[native code]` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:689` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:150` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.1% | 6.5ms | 0.4% | 19.0ms | `find` | `[native code]` |
| 0.1% | 6.5ms | 0.1% | 6.5ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` |
| 0.1% | 6.3ms | 0.1% | 6.3ms | `entries` | `[native code]` |
| 0.1% | 6.3ms | 0.1% | 7.5ms | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:311` |
| 0.1% | 6.2ms | 0.1% | 6.2ms | `proofRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:64` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `safeCssToken` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:66` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `result` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:377` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:87` |
| 0.1% | 6.1ms | 0.2% | 10.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `element` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:301` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:268` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `Buffer` | `[native code]` |
| 0.1% | 5.9ms | 0.1% | 5.9ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.1% | 5.9ms | 0.1% | 5.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:590` |
| 0.1% | 5.9ms | 1.8% | 78.8ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:129` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:675` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:831` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:32` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1025` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `read` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:78` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:583` |
| 0.1% | 5.7ms | 0.1% | 7.0ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:130` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `isFinite` | `[native code]` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:117` |
| 0.1% | 5.6ms | 0.1% | 5.6ms | `startTags` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.1% | 5.6ms | 0.1% | 5.6ms | `segmentEntersMeasuredBox` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:667` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `unclipped` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1034` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `separatedSharpSupports` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:62` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `classCommentStart` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:356` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/` | `[native code]` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `xmlHasColon` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `rectangleInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:339` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:520` |
| 0.1% | 5.2ms | 1.9% | 82.7ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:354` |
| 0.1% | 5.2ms | 0.2% | 10.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:594` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:33` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:498` |
| 0.1% | 5.1ms | 0.1% | 8.4ms | `skipSeparators` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:168` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `xmlList` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:40` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `classRelationshipTerminalClearance` | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `pointList` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `canonicalOpeningTag` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:437` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `node:fs` | `node:fs:2` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `orthogonal` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:461` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `parseFloat` | `[native code]` |
| 0.1% | 4.9ms | 0.2% | 11.3ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:662` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `localPaintResourceId` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:373` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `assign` | `[native code]` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:121` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:797` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:309` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.1% | 4.7ms | 0.1% | 6.1ms | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:365` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:177` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:725` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:367` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `isRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:66` |
| 0.1% | 4.6ms | 0.1% | 6.9ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:135` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `validateRole` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `join` | `[native code]` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 4.4ms | 0.1% | 5.9ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1836` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `/<\s*text/i` | `[native code]` |
| 0.1% | 4.3ms | 0.2% | 11.4ms | `emittedBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:72` |
| 0.0% | 4.3ms | 0.0% | 4.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:520` |
| 0.0% | 4.3ms | 0.0% | 4.3ms | `positionedPaintCertification` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` |
| 0.0% | 4.3ms | 0.0% | 4.3ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:434` |
| 0.0% | 4.2ms | 0.3% | 15.2ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:486` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:642` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:389` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 4.2ms | 0.2% | 9.8ms | `emitted` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:22` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `range` | `/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts:17` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:390` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:511` |
| 0.0% | 4.1ms | 0.0% | 4.1ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:501` |
| 0.0% | 4.1ms | 0.0% | 4.1ms | `writtenDecimalParts` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:30` |
| 0.0% | 4.0ms | 0.2% | 9.2ms | `resolveCss` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:728` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `readXmlReferenceEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:219` |
| 0.0% | 4.0ms | 1.7% | 75.4ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:252` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:301` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `xmlHasColon` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:89` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:20` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `markerTerminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:296` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:364` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:286` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `terminalEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `outputDescriptorsById` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `parseEncodeTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:45` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `assertInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:12` |
| 0.0% | 3.9ms | 0.1% | 6.6ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:274` |
| 0.0% | 3.9ms | 0.4% | 21.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:774` |
| 0.0% | 3.9ms | 0.1% | 7.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:705` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:67` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:133` |
| 0.0% | 3.8ms | 25.4% | 1.10s | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:118` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `open` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1429` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 3.7ms | 0.1% | 5.5ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:337` |
| 0.0% | 3.7ms | 0.1% | 4.8ms | `classNativeMarkerMinimums` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:194` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `classRelationshipLineStyle` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1610` |
| 0.0% | 3.7ms | 0.1% | 4.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:560` |
| 0.0% | 3.6ms | 0.1% | 7.4ms | `sort` | `[native code]` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `assertFinalBoundaryContacts` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `crossSize` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:33` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:142` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:759` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1061` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` |
| 0.0% | 3.4ms | 0.1% | 7.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `repairClassAnnotationSeats` | `/tmp/pr449-main-integration-20261029-762/src/class/annotation-seats.ts` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `records` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `createValidationState` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `assertKnownConnectorFields` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 3.4ms | 0.3% | 14.4ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:13` |
| 0.0% | 3.3ms | 0.2% | 9.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:737` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `writtenPoint` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:88` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:396` |
| 0.0% | 3.3ms | 0.2% | 9.8ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:371` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:633` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `/\s/` | `[native code]` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:51` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `append` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:239` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:448` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `sourceAdapter` | `/tmp/pr449-main-integration-20261029-762/src/agent/stable-family-source-hooks.ts` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `renderRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:560` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1208` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `writtenDecimalParts` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:32` |
| 0.0% | 3.1ms | 0.0% | 4.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:87` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:585` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `clip` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:84` |
| 0.0% | 3.1ms | 1.5% | 68.2ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:386` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:355` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `pose` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:336` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `classTextBlock` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 3.0ms | 0.0% | 4.0ms | `classCommentStart` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:369` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:474` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `label` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1491` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `toHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:42` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `splitAuthoredClassLine` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:99` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `circleMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts` |
| 0.0% | 3.0ms | 0.1% | 4.7ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:318` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:401` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:368` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:596` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `pose` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:333` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `prepared` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 2.9ms | 0.1% | 5.4ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:715` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:134` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:93` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `/<!--[\s\S]*?-->/g` | `[native code]` |
| 0.0% | 2.9ms | 0.2% | 11.7ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:285` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `skip` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1084` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:738` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:729` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `typedIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:74` |
| 0.0% | 2.8ms | 0.1% | 4.5ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:16` |
| 0.0% | 2.8ms | 0.7% | 33.5ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:446` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `isHexColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:143` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:164` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `toHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:324` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `BigInt` | `[native code]` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:168` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:406` |
| 0.0% | 2.7ms | 0.6% | 27.6ms | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:275` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:435` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `inRanges` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:114` |
| 0.0% | 2.7ms | 0.1% | 5.7ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:350` |
| 0.0% | 2.7ms | 0.1% | 8.3ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:239` |
| 0.0% | 2.6ms | 0.6% | 29.1ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:315` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `normalizeCssObfuscation` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:37` |
| 0.0% | 2.6ms | 0.3% | 14.9ms | `cloneValue` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `flatIntoArray` | `[native code]` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `Map` | `[native code]` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `sceneNodeWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `indexOf` | `[native code]` |
| 0.0% | 2.6ms | 0.2% | 12.9ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1475` |
| 0.0% | 2.6ms | 0.2% | 9.9ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:230` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:87` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:109` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `validateRoleStyleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/shared/diagram-limits.ts:16` |
| 0.0% | 2.5ms | 0.2% | 9.9ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:726` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:319` |
| 0.0% | 2.5ms | 0.1% | 5.5ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:367` |
| 0.0% | 2.5ms | 0.3% | 13.8ms | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:56` |
| 0.0% | 2.5ms | 0.3% | 14.4ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `assertRenderableMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 2.5ms | 0.0% | 3.7ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:299` |
| 0.0% | 2.5ms | 0.1% | 8.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:776` |
| 0.0% | 2.5ms | 0.3% | 13.4ms | `color` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1039` |
| 0.0% | 2.5ms | 0.1% | 6.9ms | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:106` |
| 0.0% | 2.5ms | 0.2% | 9.2ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:471` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `nativeTextPaintWriteOf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:68` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `continuesClassText` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:553` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1033` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` |
| 0.0% | 2.5ms | 0.2% | 9.1ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:839` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `oneOf` | `/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:177` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `work` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `retainNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/experimental/position-cache.ts` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `validatePoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `Segmenter` | `[native code]` |
| 0.0% | 2.4ms | 5.7% | 251.8ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1463` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:87` |
| 0.0% | 2.4ms | 1.6% | 72.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:49` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `/^(?:0\|[1-9]\d*)$/` | `[native code]` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:963` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:612` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `assertMarkerPaint` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:27` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `transferSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `connectorEndpointAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:444` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `dependencyArrowMarker` | `/tmp/pr449-main-integration-20261029-762/src/gantt/dependency-paint.ts:5` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `escapeXml` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:97` |
| 0.0% | 2.3ms | 0.0% | 3.7ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:92` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:976` |
| 0.0% | 2.3ms | 0.0% | 4.1ms | `relationAccessibility` | `/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` |
| 0.0% | 2.3ms | 0.2% | 8.9ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:334` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `max` | `[native code]` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:183` |
| 0.0% | 2.3ms | 0.1% | 4.9ms | `validateRoleStyles` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:340` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:536` |
| 0.0% | 2.3ms | 0.0% | 3.5ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:379` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 2.2ms | 0.1% | 6.8ms | `rectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:323` |
| 0.0% | 2.2ms | 0.2% | 11.1ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:753` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `classNativeMarkerMinimums` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:197` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:403` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `Set` | `[native code]` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `/var\(--([\w-]+)\)/g` | `[native code]` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `attr` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:552` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `install` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:41` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `validatePoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:462` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:686` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `tipAnchoredArrow` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `supportedRelationEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1515` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:796` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:910` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `imul` | `[native code]` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `(anonymous)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:11` |
| 0.0% | 2.1ms | 0.1% | 5.4ms | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:164` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `inspectOwnedSvgOnce` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `ownConnectorEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:191` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 2.1ms | 0.0% | 3.4ms | `parseMarkerlessClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1415` |
| 0.0% | 2.1ms | 0.0% | 3.4ms | `ActualTextPaintWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:393` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `measureTextWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:146` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `assertKnownConnectorFields` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:160` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `multiplySceneOpacity` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:541` |
| 0.0% | 2.1ms | 0.1% | 4.6ms | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` |
| 0.0% | 2.1ms | 26.7% | 1.16s | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:136` |
| 0.0% | 2.0ms | 0.2% | 9.1ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:357` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:206` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:169` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `classRelationText` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1330` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `raw` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `/--([\w-]+)\s*:\s*([^;{}]+)/g` | `[native code]` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:714` |
| 0.0% | 2.0ms | 0.0% | 3.8ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:351` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `copyProps` | `internal:primordials` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:441` |
| 0.0% | 1.9ms | 0.0% | 3.1ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:436` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `lazyGraphicalArtifact` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:35` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:109` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:360` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `renderDivider` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:409` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:844` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1102` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:6` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1808` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 1.8ms | 0.1% | 5.0ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:718` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1029` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:40` |
| 0.0% | 1.8ms | 0.1% | 7.2ms | `measureTextWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:206` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:348` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `normalizeCssObfuscation` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:27` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `world` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:23` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `terminalMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:55` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `viewportBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` |
| 0.0% | 1.8ms | 0.0% | 3.8ms | `assertMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:58` |
| 0.0% | 1.8ms | 0.1% | 8.5ms | `serializeMarkerResource` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:141` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `serializeMarkerResource` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:123` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:24` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:358` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `isPlainRecord` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `compactProvedPath` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-portal-channel.ts:428` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validatePoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:455` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1088` |
| 0.0% | 1.7ms | 0.0% | 3.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:275` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:549` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:427` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:204` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:262` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `optional` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:49` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:826` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:235` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:349` |
| 0.0% | 1.7ms | 0.0% | 3.1ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:685` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `authoredClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 1.7ms | 6.0% | 265.3ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1467` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:639` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:284` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `addClassSvgNumbers` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:66` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `retainRequestGraphLayoutDecision` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `delete` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:161` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:369` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:262` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:96` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:836` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:176` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `assertMarkerPaint` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:28` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `legibleInk` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:137` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `parseMarkedClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1320` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `orthogonal` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `schemaMatchesRuntimeKind` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:41` |
| 0.0% | 1.6ms | 0.1% | 5.1ms | `pose` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:317` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:146` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:387` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `read` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:76` |
| 0.0% | 1.6ms | 0.1% | 4.4ms | `writtenDecimalParts` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:31` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `transformPoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:19` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:127` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `expectedCapabilityState` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1645` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:272` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:26` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1094` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `validateJsonConfigAdmission` | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts:216` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1021` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1498` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:625` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `geometryElements` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 1.5ms | 0.5% | 25.7ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:193` |
| 0.0% | 1.5ms | 0.0% | 2.7ms | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:266` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:725` |
| 0.0% | 1.5ms | 0.3% | 14.9ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:484` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:988` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:283` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:499` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:661` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `ownerSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `work` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `readXmlReferenceEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `now` | `[native code]` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `safeCssPaint` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:134` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `selfContact` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1211` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `ActualTextPaintWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `createEmissionContext` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:40` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:96` |
| 0.0% | 1.5ms | 0.1% | 6.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:185` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `connectorMarkerPaintRegions` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:319` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.5ms | 0.0% | 2.8ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:546` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `skip` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:62` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:62` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:511` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:235` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `classRelationshipEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `get conformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:496` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `ownConnectorEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:96` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `createEmissionContext` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:22` |
| 0.0% | 1.4ms | 0.0% | 2.5ms | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:81` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:86` |
| 0.0% | 1.4ms | 1.7% | 74.3ms | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:119` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1802` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `createNativeSceneValidator` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2361` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `roleStyleJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:494` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `seatFinalMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scanSvgStartTagsFresh` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 1.4ms | 0.0% | 2.7ms | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:369` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `createPaintRecorder` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:243` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:510` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `/[^\x00-\x7f]/` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:979` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `svgOpenTag` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.4ms | 0.1% | 6.9ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:83` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:598` |
| 0.0% | 1.4ms | 0.1% | 6.1ms | `ownConnectorEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:190` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:16` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `document/identity/serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:512` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:116` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:422` |
| 0.0% | 1.4ms | 0.5% | 26.0ms | `node:zlib` | `node:zlib:2` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:584` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `projectClassRectangleContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:194` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:236` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:292` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `crossSize` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `terminalMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:56` |
| 0.0% | 1.4ms | 0.0% | 3.4ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:808` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:217` |
| 0.0% | 1.4ms | 0.1% | 7.6ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:282` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `read` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:64` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:719` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1031` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `seatFinalMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:475` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:18` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector/stroke/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `numberIsValid` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:280` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `writeStructuredSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:594` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:366` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:111` |
| 0.0% | 1.3ms | 0.0% | 3.8ms | `boundedImmutableJsonSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1242` |
| 0.0% | 1.3ms | 0.1% | 4.3ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:119` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:417` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `intersects` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `renderRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:589` |
| 0.0% | 1.3ms | 0.0% | 3.1ms | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:112` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `decodeWithTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:456` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:263` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `hasOwned` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `NativeZlib` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 2.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:712` |
| 0.0% | 1.3ms | 1.6% | 73.2ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1019` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `isWideRange` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:128` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `assertInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:32` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:696` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:276` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:405` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `declareFamilyScenePrimitiveEvidence` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `luminanceContrastRatio` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:73` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:233` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:552` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1755` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:667` |
| 0.0% | 1.3ms | 0.0% | 2.6ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:262` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:530` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1742` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `trim` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:357` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:432` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `extractClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:457` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:258` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `measureClassCards` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:185` |
| 0.0% | 1.3ms | 0.0% | 2.6ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:173` |
| 0.0% | 1.3ms | 0.6% | 26.1ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` |
| 0.0% | 1.3ms | 0.0% | 4.0ms | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1097` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2083` |
| 0.0% | 1.3ms | 0.0% | 4.0ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:581` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pose` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:329` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:110` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `/^(?:#[0-9a-f]{3,4}\|#[0-9a-f]{6}\|#[0-9a-f]{8}\|[a-z][a-z0-9-]*)$/i` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:418` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `getOwnPropertyDescriptors` | `[native code]` |
| 0.0% | 1.3ms | 0.2% | 10.7ms | `reduce` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `get` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `mainSize` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:32` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:341` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:843` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `extractClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:433` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:650` |
| 0.0% | 1.3ms | 0.2% | 10.5ms | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:381` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:138` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `retainedLabelBounds` | `/tmp/pr449-main-integration-20261029-762/src/agent/layout-to-rendered.ts:17` |
| 0.0% | 1.3ms | 0.3% | 16.1ms | `flatIntoArrayWithCallback` | `[native code]` |
| 0.0% | 1.3ms | 0.3% | 16.6ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:530` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parseClassRelationEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1399` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector/relation/accessibility` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.3ms | 0.4% | 18.9ms | `validatePoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:465` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:129` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connectorEndpointAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:443` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `applyReplacements` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:198` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `rectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 2.3ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:511` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:152` |
| 0.0% | 1.2ms | 0.2% | 8.8ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:311` |
| 0.0% | 1.2ms | 5.6% | 247.4ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:575` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:744` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:122` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:718` |
| 0.0% | 1.2ms | 0.0% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:680` |
| 0.0% | 1.2ms | 0.5% | 22.5ms | `assertInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:16` |
| 0.0% | 1.2ms | 0.5% | 24.4ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:104` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:15` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:604` |
| 0.0% | 1.2ms | 0.0% | 2.6ms | `parseExtensionId` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:202` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `matchMermaidFrontmatter` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:701` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:844` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/types.ts:1761` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:668` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:317` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:392` |
| 0.0% | 1.2ms | 0.6% | 27.6ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:639` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `/^[A-Za-z0-9_-]+(?: [A-Za-z0-9_-]+)*$/` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 3.9ms | `from` | `[native code]` |
| 0.0% | 1.2ms | 0.1% | 6.7ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1063` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `cachedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/experimental/position-cache.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:586` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `createNativePaintEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.2ms | 0.2% | 8.8ms | `attr` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:53` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `occurrence` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:755` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `diagramTitleBand` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts:356` |
| 0.0% | 1.2ms | 0.9% | 41.3ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:330` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:429` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorDirection` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:206` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `classifyClassStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:537` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:132` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:33` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:706` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `escapeXml` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:95` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-limits.ts:2` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `assertFinalClassSharpContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `markPaintPrepared` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:325` |
| 0.0% | 1.2ms | 0.0% | 2.4ms | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:197` |
| 0.0% | 1.2ms | 0.3% | 14.5ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:435` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `sign` | `[native code]` |
| 0.0% | 1.2ms | 0.3% | 15.7ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:759` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.0% | 1.2ms | 0.1% | 6.1ms | `collectPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1371` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `safeCssPaint` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:129` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `endsWith` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:661` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:105` |
| 0.0% | 1.2ms | 0.0% | 2.7ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:265` |
| 0.0% | 1.2ms | 0.0% | 3.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:183` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1073` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:794` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1782` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `apply` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `dereferenceSchema` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `SvgWriter` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `reserve` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `admitRenderOptionsInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1293` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:428` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:93` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parseClassInteractionWithAuthored` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:922` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `topRoundedRectPath` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:843` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:502` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:172` |
| 0.0% | 1.2ms | 0.2% | 11.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:124` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `immutableSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1214` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:626` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1141` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:207` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parseClassRelationEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1354` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `rectOverlap` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:364` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `assertRenderableMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:88` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `createClassInterfaceAllocator` | `/tmp/pr449-main-integration-20261029-762/src/class/interface-occurrences.ts:21` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1065` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:50` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `resolvedInlineColorAttribute` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:686` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:284` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `sourceEnvelopeMetadata` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:853` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:591` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `nativePaintSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `nativePaintSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:227` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `renderRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:578` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/external-scene.ts:154` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:765` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `resetBuffer` | `internal:streams/writable` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:608` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1447` |
| 0.0% | 1.1ms | 0.0% | 2.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:440` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:168` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:637` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:180` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `topRoundedRectPath` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:844` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `scanInlineNamespaceStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `unsafeThemeColorKeys` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `executionCapabilityKey` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1432` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `get` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:10` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1071` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:213` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:126` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `rejectUnknownKeys` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:153` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `serializeMarkerResource` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:137` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `rejectUnknownKeys` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `node:zlib:456` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `normalizeMermaidRuntimeConfig` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `executionOffer` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validatePrimitiveCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:341` |
| 0.0% | 1.1ms | 0.0% | 2.4ms | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:57` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:284` |
| 0.0% | 1.1ms | 0.0% | 2.3ms | `rejectUnknownKeys` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:152` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:208` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `classNativeMarkerMinimums` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `transferSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:751` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `withRenderStageObserver` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:15` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:213` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isFrozen` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:161` |
| 0.0% | 1.1ms | 0.0% | 2.2ms | `writeFileSync` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1462` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isExtensible` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `flatMap` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `normalizedReference` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:595` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validatePrimitiveCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:332` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:605` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `distanceToSegment` | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:114` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:664` |
| 0.0% | 1.1ms | 80.0% | 3.48s | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:11` |
| 0.0% | 1.1ms | 0.0% | 2.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1035` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `cloneFrontmatterMap` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:724` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1199` |
| 0.0% | 1.1ms | 0.1% | 5.6ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:773` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `documentClose` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:140` |
| 0.0% | 1.1ms | 0.2% | 12.8ms | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:200` |
| 0.0% | 1.1ms | 0.1% | 6.2ms | `XmlLeafWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:298` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:369` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `compareCodePointStrings` | `/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:293` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:204` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `detectorClaims` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1595` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:879` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:346` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `matchingBrace` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:146` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `transformAttribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:531` |
| 0.0% | 1.0ms | 0.2% | 10.7ms | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:138` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1201` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:734` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:506` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `atan2` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `startsWith` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 2.1ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:151` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `expandInlineNamespaceStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:179` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `separatedSharpSupportBounds` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:68` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:591` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:497` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolveClassRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `paintPrimitiveSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.0ms | 0.1% | 7.6ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:229` |
| 0.0% | 1.0ms | 2.0% | 89.3ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:85` |
| 0.0% | 1.0ms | 0.2% | 10.3ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:127` |
| 0.0% | 1.0ms | 0.0% | 3.6ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:641` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `/^\s*<([A-Za-z][\w:-]*)\b[^>]*>/` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `xmlTokenAt` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:85` |
| 0.0% | 1.0ms | 0.5% | 23.1ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` |
| 0.0% | 1.0ms | 0.2% | 9.0ms | `performIteration` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:290` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:65` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `/^\s*<g\b[^>]*>(?:<title>[^<]*<\/title>)?$/` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:307` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `/&quot;\|&#0*34;\|&#x0*22;/gi` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:642` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:398` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:89` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `renderDisplayRuns` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:148` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:703` |
| 0.0% | 1.0ms | 0.5% | 25.0ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:524` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `writtenDecimalParts` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:29` |
| 0.0% | 1.0ms | 0.1% | 4.7ms | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:649` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `get receipt` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:346` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `checkFamilyConfigColors` | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:246` |
| 0.0% | 1.0ms | 0.0% | 3.8ms | `emittedPoint` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:24` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `scanInlineNamespaceStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:48` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:102` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `requiredBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1363` |
| 0.0% | 1.0ms | 0.1% | 7.2ms | `SvgWriter` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:471` |
| 0.0% | 998us | 0.0% | 998us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:840` |
| 0.0% | 995us | 0.0% | 995us | `inlineResolvedColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:637` |
| 0.0% | 989us | 0.0% | 989us | `findMarkerlessRelationshipOperator` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1550` |
| 0.0% | 988us | 0.0% | 988us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:253` |
| 0.0% | 978us | 0.0% | 978us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:241` |
| 0.0% | 976us | 0.0% | 976us | `normalizeCssObfuscation` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:33` |
| 0.0% | 975us | 0.0% | 975us | `validateRawThemeCss` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 972us | 0.1% | 7.6ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:325` |
| 0.0% | 969us | 0.0% | 969us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:725` |
| 0.0% | 967us | 0.0% | 967us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 954us | 0.0% | 954us | `positionFamilyForNativeRender` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 100.0% | 5.40s | 0.0% | 0us | `withTextMeasurementExecution` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:135` |
| 82.5% | 3.59s | 0.0% | 0us | `measureRenderStage` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:30` |
| 80.0% | 3.48s | 0.0% | 1.1ms | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:11` |
| 80.0% | 3.48s | 0.0% | 0us | `withSvgInspectionCache` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:20` |
| 80.0% | 3.48s | 0.0% | 0us | `withRenderStageObserver` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:20` |
| 78.2% | 3.40s | 0.0% | 0us | `consumeResolvedGraphicalRequest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:316` |
| 47.6% | 2.07s | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:183` |
| 45.8% | 1.99s | 0.0% | 0us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:140` |
| 41.2% | 1.79s | 0.0% | 0us | `withDeferredTerminalProjections` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:16` |
| 41.2% | 1.79s | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:200` |
| 26.7% | 1.16s | 0.0% | 2.1ms | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:136` |
| 25.4% | 1.10s | 0.0% | 3.8ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:118` |
| 20.9% | 912.0ms | 0.2% | 10.8ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:160` |
| 18.9% | 822.8ms | 0.0% | 0us | `renderResolvedMermaidSVG` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:270` |
| 18.8% | 821.8ms | 0.0% | 0us | `positionFamilyForNativeRender` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:67` |
| 18.5% | 808.4ms | 0.0% | 0us | `withGraphLayoutDecisionObserver` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:37` |
| 18.5% | 808.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:123` |
| 17.0% | 740.7ms | 0.0% | 0us | `layout` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:25` |
| 16.2% | 705.4ms | 0.0% | 0us | `runMeasuredGraphBackend` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:73` |
| 13.1% | 574.0ms | 0.1% | 6.7ms | `serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:624` |
| 12.1% | 527.9ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:665` |
| 12.0% | 522.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 10.4% | 455.9ms | 0.2% | 8.7ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:631` |
| 10.2% | 447.0ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:131` |
| 10.0% | 436.1ms | 6.2% | 270.4ms | `bound require` | `[native code]` |
| 9.1% | 399.8ms | 0.0% | 0us | `inspectOwnedSvgOnce` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:46` |
| 9.1% | 396.1ms | 0.0% | 0us | `applyOutputSecurityPolicy` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:742` |
| 8.7% | 382.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:725` |
| 8.7% | 379.0ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:252` |
| 8.2% | 359.7ms | 0.0% | 0us | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:359` |
| 6.3% | 275.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:3` |
| 6.3% | 275.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:5` |
| 6.2% | 273.1ms | 1.6% | 71.6ms | `anonymous` | `[native code]` |
| 6.0% | 265.3ms | 0.0% | 1.7ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1467` |
| 6.0% | 261.1ms | 0.0% | 0us | `o` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 5.8% | 254.6ms | 0.0% | 0us | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:792` |
| 5.7% | 251.8ms | 0.0% | 2.4ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1463` |
| 5.6% | 247.4ms | 0.0% | 1.2ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:575` |
| 5.5% | 242.4ms | 0.1% | 8.2ms | `forEach` | `[native code]` |
| 4.6% | 203.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:678` |
| 4.5% | 196.9ms | 0.0% | 0us | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:791` |
| 4.3% | 189.4ms | 0.6% | 29.6ms | `map` | `[native code]` |
| 4.2% | 184.3ms | 4.2% | 184.3ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:106` |
| 4.0% | 177.4ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:242` |
| 3.9% | 170.8ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:94` |
| 3.8% | 168.0ms | 0.0% | 0us | `inspectPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:98` |
| 3.8% | 165.6ms | 0.0% | 0us | `require` | `[native code]` |
| 3.7% | 162.6ms | 0.0% | 0us | `finalizeFlatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:655` |
| 3.6% | 159.7ms | 0.0% | 0us | `seatFinalMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:569` |
| 3.5% | 155.5ms | 3.5% | 155.5ms | `getOwnPropertyDescriptor` | `[native code]` |
| 3.4% | 148.6ms | 0.0% | 0us | `finalizeClassSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:824` |
| 3.3% | 144.9ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:420` |
| 3.1% | 136.5ms | 3.0% | 131.2ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:169` |
| 3.0% | 134.9ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:144` |
| 3.0% | 134.2ms | 0.0% | 0us | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:308` |
| 3.0% | 131.6ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:208` |
| 3.0% | 131.4ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:103` |
| 3.0% | 130.5ms | 0.0% | 0us | `r` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 3.0% | 130.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6538` |
| 3.0% | 130.5ms | 0.0% | 0us | `_defineProperties` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:10` |
| 3.0% | 130.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:115` |
| 3.0% | 130.5ms | 0.0% | 0us | `_createClass` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:11` |
| 3.0% | 130.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:66` |
| 3.0% | 130.5ms | 0.0% | 0us | `_toPropertyKey` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:12` |
| 3.0% | 130.5ms | 3.0% | 130.5ms | `_toPrimitive` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:13` |
| 2.9% | 130.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:148` |
| 2.3% | 102.8ms | 0.0% | 0us | `connectorMarkerPaintRegions` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:353` |
| 2.3% | 100.2ms | 0.0% | 0us | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:1026` |
| 2.2% | 98.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:601` |
| 2.2% | 97.0ms | 0.0% | 0us | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:219` |
| 2.1% | 93.5ms | 0.1% | 7.6ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:739` |
| 2.1% | 92.6ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:127` |
| 2.0% | 89.3ms | 0.0% | 1.0ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:85` |
| 1.9% | 84.9ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:179` |
| 1.9% | 83.7ms | 1.9% | 83.7ms | `copyDataProperties` | `[native code]` |
| 1.9% | 82.7ms | 0.1% | 5.2ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:354` |
| 1.8% | 81.6ms | 0.0% | 0us | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:321` |
| 1.8% | 79.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:208` |
| 1.8% | 78.8ms | 0.1% | 5.9ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:129` |
| 1.7% | 77.9ms | 0.0% | 0us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:111` |
| 1.7% | 76.4ms | 0.0% | 0us | `report` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:235` |
| 1.7% | 75.5ms | 0.0% | 0us | `executeInspectedGraphicalRequest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:297` |
| 1.7% | 75.4ms | 0.0% | 4.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:252` |
| 1.7% | 75.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:191` |
| 1.7% | 75.2ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:418` |
| 1.7% | 74.7ms | 1.7% | 74.7ms | `fromEntries` | `[native code]` |
| 1.7% | 74.3ms | 0.0% | 1.4ms | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:119` |
| 1.7% | 74.0ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:90` |
| 1.6% | 73.9ms | 0.0% | 0us | `styleSpecJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:608` |
| 1.6% | 73.2ms | 0.0% | 1.3ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1019` |
| 1.6% | 73.1ms | 0.0% | 0us | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:200` |
| 1.6% | 72.9ms | 0.3% | 14.4ms | `xmlNameCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:91` |
| 1.6% | 72.6ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:49` |
| 1.5% | 68.2ms | 0.0% | 3.1ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:386` |
| 1.5% | 66.8ms | 1.5% | 66.8ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:90` |
| 1.5% | 66.8ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:218` |
| 1.5% | 65.7ms | 0.2% | 9.3ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:117` |
| 1.4% | 64.6ms | 0.0% | 0us | `layout` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:20` |
| 1.4% | 63.7ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:89` |
| 1.4% | 63.4ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:166` |
| 1.4% | 63.3ms | 1.0% | 47.7ms | `stringify` | `[native code]` |
| 1.4% | 62.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/decode-data-html.js:3` |
| 1.4% | 62.4ms | 1.4% | 62.4ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:23` |
| 1.4% | 61.3ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:94` |
| 1.3% | 60.9ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1210` |
| 1.3% | 57.3ms | 0.1% | 6.9ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:374` |
| 1.2% | 54.6ms | 0.0% | 0us | `inlineResolvedColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:636` |
| 1.1% | 50.8ms | 0.5% | 24.8ms | `some` | `[native code]` |
| 1.1% | 50.0ms | 0.0% | 0us | `projectSvgCss` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:249` |
| 1.1% | 50.0ms | 0.0% | 0us | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:701` |
| 1.1% | 48.6ms | 0.0% | 0us | `rendered` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:427` |
| 1.1% | 48.6ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1031` |
| 1.1% | 48.6ms | 1.1% | 48.6ms | `freeze` | `[native code]` |
| 1.1% | 48.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/families.ts:8` |
| 1.0% | 47.0ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:502` |
| 1.0% | 47.0ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:171` |
| 1.0% | 46.8ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:678` |
| 1.0% | 46.3ms | 1.0% | 44.8ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` |
| 1.0% | 46.0ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:632` |
| 1.0% | 45.5ms | 0.9% | 42.2ms | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:13` |
| 1.0% | 44.9ms | 0.0% | 0us | `resolvedColorValue` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:601` |
| 1.0% | 44.4ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:565` |
| 0.9% | 43.1ms | 0.9% | 43.1ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` |
| 0.9% | 42.5ms | 0.9% | 42.5ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:113` |
| 0.9% | 41.6ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:100` |
| 0.9% | 41.3ms | 0.0% | 1.2ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:330` |
| 0.9% | 41.2ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:441` |
| 0.9% | 41.1ms | 0.3% | 14.5ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:158` |
| 0.8% | 38.4ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:186` |
| 0.8% | 38.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:3` |
| 0.8% | 38.1ms | 0.4% | 19.4ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:435` |
| 0.8% | 38.1ms | 0.0% | 0us | `normalizeMermaidSourceWithOverrides` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:762` |
| 0.8% | 38.1ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1737` |
| 0.8% | 36.3ms | 0.0% | 0us | `finalizeClassSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:834` |
| 0.8% | 36.0ms | 0.0% | 0us | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:711` |
| 0.8% | 35.7ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:619` |
| 0.8% | 35.1ms | 0.0% | 0us | `assertFinalClassSharpContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:866` |
| 0.8% | 34.8ms | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:126` |
| 0.7% | 34.5ms | 0.0% | 0us | `assertAdmissibleSceneDoc` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation.ts:247` |
| 0.7% | 34.5ms | 0.0% | 0us | `admitSceneDocumentWith` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:270` |
| 0.7% | 34.5ms | 0.0% | 0us | `render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:394` |
| 0.7% | 33.8ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:167` |
| 0.7% | 33.6ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:197` |
| 0.7% | 33.5ms | 0.0% | 0us | `layoutClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:631` |
| 0.7% | 33.5ms | 0.0% | 2.8ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:446` |
| 0.7% | 33.2ms | 0.7% | 32.2ms | `match` | `[native code]` |
| 0.7% | 32.8ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:465` |
| 0.7% | 32.2ms | 0.0% | 0us | `measureClassCards` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:186` |
| 0.7% | 30.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:728` |
| 0.7% | 30.6ms | 0.0% | 0us | `setConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:53` |
| 0.6% | 30.3ms | 0.0% | 0us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:985` |
| 0.6% | 30.0ms | 0.6% | 30.0ms | `cloneObject` | `[native code]` |
| 0.6% | 29.8ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:764` |
| 0.6% | 29.5ms | 0.0% | 0us | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:376` |
| 0.6% | 29.4ms | 0.0% | 0us | `positionedPaintCertification` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:154` |
| 0.6% | 29.1ms | 0.0% | 2.6ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:315` |
| 0.6% | 28.4ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:729` |
| 0.6% | 28.1ms | 0.0% | 0us | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1448` |
| 0.6% | 28.0ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1879` |
| 0.6% | 27.7ms | 0.6% | 27.7ms | `has` | `[native code]` |
| 0.6% | 27.6ms | 0.0% | 1.2ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` |
| 0.6% | 27.6ms | 0.0% | 0us | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1041` |
| 0.6% | 27.6ms | 0.0% | 2.7ms | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:275` |
| 0.6% | 27.4ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:557` |
| 0.6% | 27.3ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:589` |
| 0.6% | 27.1ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:145` |
| 0.6% | 27.1ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:125` |
| 0.6% | 26.5ms | 0.0% | 0us | `classStatementEnds` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:650` |
| 0.6% | 26.2ms | 0.0% | 0us | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:209` |
| 0.6% | 26.1ms | 0.0% | 1.3ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` |
| 0.5% | 26.0ms | 0.0% | 1.4ms | `node:zlib` | `node:zlib:2` |
| 0.5% | 25.7ms | 0.0% | 1.5ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:193` |
| 0.5% | 25.5ms | 0.5% | 25.5ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:115` |
| 0.5% | 25.4ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:195` |
| 0.5% | 25.0ms | 0.0% | 1.0ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:524` |
| 0.5% | 24.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:12` |
| 0.5% | 24.4ms | 0.0% | 1.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:104` |
| 0.5% | 24.0ms | 0.0% | 0us | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:846` |
| 0.5% | 23.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:5` |
| 0.5% | 23.2ms | 0.0% | 0us | `installedFamilyStatementEnds` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts:76` |
| 0.5% | 23.1ms | 0.0% | 1.0ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` |
| 0.5% | 23.1ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1468` |
| 0.5% | 23.0ms | 0.0% | 0us | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:285` |
| 0.5% | 22.9ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:93` |
| 0.5% | 22.5ms | 0.0% | 0us | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:569` |
| 0.5% | 22.5ms | 0.0% | 1.2ms | `assertInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:16` |
| 0.5% | 22.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:19` |
| 0.5% | 22.4ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:237` |
| 0.5% | 22.3ms | 0.5% | 22.3ms | `hasOwn` | `[native code]` |
| 0.4% | 21.4ms | 0.3% | 15.5ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:119` |
| 0.4% | 21.0ms | 0.0% | 3.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:774` |
| 0.4% | 21.0ms | 0.0% | 0us | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` |
| 0.4% | 20.7ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:588` |
| 0.4% | 20.6ms | 0.1% | 7.9ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:162` |
| 0.4% | 20.3ms | 0.0% | 0us | `serialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1495` |
| 0.4% | 20.2ms | 0.4% | 20.2ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:105` |
| 0.4% | 19.9ms | 0.4% | 17.6ms | `test` | `[native code]` |
| 0.4% | 19.7ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:169` |
| 0.4% | 19.6ms | 0.2% | 12.3ms | `every` | `[native code]` |
| 0.4% | 19.6ms | 0.1% | 6.7ms | `filter` | `[native code]` |
| 0.4% | 19.3ms | 0.2% | 10.1ms | `replace` | `[native code]` |
| 0.4% | 19.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:812` |
| 0.4% | 19.2ms | 0.4% | 19.2ms | `set` | `[native code]` |
| 0.4% | 19.2ms | 0.0% | 0us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:992` |
| 0.4% | 19.0ms | 0.4% | 19.0ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:582` |
| 0.4% | 19.0ms | 0.1% | 6.5ms | `find` | `[native code]` |
| 0.4% | 18.9ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:646` |
| 0.4% | 18.9ms | 0.0% | 1.3ms | `validatePoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:465` |
| 0.4% | 18.7ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:637` |
| 0.4% | 18.2ms | 0.0% | 0us | `node:stream` | `node:stream:2` |
| 0.4% | 18.1ms | 0.1% | 7.1ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:95` |
| 0.4% | 17.8ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:347` |
| 0.4% | 17.6ms | 0.1% | 7.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:562` |
| 0.4% | 17.6ms | 0.0% | 0us | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:362` |
| 0.4% | 17.6ms | 0.0% | 0us | `visitSvgFirstTagAttributes` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:79` |
| 0.4% | 17.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:555` |
| 0.3% | 17.1ms | 0.3% | 17.1ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:473` |
| 0.3% | 17.0ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:803` |
| 0.3% | 16.8ms | 0.3% | 16.8ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:226` |
| 0.3% | 16.7ms | 0.3% | 16.7ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.3% | 16.6ms | 0.0% | 1.3ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:530` |
| 0.3% | 16.5ms | 0.3% | 16.5ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:735` |
| 0.3% | 16.4ms | 0.0% | 0us | `internal:stream` | `internal:stream:2` |
| 0.3% | 16.2ms | 0.3% | 16.2ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:738` |
| 0.3% | 16.1ms | 0.0% | 1.3ms | `flatIntoArrayWithCallback` | `[native code]` |
| 0.3% | 15.7ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1878` |
| 0.3% | 15.7ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:759` |
| 0.3% | 15.6ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1632` |
| 0.3% | 15.6ms | 0.0% | 0us | `get receipt` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:347` |
| 0.3% | 15.6ms | 0.3% | 15.6ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:102` |
| 0.3% | 15.6ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:682` |
| 0.3% | 15.4ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1616` |
| 0.3% | 15.4ms | 0.3% | 15.4ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:37` |
| 0.3% | 15.2ms | 0.0% | 4.2ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:486` |
| 0.3% | 15.0ms | 0.2% | 12.6ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:91` |
| 0.3% | 14.9ms | 0.0% | 2.6ms | `cloneValue` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.3% | 14.9ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:161` |
| 0.3% | 14.9ms | 0.0% | 0us | `renderRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:671` |
| 0.3% | 14.9ms | 0.0% | 1.5ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:484` |
| 0.3% | 14.8ms | 0.0% | 0us | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:437` |
| 0.3% | 14.7ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:702` |
| 0.3% | 14.5ms | 0.0% | 1.2ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:435` |
| 0.3% | 14.4ms | 0.0% | 2.5ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` |
| 0.3% | 14.4ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:609` |
| 0.3% | 14.4ms | 0.0% | 3.4ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:13` |
| 0.3% | 14.3ms | 0.2% | 8.9ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:268` |
| 0.3% | 14.3ms | 0.0% | 0us | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` |
| 0.3% | 14.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:328` |
| 0.3% | 14.2ms | 0.3% | 14.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:463` |
| 0.3% | 14.1ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:903` |
| 0.3% | 14.1ms | 0.0% | 0us | `color` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1038` |
| 0.3% | 14.1ms | 0.2% | 9.9ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:277` |
| 0.3% | 14.1ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:532` |
| 0.3% | 14.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:153` |
| 0.3% | 14.1ms | 0.0% | 0us | `render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:152` |
| 0.3% | 14.0ms | 0.0% | 0us | `classifyClassStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:536` |
| 0.3% | 14.0ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:178` |
| 0.3% | 14.0ms | 0.0% | 0us | `svgStyleRanges` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:256` |
| 0.3% | 13.8ms | 0.0% | 2.5ms | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:56` |
| 0.3% | 13.8ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:825` |
| 0.3% | 13.6ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:618` |
| 0.3% | 13.6ms | 0.3% | 13.6ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:247` |
| 0.3% | 13.4ms | 0.0% | 2.5ms | `color` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1039` |
| 0.3% | 13.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:659` |
| 0.3% | 13.4ms | 0.0% | 0us | `buildClassEndpointMarkerTemplates` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts:9` |
| 0.3% | 13.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts:9` |
| 0.3% | 13.3ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:605` |
| 0.3% | 13.1ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:292` |
| 0.2% | 12.9ms | 0.0% | 2.6ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1475` |
| 0.2% | 12.9ms | 0.1% | 7.7ms | `next` | `[native code]` |
| 0.2% | 12.8ms | 0.2% | 12.8ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1457` |
| 0.2% | 12.8ms | 0.0% | 1.1ms | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:200` |
| 0.2% | 12.6ms | 0.0% | 0us | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:346` |
| 0.2% | 12.5ms | 0.0% | 0us | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:358` |
| 0.2% | 12.4ms | 0.2% | 12.4ms | `add` | `[native code]` |
| 0.2% | 12.3ms | 0.0% | 0us | `sourceEnvelopeMetadata` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:809` |
| 0.2% | 12.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.2% | 12.1ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:799` |
| 0.2% | 12.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:8` |
| 0.2% | 12.1ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:143` |
| 0.2% | 12.1ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:323` |
| 0.2% | 12.0ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:420` |
| 0.2% | 11.7ms | 0.0% | 2.9ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:285` |
| 0.2% | 11.6ms | 0.0% | 0us | `internal:streams/pipeline` | `internal:streams/pipeline:2` |
| 0.2% | 11.6ms | 0.0% | 0us | `internal:streams/compose` | `internal:streams/compose:2` |
| 0.2% | 11.6ms | 0.2% | 11.6ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:165` |
| 0.2% | 11.6ms | 0.0% | 0us | `prepareMarkerTerminals` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:9` |
| 0.2% | 11.6ms | 0.2% | 9.4ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:93` |
| 0.2% | 11.5ms | 0.2% | 9.9ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:15` |
| 0.2% | 11.4ms | 0.1% | 7.9ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:633` |
| 0.2% | 11.4ms | 0.1% | 4.3ms | `emittedBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:72` |
| 0.2% | 11.4ms | 0.2% | 9.0ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:496` |
| 0.2% | 11.4ms | 0.0% | 0us | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:155` |
| 0.2% | 11.3ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:563` |
| 0.2% | 11.3ms | 0.1% | 4.9ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:662` |
| 0.2% | 11.2ms | 0.1% | 7.6ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:422` |
| 0.2% | 11.1ms | 0.2% | 11.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.2% | 11.1ms | 0.0% | 0us | `resolveSvgColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:758` |
| 0.2% | 11.1ms | 0.2% | 11.1ms | `preventExtensions` | `[native code]` |
| 0.2% | 11.1ms | 0.0% | 2.2ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:753` |
| 0.2% | 11.1ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:86` |
| 0.2% | 11.1ms | 0.2% | 9.5ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:108` |
| 0.2% | 11.0ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:615` |
| 0.2% | 11.0ms | 0.0% | 1.2ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:124` |
| 0.2% | 11.0ms | 0.0% | 0us | `rectangleInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:344` |
| 0.2% | 10.9ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:222` |
| 0.2% | 10.9ms | 0.2% | 10.9ms | `/acc(?:Title\|Descr)/i` | `[native code]` |
| 0.2% | 10.9ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:697` |
| 0.2% | 10.9ms | 0.2% | 10.9ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:251` |
| 0.2% | 10.8ms | 0.2% | 10.8ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:658` |
| 0.2% | 10.7ms | 0.0% | 1.0ms | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:138` |
| 0.2% | 10.7ms | 0.2% | 10.7ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:235` |
| 0.2% | 10.7ms | 0.0% | 0us | `hooks` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:508` |
| 0.2% | 10.7ms | 0.2% | 10.7ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1171` |
| 0.2% | 10.7ms | 0.2% | 10.7ms | `min` | `[native code]` |
| 0.2% | 10.7ms | 0.0% | 0us | `advance` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` |
| 0.2% | 10.7ms | 0.0% | 1.3ms | `reduce` | `[native code]` |
| 0.2% | 10.7ms | 0.0% | 0us | `zlibBufferSync` | `node:zlib:94` |
| 0.2% | 10.7ms | 0.0% | 0us | `processChunkSync` | `node:zlib:203` |
| 0.2% | 10.7ms | 0.2% | 10.7ms | `writeSync` | `[native code]` |
| 0.2% | 10.6ms | 0.1% | 5.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:594` |
| 0.2% | 10.5ms | 0.2% | 10.5ms | `Number` | `[native code]` |
| 0.2% | 10.5ms | 0.0% | 1.3ms | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:381` |
| 0.2% | 10.4ms | 0.0% | 0us | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:42` |
| 0.2% | 10.4ms | 0.1% | 8.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:646` |
| 0.2% | 10.3ms | 0.0% | 1.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:127` |
| 0.2% | 10.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:143` |
| 0.2% | 10.3ms | 0.0% | 0us | `assessRenderedLayoutHardViolations` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:211` |
| 0.2% | 10.3ms | 0.0% | 0us | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:677` |
| 0.2% | 10.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:652` |
| 0.2% | 10.1ms | 0.2% | 10.1ms | `includes` | `[native code]` |
| 0.2% | 10.0ms | 0.1% | 6.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` |
| 0.2% | 9.9ms | 0.1% | 6.9ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:274` |
| 0.2% | 9.9ms | 0.0% | 2.5ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:726` |
| 0.2% | 9.9ms | 0.0% | 0us | `serializeMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:155` |
| 0.2% | 9.9ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:102` |
| 0.2% | 9.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:7` |
| 0.2% | 9.9ms | 0.0% | 2.6ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:230` |
| 0.2% | 9.8ms | 0.0% | 4.2ms | `emitted` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:22` |
| 0.2% | 9.8ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:200` |
| 0.2% | 9.8ms | 0.0% | 3.3ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:371` |
| 0.2% | 9.7ms | 0.2% | 9.7ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.2% | 9.7ms | 0.2% | 9.7ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:86` |
| 0.2% | 9.6ms | 0.2% | 9.6ms | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` |
| 0.2% | 9.6ms | 0.0% | 0us | `paintAttribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:493` |
| 0.2% | 9.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:662` |
| 0.2% | 9.4ms | 0.0% | 3.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:737` |
| 0.2% | 9.4ms | 0.2% | 9.4ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:115` |
| 0.2% | 9.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:816` |
| 0.2% | 9.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` |
| 0.2% | 9.3ms | 0.2% | 9.3ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:304` |
| 0.2% | 9.2ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:245` |
| 0.2% | 9.2ms | 0.0% | 0us | `resolvedInlineColorAttribute` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:683` |
| 0.2% | 9.2ms | 0.0% | 4.0ms | `resolveCss` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:728` |
| 0.2% | 9.2ms | 0.0% | 2.5ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:471` |
| 0.2% | 9.2ms | 0.0% | 0us | `registerBuiltInStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:294` |
| 0.2% | 9.2ms | 0.2% | 9.2ms | `connectorSubpaths` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:363` |
| 0.2% | 9.1ms | 0.0% | 2.5ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:839` |
| 0.2% | 9.1ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:564` |
| 0.2% | 9.1ms | 0.0% | 2.0ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:357` |
| 0.2% | 9.0ms | 0.0% | 1.0ms | `performIteration` | `[native code]` |
| 0.2% | 9.0ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1783` |
| 0.2% | 9.0ms | 0.0% | 0us | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:41` |
| 0.2% | 9.0ms | 0.2% | 9.0ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:322` |
| 0.2% | 8.9ms | 0.0% | 2.3ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:334` |
| 0.2% | 8.8ms | 0.0% | 1.2ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:311` |
| 0.2% | 8.8ms | 0.0% | 1.2ms | `attr` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:53` |
| 0.2% | 8.8ms | 0.0% | 0us | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:134` |
| 0.2% | 8.7ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:592` |
| 0.2% | 8.7ms | 0.2% | 8.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:192` |
| 0.1% | 8.6ms | 0.1% | 8.6ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:733` |
| 0.1% | 8.6ms | 0.1% | 8.6ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:529` |
| 0.1% | 8.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts:76` |
| 0.1% | 8.6ms | 0.1% | 8.6ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` |
| 0.1% | 8.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:554` |
| 0.1% | 8.5ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:682` |
| 0.1% | 8.5ms | 0.0% | 1.8ms | `serializeMarkerResource` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:141` |
| 0.1% | 8.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/block/markers.ts:10` |
| 0.1% | 8.5ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:998` |
| 0.1% | 8.5ms | 0.1% | 8.5ms | `deferredTerminalProjectionInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.1% | 8.4ms | 0.1% | 8.4ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.1% | 8.4ms | 0.1% | 5.1ms | `skipSeparators` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:168` |
| 0.1% | 8.4ms | 0.0% | 0us | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:92` |
| 0.1% | 8.4ms | 0.0% | 0us | `finalizeClassSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:802` |
| 0.1% | 8.3ms | 0.0% | 0us | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:117` |
| 0.1% | 8.3ms | 0.1% | 8.3ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.1% | 8.3ms | 0.0% | 2.7ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:239` |
| 0.1% | 8.3ms | 0.0% | 0us | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:245` |
| 0.1% | 8.2ms | 0.1% | 8.2ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:524` |
| 0.1% | 8.2ms | 0.0% | 0us | `classStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:392` |
| 0.1% | 8.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:4` |
| 0.1% | 8.1ms | 0.0% | 0us | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:14` |
| 0.1% | 8.0ms | 0.0% | 0us | `registerBuiltInStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:292` |
| 0.1% | 8.0ms | 0.0% | 2.5ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:776` |
| 0.1% | 8.0ms | 0.1% | 8.0ms | `push` | `[native code]` |
| 0.1% | 8.0ms | 0.1% | 8.0ms | `arrayIteratorNextHelper` | `[native code]` |
| 0.1% | 7.9ms | 0.1% | 7.9ms | `String` | `[native code]` |
| 0.1% | 7.8ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1047` |
| 0.1% | 7.8ms | 0.1% | 7.8ms | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:38` |
| 0.1% | 7.8ms | 0.1% | 7.8ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:338` |
| 0.1% | 7.8ms | 0.0% | 3.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:705` |
| 0.1% | 7.8ms | 0.0% | 0us | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:62` |
| 0.1% | 7.6ms | 0.0% | 0us | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:400` |
| 0.1% | 7.6ms | 0.0% | 1.4ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:282` |
| 0.1% | 7.6ms | 0.0% | 972us | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:325` |
| 0.1% | 7.6ms | 0.0% | 0us | `markerTerminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:294` |
| 0.1% | 7.6ms | 0.0% | 1.0ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:229` |
| 0.1% | 7.5ms | 0.1% | 7.5ms | `RegExp` | `[native code]` |
| 0.1% | 7.5ms | 0.1% | 7.5ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:30` |
| 0.1% | 7.5ms | 0.1% | 6.3ms | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:311` |
| 0.1% | 7.5ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:391` |
| 0.1% | 7.5ms | 0.0% | 0us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:988` |
| 0.1% | 7.4ms | 0.1% | 7.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:550` |
| 0.1% | 7.4ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1583` |
| 0.1% | 7.4ms | 0.0% | 0us | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:537` |
| 0.1% | 7.4ms | 0.0% | 3.6ms | `sort` | `[native code]` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `compositeCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:277` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:488` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `xmlRange` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:48` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `registrationIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` |
| 0.1% | 7.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:548` |
| 0.1% | 7.3ms | 0.0% | 0us | `registerCanonicalStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:235` |
| 0.1% | 7.3ms | 0.0% | 3.4ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` |
| 0.1% | 7.3ms | 0.0% | 0us | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1501` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `markerPaintPieces` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:64` |
| 0.1% | 7.2ms | 0.1% | 7.2ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:485` |
| 0.1% | 7.2ms | 0.0% | 1.0ms | `SvgWriter` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:471` |
| 0.1% | 7.2ms | 0.0% | 1.8ms | `measureTextWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:206` |
| 0.1% | 7.2ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:423` |
| 0.1% | 7.2ms | 0.0% | 0us | `inspectSecurityTail` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:706` |
| 0.1% | 7.2ms | 0.1% | 7.2ms | `get` | `[native code]` |
| 0.1% | 7.2ms | 0.1% | 7.2ms | `defineProperty` | `[native code]` |
| 0.1% | 7.0ms | 0.0% | 0us | `assertInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:26` |
| 0.1% | 7.0ms | 0.1% | 5.7ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:130` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:760` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `appendPrivate` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:55` |
| 0.1% | 6.9ms | 0.0% | 1.4ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:83` |
| 0.1% | 6.9ms | 0.1% | 4.6ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:135` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `slice` | `[native code]` |
| 0.1% | 6.9ms | 0.0% | 2.5ms | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:106` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:537` |
| 0.1% | 6.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-format/src/defaultLocale.js:7` |
| 0.1% | 6.9ms | 0.0% | 0us | `defaultLocale` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-format/src/defaultLocale.js:14` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `locale_default` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-format/src/locale.js` |
| 0.1% | 6.8ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1122` |
| 0.1% | 6.8ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1728` |
| 0.1% | 6.8ms | 0.1% | 6.8ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:345` |
| 0.1% | 6.8ms | 0.0% | 2.2ms | `rectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:323` |
| 0.1% | 6.8ms | 0.1% | 6.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 6.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:8` |
| 0.1% | 6.7ms | 0.0% | 0us | `parseMarkedClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1307` |
| 0.1% | 6.7ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1088` |
| 0.1% | 6.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:719` |
| 0.1% | 6.7ms | 0.0% | 1.2ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1063` |
| 0.1% | 6.6ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:597` |
| 0.1% | 6.6ms | 0.0% | 3.9ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:274` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:689` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:150` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.1% | 6.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:693` |
| 0.1% | 6.6ms | 0.0% | 0us | `classTerminalLead` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:215` |
| 0.1% | 6.5ms | 0.1% | 6.5ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` |
| 0.1% | 6.5ms | 0.0% | 0us | `detectorClaims` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1596` |
| 0.1% | 6.4ms | 0.0% | 0us | `finalizeFlatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:657` |
| 0.1% | 6.4ms | 0.0% | 0us | `internal:streams/destroy` | `internal:streams/destroy:2` |
| 0.1% | 6.4ms | 0.0% | 0us | `internal:errors` | `internal:errors:2` |
| 0.1% | 6.3ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:316` |
| 0.1% | 6.3ms | 0.1% | 6.3ms | `entries` | `[native code]` |
| 0.1% | 6.3ms | 0.0% | 0us | `hooks` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:507` |
| 0.1% | 6.2ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1765` |
| 0.1% | 6.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:10` |
| 0.1% | 6.2ms | 0.0% | 1.1ms | `XmlLeafWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:298` |
| 0.1% | 6.2ms | 0.0% | 0us | `expandLocalReferences` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` |
| 0.1% | 6.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` |
| 0.1% | 6.2ms | 0.1% | 6.2ms | `proofRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:64` |
| 0.1% | 6.2ms | 0.0% | 0us | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:130` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `safeCssToken` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:66` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `result` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:377` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:87` |
| 0.1% | 6.1ms | 0.1% | 4.7ms | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:365` |
| 0.1% | 6.1ms | 0.0% | 1.4ms | `ownConnectorEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:190` |
| 0.1% | 6.1ms | 0.0% | 1.5ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:185` |
| 0.1% | 6.1ms | 0.0% | 1.2ms | `collectPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1371` |
| 0.1% | 6.1ms | 0.0% | 0us | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1390` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.1% | 6.0ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:738` |
| 0.1% | 6.0ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:88` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.1% | 6.0ms | 0.0% | 0us | `element` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:477` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `element` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:301` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:268` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `Buffer` | `[native code]` |
| 0.1% | 6.0ms | 0.0% | 0us | `(anonymous)` | `[native code]` |
| 0.1% | 5.9ms | 0.1% | 4.4ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1836` |
| 0.1% | 5.9ms | 0.0% | 0us | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:983` |
| 0.1% | 5.9ms | 0.1% | 5.9ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.1% | 5.9ms | 0.1% | 5.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:590` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:675` |
| 0.1% | 5.8ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:154` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:831` |
| 0.1% | 5.8ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:936` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:32` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1025` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `read` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:78` |
| 0.1% | 5.7ms | 0.0% | 2.7ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:350` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:583` |
| 0.1% | 5.7ms | 0.0% | 0us | `escapeDisplayAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:115` |
| 0.1% | 5.7ms | 0.0% | 0us | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:720` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `isFinite` | `[native code]` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:117` |
| 0.1% | 5.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-doc.js:4` |
| 0.1% | 5.6ms | 0.0% | 0us | `verifyNoExternalRefs` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:716` |
| 0.1% | 5.6ms | 0.1% | 5.6ms | `startTags` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.1% | 5.6ms | 0.0% | 0us | `inspectSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:688` |
| 0.1% | 5.6ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1049` |
| 0.1% | 5.6ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:531` |
| 0.1% | 5.6ms | 0.1% | 5.6ms | `segmentEntersMeasuredBox` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.1% | 5.6ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:773` |
| 0.1% | 5.5ms | 0.0% | 3.7ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:337` |
| 0.1% | 5.5ms | 0.0% | 2.5ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:367` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:667` |
| 0.1% | 5.4ms | 0.0% | 2.9ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:715` |
| 0.1% | 5.4ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1008` |
| 0.1% | 5.4ms | 0.0% | 0us | `drawn` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:421` |
| 0.1% | 5.4ms | 0.0% | 2.1ms | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:164` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `unclipped` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1034` |
| 0.1% | 5.4ms | 0.0% | 0us | `measureText` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:188` |
| 0.1% | 5.4ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:582` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `separatedSharpSupports` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:62` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `classCommentStart` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:356` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/` | `[native code]` |
| 0.1% | 5.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:11` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.1% | 5.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:974` |
| 0.1% | 5.2ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:2` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `xmlHasColon` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `rectangleInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:339` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:520` |
| 0.1% | 5.2ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:652` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:33` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:498` |
| 0.1% | 5.1ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:802` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `xmlList` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:40` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `classRelationshipTerminalClearance` | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts` |
| 0.1% | 5.1ms | 0.0% | 0us | `geometryElements` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:77` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `pointList` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.1% | 5.1ms | 0.0% | 0us | `transformSvgCssValues` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:270` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `canonicalOpeningTag` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:437` |
| 0.1% | 5.1ms | 0.0% | 0us | `canonicalizeSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:485` |
| 0.1% | 5.1ms | 0.0% | 0us | `attachSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:495` |
| 0.1% | 5.1ms | 0.0% | 0us | `documentOpen` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:135` |
| 0.1% | 5.1ms | 0.0% | 1.6ms | `pose` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:317` |
| 0.1% | 5.1ms | 0.0% | 0us | `descriptorOwnsDetectionLine` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2072` |
| 0.1% | 5.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:762` |
| 0.1% | 5.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:874` |
| 0.1% | 5.0ms | 0.0% | 1.8ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:718` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `node:fs` | `node:fs:2` |
| 0.1% | 5.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1739` |
| 0.1% | 5.0ms | 0.0% | 0us | `normalizeMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:665` |
| 0.1% | 5.0ms | 0.0% | 0us | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:34` |
| 0.1% | 5.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:35` |
| 0.1% | 4.9ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:688` |
| 0.1% | 4.9ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:133` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `orthogonal` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:461` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `parseFloat` | `[native code]` |
| 0.1% | 4.9ms | 0.0% | 0us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:275` |
| 0.1% | 4.9ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:739` |
| 0.1% | 4.9ms | 0.0% | 3.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:560` |
| 0.1% | 4.9ms | 0.0% | 0us | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:453` |
| 0.1% | 4.9ms | 0.0% | 2.3ms | `validateRoleStyles` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:340` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` |
| 0.1% | 4.8ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:152` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `localPaintResourceId` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:373` |
| 0.1% | 4.8ms | 0.0% | 3.7ms | `classNativeMarkerMinimums` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:194` |
| 0.1% | 4.8ms | 0.0% | 0us | `classifyClassStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:449` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `assign` | `[native code]` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:121` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:309` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:797` |
| 0.1% | 4.7ms | 0.0% | 1.0ms | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:649` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.1% | 4.7ms | 0.0% | 3.0ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:318` |
| 0.1% | 4.7ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:462` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:177` |
| 0.1% | 4.7ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:58` |
| 0.1% | 4.7ms | 0.0% | 0us | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:353` |
| 0.1% | 4.7ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1856` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:725` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.1% | 4.6ms | 0.0% | 0us | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:465` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:367` |
| 0.1% | 4.6ms | 0.0% | 0us | `renderDivider` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:408` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `isRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.1% | 4.6ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:839` |
| 0.1% | 4.6ms | 0.0% | 2.1ms | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:66` |
| 0.1% | 4.5ms | 0.0% | 2.8ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:16` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `validateRole` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `join` | `[native code]` |
| 0.1% | 4.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:6` |
| 0.1% | 4.4ms | 0.0% | 0us | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1451` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 4.4ms | 0.0% | 0us | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:96` |
| 0.1% | 4.4ms | 0.0% | 1.6ms | `writtenDecimalParts` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:31` |
| 0.1% | 4.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:186` |
| 0.1% | 4.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:185` |
| 0.1% | 4.4ms | 0.0% | 0us | `createExtensionIdentity` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:229` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `/<\s*text/i` | `[native code]` |
| 0.1% | 4.4ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:196` |
| 0.1% | 4.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:16` |
| 0.1% | 4.3ms | 0.0% | 1.3ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:119` |
| 0.0% | 4.3ms | 0.0% | 0us | `node:fs` | `node:fs:8` |
| 0.0% | 4.3ms | 0.0% | 0us | `classifyClassStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:473` |
| 0.0% | 4.3ms | 0.0% | 4.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:520` |
| 0.0% | 4.3ms | 0.0% | 4.3ms | `positionedPaintCertification` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` |
| 0.0% | 4.3ms | 0.0% | 4.3ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:434` |
| 0.0% | 4.3ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:158` |
| 0.0% | 4.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:5` |
| 0.0% | 4.3ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:110` |
| 0.0% | 4.2ms | 0.0% | 0us | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:519` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:642` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:389` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 4.2ms | 0.0% | 3.1ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:87` |
| 0.0% | 4.2ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:181` |
| 0.0% | 4.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1024` |
| 0.0% | 4.2ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:837` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `range` | `/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts:17` |
| 0.0% | 4.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/xychart/config-diagnostics.ts:9` |
| 0.0% | 4.2ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:698` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:390` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 4.2ms | 0.0% | 0us | `classifyClassStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:460` |
| 0.0% | 4.2ms | 0.0% | 4.2ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:511` |
| 0.0% | 4.1ms | 0.0% | 2.3ms | `relationAccessibility` | `/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` |
| 0.0% | 4.1ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:315` |
| 0.0% | 4.1ms | 0.0% | 0us | `ensureContrast` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:102` |
| 0.0% | 4.1ms | 0.0% | 4.1ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:501` |
| 0.0% | 4.1ms | 0.0% | 4.1ms | `writtenDecimalParts` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:30` |
| 0.0% | 4.0ms | 0.0% | 3.0ms | `classCommentStart` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:369` |
| 0.0% | 4.0ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:117` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `readXmlReferenceEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:219` |
| 0.0% | 4.0ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:616` |
| 0.0% | 4.0ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:754` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:301` |
| 0.0% | 4.0ms | 0.0% | 1.3ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:581` |
| 0.0% | 4.0ms | 0.0% | 1.3ms | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1097` |
| 0.0% | 4.0ms | 0.0% | 0us | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:306` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `xmlHasColon` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:89` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:20` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `markerTerminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:296` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:364` |
| 0.0% | 3.9ms | 0.0% | 0us | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:454` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:286` |
| 0.0% | 3.9ms | 0.0% | 1.2ms | `from` | `[native code]` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `terminalEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.0% | 3.9ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:98` |
| 0.0% | 3.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:206` |
| 0.0% | 3.9ms | 0.0% | 0us | `createCliRenderOutputDescriptors` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:201` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 3.9ms | 0.0% | 0us | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:515` |
| 0.0% | 3.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:153` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `outputDescriptorsById` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `assertInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:12` |
| 0.0% | 3.9ms | 0.0% | 3.9ms | `parseEncodeTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:45` |
| 0.0% | 3.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/encode-html.js:10` |
| 0.0% | 3.9ms | 0.0% | 0us | `renderDisplayRuns` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:152` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:67` |
| 0.0% | 3.8ms | 0.0% | 0us | `toMermaidLines` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:100` |
| 0.0% | 3.8ms | 0.0% | 0us | `preprocessMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:869` |
| 0.0% | 3.8ms | 0.0% | 0us | `extractInitDirectives` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:1117` |
| 0.0% | 3.8ms | 0.0% | 0us | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:512` |
| 0.0% | 3.8ms | 0.0% | 2.0ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:351` |
| 0.0% | 3.8ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1457` |
| 0.0% | 3.8ms | 0.0% | 1.8ms | `assertMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:58` |
| 0.0% | 3.8ms | 0.0% | 0us | `admitRenderContractDigestInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1150` |
| 0.0% | 3.8ms | 0.0% | 0us | `deferredRequestReceiptDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1108` |
| 0.0% | 3.8ms | 0.0% | 1.3ms | `boundedImmutableJsonSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1242` |
| 0.0% | 3.8ms | 0.0% | 0us | `deferredRenderContractDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1127` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:133` |
| 0.0% | 3.8ms | 0.0% | 0us | `projectClassRectangleContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:163` |
| 0.0% | 3.8ms | 0.0% | 1.0ms | `emittedPoint` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:24` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `open` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1429` |
| 0.0% | 3.7ms | 0.0% | 0us | `serialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1494` |
| 0.0% | 3.7ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:247` |
| 0.0% | 3.7ms | 0.0% | 2.5ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:299` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 3.7ms | 0.0% | 0us | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:694` |
| 0.0% | 3.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:665` |
| 0.0% | 3.7ms | 0.0% | 0us | `renderRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:552` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `classRelationshipLineStyle` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1610` |
| 0.0% | 3.7ms | 0.0% | 0us | `detectInstalledFamilyDescriptorFromFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts:60` |
| 0.0% | 3.7ms | 0.0% | 0us | `detectRegisteredFamilyDescriptorFromFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2083` |
| 0.0% | 3.7ms | 0.0% | 0us | `classifyMermaidFamilyDescriptorFromFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/family-detection.ts:39` |
| 0.0% | 3.7ms | 0.0% | 0us | `connectorMarkerPaintRegions` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:316` |
| 0.0% | 3.7ms | 0.0% | 2.3ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:92` |
| 0.0% | 3.6ms | 0.0% | 0us | `connectorGeometryEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:181` |
| 0.0% | 3.6ms | 0.0% | 1.0ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:641` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `assertFinalBoundaryContacts` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.0% | 3.6ms | 0.0% | 0us | `snapshotScenePrimitiveCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1548` |
| 0.0% | 3.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:4` |
| 0.0% | 3.6ms | 0.0% | 0us | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:109` |
| 0.0% | 3.6ms | 0.0% | 0us | `documentOpen` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:129` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `crossSize` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:33` |
| 0.0% | 3.6ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1709` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:142` |
| 0.0% | 3.6ms | 0.0% | 0us | `parseClassInteractionWithAuthored` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:923` |
| 0.0% | 3.5ms | 0.0% | 0us | `renderedSvgDigest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:61` |
| 0.0% | 3.5ms | 0.0% | 0us | `cssPaintDefinitions` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:611` |
| 0.0% | 3.5ms | 0.0% | 0us | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:702` |
| 0.0% | 3.5ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:605` |
| 0.0% | 3.5ms | 0.0% | 2.3ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:379` |
| 0.0% | 3.5ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:458` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:759` |
| 0.0% | 3.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:272` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1061` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` |
| 0.0% | 3.4ms | 0.0% | 1.4ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:808` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `repairClassAnnotationSeats` | `/tmp/pr449-main-integration-20261029-762/src/class/annotation-seats.ts` |
| 0.0% | 3.4ms | 0.0% | 0us | `finalizeClassSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:815` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `records` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 3.4ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1613` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `createValidationState` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 3.4ms | 0.0% | 0us | `parseClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1292` |
| 0.0% | 3.4ms | 0.0% | 2.1ms | `parseMarkerlessClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1415` |
| 0.0% | 3.4ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1502` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `assertKnownConnectorFields` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 3.4ms | 0.0% | 2.1ms | `ActualTextPaintWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:393` |
| 0.0% | 3.3ms | 0.0% | 0us | `terminalEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:70` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `writtenPoint` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:88` |
| 0.0% | 3.3ms | 0.0% | 0us | `ownConnectorEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:192` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:396` |
| 0.0% | 3.3ms | 0.0% | 0us | `compositeCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:275` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:633` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `/\s/` | `[native code]` |
| 0.0% | 3.2ms | 0.0% | 0us | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:212` |
| 0.0% | 3.2ms | 0.0% | 0us | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:701` |
| 0.0% | 3.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:4` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:51` |
| 0.0% | 3.2ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:150` |
| 0.0% | 3.2ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:138` |
| 0.0% | 3.2ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:276` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `append` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:239` |
| 0.0% | 3.2ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:642` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:448` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `sourceAdapter` | `/tmp/pr449-main-integration-20261029-762/src/agent/stable-family-source-hooks.ts` |
| 0.0% | 3.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/stable-family-source-hooks.ts:446` |
| 0.0% | 3.2ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:203` |
| 0.0% | 3.2ms | 0.0% | 0us | `unsafeCssReferences` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:621` |
| 0.0% | 3.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:13` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `renderRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:560` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1208` |
| 0.0% | 3.2ms | 0.0% | 0us | `projectClassRectangleContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:164` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `writtenDecimalParts` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:32` |
| 0.0% | 3.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:655` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:585` |
| 0.0% | 3.1ms | 0.0% | 1.7ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:685` |
| 0.0% | 3.1ms | 0.0% | 1.2ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:183` |
| 0.0% | 3.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:104` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `clip` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:84` |
| 0.0% | 3.1ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:317` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts` |
| 0.0% | 3.1ms | 0.0% | 0us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1190` |
| 0.0% | 3.1ms | 0.0% | 0us | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:365` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:355` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `pose` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:336` |
| 0.0% | 3.1ms | 0.0% | 1.7ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:275` |
| 0.0% | 3.1ms | 0.0% | 0us | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:734` |
| 0.0% | 3.1ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:266` |
| 0.0% | 3.1ms | 0.0% | 0us | `layoutResult` | `/tmp/pr449-main-integration-20261029-762/src/browser-lazy/family.ts:37` |
| 0.0% | 3.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:142` |
| 0.0% | 3.1ms | 0.0% | 1.9ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:436` |
| 0.0% | 3.1ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1546` |
| 0.0% | 3.1ms | 0.0% | 1.3ms | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:112` |
| 0.0% | 3.0ms | 0.0% | 0us | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:756` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `classTextBlock` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 3.0ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1495` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:474` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `label` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1491` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `toHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:42` |
| 0.0% | 3.0ms | 0.0% | 0us | `authoredClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:107` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `splitAuthoredClassLine` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:99` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `circleMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts` |
| 0.0% | 3.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:114` |
| 0.0% | 3.0ms | 0.0% | 0us | `flowchartMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:81` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:401` |
| 0.0% | 3.0ms | 0.0% | 0us | `parseExtensionId` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:206` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 3.0ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:259` |
| 0.0% | 3.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:3` |
| 0.0% | 3.0ms | 0.0% | 0us | `decodedSvgAttributeValue` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:179` |
| 0.0% | 3.0ms | 0.0% | 0us | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:379` |
| 0.0% | 3.0ms | 0.0% | 0us | `createNativePaintEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:55` |
| 0.0% | 3.0ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:134` |
| 0.0% | 3.0ms | 0.0% | 0us | `unsafeCssReferences` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:614` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:368` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:596` |
| 0.0% | 2.9ms | 0.0% | 0us | `replaceSvgRootStartTag` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:281` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `pose` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:333` |
| 0.0% | 2.9ms | 0.0% | 0us | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:712` |
| 0.0% | 2.9ms | 0.0% | 0us | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:691` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `prepared` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 2.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:731` |
| 0.0% | 2.9ms | 0.0% | 0us | `classRelationshipPaintBoxes` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:343` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:134` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:93` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `/<!--[\s\S]*?-->/g` | `[native code]` |
| 0.0% | 2.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:738` |
| 0.0% | 2.9ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:676` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `skip` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 2.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:7` |
| 0.0% | 2.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/resolve-block-map.js:6` |
| 0.0% | 2.9ms | 0.0% | 0us | `unsafeCssReferences` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:617` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1084` |
| 0.0% | 2.9ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:109` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:738` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` |
| 0.0% | 2.9ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:829` |
| 0.0% | 2.9ms | 0.0% | 0us | `connectorInlineLabelSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:781` |
| 0.0% | 2.8ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1860` |
| 0.0% | 2.8ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:75` |
| 0.0% | 2.8ms | 0.0% | 1.5ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:729` |
| 0.0% | 2.8ms | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1656` |
| 0.0% | 2.8ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1262` |
| 0.0% | 2.8ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:101` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `typedIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:74` |
| 0.0% | 2.8ms | 0.0% | 0us | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:175` |
| 0.0% | 2.8ms | 0.0% | 0us | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:359` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `isHexColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:143` |
| 0.0% | 2.8ms | 0.0% | 0us | `resolvedColorValue` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:598` |
| 0.0% | 2.8ms | 0.0% | 0us | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:148` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:164` |
| 0.0% | 2.8ms | 0.0% | 0us | `contrastRatio` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:84` |
| 0.0% | 2.8ms | 0.0% | 0us | `relativeLuminance` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:78` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `toHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 2.7ms | 0.0% | 0us | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:711` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:324` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `BigInt` | `[native code]` |
| 0.0% | 2.7ms | 0.0% | 1.5ms | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:266` |
| 0.0% | 2.7ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:92` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:168` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:406` |
| 0.0% | 2.7ms | 0.0% | 0us | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1104` |
| 0.0% | 2.7ms | 0.0% | 0us | `getCharWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:91` |
| 0.0% | 2.7ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:265` |
| 0.0% | 2.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:7` |
| 0.0% | 2.7ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:114` |
| 0.0% | 2.7ms | 0.0% | 0us | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:20` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:435` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `inRanges` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:114` |
| 0.0% | 2.7ms | 0.0% | 1.4ms | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:369` |
| 0.0% | 2.7ms | 0.0% | 0us | `authoredClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:109` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `normalizeCssObfuscation` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:37` |
| 0.0% | 2.6ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:634` |
| 0.0% | 2.6ms | 0.0% | 0us | `sharedRenderOptionsJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:485` |
| 0.0% | 2.6ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1745` |
| 0.0% | 2.6ms | 0.0% | 0us | `deferredTerminalProjectionInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:66` |
| 0.0% | 2.6ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:156` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `flatIntoArray` | `[native code]` |
| 0.0% | 2.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/c4/config.ts:68` |
| 0.0% | 2.6ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:651` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `Map` | `[native code]` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `sceneNodeWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `indexOf` | `[native code]` |
| 0.0% | 2.6ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:736` |
| 0.0% | 2.6ms | 0.0% | 1.2ms | `parseExtensionId` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:202` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:87` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:109` |
| 0.0% | 2.6ms | 0.0% | 1.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:262` |
| 0.0% | 2.6ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:805` |
| 0.0% | 2.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:681` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `validateRoleStyleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` |
| 0.0% | 2.6ms | 0.0% | 1.3ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:173` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/shared/diagram-limits.ts:16` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:319` |
| 0.0% | 2.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:14` |
| 0.0% | 2.5ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:680` |
| 0.0% | 2.5ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:130` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `assertRenderableMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 2.5ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:565` |
| 0.0% | 2.5ms | 0.0% | 0us | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` |
| 0.0% | 2.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` |
| 0.0% | 2.5ms | 0.0% | 0us | `gzipSync` | `node:zlib:360` |
| 0.0% | 2.5ms | 0.0% | 0us | `Gzip` | `node:zlib:328` |
| 0.0% | 2.5ms | 0.0% | 0us | `scanAccessibilityDirectives` | `/tmp/pr449-main-integration-20261029-762/src/shared/accessibility-directives.ts:125` |
| 0.0% | 2.5ms | 0.0% | 0us | `assertMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:57` |
| 0.0% | 2.5ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:722` |
| 0.0% | 2.5ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:490` |
| 0.0% | 2.5ms | 0.0% | 1.4ms | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:81` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `nativeTextPaintWriteOf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:68` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1033` |
| 0.0% | 2.5ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:716` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `continuesClassText` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:553` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` |
| 0.0% | 2.5ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:322` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `oneOf` | `/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` |
| 0.0% | 2.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/pie/config-diagnostics.ts:5` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:177` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `work` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.0% | 2.4ms | 0.0% | 0us | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:989` |
| 0.0% | 2.4ms | 0.0% | 0us | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:975` |
| 0.0% | 2.4ms | 0.0% | 0us | `positionedPaintCertification` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:158` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `retainNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/experimental/position-cache.ts` |
| 0.0% | 2.4ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:102` |
| 0.0% | 2.4ms | 0.0% | 0us | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:676` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 2.4ms | 0.0% | 1.2ms | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:197` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `validatePoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts:3` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `Segmenter` | `[native code]` |
| 0.0% | 2.4ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:603` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:87` |
| 0.0% | 2.4ms | 0.0% | 0us | `resolvedColorValue` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:599` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `/^(?:0\|[1-9]\d*)$/` | `[native code]` |
| 0.0% | 2.4ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:154` |
| 0.0% | 2.4ms | 0.0% | 0us | `rectangleInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:341` |
| 0.0% | 2.4ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:144` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:963` |
| 0.0% | 2.4ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1821` |
| 0.0% | 2.4ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1485` |
| 0.0% | 2.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/default-backend.ts:5` |
| 0.0% | 2.4ms | 0.0% | 1.1ms | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:57` |
| 0.0% | 2.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:56` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:612` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `assertMarkerPaint` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:27` |
| 0.0% | 2.4ms | 0.0% | 0us | `boundedImmutableJsonSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1243` |
| 0.0% | 2.4ms | 0.0% | 0us | `admitRenderOptionsInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1307` |
| 0.0% | 2.3ms | 0.0% | 0us | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:318` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `transferSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `connectorEndpointAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:444` |
| 0.0% | 2.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/gantt/dependency-paint.ts:16` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `dependencyArrowMarker` | `/tmp/pr449-main-integration-20261029-762/src/gantt/dependency-paint.ts:5` |
| 0.0% | 2.3ms | 0.0% | 1.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:712` |
| 0.0% | 2.3ms | 0.0% | 1.1ms | `rejectUnknownKeys` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:152` |
| 0.0% | 2.3ms | 0.0% | 0us | `expandLocalReferences` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:204` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `escapeXml` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:97` |
| 0.0% | 2.3ms | 0.0% | 1.3ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:511` |
| 0.0% | 2.3ms | 0.0% | 0us | `separatedSharpSupportBounds` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:71` |
| 0.0% | 2.3ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:185` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:976` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 2.3ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1788` |
| 0.0% | 2.3ms | 0.0% | 1.1ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:440` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `max` | `[native code]` |
| 0.0% | 2.3ms | 0.0% | 0us | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:275` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:183` |
| 0.0% | 2.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:709` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:536` |
| 0.0% | 2.3ms | 0.0% | 0us | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:218` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 2.2ms | 0.0% | 1.1ms | `writeFileSync` | `[native code]` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `classNativeMarkerMinimums` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:197` |
| 0.0% | 2.2ms | 0.0% | 0us | `extractClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:428` |
| 0.0% | 2.2ms | 0.0% | 0us | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:316` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `Set` | `[native code]` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:403` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `/var\(--([\w-]+)\)/g` | `[native code]` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `attr` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:552` |
| 0.0% | 2.2ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:189` |
| 0.0% | 2.2ms | 0.0% | 0us | `setConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:59` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `install` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:41` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `validatePoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:462` |
| 0.0% | 2.2ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1035` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` |
| 0.0% | 2.2ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:686` |
| 0.0% | 2.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:682` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `tipAnchoredArrow` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 2.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:4` |
| 0.0% | 2.1ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:703` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `supportedRelationEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1515` |
| 0.0% | 2.1ms | 0.0% | 0us | `parseClassRelationEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1396` |
| 0.0% | 2.1ms | 0.0% | 0us | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:468` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:796` |
| 0.0% | 2.1ms | 0.0% | 0us | `zlibBufferSync` | `node:zlib:88` |
| 0.0% | 2.1ms | 0.0% | 0us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1199` |
| 0.0% | 2.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:5` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:910` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `imul` | `[native code]` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `(anonymous)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:11` |
| 0.0% | 2.1ms | 0.0% | 0us | `measureRenderStage` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:34` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `inspectOwnedSvgOnce` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts` |
| 0.0% | 2.1ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:50` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `ownConnectorEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:191` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 2.1ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:153` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `measureTextWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:146` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `assertKnownConnectorFields` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:160` |
| 0.0% | 2.1ms | 0.0% | 1.0ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:151` |
| 0.0% | 2.1ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:711` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `multiplySceneOpacity` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 2.1ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:80` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:541` |
| 0.0% | 2.1ms | 0.0% | 0us | `retainTextPaintPresence` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:81` |
| 0.0% | 2.0ms | 0.0% | 0us | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:402` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:206` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:169` |
| 0.0% | 2.0ms | 0.0% | 0us | `parseClassRelationEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1400` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `classRelationText` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1330` |
| 0.0% | 2.0ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:583` |
| 0.0% | 2.0ms | 0.0% | 0us | `element` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:476` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `raw` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 2.0ms | 0.0% | 0us | `(unknown)` | `[native code]` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `/--([\w-]+)\s*:\s*([^;{}]+)/g` | `[native code]` |
| 0.0% | 2.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:709` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:714` |
| 0.0% | 2.0ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:397` |
| 0.0% | 2.0ms | 0.0% | 0us | `makeSafe` | `internal:primordials:53` |
| 0.0% | 2.0ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:76` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `copyProps` | `internal:primordials` |
| 0.0% | 1.9ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:290` |
| 0.0% | 1.9ms | 0.0% | 0us | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1374` |
| 0.0% | 1.9ms | 0.0% | 0us | `createExtensionIdentity` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:246` |
| 0.0% | 1.9ms | 0.0% | 0us | `evaluateExtensionCompatibility` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:144` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:441` |
| 0.0% | 1.9ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1083` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `lazyGraphicalArtifact` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:35` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:109` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:360` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `renderDivider` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:409` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1145` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js` |
| 0.0% | 1.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:3` |
| 0.0% | 1.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:5` |
| 0.0% | 1.9ms | 0.0% | 0us | `executionCapabilityDecision` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1453` |
| 0.0% | 1.9ms | 0.0% | 0us | `negotiateCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts:160` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:844` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1102` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `(module)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:6` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1808` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1029` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:40` |
| 0.0% | 1.8ms | 0.0% | 0us | `registerCanonicalStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:236` |
| 0.0% | 1.8ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:560` |
| 0.0% | 1.8ms | 0.0% | 0us | `registerExtension` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:290` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:348` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `normalizeCssObfuscation` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:27` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `world` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:23` |
| 0.0% | 1.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:116` |
| 0.0% | 1.8ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:640` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `terminalMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:55` |
| 0.0% | 1.8ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1481` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `viewportBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` |
| 0.0% | 1.8ms | 0.0% | 0us | `sceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` |
| 0.0% | 1.8ms | 0.0% | 0us | `connectorMarkerPaintRegions` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:352` |
| 0.0% | 1.8ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:196` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `serializeMarkerResource` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:123` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:24` |
| 0.0% | 1.7ms | 0.0% | 0us | `projectClassPositioned` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:23` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:358` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.7ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:143` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `isPlainRecord` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts` |
| 0.0% | 1.7ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:77` |
| 0.0% | 1.7ms | 0.0% | 0us | `assertFamilyGeometryOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:850` |
| 0.0% | 1.7ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:160` |
| 0.0% | 1.7ms | 0.0% | 0us | `applyFamilyRequestNormalization` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1075` |
| 0.0% | 1.7ms | 0.0% | 0us | `finalizeFlatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:654` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `compactProvedPath` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-portal-channel.ts:428` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validatePoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:455` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1088` |
| 0.0% | 1.7ms | 0.0% | 0us | `placeClassCardinalityLabels` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:549` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:549` |
| 0.0% | 1.7ms | 0.0% | 0us | `extractClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:479` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:427` |
| 0.0% | 1.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:581` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:204` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:262` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `optional` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:49` |
| 0.0% | 1.7ms | 0.0% | 0us | `terminalMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:58` |
| 0.0% | 1.7ms | 0.0% | 0us | `assertKnownConnectorFields` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:161` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:826` |
| 0.0% | 1.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:14` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:235` |
| 0.0% | 1.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:558` |
| 0.0% | 1.7ms | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:527` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:349` |
| 0.0% | 1.7ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:883` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `authoredClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 1.7ms | 0.0% | 0us | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:237` |
| 0.0% | 1.7ms | 0.0% | 0us | `finiteRect` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:159` |
| 0.0% | 1.7ms | 0.0% | 0us | `checkRect` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:229` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 1.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:115` |
| 0.0% | 1.7ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1051` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:639` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:284` |
| 0.0% | 1.7ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:284` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `addClassSvgNumbers` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:66` |
| 0.0% | 1.6ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1853` |
| 0.0% | 1.6ms | 0.0% | 0us | `emitGraphLayoutDecision` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:42` |
| 0.0% | 1.6ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:192` |
| 0.0% | 1.6ms | 0.0% | 0us | `runMeasuredGraphBackend` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:89` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `retainRequestGraphLayoutDecision` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts` |
| 0.0% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:125` |
| 0.0% | 1.6ms | 0.0% | 0us | `set` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:33` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `delete` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:161` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `sharpContactsClear` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:369` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:262` |
| 0.0% | 1.6ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:153` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:836` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:96` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:176` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `assertMarkerPaint` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:28` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `legibleInk` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:137` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `parseMarkedClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1320` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `orthogonal` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `schemaMatchesRuntimeKind` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:41` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:146` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:387` |
| 0.0% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:43` |
| 0.0% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:270` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `read` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:76` |
| 0.0% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:17` |
| 0.0% | 1.6ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:555` |
| 0.0% | 1.6ms | 0.0% | 0us | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:82` |
| 0.0% | 1.6ms | 0.0% | 0us | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:176` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `transformPoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:19` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:127` |
| 0.0% | 1.6ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1826` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `expectedCapabilityState` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1645` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:272` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1094` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:26` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `validateJsonConfigAdmission` | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts:216` |
| 0.0% | 1.6ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1715` |
| 0.0% | 1.6ms | 0.0% | 0us | `renderOptionsAdmissionMessages` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:403` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1021` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:581` |
| 0.0% | 1.5ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1585` |
| 0.0% | 1.5ms | 0.0% | 0us | `snapshotFamilyConfig` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1531` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:625` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1498` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `geometryElements` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:191` |
| 0.0% | 1.5ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1766` |
| 0.0% | 1.5ms | 0.0% | 0us | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:539` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:725` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:988` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:283` |
| 0.0% | 1.5ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:674` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:499` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:661` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `ownerSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:190` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `work` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `safeCssPaint` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:134` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `now` | `[native code]` |
| 0.0% | 1.5ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1096` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `readXmlReferenceEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `intersects` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:214` |
| 0.0% | 1.5ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:500` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `selfContact` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1211` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `ActualTextPaintWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:116` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `createEmissionContext` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:40` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `writtenSegmentEntersBox` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:96` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `connectorMarkerPaintRegions` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:319` |
| 0.0% | 1.5ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:680` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` |
| 0.0% | 1.5ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:194` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `skip` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:62` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:546` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:62` |
| 0.0% | 1.5ms | 0.0% | 0us | `addClassSvgNumbers` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:60` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:511` |
| 0.0% | 1.5ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:336` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:235` |
| 0.0% | 1.5ms | 0.0% | 0us | `retainClassRectangleContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:136` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `classRelationshipEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:771` |
| 0.0% | 1.5ms | 0.0% | 0us | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:648` |
| 0.0% | 1.5ms | 0.0% | 0us | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:196` |
| 0.0% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:9` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `get conformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:496` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `ownConnectorEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:96` |
| 0.0% | 1.4ms | 0.0% | 0us | `expandLocalReferences` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:203` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `createEmissionContext` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:22` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:713` |
| 0.0% | 1.4ms | 0.0% | 0us | `typographyAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:698` |
| 0.0% | 1.4ms | 0.0% | 0us | `structurallyEqual` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1274` |
| 0.0% | 1.4ms | 0.0% | 0us | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1359` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:86` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:9` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1802` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `createNativeSceneValidator` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` |
| 0.0% | 1.4ms | 0.0% | 0us | `immutableSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1221` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2361` |
| 0.0% | 1.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:255` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `roleStyleJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:494` |
| 0.0% | 1.4ms | 0.0% | 0us | `styleSpecJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:609` |
| 0.0% | 1.4ms | 0.0% | 0us | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:538` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `seatFinalMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `inspectPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:61` |
| 0.0% | 1.4ms | 0.0% | 0us | `createOwnedNativePaintRecorder` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:203` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scanSvgStartTagsFresh` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `createPaintRecorder` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:243` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:510` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `/[^\x00-\x7f]/` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:979` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `svgOpenTag` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `lowerClassDrawing` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:96` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:598` |
| 0.0% | 1.4ms | 0.0% | 0us | `classRelationshipTerminalClearance` | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:59` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `document/identity/serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:512` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:16` |
| 0.0% | 1.4ms | 0.0% | 0us | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:517` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:116` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:422` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:136` |
| 0.0% | 1.4ms | 0.0% | 0us | `absentPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:102` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringifyPair.js:5` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringify.js:6` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:584` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:533` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `projectClassRectangleContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:194` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:236` |
| 0.0% | 1.4ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1052` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:292` |
| 0.0% | 1.4ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1099` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `crossSize` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `terminalMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:56` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:217` |
| 0.0% | 1.4ms | 0.0% | 0us | `assertFinalBoundaryContacts` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:396` |
| 0.0% | 1.4ms | 0.0% | 0us | `parseInlineFormatting` | `/tmp/pr449-main-integration-20261029-762/src/shared/inline-format.ts:45` |
| 0.0% | 1.4ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:174` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `read` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:64` |
| 0.0% | 1.4ms | 0.0% | 0us | `nativePaintSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:228` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:719` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` |
| 0.0% | 1.3ms | 0.0% | 0us | `isWideRange` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:126` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1031` |
| 0.0% | 1.3ms | 0.0% | 0us | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:64` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:3` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:5` |
| 0.0% | 1.3ms | 0.0% | 0us | `snapshotScenePrimitiveCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1541` |
| 0.0% | 1.3ms | 0.0% | 0us | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:153` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `seatFinalMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:475` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:18` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector/stroke/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `copyDeferredTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:81` |
| 0.0% | 1.3ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:181` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:445` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `writeStructuredSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:594` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `numberIsValid` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:280` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:810` |
| 0.0% | 1.3ms | 0.0% | 0us | `assertFinalBoundaryContacts` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:359` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:366` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:111` |
| 0.0% | 1.3ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:214` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateAggregateReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1520` |
| 0.0% | 1.3ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1502` |
| 0.0% | 1.3ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1814` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-scalar.js:6` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:6` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:417` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `intersects` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `renderRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:589` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `decodeWithTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:456` |
| 0.0% | 1.3ms | 0.0% | 0us | `Zlib` | `node:zlib:297` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `NativeZlib` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:263` |
| 0.0% | 1.3ms | 0.0% | 0us | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:24` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `hasOwned` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:686` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:9` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/resolve-flow-collection.js:7` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `isWideRange` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:128` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `assertInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:32` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:696` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:276` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:405` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `declareFamilyScenePrimitiveEvidence` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `connectorGeometryEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:180` |
| 0.0% | 1.3ms | 0.0% | 0us | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1384` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `luminanceContrastRatio` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:73` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:233` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:552` |
| 0.0% | 1.3ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:157` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1756` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:15` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:667` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1755` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:530` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1742` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1742` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:55` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `trim` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:357` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:432` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `extractClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:457` |
| 0.0% | 1.3ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:214` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:258` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `measureClassCards` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:185` |
| 0.0% | 1.3ms | 0.0% | 0us | `isZeroWidth` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:137` |
| 0.0% | 1.3ms | 0.0% | 0us | `isCombiningMark` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:49` |
| 0.0% | 1.3ms | 0.0% | 0us | `getCharWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:88` |
| 0.0% | 1.3ms | 0.0% | 0us | `receiptOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:758` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2083` |
| 0.0% | 1.3ms | 0.0% | 0us | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1091` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1131` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:330` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pose` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:329` |
| 0.0% | 1.3ms | 0.0% | 0us | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:201` |
| 0.0% | 1.3ms | 0.0% | 0us | `factOf` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:97` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `classifyMermaidFamilyDescriptorFromFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/family-detection.ts:38` |
| 0.0% | 1.3ms | 0.0% | 0us | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:431` |
| 0.0% | 1.3ms | 0.0% | 0us | `normalizeFamilyDetectionLine` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:142` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `/^(?:#[0-9a-f]{3,4}\|#[0-9a-f]{6}\|#[0-9a-f]{8}\|[a-z][a-z0-9-]*)$/i` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 0us | `safeCssToken` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:69` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:110` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:418` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `getOwnPropertyDescriptors` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:169` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:55` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `get` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` |
| 0.0% | 1.3ms | 0.0% | 0us | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:42` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `mainSize` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:32` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:738` |
| 0.0% | 1.3ms | 0.0% | 0us | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:340` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:341` |
| 0.0% | 1.3ms | 0.0% | 0us | `internal:streams/legacy` | `internal:streams/legacy:2` |
| 0.0% | 1.3ms | 0.0% | 0us | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:974` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:843` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `extractClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:433` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `renderRelationshipMarkerOverlay` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:650` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `seatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:138` |
| 0.0% | 1.3ms | 0.0% | 0us | `projectClassPositioned` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:9` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `retainedLabelBounds` | `/tmp/pr449-main-integration-20261029-762/src/agent/layout-to-rendered.ts:17` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:19` |
| 0.0% | 1.3ms | 0.0% | 0us | `retainedLabelGeometry` | `/tmp/pr449-main-integration-20261029-762/src/agent/layout-to-rendered.ts:25` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parseClassRelationEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1399` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector/relation/accessibility` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connectorEndpointAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:443` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:129` |
| 0.0% | 1.3ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:263` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:354` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `applyReplacements` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:198` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `rectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `parseClassReference` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:186` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:152` |
| 0.0% | 1.3ms | 0.0% | 0us | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:372` |
| 0.0% | 1.2ms | 0.0% | 0us | `applyReplacements` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:195` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:744` |
| 0.0% | 1.2ms | 0.0% | 0us | `getCharWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:103` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:122` |
| 0.0% | 1.2ms | 0.0% | 0us | `header` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:447` |
| 0.0% | 1.2ms | 0.0% | 0us | `documentOpen` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:132` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scoreMeasuredRouteCrossingsWithAdmission` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:718` |
| 0.0% | 1.2ms | 0.0% | 0us | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:154` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:604` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:15` |
| 0.0% | 1.2ms | 0.0% | 0us | `createNativeSceneValidator` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1423` |
| 0.0% | 1.2ms | 0.0% | 0us | `sceneValidationMode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1397` |
| 0.0% | 1.2ms | 0.0% | 0us | `normalizeMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:663` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `matchMermaidFrontmatter` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `mermaidFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:149` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:701` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:844` |
| 0.0% | 1.2ms | 0.0% | 0us | `freezeBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:403` |
| 0.0% | 1.2ms | 0.0% | 0us | `snapshotBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:330` |
| 0.0% | 1.2ms | 0.0% | 0us | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:470` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/types.ts:1761` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:668` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:317` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:392` |
| 0.0% | 1.2ms | 0.0% | 0us | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:545` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `/^[A-Za-z0-9_-]+(?: [A-Za-z0-9_-]+)*$/` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:639` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `cachedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/experimental/position-cache.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:116` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:586` |
| 0.0% | 1.2ms | 0.0% | 0us | `compareCodePointStrings` | `/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts:3` |
| 0.0% | 1.2ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:637` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `createNativePaintEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `occurrence` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:755` |
| 0.0% | 1.2ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:770` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `diagramTitleBand` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts:356` |
| 0.0% | 1.2ms | 0.0% | 0us | `finishClassLayout` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:772` |
| 0.0% | 1.2ms | 0.0% | 0us | `withClassTitle` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:889` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:429` |
| 0.0% | 1.2ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:297` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorDirection` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:206` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `classifyClassStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:537` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:132` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:33` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:706` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `escapeXml` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:95` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-limits.ts:2` |
| 0.0% | 1.2ms | 0.0% | 0us | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:41` |
| 0.0% | 1.2ms | 0.0% | 0us | `classNativeMarkerMinimums` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:182` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `assertFinalClassSharpContacts` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:732` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `markPaintPrepared` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:325` |
| 0.0% | 1.2ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:424` |
| 0.0% | 1.2ms | 0.0% | 0us | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:13` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `sign` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `writtenClassRoundedHit` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `safeCssPaint` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:129` |
| 0.0% | 1.2ms | 0.0% | 0us | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:88` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `endsWith` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:661` |
| 0.0% | 1.2ms | 0.0% | 0us | `classStatementEnds` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:669` |
| 0.0% | 1.2ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:666` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:105` |
| 0.0% | 1.2ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:820` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1073` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:794` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1782` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `apply` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `dereferenceSchema` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `schemaMatchesRuntimeKind` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:39` |
| 0.0% | 1.2ms | 0.0% | 0us | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:543` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `SvgWriter` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `renderRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:585` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:375` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `reserve` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `classOwnedSurfaceViolations` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:689` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `admitRenderOptionsInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1293` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:428` |
| 0.0% | 1.2ms | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:528` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `assertClassMarkerMeaning` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:93` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:5` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parseClassInteractionWithAuthored` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:922` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `topRoundedRectPath` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:843` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:502` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:172` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:673` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `immutableSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1214` |
| 0.0% | 1.2ms | 0.0% | 0us | `immutableSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1222` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:3` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:11` |
| 0.0% | 1.2ms | 0.0% | 0us | `sourceEnvelopeMetadata` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:799` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:626` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:799` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:207` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1141` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:16` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parseClassRelationEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1354` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `rectOverlap` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderClassBox` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:364` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1702` |
| 0.0% | 1.2ms | 0.0% | 0us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1011` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `assertRenderableMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:88` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `createClassInterfaceAllocator` | `/tmp/pr449-main-integration-20261029-762/src/class/interface-occurrences.ts:21` |
| 0.0% | 1.2ms | 0.0% | 0us | `connectorGeometryEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:179` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1065` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:50` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:394` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:394` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `resolvedInlineColorAttribute` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:686` |
| 0.0% | 1.1ms | 0.0% | 0us | `knownBackendDescriptors` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:489` |
| 0.0% | 1.1ms | 0.0% | 0us | `getBackendDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:524` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:284` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `sourceEnvelopeMetadata` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:853` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1476` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:591` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `nativePaintSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `nativePaintSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:227` |
| 0.0% | 1.1ms | 0.0% | 0us | `parseClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1289` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveDiagramColors` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:52` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `renderRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:578` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1655` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:709` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `Duplex` | `internal:streams/duplex:15` |
| 0.0% | 1.1ms | 0.0% | 0us | `Zlib` | `node:zlib:298` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `resetBuffer` | `internal:streams/writable` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1523` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:765` |
| 0.0% | 1.1ms | 0.0% | 0us | `ZlibBase` | `node:zlib:123` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/external-scene.ts:154` |
| 0.0% | 1.1ms | 0.0% | 0us | `WritableState` | `internal:streams/writable:152` |
| 0.0% | 1.1ms | 0.0% | 0us | `Transform` | `internal:streams/transform:14` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:608` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1447` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:168` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:637` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `topRoundedRectPath` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:844` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:180` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1667` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `unsafeThemeColorKeys` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `scanInlineNamespaceStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `executionCapabilityDecision` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1449` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `executionCapabilityKey` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1432` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `get` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:10` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:213` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1071` |
| 0.0% | 1.1ms | 0.0% | 0us | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:96` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:126` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `renderDivider` | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:412` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `rejectUnknownKeys` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:153` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `serializeMarkerResource` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:137` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `rejectUnknownKeys` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `node:zlib` | `node:zlib:456` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `node:zlib:456` |
| 0.0% | 1.1ms | 0.0% | 0us | `graphicalBackendCapabilityClaims` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:271` |
| 0.0% | 1.1ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:744` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `normalizeMermaidRuntimeConfig` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `executionOffer` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validatePrimitiveCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:341` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:570` |
| 0.0% | 1.1ms | 0.0% | 0us | `createSketchBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:547` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1488` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1773` |
| 0.0% | 1.1ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:557` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:284` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:208` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `classNativeMarkerMinimums` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:645` |
| 0.0% | 1.1ms | 0.0% | 0us | `snapshotScenePrimitiveCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1549` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `transferSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:751` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `withRenderStageObserver` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:15` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isFrozen` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:213` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:161` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1462` |
| 0.0% | 1.1ms | 0.0% | 0us | `retainTextPaintPresence` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:71` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isExtensible` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `flatMap` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validatePrimitiveCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:332` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:302` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:605` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `normalizedReference` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:595` |
| 0.0% | 1.1ms | 0.0% | 0us | `unsafeCssReferences` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:618` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `distanceToSegment` | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `connector/transform/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:631` |
| 0.0% | 1.1ms | 0.0% | 0us | `hitsTransformed` | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:47` |
| 0.0% | 1.1ms | 0.0% | 0us | `transformedHitDistance` | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:32` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:114` |
| 0.0% | 1.1ms | 0.0% | 0us | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:956` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:664` |
| 0.0% | 1.1ms | 0.0% | 0us | `markerPaintPieces` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:27` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:724` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `cloneFrontmatterMap` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `canonicalizeFrontmatterMap` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:1084` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1199` |
| 0.0% | 1.1ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1569` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `parseClassDeclaration` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:170` |
| 0.0% | 1.1ms | 0.0% | 0us | `classifyClassStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:518` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `documentClose` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:140` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `compareCodePointStrings` | `/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:369` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:293` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:204` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `detectorClaims` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1595` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:879` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:346` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `matchingBrace` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:146` |
| 0.0% | 1.0ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:185` |
| 0.0% | 1.0ms | 0.0% | 0us | `scopeCss` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:115` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `transformAttribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:531` |
| 0.0% | 1.0ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:724` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:734` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1201` |
| 0.0% | 1.0ms | 0.0% | 0us | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:323` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:506` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `startsWith` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/common/seq.js:4` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `atan2` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:5` |
| 0.0% | 1.0ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:704` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `expandInlineNamespaceStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:179` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `separatedSharpSupportBounds` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:68` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:591` |
| 0.0% | 1.0ms | 0.0% | 0us | `internal:streams/operators` | `internal:streams/operators:2` |
| 0.0% | 1.0ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:593` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `clear` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:497` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolveClassRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `normalizeRequest` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:17` |
| 0.0% | 1.0ms | 0.0% | 0us | `applyFamilyRequestNormalization` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1042` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:108` |
| 0.0% | 1.0ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:169` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `paintPrimitiveSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `/^\s*<([A-Za-z][\w:-]*)\b[^>]*>/` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `xmlTokenAt` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:85` |
| 0.0% | 1.0ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:368` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:290` |
| 0.0% | 1.0ms | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1682` |
| 0.0% | 1.0ms | 0.0% | 0us | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1094` |
| 0.0% | 1.0ms | 0.0% | 0us | `renderContractDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1118` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:65` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `/^\s*<g\b[^>]*>(?:<title>[^<]*<\/title>)?$/` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:705` |
| 0.0% | 1.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/builtin-backends.ts:20` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:307` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:307` |
| 0.0% | 1.0ms | 0.0% | 0us | `readClassStatements` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:705` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `/&quot;\|&#0*34;\|&#x0*22;/gi` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:642` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:398` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:89` |
| 0.0% | 1.0ms | 0.0% | 0us | `inspectOwnedSvgOnce` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:49` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `renderDisplayRuns` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:148` |
| 0.0% | 1.0ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:430` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:703` |
| 0.0% | 1.0ms | 0.0% | 0us | `compareSvgSum` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:43` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `writtenDecimalParts` | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:29` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `get receipt` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:346` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:280` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `checkFamilyConfigColors` | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1762` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:618` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:246` |
| 0.0% | 1.0ms | 0.0% | 0us | `knownOwned` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:8` |
| 0.0% | 1.0ms | 0.0% | 0us | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:212` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1776` |
| 0.0% | 1.0ms | 0.0% | 0us | `replaceField` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:288` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `scanInlineNamespaceStatement` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:48` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:102` |
| 0.0% | 1.0ms | 0.0% | 0us | `createPngOutputOptionFieldDescriptors` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:105` |
| 0.0% | 1.0ms | 0.0% | 0us | `caseInsensitiveKeywordPattern` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:102` |
| 0.0% | 1.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:173` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `requiredBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1363` |
| 0.0% | 1.0ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:153` |
| 0.0% | 1.0ms | 0.0% | 0us | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:399` |
| 0.0% | 998us | 0.0% | 998us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:840` |
| 0.0% | 998us | 0.0% | 0us | `prepareMarkerPolygonInk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1018` |
| 0.0% | 995us | 0.0% | 995us | `inlineResolvedColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:637` |
| 0.0% | 993us | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:199` |
| 0.0% | 989us | 0.0% | 989us | `findMarkerlessRelationshipOperator` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1550` |
| 0.0% | 989us | 0.0% | 0us | `parseMarkedClassRelationship` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1296` |
| 0.0% | 988us | 0.0% | 988us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:253` |
| 0.0% | 978us | 0.0% | 978us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:241` |
| 0.0% | 976us | 0.0% | 976us | `normalizeCssObfuscation` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:33` |
| 0.0% | 975us | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1759` |
| 0.0% | 975us | 0.0% | 975us | `validateRawThemeCss` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 969us | 0.0% | 969us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:725` |
| 0.0% | 967us | 0.0% | 967us | `parseClassDiagram` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 0.0% | 954us | 0.0% | 954us | `positionFamilyForNativeRender` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts` |

## Function Details

### `bound require`
`[native code]` | Self: 6.2% (270.4ms) | Total: 10.0% (436.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (20)
- `(anonymous)` (15)
- `(anonymous)` (9)
- `(anonymous)` (7)
- `(anonymous)` (4)
- `(anonymous)` (4)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

**Calls:**
- `require` (96)

### `xmlSlice`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:106` | Self: 4.2% (184.3ms) | Total: 4.2% (184.3ms) | Samples: 111

**Called by:**
- `verifyDocumentEnvelope` (83)
- `verifyDocumentEnvelope` (28)

### `getOwnPropertyDescriptor`
`[native code]` | Self: 3.5% (155.5ms) | Total: 3.5% (155.5ms) | Samples: 87

**Called by:**
- `copyInner` (47)
- `copyInner` (24)
- `rectanglePaint` (3)
- `sameRectanglePaint` (2)
- `qualify` (2)
- `deferredTerminalProjectionInput` (2)
- `copyInner` (1)
- `group` (1)
- `replaceField` (1)
- `inertRectangleRecord` (1)
- `nativeGroup` (1)
- `rectangleInput` (1)
- `parts` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:169` | Self: 3.0% (131.2ms) | Total: 3.1% (136.5ms) | Samples: 78

**Called by:**
- `copyInner` (61)
- `leaf` (15)
- `snapshot` (5)
- `copy` (1)

**Calls:**
- `defineProperty` (2)
- `copyInner` (2)

### `_toPrimitive`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:13` | Self: 3.0% (130.5ms) | Total: 3.0% (130.5ms) | Samples: 1

**Called by:**
- `_toPropertyKey` (1)

### `copyDataProperties`
`[native code]` | Self: 1.9% (83.7ms) | Total: 1.9% (83.7ms) | Samples: 43

**Called by:**
- `semanticIdentityForSvg` (3)
- `ownConnectorEndpoint` (2)
- `leaf` (2)
- `group` (2)
- `group` (2)
- `connectorGeometryEndpoints` (2)
- `geometryAttributes` (2)
- `shape` (2)
- `connector` (2)
- `assertClassMarkerMeaning` (1)
- `renderDivider` (1)
- `connector` (1)
- `geometryAttributes` (1)
- `(anonymous)` (1)
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)
- `connector` (1)
- `leaf` (1)
- `layoutResult` (1)
- `shape` (1)
- `prepareMarkerPolygonInk` (1)
- `leaf` (1)
- `leaf` (1)
- `text` (1)
- `text` (1)
- `nativePaintSource` (1)
- `(module)` (1)
- `deriveConnectorTerminalProjection` (1)
- `snapshotScenePrimitiveCell` (1)
- `ownConnectorEndpoint` (1)
- `connector` (1)
- `connector` (1)
- `connectorContourSemantics` (1)

### `fromEntries`
`[native code]` | Self: 1.7% (74.7ms) | Total: 1.7% (74.7ms) | Samples: 8

**Called by:**
- `styleSpecJsonSchema` (6)
- `snapshotScenePrimitiveCell` (1)
- `freezeDescriptor` (1)

### `anonymous`
`[native code]` | Self: 1.6% (71.6ms) | Total: 6.2% (273.1ms) | Samples: 35

**Called by:**
- `require` (96)
- `node:zlib` (11)
- `node:stream` (9)
- `internal:stream` (8)
- `internal:streams/pipeline` (6)
- `internal:streams/compose` (6)
- `internal:streams/duplex` (4)
- `internal:streams/destroy` (2)
- `internal:errors` (2)
- `node:fs` (1)
- `internal:streams/operators` (1)
- `internal:streams/legacy` (1)

**Calls:**
- `(anonymous)` (15)
- `node:stream` (9)
- `(anonymous)` (9)
- `internal:stream` (8)
- `(anonymous)` (7)
- `internal:streams/pipeline` (6)
- `internal:streams/compose` (6)
- `(anonymous)` (4)
- `internal:streams/duplex` (4)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `internal:streams/destroy` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `internal:errors` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:primordials` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:streams/legacy` (1)
- `internal:streams/operators` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `xmlAsciiLetter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:90` | Self: 1.5% (66.8ms) | Total: 1.5% (66.8ms) | Samples: 38

**Called by:**
- `xmlNameCharacter` (34)
- `readXmlNameEnd` (4)

### `decodeBase64`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:23` | Self: 1.4% (62.4ms) | Total: 1.4% (62.4ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `freeze`
`[native code]` | Self: 1.1% (48.6ms) | Total: 1.1% (48.6ms) | Samples: 31

**Called by:**
- `parts` (9)
- `scanStartTags` (7)
- `geometryAttributes` (2)
- `deepFreeze` (2)
- `snapshotScenePrimitiveCell` (2)
- `finish` (2)
- `freezeDescriptor` (1)
- `writeConnectorSvg` (1)
- `qualify` (1)
- `nativePaintAncestors` (1)
- `issue` (1)
- `group` (1)
- `nativeGroup` (1)

### `stringify`
`[native code]` | Self: 1.0% (47.7ms) | Total: 1.4% (63.3ms) | Samples: 28

**Called by:**
- `(module)` (15)
- `validateNode` (7)
- `(module)` (5)
- `include` (3)
- `renderedSvgDigest` (3)
- `validateNode` (2)
- `validateNode` (2)
- `prepareDisplayText` (1)
- `validateNode` (1)

**Calls:**
- `get receipt` (11)

### `boundedUtf8ByteLength`
`/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` | Self: 1.0% (44.8ms) | Total: 1.0% (46.3ms) | Samples: 26

**Called by:**
- `write` (14)
- `serialization` (12)
- `consumeStringBudget` (1)

**Calls:**
- `/[^\x00-\x7f]/` (1)

### `indent`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` | Self: 0.9% (43.1ms) | Total: 0.9% (43.1ms) | Samples: 23

**Called by:**
- `(anonymous)` (23)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:113` | Self: 0.9% (42.5ms) | Total: 0.9% (42.5ms) | Samples: 26

**Called by:**
- `copyInner` (22)
- `leaf` (3)
- `copy` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:13` | Self: 0.9% (42.2ms) | Total: 1.0% (45.5ms) | Samples: 25

**Calls:**
- `imul` (2)
- `(anonymous)` (1)

### `match`
`[native code]` | Self: 0.7% (32.2ms) | Total: 0.7% (33.2ms) | Samples: 8

**Called by:**
- `numericCss` (4)
- `classifyClassStatement` (1)
- `resolvedColorValue` (1)
- `parseClassReference` (1)
- `parseClassDeclaration` (1)
- `ensureSvgIdentity` (1)

**Calls:**
- `/^\s*<([A-Za-z][\w:-]*)\b[^>]*>/` (1)

### `cloneObject`
`[native code]` | Self: 0.6% (30.0ms) | Total: 0.6% (30.0ms) | Samples: 20

**Called by:**
- `(anonymous)` (7)
- `deriveConnectorTerminalProjection` (2)
- `assertClassMarkerMeaning` (2)
- `terminalEndpoint` (1)
- `leaf` (1)
- `paintBounds` (1)
- `connectorGeometryEndpoints` (1)
- `connectorGeometryEndpoints` (1)
- `(anonymous)` (1)
- `connectorContourSemantics` (1)
- `(anonymous)` (1)
- `connector` (1)

### `map`
`[native code]` | Self: 0.6% (29.6ms) | Total: 4.3% (189.4ms) | Samples: 15

**Called by:**
- `validate` (16)
- `cloneValue` (9)
- `prepareMarkerTerminals` (6)
- `buildClassEndpointMarkerTemplates` (5)
- `pointsBounds` (5)
- `runBackendConformance` (5)
- `serializeMarkerResources` (4)
- `(anonymous)` (3)
- `expandLocalReferences` (3)
- `flatIntoArrayWithCallback` (2)
- `(module)` (2)
- `transformSvgCssValues` (2)
- `writeSceneNode` (2)
- `(anonymous)` (2)
- `layoutLayeredGraph` (1)
- `assessFamilyLayout` (1)
- `canonicalJson` (1)
- `text` (1)
- `validate` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `include` (1)
- `addClassSvgNumbers` (1)
- `caseInsensitiveKeywordPattern` (1)
- `sanitizeDisplayLines` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `preparePixelText` (1)
- `styleSpecJsonSchema` (1)
- `assertFinalBoundaryContacts` (1)
- `layoutMeasuredForest` (1)
- `toMermaidLines` (1)
- `createPngOutputOptionFieldDescriptors` (1)
- `prepareDisplayText` (1)
- `node:zlib` (1)
- `compareCodePointStrings` (1)
- `snapshotBackendCapabilities` (1)
- `(anonymous)` (1)
- `pointsBounds` (1)
- `projectClassPositioned` (1)
- `pointsBounds` (1)
- `projectClassPositioned` (1)
- `(anonymous)` (1)
- `connector` (1)
- `render` (1)
- `pointsBounds` (1)
- `readClassStatements` (1)

**Calls:**
- `(anonymous)` (11)
- `(anonymous)` (9)
- `(anonymous)` (5)
- `(anonymous)` (4)
- `(anonymous)` (4)
- `cloneValue` (3)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `serializeMarkerResource` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `caseInsensitiveKeywordPattern` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `canonicalJson` (1)
- `(anonymous)` (1)
- `serializeMarkerResource` (1)
- `validate` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `world` (1)
- `serializeMarkerResource` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `has`
`[native code]` | Self: 0.6% (27.7ms) | Total: 0.6% (27.7ms) | Samples: 9

**Called by:**
- `validateDescriptor` (2)
- `getCharWidth` (1)
- `(anonymous)` (1)
- `serializeSceneNode` (1)
- `(unknown)` (1)
- `verifyDocumentEnvelope` (1)
- `scanStartTags` (1)
- `validateAggregateReferences` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:115` | Self: 0.5% (25.5ms) | Total: 0.5% (25.5ms) | Samples: 7

**Called by:**
- `copyInner` (7)

### `some`
`[native code]` | Self: 0.5% (24.8ms) | Total: 1.1% (50.8ms) | Samples: 16

**Called by:**
- `installedFamilyStatementEnds` (11)
- `assertInertGroup` (4)
- `nonPainting` (3)
- `some` (2)
- `layoutMeasuredForest` (2)
- `validateDescriptor` (1)
- `detectorClaims` (1)
- `validateDescriptor` (1)
- `placeClassCardinalityLabels` (1)

**Calls:**
- `some` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `test` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `hasOwn`
`[native code]` | Self: 0.5% (22.3ms) | Total: 0.5% (22.3ms) | Samples: 6

**Called by:**
- `group` (2)
- `tryParseCssColor` (2)
- `retainTextPaintPresence` (1)
- `assertKnownConnectorFields` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:105` | Self: 0.4% (20.2ms) | Total: 0.4% (20.2ms) | Samples: 10

**Called by:**
- `copyInner` (6)
- `copyInner` (2)
- `snapshot` (1)
- `leaf` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:435` | Self: 0.4% (19.4ms) | Total: 0.8% (38.1ms) | Samples: 6

**Called by:**
- `(anonymous)` (18)

**Calls:**
- `readXmlDataEnd` (7)
- `readXmlDataEnd` (4)
- `readXmlDataEnd` (1)

### `set`
`[native code]` | Self: 0.4% (19.2ms) | Total: 0.4% (19.2ms) | Samples: 10

**Called by:**
- `validateNode` (2)
- `issue` (2)
- `registerExtension` (1)
- `classNativeMarkerMinimums` (1)
- `writeConnectorSvg` (1)
- `leaf` (1)
- `serializeSceneNode` (1)
- `inspectOwnedSvgOnce` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:582` | Self: 0.4% (19.0ms) | Total: 0.4% (19.0ms) | Samples: 6

**Called by:**
- `resolvedColorValue` (6)

### `test`
`[native code]` | Self: 0.4% (17.6ms) | Total: 0.4% (19.9ms) | Samples: 8

**Called by:**
- `assertInertGroup` (2)
- `(anonymous)` (1)
- `some` (1)
- `classCommentStart` (1)
- `inspectSecurityTail` (1)
- `validateMarkAttributes` (1)
- `parseExtensionId` (1)
- `assertMarkAttributes` (1)

**Calls:**
- `/acc(?:Title\|Descr)/i` (1)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:473` | Self: 0.3% (17.1ms) | Total: 0.3% (17.1ms) | Samples: 4

**Called by:**
- `diagramColorVariables` (4)

### `indent`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:226` | Self: 0.3% (16.8ms) | Total: 0.3% (16.8ms) | Samples: 9

**Called by:**
- `(anonymous)` (9)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.3% (16.7ms) | Total: 0.3% (16.7ms) | Samples: 4

**Called by:**
- `copyInner` (2)
- `sameRectanglePaint` (1)
- `copyInner` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:735` | Self: 0.3% (16.5ms) | Total: 0.3% (16.5ms) | Samples: 6

**Called by:**
- `finalizeClassSurfaces` (6)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:738` | Self: 0.3% (16.2ms) | Total: 0.3% (16.2ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (1)

### `writtenSegmentEntersBox`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:102` | Self: 0.3% (15.6ms) | Total: 0.3% (15.6ms) | Samples: 8

**Called by:**
- `writtenClassRoundedHit` (7)
- `writtenClassRoundedHit` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:119` | Self: 0.3% (15.5ms) | Total: 0.4% (21.4ms) | Samples: 7

**Called by:**
- `projectSvgCss` (8)
- `nativeGroup` (2)
- `visitSvgFirstTagAttributes` (1)

**Calls:**
- `isAsciiXmlNameChar` (4)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:37` | Self: 0.3% (15.4ms) | Total: 0.3% (15.4ms) | Samples: 5

**Called by:**
- `scanStartTags` (5)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:158` | Self: 0.3% (14.5ms) | Total: 0.9% (41.1ms) | Samples: 7

**Called by:**
- `classOwnedSurfaceViolations` (21)

**Calls:**
- `writtenSegmentEntersBox` (7)
- `writtenSegmentEntersBox` (6)
- `writtenSegmentEntersBox` (1)

### `xmlNameCharacter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:91` | Self: 0.3% (14.4ms) | Total: 1.6% (72.9ms) | Samples: 8

**Called by:**
- `readXmlNameEnd` (42)

**Calls:**
- `xmlAsciiLetter` (34)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:463` | Self: 0.3% (14.2ms) | Total: 0.3% (14.2ms) | Samples: 9

**Called by:**
- `connector` (7)
- `assertClassMarkerMeaning` (2)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:247` | Self: 0.3% (13.6ms) | Total: 0.3% (13.6ms) | Samples: 1

**Called by:**
- `include` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1457` | Self: 0.2% (12.8ms) | Total: 0.2% (12.8ms) | Samples: 8

**Called by:**
- `serialize` (8)

### `issue`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:91` | Self: 0.2% (12.6ms) | Total: 0.3% (15.0ms) | Samples: 6

**Called by:**
- `serializeSceneNode` (3)
- `(anonymous)` (2)
- `writeTextSvg` (1)
- `write` (1)

**Calls:**
- `assign` (1)

### `add`
`[native code]` | Self: 0.2% (12.4ms) | Total: 0.2% (12.4ms) | Samples: 7

**Called by:**
- `validateNode` (2)
- `verifyDocumentEnvelope` (2)
- `omitUndefinedObjectFields` (1)
- `validateDescriptor` (1)
- `leaf` (1)

### `every`
`[native code]` | Self: 0.2% (12.3ms) | Total: 0.4% (19.6ms) | Samples: 5

**Called by:**
- `renderDisplayRuns` (3)
- `transformedBounds` (1)
- `validateConnectorProjectionConsistency` (1)
- `evaluateExtensionCompatibility` (1)
- `preparePixelText` (1)
- `resolveExecutionPlan` (1)
- `leaf` (1)
- `negotiateCapabilities` (1)

**Calls:**
- `structurallyEqual` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:165` | Self: 0.2% (11.6ms) | Total: 0.2% (11.6ms) | Samples: 7

**Called by:**
- `classOwnedSurfaceViolations` (7)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.2% (11.1ms) | Total: 0.2% (11.1ms) | Samples: 1

**Called by:**
- `text` (1)

### `preventExtensions`
`[native code]` | Self: 0.2% (11.1ms) | Total: 0.2% (11.1ms) | Samples: 8

**Called by:**
- `copyInner` (7)
- `(anonymous)` (1)

### `/acc(?:Title\|Descr)/i`
`[native code]` | Self: 0.2% (10.9ms) | Total: 0.2% (10.9ms) | Samples: 2

**Called by:**
- `test` (1)
- `(anonymous)` (1)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:251` | Self: 0.2% (10.9ms) | Total: 0.2% (10.9ms) | Samples: 1

**Called by:**
- `validatePoint` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:160` | Self: 0.2% (10.8ms) | Total: 20.9% (912.0ms) | Samples: 5

**Called by:**
- `copyInner` (276)
- `leaf` (182)
- `copy` (50)
- `snapshot` (7)

**Calls:**
- `copyInner` (276)
- `copyInner` (61)
- `copy` (57)
- `copyInner` (34)
- `copyInner` (22)
- `copyInner` (7)
- `copyInner` (7)
- `copyInner` (7)
- `copyInner` (6)
- `copyInner` (6)
- `copyInner` (4)
- `copyInner` (3)
- `copyInner` (3)
- `copyInner` (3)
- `copyInner` (3)
- `copyInner` (2)
- `copyInner` (2)
- `copy` (2)
- `copyInner` (1)
- `copy` (1)
- `copy` (1)
- `copy` (1)
- `copyInner` (1)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:658` | Self: 0.2% (10.8ms) | Total: 0.2% (10.8ms) | Samples: 8

**Called by:**
- `(anonymous)` (8)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:235` | Self: 0.2% (10.7ms) | Total: 0.2% (10.7ms) | Samples: 8

**Called by:**
- `verifyDocumentEnvelope` (7)
- `verifyDocumentEnvelope` (1)

### `canonicalTextDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1171` | Self: 0.2% (10.7ms) | Total: 0.2% (10.7ms) | Samples: 7

**Called by:**
- `(anonymous)` (7)

### `min`
`[native code]` | Self: 0.2% (10.7ms) | Total: 0.2% (10.7ms) | Samples: 4

**Called by:**
- `sharpContactsClear` (3)
- `pointsBounds` (1)

### `writeSync`
`[native code]` | Self: 0.2% (10.7ms) | Total: 0.2% (10.7ms) | Samples: 9

**Called by:**
- `processChunkSync` (9)

### `Number`
`[native code]` | Self: 0.2% (10.5ms) | Total: 0.2% (10.5ms) | Samples: 2

**Called by:**
- `geometryAttributes` (1)
- `assertClassMarkerMeaning` (1)

### `replace`
`[native code]` | Self: 0.2% (10.1ms) | Total: 0.4% (19.3ms) | Samples: 5

**Called by:**
- `formatSvgNumericAttribute` (3)
- `parseClassInteractionWithAuthored` (2)
- `group` (2)
- `(anonymous)` (1)
- `resolveCss` (1)
- `normalizeFamilyDetectionLine` (1)

**Calls:**
- `/var\(--([\w-]+)\)/g` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `/&quot;\|&#0*34;\|&#x0*22;/gi` (1)
- `/<!--[\s\S]*?-->/g` (1)

### `includes`
`[native code]` | Self: 0.2% (10.1ms) | Total: 0.2% (10.1ms) | Samples: 5

**Called by:**
- `validateNode` (1)
- `validateDescriptor` (1)
- `validateMarker` (1)
- `leaf` (1)
- `validateMarker` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:277` | Self: 0.2% (9.9ms) | Total: 0.3% (14.1ms) | Samples: 2

**Called by:**
- `writeTextSvg` (5)

**Calls:**
- `(anonymous)` (2)
- `(anonymous)` (1)

### `pointsBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:15` | Self: 0.2% (9.9ms) | Total: 0.2% (11.5ms) | Samples: 2

**Called by:**
- `geometryBounds` (3)

**Calls:**
- `map` (1)

### `charge`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` | Self: 0.2% (9.7ms) | Total: 0.2% (9.7ms) | Samples: 5

**Called by:**
- `(anonymous)` (2)
- `assertFinalBoundaryContacts` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:86` | Self: 0.2% (9.7ms) | Total: 0.2% (9.7ms) | Samples: 2

**Called by:**
- `projectSvgCss` (2)

### `escapeAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` | Self: 0.2% (9.6ms) | Total: 0.2% (9.6ms) | Samples: 6

**Called by:**
- `attribute` (6)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:108` | Self: 0.2% (9.5ms) | Total: 0.2% (11.1ms) | Samples: 8

**Called by:**
- `leaf` (6)
- `copyInner` (3)

**Calls:**
- `pay` (1)

### `issue`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:93` | Self: 0.2% (9.4ms) | Total: 0.2% (11.6ms) | Samples: 5

**Called by:**
- `serializeSceneNode` (3)
- `write` (2)
- `writeTextSvg` (1)
- `group` (1)

**Calls:**
- `set` (2)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:115` | Self: 0.2% (9.4ms) | Total: 0.2% (9.4ms) | Samples: 1

**Called by:**
- `shape` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:304` | Self: 0.2% (9.3ms) | Total: 0.2% (9.3ms) | Samples: 6

**Called by:**
- `attribute` (6)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:117` | Self: 0.2% (9.3ms) | Total: 1.5% (65.7ms) | Samples: 3

**Called by:**
- `leaf` (25)
- `copyInner` (2)

**Calls:**
- `getOwnPropertyDescriptor` (24)

### `connectorSubpaths`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:363` | Self: 0.2% (9.2ms) | Total: 0.2% (9.2ms) | Samples: 2

**Called by:**
- `connectorContourSemantics` (2)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:496` | Self: 0.2% (9.0ms) | Total: 0.2% (11.4ms) | Samples: 8

**Called by:**
- `text` (9)

**Calls:**
- `copyDataProperties` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:322` | Self: 0.2% (9.0ms) | Total: 0.2% (9.0ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `boundedString`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:268` | Self: 0.2% (8.9ms) | Total: 0.3% (14.3ms) | Samples: 7

**Called by:**
- `validateNode` (8)
- `validateMarker` (1)

**Calls:**
- `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/` (2)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:631` | Self: 0.2% (8.7ms) | Total: 10.4% (455.9ms) | Samples: 5

**Called by:**
- `leaf` (259)

**Calls:**
- `copyInner` (182)
- `copyInner` (25)
- `copyInner` (15)
- `copyInner` (13)
- `copyInner` (6)
- `copyInner` (3)
- `copyInner` (2)
- `copyInner` (2)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copy` (1)
- `copyInner` (1)
- `copyInner` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:192` | Self: 0.2% (8.7ms) | Total: 0.2% (8.7ms) | Samples: 6

**Called by:**
- `copyInner` (6)

### `scoreMeasuredRouteCrossingsWithAdmission`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:733` | Self: 0.1% (8.6ms) | Total: 0.1% (8.6ms) | Samples: 4

**Called by:**
- `(anonymous)` (3)
- `validate` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:529` | Self: 0.1% (8.6ms) | Total: 0.1% (8.6ms) | Samples: 6

**Called by:**
- `(anonymous)` (6)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` | Self: 0.1% (8.6ms) | Total: 0.1% (8.6ms) | Samples: 7

**Called by:**
- `copyInner` (7)

### `deferredTerminalProjectionInput`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` | Self: 0.1% (8.5ms) | Total: 0.1% (8.5ms) | Samples: 6

**Called by:**
- `copyInner` (6)

### `isAsciiXmlNameChar`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` | Self: 0.1% (8.4ms) | Total: 0.1% (8.4ms) | Samples: 6

**Called by:**
- `scanStartTags` (4)
- `scanStartTags` (2)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.1% (8.3ms) | Total: 0.1% (8.3ms) | Samples: 3

**Called by:**
- `positionedPaintCertification` (3)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:524` | Self: 0.1% (8.2ms) | Total: 0.1% (8.2ms) | Samples: 2

**Called by:**
- `write` (2)

### `forEach`
`[native code]` | Self: 0.1% (8.2ms) | Total: 5.5% (242.4ms) | Samples: 3

**Called by:**
- `lowerClassDrawing` (95)
- `connectorMarkerPaintRegions` (28)
- `classRelationshipPaintBoxes` (2)
- `connectorMarkerPaintRegions` (1)

**Calls:**
- `(anonymous)` (92)
- `include` (11)
- `include` (4)
- `include` (3)
- `include` (2)
- `include` (2)
- `include` (1)
- `include` (1)
- `(anonymous)` (1)
- `include` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `include` (1)
- `include` (1)
- `(anonymous)` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:646` | Self: 0.1% (8.0ms) | Total: 0.2% (10.4ms) | Samples: 5

**Called by:**
- `leaf` (7)

**Calls:**
- `assign` (2)

### `push`
`[native code]` | Self: 0.1% (8.0ms) | Total: 0.1% (8.0ms) | Samples: 5

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (2)
- `scanAccessibilityDirectives` (1)
- `lowerClassDrawing` (1)
- `nativeGroup` (1)

### `arrayIteratorNextHelper`
`[native code]` | Self: 0.1% (8.0ms) | Total: 0.1% (8.0ms) | Samples: 4

**Called by:**
- `performIteration` (2)
- `next` (2)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:162` | Self: 0.1% (7.9ms) | Total: 0.4% (20.6ms) | Samples: 2

**Called by:**
- `absentPaint` (1)
- `paintedStrokeExtent` (1)
- `relativeLuminance` (1)
- `color` (1)

**Calls:**
- `hasOwn` (2)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:633` | Self: 0.1% (7.9ms) | Total: 0.2% (11.4ms) | Samples: 3

**Called by:**
- `leaf` (5)

**Calls:**
- `transferSceneNodeSerialization` (1)
- `transferSceneNodeSerialization` (1)

### `String`
`[native code]` | Self: 0.1% (7.9ms) | Total: 0.1% (7.9ms) | Samples: 2

**Called by:**
- `renderRelationship` (1)
- `renderClassBox` (1)

### `compareSvgSum`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:38` | Self: 0.1% (7.8ms) | Total: 0.1% (7.8ms) | Samples: 3

**Called by:**
- `writtenSegmentEntersBox` (3)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:338` | Self: 0.1% (7.8ms) | Total: 0.1% (7.8ms) | Samples: 2

**Called by:**
- `forEach` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:562` | Self: 0.1% (7.7ms) | Total: 0.4% (17.6ms) | Samples: 4

**Called by:**
- `map` (11)

**Calls:**
- `cloneObject` (7)

### `next`
`[native code]` | Self: 0.1% (7.7ms) | Total: 0.2% (12.9ms) | Samples: 4

**Called by:**
- `performIteration` (2)
- `cssPaintDefinitions` (2)
- `unsafeCssReferences` (2)
- `unsafeCssReferences` (1)

**Calls:**
- `arrayIteratorNextHelper` (2)
- `/--([\w-]+)\s*:\s*([^;{}]+)/g` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:422` | Self: 0.1% (7.6ms) | Total: 0.2% (11.2ms) | Samples: 6

**Called by:**
- `(anonymous)` (7)

**Calls:**
- `has` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:739` | Self: 0.1% (7.6ms) | Total: 2.1% (93.5ms) | Samples: 5

**Called by:**
- `finalizeClassSurfaces` (53)

**Calls:**
- `writtenClassRoundedHit` (21)
- `writtenClassRoundedHit` (7)
- `writtenClassRoundedHit` (7)
- `writtenClassRoundedHit` (3)
- `writtenClassRoundedHit` (2)
- `writtenClassRoundedHit` (2)
- `writtenClassRoundedHit` (2)
- `writtenClassRoundedHit` (1)
- `writtenClassRoundedHit` (1)
- `writtenClassRoundedHit` (1)
- `writtenPoint` (1)

### `RegExp`
`[native code]` | Self: 0.1% (7.5ms) | Total: 0.1% (7.5ms) | Samples: 4

**Called by:**
- `attr` (4)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:30` | Self: 0.1% (7.5ms) | Total: 0.1% (7.5ms) | Samples: 2

**Called by:**
- `attribute` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:550` | Self: 0.1% (7.4ms) | Total: 0.1% (7.4ms) | Samples: 2

**Called by:**
- `assertFinalClassSharpContacts` (2)

### `compositeCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:277` | Self: 0.1% (7.3ms) | Total: 0.1% (7.3ms) | Samples: 3

**Called by:**
- `toneOnFill` (3)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:488` | Self: 0.1% (7.3ms) | Total: 0.1% (7.3ms) | Samples: 4

**Called by:**
- `hooks` (4)

### `xmlRange`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:48` | Self: 0.1% (7.3ms) | Total: 0.1% (7.3ms) | Samples: 5

**Called by:**
- `writeTextSvg` (5)

### `registrationIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` | Self: 0.1% (7.3ms) | Total: 0.1% (7.3ms) | Samples: 1

**Called by:**
- `registerCanonicalStyle` (1)

### `markerPaintPieces`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:64` | Self: 0.1% (7.3ms) | Total: 0.1% (7.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:485` | Self: 0.1% (7.2ms) | Total: 0.1% (7.2ms) | Samples: 3

**Called by:**
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `writeConnectorSvg` (1)

### `get`
`[native code]` | Self: 0.1% (7.2ms) | Total: 0.1% (7.2ms) | Samples: 5

**Called by:**
- `writeTextSvg` (2)
- `snapshotDescriptorArray` (1)
- `extractClassLayout` (1)
- `certifyNativePaint` (1)

### `defineProperty`
`[native code]` | Self: 0.1% (7.2ms) | Total: 0.1% (7.2ms) | Samples: 5

**Called by:**
- `copyInner` (2)
- `copyInner` (1)
- `inertRectangleRecord` (1)
- `geometryAttributes` (1)

### `writtenSegmentEntersBox`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:95` | Self: 0.1% (7.1ms) | Total: 0.4% (18.1ms) | Samples: 5

**Called by:**
- `writtenClassRoundedHit` (6)
- `writtenClassRoundedHit` (4)

**Calls:**
- `compareSvgSum` (3)
- `compareSvgSum` (1)
- `sign` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:760` | Self: 0.1% (7.0ms) | Total: 0.1% (7.0ms) | Samples: 3

**Called by:**
- `write` (3)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` | Self: 0.1% (7.0ms) | Total: 0.1% (7.0ms) | Samples: 1

**Called by:**
- `group` (1)

### `appendPrivate`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:55` | Self: 0.1% (7.0ms) | Total: 0.1% (7.0ms) | Samples: 3

**Called by:**
- `group` (2)
- `group` (1)

### `slice`
`[native code]` | Self: 0.1% (6.9ms) | Total: 0.1% (6.9ms) | Samples: 5

**Called by:**
- `replaceSvgRootStartTag` (2)
- `scanAccessibilityDirectives` (1)
- `parseInlineFormatting` (1)
- `tryParseCssColor` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:374` | Self: 0.1% (6.9ms) | Total: 1.3% (57.3ms) | Samples: 3

**Called by:**
- `lowerClassDrawing` (32)

**Calls:**
- `leaf` (27)
- `renderDivider` (1)
- `shape` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:537` | Self: 0.1% (6.9ms) | Total: 0.1% (6.9ms) | Samples: 4

**Called by:**
- `(anonymous)` (4)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:274` | Self: 0.1% (6.9ms) | Total: 0.2% (9.9ms) | Samples: 3

**Called by:**
- `leaf` (4)

**Calls:**
- `set` (1)

### `locale_default`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-format/src/locale.js` | Self: 0.1% (6.9ms) | Total: 0.1% (6.9ms) | Samples: 1

**Called by:**
- `defaultLocale` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:345` | Self: 0.1% (6.8ms) | Total: 0.1% (6.8ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.1% (6.8ms) | Total: 0.1% (6.8ms) | Samples: 3

**Called by:**
- `validateSceneDocument` (3)

### `serialize`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:624` | Self: 0.1% (6.7ms) | Total: 13.1% (574.0ms) | Samples: 3

**Called by:**
- `leaf` (281)
- `leaf` (30)

**Calls:**
- `write` (142)
- `write` (136)
- `write` (14)
- `write` (8)
- `write` (7)
- `write` (1)

### `filter`
`[native code]` | Self: 0.1% (6.7ms) | Total: 0.4% (19.6ms) | Samples: 4

**Called by:**
- `validate` (2)
- `authoredClassStatements` (2)
- `createCliRenderOutputDescriptors` (1)
- `structurallyEqual` (1)
- `resolveExecutionPlan` (1)
- `parseClassDiagram` (1)
- `expandLocalReferences` (1)
- `semanticIdentityForSvg` (1)
- `freezeDescriptor` (1)

**Calls:**
- `(anonymous)` (1)
- `schemaMatchesRuntimeKind` (1)
- `schemaMatchesRuntimeKind` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:689` | Self: 0.1% (6.6ms) | Total: 0.1% (6.6ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (2)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:150` | Self: 0.1% (6.6ms) | Total: 0.1% (6.6ms) | Samples: 3

**Called by:**
- `classOwnedSurfaceViolations` (3)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.1% (6.6ms) | Total: 0.1% (6.6ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `find`
`[native code]` | Self: 0.1% (6.5ms) | Total: 0.4% (19.0ms) | Samples: 2

**Called by:**
- `validateDescriptor` (2)
- `validateDescriptor` (2)
- `decodedSvgAttributeValue` (2)
- `assertClassMarkerMeaning` (1)
- `validateDescriptor` (1)
- `sourceEnvelopeMetadata` (1)
- `validateBackendCapabilities` (1)

**Calls:**
- `detectorClaims` (3)
- `(anonymous)` (1)
- `detectorClaims` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` | Self: 0.1% (6.5ms) | Total: 0.1% (6.5ms) | Samples: 3

**Called by:**
- `leaf` (3)

### `entries`
`[native code]` | Self: 0.1% (6.3ms) | Total: 0.1% (6.3ms) | Samples: 4

**Called by:**
- `validateMarkAttributes` (1)
- `immutableSnapshot` (1)
- `expandLocalReferences` (1)
- `assertMarkAttributes` (1)

### `inertRectangleRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:311` | Self: 0.1% (6.3ms) | Total: 0.1% (7.5ms) | Samples: 5

**Called by:**
- `(anonymous)` (4)
- `rectangleInput` (1)
- `leaf` (1)

**Calls:**
- `defineProperty` (1)

### `proofRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:64` | Self: 0.1% (6.2ms) | Total: 0.1% (6.2ms) | Samples: 3

**Called by:**
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)

### `safeCssToken`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:66` | Self: 0.1% (6.1ms) | Total: 0.1% (6.1ms) | Samples: 2

**Called by:**
- `validatePaint` (1)
- `resolveDiagramColors` (1)

### `result`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:377` | Self: 0.1% (6.1ms) | Total: 0.1% (6.1ms) | Samples: 2

**Called by:**
- `group` (2)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:87` | Self: 0.1% (6.1ms) | Total: 0.1% (6.1ms) | Samples: 5

**Called by:**
- `ensureSvgIdentity` (5)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` | Self: 0.1% (6.1ms) | Total: 0.2% (10.0ms) | Samples: 3

**Called by:**
- `write` (4)
- `node` (1)

**Calls:**
- `stringify` (2)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.1% (6.0ms) | Total: 0.1% (6.0ms) | Samples: 2

**Called by:**
- `finish` (2)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.1% (6.0ms) | Total: 0.1% (6.0ms) | Samples: 1

**Called by:**
- `group` (1)

### `element`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:301` | Self: 0.1% (6.0ms) | Total: 0.1% (6.0ms) | Samples: 4

**Called by:**
- `element` (4)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:268` | Self: 0.1% (6.0ms) | Total: 0.1% (6.0ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `Buffer`
`[native code]` | Self: 0.1% (6.0ms) | Total: 0.1% (6.0ms) | Samples: 5

**Called by:**
- `(anonymous)` (5)

### `charge`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` | Self: 0.1% (5.9ms) | Total: 0.1% (5.9ms) | Samples: 4

**Called by:**
- `clear` (1)
- `seatMeasuredMarkers` (1)
- `clear` (1)
- `intersects` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:590` | Self: 0.1% (5.9ms) | Total: 0.1% (5.9ms) | Samples: 4

**Called by:**
- `clear` (4)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:129` | Self: 0.1% (5.9ms) | Total: 1.8% (78.8ms) | Samples: 5

**Called by:**
- `copyInner` (34)
- `leaf` (13)
- `copy` (3)
- `snapshot` (2)

**Calls:**
- `getOwnPropertyDescriptor` (47)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:675` | Self: 0.1% (5.8ms) | Total: 0.1% (5.8ms) | Samples: 4

**Called by:**
- `(anonymous)` (4)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:831` | Self: 0.1% (5.8ms) | Total: 0.1% (5.8ms) | Samples: 1

**Called by:**
- `write` (1)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:32` | Self: 0.1% (5.7ms) | Total: 0.1% (5.7ms) | Samples: 2

**Called by:**
- `scanStartTags` (2)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1025` | Self: 0.1% (5.7ms) | Total: 0.1% (5.7ms) | Samples: 2

**Called by:**
- `assertClassMarkerMeaning` (2)

### `read`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:78` | Self: 0.1% (5.7ms) | Total: 0.1% (5.7ms) | Samples: 1

**Called by:**
- `pathBounds` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:583` | Self: 0.1% (5.7ms) | Total: 0.1% (5.7ms) | Samples: 3

**Called by:**
- `resolvedColorValue` (3)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:130` | Self: 0.1% (5.7ms) | Total: 0.1% (7.0ms) | Samples: 4

**Called by:**
- `nativeGroup` (3)
- `projectSvgCss` (2)

**Calls:**
- `indexOf` (1)

### `isFinite`
`[native code]` | Self: 0.1% (5.7ms) | Total: 0.1% (5.7ms) | Samples: 3

**Called by:**
- `include` (1)
- `finiteRect` (1)
- `separatedSharpSupportBounds` (1)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` | Self: 0.1% (5.7ms) | Total: 0.1% (5.7ms) | Samples: 4

**Called by:**
- `emitted` (2)
- `attribute` (1)
- `renderMultilineText` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:117` | Self: 0.1% (5.7ms) | Total: 0.1% (5.7ms) | Samples: 1

**Called by:**
- `shape` (1)

### `startTags`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.1% (5.6ms) | Total: 0.1% (5.6ms) | Samples: 1

**Called by:**
- `inspectSecurity` (1)

### `segmentEntersMeasuredBox`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` | Self: 0.1% (5.6ms) | Total: 0.1% (5.6ms) | Samples: 2

**Called by:**
- `validate` (2)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:667` | Self: 0.1% (5.4ms) | Total: 0.1% (5.4ms) | Samples: 2

**Called by:**
- `leaf` (2)

### `unclipped`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1034` | Self: 0.1% (5.4ms) | Total: 0.1% (5.4ms) | Samples: 1

**Called by:**
- `prepareMarkerPolygonInk` (1)

### `separatedSharpSupports`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:62` | Self: 0.1% (5.4ms) | Total: 0.1% (5.4ms) | Samples: 4

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (4)

### `classCommentStart`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:356` | Self: 0.1% (5.3ms) | Total: 0.1% (5.3ms) | Samples: 4

**Called by:**
- `classStatement` (3)
- `parseClassRelationship` (1)

### `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/`
`[native code]` | Self: 0.1% (5.3ms) | Total: 0.1% (5.3ms) | Samples: 2

**Called by:**
- `boundedString` (2)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.1% (5.3ms) | Total: 0.1% (5.3ms) | Samples: 3

**Called by:**
- `visit` (1)
- `leaf` (1)
- `visit` (1)

### `xmlHasColon`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.1% (5.2ms) | Total: 0.1% (5.2ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `rectangleInput`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:339` | Self: 0.1% (5.2ms) | Total: 0.1% (5.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:520` | Self: 0.1% (5.2ms) | Total: 0.1% (5.2ms) | Samples: 3

**Called by:**
- `markerBoundsAt` (2)
- `paintBounds` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:354` | Self: 0.1% (5.2ms) | Total: 1.9% (82.7ms) | Samples: 2

**Called by:**
- `lowerClassDrawing` (34)

**Calls:**
- `toneOnFill` (12)
- `toneOnFill` (9)
- `toneOnFill` (8)
- `toneOnFill` (1)
- `toneOnFill` (1)
- `toneOnFill` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:594` | Self: 0.1% (5.2ms) | Total: 0.2% (10.6ms) | Samples: 3

**Called by:**
- `clear` (5)

**Calls:**
- `charge` (2)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:33` | Self: 0.1% (5.2ms) | Total: 0.1% (5.2ms) | Samples: 3

**Called by:**
- `attribute` (3)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:498` | Self: 0.1% (5.1ms) | Total: 0.1% (5.1ms) | Samples: 3

**Called by:**
- `text` (3)

### `skipSeparators`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:168` | Self: 0.1% (5.1ms) | Total: 0.1% (8.4ms) | Samples: 4

**Called by:**
- `svgPathDataProblem` (2)
- `svgPathDataProblem` (2)
- `finiteNumber` (2)

**Calls:**
- `/\s/` (2)

### `xmlList`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:40` | Self: 0.1% (5.1ms) | Total: 0.1% (5.1ms) | Samples: 3

**Called by:**
- `XmlLeafWrite` (3)

### `classRelationshipTerminalClearance`
`/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts` | Self: 0.1% (5.1ms) | Total: 0.1% (5.1ms) | Samples: 1

**Called by:**
- `classTerminalLead` (1)

### `pointList`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` | Self: 0.1% (5.1ms) | Total: 0.1% (5.1ms) | Samples: 1

**Called by:**
- `geometryElements` (1)

### `canonicalOpeningTag`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:437` | Self: 0.1% (5.1ms) | Total: 0.1% (5.1ms) | Samples: 1

**Called by:**
- `canonicalizeSceneNodeSerialization` (1)

### `node:fs`
`node:fs:2` | Self: 0.1% (5.0ms) | Total: 0.1% (5.0ms) | Samples: 1

### `orthogonal`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:461` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 3

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (3)

### `parseFloat`
`[native code]` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 4

**Called by:**
- `paintedStrokeExtent` (3)
- `markerPaintPieces` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:662` | Self: 0.1% (4.9ms) | Total: 0.2% (11.3ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (6)

**Calls:**
- `SvgWriter` (3)
- `SvgWriter` (1)

### `boundedUtf8ByteLength`
`/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 2

**Called by:**
- `consumeStringBudget` (2)

### `localPaintResourceId`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:373` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 3

**Called by:**
- `collectPaintResourceReferences` (3)

### `assign`
`[native code]` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 3

**Called by:**
- `leaf` (2)
- `issue` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:121` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 4

**Called by:**
- `visitSvgFirstTagAttributes` (2)
- `projectSvgCss` (2)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:797` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:309` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 2

**Called by:**
- `lowerClassDrawing` (2)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `validateMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:365` | Self: 0.1% (4.7ms) | Total: 0.1% (6.1ms) | Samples: 3

**Called by:**
- `validateNode` (4)

**Calls:**
- `entries` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:177` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 3

**Called by:**
- `copyInner` (3)

### `scoreMeasuredRouteCrossingsWithAdmission`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:725` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 2

**Called by:**
- `(anonymous)` (1)
- `validate` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 3

**Called by:**
- `layoutLayeredGraph` (3)

### `sharpContactsClear`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` | Self: 0.1% (4.6ms) | Total: 0.1% (4.6ms) | Samples: 1

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `sharpContactsClear`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:367` | Self: 0.1% (4.6ms) | Total: 0.1% (4.6ms) | Samples: 2

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (2)

### `isRetainedPixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.1% (4.6ms) | Total: 0.1% (4.6ms) | Samples: 2

**Called by:**
- `validateNode` (2)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:66` | Self: 0.1% (4.6ms) | Total: 0.1% (4.6ms) | Samples: 4

**Called by:**
- `visit` (4)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:135` | Self: 0.1% (4.6ms) | Total: 0.1% (6.9ms) | Samples: 4

**Called by:**
- `projectSvgCss` (5)

**Calls:**
- `has` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.1% (4.5ms) | Total: 0.1% (4.5ms) | Samples: 3

**Called by:**
- `copyInner` (2)
- `leaf` (1)

### `validateRole`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.1% (4.5ms) | Total: 0.1% (4.5ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `join`
`[native code]` | Self: 0.1% (4.5ms) | Total: 0.1% (4.5ms) | Samples: 3

**Called by:**
- `resolveSvgColors` (2)
- `escapeDisplayAttr` (1)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.1% (4.4ms) | Total: 0.1% (4.4ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1836` | Self: 0.1% (4.4ms) | Total: 0.1% (5.9ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (2)

**Calls:**
- `work` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.1% (4.4ms) | Total: 0.1% (4.4ms) | Samples: 3

**Called by:**
- `map` (3)

### `/<\s*text/i`
`[native code]` | Self: 0.1% (4.4ms) | Total: 0.1% (4.4ms) | Samples: 2

**Called by:**
- `group` (2)

### `emittedBox`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:72` | Self: 0.1% (4.3ms) | Total: 0.2% (11.4ms) | Samples: 3

**Called by:**
- `classOwnedSurfaceViolations` (2)
- `writtenClassRoundedHit` (2)
- `classOwnedSurfaceViolations` (2)
- `writtenClassRoundedHit` (1)
- `writtenClassRoundedHit` (1)

**Calls:**
- `emitted` (5)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:520` | Self: 0.0% (4.3ms) | Total: 0.0% (4.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `positionedPaintCertification`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` | Self: 0.0% (4.3ms) | Total: 0.0% (4.3ms) | Samples: 1

**Called by:**
- `measureRenderStage` (1)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:434` | Self: 0.0% (4.3ms) | Total: 0.0% (4.3ms) | Samples: 1

**Called by:**
- `validatePoints` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:486` | Self: 0.0% (4.2ms) | Total: 0.3% (15.2ms) | Samples: 1

**Called by:**
- `paintAttribute` (3)
- `identityAttributes` (1)
- `writeConnectorSvg` (1)
- `hooks` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)

**Calls:**
- `attribute` (6)
- `attribute` (1)

### `renderRelationshipMarkerOverlay`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:642` | Self: 0.0% (4.2ms) | Total: 0.0% (4.2ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `connectorContourSemantics`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:389` | Self: 0.0% (4.2ms) | Total: 0.0% (4.2ms) | Samples: 1

**Called by:**
- `connector` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` | Self: 0.0% (4.2ms) | Total: 0.0% (4.2ms) | Samples: 2

**Called by:**
- `seatFinalMeasuredMarkers` (2)

### `emitted`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:22` | Self: 0.0% (4.2ms) | Total: 0.2% (9.8ms) | Samples: 3

**Called by:**
- `emittedBox` (5)
- `emittedPoint` (1)

**Calls:**
- `formatSvgNumber` (2)
- `formatSvgNumber` (1)

### `range`
`/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts:17` | Self: 0.0% (4.2ms) | Total: 0.0% (4.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:390` | Self: 0.0% (4.2ms) | Total: 0.0% (4.2ms) | Samples: 2

**Called by:**
- `connector` (2)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (4.2ms) | Total: 0.0% (4.2ms) | Samples: 3

**Called by:**
- `validateNode` (1)
- `validatePoint` (1)
- `validatePoint` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:511` | Self: 0.0% (4.2ms) | Total: 0.0% (4.2ms) | Samples: 2

**Called by:**
- `visit` (1)
- `visit` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:501` | Self: 0.0% (4.1ms) | Total: 0.0% (4.1ms) | Samples: 2

**Called by:**
- `validateNode` (1)
- `validateNode` (1)

### `writtenDecimalParts`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:30` | Self: 0.0% (4.1ms) | Total: 0.0% (4.1ms) | Samples: 2

**Called by:**
- `compareSvgSum` (2)

### `resolveCss`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:728` | Self: 0.0% (4.0ms) | Total: 0.2% (9.2ms) | Samples: 3

**Called by:**
- `resolvedInlineColorAttribute` (5)

**Calls:**
- `replace` (1)
- `(anonymous)` (1)

### `readXmlReferenceEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:219` | Self: 0.0% (4.0ms) | Total: 0.0% (4.0ms) | Samples: 1

**Called by:**
- `readXmlDataEnd` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:252` | Self: 0.0% (4.0ms) | Total: 1.7% (75.4ms) | Samples: 1

**Called by:**
- `leaf` (37)

**Calls:**
- `paintBounds` (8)
- `connectorPaintBounds` (8)
- `paintBounds` (3)
- `paintBounds` (3)
- `connectorPaintBounds` (3)
- `connectorPaintBounds` (2)
- `connectorPaintBounds` (2)
- `paintBounds` (1)
- `paintBounds` (1)
- `connectorPaintBounds` (1)
- `connectorPaintBounds` (1)
- `connectorPaintBounds` (1)
- `connectorPaintBounds` (1)
- `connectorPaintBounds` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:301` | Self: 0.0% (4.0ms) | Total: 0.0% (4.0ms) | Samples: 2

**Called by:**
- `lowerClassDrawing` (2)

### `xmlHasColon`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:89` | Self: 0.0% (4.0ms) | Total: 0.0% (4.0ms) | Samples: 2

**Called by:**
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:20` | Self: 0.0% (4.0ms) | Total: 0.0% (4.0ms) | Samples: 2

**Called by:**
- `emitted` (1)
- `renderMultilineText` (1)

### `markerTerminalDepth`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:296` | Self: 0.0% (4.0ms) | Total: 0.0% (4.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `clear`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:364` | Self: 0.0% (3.9ms) | Total: 0.0% (3.9ms) | Samples: 2

**Called by:**
- `seatMeasuredMarkers` (2)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:286` | Self: 0.0% (3.9ms) | Total: 0.0% (3.9ms) | Samples: 3

**Called by:**
- `validatePaint` (3)

### `terminalEndpoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` | Self: 0.0% (3.9ms) | Total: 0.0% (3.9ms) | Samples: 1

**Called by:**
- `deriveConnectorTerminalProjection` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` | Self: 0.0% (3.9ms) | Total: 0.0% (3.9ms) | Samples: 1

**Called by:**
- `filter` (1)

### `outputDescriptorsById`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` | Self: 0.0% (3.9ms) | Total: 0.0% (3.9ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `parseEncodeTrie`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:45` | Self: 0.0% (3.9ms) | Total: 0.0% (3.9ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `assertInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:12` | Self: 0.0% (3.9ms) | Total: 0.0% (3.9ms) | Samples: 3

**Called by:**
- `validateNode` (2)
- `group` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:274` | Self: 0.0% (3.9ms) | Total: 0.1% (6.6ms) | Samples: 2

**Called by:**
- `writeTextSvg` (4)

**Calls:**
- `formatSvgNumber` (1)
- `formatSvgNumber` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:774` | Self: 0.0% (3.9ms) | Total: 0.4% (21.0ms) | Samples: 2

**Called by:**
- `write` (10)
- `node` (1)

**Calls:**
- `stringify` (7)
- `add` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:705` | Self: 0.0% (3.9ms) | Total: 0.1% (7.8ms) | Samples: 1

**Called by:**
- `runMeasuredGraphBackend` (1)
- `map` (1)

**Calls:**
- `map` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:67` | Self: 0.0% (3.8ms) | Total: 0.0% (3.8ms) | Samples: 1

**Called by:**
- `inspectPaint` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:133` | Self: 0.0% (3.8ms) | Total: 0.0% (3.8ms) | Samples: 2

**Called by:**
- `nativeGroup` (2)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:118` | Self: 0.0% (3.8ms) | Total: 25.4% (1.10s) | Samples: 3

**Called by:**
- `lowerClassDrawing` (193)
- `renderClassBox` (181)
- `renderClassBox` (64)
- `(anonymous)` (63)
- `renderClassBox` (44)
- `renderClassBox` (28)
- `renderClassBox` (27)
- `renderRelationshipLabels` (9)
- `lowerClassDrawing` (3)
- `lowerClassDrawing` (1)
- `lowerClassDrawing` (1)

**Calls:**
- `leaf` (281)
- `leaf` (259)
- `leaf` (30)
- `leaf` (10)
- `leaf` (7)
- `leaf` (6)
- `leaf` (5)
- `leaf` (3)
- `leaf` (2)
- `leaf` (2)
- `leaf` (2)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)

### `open`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1429` | Self: 0.0% (3.7ms) | Total: 0.0% (3.7ms) | Samples: 1

**Called by:**
- `serialization` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.0% (3.7ms) | Total: 0.0% (3.7ms) | Samples: 1

**Called by:**
- `join` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:337` | Self: 0.0% (3.7ms) | Total: 0.1% (5.5ms) | Samples: 1

**Called by:**
- `connector` (2)

**Calls:**
- `copyDataProperties` (1)

### `classNativeMarkerMinimums`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:194` | Self: 0.0% (3.7ms) | Total: 0.1% (4.8ms) | Samples: 3

**Called by:**
- `(anonymous)` (4)

**Calls:**
- `pay` (1)

### `classRelationshipLineStyle`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1610` | Self: 0.0% (3.7ms) | Total: 0.0% (3.7ms) | Samples: 1

**Called by:**
- `renderRelationship` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:560` | Self: 0.0% (3.7ms) | Total: 0.1% (4.9ms) | Samples: 1

**Called by:**
- `map` (2)

**Calls:**
- `charge` (1)

### `sort`
`[native code]` | Self: 0.0% (3.6ms) | Total: 0.1% (7.4ms) | Samples: 3

**Called by:**
- `detectRegisteredFamilyDescriptorFromFirstLine` (3)
- `applyReplacements` (1)
- `(module)` (1)
- `canonicalJson` (1)

**Calls:**
- `compareCodePointStrings` (1)
- `(anonymous)` (1)
- `compareCodePointStrings` (1)

### `assertFinalBoundaryContacts`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` | Self: 0.0% (3.6ms) | Total: 0.0% (3.6ms) | Samples: 1

**Called by:**
- `finalizeFlatMeasuredMarkers` (1)

### `crossSize`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:33` | Self: 0.0% (3.6ms) | Total: 0.0% (3.6ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:142` | Self: 0.0% (3.6ms) | Total: 0.0% (3.6ms) | Samples: 2

**Called by:**
- `lowerClassDrawing` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:759` | Self: 0.0% (3.5ms) | Total: 0.0% (3.5ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1061` | Self: 0.0% (3.5ms) | Total: 0.0% (3.5ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `assessFamilyLayout`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` | Self: 0.0% (3.5ms) | Total: 0.0% (3.5ms) | Samples: 1

**Called by:**
- `assessRenderedLayoutHardViolations` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` | Self: 0.0% (3.4ms) | Total: 0.1% (7.3ms) | Samples: 2

**Called by:**
- `(anonymous)` (4)

**Calls:**
- `add` (2)

### `repairClassAnnotationSeats`
`/tmp/pr449-main-integration-20261029-762/src/class/annotation-seats.ts` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (1)

### `records`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `pose` (1)

### `createValidationState`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `assertKnownConnectorFields`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `connector` (1)

### `pointsBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:13` | Self: 0.0% (3.4ms) | Total: 0.3% (14.4ms) | Samples: 2

**Called by:**
- `geometryBounds` (5)
- `include` (1)
- `markerBoundsAt` (1)

**Calls:**
- `map` (5)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:737` | Self: 0.0% (3.3ms) | Total: 0.2% (9.4ms) | Samples: 2

**Called by:**
- `write` (5)
- `node` (1)

**Calls:**
- `localPaintResourceReferences` (4)

### `writtenPoint`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 1

**Called by:**
- `classOwnedSurfaceViolations` (1)

### `transferRetainedPixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:88` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 2

**Called by:**
- `copyInner` (2)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:396` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 2

**Called by:**
- `assertClassMarkerMeaning` (1)
- `connector` (1)

### `sharpContactsClear`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:371` | Self: 0.0% (3.3ms) | Total: 0.2% (9.8ms) | Samples: 2

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (6)

**Calls:**
- `min` (3)
- `max` (1)

### `renderRelationshipMarkerOverlay`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:633` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 3

**Called by:**
- `(anonymous)` (3)

### `/\s/`
`[native code]` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `skipSeparators` (2)

### `semanticIdentityForSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:51` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `group` (2)

### `append`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:239` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 3

**Called by:**
- `leaf` (3)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:448` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 1

**Called by:**
- `connector` (1)

### `sourceAdapter`
`/tmp/pr449-main-integration-20261029-762/src/agent/stable-family-source-hooks.ts` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `attribute` (2)

### `renderRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:560` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `lowerClassDrawing` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1208` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `write` (2)

### `writtenDecimalParts`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:32` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `compareSvgSum` (1)
- `compareSvgSum` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:87` | Self: 0.0% (3.1ms) | Total: 0.0% (4.2ms) | Samples: 2

**Called by:**
- `svgStyleRanges` (2)
- `nativeGroup` (1)

**Calls:**
- `startsWith` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:585` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `clip`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:84` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:386` | Self: 0.0% (3.1ms) | Total: 1.5% (68.2ms) | Samples: 3

**Called by:**
- `lowerClassDrawing` (35)

**Calls:**
- `leaf` (28)
- `renderDivider` (2)
- `renderDivider` (1)
- `renderDivider` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `sharpContactsClear`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:355` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 2

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (2)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 2

**Called by:**
- `visit` (1)
- `visit` (1)

### `pose`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:336` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 2

**Called by:**
- `seatMeasuredMarkers` (2)

### `classTextBlock`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `finishClassLayout` (1)

### `classCommentStart`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:369` | Self: 0.0% (3.0ms) | Total: 0.0% (4.0ms) | Samples: 2

**Called by:**
- `classStatement` (3)

**Calls:**
- `test` (1)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:474` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `diagramColorVariables` (1)

### `label`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1491` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `toHex`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:42` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 2

**Called by:**
- `toneOnFill` (2)

### `splitAuthoredClassLine`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:99` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `circleMarkerResources`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `flowchartMarkerResources` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:318` | Self: 0.0% (3.0ms) | Total: 0.1% (4.7ms) | Samples: 1

**Called by:**
- `validateNode` (1)
- `validateNode` (1)

**Calls:**
- `numericCss` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:401` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 2

**Called by:**
- `lowerClassDrawing` (2)

### `escapeAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `renderClassBox` (1)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:368` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `group` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:596` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 2

**Called by:**
- `writeConnectorSvg` (2)

### `pose`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:333` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `seatMeasuredMarkers` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 2

**Called by:**
- `validateMarker` (2)

### `prepared`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:715` | Self: 0.0% (2.9ms) | Total: 0.1% (5.4ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (3)

**Calls:**
- `get` (2)

### `nonPainting`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:134` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:93` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 2

**Called by:**
- `projectSvgCss` (1)
- `svgStyleRanges` (1)

### `/<!--[\s\S]*?-->/g`
`[native code]` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `replace` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:285` | Self: 0.0% (2.9ms) | Total: 0.2% (11.7ms) | Samples: 2

**Called by:**
- `lowerClassDrawing` (7)

**Calls:**
- `escapeDisplayAttr` (4)
- `escapeAttr` (1)

### `skip`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 2

**Called by:**
- `pathBounds` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1084` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `write` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 2

**Called by:**
- `map` (2)

### `transformedBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 2

**Called by:**
- `connectorPaintBounds` (1)
- `include` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:738` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `color` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:729` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `resolveCss` (1)

### `typedIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:74` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `shape` (1)

### `pointsBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:16` | Self: 0.0% (2.8ms) | Total: 0.1% (4.5ms) | Samples: 1

**Called by:**
- `include` (1)
- `markerTerminalDepth` (1)

**Calls:**
- `map` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:446` | Self: 0.0% (2.8ms) | Total: 0.7% (33.5ms) | Samples: 1

**Called by:**
- `(anonymous)` (22)

**Calls:**
- `(anonymous)` (21)

### `isHexColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:143` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `resolvedColorValue` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:164` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 2

**Called by:**
- `classOwnedSurfaceViolations` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 2

**Called by:**
- `(anonymous)` (1)
- `attribute` (1)

### `toHex`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `toneOnFill` (2)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:324` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `BigInt`
`[native code]` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `writtenDecimalParts` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:168` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `consumeStringBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:406` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `write` (1)
- `validateNodeSerialization` (1)

### `snapshot`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:275` | Self: 0.0% (2.7ms) | Total: 0.6% (27.6ms) | Samples: 2

**Called by:**
- `group` (13)
- `leaf` (3)
- `documentOpen` (2)

**Calls:**
- `copyInner` (7)
- `copyInner` (5)
- `copyInner` (2)
- `copyInner` (1)
- `copyInner` (1)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:435` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `group` (2)

### `inRanges`
`/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:114` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `isWideRange` (1)
- `isZeroWidth` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:350` | Self: 0.0% (2.7ms) | Total: 0.1% (5.7ms) | Samples: 1

**Called by:**
- `forEach` (3)

**Calls:**
- `transformedBounds` (1)
- `transformPoint` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:239` | Self: 0.0% (2.7ms) | Total: 0.1% (8.3ms) | Samples: 2

**Called by:**
- `verifyDocumentEnvelope` (4)

**Calls:**
- `readXmlReferenceEnd` (1)
- `readXmlReferenceEnd` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:315` | Self: 0.0% (2.6ms) | Total: 0.6% (29.1ms) | Samples: 2

**Called by:**
- `validateMarker` (5)
- `validateNode` (3)
- `validateNode` (1)

**Calls:**
- `numericCss` (3)
- `numericCss` (3)
- `numericCss` (1)

### `normalizeCssObfuscation`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:37` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `unsafeCssReferences` (1)
- `inspectAttributeSecurity` (1)

### `cloneValue`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` | Self: 0.0% (2.6ms) | Total: 0.3% (14.9ms) | Samples: 2

**Called by:**
- `(anonymous)` (6)
- `map` (3)
- `sharedRenderOptionsJsonSchema` (2)

**Calls:**
- `map` (9)

### `flatIntoArray`
`[native code]` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `Map`
`[native code]` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `retainClassRectangleContacts` (1)
- `assessFamilyLayout` (1)

### `sceneNodeWrite`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `write` (1)

### `indexOf`
`[native code]` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `parseExtensionId` (1)
- `scanStartTags` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1475` | Self: 0.0% (2.6ms) | Total: 0.2% (12.9ms) | Samples: 2

**Called by:**
- `serialize` (7)

**Calls:**
- `consumeStringBudget` (3)
- `consumeStringBudget` (1)
- `consumeStringBudget` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:230` | Self: 0.0% (2.6ms) | Total: 0.2% (9.9ms) | Samples: 2

**Called by:**
- `connector` (4)
- `assertClassMarkerMeaning` (1)

**Calls:**
- `assertKnownConnectorFields` (1)
- `assertKnownConnectorFields` (1)
- `assertKnownConnectorFields` (1)

### `writtenSegmentEntersBox`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:87` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `writtenClassRoundedHit` (2)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:109` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `projectSvgCss` (1)
- `svgStyleRanges` (1)

### `validateRoleStyleRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `validateRoleStyles` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/shared/diagram-limits.ts:16` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:726` | Self: 0.0% (2.5ms) | Total: 0.2% (9.9ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (7)

**Calls:**
- `xmlRange` (5)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 2

**Called by:**
- `write` (2)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:319` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 2

**Called by:**
- `validateMarker` (1)
- `validateNode` (1)

### `clear`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:367` | Self: 0.0% (2.5ms) | Total: 0.1% (5.5ms) | Samples: 2

**Called by:**
- `seatMeasuredMarkers` (4)

**Calls:**
- `intersects` (1)
- `intersects` (1)

### `semanticIdentityForSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:56` | Self: 0.0% (2.5ms) | Total: 0.3% (13.8ms) | Samples: 2

**Called by:**
- `group` (8)

**Calls:**
- `attr` (4)
- `filter` (1)
- `attr` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` | Self: 0.0% (2.5ms) | Total: 0.3% (14.4ms) | Samples: 2

**Called by:**
- `leaf` (8)

**Calls:**
- `nonPainting` (3)
- `nonPainting` (1)
- `every` (1)
- `nonPainting` (1)

### `assertRenderableMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 2

**Called by:**
- `validateMarker` (2)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:299` | Self: 0.0% (2.5ms) | Total: 0.0% (3.7ms) | Samples: 2

**Called by:**
- `connector` (3)

**Calls:**
- `map` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:776` | Self: 0.0% (2.5ms) | Total: 0.1% (8.0ms) | Samples: 2

**Called by:**
- `write` (2)
- `node` (2)

**Calls:**
- `stringify` (2)

### `color`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1039` | Self: 0.0% (2.5ms) | Total: 0.3% (13.4ms) | Samples: 1

**Called by:**
- `prepareMarkerPolygonInk` (4)

**Calls:**
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:106` | Self: 0.0% (2.5ms) | Total: 0.1% (6.9ms) | Samples: 1

**Called by:**
- `withDeferredTerminalProjections` (4)

**Calls:**
- `leaf` (3)

### `transformedBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:471` | Self: 0.0% (2.5ms) | Total: 0.2% (9.2ms) | Samples: 1

**Called by:**
- `connectorPaintBounds` (1)
- `connectorPaintBounds` (1)

**Calls:**
- `every` (1)

### `nativeTextPaintWriteOf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:68` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `continuesClassText`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:553` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `readClassStatements` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1033` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 2

**Called by:**
- `write` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `map` (1)

### `scoreMeasuredRouteCrossingsWithAdmission`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:839` | Self: 0.0% (2.5ms) | Total: 0.2% (9.1ms) | Samples: 2

**Called by:**
- `validate` (5)
- `(anonymous)` (1)

**Calls:**
- `orthogonal` (3)
- `orthogonal` (1)

### `oneOf`
`/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `finiteNumber`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:177` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `svgPathDataProblem` (2)

### `work`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `pay` (1)

### `retainNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/experimental/position-cache.ts` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `map` (1)
- `from` (1)

### `validatePoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `validateGeometry` (1)
- `validateGeometry` (1)

### `Segmenter`
`[native code]` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `(module)` (2)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1463` | Self: 0.0% (2.4ms) | Total: 5.7% (251.8ms) | Samples: 2

**Called by:**
- `serialize` (136)

**Calls:**
- `validateNode` (22)
- `validateNode` (14)
- `validateNode` (10)
- `validateNode` (9)
- `validateNode` (9)
- `validateNode` (6)
- `validateNode` (5)
- `validateNode` (4)
- `validateNode` (4)
- `validateNode` (4)
- `validateNode` (3)
- `validateNode` (3)
- `validateNode` (3)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:87` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `visit` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:49` | Self: 0.0% (2.4ms) | Total: 1.6% (72.6ms) | Samples: 2

**Called by:**
- `join` (38)
- `group` (2)

**Calls:**
- `indent` (23)
- `indent` (9)
- `issue` (2)
- `issue` (2)
- `(anonymous)` (1)
- `indent` (1)

### `/^(?:0\|[1-9]\d*)$/`
`[native code]` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `omitUndefinedObjectFields`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:963` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `omitUndefinedObjectFields` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:612` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `assertMarkerPaint`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:27` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `transferSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `renderClassBox` (1)

### `connectorEndpointAnchors`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:444` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `connectorMarkerPaintRegions` (1)

### `dependencyArrowMarker`
`/tmp/pr449-main-integration-20261029-762/src/gantt/dependency-paint.ts:5` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `escapeXml`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:97` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 2

**Called by:**
- `escapeAttr` (2)

### `issue`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:92` | Self: 0.0% (2.3ms) | Total: 0.0% (3.7ms) | Samples: 1

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `freeze` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:976` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `relationAccessibility`
`/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` | Self: 0.0% (2.3ms) | Total: 0.0% (4.1ms) | Samples: 1

**Called by:**
- `connector` (2)

**Calls:**
- `sceneRoleTraits` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:334` | Self: 0.0% (2.3ms) | Total: 0.2% (8.9ms) | Samples: 1

**Called by:**
- `forEach` (4)

**Calls:**
- `stringify` (3)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `diagramColorVariables` (1)

### `max`
`[native code]` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `sharpContactsClear` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:183` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `seatFinalMeasuredMarkers` (1)

### `validateRoleStyles`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:340` | Self: 0.0% (2.3ms) | Total: 0.1% (4.9ms) | Samples: 1

**Called by:**
- `validateStyleSpec` (2)

**Calls:**
- `validateRoleStyleRecord` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:536` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `writeConnectorSvg` (1)

### `clear`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:379` | Self: 0.0% (2.3ms) | Total: 0.0% (3.5ms) | Samples: 2

**Called by:**
- `seatMeasuredMarkers` (3)

**Calls:**
- `charge` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `rectanglePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:323` | Self: 0.0% (2.2ms) | Total: 0.1% (6.8ms) | Samples: 2

**Called by:**
- `rectangleInput` (5)

**Calls:**
- `getOwnPropertyDescriptor` (3)

### `scoreMeasuredRouteCrossingsWithAdmission`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:753` | Self: 0.0% (2.2ms) | Total: 0.2% (11.1ms) | Samples: 1

**Called by:**
- `validate` (4)
- `(anonymous)` (3)

**Calls:**
- `separatedSharpSupports` (4)
- `separatedSharpSupportBounds` (1)
- `separatedSharpSupportBounds` (1)

### `classNativeMarkerMinimums`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:197` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:403` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 2

**Called by:**
- `assertClassMarkerMeaning` (1)
- `connector` (1)

### `Set`
`[native code]` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 2

**Called by:**
- `rejectUnknownKeys` (1)
- `validateDescriptor` (1)

### `/var\(--([\w-]+)\)/g`
`[native code]` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `replace` (1)

### `attr`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `semanticIdentityForSvg` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:552` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 2

**Called by:**
- `writeShapeSvg` (2)

### `install`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:41` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `setConnectorTerminalProjection` (1)

### `validatePoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:462` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `validateGeometry` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `filter` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:686` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `map` (1)

### `tipAnchoredArrow`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `supportedRelationEndpoint`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1515` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `parseClassRelationEndpoints` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:796` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:910` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `write` (1)

### `imul`
`[native code]` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 2

**Called by:**
- `(module)` (2)

### `(anonymous)`
`/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:11` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `measureRenderStage` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:164` | Self: 0.0% (2.1ms) | Total: 0.1% (5.4ms) | Samples: 2

**Called by:**
- `withDeferredTerminalProjections` (4)

**Calls:**
- `leaf` (1)
- `documentClose` (1)

### `inspectOwnedSvgOnce`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `applyOutputSecurityPolicy` (1)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `ownConnectorEndpoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:191` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `connector` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 2

**Called by:**
- `leaf` (2)

### `parseMarkerlessClassRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1415` | Self: 0.0% (2.1ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `parseClassRelationship` (2)

**Calls:**
- `parseClassReference` (1)

### `ActualTextPaintWrite`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:393` | Self: 0.0% (2.1ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `writeTextSvg` (2)

**Calls:**
- `(anonymous)` (1)

### `measureTextWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:146` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `assertKnownConnectorFields`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:160` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `connector` (1)

### `multiplySceneOpacity`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `visit` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:541` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `validateNodeSerialization` (1)

### `sanitizeDisplayLines`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` | Self: 0.0% (2.1ms) | Total: 0.1% (4.6ms) | Samples: 2

**Called by:**
- `escapeDisplayAttr` (3)

**Calls:**
- `map` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:136` | Self: 0.0% (2.1ms) | Total: 26.7% (1.16s) | Samples: 1

**Called by:**
- `withDeferredTerminalProjections` (624)

**Calls:**
- `renderClassBox` (199)
- `renderClassBox` (66)
- `renderClassBox` (47)
- `group` (44)
- `group` (38)
- `renderClassBox` (35)
- `renderClassBox` (34)
- `renderClassBox` (32)
- `group` (27)
- `group` (22)
- `group` (14)
- `group` (14)
- `group` (13)
- `renderClassBox` (7)
- `renderClassBox` (2)
- `group` (2)
- `renderClassBox` (2)
- `group` (2)
- `renderClassBox` (2)
- `renderClassBox` (2)
- `group` (2)
- `group` (2)
- `renderClassBox` (2)
- `group` (2)
- `group` (2)
- `group` (1)
- `group` (1)
- `renderClassBox` (1)
- `push` (1)
- `group` (1)
- `renderClassBox` (1)
- `renderClassBox` (1)
- `renderClassBox` (1)
- `group` (1)

### `sameRectanglePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:357` | Self: 0.0% (2.0ms) | Total: 0.2% (9.1ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `pay` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:206` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:169` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `compositeCssColor` (1)

### `classRelationText`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1330` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `parseClassRelationEndpoints` (1)

### `raw`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `element` (1)

### `/--([\w-]+)\s*:\s*([^;{}]+)/g`
`[native code]` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `next` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:714` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `map` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:351` | Self: 0.0% (2.0ms) | Total: 0.0% (3.8ms) | Samples: 1

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `readXmlDataEnd` (1)

### `copyProps`
`internal:primordials` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `makeSafe` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:441` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `measureClassCards` (1)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:436` | Self: 0.0% (1.9ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `validatePoints` (1)
- `validateNode` (1)

**Calls:**
- `finite` (1)

### `lazyGraphicalArtifact`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `withSvgInspectionCache` (1)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:35` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:109` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `shape` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:360` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `renderDivider`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:409` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `renderClassBox` (1)

### `boundedString`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `validateMarker` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `every` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:844` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1102` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `write` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:6` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1808` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `connectorInlineLabelSvg` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:718` | Self: 0.0% (1.8ms) | Total: 0.1% (5.0ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (3)

**Calls:**
- `compareSvgSum` (1)
- `compareSvgSum` (1)

### `layoutMeasuredForest`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1029` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `write` (1)

### `compareSvgSum`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:40` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `writtenSegmentEntersBox` (1)

### `measureTextWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:206` | Self: 0.0% (1.8ms) | Total: 0.1% (7.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `measureText` (4)

### `sameRectanglePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:348` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `normalizeCssObfuscation`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:27` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `unsafeCssReferences` (1)

### `world`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:23` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `map` (1)

### `terminalMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:55` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `deriveConnectorTerminalProjection` (1)

### `viewportBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `resolveSceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `sceneRoleTraits` (1)

### `assertMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:58` | Self: 0.0% (1.8ms) | Total: 0.0% (3.8ms) | Samples: 1

**Called by:**
- `connector` (2)

**Calls:**
- `entries` (1)

### `serializeMarkerResource`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:141` | Self: 0.0% (1.8ms) | Total: 0.1% (8.5ms) | Samples: 1

**Called by:**
- `map` (2)
- `createFixture` (1)

**Calls:**
- `geometryElements` (1)
- `geometryElements` (1)

### `serializeMarkerResource`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:123` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:24` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `map` (1)

### `sameRectanglePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:358` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `xmlSlice`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `isPlainRecord`
`/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `validate` (1)

### `compactProvedPath`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-portal-channel.ts:428` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `finalizeFlatMeasuredMarkers` (1)

### `validatePoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:455` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `validateGeometry` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1088` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `write` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:275` | Self: 0.0% (1.7ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `add` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:549` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `some` (1)

### `validateStyleSpec`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:427` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `registerBuiltInStyle` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:204` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `group` (1)

### `boundedString`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:262` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `optional`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:49` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `terminalMarker` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:826` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:235` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `connector` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:349` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:685` | Self: 0.0% (1.7ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `identityAttributes` (1)

### `authoredClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `parseClassDiagram` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `paintedStrokeExtent` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1467` | Self: 0.0% (1.7ms) | Total: 6.0% (265.3ms) | Samples: 1

**Called by:**
- `serialize` (142)

**Calls:**
- `serializeSceneNode` (129)
- `serializeSceneNode` (3)
- `serializeSceneNode` (2)
- `serializeSceneNode` (2)
- `issue` (2)
- `sceneNodeWrite` (1)
- `serializeSceneNode` (1)
- `issue` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `map` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:639` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `writeConnectorSvg` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:284` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `createFixture` (1)

### `addClassSvgNumbers`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:66` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `projectClassRectangleContacts` (1)

### `retainRequestGraphLayoutDecision`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `delete`
`/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `set` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:161` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `some` (1)

### `sharpContactsClear`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:369` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:262` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:96` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `shape` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:836` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `write` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:176` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `setConnectorTerminalProjection` (1)

### `assertMarkerPaint`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:28` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `legibleInk`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:137` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `toneOnFill` (1)

### `parseMarkedClassRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1320` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `classifyClassStatement` (1)

### `orthogonal`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `schemaMatchesRuntimeKind`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:41` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `filter` (1)

### `pose`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:317` | Self: 0.0% (1.6ms) | Total: 0.1% (5.1ms) | Samples: 1

**Called by:**
- `seatMeasuredMarkers` (2)

**Calls:**
- `records` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:146` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:387` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `connector` (1)

### `read`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:76` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `pathBounds` (1)

### `writtenDecimalParts`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:31` | Self: 0.0% (1.6ms) | Total: 0.1% (4.4ms) | Samples: 1

**Called by:**
- `compareSvgSum` (2)

**Calls:**
- `BigInt` (1)

### `transformPoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:19` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `include` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:127` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `withDeferredTerminalProjections` (1)

### `expectedCapabilityState`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1645` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `validateDescriptor` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:272` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `include` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:26` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `some` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1094` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `validateJsonConfigAdmission`
`/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts:216` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `renderOptionsAdmissionMessages` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1021` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `snapshotDescriptorArray`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1498` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `snapshotFamilyConfig` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:625` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `geometryElements`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `serializeMarkerResource` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:193` | Self: 0.0% (1.5ms) | Total: 0.5% (25.7ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (14)

**Calls:**
- `serialization` (12)
- `serialization` (1)

### `assessFamilyLayout`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:266` | Self: 0.0% (1.5ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `assessRenderedLayoutHardViolations` (2)

**Calls:**
- `rectOverlap` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:725` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:484` | Self: 0.0% (1.5ms) | Total: 0.3% (14.9ms) | Samples: 1

**Called by:**
- `identityAttributes` (4)
- `writeConnectorSvg` (1)
- `hooks` (1)
- `identityAttributes` (1)
- `typographyAttributes` (1)
- `writeConnectorSvg` (1)
- `identityAttributes` (1)

**Calls:**
- `escapeAttr` (6)
- `escapeAttr` (3)

### `inertRectangleRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `rectangleInput` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:988` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:283` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:499` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `text` (1)

### `renderRelationshipMarkerOverlay`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:661` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `ownerSnapshot`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `nativePaintAncestors` (1)

### `work`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `readXmlReferenceEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `readXmlDataEnd` (1)

### `now`
`[native code]` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `safeCssPaint`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:134` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `selfContact`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `validate` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1211` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `write` (1)

### `ActualTextPaintWrite`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `createEmissionContext`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `createNativePaintEmission` (1)

### `layoutMeasuredForest`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:40` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `writtenSegmentEntersBox`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:96` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `writtenClassRoundedHit` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:185` | Self: 0.0% (1.5ms) | Total: 0.1% (6.1ms) | Samples: 1

**Called by:**
- `copyInner` (3)
- `leaf` (1)

**Calls:**
- `transferRetainedPixelText` (2)
- `transferRetainedPixelText` (1)

### `connectorMarkerPaintRegions`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:319` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `scopeSvgStyles` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` | Self: 0.0% (1.5ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `paintedStrokeExtent` (1)
- `relativeLuminance` (1)

**Calls:**
- `trim` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:546` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `visit` (1)

### `skip`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:62` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `pathBounds` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:62` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `map` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:511` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `indent`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:235` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `classRelationshipEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `renderRelationshipMarkerOverlay` (1)

### `get conformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:496` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `retainedNativeDrawing` (1)

### `ownConnectorEndpoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `connector` (1)

### `(anonymous)`
`/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `from` (1)

### `charge`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:96` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `clear` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `scopeSvgStyles` (1)

### `createEmissionContext`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:22` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `createNativePaintEmission` (1)

### `ensureSvgIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:81` | Self: 0.0% (1.4ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `group` (2)

**Calls:**
- `match` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:86` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `inspectPaint` (1)

### `readXmlNameEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:119` | Self: 0.0% (1.4ms) | Total: 1.7% (74.3ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (39)
- `verifyDocumentEnvelope` (4)

**Calls:**
- `xmlNameCharacter` (42)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1802` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `some` (1)

### `createNativeSceneValidator`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2361` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `roleStyleJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:494` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `styleSpecJsonSchema` (1)

### `seatFinalMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `finalizeFlatMeasuredMarkers` (1)

### `scanSvgStartTagsFresh`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `nativeGroup` (1)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:369` | Self: 0.0% (1.4ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `group` (2)

**Calls:**
- `push` (1)

### `createPaintRecorder`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:243` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `createOwnedNativePaintRecorder` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:510` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `/[^\x00-\x7f]/`
`[native code]` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `boundedUtf8ByteLength` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:979` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `map` (1)

### `svgOpenTag`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:83` | Self: 0.0% (1.4ms) | Total: 0.1% (6.9ms) | Samples: 1

**Called by:**
- `inspectPaint` (5)

**Calls:**
- `nativePaintAncestors` (2)
- `nativePaintAncestors` (1)
- `nativePaintAncestors` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:598` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `seatMeasuredMarkers` (1)

### `ownConnectorEndpoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:190` | Self: 0.0% (1.4ms) | Total: 0.1% (6.1ms) | Samples: 1

**Called by:**
- `connector` (2)

**Calls:**
- `copyDataProperties` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:16` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `classRelationshipTerminalClearance` (1)

### `document/identity/serialize`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:512` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:116` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `projectSvgCss` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:422` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `connector` (1)

### `node:zlib`
`node:zlib:2` | Self: 0.0% (1.4ms) | Total: 0.5% (26.0ms) | Samples: 1

**Calls:**
- `anonymous` (11)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:584` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `projectClassRectangleContacts`
`/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:194` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `renderClassBox` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:236` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `measureRenderStage` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:292` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `crossSize`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `finishClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `runMeasuredGraphBackend` (1)

### `terminalMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:56` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `deriveConnectorTerminalProjection` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:808` | Self: 0.0% (1.4ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `attribute` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:217` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:282` | Self: 0.0% (1.4ms) | Total: 0.1% (7.6ms) | Samples: 1

**Called by:**
- `connector` (4)
- `assertClassMarkerMeaning` (1)

**Calls:**
- `connectorGeometryEndpoints` (2)
- `connectorGeometryEndpoints` (1)
- `connectorGeometryEndpoints` (1)

### `read`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:64` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `pathBounds` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:719` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `write` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1031` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `write` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `seatFinalMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:475` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `finalizeFlatMeasuredMarkers` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:18` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `connector/stroke/render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `numberIsValid`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:280` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateStyleSpec` (1)

### `writeStructuredSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:594` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `validateConnectorProjectionConsistency`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:366` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `map` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateMarker` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:111` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `filter` (1)

### `boundedImmutableJsonSnapshot`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1242` | Self: 0.0% (1.3ms) | Total: 0.0% (3.8ms) | Samples: 1

**Called by:**
- `admitRenderContractDigestInput` (3)

**Calls:**
- `omitUndefinedObjectFields` (2)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:119` | Self: 0.0% (1.3ms) | Total: 0.1% (4.3ms) | Samples: 1

**Called by:**
- `shape` (3)

**Calls:**
- `copyDataProperties` (2)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:417` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector` (1)

### `intersects`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `clear` (1)

### `renderRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:589` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:112` | Self: 0.0% (1.3ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `finishClassLayout` (2)

**Calls:**
- `classRelationshipPaintBoxes` (1)

### `decodeWithTrie`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:456` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `parseClassInteractionWithAuthored` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:263` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `seatFinalMeasuredMarkers` (1)

### `hasOwned`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `qualify` (1)

### `NativeZlib`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Zlib` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:712` | Self: 0.0% (1.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `replaceField` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1019` | Self: 0.0% (1.3ms) | Total: 1.6% (73.2ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (20)

**Calls:**
- `connectorMarkerPaintRegions` (15)
- `connectorMarkerPaintRegions` (2)
- `copyDataProperties` (1)
- `proofRecord` (1)

### `isWideRange`
`/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:128` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `getCharWidth` (1)

### `assertInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:32` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `group` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:696` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `classStatementEnds` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:276` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:405` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `declareFamilyScenePrimitiveEvidence`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `completeBuiltinDescriptor` (1)

### `luminanceContrastRatio`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:73` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `ensureContrast` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:233` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connectorPaintBounds` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:552` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `assertFinalClassSharpContacts` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1755` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:667` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:262` | Self: 0.0% (1.3ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `copyDataProperties` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:530` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `text` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1742` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `find` (1)

### `trim`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `tryParseCssColor` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:357` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:432` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `extractClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:457` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:258` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `createFixture` (1)

### `measureClassCards`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:185` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `layoutClassDiagram` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:173` | Self: 0.0% (1.3ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `compositeCssColor` (1)
- `color` (1)

**Calls:**
- `slice` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` | Self: 0.0% (1.3ms) | Total: 0.6% (26.1ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (16)

**Calls:**
- `geometryAttributes` (7)
- `geometryAttributes` (3)
- `geometryAttributes` (2)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)

### `canonicalJson`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1097` | Self: 0.0% (1.3ms) | Total: 0.0% (4.0ms) | Samples: 1

**Called by:**
- `map` (1)
- `canonicalJson` (1)
- `(anonymous)` (1)

**Calls:**
- `canonicalJson` (1)
- `canonicalJson` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2083` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `sort` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:581` | Self: 0.0% (1.3ms) | Total: 0.0% (4.0ms) | Samples: 1

**Called by:**
- `write` (3)

**Calls:**
- `isFrozen` (1)
- `set` (1)

### `pose`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:329` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `seatMeasuredMarkers` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `factOf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:110` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `filter` (1)

### `/^(?:#[0-9a-f]{3,4}\|#[0-9a-f]{6}\|#[0-9a-f]{8}\|[a-z][a-z0-9-]*)$/i`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `safeCssToken` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:418` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector` (1)

### `getOwnPropertyDescriptors`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `reduce`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.2% (10.7ms) | Samples: 1

**Called by:**
- `advance` (7)

**Calls:**
- `(anonymous)` (6)

### `get`
`/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `mainSize`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:32` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `layoutMeasuredForest` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:341` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `map` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:843` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `write` (1)

### `extractClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:433` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `renderRelationshipMarkerOverlay`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:650` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `connectorContourSemantics`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:381` | Self: 0.0% (1.3ms) | Total: 0.2% (10.5ms) | Samples: 1

**Called by:**
- `connector` (3)

**Calls:**
- `connectorSubpaths` (2)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:138` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `seatFinalMeasuredMarkers` (1)

### `retainedLabelBounds`
`/tmp/pr449-main-integration-20261029-762/src/agent/layout-to-rendered.ts:17` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `retainedLabelGeometry` (1)

### `flatIntoArrayWithCallback`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.3% (16.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (3)
- `deriveConnectorTerminalProjection` (2)
- `resolveExecutionPlan` (1)
- `connectorPaintBounds` (1)
- `authoredClassStatements` (1)
- `(module)` (1)

**Calls:**
- `(anonymous)` (2)
- `map` (2)
- `splitAuthoredClassLine` (1)
- `executionOffer` (1)
- `flatIntoArray` (1)
- `(anonymous)` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:530` | Self: 0.0% (1.3ms) | Total: 0.3% (16.6ms) | Samples: 1

**Called by:**
- `validateNode` (13)

**Calls:**
- `svgPathDataProblem` (6)
- `svgPathDataProblem` (2)
- `svgPathDataProblem` (2)
- `svgPathDataProblem` (1)
- `svgPathDataProblem` (1)

### `parseClassRelationEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1399` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `parseMarkedClassRelationship` (1)

### `connector/relation/accessibility`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `validatePoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:465` | Self: 0.0% (1.3ms) | Total: 0.4% (18.9ms) | Samples: 1

**Called by:**
- `validateGeometry` (5)

**Calls:**
- `validatePoint` (1)
- `validatePoint` (1)
- `validatePoint` (1)
- `validatePoint` (1)

### `nonPainting`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:129` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `connectorEndpointAnchors`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:443` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connectorMarkerPaintRegions` (1)

### `applyReplacements`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:198` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `resolveSvgColors` (1)

### `rectanglePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `rectangleInput` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:511` | Self: 0.0% (1.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `connectorPaintBounds` (1)
- `markerBoundsAt` (1)

**Calls:**
- `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:152` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `every` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:311` | Self: 0.0% (1.2ms) | Total: 0.2% (8.8ms) | Samples: 1

**Called by:**
- `validateNode` (2)
- `validateMarker` (2)

**Calls:**
- `safeCssPaint` (1)
- `safeCssToken` (1)
- `safeCssToken` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:575` | Self: 0.0% (1.2ms) | Total: 5.6% (247.4ms) | Samples: 1

**Called by:**
- `write` (129)
- `drawn` (4)
- `(anonymous)` (2)
- `validateNodeSerialization` (1)

**Calls:**
- `writeShapeSvg` (23)
- `writeConnectorSvg` (16)
- `writeTextSvg` (15)
- `writeConnectorSvg` (9)
- `writeConnectorSvg` (7)
- `writeTextSvg` (7)
- `writeShapeSvg` (6)
- `writeShapeSvg` (4)
- `writeTextSvg` (3)
- `writeTextSvg` (3)
- `writeConnectorSvg` (3)
- `issue` (3)
- `issue` (3)
- `writeShapeSvg` (2)
- `writeConnectorSvg` (2)
- `writeTextSvg` (2)
- `writeConnectorSvg` (2)
- `writeShapeSvg` (2)
- `writeConnectorSvg` (2)
- `writeConnectorSvg` (2)
- `writeSceneNode` (2)
- `writeTextSvg` (2)
- `writeTextSvg` (2)
- `writeShapeSvg` (2)
- `writeConnectorSvg` (2)
- `writeSceneNode` (1)
- `writeConnectorSvg` (1)
- `writeTextSvg` (1)
- `writeConnectorSvg` (1)
- `writeTextSvg` (1)
- `writeTextSvg` (1)
- `writeConnectorSvg` (1)
- `writeTextSvg` (1)
- `writeStructuredSceneNode` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:744` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `parseClassDiagram` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:122` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `inspectOwnedSvgOnce` (1)

### `scoreMeasuredRouteCrossingsWithAdmission`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:718` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:680` | Self: 0.0% (1.2ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `map` (1)
- `measureRenderStage` (1)

**Calls:**
- `map` (1)

### `assertInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:16` | Self: 0.0% (1.2ms) | Total: 0.5% (22.5ms) | Samples: 1

**Called by:**
- `group` (7)
- `validateNode` (6)

**Calls:**
- `visitSvgFirstTagAttributes` (9)
- `test` (2)
- `/^\s*<g\b[^>]*>(?:<title>[^<]*<\/title>)?$/` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:104` | Self: 0.0% (1.2ms) | Total: 0.5% (24.4ms) | Samples: 1

**Called by:**
- `visitSvgFirstTagAttributes` (3)
- `svgStyleRanges` (3)
- `projectSvgCss` (2)
- `nativeGroup` (1)

**Calls:**
- `scanTagEnd` (5)
- `scanTagEnd` (2)
- `scanTagEnd` (1)

### `deepFreeze`
`/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:15` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `deepFreeze` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:604` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `parseExtensionId`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:202` | Self: 0.0% (1.2ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `sceneValidationMode` (1)
- `createExtensionIdentity` (1)

**Calls:**
- `indexOf` (1)

### `matchMermaidFrontmatter`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `mermaidFirstLine` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:701` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `classStatementEnds` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:844` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `write` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/agent/types.ts:1761` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:668` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `runMeasuredGraphBackend` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:317` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateMarker` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:392` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `ActualTextPaintWrite` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` | Self: 0.0% (1.2ms) | Total: 0.6% (27.6ms) | Samples: 1

**Called by:**
- `geometryAttributes` (6)
- `geometryAttributes` (1)
- `identityAttributes` (1)
- `geometryAttributes` (1)
- `hooks` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `identityAttributes` (1)

**Calls:**
- `formatSvgNumericAttribute` (4)
- `formatSvgNumericAttribute` (3)
- `formatSvgNumericAttribute` (2)
- `formatSvgNumber` (2)
- `formatSvgNumber` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:639` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `/^[A-Za-z0-9_-]+(?: [A-Za-z0-9_-]+)*$/`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `assertMarkAttributes` (1)

### `from`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (3.9ms) | Samples: 1

**Called by:**
- `(module)` (2)
- `knownBackendDescriptors` (1)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1063` | Self: 0.0% (1.2ms) | Total: 0.1% (6.7ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (2)

**Calls:**
- `unclipped` (1)

### `cachedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/experimental/position-cache.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `retainedNativeDrawing` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:586` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `createNativePaintEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `attr`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:53` | Self: 0.0% (1.2ms) | Total: 0.2% (8.8ms) | Samples: 1

**Called by:**
- `semanticIdentityForSvg` (4)
- `semanticIdentityForSvg` (1)

**Calls:**
- `RegExp` (4)

### `occurrence`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:755` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `finish` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `resolvedColorValue` (1)

### `diagramTitleBand`
`/tmp/pr449-main-integration-20261029-762/src/styles.ts:356` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `withClassTitle` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:330` | Self: 0.0% (1.2ms) | Total: 0.9% (41.3ms) | Samples: 1

**Called by:**
- `forEach` (11)

**Calls:**
- `markerBoundsAt` (4)
- `markerBoundsAt` (2)
- `pointsBounds` (1)
- `markerBoundsAt` (1)
- `pointsBounds` (1)
- `markerBoundsAt` (1)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:429` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validatePoints` (1)

### `connectorDirection`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:206` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `connector` (1)

### `classifyClassStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:537` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `readClassStatements` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:132` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:33` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `scopeSvgStyles` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:706` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `runMeasuredGraphBackend` (1)

### `escapeXml`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:95` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `escapeAttr` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-limits.ts:2` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

### `assertFinalClassSharpContacts`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `finalizeClassSurfaces` (1)

### `markPaintPrepared`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:325` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `nativePaintAncestors`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:197` | Self: 0.0% (1.2ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `visit` (2)

**Calls:**
- `apply` (1)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:435` | Self: 0.0% (1.2ms) | Total: 0.3% (14.5ms) | Samples: 1

**Called by:**
- `validateNode` (2)
- `validatePoints` (1)
- `validateMarker` (1)

**Calls:**
- `finite` (1)
- `finite` (1)
- `finite` (1)

### `sign`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `writtenSegmentEntersBox` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:759` | Self: 0.0% (1.2ms) | Total: 0.3% (15.7ms) | Samples: 1

**Called by:**
- `write` (9)
- `node` (1)

**Calls:**
- `boundedString` (8)
- `boundedString` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `classOwnedSurfaceViolations` (1)

### `collectPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1371` | Self: 0.0% (1.2ms) | Total: 0.1% (6.1ms) | Samples: 1

**Called by:**
- `localPaintResourceReferences` (4)

**Calls:**
- `localPaintResourceId` (3)

### `safeCssPaint`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:129` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `endsWith`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `set` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:661` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `visit` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:105` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `finishClassLayout` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:265` | Self: 0.0% (1.2ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `copyDataProperties` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:183` | Self: 0.0% (1.2ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `defineProperty` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1073` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `write` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:794` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `node` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1782` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `apply`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `nativePaintAncestors` (1)

### `dereferenceSchema`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `schemaMatchesRuntimeKind` (1)

### `SvgWriter`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `transferRetainedPixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `reserve`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `nativeGroup` (1)

### `admitRenderOptionsInput`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1293` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:428` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:93` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `finishClassLayout` (1)

### `parseClassInteractionWithAuthored`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:922` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `classifyClassStatement` (1)

### `topRoundedRectPath`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:843` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `renderClassBox` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:502` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `text` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:172` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `find` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:124` | Self: 0.0% (1.2ms) | Total: 0.2% (11.0ms) | Samples: 1

**Called by:**
- `copyInner` (4)
- `leaf` (2)
- `snapshot` (1)
- `copy` (1)

**Calls:**
- `deferredTerminalProjectionInput` (6)
- `deferredTerminalProjectionInput` (1)

### `immutableSnapshot`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1214` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `immutableSnapshot` (1)

### `renderRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:626` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1141` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `parseClassDiagram` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:207` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `markerBoundsAt` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `parseClassRelationEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1354` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `parseMarkedClassRelationship` (1)

### `rectOverlap`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `assessFamilyLayout` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:364` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `assertRenderableMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:88` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateMarker` (1)

### `createClassInterfaceAllocator`
`/tmp/pr449-main-integration-20261029-762/src/class/interface-occurrences.ts:21` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `parseClassDiagram` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1065` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `write` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:50` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `map` (1)

### `resolvedInlineColorAttribute`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:686` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `color` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:284` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `sourceEnvelopeMetadata`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:853` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `normalizeSource` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:591` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `nativePaintSource`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `geometryAttributes` (1)

### `nativePaintSource`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:227` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `renderRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:578` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/external-scene.ts:154` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `every` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:765` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `write` (1)

### `resetBuffer`
`internal:streams/writable` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `WritableState` (1)

### `writeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:608` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `node`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1447` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `group` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:440` | Self: 0.0% (1.1ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `connector` (2)

**Calls:**
- `copyDataProperties` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:168` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:637` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `finiteNumber`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:180` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `svgPathDataProblem` (1)

### `topRoundedRectPath`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:844` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `renderClassBox` (1)

### `scanInlineNamespaceStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `readClassStatements` (1)

### `unsafeThemeColorKeys`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `resolveAppearance` (1)

### `executionCapabilityKey`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1432` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `executionCapabilityDecision` (1)

### `get`
`/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:10` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1071` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:213` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:126` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `rejectUnknownKeys`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:153` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateMarkAttributes` (1)

### `serializeMarkerResource`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:137` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `rejectUnknownKeys`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateMarkAttributes` (1)

### `(anonymous)`
`node:zlib:456` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `normalizeMermaidRuntimeConfig`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `normalizeSource` (1)

### `executionOffer`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `validatePrimitiveCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:341` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `graphicalBackendCapabilityClaims` (1)

### `semanticIdentityForSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:57` | Self: 0.0% (1.1ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `group` (2)

**Calls:**
- `attr` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:284` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `rejectUnknownKeys`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:152` | Self: 0.0% (1.1ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `validateMarkAttributes` (2)

**Calls:**
- `Set` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:208` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `classNativeMarkerMinimums`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `transferSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:751` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `withRenderStageObserver`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:15` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:213` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateGeometry` (1)

### `isFrozen`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:161` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `setConnectorTerminalProjection` (1)

### `writeFileSync`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `writeFileSync` (1)
- `(module)` (1)

**Calls:**
- `writeFileSync` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1462` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `serialize` (1)

### `isExtensible`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `retainTextPaintPresence` (1)

### `flatMap`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `connectorPaintBounds` (1)

### `normalizedReference`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:595` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `unsafeCssReferences` (1)

### `validatePrimitiveCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:332` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateBackendCapabilities` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:605` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `distanceToSegment`
`/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `transformedHitDistance` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:114` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `measureRenderStage` (1)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:664` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:11` | Self: 0.0% (1.1ms) | Total: 80.0% (3.48s) | Samples: 1

**Calls:**
- `withRenderStageObserver` (1869)
- `withRenderStageObserver` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1035` | Self: 0.0% (1.1ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `write` (2)

**Calls:**
- `stringify` (1)

### `cloneFrontmatterMap`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `canonicalizeFrontmatterMap` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:724` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `write` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1199` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `filter` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:773` | Self: 0.0% (1.1ms) | Total: 0.1% (5.6ms) | Samples: 1

**Called by:**
- `write` (2)

**Calls:**
- `validateRole` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `documentClose`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:140` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:200` | Self: 0.0% (1.1ms) | Total: 0.2% (12.8ms) | Samples: 1

**Called by:**
- `renderClassBox` (9)

**Calls:**
- `ensureContrast` (3)
- `toHex` (2)
- `toHex` (2)
- `legibleInk` (1)

### `XmlLeafWrite`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:298` | Self: 0.0% (1.1ms) | Total: 0.1% (6.2ms) | Samples: 1

**Called by:**
- `SvgWriter` (4)

**Calls:**
- `xmlList` (3)

### `clear`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:369` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `seatMeasuredMarkers` (1)

### `compareCodePointStrings`
`/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `sort` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:293` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `assertClassMarkerMeaning` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:204` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `detectorClaims`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1595` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `find` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:879` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `node` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:346` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `matchingBrace`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:146` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `scopeCss` (1)

### `transformAttribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:531` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:138` | Self: 0.0% (1.0ms) | Total: 0.2% (10.7ms) | Samples: 1

**Called by:**
- `setConnectorTerminalProjection` (4)

**Calls:**
- `terminalEndpoint` (1)
- `terminalEndpoint` (1)
- `copyDataProperties` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1201` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `write` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:734` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `parseClassDiagram` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:506` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `atan2`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `include` (1)

### `startsWith`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:151` | Self: 0.0% (1.0ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `classOwnedSurfaceViolations` (2)

**Calls:**
- `emittedPoint` (1)

### `expandInlineNamespaceStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `readClassStatements` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:179` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `classNativeMarkerMinimums` (1)

### `separatedSharpSupportBounds`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:68` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:591` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `clear` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `paintedStrokeExtent` (1)

### `clear`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `seatMeasuredMarkers` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:497` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `resolveClassRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `normalizeRequest` (1)

### `omitUndefinedObjectFields`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `boundedImmutableJsonSnapshot` (1)

### `paintPrimitiveSource`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `solidInteriors` (1)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:229` | Self: 0.0% (1.0ms) | Total: 0.1% (7.6ms) | Samples: 1

**Called by:**
- `validateGeometry` (6)

**Calls:**
- `finiteNumber` (2)
- `finiteNumber` (2)
- `finiteNumber` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:85` | Self: 0.0% (1.0ms) | Total: 2.0% (89.3ms) | Samples: 1

**Called by:**
- `inspectPaint` (47)

**Calls:**
- `visit` (37)
- `visit` (4)
- `visit` (3)
- `visit` (1)
- `visit` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:127` | Self: 0.0% (1.0ms) | Total: 0.2% (10.3ms) | Samples: 1

**Called by:**
- `copyInner` (3)
- `copy` (1)

**Calls:**
- `pay` (2)
- `pay` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:641` | Self: 0.0% (1.0ms) | Total: 0.0% (3.6ms) | Samples: 1

**Called by:**
- `writeConnectorSvg` (3)

**Calls:**
- `freeze` (2)

### `/^\s*<([A-Za-z][\w:-]*)\b[^>]*>/`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `match` (1)

### `xmlTokenAt`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:85` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` | Self: 0.0% (1.0ms) | Total: 0.5% (23.1ms) | Samples: 1

**Called by:**
- `connectorPaintBounds` (5)
- `include` (4)
- `markerTerminalDepth` (2)

**Calls:**
- `geometryBounds` (7)
- `pathBounds` (1)
- `pointsBounds` (1)
- `pathBounds` (1)

### `performIteration`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.2% (9.0ms) | Samples: 1

**Called by:**
- `descriptorOwnsDetectionLine` (2)
- `parseClassDiagram` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)

**Calls:**
- `arrayIteratorNextHelper` (2)
- `next` (2)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:290` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:65` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `visit` (1)

### `/^\s*<g\b[^>]*>(?:<title>[^<]*<\/title>)?$/`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `assertInertGroup` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:307` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `find` (1)

### `/&quot;\|&#0*34;\|&#x0*22;/gi`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `replace` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:642` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `consumeStringBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:398` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `write` (1)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:89` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `ensureSvgIdentity` (1)

### `renderDisplayRuns`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:148` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `renderMultilineText` (1)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:703` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `inlineResolvedColors` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:524` | Self: 0.0% (1.0ms) | Total: 0.5% (25.0ms) | Samples: 1

**Called by:**
- `validateMarker` (3)
- `validateNode` (3)
- `validateNode` (3)

**Calls:**
- `validatePoints` (5)
- `validatePoints` (1)
- `validatePoints` (1)
- `validatePoints` (1)

### `writtenDecimalParts`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:29` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `compareSvgSum` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:649` | Self: 0.0% (1.0ms) | Total: 0.1% (4.7ms) | Samples: 1

**Called by:**
- `validateNode` (3)
- `validateNode` (1)

**Calls:**
- `assertRenderableMarker` (2)
- `assertRenderableMarker` (1)

### `get receipt`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:346` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `renderPreparedLine`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `renderMultilineText` (1)

### `checkFamilyConfigColors`
`/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:246` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validatePoint` (1)

### `emittedPoint`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:24` | Self: 0.0% (1.0ms) | Total: 0.0% (3.8ms) | Samples: 1

**Called by:**
- `classOwnedSurfaceViolations` (1)
- `writtenClassRoundedHit` (1)

**Calls:**
- `emitted` (1)

### `scanInlineNamespaceStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:48` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `readClassStatements` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:102` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `map` (1)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validateGeometry` (1)

### `requiredBackendCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1363` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `resolveExecutionPlan` (1)

### `SvgWriter`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:471` | Self: 0.0% (1.0ms) | Total: 0.1% (7.2ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (3)
- `writeTextSvg` (2)

**Calls:**
- `XmlLeafWrite` (4)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:840` | Self: 0.0% (998us) | Total: 0.0% (998us) | Samples: 1

**Called by:**
- `write` (1)

### `inlineResolvedColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:637` | Self: 0.0% (995us) | Total: 0.0% (995us) | Samples: 1

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

### `findMarkerlessRelationshipOperator`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1550` | Self: 0.0% (989us) | Total: 0.0% (989us) | Samples: 1

**Called by:**
- `parseMarkedClassRelationship` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:253` | Self: 0.0% (988us) | Total: 0.0% (988us) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:241` | Self: 0.0% (978us) | Total: 0.0% (978us) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `normalizeCssObfuscation`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:33` | Self: 0.0% (976us) | Total: 0.0% (976us) | Samples: 1

**Called by:**
- `inspectAttributeSecurity` (1)

### `validateRawThemeCss`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (975us) | Total: 0.0% (975us) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:325` | Self: 0.0% (972us) | Total: 0.1% (7.6ms) | Samples: 1

**Called by:**
- `lowerClassDrawing` (2)

**Calls:**
- `String` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:725` | Self: 0.0% (969us) | Total: 0.0% (969us) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` | Self: 0.0% (967us) | Total: 0.0% (967us) | Samples: 1

**Called by:**
- `layout` (1)

### `positionFamilyForNativeRender`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts` | Self: 0.0% (954us) | Total: 0.0% (954us) | Samples: 1

**Called by:**
- `measureRenderStage` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1099` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `numericCss` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:12` | Self: 0.0% (0us) | Total: 0.5% (24.5ms) | Samples: 0

**Calls:**
- `stringify` (15)
- `(anonymous)` (2)

### `typographyAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:698` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `writeTextSvg` (1)

**Calls:**
- `attribute` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:19` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `retainedLabelGeometry` (1)

### `createPngOutputOptionFieldDescriptors`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:105` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `map` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:729` | Self: 0.0% (0us) | Total: 0.6% (28.4ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (15)

**Calls:**
- `renderMultilineText` (5)
- `renderMultilineText` (4)
- `renderMultilineText` (4)
- `renderMultilineText` (1)
- `renderMultilineText` (1)

### `boundedImmutableJsonSnapshot`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1243` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `admitRenderOptionsInput` (2)

**Calls:**
- `omitUndefinedObjectFields` (1)
- `omitUndefinedObjectFields` (1)

### `canonicalizeSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:485` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `attachSceneNodeSerialization` (1)

**Calls:**
- `canonicalOpeningTag` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:4` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Calls:**
- `tipAnchoredArrow` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:662` | Self: 0.0% (0us) | Total: 0.2% (9.5ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (8)

**Calls:**
- `classNativeMarkerMinimums` (4)
- `classNativeMarkerMinimums` (2)
- `classNativeMarkerMinimums` (1)
- `classNativeMarkerMinimums` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6538` | Self: 0.0% (0us) | Total: 3.0% (130.5ms) | Samples: 0

**Called by:**
- `o` (1)

**Calls:**
- `(anonymous)` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:762` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `write` (2)

**Calls:**
- `set` (2)

### `defaultLocale`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-format/src/defaultLocale.js:14` | Self: 0.0% (0us) | Total: 0.1% (6.9ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `locale_default` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:582` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (2)

**Calls:**
- `attribute` (1)
- `attribute` (1)

### `verifyNoExternalRefs`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:716` | Self: 0.0% (0us) | Total: 0.1% (5.6ms) | Samples: 0

**Called by:**
- `runBackendConformance` (1)

**Calls:**
- `inspectOwnedSvgOnce` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:637` | Self: 0.0% (0us) | Total: 0.4% (18.7ms) | Samples: 0

**Called by:**
- `leaf` (10)

**Calls:**
- `rectangleInput` (8)
- `rectangleInput` (1)
- `rectangleInput` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:166` | Self: 0.0% (0us) | Total: 1.4% (63.4ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (38)

**Calls:**
- `group` (15)
- `group` (11)
- `group` (10)
- `group` (2)

### `applyFamilyRequestNormalization`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1042` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `resolveAppearance` (1)

**Calls:**
- `normalizeRequest` (1)

### `consumeResolvedGraphicalRequest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:316` | Self: 0.0% (0us) | Total: 78.2% (3.40s) | Samples: 0

**Called by:**
- `withSvgInspectionCache` (1818)

**Calls:**
- `withTextMeasurementExecution` (1404)
- `renderResolvedMermaidSVG` (414)

### `classifyClassStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:518` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `readClassStatements` (1)

**Calls:**
- `parseClassDeclaration` (1)

### `documentOpen`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:135` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (1)

**Calls:**
- `attachSceneNodeSerialization` (1)

### `hitsTransformed`
`/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:47` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `connector/transform/render` (1)

**Calls:**
- `transformedHitDistance` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1476` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `getBackendDescriptor` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:738` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `replace` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:323` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `forEach` (1)

**Calls:**
- `atan2` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:645` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `includes` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:4` | Self: 0.0% (0us) | Total: 0.1% (8.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `parseClassReference`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:186` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `parseMarkerlessClassRelationship` (1)

**Calls:**
- `match` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:136` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `every` (1)

**Calls:**
- `absentPaint` (1)

### `assertMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:57` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `connector` (2)

**Calls:**
- `/^[A-Za-z0-9_-]+(?: [A-Za-z0-9_-]+)*$/` (1)
- `test` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:150` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (2)

**Calls:**
- `(anonymous)` (2)

### `deferredRenderContractDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1127` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `deferredRequestReceiptDigest` (3)

**Calls:**
- `admitRenderContractDigestInput` (3)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:50` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `formatSvgNumericAttribute` (1)

### `renderRelationshipMarkerOverlay`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:648` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `classRelationshipEndpoints` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:676` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `element` (2)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:515` | Self: 0.0% (0us) | Total: 0.0% (3.9ms) | Samples: 0

**Called by:**
- `writeTextSvg` (2)
- `writeShapeSvg` (1)

**Calls:**
- `paintAttribute` (3)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:674` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `cloneObject` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:5` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:145` | Self: 0.0% (0us) | Total: 0.6% (27.1ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (14)

**Calls:**
- `parts` (9)
- `parts` (2)
- `parts` (1)
- `parts` (1)
- `parts` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:570` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `createSketchBackend` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `(anonymous)` (1)

### `contrastRatio`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:84` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `ensureContrast` (2)

**Calls:**
- `relativeLuminance` (2)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:712` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (2)

**Calls:**
- `emittedBox` (2)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:340` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `forEach` (1)

**Calls:**
- `map` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/agent/families.ts:8` | Self: 0.0% (0us) | Total: 1.1% (48.2ms) | Samples: 0

**Calls:**
- `installBuiltinFamily` (19)
- `installBuiltinFamily` (11)
- `copyDataProperties` (1)

### `canonicalizeFrontmatterMap`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:1084` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `normalizeSource` (1)

**Calls:**
- `cloneFrontmatterMap` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:698` | Self: 0.0% (0us) | Total: 0.0% (4.2ms) | Samples: 0

**Called by:**
- `leaf` (3)

**Calls:**
- `snapshot` (3)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:93` | Self: 0.0% (0us) | Total: 0.5% (22.9ms) | Samples: 0

**Called by:**
- `measureRenderStage` (12)

**Calls:**
- `layoutLayeredGraph` (6)
- `layoutLayeredGraph` (3)
- `layoutLayeredGraph` (2)
- `layoutLayeredGraph` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` | Self: 0.0% (0us) | Total: 0.3% (14.3ms) | Samples: 0

**Called by:**
- `markerBoundsAt` (2)
- `include` (1)

**Calls:**
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:678` | Self: 0.0% (0us) | Total: 4.6% (203.9ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (115)

**Calls:**
- `measureRenderStage` (115)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:5` | Self: 0.0% (0us) | Total: 0.5% (23.3ms) | Samples: 0

**Called by:**
- `anonymous` (15)

**Calls:**
- `bound require` (15)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/pie/config-diagnostics.ts:5` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Calls:**
- `oneOf` (1)

### `replaceField`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:288` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:242` | Self: 0.0% (0us) | Total: 4.0% (177.4ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (94)

**Calls:**
- `inspectPaint` (90)
- `finish` (2)
- `inspectPaint` (1)
- `finish` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/decode-data-html.js:3` | Self: 0.0% (0us) | Total: 1.4% (62.4ms) | Samples: 0

**Calls:**
- `decodeBase64` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:212` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `knownOwned` (1)

### `renderRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:671` | Self: 0.0% (0us) | Total: 0.3% (14.9ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (9)

**Calls:**
- `leaf` (9)

### `markerTerminalDepth`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:294` | Self: 0.0% (0us) | Total: 0.1% (7.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (4)
- `(anonymous)` (1)

**Calls:**
- `markerBoundsAt` (2)
- `markerBoundsAt` (2)
- `pointsBounds` (1)

### `serializeMarkerResources`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:155` | Self: 0.0% (0us) | Total: 0.2% (9.9ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (4)

**Calls:**
- `map` (4)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:114` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `createNativeSceneValidator` (1)
- `createNativeSceneValidator` (1)

### `flowchartMarkerResources`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:81` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `circleMarkerResources` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:58` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `find` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1104` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (1)

**Calls:**
- `proofRecord` (1)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:988` | Self: 0.0% (0us) | Total: 0.1% (7.5ms) | Samples: 0

**Called by:**
- `layout` (4)

**Calls:**
- `authoredClassStatements` (2)
- `authoredClassStatements` (1)
- `authoredClassStatements` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/gantt/dependency-paint.ts:16` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Calls:**
- `dependencyArrowMarker` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:420` | Self: 0.0% (0us) | Total: 3.3% (144.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (83)

**Calls:**
- `xmlSlice` (83)

### `classifyClassStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:449` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `readClassStatements` (4)

**Calls:**
- `parseClassInteractionWithAuthored` (3)
- `parseClassInteractionWithAuthored` (1)

### `renderOptionsAdmissionMessages`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:403` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `validateJsonConfigAdmission` (1)

### `finalizeClassSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:815` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `repairClassAnnotationSeats` (1)

### `finishClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:772` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `withClassTitle` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `(anonymous)` (1)

### `internal:streams/compose`
`internal:streams/compose:2` | Self: 0.0% (0us) | Total: 0.2% (11.6ms) | Samples: 0

**Called by:**
- `anonymous` (6)

**Calls:**
- `anonymous` (6)

### `gzipSync`
`node:zlib:360` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `Gzip` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/resolve-block-map.js:6` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `seatFinalMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:569` | Self: 0.0% (0us) | Total: 3.6% (159.7ms) | Samples: 0

**Called by:**
- `finalizeFlatMeasuredMarkers` (93)

**Calls:**
- `seatMeasuredMarkers` (58)
- `seatMeasuredMarkers` (23)
- `seatMeasuredMarkers` (6)
- `seatMeasuredMarkers` (2)
- `seatMeasuredMarkers` (1)
- `seatMeasuredMarkers` (1)
- `seatMeasuredMarkers` (1)
- `seatMeasuredMarkers` (1)

### `WritableState`
`internal:streams/writable:152` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Duplex` (1)

**Calls:**
- `resetBuffer` (1)

### `withClassTitle`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:889` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `diagramTitleBand` (1)

### `svgStyleRanges`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:256` | Self: 0.0% (0us) | Total: 0.3% (14.0ms) | Samples: 0

**Called by:**
- `scopeSvgStyles` (7)

**Calls:**
- `scanStartTags` (3)
- `scanStartTags` (2)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1745` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `measureRenderStage` (2)

**Calls:**
- `immutableSnapshot` (1)
- `immutableSnapshot` (1)

### `r`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 3.0% (130.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `o` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1766` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `add` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:102` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (1)
- `projectSvgCss` (1)

**Calls:**
- `isAsciiXmlNameChar` (2)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:94` | Self: 0.0% (0us) | Total: 1.4% (61.3ms) | Samples: 0

**Called by:**
- `inspectPaint` (33)

**Calls:**
- `leaf` (32)
- `leaf` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:77` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `validateSerializableRenderOptions` (1)

**Calls:**
- `map` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:173` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `createPngOutputOptionFieldDescriptors` (1)

### `connectorMarkerPaintRegions`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:353` | Self: 0.0% (0us) | Total: 2.3% (102.8ms) | Samples: 0

**Called by:**
- `prepareMarkerPolygonInk` (15)
- `assertClassMarkerMeaning` (13)

**Calls:**
- `forEach` (28)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:259` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `includes` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:153` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (1)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `authoredClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:109` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (2)

**Calls:**
- `filter` (2)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:651` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:557` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `connectorGeometryEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:179` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `cloneObject` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-doc.js:4` | Self: 0.0% (0us) | Total: 0.1% (5.6ms) | Samples: 0

**Called by:**
- `anonymous` (3)

**Calls:**
- `bound require` (3)

### `node`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1448` | Self: 0.0% (0us) | Total: 0.6% (28.1ms) | Samples: 0

**Called by:**
- `group` (18)

**Calls:**
- `validateNode` (10)
- `validateNode` (2)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:208` | Self: 0.0% (0us) | Total: 1.8% (79.2ms) | Samples: 0

**Calls:**
- `(anonymous)` (8)
- `expandLocalReferences` (2)

### `finishClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:791` | Self: 0.0% (0us) | Total: 4.5% (196.9ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (94)

**Calls:**
- `finalizeClassSurfaces` (73)
- `finalizeClassSurfaces` (15)
- `finalizeClassSurfaces` (5)
- `finalizeClassSurfaces` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1788` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (2)

**Calls:**
- `has` (2)

### `withRenderStageObserver`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:20` | Self: 0.0% (0us) | Total: 80.0% (3.48s) | Samples: 0

**Called by:**
- `(module)` (1869)

**Calls:**
- `withSvgInspectionCache` (1869)

### `node:stream`
`node:stream:2` | Self: 0.0% (0us) | Total: 0.4% (18.2ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `anonymous` (9)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:558` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `charge` (1)

### `classRelationshipPaintBoxes`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:343` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `classOwnedSurfaceViolations` (1)
- `assertClassMarkerMeaning` (1)

**Calls:**
- `forEach` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:5` | Self: 0.0% (0us) | Total: 6.3% (275.6ms) | Samples: 0

**Calls:**
- `(anonymous)` (4)

### `classStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:392` | Self: 0.0% (0us) | Total: 0.1% (8.2ms) | Samples: 0

**Called by:**
- `readClassStatements` (3)
- `classifyClassStatement` (3)

**Calls:**
- `classCommentStart` (3)
- `classCommentStart` (3)

### `Duplex`
`internal:streams/duplex:15` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Transform` (1)

**Calls:**
- `WritableState` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:7` | Self: 0.0% (0us) | Total: 0.2% (9.9ms) | Samples: 0

**Called by:**
- `anonymous` (7)

**Calls:**
- `bound require` (7)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:148` | Self: 0.0% (0us) | Total: 2.9% (130.4ms) | Samples: 0

**Called by:**
- `forEach` (92)

**Calls:**
- `leaf` (63)
- `connector` (21)
- `renderRelationshipMarkerOverlay` (3)
- `renderRelationshipMarkerOverlay` (2)
- `renderRelationshipMarkerOverlay` (1)
- `renderRelationshipMarkerOverlay` (1)
- `renderRelationshipMarkerOverlay` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:133` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (3)

**Calls:**
- `terminalMarker` (1)
- `terminalMarker` (1)
- `terminalMarker` (1)

### `cssPaintDefinitions`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:611` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Called by:**
- `colorResolution` (2)

**Calls:**
- `next` (2)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1041` | Self: 0.0% (0us) | Total: 0.6% (27.6ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (12)

**Calls:**
- `color` (8)
- `color` (4)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:266` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `copyDataProperties` (2)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:88` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `ensureSvgIdentity` (1)

**Calls:**
- `endsWith` (1)

### `finalizeFlatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:654` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `compactProvedPath` (1)

### `consumeStringBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:400` | Self: 0.0% (0us) | Total: 0.1% (7.6ms) | Samples: 0

**Called by:**
- `write` (3)

**Calls:**
- `boundedUtf8ByteLength` (2)
- `boundedUtf8ByteLength` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:532` | Self: 0.0% (0us) | Total: 0.3% (14.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `has` (1)

### `deferredTerminalProjectionInput`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:66` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `copyInner` (1)
- `copyDeferredTerminalProjection` (1)

**Calls:**
- `getOwnPropertyDescriptor` (2)

### `escapeDisplayAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:115` | Self: 0.0% (0us) | Total: 0.1% (5.7ms) | Samples: 0

**Called by:**
- `renderClassBox` (4)

**Calls:**
- `sanitizeDisplayLines` (3)
- `join` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1569` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `fromEntries` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:9` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `internal:streams/duplex`
`internal:streams/duplex:2` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `anonymous` (4)

### `executionCapabilityDecision`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1453` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `resolveExecutionPlan` (1)

**Calls:**
- `negotiateCapabilities` (1)

### `nativePaintAncestors`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:190` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `ownerSnapshot` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:123` | Self: 0.0% (0us) | Total: 18.5% (808.4ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (405)

**Calls:**
- `withGraphLayoutDecisionObserver` (405)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:222` | Self: 0.0% (0us) | Total: 0.2% (10.9ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (6)

**Calls:**
- `layoutMeasuredForest` (2)
- `layoutMeasuredForest` (1)
- `layoutMeasuredForest` (1)
- `layoutMeasuredForest` (1)
- `layoutMeasuredForest` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:581` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `separatedSharpSupportBounds`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:71` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

**Calls:**
- `isFinite` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:5` | Self: 0.0% (0us) | Total: 0.0% (4.3ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `snapshotScenePrimitiveCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1541` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `snapshotDescriptorArray` (1)

**Calls:**
- `fromEntries` (1)

### `registerCanonicalStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:235` | Self: 0.0% (0us) | Total: 0.1% (7.3ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (1)

**Calls:**
- `registrationIdentity` (1)

### `renderRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:552` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (1)

**Calls:**
- `classRelationshipLineStyle` (1)

### `createCliRenderOutputDescriptors`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:201` | Self: 0.0% (0us) | Total: 0.0% (3.9ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `filter` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:538` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:109` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (2)

**Calls:**
- `flatIntoArrayWithCallback` (2)

### `assessRenderedLayoutHardViolations`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:211` | Self: 0.0% (0us) | Total: 0.2% (10.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (6)

**Calls:**
- `assessFamilyLayout` (2)
- `assessFamilyLayout` (2)
- `assessFamilyLayout` (1)
- `assessFamilyLayout` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:200` | Self: 0.0% (0us) | Total: 1.6% (73.1ms) | Samples: 0

**Called by:**
- `group` (39)

**Calls:**
- `(anonymous)` (38)
- `(anonymous)` (1)

### `knownBackendDescriptors`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:489` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `getBackendDescriptor` (1)

**Calls:**
- `from` (1)

### `receiptOf`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:758` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:705` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `cloneObject` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:153` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `classOwnedSurfaceViolations` (1)

**Calls:**
- `emittedBox` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:548` | Self: 0.0% (0us) | Total: 0.1% (7.3ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringify.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:144` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (2)

**Calls:**
- `copyDataProperties` (2)

### `sceneValidationMode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1397` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `createNativeSceneValidator` (1)

**Calls:**
- `parseExtensionId` (1)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:702` | Self: 0.0% (0us) | Total: 0.3% (14.7ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (11)

**Calls:**
- `sourceEnvelopeMetadata` (9)
- `sourceEnvelopeMetadata` (1)
- `sourceEnvelopeMetadata` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1759` | Self: 0.0% (0us) | Total: 0.0% (975us) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `validateRawThemeCss` (1)

### `compareSvgSum`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:42` | Self: 0.0% (0us) | Total: 0.2% (10.4ms) | Samples: 0

**Called by:**
- `classOwnedSurfaceViolations` (3)
- `projectClassRectangleContacts` (1)
- `classOwnedSurfaceViolations` (1)

**Calls:**
- `writtenDecimalParts` (2)
- `writtenDecimalParts` (2)
- `writtenDecimalParts` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:678` | Self: 0.0% (0us) | Total: 1.0% (46.8ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (23)

**Calls:**
- `geometryAttributes` (7)
- `geometryAttributes` (2)
- `geometryAttributes` (2)
- `geometryAttributes` (2)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:169` | Self: 0.0% (0us) | Total: 0.4% (19.7ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (13)

**Calls:**
- `snapshot` (13)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:738` | Self: 0.0% (0us) | Total: 0.1% (6.0ms) | Samples: 0

**Called by:**
- `drawNative` (2)

**Calls:**
- `finish` (2)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:744` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `normalizeMermaidRuntimeConfig` (1)

### `finalizeClassSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:824` | Self: 0.0% (0us) | Total: 3.4% (148.6ms) | Samples: 0

**Called by:**
- `finishClassLayout` (73)

**Calls:**
- `classOwnedSurfaceViolations` (53)
- `classOwnedSurfaceViolations` (6)
- `classOwnedSurfaceViolations` (3)
- `classOwnedSurfaceViolations` (3)
- `classOwnedSurfaceViolations` (2)
- `classOwnedSurfaceViolations` (2)
- `classOwnedSurfaceViolations` (1)
- `classOwnedSurfaceViolations` (1)
- `classOwnedSurfaceViolations` (1)
- `classOwnedSurfaceViolations` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:290` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (1)

**Calls:**
- `cloneObject` (1)

### `measureRenderStage`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:30` | Self: 0.0% (0us) | Total: 82.5% (3.59s) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (1119)
- `renderResolvedMermaidSVG` (414)
- `renderPositionedWithTextMeasurement` (219)
- `(anonymous)` (115)
- `executeInspectedGraphicalRequest` (50)
- `renderPositionedWithTextMeasurement` (16)

**Calls:**
- `retainedNativeDrawing` (1083)
- `positionFamilyForNativeRender` (413)
- `applyOutputSecurityPolicy` (219)
- `layoutLayeredGraph` (99)
- `retainedNativeDrawing` (34)
- `resolveRenderRequestForExecution` (21)
- `positionedPaintCertification` (14)
- `layoutLayeredGraph` (12)
- `resolveRenderRequestForExecution` (7)
- `resolveRenderRequestForExecution` (5)
- `resolveRenderRequestForExecution` (5)
- `resolveRenderRequestForExecution` (3)
- `resolveRenderRequestForExecution` (2)
- `resolveRenderRequestForExecution` (2)
- `(anonymous)` (2)
- `resolveRenderRequestForExecution` (1)
- `(anonymous)` (1)
- `retainedNativeDrawing` (1)
- `resolveRenderRequestForExecution` (1)
- `positionFamilyForNativeRender` (1)
- `positionedPaintCertification` (1)
- `resolveRenderRequestForExecution` (1)
- `positionedPaintCertification` (1)
- `resolveRenderRequestForExecution` (1)
- `(anonymous)` (1)
- `resolveRenderRequestForExecution` (1)
- `retainedNativeDrawing` (1)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:702` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Called by:**
- `inlineResolvedColors` (2)

**Calls:**
- `cssPaintDefinitions` (2)

### `assessFamilyLayout`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:275` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `assessRenderedLayoutHardViolations` (2)

**Calls:**
- `map` (1)
- `Map` (1)

### `makeSafe`
`internal:primordials:53` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `internal:primordials` (1)

**Calls:**
- `copyProps` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1502` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `validateAggregateReferences` (1)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:431` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:975` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `prepareMarkerPolygonInk` (1)

**Calls:**
- `work` (1)

### `validateStyleSpec`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:453` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (2)

**Calls:**
- `validateRoleStyles` (2)

### `deepFreeze`
`/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` | Self: 0.0% (0us) | Total: 0.4% (21.0ms) | Samples: 0

**Called by:**
- `deepFreeze` (12)
- `(module)` (1)
- `validateSerializableRenderOptions` (1)
- `withTextMeasurementExecution` (1)

**Calls:**
- `deepFreeze` (12)
- `freeze` (2)
- `deepFreeze` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:96` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `svgOpenTag` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:272` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `(anonymous)` (1)

### `hooks`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:508` | Self: 0.0% (0us) | Total: 0.2% (10.7ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (6)

**Calls:**
- `attribute` (4)
- `attribute` (1)
- `attribute` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:680` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `cloneObject` (1)

### `caseInsensitiveKeywordPattern`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:102` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `map` (1)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:209` | Self: 0.0% (0us) | Total: 0.6% (26.2ms) | Samples: 0

**Called by:**
- `markerBoundsAt` (7)
- `connectorPaintBounds` (3)

**Calls:**
- `pointsBounds` (5)
- `pointsBounds` (3)
- `pointsBounds` (2)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:92` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `inspectPaint` (2)

**Calls:**
- `observe` (1)
- `observe` (1)

### `immutableSnapshot`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1222` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `immutableSnapshot` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:394` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `measureClassCards` (1)

**Calls:**
- `map` (1)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:379` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `group` (2)

**Calls:**
- `decodedSvgAttributeValue` (2)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:588` | Self: 0.0% (0us) | Total: 0.4% (20.7ms) | Samples: 0

**Called by:**
- `group` (10)
- `createFixture` (1)

**Calls:**
- `assertInertGroup` (7)
- `assertInertGroup` (2)
- `assertInertGroup` (1)
- `assertInertGroup` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:709` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:673` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `map` (1)

### `resolvedColorValue`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:601` | Self: 0.0% (0us) | Total: 1.0% (44.9ms) | Samples: 0

**Called by:**
- `toneOnFill` (7)
- `toneOnFill` (6)
- `toneOnFill` (1)

**Calls:**
- `diagramColorVariables` (6)
- `diagramColorVariables` (4)
- `diagramColorVariables` (3)
- `diagramColorVariables` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:512` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `include` (1)
- `paintBounds` (1)
- `markerBoundsAt` (1)

**Calls:**
- `parseFloat` (3)

### `withGraphLayoutDecisionObserver`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:37` | Self: 0.0% (0us) | Total: 18.5% (808.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (405)

**Calls:**
- `layout` (360)
- `layout` (44)
- `layoutResult` (1)

### `(unknown)`
`[native code]` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `(unknown)` (1)
- `knownOwned` (1)

**Calls:**
- `(unknown)` (1)
- `has` (1)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1632` | Self: 0.0% (0us) | Total: 0.3% (15.6ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (5)

**Calls:**
- `applyOutputSecurityPolicy` (5)

### `Transform`
`internal:streams/transform:14` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `ZlibBase` (1)

**Calls:**
- `Duplex` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:155` | Self: 0.0% (0us) | Total: 0.2% (11.4ms) | Samples: 0

**Called by:**
- `classOwnedSurfaceViolations` (7)

**Calls:**
- `writtenSegmentEntersBox` (4)
- `writtenSegmentEntersBox` (2)
- `writtenSegmentEntersBox` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:799` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `find` (1)

**Calls:**
- `test` (1)

### `addClassSvgNumbers`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:60` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `projectClassRectangleContacts` (1)

**Calls:**
- `map` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:297` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `connectorDirection` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:94` | Self: 0.0% (0us) | Total: 3.9% (170.8ms) | Samples: 0

**Called by:**
- `measureRenderStage` (99)

**Calls:**
- `finalizeFlatMeasuredMarkers` (95)
- `finalizeFlatMeasuredMarkers` (3)
- `finalizeFlatMeasuredMarkers` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:110` | Self: 0.0% (0us) | Total: 0.0% (4.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (3)

**Calls:**
- `createNativePaintEmission` (2)
- `createNativePaintEmission` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:531` | Self: 0.0% (0us) | Total: 0.1% (5.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `segmentEntersMeasuredBox` (2)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:89` | Self: 0.0% (0us) | Total: 1.4% (63.7ms) | Samples: 0

**Called by:**
- `finishClassLayout` (30)

**Calls:**
- `connector` (15)
- `connector` (3)
- `connector` (2)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)

### `connectorMarkerPaintRegions`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:316` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `prepareMarkerPolygonInk` (2)

**Calls:**
- `connectorEndpointAnchors` (1)
- `connectorEndpointAnchors` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:276` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `leaf` (3)

**Calls:**
- `append` (3)

### `nonPainting`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:130` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `leaf` (3)

**Calls:**
- `some` (3)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:839` | Self: 0.0% (0us) | Total: 0.1% (4.6ms) | Samples: 0

**Called by:**
- `write` (2)

**Calls:**
- `isRetainedPixelText` (2)

### `header`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:447` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `documentOpen` (1)

**Calls:**
- `inspectOwnedSvgOnce` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:346` | Self: 0.0% (0us) | Total: 0.2% (12.6ms) | Samples: 0

**Called by:**
- `forEach` (2)

**Calls:**
- `paintedStrokeExtent` (1)
- `paintedStrokeExtent` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:116` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `seatFinalMeasuredMarkers` (1)

**Calls:**
- `charge` (1)

### `validateBackendCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:307` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `registerBuiltInBackend` (1)

**Calls:**
- `find` (1)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1199` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `layout` (2)

**Calls:**
- `performIteration` (1)
- `filter` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:974` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `map` (4)

**Calls:**
- `connector/relation/accessibility` (1)
- `connector/stroke/render` (1)
- `document/identity/serialize` (1)
- `connector/transform/render` (1)

### `mermaidFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:149` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `normalizeMermaidSource` (1)

**Calls:**
- `matchMermaidFrontmatter` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:391` | Self: 0.0% (0us) | Total: 0.1% (7.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (4)

**Calls:**
- `readXmlNameEnd` (4)

### `decodedSvgAttributeValue`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:179` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `nativeGroup` (2)

**Calls:**
- `find` (2)

### `buildClassEndpointMarkerTemplates`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts:9` | Self: 0.0% (0us) | Total: 0.3% (13.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `map` (5)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts:76` | Self: 0.0% (0us) | Total: 0.1% (8.6ms) | Samples: 0

**Called by:**
- `some` (1)

**Calls:**
- `/acc(?:Title\|Descr)/i` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:681` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:581` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `some` (1)

### `o`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 6.0% (261.1ms) | Samples: 0

**Called by:**
- `r` (1)
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `projectClassRectangleContacts`
`/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:163` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (2)

**Calls:**
- `compareSvgSum` (1)
- `compareSvgSum` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:143` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `validate` (1)

**Calls:**
- `isPlainRecord` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:565` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (2)

**Calls:**
- `copyDataProperties` (2)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1682` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `renderContractDigest` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/agent/stable-family-source-hooks.ts:446` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Calls:**
- `sourceAdapter` (1)

### `extractClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:428` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `get` (1)

### `unsafeCssReferences`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:617` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `inspectAttributeSecurity` (2)

**Calls:**
- `next` (2)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:616` | Self: 0.0% (0us) | Total: 0.0% (4.0ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `transformedBounds` (1)
- `transformedBounds` (1)

### `assessFamilyLayout`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:237` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `assessRenderedLayoutHardViolations` (1)

**Calls:**
- `checkRect` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:181` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `copyDeferredTerminalProjection` (1)

### `classifyMermaidFamilyDescriptorFromFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/family-detection.ts:39` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `detectInstalledFamilyDescriptorFromFirstLine` (3)

### `advance`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` | Self: 0.0% (0us) | Total: 0.2% (10.7ms) | Samples: 0

**Called by:**
- `preparePixelText` (7)

**Calls:**
- `reduce` (7)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:701` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `node` (2)

**Calls:**
- `serializeSceneNode` (1)
- `serializeSceneNode` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/builtin-backends.ts:20` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `registerBuiltInBackend` (1)

### `getCharWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:103` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `measureText` (1)

**Calls:**
- `has` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:154` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `/^(?:0\|[1-9]\d*)$/` (1)

### `terminalEndpoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:70` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `deriveConnectorTerminalProjection` (1)

**Calls:**
- `cloneObject` (1)

### `parseClassInteractionWithAuthored`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:923` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `classifyClassStatement` (3)

**Calls:**
- `replace` (2)
- `decodeWithTrie` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:711` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (1)

**Calls:**
- `emittedPoint` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:655` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (2)

**Calls:**
- `map` (2)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:441` | Self: 0.0% (0us) | Total: 0.9% (41.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (29)

**Calls:**
- `xmlSlice` (28)
- `xmlSlice` (1)

### `compareSvgSum`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:43` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `projectClassRectangleContacts` (1)

**Calls:**
- `writtenDecimalParts` (1)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:212` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `validateGeometry` (2)

**Calls:**
- `skipSeparators` (2)

### `validateMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:353` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `validateNode` (4)

**Calls:**
- `rejectUnknownKeys` (2)
- `rejectUnknownKeys` (1)
- `rejectUnknownKeys` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:689` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (1)

**Calls:**
- `classRelationshipPaintBoxes` (1)

### `ensureContrast`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:102` | Self: 0.0% (0us) | Total: 0.0% (4.1ms) | Samples: 0

**Called by:**
- `toneOnFill` (3)

**Calls:**
- `contrastRatio` (2)
- `luminanceContrastRatio` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:252` | Self: 0.0% (0us) | Total: 8.7% (379.0ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (219)

**Calls:**
- `measureRenderStage` (219)

### `serialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1494` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `open` (1)

### `freezeBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:403` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `registerBuiltInBackend` (1)

**Calls:**
- `snapshotBackendCapabilities` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:989` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (1)

**Calls:**
- `pay` (1)

### `render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:394` | Self: 0.0% (0us) | Total: 0.7% (34.5ms) | Samples: 0

**Called by:**
- `rendered` (15)

**Calls:**
- `admitSceneDocumentWith` (15)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1826` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `expectedCapabilityState` (1)

### `createExtensionIdentity`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:229` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `parseExtensionId` (1)
- `parseExtensionId` (1)

### `classRelationshipTerminalClearance`
`/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:59` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `classTerminalLead` (1)

**Calls:**
- `(anonymous)` (1)

### `scopeCss`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:115` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `scopeSvgStyles` (1)

**Calls:**
- `matchingBrace` (1)

### `layout`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:20` | Self: 0.0% (0us) | Total: 1.4% (64.6ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (44)

**Calls:**
- `parseClassDiagram` (20)
- `parseClassDiagram` (14)
- `parseClassDiagram` (4)
- `parseClassDiagram` (2)
- `parseClassDiagram` (2)
- `parseClassDiagram` (1)
- `parseClassDiagram` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:803` | Self: 0.0% (0us) | Total: 0.3% (17.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (7)

**Calls:**
- `hooks` (6)
- `hooks` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:711` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `SvgWriter` (2)

### `projectClassPositioned`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:9` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `map` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:100` | Self: 0.0% (0us) | Total: 0.9% (41.6ms) | Samples: 0

**Called by:**
- `finishClassLayout` (15)

**Calls:**
- `connectorMarkerPaintRegions` (13)
- `connectorMarkerPaintRegions` (1)
- `connectorMarkerPaintRegions` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:565` | Self: 0.0% (0us) | Total: 1.0% (44.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (25)

**Calls:**
- `scoreMeasuredRouteCrossingsWithAdmission` (12)
- `scoreMeasuredRouteCrossingsWithAdmission` (5)
- `scoreMeasuredRouteCrossingsWithAdmission` (4)
- `scoreMeasuredRouteCrossingsWithAdmission` (2)
- `scoreMeasuredRouteCrossingsWithAdmission` (1)
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:3` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:330` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `get receipt` (1)

**Calls:**
- `receiptOf` (1)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:376` | Self: 0.0% (0us) | Total: 0.6% (29.5ms) | Samples: 0

**Called by:**
- `group` (18)

**Calls:**
- `scanStartTags` (7)
- `scanStartTags` (3)
- `scanStartTags` (2)
- `scanStartTags` (2)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanSvgStartTagsFresh` (1)
- `freeze` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1737` | Self: 0.0% (0us) | Total: 0.8% (38.1ms) | Samples: 0

**Called by:**
- `measureRenderStage` (21)

**Calls:**
- `normalizeMermaidSourceWithOverrides` (21)

### `renderContractDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1118` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `resolveAppearance` (1)

**Calls:**
- `canonicalJson` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:127` | Self: 0.0% (0us) | Total: 2.1% (92.6ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (30)
- `(anonymous)` (21)

**Calls:**
- `connector` (7)
- `connector` (6)
- `connector` (4)
- `connector` (4)
- `connector` (4)
- `connector` (3)
- `connector` (3)
- `connector` (2)
- `connector` (2)
- `connector` (2)
- `connector` (2)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)

### `compositeCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:275` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `toneOnFill` (2)

**Calls:**
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)

### `detectRegisteredFamilyDescriptorFromFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2083` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `detectInstalledFamilyDescriptorFromFirstLine` (3)

**Calls:**
- `sort` (3)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:4` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `structurallyEqual`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1274` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `every` (1)

**Calls:**
- `filter` (1)

### `finiteRect`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:159` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `checkRect` (1)

**Calls:**
- `isFinite` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `map` (2)

**Calls:**
- `serializeSceneNode` (2)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:724` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `transformAttribute` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/default-backend.ts:5` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Calls:**
- `registerBuiltInBackend` (1)
- `registerBuiltInBackend` (1)

### `validateMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:354` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `test` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1523` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `every` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:96` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `paintBounds` (3)

**Calls:**
- `skip` (2)
- `skip` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1052` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `report` (1)

**Calls:**
- `applyOutputSecurityPolicy` (1)

### `snapshotScenePrimitiveCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1548` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `snapshotDescriptorArray` (3)

**Calls:**
- `freeze` (2)
- `snapshotDescriptorArray` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:194` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (1)

**Calls:**
- `freeze` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/encode-html.js:10` | Self: 0.0% (0us) | Total: 0.0% (3.9ms) | Samples: 0

**Calls:**
- `parseEncodeTrie` (1)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:181` | Self: 0.0% (0us) | Total: 0.0% (4.2ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (3)

**Calls:**
- `scopeHash` (1)
- `scopeHash` (1)
- `scopeHash` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:328` | Self: 0.0% (0us) | Total: 0.3% (14.3ms) | Samples: 0

**Called by:**
- `get receipt` (10)

**Calls:**
- `canonicalTextDigest` (7)
- `renderedSvgDigest` (3)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:218` | Self: 0.0% (0us) | Total: 1.5% (66.8ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (35)

**Calls:**
- `inlineResolvedColors` (28)
- `resolveSvgColors` (6)
- `inlineResolvedColors` (1)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:985` | Self: 0.0% (0us) | Total: 0.6% (30.3ms) | Samples: 0

**Called by:**
- `layout` (20)

**Calls:**
- `classStatementEnds` (17)
- `scanAccessibilityDirectives` (2)
- `classStatementEnds` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:418` | Self: 0.0% (0us) | Total: 1.7% (75.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (43)

**Calls:**
- `readXmlNameEnd` (39)
- `readXmlNameEnd` (4)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:189` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `assertFinalBoundaryContacts`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:396` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `finalizeFlatMeasuredMarkers` (1)

**Calls:**
- `charge` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:317` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `drawNative` (2)

**Calls:**
- `freeze` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1739` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `normalizeMermaidSource` (4)

**Calls:**
- `classifyMermaidFamilyDescriptorFromFirstLine` (3)
- `classifyMermaidFamilyDescriptorFromFirstLine` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:200` | Self: 0.0% (0us) | Total: 0.2% (9.8ms) | Samples: 0

**Called by:**
- `copyInner` (7)

**Calls:**
- `preventExtensions` (7)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1613` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (1)

**Calls:**
- `createValidationState` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:56` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `formatSvgNumericAttribute` (1)
- `replace` (1)

**Calls:**
- `(anonymous)` (2)

### `setConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:59` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `install` (1)

### `writeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `map` (2)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:114` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Calls:**
- `flowchartMarkerResources` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:728` | Self: 0.0% (0us) | Total: 0.7% (30.6ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (21)

**Calls:**
- `inspectAttributeSecurity` (8)
- `inspectAttributeSecurity` (6)
- `inspectAttributeSecurity` (4)
- `inspectAttributeSecurity` (2)
- `inspectAttributeSecurity` (1)

### `report`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:235` | Self: 0.0% (0us) | Total: 1.7% (76.4ms) | Samples: 0

**Called by:**
- `retainedNativeDrawing` (33)

**Calls:**
- `runBackendConformance` (16)
- `runBackendConformance` (6)
- `runBackendConformance` (5)
- `runBackendConformance` (4)
- `runBackendConformance` (1)
- `runBackendConformance` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:539` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:115` | Self: 0.0% (0us) | Total: 3.0% (130.5ms) | Samples: 0

**Called by:**
- `o` (1)

**Calls:**
- `(anonymous)` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1762` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `checkFamilyConfigColors` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1495` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `label` (1)

### `registerExtension`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:290` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `registerCanonicalStyle` (1)

**Calls:**
- `set` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:245` | Self: 0.0% (0us) | Total: 0.2% (9.2ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (4)

**Calls:**
- `finish` (2)
- `finish` (1)
- `finish` (1)

### `isWideRange`
`/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:126` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `getCharWidth` (1)

**Calls:**
- `inRanges` (1)

### `withDeferredTerminalProjections`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:16` | Self: 0.0% (0us) | Total: 41.2% (1.79s) | Samples: 0

**Called by:**
- `drawNative` (977)

**Calls:**
- `lowerClassDrawing` (624)
- `lowerClassDrawing` (230)
- `lowerClassDrawing` (95)
- `lowerClassDrawing` (9)
- `lowerClassDrawing` (5)
- `lowerClassDrawing` (4)
- `lowerClassDrawing` (4)
- `lowerClassDrawing` (4)
- `lowerClassDrawing` (1)
- `lowerClassDrawing` (1)

### `attachSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:495` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `documentOpen` (1)

**Calls:**
- `canonicalizeSceneNodeSerialization` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts:3` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Calls:**
- `Segmenter` (2)

### `Gzip`
`node:zlib:328` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `gzipSync` (2)

**Calls:**
- `Zlib` (1)
- `Zlib` (1)

### `resolveDiagramColors`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:52` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveAppearance` (1)

**Calls:**
- `safeCssToken` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:285` | Self: 0.0% (0us) | Total: 0.5% (23.0ms) | Samples: 0

**Called by:**
- `validatePaint` (3)
- `validatePaint` (1)

**Calls:**
- `match` (4)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:527` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `text` (1)

**Calls:**
- `copyDataProperties` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:563` | Self: 0.0% (0us) | Total: 0.2% (11.3ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (7)

**Calls:**
- `(anonymous)` (6)
- `(anonymous)` (1)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:709` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `node` (1)

**Calls:**
- `consumeStringBudget` (1)

### `styleSpecJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:609` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `roleStyleJsonSchema` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:195` | Self: 0.0% (0us) | Total: 0.5% (25.4ms) | Samples: 0

**Called by:**
- `renderClassBox` (8)

**Calls:**
- `resolvedColorValue` (6)
- `resolvedColorValue` (1)
- `resolvedColorValue` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:816` | Self: 0.0% (0us) | Total: 0.2% (9.3ms) | Samples: 0

**Called by:**
- `write` (6)

**Calls:**
- `validatePaint` (3)
- `validatePaint` (1)
- `validatePaint` (1)
- `validatePaint` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:732` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `renderMultilineText` (1)

**Calls:**
- `markPaintPrepared` (1)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:185` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

**Calls:**
- `scopeCss` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:138` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `map` (1)

### `assertInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:26` | Self: 0.0% (0us) | Total: 0.1% (7.0ms) | Samples: 0

**Called by:**
- `validateNode` (2)
- `group` (2)

**Calls:**
- `some` (4)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:517` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `paintAttribute` (1)

### `measureText`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:188` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `measureTextWidth` (4)

**Calls:**
- `getCharWidth` (2)
- `getCharWidth` (1)
- `getCharWidth` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:528` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `text` (1)

**Calls:**
- `map` (1)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1655` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `resolveDiagramColors` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:153` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (1)

**Calls:**
- `copyDataProperties` (1)

### `runMeasuredGraphBackend`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:73` | Self: 0.0% (0us) | Total: 16.2% (705.4ms) | Samples: 0

**Called by:**
- `layout` (337)

**Calls:**
- `(anonymous)` (115)
- `finishClassLayout` (100)
- `finishClassLayout` (94)
- `(anonymous)` (8)
- `(anonymous)` (5)
- `(anonymous)` (4)
- `(anonymous)` (2)
- `finishClassLayout` (1)
- `finishClassLayout` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `finishClassLayout` (1)
- `(anonymous)` (1)
- `finishClassLayout` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:554` | Self: 0.0% (0us) | Total: 0.1% (8.5ms) | Samples: 0

**Called by:**
- `assertFinalClassSharpContacts` (2)

**Calls:**
- `pay` (1)
- `pay` (1)

### `negotiateCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts:160` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `executionCapabilityDecision` (1)

**Calls:**
- `every` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1468` | Self: 0.0% (0us) | Total: 0.5% (23.1ms) | Samples: 0

**Called by:**
- `serialize` (14)

**Calls:**
- `boundedUtf8ByteLength` (14)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:682` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `map` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1262` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (2)

**Calls:**
- `validateConnectorProjectionConsistency` (1)
- `validateConnectorProjectionConsistency` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:618` | Self: 0.0% (0us) | Total: 0.3% (13.6ms) | Samples: 0

**Called by:**
- `group` (11)

**Calls:**
- `ensureSvgIdentity` (7)
- `replace` (2)
- `ensureSvgIdentity` (2)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1821` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `measureRenderStage` (2)

**Calls:**
- `deferredRequestReceiptDigest` (2)

### `finishClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:792` | Self: 0.0% (0us) | Total: 5.8% (254.6ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (100)

**Calls:**
- `assertClassMarkerMeaning` (45)
- `assertClassMarkerMeaning` (30)
- `assertClassMarkerMeaning` (15)
- `assertClassMarkerMeaning` (3)
- `assertClassMarkerMeaning` (2)
- `assertClassMarkerMeaning` (1)
- `assertClassMarkerMeaning` (1)
- `assertClassMarkerMeaning` (1)
- `assertClassMarkerMeaning` (1)
- `assertClassMarkerMeaning` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:609` | Self: 0.0% (0us) | Total: 0.3% (14.4ms) | Samples: 0

**Called by:**
- `validateNode` (3)
- `validateNode` (1)

**Calls:**
- `validateGeometry` (3)
- `validateGeometry` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` | Self: 0.0% (0us) | Total: 0.2% (12.3ms) | Samples: 0

**Called by:**
- `map` (9)

**Calls:**
- `cloneValue` (6)
- `map` (3)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1485` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (2)

**Calls:**
- `filter` (1)
- `requiredBackendCapabilities` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:197` | Self: 0.0% (0us) | Total: 0.7% (33.6ms) | Samples: 0

**Called by:**
- `renderClassBox` (12)

**Calls:**
- `resolvedColorValue` (7)
- `compositeCssColor` (3)
- `compositeCssColor` (2)

### `semanticIdentityForSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:62` | Self: 0.0% (0us) | Total: 0.1% (7.8ms) | Samples: 0

**Called by:**
- `group` (3)

**Calls:**
- `copyDataProperties` (3)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1776` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `Set` (1)

### `measureRenderStage`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:34` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

**Calls:**
- `(anonymous)` (1)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:688` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (2)

**Calls:**
- `preprocessMermaidSource` (1)
- `canonicalizeFrontmatterMap` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:103` | Self: 0.0% (0us) | Total: 3.0% (131.4ms) | Samples: 0

**Called by:**
- `finishClassLayout` (45)

**Calls:**
- `prepareMarkerPolygonInk` (20)
- `prepareMarkerPolygonInk` (12)
- `prepareMarkerPolygonInk` (2)
- `prepareMarkerPolygonInk` (2)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)
- `prepareMarkerPolygonInk` (1)

### `createNativePaintEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:55` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `drawNative` (2)

**Calls:**
- `createEmissionContext` (1)
- `createEmissionContext` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1049` | Self: 0.0% (0us) | Total: 0.1% (5.6ms) | Samples: 0

**Called by:**
- `report` (1)

**Calls:**
- `verifyNoExternalRefs` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:533` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `validatePoints` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:157` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `qualify` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:80` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `inspectPaint` (1)

**Calls:**
- `multiplySceneOpacity` (1)

### `snapshotScenePrimitiveCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1549` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `snapshotDescriptorArray` (1)

**Calls:**
- `copyDataProperties` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/c4/config.ts:68` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:292` | Self: 0.0% (0us) | Total: 0.3% (13.1ms) | Samples: 0

**Called by:**
- `connector` (6)

**Calls:**
- `ownConnectorEndpoint` (2)
- `ownConnectorEndpoint` (2)
- `ownConnectorEndpoint` (1)
- `ownConnectorEndpoint` (1)

### `executionCapabilityDecision`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1449` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveExecutionPlan` (1)

**Calls:**
- `executionCapabilityKey` (1)

### `assertFinalClassSharpContacts`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:866` | Self: 0.0% (0us) | Total: 0.8% (35.1ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (14)

**Calls:**
- `(anonymous)` (9)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)

### `require`
`[native code]` | Self: 0.0% (0us) | Total: 3.8% (165.6ms) | Samples: 0

**Called by:**
- `bound require` (96)

**Calls:**
- `anonymous` (96)

### `connectorInlineLabelSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:781` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (2)

**Calls:**
- `renderMultilineText` (1)
- `renderMultilineText` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:208` | Self: 0.0% (0us) | Total: 3.0% (131.6ms) | Samples: 0

**Called by:**
- `visit` (36)
- `visit` (32)

**Calls:**
- `leaf` (37)
- `leaf` (8)
- `leaf` (4)
- `leaf` (3)
- `leaf` (3)
- `leaf` (2)
- `leaf` (2)
- `leaf` (2)
- `leaf` (2)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)

### `registerBuiltInStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:292` | Self: 0.0% (0us) | Total: 0.1% (8.0ms) | Samples: 0

**Called by:**
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `validateStyleSpec` (2)
- `validateStyleSpec` (1)
- `validateStyleSpec` (1)

### `normalizeMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:665` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (4)

**Calls:**
- `(anonymous)` (4)

### `createOwnedNativePaintRecorder`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:203` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `inspectPaint` (1)

**Calls:**
- `createPaintRecorder` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:545` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:502` | Self: 0.0% (0us) | Total: 1.0% (47.0ms) | Samples: 0

**Called by:**
- `group` (27)

**Calls:**
- `nativeGroup` (18)
- `nativeGroup` (2)
- `result` (2)
- `nativeGroup` (2)
- `nativeGroup` (1)
- `nativeGroup` (1)
- `nativeGroup` (1)

### `omitUndefinedObjectFields`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:983` | Self: 0.0% (0us) | Total: 0.1% (5.9ms) | Samples: 0

**Called by:**
- `omitUndefinedObjectFields` (2)
- `boundedImmutableJsonSnapshot` (2)
- `omitUndefinedObjectFields` (1)

**Calls:**
- `omitUndefinedObjectFields` (2)
- `omitUndefinedObjectFields` (2)
- `omitUndefinedObjectFields` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1879` | Self: 0.0% (0us) | Total: 0.6% (28.0ms) | Samples: 0

**Called by:**
- `(module)` (19)

**Calls:**
- `validateDescriptor` (2)
- `validateDescriptor` (2)
- `validateDescriptor` (2)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:185` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (2)

**Calls:**
- `map` (1)
- `qualify` (1)

### `normalizeFamilyDetectionLine`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:142` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `classifyMermaidFamilyDescriptorFromFirstLine` (1)

**Calls:**
- `replace` (1)

### `retainClassRectangleContacts`
`/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:136` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `Map` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:316` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `validateNode` (1)
- `validateNode` (1)

**Calls:**
- `numericCss` (1)
- `numericCss` (1)

### `projectClassRectangleContacts`
`/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts:164` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (2)

**Calls:**
- `addClassSvgNumbers` (1)
- `addClassSvgNumbers` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:713` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `typographyAttributes` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:642` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `includes` (1)

### `element`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:477` | Self: 0.0% (0us) | Total: 0.1% (6.0ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (2)
- `writeConnectorSvg` (2)

**Calls:**
- `element` (4)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:764` | Self: 0.0% (0us) | Total: 0.6% (29.8ms) | Samples: 0

**Called by:**
- `classStatementEnds` (11)
- `parseClassDiagram` (8)

**Calls:**
- `classifyClassStatement` (9)
- `classifyClassStatement` (4)
- `classifyClassStatement` (3)
- `classifyClassStatement` (1)
- `classifyClassStatement` (1)
- `classifyClassStatement` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:10` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `map` (4)

**Calls:**
- `markerTerminalDepth` (4)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:171` | Self: 0.0% (0us) | Total: 1.0% (47.0ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (27)

**Calls:**
- `group` (27)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:196` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (2)

**Calls:**
- `/<\s*text/i` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:270` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `cloneObject` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:8` | Self: 0.0% (0us) | Total: 0.1% (6.8ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `bound require` (4)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:677` | Self: 0.0% (0us) | Total: 0.2% (10.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (6)

**Calls:**
- `unsafeCssReferences` (2)
- `unsafeCssReferences` (2)
- `unsafeCssReferences` (1)
- `unsafeCssReferences` (1)

### `classStatementEnds`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:669` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (1)

**Calls:**
- `visit` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:739` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (3)

**Calls:**
- `ActualTextPaintWrite` (2)
- `ActualTextPaintWrite` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1008` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `report` (4)

**Calls:**
- `drawn` (4)

### `extractClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:479` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `placeClassCardinalityLabels` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:9` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-measurement.ts:9` | Self: 0.0% (0us) | Total: 0.3% (13.4ms) | Samples: 0

**Called by:**
- `map` (5)

**Calls:**
- `flatIntoArrayWithCallback` (3)
- `markerPaintPieces` (1)
- `markerPaintPieces` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:711` | Self: 0.0% (0us) | Total: 0.8% (36.0ms) | Samples: 0

**Called by:**
- `seatFinalMeasuredMarkers` (23)

**Calls:**
- `clear` (10)
- `clear` (4)
- `clear` (3)
- `clear` (2)
- `clear` (2)
- `clear` (1)
- `clear` (1)

### `admitRenderOptionsInput`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1307` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (2)

**Calls:**
- `boundedImmutableJsonSnapshot` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:11` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:770` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `occurrence` (1)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:375` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `reserve` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1878` | Self: 0.0% (0us) | Total: 0.3% (15.7ms) | Samples: 0

**Called by:**
- `(module)` (11)

**Calls:**
- `freezeDescriptor` (6)
- `completeBuiltinDescriptor` (1)
- `freezeDescriptor` (1)
- `freezeDescriptor` (1)
- `completeBuiltinDescriptor` (1)
- `freezeDescriptor` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1783` | Self: 0.0% (0us) | Total: 0.2% (9.0ms) | Samples: 0

**Called by:**
- `measureRenderStage` (7)

**Calls:**
- `resolveExecutionPlan` (2)
- `resolveExecutionPlan` (2)
- `resolveExecutionPlan` (1)
- `resolveExecutionPlan` (1)
- `resolveExecutionPlan` (1)

### `inlineResolvedColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:636` | Self: 0.0% (0us) | Total: 1.2% (54.6ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (28)

**Calls:**
- `colorResolution` (25)
- `colorResolution` (2)
- `colorResolution` (1)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:465` | Self: 0.0% (0us) | Total: 0.1% (4.6ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (2)
- `assertFamilyGeometryOptions` (1)

**Calls:**
- `validate` (2)
- `validate` (1)

### `drawn`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:421` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `runBackendConformance` (4)

**Calls:**
- `serializeSceneNode` (4)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:17` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `scanStartTags` (1)

**Calls:**
- `has` (1)

### `snapshotBackendCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:330` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `freezeBuiltInBackend` (1)

**Calls:**
- `map` (1)

### `applyFamilyRequestNormalization`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1075` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `resolveAppearance` (1)

**Calls:**
- `assertFamilyGeometryOptions` (1)

### `inspectSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:688` | Self: 0.0% (0us) | Total: 0.1% (5.6ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `startTags` (1)

### `normalizeMermaidSourceWithOverrides`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:762` | Self: 0.0% (0us) | Total: 0.8% (38.1ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (21)

**Calls:**
- `normalizeSource` (11)
- `normalizeMermaidSource` (4)
- `normalizeSource` (2)
- `normalizeSource` (2)
- `normalizeSource` (1)
- `normalizeMermaidSource` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:19` | Self: 0.0% (0us) | Total: 0.5% (22.5ms) | Samples: 0

**Calls:**
- `zlibBufferSync` (9)
- `stringify` (5)
- `zlibBufferSync` (2)
- `gzipSync` (2)
- `writeFileSync` (1)

### `isCombiningMark`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:49` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `getCharWidth` (1)

**Calls:**
- `isZeroWidth` (1)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1667` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `unsafeThemeColorKeys` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:316` | Self: 0.0% (0us) | Total: 0.1% (6.3ms) | Samples: 0

**Called by:**
- `connector` (4)

**Calls:**
- `assertMarkAttributes` (2)
- `assertMarkAttributes` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `resolveSvgColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:758` | Self: 0.0% (0us) | Total: 0.2% (11.1ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (6)

**Calls:**
- `join` (2)
- `transformSvgCssValues` (2)
- `applyReplacements` (1)
- `applyReplacements` (1)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:64` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `finishClassLayout` (1)

**Calls:**
- `Number` (1)

### `createExtensionIdentity`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:246` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `completeBuiltinDescriptor` (1)

**Calls:**
- `evaluateExtensionCompatibility` (1)

### `renderedSvgDigest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:61` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `stringify` (3)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:430` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `measureClassCards` (1)

**Calls:**
- `every` (1)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:454` | Self: 0.0% (0us) | Total: 0.0% (3.9ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (3)

**Calls:**
- `sharedRenderOptionsJsonSchema` (2)
- `deepFreeze` (1)

### `validateStyleSpec`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:445` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (1)

**Calls:**
- `numberIsValid` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:424` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `measureClassCards` (1)

**Calls:**
- `qualify` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:560` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `completeBuiltinDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1374` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `createExtensionIdentity` (1)

### `Zlib`
`node:zlib:298` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Gzip` (1)

**Calls:**
- `ZlibBase` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1583` | Self: 0.0% (0us) | Total: 0.1% (7.4ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (6)

**Calls:**
- `snapshotDescriptorArray` (5)
- `freeze` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1031` | Self: 0.0% (0us) | Total: 1.1% (48.6ms) | Samples: 0

**Called by:**
- `report` (16)

**Calls:**
- `rendered` (16)

### `toMermaidLines`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:100` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `extractInitDirectives` (1)

**Calls:**
- `map` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:169` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `getOwnPropertyDescriptors` (1)

### `layoutMeasuredForest`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:96` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `map` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:196` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `renderClassBox` (1)

**Calls:**
- `resolvedColorValue` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:874` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `write` (4)

**Calls:**
- `validatePaint` (2)
- `validatePaint` (1)
- `validatePaint` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:117` | Self: 0.0% (0us) | Total: 0.0% (4.0ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (2)

**Calls:**
- `assertMarkerPaint` (1)
- `assertMarkerPaint` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:101` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `shape` (1)

**Calls:**
- `typedIdentity` (1)

### `retainTextPaintPresence`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:81` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `hasOwn` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1131` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `receiptOf` (1)

**Calls:**
- `canonicalJson` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:597` | Self: 0.0% (0us) | Total: 0.1% (6.6ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `transformedBounds` (1)

### `_toPropertyKey`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:12` | Self: 0.0% (0us) | Total: 3.0% (130.5ms) | Samples: 0

**Called by:**
- `_defineProperties` (1)

**Calls:**
- `_toPrimitive` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:458` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Called by:**
- `connector` (2)

**Calls:**
- `copyDataProperties` (2)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:33` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `prepareDisplayText` (1)

**Calls:**
- `delete` (1)

### `renderRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:585` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (1)

**Calls:**
- `String` (1)

### `authoredClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:107` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/resolve-flow-collection.js:7` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1088` | Self: 0.0% (0us) | Total: 0.1% (6.7ms) | Samples: 0

**Called by:**
- `report` (5)

**Calls:**
- `map` (5)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:131` | Self: 0.0% (0us) | Total: 10.2% (447.0ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (230)

**Calls:**
- `leaf` (193)
- `connector` (30)
- `renderRelationship` (2)
- `renderRelationship` (1)
- `renderRelationship` (1)
- `renderRelationship` (1)
- `renderRelationship` (1)
- `renderRelationship` (1)

### `transformedHitDistance`
`/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:32` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `hitsTransformed` (1)

**Calls:**
- `distanceToSegment` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:191` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `serializeMarkerResource` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:115` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:75` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `validateSerializableRenderOptions` (2)

**Calls:**
- `filter` (2)

### `absentPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:102` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `tryParseCssColor` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:693` | Self: 0.0% (0us) | Total: 0.1% (6.6ms) | Samples: 0

**Called by:**
- `measureRenderStage` (2)

**Calls:**
- `classTerminalLead` (2)

### `terminalMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:58` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `deriveConnectorTerminalProjection` (1)

**Calls:**
- `optional` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:394` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `map` (1)

### `parseClassDeclaration`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:170` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `classifyClassStatement` (1)

**Calls:**
- `match` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:144` | Self: 0.0% (0us) | Total: 3.0% (134.9ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (95)

**Calls:**
- `forEach` (95)

### `expandLocalReferences`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `(module)` (2)
- `(anonymous)` (1)

**Calls:**
- `map` (3)

### `internal:streams/legacy`
`internal:streams/legacy:2` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:102` | Self: 0.0% (0us) | Total: 0.2% (9.9ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (4)

**Calls:**
- `serializeMarkerResources` (4)

### `detectorClaims`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1596` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `find` (3)

**Calls:**
- `descriptorOwnsDetectionLine` (2)
- `some` (1)

### `rectangleInput`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:341` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:14` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `connectorMarkerPaintRegions`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:352` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (1)

**Calls:**
- `forEach` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:3` | Self: 0.0% (0us) | Total: 6.3% (275.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (4)

**Calls:**
- `bound require` (4)

### `processChunkSync`
`node:zlib:203` | Self: 0.0% (0us) | Total: 0.2% (10.7ms) | Samples: 0

**Called by:**
- `zlibBufferSync` (9)

**Calls:**
- `writeSync` (9)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:722` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `paintAttributes` (2)

### `checkRect`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:229` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `assessFamilyLayout` (1)

**Calls:**
- `finiteRect` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:156` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (2)

**Calls:**
- `appendPrivate` (2)

### `deferredRequestReceiptDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1108` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (2)
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `deferredRenderContractDigest` (3)

### `_createClass`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:11` | Self: 0.0% (0us) | Total: 3.0% (130.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `_defineProperties` (1)

### `admitSceneDocumentWith`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:270` | Self: 0.0% (0us) | Total: 0.7% (34.5ms) | Samples: 0

**Called by:**
- `render` (15)

**Calls:**
- `assertAdmissibleSceneDoc` (15)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1856` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (2)

**Calls:**
- `find` (2)

### `registerCanonicalStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:236` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (1)

**Calls:**
- `registerExtension` (1)

### `finalizeClassSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:834` | Self: 0.0% (0us) | Total: 0.8% (36.3ms) | Samples: 0

**Called by:**
- `finishClassLayout` (15)

**Calls:**
- `assertFinalClassSharpContacts` (14)
- `assertFinalClassSharpContacts` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:423` | Self: 0.0% (0us) | Total: 0.1% (7.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `xmlHasColon` (1)
- `xmlHasColon` (1)

### `documentOpen`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:129` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (2)

**Calls:**
- `snapshot` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:883` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `validatePaint` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:161` | Self: 0.0% (0us) | Total: 0.3% (14.9ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (9)

**Calls:**
- `renderRelationshipLabels` (9)

### `parseClassRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1289` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `classifyClassStatement` (1)

**Calls:**
- `classCommentStart` (1)

### `inspectPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:98` | Self: 0.0% (0us) | Total: 3.8% (168.0ms) | Samples: 0

**Called by:**
- `drawNative` (90)

**Calls:**
- `visit` (47)
- `visit` (33)
- `visit` (5)
- `visit` (2)
- `visit` (1)
- `visit` (1)
- `visit` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:731` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `renderMultilineText` (2)

**Calls:**
- `prepared` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1024` | Self: 0.0% (0us) | Total: 0.0% (4.2ms) | Samples: 0

**Called by:**
- `write` (3)

**Calls:**
- `validatePoint` (2)
- `validatePoint` (1)

### `geometryElements`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:77` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `serializeMarkerResource` (1)

**Calls:**
- `pointList` (1)

### `withTextMeasurementExecution`
`/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:135` | Self: 0.0% (0us) | Total: 100.0% (5.40s) | Samples: 0

**Called by:**
- `consumeResolvedGraphicalRequest` (1404)
- `retainedNativeDrawing` (1083)
- `positionFamilyForNativeRender` (413)
- `runBackendConformance` (6)

**Calls:**
- `renderPositionedWithTextMeasurement` (1119)
- `drawNative` (977)
- `(anonymous)` (405)
- `renderPositionedWithTextMeasurement` (219)
- `drawNative` (94)
- `renderPositionedWithTextMeasurement` (35)
- `renderPositionedWithTextMeasurement` (17)
- `renderPositionedWithTextMeasurement` (13)
- `(anonymous)` (6)
- `drawNative` (4)
- `drawNative` (3)
- `drawNative` (2)
- `(anonymous)` (2)
- `createFixture` (1)
- `deepFreeze` (1)
- `createFixture` (1)
- `createFixture` (1)
- `createFixture` (1)
- `renderPositionedWithTextMeasurement` (1)
- `drawNative` (1)
- `createFixture` (1)
- `drawNative` (1)
- `drawNative` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-scalar.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:154` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `classOwnedSurfaceViolations` (1)

**Calls:**
- `emittedBox` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:323` | Self: 0.0% (0us) | Total: 0.2% (12.1ms) | Samples: 0

**Called by:**
- `measureClassCards` (7)

**Calls:**
- `prepareDisplayText` (2)
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)

### `sameRectanglePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:359` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `getOwnPropertyDescriptor` (2)

### `positionFamilyForNativeRender`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:67` | Self: 0.0% (0us) | Total: 18.8% (821.8ms) | Samples: 0

**Called by:**
- `measureRenderStage` (413)

**Calls:**
- `withTextMeasurementExecution` (413)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:615` | Self: 0.0% (0us) | Total: 0.2% (11.0ms) | Samples: 0

**Called by:**
- `leaf` (8)

**Calls:**
- `markerBoundsAt` (5)
- `markerBoundsAt` (2)
- `markerBoundsAt` (1)

### `color`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1038` | Self: 0.0% (0us) | Total: 0.3% (14.1ms) | Samples: 0

**Called by:**
- `prepareMarkerPolygonInk` (8)

**Calls:**
- `resolvedInlineColorAttribute` (5)
- `(anonymous)` (2)
- `resolvedInlineColorAttribute` (1)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1190` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `layout` (2)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `layoutMeasuredForest`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:42` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `mainSize` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:142` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `projectClassPositioned` (1)
- `projectClassPositioned` (1)

### `graphicalBackendCapabilityClaims`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:271` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `createSketchBackend` (1)

**Calls:**
- `validatePrimitiveCapabilities` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:308` | Self: 0.0% (0us) | Total: 3.0% (134.2ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (66)

**Calls:**
- `leaf` (64)
- `shape` (2)

### `sourceEnvelopeMetadata`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:809` | Self: 0.0% (0us) | Total: 0.2% (12.3ms) | Samples: 0

**Called by:**
- `normalizeSource` (9)

**Calls:**
- `installedFamilyStatementEnds` (9)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:13` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `freeze` (1)

### `internal:streams/destroy`
`internal:streams/destroy:2` | Self: 0.0% (0us) | Total: 0.1% (6.4ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `inspectOwnedSvgOnce`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:46` | Self: 0.0% (0us) | Total: 9.1% (399.8ms) | Samples: 0

**Called by:**
- `applyOutputSecurityPolicy` (223)
- `verifyNoExternalRefs` (1)
- `header` (1)

**Calls:**
- `(anonymous)` (221)
- `(anonymous)` (1)
- `scanStartTags` (1)
- `inspectSecurity` (1)
- `inspectSecurityTail` (1)

### `snapshotDescriptorArray`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1501` | Self: 0.0% (0us) | Total: 0.1% (7.3ms) | Samples: 0

**Called by:**
- `freezeDescriptor` (5)
- `snapshotScenePrimitiveCell` (1)

**Calls:**
- `snapshotScenePrimitiveCell` (3)
- `get` (1)
- `snapshotScenePrimitiveCell` (1)
- `snapshotScenePrimitiveCell` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:153` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `stringify` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1051` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `finite` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:725` | Self: 0.0% (0us) | Total: 8.7% (382.7ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (221)

**Calls:**
- `verifyDocumentEnvelope` (83)
- `verifyDocumentEnvelope` (43)
- `verifyDocumentEnvelope` (29)
- `verifyDocumentEnvelope` (22)
- `verifyDocumentEnvelope` (18)
- `verifyDocumentEnvelope` (7)
- `verifyDocumentEnvelope` (4)
- `verifyDocumentEnvelope` (4)
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)

### `knownOwned`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:8` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `copy` (1)

**Calls:**
- `(unknown)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:4` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:41` | Self: 0.0% (0us) | Total: 0.2% (9.0ms) | Samples: 0

**Called by:**
- `attribute` (4)

**Calls:**
- `replace` (3)
- `(anonymous)` (1)

### `internal:streams/pipeline`
`internal:streams/pipeline:2` | Self: 0.0% (0us) | Total: 0.2% (11.6ms) | Samples: 0

**Called by:**
- `anonymous` (6)

**Calls:**
- `anonymous` (6)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:6` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `anonymous` (3)

**Calls:**
- `bound require` (3)

### `assertFinalBoundaryContacts`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:359` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `finalizeFlatMeasuredMarkers` (1)

**Calls:**
- `map` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1814` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `deferredRequestReceiptDigest` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:143` | Self: 0.0% (0us) | Total: 0.2% (10.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (6)

**Calls:**
- `assessRenderedLayoutHardViolations` (6)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:125` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `emitGraphLayoutDecision` (1)

**Calls:**
- `retainRequestGraphLayoutDecision` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1702` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `performIteration` (1)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1656` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (2)

**Calls:**
- `applyFamilyRequestNormalization` (1)
- `applyFamilyRequestNormalization` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:35` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `some` (2)

**Calls:**
- `crossSize` (1)
- `crossSize` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:284` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `connector` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:646` | Self: 0.0% (0us) | Total: 0.4% (18.9ms) | Samples: 0

**Called by:**
- `leaf` (8)

**Calls:**
- `pathBounds` (3)
- `pathBounds` (2)
- `pathBounds` (1)
- `pathBounds` (1)
- `geometryBounds` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:738` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `includes` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:200` | Self: 0.0% (0us) | Total: 41.2% (1.79s) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (977)

**Calls:**
- `withDeferredTerminalProjections` (977)

### `intersects`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:214` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `clear` (1)

**Calls:**
- `charge` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:519` | Self: 0.0% (0us) | Total: 0.0% (4.2ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `paintAttribute` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:637` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `defineProperty` (1)

### `placeClassCardinalityLabels`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:549` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `extractClassLayout` (1)

**Calls:**
- `some` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:397` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `xmlHasColon` (1)

### `retainedLabelGeometry`
`/tmp/pr449-main-integration-20261029-762/src/agent/layout-to-rendered.ts:25` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `retainedLabelBounds` (1)

### `connectorGeometryEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:180` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `cloneObject` (1)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:720` | Self: 0.0% (0us) | Total: 0.1% (5.7ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (3)

**Calls:**
- `compareSvgSum` (3)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1096` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `safeCssPaint` (1)

### `installedFamilyStatementEnds`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts:76` | Self: 0.0% (0us) | Total: 0.5% (23.2ms) | Samples: 0

**Called by:**
- `sourceEnvelopeMetadata` (9)
- `normalizeSource` (2)

**Calls:**
- `some` (11)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:134` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (2)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `internal:stream`
`internal:stream:2` | Self: 0.0% (0us) | Total: 0.3% (16.4ms) | Samples: 0

**Called by:**
- `anonymous` (8)

**Calls:**
- `anonymous` (8)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:176` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `include` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:903` | Self: 0.0% (0us) | Total: 0.3% (14.1ms) | Samples: 0

**Called by:**
- `node` (10)

**Calls:**
- `assertInertGroup` (6)
- `assertInertGroup` (2)
- `assertInertGroup` (2)

### `expandLocalReferences`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:204` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `filter` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:153` | Self: 0.0% (0us) | Total: 0.3% (14.1ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `serializeSceneNode` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:500` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `selfContact` (1)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:218` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `validateGeometry` (2)

**Calls:**
- `skipSeparators` (2)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:825` | Self: 0.0% (0us) | Total: 0.3% (13.8ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (9)

**Calls:**
- `identityAttributes` (5)
- `identityAttributes` (1)
- `identityAttributes` (1)
- `identityAttributes` (1)
- `identityAttributes` (1)

### `connector/transform/render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:631` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `hitsTransformed` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:564` | Self: 0.0% (0us) | Total: 0.2% (9.1ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `Number` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1047` | Self: 0.0% (0us) | Total: 0.1% (7.8ms) | Samples: 0

**Called by:**
- `write` (4)
- `validateSceneDocument` (1)

**Calls:**
- `validateGeometry` (3)
- `validateGeometry` (1)
- `validateGeometry` (1)

### `compareCodePointStrings`
`/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts:3` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `sort` (1)

**Calls:**
- `map` (1)

### `getBackendDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:524` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveExecutionPlan` (1)

**Calls:**
- `knownBackendDescriptors` (1)

### `inertRectangleRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:306` | Self: 0.0% (0us) | Total: 0.0% (4.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:736` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `issue` (1)
- `issue` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:203` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `copyInner` (2)

**Calls:**
- `retainTextPaintPresence` (1)
- `retainTextPaintPresence` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:214` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `connector` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:555` | Self: 0.0% (0us) | Total: 0.4% (17.6ms) | Samples: 0

**Called by:**
- `assertFinalClassSharpContacts` (9)

**Calls:**
- `scoreMeasuredRouteCrossingsWithAdmission` (3)
- `scoreMeasuredRouteCrossingsWithAdmission` (3)
- `scoreMeasuredRouteCrossingsWithAdmission` (1)
- `scoreMeasuredRouteCrossingsWithAdmission` (1)
- `scoreMeasuredRouteCrossingsWithAdmission` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:652` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `leaf` (3)

**Calls:**
- `paintedStrokeExtent` (1)
- `paintedStrokeExtent` (1)
- `paintedStrokeExtent` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:199` | Self: 0.0% (0us) | Total: 0.0% (993us) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `group` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:201` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `factOf` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:154` | Self: 0.0% (0us) | Total: 0.1% (5.8ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (2)

**Calls:**
- `hasOwn` (2)

### `nativePaintAncestors`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:196` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `freeze` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:219` | Self: 0.0% (0us) | Total: 2.2% (97.0ms) | Samples: 0

**Called by:**
- `copyInner` (57)

**Calls:**
- `copyInner` (50)
- `copyInner` (3)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:13` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Calls:**
- `bound require` (2)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:810` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `renderDivider`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:408` | Self: 0.0% (0us) | Total: 0.1% (4.6ms) | Samples: 0

**Called by:**
- `renderClassBox` (2)
- `renderClassBox` (1)

**Calls:**
- `shape` (3)

### `validateAggregateReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1520` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `has` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:593` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `paintedStrokeExtent` (1)

### `detectInstalledFamilyDescriptorFromFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts:60` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `classifyMermaidFamilyDescriptorFromFirstLine` (3)

**Calls:**
- `detectRegisteredFamilyDescriptorFromFirstLine` (3)

### `parseClassRelationEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1400` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `parseMarkedClassRelationship` (1)

**Calls:**
- `classRelationText` (1)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:437` | Self: 0.0% (0us) | Total: 0.3% (14.8ms) | Samples: 0

**Called by:**
- `group` (9)

**Calls:**
- `freeze` (9)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:185` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Calls:**
- `map` (2)

### `markerPaintPieces`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:27` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `parseFloat` (1)

### `parseMarkedClassRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1296` | Self: 0.0% (0us) | Total: 0.0% (989us) | Samples: 0

**Called by:**
- `classifyClassStatement` (1)

**Calls:**
- `findMarkerlessRelationshipOperator` (1)

### `writtenClassRoundedHit`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:148` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `classOwnedSurfaceViolations` (2)

**Calls:**
- `emittedBox` (2)

### `preprocessMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:869` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `normalizeSource` (1)

**Calls:**
- `extractInitDirectives` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:88` | Self: 0.0% (0us) | Total: 0.1% (6.0ms) | Samples: 0

**Called by:**
- `visit` (3)

**Calls:**
- `observe` (1)
- `observe` (1)
- `observe` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `filter` (1)

### `finalizeFlatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:655` | Self: 0.0% (0us) | Total: 3.7% (162.6ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (95)

**Calls:**
- `seatFinalMeasuredMarkers` (93)
- `seatFinalMeasuredMarkers` (1)
- `seatFinalMeasuredMarkers` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:8` | Self: 0.0% (0us) | Total: 0.2% (12.1ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `bound require` (9)

### `assertClassMarkerMeaning`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts:98` | Self: 0.0% (0us) | Total: 0.0% (3.9ms) | Samples: 0

**Called by:**
- `finishClassLayout` (3)

**Calls:**
- `cloneObject` (2)
- `copyDataProperties` (1)

### `applyOutputSecurityPolicy`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:742` | Self: 0.0% (0us) | Total: 9.1% (396.1ms) | Samples: 0

**Called by:**
- `measureRenderStage` (219)
- `validateSceneDocument` (5)
- `runBackendConformance` (1)

**Calls:**
- `inspectOwnedSvgOnce` (223)
- `inspectOwnedSvgOnce` (1)
- `inspectOwnedSvgOnce` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:206` | Self: 0.0% (0us) | Total: 0.0% (3.9ms) | Samples: 0

**Calls:**
- `createCliRenderOutputDescriptors` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:543` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1773` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `some` (1)

### `paintAttribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:493` | Self: 0.0% (0us) | Total: 0.2% (9.6ms) | Samples: 0

**Called by:**
- `paintAttributes` (3)
- `paintAttributes` (1)
- `paintAttributes` (1)

**Calls:**
- `attribute` (3)
- `attribute` (2)

### `renderDisplayRuns`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:152` | Self: 0.0% (0us) | Total: 0.0% (3.9ms) | Samples: 0

**Called by:**
- `renderMultilineText` (3)

**Calls:**
- `every` (3)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:24` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `hasOwned` (1)

### `inspectOwnedSvgOnce`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:49` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `applyOutputSecurityPolicy` (1)

**Calls:**
- `set` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:82` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `pathBounds` (1)

**Calls:**
- `isFinite` (1)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:676` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `normalizeCssObfuscation` (1)
- `normalizeCssObfuscation` (1)

### `internal:streams/operators`
`internal:streams/operators:2` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:318` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (2)

**Calls:**
- `topRoundedRectPath` (1)
- `topRoundedRectPath` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `map` (3)

**Calls:**
- `expandLocalReferences` (1)
- `expandLocalReferences` (1)
- `expandLocalReferences` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:709` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:465` | Self: 0.0% (0us) | Total: 0.7% (32.8ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (15)
- `connector` (1)

**Calls:**
- `setConnectorTerminalProjection` (15)
- `setConnectorTerminalProjection` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:802` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (3)

**Calls:**
- `element` (2)
- `element` (1)

### `finalizeClassSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:802` | Self: 0.0% (0us) | Total: 0.1% (8.4ms) | Samples: 0

**Called by:**
- `finishClassLayout` (5)

**Calls:**
- `projectClassRectangleContacts` (2)
- `projectClassRectangleContacts` (2)
- `projectClassRectangleContacts` (1)

### `projectClassPositioned`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts:23` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `map` (1)

### `finiteNumber`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:175` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `svgPathDataProblem` (2)

**Calls:**
- `skipSeparators` (2)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:605` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Called by:**
- `validateNode` (1)
- `validateNode` (1)

**Calls:**
- `boundedString` (1)
- `boundedString` (1)

### `scoreMeasuredRouteCrossingsWithAdmission`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:846` | Self: 0.0% (0us) | Total: 0.5% (24.0ms) | Samples: 0

**Called by:**
- `validate` (12)

**Calls:**
- `sharpContactsClear` (6)
- `sharpContactsClear` (2)
- `sharpContactsClear` (2)
- `sharpContactsClear` (1)
- `sharpContactsClear` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:555` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `retainTextPaintPresence`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:71` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `isExtensible` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 12.0% (522.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (2)
- `r` (1)
- `o` (1)

### `clear`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:365` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `seatMeasuredMarkers` (2)

**Calls:**
- `charge` (1)
- `charge` (1)

### `visitSvgFirstTagAttributes`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:79` | Self: 0.0% (0us) | Total: 0.4% (17.6ms) | Samples: 0

**Called by:**
- `assertInertGroup` (9)

**Calls:**
- `scanStartTags` (3)
- `scanStartTags` (2)
- `scanStartTags` (2)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:634` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `group` (2)

**Calls:**
- `copyDataProperties` (2)

### `render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:152` | Self: 0.0% (0us) | Total: 0.3% (14.1ms) | Samples: 0

**Called by:**
- `rendered` (1)

**Calls:**
- `map` (1)

### `measureClassCards`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:186` | Self: 0.0% (0us) | Total: 0.7% (32.2ms) | Samples: 0

**Called by:**
- `layoutClassDiagram` (21)

**Calls:**
- `preparePixelText` (8)
- `preparePixelText` (7)
- `preparePixelText` (2)
- `preparePixelText` (1)
- `preparePixelText` (1)
- `preparePixelText` (1)
- `preparePixelText` (1)

### `escapeAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:109` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `attribute` (3)

**Calls:**
- `escapeXml` (2)
- `escapeXml` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:665` | Self: 0.0% (0us) | Total: 12.1% (527.9ms) | Samples: 0

**Called by:**
- `leaf` (281)

**Calls:**
- `serialize` (281)

### `inspectPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:61` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `createOwnedNativePaintRecorder` (1)

### `classTerminalLead`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:215` | Self: 0.0% (0us) | Total: 0.1% (6.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `classRelationshipTerminalClearance` (1)
- `classRelationshipTerminalClearance` (1)

### `unsafeCssReferences`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:614` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `inspectAttributeSecurity` (2)

**Calls:**
- `normalizeCssObfuscation` (1)
- `normalizeCssObfuscation` (1)

### `nativePaintSource`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:228` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `copyDataProperties` (1)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:694` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `diagramColorVariables` (2)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:125` | Self: 0.0% (0us) | Total: 0.6% (27.1ms) | Samples: 0

**Called by:**
- `renderDivider` (3)
- `renderClassBox` (3)
- `renderClassBox` (2)
- `renderClassBox` (1)

**Calls:**
- `shape` (3)
- `shape` (1)
- `shape` (1)
- `shape` (1)
- `shape` (1)
- `shape` (1)
- `shape` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:126` | Self: 0.0% (0us) | Total: 0.8% (34.8ms) | Samples: 0

**Called by:**
- `renderClassBox` (18)

**Calls:**
- `text` (9)
- `text` (3)
- `text` (1)
- `text` (1)
- `text` (1)
- `text` (1)
- `text` (1)
- `text` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:3` | Self: 0.0% (0us) | Total: 0.8% (38.3ms) | Samples: 0

**Calls:**
- `bound require` (20)

### `finalizeFlatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:657` | Self: 0.0% (0us) | Total: 0.1% (6.4ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (3)

**Calls:**
- `assertFinalBoundaryContacts` (1)
- `assertFinalBoundaryContacts` (1)
- `assertFinalBoundaryContacts` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:111` | Self: 0.0% (0us) | Total: 1.7% (77.9ms) | Samples: 0

**Called by:**
- `measureRenderStage` (34)

**Calls:**
- `report` (33)
- `get conformance` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:322` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `measureClassCards` (2)

**Calls:**
- `get` (1)
- `get` (1)

### `internal:errors`
`internal:errors:2` | Self: 0.0% (0us) | Total: 0.1% (6.4ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:15` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:805` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `attribute` (1)
- `attribute` (1)

### `registerBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:468` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `validateBackendCapabilities` (1)
- `validateBackendCapabilities` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:703` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `classStatementEnds` (1)
- `parseClassDiagram` (1)

**Calls:**
- `scanInlineNamespaceStatement` (1)
- `scanInlineNamespaceStatement` (1)

### `canonicalJson`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1091` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `canonicalJson` (1)

**Calls:**
- `map` (1)

### `rectangleInput`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:344` | Self: 0.0% (0us) | Total: 0.2% (11.0ms) | Samples: 0

**Called by:**
- `leaf` (8)

**Calls:**
- `rectanglePaint` (5)
- `inertRectangleRecord` (1)
- `inertRectangleRecord` (1)
- `rectanglePaint` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:143` | Self: 0.0% (0us) | Total: 0.2% (12.1ms) | Samples: 0

**Called by:**
- `nativeGroup` (7)

**Calls:**
- `freeze` (7)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:116` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (1)

**Calls:**
- `map` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:275` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `writeTextSvg` (4)

**Calls:**
- `renderDisplayRuns` (3)
- `renderDisplayRuns` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:605` | Self: 0.0% (0us) | Total: 0.3% (13.3ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (7)

**Calls:**
- `attribute` (6)
- `attribute` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:186` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `map` (2)

**Calls:**
- `createExtensionIdentity` (2)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:169` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `paintPrimitiveSource` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:640` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `copyDataProperties` (1)

### `resolvedColorValue`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:598` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `toneOnFill` (1)

**Calls:**
- `isHexColor` (1)

### `validateConnectorProjectionConsistency`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1359` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `every` (1)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:697` | Self: 0.0% (0us) | Total: 0.2% (10.9ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (2)

**Calls:**
- `installedFamilyStatementEnds` (2)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1488` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `assertAdmissibleSceneDoc`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation.ts:247` | Self: 0.0% (0us) | Total: 0.7% (34.5ms) | Samples: 0

**Called by:**
- `admitSceneDocumentWith` (15)

**Calls:**
- `validateSceneDocument` (9)
- `validateSceneDocument` (5)
- `validateSceneDocument` (1)

### `Zlib`
`node:zlib:297` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Gzip` (1)

**Calls:**
- `NativeZlib` (1)

### `admitRenderContractDigestInput`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1150` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `deferredRenderContractDigest` (3)

**Calls:**
- `boundedImmutableJsonSnapshot` (3)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:754` | Self: 0.0% (0us) | Total: 0.0% (4.0ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (3)

**Calls:**
- `classStatement` (3)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:321` | Self: 0.0% (0us) | Total: 1.8% (81.6ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (47)

**Calls:**
- `leaf` (44)
- `shape` (3)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringifyPair.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:716` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `classStatementEnds` (1)

**Calls:**
- `continuesClassText` (1)

### `relativeLuminance`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:78` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `contrastRatio` (2)

**Calls:**
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)

### `registerBuiltInStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:294` | Self: 0.0% (0us) | Total: 0.2% (9.2ms) | Samples: 0

**Called by:**
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `registerCanonicalStyle` (1)
- `registerCanonicalStyle` (1)

### `getCharWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:88` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureText` (1)

**Calls:**
- `isCombiningMark` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1502` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (3)

**Calls:**
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)

### `normalizeMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:663` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `mermaidFirstLine` (1)

### `styleSpecJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:608` | Self: 0.0% (0us) | Total: 1.6% (73.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (7)

**Calls:**
- `fromEntries` (6)
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:11` | Self: 0.0% (0us) | Total: 0.1% (5.3ms) | Samples: 0

**Called by:**
- `map` (2)

**Calls:**
- `markerTerminalDepth` (1)
- `markerTerminalDepth` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:16` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:358` | Self: 0.0% (0us) | Total: 0.2% (12.5ms) | Samples: 0

**Called by:**
- `seatFinalMeasuredMarkers` (6)

**Calls:**
- `pose` (2)
- `pose` (2)
- `pose` (1)
- `pose` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1756` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `includes` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:705` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `classStatementEnds` (1)

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:719` | Self: 0.0% (0us) | Total: 0.1% (6.7ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (4)

**Calls:**
- `extractClassLayout` (1)
- `extractClassLayout` (1)
- `extractClassLayout` (1)
- `extractClassLayout` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:589` | Self: 0.0% (0us) | Total: 0.6% (27.3ms) | Samples: 0

**Called by:**
- `group` (15)

**Calls:**
- `semanticIdentityForSvg` (8)
- `semanticIdentityForSvg` (3)
- `semanticIdentityForSvg` (2)
- `semanticIdentityForSvg` (2)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:14` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Calls:**
- `get receipt` (1)
- `now` (1)

### `immutableSnapshot`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1221` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `entries` (1)

### `omitUndefinedObjectFields`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:974` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `boundedImmutableJsonSnapshot` (1)

**Calls:**
- `add` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:43` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `replace` (1)

**Calls:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:601` | Self: 0.0% (0us) | Total: 2.2% (98.7ms) | Samples: 0

**Called by:**
- `seatMeasuredMarkers` (57)

**Calls:**
- `validate` (25)
- `validate` (16)
- `validate` (6)
- `validate` (4)
- `validate` (2)
- `validate` (1)
- `validate` (1)
- `validate` (1)
- `validate` (1)

### `projectSvgCss`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:249` | Self: 0.0% (0us) | Total: 1.1% (50.0ms) | Samples: 0

**Called by:**
- `colorResolution` (25)

**Calls:**
- `scanStartTags` (8)
- `scanStartTags` (5)
- `scanStartTags` (2)
- `scanStartTags` (2)
- `scanStartTags` (2)
- `scanStartTags` (2)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `clear`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:362` | Self: 0.0% (0us) | Total: 0.4% (17.6ms) | Samples: 0

**Called by:**
- `seatMeasuredMarkers` (10)

**Calls:**
- `(anonymous)` (5)
- `(anonymous)` (4)
- `(anonymous)` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1481` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `viewportBox` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:632` | Self: 0.0% (0us) | Total: 1.0% (46.0ms) | Samples: 0

**Called by:**
- `leaf` (30)

**Calls:**
- `serialize` (30)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`[native code]` | Self: 0.0% (0us) | Total: 0.1% (6.0ms) | Samples: 0

**Called by:**
- `zlibBufferSync` (2)
- `(module)` (2)
- `(module)` (1)

**Calls:**
- `Buffer` (5)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:245` | Self: 0.0% (0us) | Total: 0.1% (8.3ms) | Samples: 0

**Called by:**
- `connectorPaintBounds` (2)
- `include` (2)
- `markerTerminalDepth` (2)

**Calls:**
- `paintedStrokeExtent` (2)
- `paintedStrokeExtent` (2)
- `paintedStrokeExtent` (1)
- `paintedStrokeExtent` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:603` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `flatIntoArrayWithCallback` (1)
- `flatMap` (1)

### `validateBackendCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:302` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `registerBuiltInBackend` (1)

**Calls:**
- `validatePrimitiveCapabilities` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-format/src/defaultLocale.js:7` | Self: 0.0% (0us) | Total: 0.1% (6.9ms) | Samples: 0

**Calls:**
- `defaultLocale` (1)

### `compareSvgSum`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:41` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `classOwnedSurfaceViolations` (1)

**Calls:**
- `writtenDecimalParts` (1)

### `seatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts:1026` | Self: 0.0% (0us) | Total: 2.3% (100.2ms) | Samples: 0

**Called by:**
- `seatFinalMeasuredMarkers` (58)

**Calls:**
- `(anonymous)` (57)
- `(anonymous)` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:247` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `leaf` (3)

**Calls:**
- `nativePaintSource` (1)
- `nativePaintSource` (1)
- `nativePaintSource` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:214` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `finish` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:462` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (1)

**Calls:**
- `copyDataProperties` (1)

### `positionedPaintCertification`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:154` | Self: 0.0% (0us) | Total: 0.6% (29.4ms) | Samples: 0

**Called by:**
- `measureRenderStage` (14)

**Calls:**
- `certifyNativePaint` (3)
- `certifyNativePaint` (3)
- `certifyNativePaint` (2)
- `certifyNativePaint` (2)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)

### `layoutMeasuredForest`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts:34` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (2)

**Calls:**
- `some` (2)

### `layoutResult`
`/tmp/pr449-main-integration-20261029-762/src/browser-lazy/family.ts:37` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (1)

**Calls:**
- `copyDataProperties` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:263` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `copyDataProperties` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:7` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:652` | Self: 0.0% (0us) | Total: 0.2% (10.1ms) | Samples: 0

**Called by:**
- `geometryAttributes` (6)

**Calls:**
- `inertRectangleRecord` (4)
- `inertRectangleRecord` (1)
- `preventExtensions` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/xychart/config-diagnostics.ts:9` | Self: 0.0% (0us) | Total: 0.0% (4.2ms) | Samples: 0

**Calls:**
- `range` (1)

### `prepareMarkerTerminals`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:9` | Self: 0.0% (0us) | Total: 0.2% (11.6ms) | Samples: 0

**Called by:**
- `(module)` (4)
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `map` (6)

### `applyReplacements`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:195` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveSvgColors` (1)

**Calls:**
- `sort` (1)

### `finishClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:771` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `retainClassRectangleContacts` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` | Self: 0.0% (0us) | Total: 0.2% (9.3ms) | Samples: 0

**Called by:**
- `reduce` (6)

**Calls:**
- `measureTextWidth` (5)
- `measureTextWidth` (1)

### `factOf`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:97` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `join` (1)

**Calls:**
- `pay` (1)

### `parseMarkedClassRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1307` | Self: 0.0% (0us) | Total: 0.1% (6.7ms) | Samples: 0

**Called by:**
- `classifyClassStatement` (4)

**Calls:**
- `parseClassRelationEndpoints` (1)
- `parseClassRelationEndpoints` (1)
- `parseClassRelationEndpoints` (1)
- `parseClassRelationEndpoints` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1585` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `snapshotFamilyConfig` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1765` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `measureRenderStage` (5)

**Calls:**
- `resolveAppearance` (2)
- `resolveAppearance` (1)
- `resolveAppearance` (1)
- `resolveAppearance` (1)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1616` | Self: 0.0% (0us) | Total: 0.3% (15.4ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (9)

**Calls:**
- `validateNode` (3)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (1)
- `validateNode` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1122` | Self: 0.0% (0us) | Total: 0.1% (6.8ms) | Samples: 0

**Called by:**
- `write` (3)

**Calls:**
- `validateGeometry` (3)

### `normalizeRequest`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:17` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `applyFamilyRequestNormalization` (1)

**Calls:**
- `resolveClassRenderOptions` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:179` | Self: 0.0% (0us) | Total: 1.9% (84.9ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (44)

**Calls:**
- `join` (39)
- `join` (1)
- `join` (1)
- `join` (1)
- `issue` (1)
- `join` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:686` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `inertRectangleRecord` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:16` | Self: 0.0% (0us) | Total: 0.1% (4.3ms) | Samples: 0

**Called by:**
- `anonymous` (3)

**Calls:**
- `bound require` (3)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:592` | Self: 0.0% (0us) | Total: 0.2% (8.7ms) | Samples: 0

**Called by:**
- `leaf` (3)

**Calls:**
- `geometryBounds` (3)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:372` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:347` | Self: 0.0% (0us) | Total: 0.4% (17.8ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (3)
- `connector` (3)

**Calls:**
- `connectorContourSemantics` (3)
- `connectorContourSemantics` (1)
- `connectorContourSemantics` (1)
- `connectorContourSemantics` (1)

### `canonicalJson`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1094` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `renderContractDigest` (1)

**Calls:**
- `sort` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:315` | Self: 0.0% (0us) | Total: 0.0% (4.1ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (1)
- `connector` (1)

**Calls:**
- `relationAccessibility` (2)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:701` | Self: 0.0% (0us) | Total: 1.1% (50.0ms) | Samples: 0

**Called by:**
- `inlineResolvedColors` (25)

**Calls:**
- `projectSvgCss` (25)

### `sourceEnvelopeMetadata`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:799` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `normalizeSource` (1)

**Calls:**
- `find` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:537` | Self: 0.0% (0us) | Total: 0.1% (7.4ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (5)

**Calls:**
- `attribute` (4)
- `attribute` (1)

### `unsafeCssReferences`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:618` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `inspectAttributeSecurity` (1)

**Calls:**
- `normalizedReference` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:158` | Self: 0.0% (0us) | Total: 0.0% (4.3ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (1)

**Calls:**
- `appendPrivate` (1)

### `serialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1495` | Self: 0.0% (0us) | Total: 0.4% (20.3ms) | Samples: 0

**Called by:**
- `group` (12)

**Calls:**
- `boundedUtf8ByteLength` (12)

### `classOwnedSurfaceViolations`
`/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts:691` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `finalizeClassSurfaces` (2)

**Calls:**
- `emittedBox` (2)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:280` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `connectorInlineLabelSvg` (1)

**Calls:**
- `renderPreparedLine` (1)

### `completeBuiltinDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1384` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `declareFamilyScenePrimitiveEvidence` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:9` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `classifyMermaidFamilyDescriptorFromFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/family-detection.ts:38` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `normalizeFamilyDetectionLine` (1)

### `connectorContourSemantics`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:399` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `cloneObject` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:812` | Self: 0.0% (0us) | Total: 0.4% (19.3ms) | Samples: 0

**Called by:**
- `write` (14)

**Calls:**
- `validateGeometry` (13)
- `validateGeometry` (1)

### `extractInitDirectives`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:1117` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `preprocessMermaidSource` (1)

**Calls:**
- `toMermaidLines` (1)

### `descriptorOwnsDetectionLine`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2072` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `detectorClaims` (2)

**Calls:**
- `performIteration` (2)

### `resolvedColorValue`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:599` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `toneOnFill` (1)

**Calls:**
- `match` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:829` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `connectorInlineLabelSvg` (2)

### `parseClassRelationship`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1292` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `classifyClassStatement` (2)

**Calls:**
- `parseMarkerlessClassRelationship` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1083` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `validatePoint` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:140` | Self: 0.0% (0us) | Total: 45.8% (1.99s) | Samples: 0

**Called by:**
- `measureRenderStage` (1083)

**Calls:**
- `withTextMeasurementExecution` (1083)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:153` | Self: 0.0% (0us) | Total: 0.0% (3.9ms) | Samples: 0

**Calls:**
- `outputDescriptorsById` (1)

### `classifyClassStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:460` | Self: 0.0% (0us) | Total: 0.0% (4.2ms) | Samples: 0

**Called by:**
- `readClassStatements` (3)

**Calls:**
- `classStatement` (3)

### `unsafeCssReferences`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:621` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `inspectAttributeSecurity` (1)

**Calls:**
- `next` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:666` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `classStatementEnds` (1)

**Calls:**
- `visit` (1)

### `internal:primordials`
`internal:primordials:76` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeSafe` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:116` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `cachedNativeDrawing` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:55` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `sort` (1)

### `sceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `relationAccessibility` (1)

**Calls:**
- `resolveSceneRoleTraits` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts:557` | Self: 0.0% (0us) | Total: 0.6% (27.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (16)

**Calls:**
- `map` (16)

### `runMeasuredGraphBackend`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:89` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `emitGraphLayoutDecision` (1)

### `parseExtensionId`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:206` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `createExtensionIdentity` (1)

**Calls:**
- `test` (1)

### `withSvgInspectionCache`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:20` | Self: 0.0% (0us) | Total: 80.0% (3.48s) | Samples: 0

**Called by:**
- `withRenderStageObserver` (1869)

**Calls:**
- `consumeResolvedGraphicalRequest` (1818)
- `executeInspectedGraphicalRequest` (50)
- `lazyGraphicalArtifact` (1)

### `emitGraphLayoutDecision`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:42` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `(anonymous)` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:237` | Self: 0.0% (0us) | Total: 0.5% (22.4ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (13)

**Calls:**
- `scopeSvgStyles` (7)
- `scopeSvgStyles` (3)
- `replaceSvgRootStartTag` (2)
- `scopeSvgStyles` (1)

### `registerBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:470` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `freezeBuiltInBackend` (1)

### `setConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:53` | Self: 0.0% (0us) | Total: 0.7% (30.6ms) | Samples: 0

**Called by:**
- `connector` (15)

**Calls:**
- `deriveConnectorTerminalProjection` (4)
- `deriveConnectorTerminalProjection` (3)
- `deriveConnectorTerminalProjection` (2)
- `deriveConnectorTerminalProjection` (2)
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)

### `omitUndefinedObjectFields`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:956` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `omitUndefinedObjectFields` (1)

**Calls:**
- `omitUndefinedObjectFields` (1)

### `replaceSvgRootStartTag`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:281` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (2)

**Calls:**
- `slice` (2)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:152` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (1)

**Calls:**
- `copyDataProperties` (1)

### `lowerClassDrawing`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:86` | Self: 0.0% (0us) | Total: 0.2% (11.1ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (5)

**Calls:**
- `documentOpen` (2)
- `leaf` (1)
- `documentOpen` (1)
- `documentOpen` (1)

### `ownConnectorEndpoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:192` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `connector` (2)

**Calls:**
- `copyDataProperties` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:665` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `color` (2)

**Calls:**
- `colorResolution` (2)

### `snapshotFamilyConfig`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1531` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `freezeDescriptor` (1)

**Calls:**
- `snapshotDescriptorArray` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1709` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `measureRenderStage` (3)

**Calls:**
- `admitRenderOptionsInput` (2)
- `admitRenderOptionsInput` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:192` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `set` (1)

### `zlibBufferSync`
`node:zlib:94` | Self: 0.0% (0us) | Total: 0.2% (10.7ms) | Samples: 0

**Called by:**
- `(module)` (9)

**Calls:**
- `processChunkSync` (9)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:108` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `shape` (1)

**Calls:**
- `copyDataProperties` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:55` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:90` | Self: 0.0% (0us) | Total: 1.7% (74.0ms) | Samples: 0

**Called by:**
- `visit` (37)

**Calls:**
- `leaf` (36)
- `leaf` (1)

### `assertKnownConnectorFields`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:161` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `hasOwn` (1)

### `createNativeSceneValidator`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1423` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `sceneValidationMode` (1)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1011` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `createClassInterfaceAllocator` (1)

### `getCharWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:91` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `measureText` (2)

**Calls:**
- `isWideRange` (1)
- `isWideRange` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:799` | Self: 0.0% (0us) | Total: 0.2% (12.1ms) | Samples: 0

**Called by:**
- `write` (9)

**Calls:**
- `validateMarkAttributes` (4)
- `validateMarkAttributes` (4)
- `validateMarkAttributes` (1)

### `connectorContourSemantics`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:402` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `copyDataProperties` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:130` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (2)

**Calls:**
- `cloneObject` (2)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:183` | Self: 0.0% (0us) | Total: 47.6% (2.07s) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1119)

**Calls:**
- `measureRenderStage` (1119)

### `resolvedInlineColorAttribute`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:683` | Self: 0.0% (0us) | Total: 0.2% (9.2ms) | Samples: 0

**Called by:**
- `color` (5)

**Calls:**
- `resolveCss` (5)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:682` | Self: 0.0% (0us) | Total: 0.3% (15.6ms) | Samples: 0

**Called by:**
- `leaf` (6)

**Calls:**
- `sameRectanglePaint` (2)
- `sameRectanglePaint` (2)
- `sameRectanglePaint` (1)
- `sameRectanglePaint` (1)

### `node`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1451` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `group` (3)

**Calls:**
- `validateNodeSerialization` (2)
- `validateNodeSerialization` (1)

### `node:fs`
`node:fs:8` | Self: 0.0% (0us) | Total: 0.0% (4.3ms) | Samples: 0

**Calls:**
- `anonymous` (1)

### `evaluateExtensionCompatibility`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:144` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `createExtensionIdentity` (1)

**Calls:**
- `every` (1)

### `classStatementEnds`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:650` | Self: 0.0% (0us) | Total: 0.6% (26.5ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (17)

**Calls:**
- `readClassStatements` (11)
- `readClassStatements` (1)
- `readClassStatements` (1)
- `readClassStatements` (1)
- `readClassStatements` (1)
- `readClassStatements` (1)
- `readClassStatements` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:368` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `xmlTokenAt` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1145` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (1)

**Calls:**
- `copyDataProperties` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:20` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)

**Calls:**
- `getOwnPropertyDescriptor` (2)

### `pointsBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:14` | Self: 0.0% (0us) | Total: 0.1% (8.1ms) | Samples: 0

**Called by:**
- `geometryBounds` (2)

**Calls:**
- `map` (1)
- `min` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:936` | Self: 0.0% (0us) | Total: 0.1% (5.8ms) | Samples: 0

**Called by:**
- `write` (2)
- `validateSceneDocument` (2)

**Calls:**
- `validateMarker` (1)
- `validateMarker` (1)
- `validateMarker` (1)
- `validateMarker` (1)

### `safeCssToken`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:69` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validatePaint` (1)

**Calls:**
- `/^(?:#[0-9a-f]{3,4}\|#[0-9a-f]{6}\|#[0-9a-f]{8}\|[a-z][a-z0-9-]*)$/i` (1)

### `ZlibBase`
`node:zlib:123` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Zlib` (1)

**Calls:**
- `Transform` (1)

### `readXmlNameEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:117` | Self: 0.0% (0us) | Total: 0.1% (8.3ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (4)

**Calls:**
- `xmlAsciiLetter` (4)

### `(module)`
`/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts:7` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Calls:**
- `from` (2)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1728` | Self: 0.0% (0us) | Total: 0.1% (6.8ms) | Samples: 0

**Called by:**
- `measureRenderStage` (5)

**Calls:**
- `validateSerializableRenderOptions` (3)
- `validateSerializableRenderOptions` (2)

### `scanAccessibilityDirectives`
`/tmp/pr449-main-integration-20261029-762/src/shared/accessibility-directives.ts:125` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `parseClassDiagram` (2)

**Calls:**
- `push` (1)
- `slice` (1)

### `finishClassLayout`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:756` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `classTextBlock` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:820` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `attribute` (1)

### `sharedRenderOptionsJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:485` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `validateSerializableRenderOptions` (2)

**Calls:**
- `cloneValue` (2)

### `ensureSvgIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:92` | Self: 0.0% (0us) | Total: 0.1% (8.4ms) | Samples: 0

**Called by:**
- `group` (7)

**Calls:**
- `set` (5)
- `set` (1)
- `set` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:336` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (1)

**Calls:**
- `copyDataProperties` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1742` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `find` (1)

### `element`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:476` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `raw` (1)

### `_defineProperties`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:10` | Self: 0.0% (0us) | Total: 3.0% (130.5ms) | Samples: 0

**Called by:**
- `_createClass` (1)

**Calls:**
- `_toPropertyKey` (1)

### `renderClassBox`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:359` | Self: 0.0% (0us) | Total: 8.2% (359.7ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (199)

**Calls:**
- `leaf` (181)
- `text` (18)

### `executeInspectedGraphicalRequest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:297` | Self: 0.0% (0us) | Total: 1.7% (75.5ms) | Samples: 0

**Called by:**
- `withSvgInspectionCache` (50)

**Calls:**
- `measureRenderStage` (50)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:998` | Self: 0.0% (0us) | Total: 0.1% (8.5ms) | Samples: 0

**Called by:**
- `report` (6)

**Calls:**
- `withTextMeasurementExecution` (6)

### `inspectSecurityTail`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:706` | Self: 0.0% (0us) | Total: 0.1% (7.2ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `test` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:682` | Self: 0.0% (0us) | Total: 0.1% (8.5ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (4)

**Calls:**
- `paintAttributes` (1)
- `paintAttributes` (1)
- `paintAttributes` (1)
- `paintAttributes` (1)

### `prepareMarkerPolygonInk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1018` | Self: 0.0% (0us) | Total: 0.0% (998us) | Samples: 0

**Called by:**
- `assertClassMarkerMeaning` (1)

**Calls:**
- `proofRecord` (1)

### `classNativeMarkerMinimums`
`/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts:182` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `set` (1)

### `isZeroWidth`
`/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:137` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `isCombiningMark` (1)

**Calls:**
- `inRanges` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1457` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (2)

**Calls:**
- `get` (1)
- `nativeTextPaintWriteOf` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:837` | Self: 0.0% (0us) | Total: 0.0% (4.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `freeze` (1)
- `set` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:66` | Self: 0.0% (0us) | Total: 3.0% (130.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `_createClass` (1)

### `zlibBufferSync`
`node:zlib:88` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `(anonymous)` (2)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1853` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `performIteration` (1)

### `createSketchBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:547` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `graphicalBackendCapabilityClaims` (1)

### `expandLocalReferences`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:203` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `entries` (1)

### `parseClassRelationEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:1396` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `parseMarkedClassRelationship` (1)

**Calls:**
- `supportedRelationEndpoint` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1715` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `renderOptionsAdmissionMessages` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:619` | Self: 0.0% (0us) | Total: 0.8% (35.7ms) | Samples: 0

**Called by:**
- `validateNode` (11)

**Calls:**
- `validatePaint` (5)
- `validatePaint` (2)
- `validatePaint` (2)
- `validatePaint` (1)
- `validatePaint` (1)

### `hooks`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:507` | Self: 0.0% (0us) | Total: 0.1% (6.3ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `readClassStatements`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:704` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `classStatementEnds` (1)

**Calls:**
- `expandInlineNamespaceStatement` (1)

### `layoutClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:631` | Self: 0.0% (0us) | Total: 0.7% (33.5ms) | Samples: 0

**Called by:**
- `layout` (22)

**Calls:**
- `measureClassCards` (21)
- `measureClassCards` (1)

### `documentOpen`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:132` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (1)

**Calls:**
- `header` (1)

### `positionedPaintCertification`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:158` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `retainNativeDrawing` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/common/seq.js:4` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1546` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (2)

**Calls:**
- `executionCapabilityDecision` (1)
- `executionCapabilityDecision` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts:104` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (2)

**Calls:**
- `clip` (2)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:174` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `parseInlineFormatting` (1)

### `renderResolvedMermaidSVG`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:270` | Self: 0.0% (0us) | Total: 18.9% (822.8ms) | Samples: 0

**Called by:**
- `consumeResolvedGraphicalRequest` (414)

**Calls:**
- `measureRenderStage` (414)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:191` | Self: 0.0% (0us) | Total: 1.7% (75.4ms) | Samples: 0

**Called by:**
- `(module)` (8)

**Calls:**
- `styleSpecJsonSchema` (7)
- `styleSpecJsonSchema` (1)

### `schemaMatchesRuntimeKind`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:39` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `filter` (1)

**Calls:**
- `dereferenceSchema` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:160` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `validate` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:255` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Calls:**
- `deepFreeze` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:490` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `paintAttribute` (2)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `scoreMeasuredRouteCrossingsWithAdmission`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts:734` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `validate` (2)

**Calls:**
- `push` (2)

### `copyDeferredTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:81` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `deferredTerminalProjectionInput` (1)

### `renderDivider`
`/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts:412` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `renderClassBox` (1)

**Calls:**
- `copyDataProperties` (1)

### `connectorGeometryEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:181` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `connector` (2)

**Calls:**
- `copyDataProperties` (2)

### `parseClassDiagram`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:992` | Self: 0.0% (0us) | Total: 0.4% (19.2ms) | Samples: 0

**Called by:**
- `layout` (14)

**Calls:**
- `readClassStatements` (8)
- `readClassStatements` (3)
- `readClassStatements` (1)
- `readClassStatements` (1)
- `readClassStatements` (1)

### `parseInlineFormatting`
`/tmp/pr449-main-integration-20261029-762/src/shared/inline-format.ts:45` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `prepareDisplayText` (1)

**Calls:**
- `slice` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/block/markers.ts:10` | Self: 0.0% (0us) | Total: 0.1% (8.5ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (4)

### `classifyClassStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:536` | Self: 0.0% (0us) | Total: 0.3% (14.0ms) | Samples: 0

**Called by:**
- `readClassStatements` (9)

**Calls:**
- `parseMarkedClassRelationship` (4)
- `parseClassRelationship` (2)
- `parseMarkedClassRelationship` (1)
- `parseMarkedClassRelationship` (1)
- `parseClassRelationship` (1)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:178` | Self: 0.0% (0us) | Total: 0.3% (14.0ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (7)

**Calls:**
- `svgStyleRanges` (7)

### `localPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1390` | Self: 0.0% (0us) | Total: 0.1% (6.1ms) | Samples: 0

**Called by:**
- `validateNode` (4)

**Calls:**
- `collectPaintResourceReferences` (4)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:420` | Self: 0.0% (0us) | Total: 0.2% (12.0ms) | Samples: 0

**Called by:**
- `measureClassCards` (8)

**Calls:**
- `advance` (7)
- `qualify` (1)

### `assertFamilyGeometryOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:850` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `applyFamilyRequestNormalization` (1)

**Calls:**
- `validateSerializableRenderOptions` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:186` | Self: 0.0% (0us) | Total: 0.8% (38.4ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (17)

**Calls:**
- `measureRenderStage` (16)
- `measureRenderStage` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:618` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `validatePoint` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:569` | Self: 0.0% (0us) | Total: 0.5% (22.5ms) | Samples: 0

**Called by:**
- `resolvedColorValue` (4)
- `colorResolution` (2)

**Calls:**
- `resolveColors` (4)
- `resolveColors` (1)
- `resolveColors` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1210` | Self: 0.0% (0us) | Total: 1.3% (60.9ms) | Samples: 0

**Called by:**
- `write` (22)

**Calls:**
- `validateMarker` (11)
- `validateMarker` (3)
- `validateMarker` (3)
- `validateMarker` (1)
- `validateMarker` (1)
- `validateMarker` (1)
- `validateMarker` (1)
- `validateMarker` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:167` | Self: 0.0% (0us) | Total: 0.7% (33.8ms) | Samples: 0

**Called by:**
- `lowerClassDrawing` (22)

**Calls:**
- `node` (18)
- `node` (3)
- `node` (1)

### `transformSvgCssValues`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:270` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `resolveSvgColors` (2)

**Calls:**
- `map` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/class/layout.ts:659` | Self: 0.0% (0us) | Total: 0.3% (13.4ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (5)

**Calls:**
- `buildClassEndpointMarkerTemplates` (5)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:134` | Self: 0.0% (0us) | Total: 0.2% (8.8ms) | Samples: 0

**Called by:**
- `paintBounds` (2)
- `markerBoundsAt` (1)

**Calls:**
- `read` (1)
- `read` (1)
- `read` (1)

### `classifyClassStatement`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:473` | Self: 0.0% (0us) | Total: 0.0% (4.3ms) | Samples: 0

**Called by:**
- `readClassStatements` (1)

**Calls:**
- `match` (1)

### `node:zlib`
`node:zlib:456` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `map` (1)

### `get receipt`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:347` | Self: 0.0% (0us) | Total: 0.3% (15.6ms) | Samples: 0

**Called by:**
- `stringify` (11)

**Calls:**
- `(anonymous)` (10)
- `(anonymous)` (1)

### `layout`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/class.ts:25` | Self: 0.0% (0us) | Total: 17.0% (740.7ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (360)

**Calls:**
- `runMeasuredGraphBackend` (337)
- `layoutClassDiagram` (22)
- `runMeasuredGraphBackend` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:583` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1860` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (2)

**Calls:**
- `find` (2)

### `rendered`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:427` | Self: 0.0% (0us) | Total: 1.1% (48.6ms) | Samples: 0

**Called by:**
- `runBackendConformance` (16)

**Calls:**
- `render` (15)
- `render` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 28.6% | 1.24s | `[native code]` |
| 9.2% | 404.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 8.6% | 375.7ms | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 5.1% | 225.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 5.0% | 220.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 3.3% | 147.7ms | `/tmp/pr449-main-integration-20261029-762/src/class/owned-surfaces.ts` |
| 3.0% | 130.5ms | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 2.7% | 120.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 2.7% | 119.9ms | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 1.9% | 84.1ms | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 1.6% | 70.1ms | `/tmp/pr449-main-integration-20261029-762/src/class/renderer.ts` |
| 1.4% | 64.6ms | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-route-safety.ts` |
| 1.4% | 64.0ms | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 1.4% | 63.8ms | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 1.4% | 62.4ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js` |
| 1.3% | 59.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 1.3% | 56.8ms | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 1.1% | 49.7ms | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` |
| 1.1% | 49.1ms | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts` |
| 1.1% | 48.9ms | `/tmp/pr449-week-comparison-20261101/class128-profile/profile.ts` |
| 1.0% | 46.8ms | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 1.0% | 45.9ms | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-marker-seating.ts` |
| 0.8% | 38.1ms | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.8% | 37.6ms | `/tmp/pr449-main-integration-20261029-762/src/class/layout.ts` |
| 0.8% | 36.6ms | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.7% | 30.9ms | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.7% | 30.7ms | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.6% | 27.8ms | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.4% | 21.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.4% | 21.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.4% | 19.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.4% | 17.6ms | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.4% | 17.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.2% | 12.8ms | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.2% | 12.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.2% | 12.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-paint-pieces.ts` |
| 0.2% | 11.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` |
| 0.2% | 10.9ms | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.2% | 10.7ms | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.2% | 9.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.2% | 8.9ms | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts` |
| 0.1% | 8.4ms | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.1% | 8.2ms | `/tmp/pr449-main-integration-20261029-762/src/class/marker-port-capacity.ts` |
| 0.1% | 7.8ms | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.1% | 7.4ms | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` |
| 0.1% | 7.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` |
| 0.1% | 7.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.1% | 6.9ms | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-format/src/locale.js` |
| 0.1% | 6.7ms | `/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` |
| 0.1% | 6.3ms | `/tmp/pr449-main-integration-20261029-762/src/class/marker-admission.ts` |
| 0.1% | 5.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` |
| 0.1% | 5.3ms | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.1% | 5.1ms | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts` |
| 0.1% | 5.0ms | `node:fs` |
| 0.1% | 5.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.1% | 4.9ms | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` |
| 0.1% | 4.7ms | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.1% | 4.6ms | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.0% | 4.1ms | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts` |
| 0.0% | 4.1ms | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts` |
| 0.0% | 3.9ms | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 3.9ms | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 3.9ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js` |
| 0.0% | 3.7ms | `/tmp/pr449-main-integration-20261029-762/src/experimental/position-cache.ts` |
| 0.0% | 3.4ms | `/tmp/pr449-main-integration-20261029-762/src/class/annotation-seats.ts` |
| 0.0% | 3.4ms | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.0% | 3.2ms | `/tmp/pr449-main-integration-20261029-762/src/agent/stable-family-source-hooks.ts` |
| 0.0% | 3.1ms | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts` |
| 0.0% | 3.0ms | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts` |
| 0.0% | 3.0ms | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts` |
| 0.0% | 2.8ms | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 2.6ms | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts` |
| 0.0% | 2.5ms | `/tmp/pr449-main-integration-20261029-762/src/shared/diagram-limits.ts` |
| 0.0% | 2.5ms | `node:zlib` |
| 0.0% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/gantt/dependency-paint.ts` |
| 0.0% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts` |
| 0.0% | 2.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` |
| 0.0% | 2.1ms | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts` |
| 0.0% | 2.0ms | `internal:primordials` |
| 0.0% | 1.9ms | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js` |
| 0.0% | 1.9ms | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.8ms | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.0% | 1.7ms | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/class.ts` |
| 0.0% | 1.7ms | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-portal-channel.ts` |
| 0.0% | 1.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts` |
| 0.0% | 1.6ms | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/class/elk-contacts.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/agent/layout-to-rendered.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/agent/types.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/styles.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-limits.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/class/interface-occurrences.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/external-scene.ts` |
| 0.0% | 1.1ms | `internal:streams/writable` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts` |
