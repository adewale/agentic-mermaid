import {readFileSync} from 'node:fs'
Bun.plugin({name:'old-producer-owner-control',setup(build){build.onLoad({filter:/\/src\/layout\/agentic-producer-core\.ts$/},()=>({contents:readFileSync('/tmp/pr449-week-comparison-20261101/flow-fit-owning-7a8c58917/before-producer.ts','utf8'),loader:'ts'}))}})
