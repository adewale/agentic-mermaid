import {writeFileSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
import {drawNative} from '/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts'
import {certifyNativePaint} from '/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts'
import {tipAnchoredArrow,serializeMarkerResource} from '/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
const dir='/tmp/pr449-week-comparison-20261101/written-marker-custody-37f'
if(process.argv[2]!=='GO')throw Error('Explicit GO required')
const header={family:'flowchart',width:100,height:80,transparent:false,colors:{bg:'#fff',fg:'#111'}}
const context={positioned:{width:100,height:80},colors:header.colors,resolved:{renderOptions:{}}}
const marker=tipAnchoredArrow('arrow',{width:8,height:5},'end',{fill:'#111'},'userSpaceOnUse')
const producer=factory=>({...header,parts:[
 factory.documentOpen({id:'root',width:100,height:80,colors:header.colors,transparent:false,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="100" height="80">'),
 factory.definitions({id:'defs'},`<defs>${serializeMarkerResource(marker)}</defs>`),
 factory.connector({id:'arrow-edge',role:'edge',lineStyle:'solid',geometry:{kind:'polyline',points:[{x:20.000000000003,y:30.000000000003},{x:30.000000000003,y:30.000000000003}]},paint:{stroke:'#111',strokeWidth:'1'},endpoints:{from:'other',to:'cover'},markers:{end:marker}}),
 factory.shape({id:'cover',role:'node',geometry:{kind:'rect',x:20,y:20,width:10,height:20},paint:{fill:'#fff'}}),factory.documentClose()
]})
const run=()=>{const drawing=drawNative(producer,context,'flowchart');return{svg:drawing.svg,proof:certifyNativePaint(drawing.header,drawing.paint)}}
const clean=run(),original=Object.getOwnPropertyDescriptor(WeakMap.prototype,'set')!,set=original.value,apply=Reflect.apply
let observed=0,changed
try{
 Object.defineProperty(WeakMap.prototype,'set',{...original,value(key,value){
  if(value&&typeof value==='object'&&value.rawBounds&&Array.isArray(value.contours)&&typeof value.collapsed==='boolean'){
   observed++;value={...value,contours:value.contours.map(c=>({...c,endTangent:{x:-1,y:0}})),rawEndTangent:{x:-1,y:0}}
  }
  return apply(set,this,[key,value])
 }})
 changed=run()
}finally{Object.defineProperty(WeakMap.prototype,'set',original)}
const actual=new Resvg(changed.svg,{font:{loadSystemFonts:false}}).render().pixels
const removed=new Resvg(changed.svg.replace(' marker-end="url(#arrow)"',''),{font:{loadSystemFonts:false}}).render().pixels
const report={actualDrawCertifyCalls:2,offlineRasters:2,observed,wholeSVGExact:clean.svg===changed.svg,clean,changed,markerChangesImage:Buffer.compare(actual,removed)!==0,prototypeRestored:WeakMap.prototype.set===set}
writeFileSync(dir+'/RESULT.json.gz',gzipSync(JSON.stringify(report)));writeFileSync(dir+'/actual.svg.gz',gzipSync(changed.svg));console.log(JSON.stringify({...report,clean:{proof:clean.proof},changed:{proof:changed.proof}}))
