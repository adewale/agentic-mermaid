# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 3.49s | 1434 | 1.0ms | 1433 |

**Top 10:** `(anonymous)` 16.0%, `anonymous` 7.5%, `gc` 5.3%, `paintedStrokeExtent` 4.5%, `(anonymous)` 2.0%, `isBuiltinFamilyId` 1.9%, `decodeBase64` 1.7%, `some` 1.6%, `xmlAsciiLetter` 1.4%, `stringify` 1.3%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 16.0% | 563.0ms | 16.0% | 563.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:7` |
| 7.5% | 262.3ms | 13.5% | 472.7ms | `anonymous` | `[native code]` |
| 5.3% | 187.2ms | 5.3% | 187.2ms | `gc` | `[native code]` |
| 4.5% | 159.7ms | 4.5% | 159.7ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:510` |
| 2.0% | 70.2ms | 2.0% | 70.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts` |
| 1.9% | 67.6ms | 1.9% | 67.6ms | `isBuiltinFamilyId` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1414` |
| 1.7% | 62.4ms | 1.7% | 62.4ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:21` |
| 1.6% | 56.3ms | 2.4% | 85.8ms | `some` | `[native code]` |
| 1.4% | 51.0ms | 1.4% | 51.0ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` |
| 1.3% | 46.1ms | 1.9% | 66.6ms | `stringify` | `[native code]` |
| 1.1% | 41.9ms | 1.4% | 49.8ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:170` |
| 1.1% | 40.2ms | 11.3% | 398.0ms | `map` | `[native code]` |
| 1.0% | 38.4ms | 1.0% | 38.4ms | `@lazy` | `[native code]` |
| 0.9% | 32.6ms | 0.9% | 32.6ms | `getOwnPropertyDescriptor` | `[native code]` |
| 0.8% | 31.0ms | 0.8% | 31.0ms | `has` | `[native code]` |
| 0.8% | 29.1ms | 0.8% | 29.1ms | `copyDataProperties` | `[native code]` |
| 0.7% | 26.2ms | 1.1% | 40.3ms | `filter` | `[native code]` |
| 0.6% | 23.2ms | 0.6% | 23.2ms | `set` | `[native code]` |
| 0.6% | 21.2ms | 0.6% | 21.2ms | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:17` |
| 0.6% | 21.1ms | 0.6% | 21.1ms | `freeze` | `[native code]` |
| 0.6% | 21.0ms | 0.6% | 21.0ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:170` |
| 0.5% | 20.0ms | 0.5% | 20.0ms | `cloneObject` | `[native code]` |
| 0.5% | 19.2ms | 0.5% | 19.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.5% | 19.2ms | 0.5% | 19.2ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:519` |
| 0.4% | 17.4ms | 0.4% | 17.4ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` |
| 0.4% | 17.2ms | 0.6% | 24.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:407` |
| 0.4% | 17.2ms | 0.6% | 21.1ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` |
| 0.4% | 15.6ms | 0.4% | 15.6ms | `add` | `[native code]` |
| 0.4% | 14.6ms | 0.4% | 14.6ms | `every` | `[native code]` |
| 0.4% | 14.6ms | 0.9% | 32.8ms | `test` | `[native code]` |
| 0.4% | 14.5ms | 0.4% | 14.5ms | `sourceIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` |
| 0.4% | 14.2ms | 0.4% | 14.2ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:92` |
| 0.3% | 12.7ms | 0.3% | 12.7ms | `join` | `[native code]` |
| 0.3% | 12.6ms | 0.3% | 12.6ms | `defineProperty` | `[native code]` |
| 0.3% | 12.4ms | 0.3% | 12.4ms | `get` | `[native code]` |
| 0.3% | 11.8ms | 0.3% | 13.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:109` |
| 0.3% | 11.6ms | 0.3% | 11.6ms | `xmlRange` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:48` |
| 0.3% | 10.7ms | 0.3% | 10.7ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` |
| 0.3% | 10.5ms | 0.3% | 10.5ms | `/^\s*<g\b[^>]*>(?:<title>[^<]*<\/title>)?$/` | `[native code]` |
| 0.2% | 10.4ms | 0.2% | 10.4ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:485` |
| 0.2% | 9.9ms | 0.5% | 19.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:420` |
| 0.2% | 9.6ms | 0.2% | 9.6ms | `writeSync` | `[native code]` |
| 0.2% | 9.5ms | 0.2% | 9.5ms | `positiveNumber` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts:216` |
| 0.2% | 9.3ms | 0.2% | 9.3ms | `arrayIteratorNextHelper` | `[native code]` |
| 0.2% | 9.2ms | 1.4% | 52.4ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:228` |
| 0.2% | 8.5ms | 0.2% | 8.5ms | `isFrozen` | `[native code]` |
| 0.2% | 8.5ms | 0.2% | 8.5ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1171` |
| 0.2% | 8.4ms | 0.2% | 8.4ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:96` |
| 0.2% | 8.3ms | 0.2% | 9.4ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:162` |
| 0.2% | 8.3ms | 0.2% | 8.3ms | `lazyGraphicalArtifact` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:344` |
| 0.2% | 7.9ms | 0.2% | 7.9ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:20` |
| 0.2% | 7.9ms | 0.2% | 7.9ms | `ownerSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.2% | 7.6ms | 0.2% | 7.6ms | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1447` |
| 0.2% | 7.5ms | 0.2% | 7.5ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1801` |
| 0.2% | 7.4ms | 0.2% | 7.4ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:203` |
| 0.2% | 7.4ms | 0.2% | 7.4ms | `importModule` | `[native code]` |
| 0.2% | 7.4ms | 0.2% | 7.4ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` |
| 0.2% | 7.2ms | 0.3% | 11.4ms | `find` | `[native code]` |
| 0.2% | 7.2ms | 0.2% | 7.2ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `RegExp` | `[native code]` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:295` |
| 0.1% | 6.7ms | 0.1% | 6.7ms | `Segmenter` | `[native code]` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:316` |
| 0.1% | 6.3ms | 0.4% | 17.0ms | `Set` | `[native code]` |
| 0.1% | 6.3ms | 0.1% | 6.3ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:205` |
| 0.1% | 6.2ms | 10.6% | 372.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:161` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `slice` | `[native code]` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:66` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:95` |
| 0.1% | 5.6ms | 0.1% | 5.6ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:176` |
| 0.1% | 5.5ms | 0.1% | 5.5ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `xmlScalarCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:88` |
| 0.1% | 5.1ms | 0.1% | 6.0ms | `append` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:239` |
| 0.1% | 5.1ms | 0.2% | 7.3ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:173` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1462` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1456` |
| 0.1% | 4.8ms | 0.2% | 9.7ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:156` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `deferredTerminalProjectionInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `collectPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1374` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:93` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `snapshotBoundedExternalData` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `compare` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:33` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `/[^\x20-\x7e]/u` | `[native code]` |
| 0.1% | 4.6ms | 0.2% | 7.0ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:173` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:618` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:179` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1091` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `hasOwn` | `[native code]` |
| 0.1% | 4.4ms | 0.2% | 8.5ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:122` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:413` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:163` |
| 0.1% | 4.3ms | 0.9% | 34.1ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1491` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `flatIntoArray` | `[native code]` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:116` |
| 0.1% | 4.2ms | 1.3% | 47.4ms | `xmlNameCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:87` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 4.2ms | 0.3% | 13.4ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:171` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:681` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 4.1ms | 0.1% | 4.1ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.1% | 4.1ms | 0.1% | 4.1ms | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.1% | 4.1ms | 0.1% | 4.1ms | `Buffer` | `[native code]` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:533` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `push` | `[native code]` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `ownFragment` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:116` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:235` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:580` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 3.9ms | 0.1% | 6.6ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:711` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `/[^\x00-\x7f]/` | `[native code]` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:643` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `assign` | `[native code]` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.1% | 3.8ms | 0.1% | 3.8ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.1% | 3.8ms | 0.1% | 3.8ms | `localPaintResourceId` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:373` |
| 0.1% | 3.8ms | 0.1% | 3.8ms | `sceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.1% | 3.7ms | 0.1% | 3.7ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:67` |
| 0.1% | 3.7ms | 0.1% | 3.7ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:461` |
| 0.1% | 3.7ms | 0.1% | 3.7ms | `inverseMatrix` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:23` |
| 0.1% | 3.7ms | 0.1% | 5.2ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:268` |
| 0.1% | 3.7ms | 0.1% | 3.7ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:176` |
| 0.1% | 3.7ms | 0.1% | 3.7ms | `record` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 3.6ms | 0.1% | 3.6ms | `includes` | `[native code]` |
| 0.1% | 3.6ms | 5.1% | 179.8ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:639` |
| 0.1% | 3.6ms | 0.1% | 6.0ms | `replace` | `[native code]` |
| 0.1% | 3.6ms | 0.1% | 3.6ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:304` |
| 0.1% | 3.6ms | 0.1% | 6.3ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:88` |
| 0.1% | 3.6ms | 0.1% | 3.6ms | `isWhitespace` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.1% | 3.6ms | 0.1% | 3.6ms | `nodeWorldBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:460` |
| 0.1% | 3.5ms | 0.1% | 3.5ms | `hasSceneWriteEmissionOccurrence` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.1% | 3.5ms | 0.1% | 3.5ms | `values` | `[native code]` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:113` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:844` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `inRanges` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:114` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:40` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `topRoundedRectPath` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:844` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:193` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:662` |
| 0.0% | 3.3ms | 0.4% | 16.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:297` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:481` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:87` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `trim` | `[native code]` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `sort` | `[native code]` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:336` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:309` |
| 0.0% | 3.1ms | 0.2% | 8.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:800` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 3.0ms | 0.1% | 4.5ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:501` |
| 0.0% | 3.0ms | 0.1% | 6.6ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:776` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `writeStructuredSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:594` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:147` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:271` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:590` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `min` | `[native code]` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `ArrayBuffer` | `[native code]` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2361` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:845` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:134` |
| 0.0% | 2.9ms | 0.1% | 5.7ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:36` |
| 0.0% | 2.9ms | 0.2% | 7.9ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:685` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:207` |
| 0.0% | 2.8ms | 0.3% | 11.7ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:106` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `parseErRelationshipSyntax` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:207` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:443` |
| 0.0% | 2.7ms | 2.7% | 96.0ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:283` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `skipSeparators` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:168` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:214` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `isSupportedSemVerRange` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:327` |
| 0.0% | 2.7ms | 0.2% | 9.6ms | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1395` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `flatMap` | `[native code]` |
| 0.0% | 2.7ms | 0.1% | 6.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:128` |
| 0.0% | 2.7ms | 1.4% | 50.2ms | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:104` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `overlaps` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:56` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:154` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:663` |
| 0.0% | 2.6ms | 0.2% | 10.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 2.6ms | 0.6% | 22.6ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:130` |
| 0.0% | 2.6ms | 0.3% | 13.1ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` |
| 0.0% | 2.6ms | 0.2% | 9.5ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:778` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `entries` | `[native code]` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `appendPrivate` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:55` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:406` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `Number` | `[native code]` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `box` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:59` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `split` | `[native code]` |
| 0.0% | 2.5ms | 0.1% | 3.7ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `erCardinalityPieces` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:110` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:114` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 2.4ms | 0.1% | 4.5ms | `expectedCapabilityState` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1641` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:894` |
| 0.0% | 2.4ms | 0.2% | 9.9ms | `chargeInkSort` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:7` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `erCardinalityInk` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:125` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1374` |
| 0.0% | 2.3ms | 4.2% | 149.9ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:638` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:552` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:440` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1516` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:117` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `Transform` | `internal:streams/transform` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `recordAdmittedScene` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-admission-state.ts` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/flowchart-lexer.ts` |
| 0.0% | 2.2ms | 0.2% | 8.2ms | `compositeCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:275` |
| 0.0% | 2.2ms | 0.1% | 4.9ms | `snapshotScenePrimitiveCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1541` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:275` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:51` |
| 0.0% | 2.2ms | 0.3% | 12.1ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:581` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `serialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1499` |
| 0.0% | 2.2ms | 0.3% | 12.6ms | `serialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1500` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:145` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:488` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `parseInt` | `[native code]` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:331` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1452` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:303` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `f` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/geometry.ts:16` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:224` |
| 0.0% | 2.1ms | 0.0% | 3.4ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:311` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `finiteRect` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:159` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `init` | `[native code]` |
| 0.0% | 2.1ms | 0.1% | 3.9ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:660` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `terminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 2.1ms | 0.0% | 3.3ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:150` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `getOwnPropertyNames` | `[native code]` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `parseFloat` | `[native code]` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1664` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `toPrecision` | `[native code]` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `hasPublicLayoutProjection` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `ownedTextPaintRoster` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `connectorMarkerPaintRegions` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:355` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:356` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:824` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `indentLines` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:744` |
| 0.0% | 1.8ms | 0.1% | 4.3ms | `terminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1251` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1356` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `shortenMeasuredRoutes` | `/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts` |
| 0.0% | 1.8ms | 0.1% | 5.4ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:214` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:708` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:841` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:254` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:410` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `pushTickAt` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:55` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `skipSpace` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:667` |
| 0.0% | 1.7ms | 0.0% | 3.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:118` |
| 0.0% | 1.7ms | 0.1% | 5.6ms | `sceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `admitWritableSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:501` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validateRole` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.6ms | 1.5% | 53.7ms | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:150` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `renderCardinality` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `/<(?:[^\s<>/:]+:)?iframe\b/i` | `[native code]` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Scalar.js:8` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `installedFamilyStatementEnds` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `capturedRequestFamily` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `compare` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/generated-identity.ts:7` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:848` |
| 0.0% | 1.6ms | 0.0% | 2.9ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:582` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:700` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:670` |
| 0.0% | 1.6ms | 16.3% | 570.8ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:118` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:175` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `createTextMeasurementExecution` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:487` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:298` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:830` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:538` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `tag` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:152` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:259` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `tag` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:148` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `projectSvgCss` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:26` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `get` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` |
| 0.0% | 1.5ms | 0.1% | 5.4ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:298` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `typographyAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:694` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `erLabelUnread` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1059` |
| 0.0% | 1.5ms | 0.2% | 8.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:405` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:922` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `numberIsValid` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:280` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `intersects` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `finishXmlLeaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:277` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `SvgWriter` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `_close` | `node:zlib` |
| 0.0% | 1.5ms | 0.0% | 2.8ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1391` |
| 0.0% | 1.5ms | 0.1% | 3.9ms | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:171` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1715` |
| 0.0% | 1.5ms | 0.2% | 7.6ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:253` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1004` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:518` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1242` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `isArray` | `[native code]` |
| 0.0% | 1.4ms | 1.2% | 43.5ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:39` |
| 0.0% | 1.4ms | 0.1% | 5.4ms | `strokedBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:543` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:28` |
| 0.0% | 1.4ms | 0.1% | 4.5ms | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:446` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:794` |
| 0.0% | 1.4ms | 0.0% | 2.9ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:581` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:554` |
| 0.0% | 1.4ms | 0.4% | 14.4ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:726` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 2.7ms | `value` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:127` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `trailingCommentStart` | `/tmp/pr449-main-integration-20261029-762/src/shared/trailing-comment.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:23` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `assertMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/journey/config-diagnostics.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:285` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `declareFamilyScenePrimitiveEvidence` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:254` |
| 0.0% | 1.4ms | 0.3% | 13.1ms | `ensureContrast` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:102` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `resolveSvgColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `unionSceneBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.4ms | 0.1% | 6.0ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:471` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `commandAtCursor` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:172` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `nativePaintSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:228` |
| 0.0% | 1.4ms | 0.0% | 2.7ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:739` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `connectorSubpaths` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts:4` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1206` |
| 0.0% | 1.4ms | 0.0% | 2.5ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:177` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:840` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:473` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:568` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `nativeAttributeValue` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:59` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:18` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `relationshipFrom` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1107` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:387` |
| 0.0% | 1.3ms | 0.0% | 2.7ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:535` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `preparedInterTextBounds` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.3ms | 0.1% | 4.3ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:526` |
| 0.0% | 1.3ms | 0.2% | 8.0ms | `forEach` | `[native code]` |
| 0.0% | 1.3ms | 0.1% | 4.5ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:193` |
| 0.0% | 1.3ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:298` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `writtenPolylineProjectionOf` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts` |
| 0.0% | 1.3ms | 0.1% | 4.1ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:517` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `uncertain` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `boxAt` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:168` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:605` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1213` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:244` |
| 0.0% | 1.3ms | 0.3% | 12.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:175` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:529` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `assignPorts` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.3ms | 0.8% | 28.4ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `reorder` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:432` |
| 0.0% | 1.3ms | 0.0% | 2.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:893` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:335` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:273` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `paintPrimitiveSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `inRanges` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:18` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:367` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readErStatement` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `escapeDisplayAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:504` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:182` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:155` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1517` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parseInlineFormatting` | `/tmp/pr449-main-integration-20261029-762/src/shared/inline-format.ts:29` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1298` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:758` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:402` |
| 0.0% | 1.3ms | 0.3% | 12.0ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:431` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `captureNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pathMoveCount` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:838` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:315` |
| 0.0% | 1.3ms | 0.2% | 10.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:167` |
| 0.0% | 1.3ms | 0.0% | 2.8ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1386` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:452` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:60` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `xmlRange` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:384` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:284` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `safeCssPaint` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:129` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `emissionRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:76` |
| 0.0% | 1.3ms | 0.0% | 2.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:418` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:506` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:573` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `createPngOutputOptionFieldDescriptors` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:105` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:796` |
| 0.0% | 1.3ms | 0.2% | 9.6ms | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:197` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:91` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `reorder` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:409` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:122` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `ActualTextPaintWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:393` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:851` |
| 0.0% | 1.3ms | 0.0% | 3.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:774` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:751` |
| 0.0% | 1.3ms | 0.8% | 29.6ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:652` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `assertBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:497` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `unsafeActiveCss` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `getCharWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 1.2ms | 4.0% | 141.3ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1468` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `resolveLabelContent` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:58` |
| 0.0% | 1.2ms | 0.0% | 2.2ms | `tagRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:25` |
| 0.0% | 1.2ms | 18.8% | 659.3ms | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:128` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1498` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `element` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:476` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `freezeBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1380` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderResolvedMermaidSVG` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:107` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:197` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:528` |
| 0.0% | 1.2ms | 0.3% | 10.6ms | `next` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:81` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:317` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:656` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `nativePaintSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1391` |
| 0.0% | 1.2ms | 0.0% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1917` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1798` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `fieldJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:508` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `transferSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:751` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `replaceField` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:835` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `statementEndAt` | `/tmp/pr449-main-integration-20261029-762/src/shared/accessibility-directives.ts` |
| 0.0% | 1.2ms | 0.0% | 2.3ms | `srgbRelativeLuminance` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:68` |
| 0.0% | 1.2ms | 0.2% | 8.8ms | `reduce` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1246` |
| 0.0% | 1.2ms | 0.0% | 2.7ms | `glyphBox` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1314` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:315` |
| 0.0% | 1.2ms | 0.1% | 5.0ms | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:536` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `install` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:41` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `chargeInkSort` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:17` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parseErRelationshipSyntax` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1075` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:251` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `indexedPlacedCollides` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:123` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `nativeAccessibilityEdits` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:673` |
| 0.0% | 1.2ms | 0.1% | 6.5ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:486` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `canonicalErContacts` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:236` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `advanceAttrs` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:263` |
| 0.0% | 1.2ms | 0.0% | 2.6ms | `replaceField` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:294` |
| 0.0% | 1.2ms | 0.0% | 2.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:229` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `/[-#:[\]",\u0000-\u001f]/` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `withRenderStageObserver` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ownsParts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:424` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:206` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:698` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `serialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.2ms | 0.0% | 2.1ms | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:265` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:390` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:136` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `internal:streams/readable:525` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `imul` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `transferNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parseHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:25` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:512` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:260` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `resolveRoleStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:240` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:762` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:363` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `serializableOptionCandidate` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.2ms | 0.8% | 28.6ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:61` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1066` |
| 0.0% | 1.2ms | 0.0% | 2.4ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:517` |
| 0.0% | 1.2ms | 0.0% | 2.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:763` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Duplex` | `internal:streams/duplex` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:733` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorEndpointAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:443` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:246` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:565` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateJsonConfigAdmission` | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:276` |
| 0.0% | 1.2ms | 0.1% | 6.6ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:420` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:503` |
| 0.0% | 1.2ms | 0.4% | 14.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:49` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `py` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `/^(?:class\|data-[a-z][a-z0-9-]*\|role\|aria-[a-z]+\|tabindex\|pointer-events\|transform\|style)$/` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1802` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `createNativePaintEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:54` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `retainTextPaintPresence` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:79` |
| 0.0% | 1.1ms | 0.0% | 2.6ms | `connectorGeometryEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:174` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateRawThemeCss` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:269` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:200` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:654` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:58` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:734` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `visibleSketchProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:438` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `decodeWithTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:442` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:262` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:30` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.5% | 18.5ms | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:200` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/c4/parser.ts:27` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:287` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `parseExtensionId` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:202` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `prepared` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:321` |
| 0.0% | 1.1ms | 0.2% | 7.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:276` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `erLabelPillGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1700` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `collectNativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:164` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `/[-+]?(?:(?:\d+(?:\.\d*)?)\|(?:\.\d+))(?:[eE][-+]?\d+)?/y` | `[native code]` |
| 0.0% | 1.1ms | 0.1% | 3.9ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:142` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `decodeWithTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:456` |
| 0.0% | 1.1ms | 0.1% | 6.0ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:315` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `consumePointBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `XmlLeafWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:298` |
| 0.0% | 1.1ms | 0.0% | 2.2ms | `replaceField` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:293` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1518` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1848` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `preventExtensions` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:335` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `createOwnedNativePaintRecorder` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.1ms | 0.2% | 7.3ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:144` |
| 0.0% | 1.1ms | 0.0% | 2.3ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:13` |
| 0.0% | 1.1ms | 0.0% | 2.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:640` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:226` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:42` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:703` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1023` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:290` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `canonicalizeSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `srgbToLinear` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:63` |
| 0.0% | 1.1ms | 0.1% | 3.7ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:281` |
| 0.0% | 1.1ms | 0.0% | 2.8ms | `erCardinalityPieces` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:66` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `apply` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:69` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:562` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:270` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isWhitespace` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:31` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolvedColorValue` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:599` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `ownerOf` | `/tmp/pr449-main-integration-20261029-762/src/shared/subgraph-membership.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:250` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:214` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `erCharge` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:204` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1519` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/directives.js:175` |
| 0.0% | 1.0ms | 0.0% | 2.1ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:91` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:508` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finiteString` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `header` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:115` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `erCharge` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `ownFragment` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.0ms | 0.0% | 2.4ms | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `connectorTerminalStrokeLosses` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `schemaRecord` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.0ms | 0.5% | 19.5ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:813` |
| 0.0% | 1.0ms | 0.1% | 3.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:759` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finiteString` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts:234` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:181` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:330` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `keys` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 2.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1104` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `graphemes` | `/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts` |
| 0.0% | 1.0ms | 0.2% | 9.0ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:221` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `checkArchitectureRenderOptionColors` | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `xmlTokenAt` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:17` |
| 0.0% | 1.0ms | 0.2% | 9.5ms | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:92` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:670` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:35` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `safeCssFontFamily` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-font.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:735` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `immutableDecision` | `/tmp/pr449-main-integration-20261029-762/src/layout/decision-evidence.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:674` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `renderDisplayRuns` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:148` |
| 0.0% | 1.0ms | 0.1% | 4.9ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:653` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:248` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts:308` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `expandSceneBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:35` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `cliRenderFormats` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:796` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:606` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:417` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `emissionRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1040` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:6` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `WriteStream` | `internal:fs/streams` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:616` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `/\sdata-from="([^"]*)"/` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `textPaints` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:169` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1241` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `snapshotIdentityRecord` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.0ms | 0.3% | 13.5ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:653` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:190` |
| 0.0% | 1.0ms | 0.0% | 3.0ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` |
| 0.0% | 1.0ms | 0.1% | 3.9ms | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:174` |
| 0.0% | 999us | 0.0% | 999us | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:15` |
| 0.0% | 997us | 0.0% | 997us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:241` |
| 0.0% | 994us | 0.0% | 994us | `optional` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:49` |
| 0.0% | 991us | 0.0% | 991us | `performIteration` | `[native code]` |
| 0.0% | 990us | 0.0% | 990us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` |
| 0.0% | 988us | 0.0% | 988us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:642` |
| 0.0% | 986us | 0.0% | 986us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 979us | 0.0% | 979us | `xmlHasColon` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:85` |
| 0.0% | 979us | 0.0% | 979us | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` |
| 0.0% | 978us | 0.0% | 978us | `defineProperties` | `[native code]` |
| 0.0% | 976us | 0.0% | 976us | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 966us | 0.0% | 966us | `mixedChannels` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 966us | 0.0% | 966us | `startTags` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:65` |
| 0.0% | 964us | 0.0% | 964us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 960us | 0.0% | 960us | `erFrameInkPadding` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:768` |
| 0.0% | 943us | 0.0% | 943us | `nodeWorldBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 87.4% | 3.05s | 0.0% | 0us | `withTextMeasurementExecution` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:135` |
| 64.3% | 2.25s | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 54.2% | 1.89s | 0.0% | 0us | `withPerformanceObserver` | `/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts:42` |
| 54.2% | 1.89s | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:31` |
| 54.2% | 1.89s | 0.0% | 0us | `withRenderStageObserver` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:20` |
| 54.2% | 1.89s | 0.0% | 0us | `withSvgInspectionCache` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:20` |
| 53.2% | 1.86s | 0.0% | 0us | `consumeResolvedGraphicalRequest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:316` |
| 52.8% | 1.84s | 0.0% | 0us | `measureRenderStage` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:30` |
| 35.8% | 1.25s | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:183` |
| 33.8% | 1.18s | 0.0% | 0us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:140` |
| 32.1% | 1.12s | 0.0% | 0us | `o` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 30.5% | 1.07s | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:205` |
| 30.5% | 1.07s | 0.0% | 0us | `withDeferredTerminalProjections` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:16` |
| 18.8% | 659.3ms | 0.0% | 1.2ms | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:128` |
| 16.3% | 570.8ms | 0.0% | 1.6ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:118` |
| 16.0% | 563.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6538` |
| 16.0% | 563.0ms | 0.0% | 0us | `r` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 16.0% | 563.0ms | 16.0% | 563.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:7` |
| 13.5% | 472.7ms | 7.5% | 262.3ms | `anonymous` | `[native code]` |
| 11.3% | 398.0ms | 1.1% | 40.2ms | `map` | `[native code]` |
| 10.9% | 382.1ms | 0.0% | 0us | `serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:631` |
| 10.6% | 372.0ms | 0.1% | 6.2ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:161` |
| 10.4% | 365.8ms | 0.0% | 0us | `bound require` | `[native code]` |
| 10.4% | 365.8ms | 0.0% | 0us | `require` | `[native code]` |
| 9.8% | 345.0ms | 0.0% | 0us | `renderResolvedMermaidSVG` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:270` |
| 9.8% | 345.0ms | 0.0% | 0us | `positionFamilyForNativeRender` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:67` |
| 9.6% | 338.4ms | 0.0% | 0us | `withGraphLayoutDecisionObserver` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:37` |
| 9.6% | 338.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:123` |
| 9.1% | 318.8ms | 0.0% | 0us | `layout` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:27` |
| 8.3% | 291.1ms | 0.0% | 0us | `nativeCandidate` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1115` |
| 8.3% | 291.1ms | 0.0% | 0us | `runMeasuredGraphBackend` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:73` |
| 6.0% | 212.6ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1472` |
| 6.0% | 211.3ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:575` |
| 5.8% | 206.3ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:123` |
| 5.8% | 206.0ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:672` |
| 5.3% | 187.2ms | 5.3% | 187.2ms | `gc` | `[native code]` |
| 5.2% | 181.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/util.js:3` |
| 5.1% | 179.8ms | 0.1% | 3.6ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:639` |
| 4.7% | 167.8ms | 0.0% | 0us | `markerTerminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:294` |
| 4.7% | 167.8ms | 0.0% | 0us | `prepareMarkerTerminals` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:9` |
| 4.7% | 167.0ms | 0.0% | 0us | `applyOutputSecurityPolicy` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:727` |
| 4.7% | 166.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:10` |
| 4.7% | 165.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:45` |
| 4.7% | 164.5ms | 0.0% | 0us | `inspectOwnedSvgOnce` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:46` |
| 4.6% | 161.0ms | 0.0% | 0us | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:245` |
| 4.6% | 160.9ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:252` |
| 4.5% | 159.7ms | 4.5% | 159.7ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:510` |
| 4.5% | 159.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/architecture/markers.ts:16` |
| 4.5% | 159.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:710` |
| 4.2% | 149.9ms | 0.0% | 2.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:638` |
| 4.0% | 141.3ms | 0.0% | 1.2ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1468` |
| 3.7% | 131.4ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:137` |
| 3.4% | 121.2ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:166` |
| 3.4% | 119.5ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:242` |
| 2.9% | 103.0ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:247` |
| 2.8% | 100.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/families.ts:8` |
| 2.8% | 98.7ms | 0.0% | 0us | `inspectPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:98` |
| 2.7% | 96.0ms | 0.0% | 2.7ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:283` |
| 2.4% | 87.2ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:215` |
| 2.4% | 85.8ms | 1.6% | 56.3ms | `some` | `[native code]` |
| 2.4% | 85.5ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:587` |
| 2.3% | 83.8ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1879` |
| 2.1% | 76.0ms | 0.0% | 0us | `renderCardinality` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:590` |
| 2.1% | 75.1ms | 0.0% | 0us | `flatIntoArrayWithCallback` | `[native code]` |
| 2.0% | 70.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts:47` |
| 2.0% | 70.2ms | 2.0% | 70.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts` |
| 2.0% | 70.0ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:208` |
| 1.9% | 68.7ms | 0.0% | 0us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:111` |
| 1.9% | 68.2ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1185` |
| 1.9% | 67.6ms | 1.9% | 67.6ms | `isBuiltinFamilyId` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1414` |
| 1.9% | 67.6ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1663` |
| 1.9% | 67.4ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:167` |
| 1.9% | 67.4ms | 0.0% | 0us | `report` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:235` |
| 1.9% | 66.6ms | 1.3% | 46.1ms | `stringify` | `[native code]` |
| 1.8% | 63.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/decode-data-html.js:3` |
| 1.7% | 62.4ms | 1.7% | 62.4ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:21` |
| 1.6% | 58.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:32` |
| 1.6% | 56.5ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:85` |
| 1.5% | 54.2ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:627` |
| 1.5% | 53.7ms | 0.0% | 1.6ms | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:150` |
| 1.5% | 53.2ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:403` |
| 1.5% | 52.7ms | 0.0% | 0us | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:49` |
| 1.5% | 52.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1188` |
| 1.4% | 52.4ms | 0.2% | 9.2ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:228` |
| 1.4% | 52.3ms | 0.0% | 0us | `renderCardinality` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:589` |
| 1.4% | 51.2ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:218` |
| 1.4% | 51.0ms | 1.4% | 51.0ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` |
| 1.4% | 50.2ms | 0.0% | 2.7ms | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:104` |
| 1.4% | 49.9ms | 0.0% | 0us | `erCardinalityInk` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:126` |
| 1.4% | 49.8ms | 1.1% | 41.9ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:170` |
| 1.4% | 49.3ms | 0.0% | 0us | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:621` |
| 1.3% | 47.9ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:729` |
| 1.3% | 47.4ms | 0.1% | 4.2ms | `xmlNameCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:87` |
| 1.3% | 47.0ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:90` |
| 1.2% | 43.5ms | 0.0% | 1.4ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:39` |
| 1.2% | 43.2ms | 0.0% | 0us | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1453` |
| 1.1% | 40.5ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:127` |
| 1.1% | 40.3ms | 0.7% | 26.2ms | `filter` | `[native code]` |
| 1.1% | 39.1ms | 0.0% | 0us | `renderRelationshipLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:543` |
| 1.0% | 38.4ms | 0.0% | 0us | `internal:fs/binding` | `internal:fs/binding:3` |
| 1.0% | 38.4ms | 0.0% | 0us | `node:fs` | `node:fs:8` |
| 1.0% | 38.4ms | 1.0% | 38.4ms | `@lazy` | `[native code]` |
| 1.0% | 37.1ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:186` |
| 1.0% | 37.1ms | 0.0% | 0us | `positionedPaintCertification` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:154` |
| 1.0% | 36.6ms | 0.0% | 0us | `inlineResolvedColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:636` |
| 1.0% | 36.6ms | 0.0% | 0us | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:701` |
| 1.0% | 35.1ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1301` |
| 1.0% | 35.1ms | 0.0% | 0us | `finalizeErRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:28` |
| 1.0% | 35.0ms | 0.0% | 0us | `projectSvgCss` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:287` |
| 0.9% | 34.8ms | 0.0% | 0us | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:37` |
| 0.9% | 34.1ms | 0.1% | 4.3ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1491` |
| 0.9% | 34.0ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1031` |
| 0.9% | 34.0ms | 0.0% | 0us | `rendered` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:427` |
| 0.9% | 34.0ms | 0.0% | 0us | `render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:394` |
| 0.9% | 33.7ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:682` |
| 0.9% | 33.5ms | 0.0% | 0us | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:15` |
| 0.9% | 32.8ms | 0.4% | 14.6ms | `test` | `[native code]` |
| 0.9% | 32.6ms | 0.9% | 32.6ms | `getOwnPropertyDescriptor` | `[native code]` |
| 0.9% | 32.4ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:252` |
| 0.8% | 31.0ms | 0.8% | 31.0ms | `has` | `[native code]` |
| 0.8% | 30.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1245` |
| 0.8% | 29.6ms | 0.0% | 1.3ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:652` |
| 0.8% | 29.1ms | 0.8% | 29.1ms | `copyDataProperties` | `[native code]` |
| 0.8% | 28.6ms | 0.0% | 1.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:61` |
| 0.8% | 28.4ms | 0.0% | 1.3ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` |
| 0.8% | 28.1ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:279` |
| 0.7% | 27.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:3` |
| 0.7% | 27.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:5` |
| 0.7% | 27.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:3` |
| 0.7% | 26.7ms | 0.0% | 0us | `executeInspectedGraphicalRequest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:297` |
| 0.7% | 26.2ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:259` |
| 0.7% | 25.5ms | 0.0% | 0us | `layoutErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1128` |
| 0.7% | 25.3ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:237` |
| 0.7% | 25.3ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:94` |
| 0.7% | 25.3ms | 0.0% | 0us | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:95` |
| 0.7% | 24.5ms | 0.0% | 0us | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` |
| 0.6% | 24.4ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:125` |
| 0.6% | 24.2ms | 0.4% | 17.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:407` |
| 0.6% | 23.6ms | 0.0% | 0us | `nativePlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1163` |
| 0.6% | 23.2ms | 0.6% | 23.2ms | `set` | `[native code]` |
| 0.6% | 23.2ms | 0.0% | 0us | `resolvedColorValue` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:601` |
| 0.6% | 23.2ms | 0.0% | 0us | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:220` |
| 0.6% | 22.6ms | 0.0% | 0us | `groupValidation` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:506` |
| 0.6% | 22.6ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:906` |
| 0.6% | 22.6ms | 0.0% | 2.6ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:130` |
| 0.6% | 22.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:36` |
| 0.6% | 22.1ms | 0.0% | 0us | `admitSceneDocumentWith` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:270` |
| 0.6% | 22.1ms | 0.0% | 0us | `assertAdmissibleSceneDoc` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation.ts:247` |
| 0.6% | 21.8ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:94` |
| 0.6% | 21.7ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:678` |
| 0.6% | 21.3ms | 0.0% | 0us | `measureErEntities` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:451` |
| 0.6% | 21.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:22` |
| 0.6% | 21.2ms | 0.6% | 21.2ms | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:17` |
| 0.6% | 21.1ms | 0.4% | 17.2ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` |
| 0.6% | 21.1ms | 0.6% | 21.1ms | `freeze` | `[native code]` |
| 0.6% | 21.0ms | 0.6% | 21.0ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:170` |
| 0.5% | 20.4ms | 0.0% | 0us | `get receipt` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:347` |
| 0.5% | 20.0ms | 0.5% | 20.0ms | `cloneObject` | `[native code]` |
| 0.5% | 19.8ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:195` |
| 0.5% | 19.6ms | 0.0% | 0us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:275` |
| 0.5% | 19.5ms | 0.0% | 1.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:813` |
| 0.5% | 19.5ms | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:126` |
| 0.5% | 19.5ms | 0.0% | 0us | `layout` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:23` |
| 0.5% | 19.2ms | 0.5% | 19.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.5% | 19.2ms | 0.2% | 9.9ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:420` |
| 0.5% | 19.2ms | 0.5% | 19.2ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:519` |
| 0.5% | 18.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:328` |
| 0.5% | 18.5ms | 0.0% | 0us | `nativePlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1139` |
| 0.5% | 18.5ms | 0.0% | 1.1ms | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:200` |
| 0.5% | 18.2ms | 0.0% | 0us | `visitSvgFirstTagAttributes` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:106` |
| 0.5% | 18.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:69` |
| 0.5% | 17.9ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:588` |
| 0.5% | 17.9ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1328` |
| 0.5% | 17.6ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:736` |
| 0.4% | 17.4ms | 0.4% | 17.4ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` |
| 0.4% | 17.1ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:106` |
| 0.4% | 17.1ms | 0.0% | 0us | `erCardinalityEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:134` |
| 0.4% | 17.0ms | 0.1% | 6.3ms | `Set` | `[native code]` |
| 0.4% | 16.7ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1473` |
| 0.4% | 16.7ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:646` |
| 0.4% | 16.4ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:296` |
| 0.4% | 16.4ms | 0.0% | 3.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:297` |
| 0.4% | 16.1ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:198` |
| 0.4% | 15.9ms | 0.0% | 0us | `captureNativeGroupParse` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:173` |
| 0.4% | 15.9ms | 0.0% | 0us | `captureNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:101` |
| 0.4% | 15.6ms | 0.4% | 15.6ms | `add` | `[native code]` |
| 0.4% | 15.6ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:738` |
| 0.4% | 15.5ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1878` |
| 0.4% | 15.4ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1322` |
| 0.4% | 15.3ms | 0.0% | 0us | `parseErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:832` |
| 0.4% | 15.1ms | 0.0% | 0us | `drawn` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:421` |
| 0.4% | 15.0ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:140` |
| 0.4% | 14.9ms | 0.0% | 0us | `paintAttribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:493` |
| 0.4% | 14.7ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1621` |
| 0.4% | 14.6ms | 0.4% | 14.6ms | `every` | `[native code]` |
| 0.4% | 14.5ms | 0.4% | 14.5ms | `sourceIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` |
| 0.4% | 14.4ms | 0.0% | 1.4ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:726` |
| 0.4% | 14.4ms | 0.0% | 0us | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1456` |
| 0.4% | 14.3ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:184` |
| 0.4% | 14.3ms | 0.0% | 0us | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:200` |
| 0.4% | 14.2ms | 0.4% | 14.2ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:92` |
| 0.4% | 14.1ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:49` |
| 0.4% | 14.1ms | 0.0% | 0us | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:56` |
| 0.3% | 13.8ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1008` |
| 0.3% | 13.7ms | 0.0% | 0us | `node:zlib` | `node:zlib:2` |
| 0.3% | 13.7ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:203` |
| 0.3% | 13.7ms | 0.0% | 0us | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:515` |
| 0.3% | 13.5ms | 0.0% | 1.0ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:653` |
| 0.3% | 13.4ms | 0.1% | 4.2ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:171` |
| 0.3% | 13.3ms | 0.0% | 0us | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:702` |
| 0.3% | 13.2ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:295` |
| 0.3% | 13.2ms | 0.0% | 0us | `chargeInkSort` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:11` |
| 0.3% | 13.1ms | 0.0% | 0us | `resolveSvgColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:758` |
| 0.3% | 13.1ms | 0.0% | 2.6ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` |
| 0.3% | 13.1ms | 0.0% | 1.4ms | `ensureContrast` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:102` |
| 0.3% | 13.0ms | 0.3% | 11.8ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:109` |
| 0.3% | 12.8ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:998` |
| 0.3% | 12.8ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:83` |
| 0.3% | 12.7ms | 0.3% | 12.7ms | `join` | `[native code]` |
| 0.3% | 12.7ms | 0.0% | 0us | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1318` |
| 0.3% | 12.6ms | 0.0% | 2.2ms | `serialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1500` |
| 0.3% | 12.6ms | 0.3% | 12.6ms | `defineProperty` | `[native code]` |
| 0.3% | 12.4ms | 0.3% | 12.4ms | `get` | `[native code]` |
| 0.3% | 12.4ms | 0.0% | 0us | `collides` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:173` |
| 0.3% | 12.4ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:617` |
| 0.3% | 12.1ms | 0.0% | 2.2ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:581` |
| 0.3% | 12.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-doc.js:4` |
| 0.3% | 12.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:8` |
| 0.3% | 12.0ms | 0.0% | 1.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:431` |
| 0.3% | 12.0ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:175` |
| 0.3% | 11.7ms | 0.0% | 2.8ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` |
| 0.3% | 11.7ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:311` |
| 0.3% | 11.6ms | 0.3% | 11.6ms | `xmlRange` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:48` |
| 0.3% | 11.6ms | 0.0% | 0us | `normalizeMermaidSourceWithOverrides` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:762` |
| 0.3% | 11.6ms | 0.0% | 0us | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:739` |
| 0.3% | 11.6ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1737` |
| 0.3% | 11.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:5` |
| 0.3% | 11.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:8` |
| 0.3% | 11.4ms | 0.2% | 7.2ms | `find` | `[native code]` |
| 0.3% | 11.2ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` |
| 0.3% | 11.1ms | 0.0% | 0us | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:34` |
| 0.3% | 11.1ms | 0.0% | 0us | `zlibBufferSync` | `node:zlib:94` |
| 0.3% | 10.9ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` |
| 0.3% | 10.9ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:237` |
| 0.3% | 10.7ms | 0.3% | 10.7ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` |
| 0.3% | 10.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:713` |
| 0.3% | 10.6ms | 0.0% | 1.2ms | `next` | `[native code]` |
| 0.3% | 10.6ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:73` |
| 0.3% | 10.5ms | 0.3% | 10.5ms | `/^\s*<g\b[^>]*>(?:<title>[^<]*<\/title>)?$/` | `[native code]` |
| 0.3% | 10.5ms | 0.0% | 0us | `node:stream` | `node:stream:2` |
| 0.3% | 10.5ms | 0.0% | 0us | `internal:stream` | `internal:stream:2` |
| 0.2% | 10.4ms | 0.2% | 10.4ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:485` |
| 0.2% | 10.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:7` |
| 0.2% | 10.3ms | 0.0% | 0us | `renderedSvgDigest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:61` |
| 0.2% | 10.2ms | 0.0% | 2.6ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` |
| 0.2% | 10.1ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` |
| 0.2% | 10.0ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:323` |
| 0.2% | 9.9ms | 0.0% | 2.4ms | `chargeInkSort` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:7` |
| 0.2% | 9.7ms | 0.0% | 0us | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:572` |
| 0.2% | 9.7ms | 0.1% | 4.8ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:156` |
| 0.2% | 9.7ms | 0.0% | 0us | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:530` |
| 0.2% | 9.6ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:411` |
| 0.2% | 9.6ms | 0.0% | 2.7ms | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1395` |
| 0.2% | 9.6ms | 0.0% | 0us | `processChunkSync` | `node:zlib:203` |
| 0.2% | 9.6ms | 0.2% | 9.6ms | `writeSync` | `[native code]` |
| 0.2% | 9.6ms | 0.0% | 0us | `admitSceneDocumentWith` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:268` |
| 0.2% | 9.6ms | 0.0% | 1.3ms | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:197` |
| 0.2% | 9.5ms | 0.0% | 1.0ms | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:92` |
| 0.2% | 9.5ms | 0.0% | 2.6ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:778` |
| 0.2% | 9.5ms | 0.0% | 0us | `resolveRenderStyle` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts:283` |
| 0.2% | 9.5ms | 0.2% | 9.5ms | `positiveNumber` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts:216` |
| 0.2% | 9.4ms | 0.0% | 0us | `visitSvgStartTagsFresh` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:116` |
| 0.2% | 9.4ms | 0.0% | 0us | `collectNativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:146` |
| 0.2% | 9.4ms | 0.2% | 8.3ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:162` |
| 0.2% | 9.3ms | 0.2% | 9.3ms | `arrayIteratorNextHelper` | `[native code]` |
| 0.2% | 9.3ms | 0.0% | 0us | `relativeLuminance` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:78` |
| 0.2% | 9.2ms | 0.0% | 0us | `contrastRatio` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:85` |
| 0.2% | 9.2ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:171` |
| 0.2% | 9.1ms | 0.0% | 0us | `internal:streams/pipeline` | `internal:streams/pipeline:2` |
| 0.2% | 9.1ms | 0.0% | 0us | `internal:streams/compose` | `internal:streams/compose:2` |
| 0.2% | 9.1ms | 0.0% | 0us | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:178` |
| 0.2% | 9.0ms | 0.0% | 1.0ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:221` |
| 0.2% | 9.0ms | 0.0% | 0us | `renderRelationshipLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:534` |
| 0.2% | 8.8ms | 0.0% | 3.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:800` |
| 0.2% | 8.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:659` |
| 0.2% | 8.8ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:563` |
| 0.2% | 8.8ms | 0.0% | 1.2ms | `reduce` | `[native code]` |
| 0.2% | 8.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:112` |
| 0.2% | 8.6ms | 0.0% | 0us | `enoughLead` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:300` |
| 0.2% | 8.5ms | 0.2% | 8.5ms | `isFrozen` | `[native code]` |
| 0.2% | 8.5ms | 0.0% | 0us | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:277` |
| 0.2% | 8.5ms | 0.2% | 8.5ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1171` |
| 0.2% | 8.5ms | 0.1% | 4.4ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:122` |
| 0.2% | 8.4ms | 0.2% | 8.4ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:96` |
| 0.2% | 8.3ms | 0.0% | 0us | `readErOuterStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:514` |
| 0.2% | 8.3ms | 0.0% | 0us | `findErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:698` |
| 0.2% | 8.3ms | 0.0% | 1.5ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:405` |
| 0.2% | 8.3ms | 0.2% | 8.3ms | `lazyGraphicalArtifact` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:344` |
| 0.2% | 8.2ms | 0.0% | 0us | `resolveRoleStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:251` |
| 0.2% | 8.2ms | 0.0% | 2.2ms | `compositeCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:275` |
| 0.2% | 8.2ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:719` |
| 0.2% | 8.1ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:509` |
| 0.2% | 8.0ms | 0.0% | 1.3ms | `forEach` | `[native code]` |
| 0.2% | 7.9ms | 0.2% | 7.9ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:20` |
| 0.2% | 7.9ms | 0.0% | 2.9ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:685` |
| 0.2% | 7.9ms | 0.0% | 0us | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:190` |
| 0.2% | 7.9ms | 0.2% | 7.9ms | `ownerSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.2% | 7.8ms | 0.0% | 0us | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:102` |
| 0.2% | 7.8ms | 0.0% | 0us | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1501` |
| 0.2% | 7.6ms | 0.2% | 7.6ms | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1447` |
| 0.2% | 7.6ms | 0.0% | 1.5ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:253` |
| 0.2% | 7.5ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:186` |
| 0.2% | 7.5ms | 0.0% | 0us | `erCardinalityInk` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:127` |
| 0.2% | 7.5ms | 0.2% | 7.5ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1801` |
| 0.2% | 7.4ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1392` |
| 0.2% | 7.4ms | 0.0% | 0us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:274` |
| 0.2% | 7.4ms | 0.2% | 7.4ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:203` |
| 0.2% | 7.4ms | 0.2% | 7.4ms | `importModule` | `[native code]` |
| 0.2% | 7.4ms | 0.2% | 7.4ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` |
| 0.2% | 7.4ms | 0.0% | 0us | `(anonymous)` | `[native code]` |
| 0.2% | 7.3ms | 0.0% | 0us | `advance` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` |
| 0.2% | 7.3ms | 0.1% | 5.1ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:173` |
| 0.2% | 7.3ms | 0.0% | 1.1ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:144` |
| 0.2% | 7.2ms | 0.0% | 0us | `resolveRoleStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:244` |
| 0.2% | 7.2ms | 0.2% | 7.2ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` |
| 0.2% | 7.2ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:169` |
| 0.2% | 7.2ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:178` |
| 0.2% | 7.2ms | 0.0% | 0us | `svgStyleRanges` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:294` |
| 0.2% | 7.2ms | 0.0% | 1.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:276` |
| 0.2% | 7.1ms | 0.0% | 0us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:251` |
| 0.2% | 7.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:116` |
| 0.2% | 7.0ms | 0.1% | 4.6ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:173` |
| 0.2% | 7.0ms | 0.0% | 0us | `readErStatement` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:298` |
| 0.2% | 7.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:817` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `RegExp` | `[native code]` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:295` |
| 0.1% | 6.9ms | 0.0% | 0us | `Zlib` | `node:zlib:298` |
| 0.1% | 6.9ms | 0.0% | 0us | `gzipSync` | `node:zlib:360` |
| 0.1% | 6.9ms | 0.0% | 0us | `Gzip` | `node:zlib:328` |
| 0.1% | 6.7ms | 0.0% | 0us | `erCardinalityInk` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:123` |
| 0.1% | 6.7ms | 0.1% | 6.7ms | `Segmenter` | `[native code]` |
| 0.1% | 6.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts:3` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:316` |
| 0.1% | 6.6ms | 0.0% | 1.2ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:420` |
| 0.1% | 6.6ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:199` |
| 0.1% | 6.6ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:605` |
| 0.1% | 6.6ms | 0.0% | 0us | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:41` |
| 0.1% | 6.6ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1483` |
| 0.1% | 6.6ms | 0.1% | 3.9ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:711` |
| 0.1% | 6.6ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:2` |
| 0.1% | 6.6ms | 0.0% | 3.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:776` |
| 0.1% | 6.5ms | 0.0% | 1.2ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:486` |
| 0.1% | 6.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/terminal-contract.ts:29` |
| 0.1% | 6.3ms | 0.1% | 3.6ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:88` |
| 0.1% | 6.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:7` |
| 0.1% | 6.3ms | 0.0% | 0us | `hasDomSvgIdentityRole` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:69` |
| 0.1% | 6.3ms | 0.1% | 6.3ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:205` |
| 0.1% | 6.3ms | 0.0% | 0us | `nativePlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1154` |
| 0.1% | 6.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1160` |
| 0.1% | 6.2ms | 0.0% | 0us | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:569` |
| 0.1% | 6.2ms | 0.0% | 0us | `deferredTerminalProjectionInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:66` |
| 0.1% | 6.1ms | 0.0% | 2.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:128` |
| 0.1% | 6.1ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:125` |
| 0.1% | 6.1ms | 0.0% | 0us | `measureTextWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:206` |
| 0.1% | 6.1ms | 0.0% | 0us | `measureText` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:188` |
| 0.1% | 6.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` |
| 0.1% | 6.0ms | 0.1% | 5.1ms | `append` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:239` |
| 0.1% | 6.0ms | 0.0% | 1.4ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:471` |
| 0.1% | 6.0ms | 0.0% | 1.1ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:315` |
| 0.1% | 6.0ms | 0.1% | 3.6ms | `replace` | `[native code]` |
| 0.1% | 5.9ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:313` |
| 0.1% | 5.9ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:171` |
| 0.1% | 5.8ms | 0.0% | 0us | `cloneValue` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `slice` | `[native code]` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:66` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:95` |
| 0.1% | 5.7ms | 0.0% | 2.9ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:36` |
| 0.1% | 5.7ms | 0.0% | 0us | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` |
| 0.1% | 5.6ms | 0.1% | 5.6ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:176` |
| 0.1% | 5.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:16` |
| 0.1% | 5.6ms | 0.0% | 1.7ms | `sceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` |
| 0.1% | 5.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:5` |
| 0.1% | 5.5ms | 0.1% | 5.5ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 5.5ms | 0.0% | 0us | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:229` |
| 0.1% | 5.4ms | 0.0% | 1.4ms | `strokedBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:543` |
| 0.1% | 5.4ms | 0.0% | 1.5ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:298` |
| 0.1% | 5.4ms | 0.0% | 1.8ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:214` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 5.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:71` |
| 0.1% | 5.2ms | 0.0% | 0us | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:240` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `xmlScalarCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:88` |
| 0.1% | 5.2ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1637` |
| 0.1% | 5.2ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:633` |
| 0.1% | 5.2ms | 0.1% | 3.7ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:268` |
| 0.1% | 5.1ms | 0.0% | 0us | `registerBuiltInStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:292` |
| 0.1% | 5.0ms | 0.0% | 1.2ms | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:536` |
| 0.1% | 5.0ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:145` |
| 0.1% | 5.0ms | 0.0% | 0us | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:560` |
| 0.1% | 5.0ms | 0.0% | 0us | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:98` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1462` |
| 0.1% | 4.9ms | 0.0% | 1.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:653` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 4.9ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1224` |
| 0.1% | 4.9ms | 0.0% | 2.2ms | `snapshotScenePrimitiveCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1541` |
| 0.1% | 4.9ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1583` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1456` |
| 0.1% | 4.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:310` |
| 0.1% | 4.8ms | 0.0% | 0us | `transformSvgCssValues` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:308` |
| 0.1% | 4.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `deferredTerminalProjectionInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.1% | 4.8ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:376` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `collectPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1374` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:93` |
| 0.1% | 4.7ms | 0.0% | 0us | `ZlibBase` | `node:zlib:123` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `snapshotBoundedExternalData` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `compare` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:33` |
| 0.1% | 4.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1355` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `/[^\x20-\x7e]/u` | `[native code]` |
| 0.1% | 4.6ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:761` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:618` |
| 0.1% | 4.6ms | 0.0% | 0us | `inspectOwnedSvgOnce` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:44` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:179` |
| 0.1% | 4.6ms | 0.0% | 0us | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:130` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.1% | 4.5ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:172` |
| 0.1% | 4.5ms | 0.0% | 1.4ms | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:446` |
| 0.1% | 4.5ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:674` |
| 0.1% | 4.5ms | 0.0% | 1.3ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:193` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` |
| 0.1% | 4.5ms | 0.0% | 3.0ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:501` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts` |
| 0.1% | 4.5ms | 0.0% | 2.4ms | `expectedCapabilityState` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1641` |
| 0.1% | 4.5ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1826` |
| 0.1% | 4.4ms | 0.0% | 0us | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:213` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1091` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `hasOwn` | `[native code]` |
| 0.1% | 4.4ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:196` |
| 0.1% | 4.4ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:321` |
| 0.1% | 4.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/block/markers.ts:10` |
| 0.1% | 4.4ms | 0.1% | 4.4ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:413` |
| 0.1% | 4.3ms | 0.0% | 1.3ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:526` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:163` |
| 0.1% | 4.3ms | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:495` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `flatIntoArray` | `[native code]` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:116` |
| 0.1% | 4.3ms | 0.0% | 1.8ms | `terminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1251` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:681` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 4.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:6` |
| 0.1% | 4.1ms | 0.0% | 0us | `measureErEntities` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:453` |
| 0.1% | 4.1ms | 0.0% | 1.3ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:517` |
| 0.1% | 4.1ms | 0.0% | 0us | `captureNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:94` |
| 0.1% | 4.1ms | 0.1% | 4.1ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.1% | 4.1ms | 0.1% | 4.1ms | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.1% | 4.1ms | 0.1% | 4.1ms | `Buffer` | `[native code]` |
| 0.1% | 4.1ms | 0.0% | 0us | `zlibBufferSync` | `node:zlib:88` |
| 0.1% | 4.1ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:148` |
| 0.1% | 4.1ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:185` |
| 0.1% | 4.1ms | 0.0% | 0us | `toHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:43` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:533` |
| 0.1% | 4.0ms | 0.0% | 0us | `hooks` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:507` |
| 0.1% | 4.0ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:803` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `push` | `[native code]` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `ownFragment` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:116` |
| 0.1% | 4.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1357` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:235` |
| 0.1% | 4.0ms | 0.0% | 0us | `nativePlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1137` |
| 0.1% | 4.0ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1502` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:580` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 4.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1367` |
| 0.1% | 3.9ms | 0.0% | 1.0ms | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` |
| 0.1% | 3.9ms | 0.0% | 2.1ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:660` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `/[^\x00-\x7f]/` | `[native code]` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` |
| 0.1% | 3.9ms | 0.0% | 1.1ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:142` |
| 0.1% | 3.9ms | 0.0% | 0us | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:397` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:643` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `assign` | `[native code]` |
| 0.1% | 3.9ms | 0.0% | 1.5ms | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:171` |
| 0.1% | 3.9ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1480` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.1% | 3.8ms | 0.1% | 3.8ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.1% | 3.8ms | 0.0% | 0us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:277` |
| 0.1% | 3.8ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:582` |
| 0.1% | 3.8ms | 0.1% | 3.8ms | `localPaintResourceId` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:373` |
| 0.1% | 3.8ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:268` |
| 0.1% | 3.8ms | 0.1% | 3.8ms | `sceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.1% | 3.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/util.js:5` |
| 0.1% | 3.7ms | 0.0% | 2.5ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` |
| 0.1% | 3.7ms | 0.1% | 3.7ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:67` |
| 0.1% | 3.7ms | 0.1% | 3.7ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:461` |
| 0.1% | 3.7ms | 0.1% | 3.7ms | `inverseMatrix` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:23` |
| 0.1% | 3.7ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1930` |
| 0.1% | 3.7ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:464` |
| 0.1% | 3.7ms | 0.1% | 3.7ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:176` |
| 0.1% | 3.7ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:777` |
| 0.1% | 3.7ms | 0.1% | 3.7ms | `record` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 3.7ms | 0.0% | 1.1ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:281` |
| 0.1% | 3.6ms | 0.1% | 3.6ms | `includes` | `[native code]` |
| 0.1% | 3.6ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:759` |
| 0.1% | 3.6ms | 0.1% | 3.6ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:304` |
| 0.1% | 3.6ms | 0.1% | 3.6ms | `isWhitespace` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.1% | 3.6ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:153` |
| 0.1% | 3.6ms | 0.1% | 3.6ms | `nodeWorldBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:460` |
| 0.1% | 3.5ms | 0.1% | 3.5ms | `hasSceneWriteEmissionOccurrence` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.1% | 3.5ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1460` |
| 0.1% | 3.5ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:532` |
| 0.1% | 3.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:974` |
| 0.1% | 3.5ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1088` |
| 0.1% | 3.5ms | 0.1% | 3.5ms | `values` | `[native code]` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:113` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:844` |
| 0.0% | 3.4ms | 0.0% | 2.1ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:311` |
| 0.0% | 3.4ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:250` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `inRanges` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:114` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:40` |
| 0.0% | 3.4ms | 0.0% | 0us | `registerGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:87` |
| 0.0% | 3.4ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1394` |
| 0.0% | 3.3ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:225` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `topRoundedRectPath` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:844` |
| 0.0% | 3.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:143` |
| 0.0% | 3.3ms | 0.0% | 0us | `assessRenderedLayoutHardViolations` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:211` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:193` |
| 0.0% | 3.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:760` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.0% | 3.3ms | 0.0% | 2.1ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:150` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:662` |
| 0.0% | 3.2ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:80` |
| 0.0% | 3.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:26` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:481` |
| 0.0% | 3.2ms | 0.0% | 0us | `getCharWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:91` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:87` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `trim` | `[native code]` |
| 0.0% | 3.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:142` |
| 0.0% | 3.1ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:317` |
| 0.0% | 3.1ms | 0.0% | 0us | `applyReplacements` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:233` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `sort` | `[native code]` |
| 0.0% | 3.1ms | 0.0% | 0us | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:353` |
| 0.0% | 3.1ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1728` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` |
| 0.0% | 3.1ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:153` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:336` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:309` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 3.0ms | 0.0% | 0us | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:440` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` |
| 0.0% | 3.0ms | 0.0% | 1.0ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` |
| 0.0% | 3.0ms | 0.0% | 0us | `relationAccessibility` | `/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` |
| 0.0% | 3.0ms | 0.0% | 1.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:118` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `writeStructuredSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:594` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:147` |
| 0.0% | 3.0ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:774` |
| 0.0% | 3.0ms | 0.0% | 0us | `hasOwned` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:11` |
| 0.0% | 3.0ms | 0.0% | 0us | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:213` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:271` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:590` |
| 0.0% | 2.9ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:590` |
| 0.0% | 2.9ms | 0.0% | 1.6ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:582` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `min` | `[native code]` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `ArrayBuffer` | `[native code]` |
| 0.0% | 2.9ms | 0.0% | 0us | `node:zlib` | `node:zlib:159` |
| 0.0% | 2.9ms | 0.0% | 0us | `erRelationshipBlock` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:19` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2361` |
| 0.0% | 2.9ms | 0.0% | 0us | `parseErRelationshipSyntax` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1086` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:845` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:134` |
| 0.0% | 2.9ms | 0.0% | 1.4ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:581` |
| 0.0% | 2.9ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1783` |
| 0.0% | 2.8ms | 0.0% | 1.3ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1386` |
| 0.0% | 2.8ms | 0.0% | 1.1ms | `erCardinalityPieces` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:66` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:207` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:106` |
| 0.0% | 2.8ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1356` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `parseErRelationshipSyntax` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 2.8ms | 0.0% | 0us | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:85` |
| 0.0% | 2.8ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:893` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:207` |
| 0.0% | 2.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:7` |
| 0.0% | 2.8ms | 0.0% | 1.5ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1391` |
| 0.0% | 2.8ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:197` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:443` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `skipSeparators` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:168` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:214` |
| 0.0% | 2.7ms | 0.0% | 0us | `evaluateExtensionCompatibility` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:110` |
| 0.0% | 2.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:186` |
| 0.0% | 2.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:185` |
| 0.0% | 2.7ms | 0.0% | 0us | `createExtensionIdentity` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:246` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `isSupportedSemVerRange` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:327` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `flatMap` | `[native code]` |
| 0.0% | 2.7ms | 0.0% | 0us | `renderRelationshipLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:527` |
| 0.0% | 2.7ms | 0.0% | 0us | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1319` |
| 0.0% | 2.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1319` |
| 0.0% | 2.7ms | 0.0% | 1.2ms | `glyphBox` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1314` |
| 0.0% | 2.7ms | 0.0% | 1.4ms | `value` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:127` |
| 0.0% | 2.7ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1336` |
| 0.0% | 2.7ms | 0.0% | 1.4ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:739` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `overlaps` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:56` |
| 0.0% | 2.7ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:62` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:154` |
| 0.0% | 2.7ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1765` |
| 0.0% | 2.7ms | 0.0% | 1.3ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:535` |
| 0.0% | 2.7ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1535` |
| 0.0% | 2.7ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:247` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:663` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 2.6ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:475` |
| 0.0% | 2.6ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:312` |
| 0.0% | 2.6ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` |
| 0.0% | 2.6ms | 0.0% | 0us | `captureFields` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` |
| 0.0% | 2.6ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:641` |
| 0.0% | 2.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:14` |
| 0.0% | 2.6ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1520` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `entries` | `[native code]` |
| 0.0% | 2.6ms | 0.0% | 0us | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:365` |
| 0.0% | 2.6ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1507` |
| 0.0% | 2.6ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:219` |
| 0.0% | 2.6ms | 0.0% | 0us | `validateAggregateReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1525` |
| 0.0% | 2.6ms | 0.0% | 1.2ms | `replaceField` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:294` |
| 0.0% | 2.6ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:156` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `appendPrivate` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:55` |
| 0.0% | 2.6ms | 0.0% | 1.1ms | `connectorGeometryEndpoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:174` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:406` |
| 0.0% | 2.5ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:676` |
| 0.0% | 2.5ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:689` |
| 0.0% | 2.5ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:821` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `Number` | `[native code]` |
| 0.0% | 2.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:4` |
| 0.0% | 2.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringifyPair.js:5` |
| 0.0% | 2.5ms | 0.0% | 1.4ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:177` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 0.0% | 2.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/createNode.js:3` |
| 0.0% | 2.5ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1917` |
| 0.0% | 2.5ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:484` |
| 0.0% | 2.5ms | 0.0% | 0us | `label` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1492` |
| 0.0% | 2.5ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1495` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `box` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:59` |
| 0.0% | 2.5ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:181` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `split` | `[native code]` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.0% | 2.4ms | 0.0% | 0us | `setConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:53` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `erCardinalityPieces` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:110` |
| 0.0% | 2.4ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:402` |
| 0.0% | 2.4ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:298` |
| 0.0% | 2.4ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1029` |
| 0.0% | 2.4ms | 0.0% | 0us | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:86` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:114` |
| 0.0% | 2.4ms | 0.0% | 1.0ms | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` |
| 0.0% | 2.4ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:763` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 2.4ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1561` |
| 0.0% | 2.4ms | 0.0% | 0us | `contrastRatio` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:84` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 2.4ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:108` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:894` |
| 0.0% | 2.4ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:195` |
| 0.0% | 2.4ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1558` |
| 0.0% | 2.4ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:581` |
| 0.0% | 2.4ms | 0.0% | 1.2ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:517` |
| 0.0% | 2.4ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:941` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `erCardinalityInk` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:125` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1374` |
| 0.0% | 2.4ms | 0.0% | 0us | `attr` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:53` |
| 0.0% | 2.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:5` |
| 0.0% | 2.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:3` |
| 0.0% | 2.3ms | 0.0% | 1.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:640` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.3ms | 0.0% | 0us | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:27` |
| 0.0% | 2.3ms | 0.0% | 1.2ms | `srgbRelativeLuminance` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:68` |
| 0.0% | 2.3ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:424` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:552` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:440` |
| 0.0% | 2.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1052` |
| 0.0% | 2.3ms | 0.0% | 1.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1104` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1516` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:117` |
| 0.0% | 2.3ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:693` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `Transform` | `internal:streams/transform` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 2.3ms | 0.0% | 1.1ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:13` |
| 0.0% | 2.3ms | 0.0% | 0us | `admitSceneDocumentWith` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:271` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `recordAdmittedScene` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-admission-state.ts` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/flowchart-lexer.ts` |
| 0.0% | 2.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/flowchart-lexer.ts:115` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:275` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:51` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `serialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1499` |
| 0.0% | 2.2ms | 0.0% | 1.2ms | `tagRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:25` |
| 0.0% | 2.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/omap.js:7` |
| 0.0% | 2.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:14` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:145` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:488` |
| 0.0% | 2.2ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:807` |
| 0.0% | 2.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:13` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `parseInt` | `[native code]` |
| 0.0% | 2.2ms | 0.0% | 0us | `get WriteStream` | `node:fs:667` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:331` |
| 0.0% | 2.2ms | 0.0% | 0us | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:476` |
| 0.0% | 2.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1267` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 2.2ms | 0.0% | 1.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:229` |
| 0.0% | 2.2ms | 0.0% | 1.1ms | `replaceField` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:293` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1452` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:303` |
| 0.0% | 2.1ms | 0.0% | 1.2ms | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:265` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `f` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/geometry.ts:16` |
| 0.0% | 2.1ms | 0.0% | 0us | `projectErPositioned` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:11` |
| 0.0% | 2.1ms | 0.0% | 1.0ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:91` |
| 0.0% | 2.1ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:592` |
| 0.0% | 2.1ms | 0.0% | 0us | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:209` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:224` |
| 0.0% | 2.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:16` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `finiteRect` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:159` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `init` | `[native code]` |
| 0.0% | 2.1ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:739` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `terminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `getOwnPropertyNames` | `[native code]` |
| 0.0% | 2.1ms | 0.0% | 0us | `replaceField` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:286` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `parseFloat` | `[native code]` |
| 0.0% | 2.0ms | 0.0% | 0us | `rejectUnknownKeys` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:154` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1664` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 2.0ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:715` |
| 0.0% | 2.0ms | 0.0% | 0us | `assignChannelTracks` | `/tmp/pr449-main-integration-20261029-762/src/layout/channel-tracks.ts:27` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `toPrecision` | `[native code]` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `hasPublicLayoutProjection` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 2.0ms | 0.0% | 0us | `hasPublicVerificationProjection` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1620` |
| 0.0% | 2.0ms | 0.0% | 0us | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:454` |
| 0.0% | 2.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:875` |
| 0.0% | 2.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1534` |
| 0.0% | 2.0ms | 0.0% | 0us | `collectPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1376` |
| 0.0% | 2.0ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:760` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `ownedTextPaintRoster` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 2.0ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1944` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `connectorMarkerPaintRegions` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:355` |
| 0.0% | 2.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1569` |
| 0.0% | 2.0ms | 0.0% | 0us | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:27` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:356` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:824` |
| 0.0% | 1.9ms | 0.0% | 0us | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:93` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `indentLines` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:744` |
| 0.0% | 1.9ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1782` |
| 0.0% | 1.8ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:405` |
| 0.0% | 1.8ms | 0.0% | 0us | `styledRunLayout` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:252` |
| 0.0% | 1.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:253` |
| 0.0% | 1.8ms | 0.0% | 0us | `isWideRange` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:127` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.0% | 1.8ms | 0.0% | 0us | `advanceAttrs` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:264` |
| 0.0% | 1.8ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/encode-html.js:10` |
| 0.0% | 1.8ms | 0.0% | 0us | `parseEncodeTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:85` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1356` |
| 0.0% | 1.8ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:96` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `shortenMeasuredRoutes` | `/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts` |
| 0.0% | 1.8ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:808` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:708` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:841` |
| 0.0% | 1.8ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:562` |
| 0.0% | 1.8ms | 0.0% | 0us | `mermaidInitDirectives` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:558` |
| 0.0% | 1.8ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:702` |
| 0.0% | 1.8ms | 0.0% | 0us | `sourceEnvelopeMetadata` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:789` |
| 0.0% | 1.7ms | 0.0% | 0us | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1385` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:254` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:410` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `pushTickAt` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:55` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `skipSpace` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:667` |
| 0.0% | 1.7ms | 0.0% | 0us | `findErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:670` |
| 0.0% | 1.7ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:101` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `admitWritableSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:501` |
| 0.0% | 1.7ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:103` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validateRole` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.7ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `renderCardinality` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.6ms | 0.0% | 0us | `inspectSecurityTail` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:691` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `/<(?:[^\s<>/:]+:)?iframe\b/i` | `[native code]` |
| 0.0% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/createNode.js:5` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Scalar.js:8` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `installedFamilyStatementEnds` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts` |
| 0.0% | 1.6ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:697` |
| 0.0% | 1.6ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1749` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `capturedRequestFamily` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.6ms | 0.0% | 0us | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:62` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `compare` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.0% | 1.6ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1773` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/generated-identity.ts:7` |
| 0.0% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:279` |
| 0.0% | 1.6ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:278` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:848` |
| 0.0% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:181` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:700` |
| 0.0% | 1.6ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:489` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:670` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:175` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `createTextMeasurementExecution` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts` |
| 0.0% | 1.6ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1553` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:487` |
| 0.0% | 1.6ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:722` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:298` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:830` |
| 0.0% | 1.5ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:725` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:538` |
| 0.0% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:8` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:259` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `tag` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:152` |
| 0.0% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1131` |
| 0.0% | 1.5ms | 0.0% | 0us | `receiptOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:757` |
| 0.0% | 1.5ms | 0.0% | 0us | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1097` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `projectSvgCss` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:330` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `tag` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:148` |
| 0.0% | 1.5ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1148` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:26` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `get` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` |
| 0.0% | 1.5ms | 0.0% | 0us | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:474` |
| 0.0% | 1.5ms | 0.0% | 0us | `canonicalizeSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:458` |
| 0.0% | 1.5ms | 0.0% | 0us | `isCombiningMark` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:49` |
| 0.0% | 1.5ms | 0.0% | 0us | `getCharWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:88` |
| 0.0% | 1.5ms | 0.0% | 0us | `isZeroWidth` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:137` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:713` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `typographyAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:694` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `erLabelUnread` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1059` |
| 0.0% | 1.5ms | 0.0% | 0us | `parseErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:918` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:922` |
| 0.0% | 1.5ms | 0.0% | 0us | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:471` |
| 0.0% | 1.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:810` |
| 0.0% | 1.5ms | 0.0% | 0us | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:445` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `numberIsValid` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:280` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `intersects` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `finishXmlLeaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:277` |
| 0.0% | 1.5ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:380` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `SvgWriter` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `_close` | `node:zlib` |
| 0.0% | 1.5ms | 0.0% | 0us | `processChunkSync` | `node:zlib:229` |
| 0.0% | 1.5ms | 0.0% | 0us | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:111` |
| 0.0% | 1.5ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1209` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1715` |
| 0.0% | 1.5ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1715` |
| 0.0% | 1.5ms | 0.0% | 0us | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:218` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1004` |
| 0.0% | 1.5ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:92` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:518` |
| 0.0% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:15` |
| 0.0% | 1.5ms | 0.0% | 0us | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:662` |
| 0.0% | 1.5ms | 0.0% | 0us | `unsafeCssReferences` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:599` |
| 0.0% | 1.5ms | 0.0% | 0us | `normalizeCssObfuscation` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:29` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `erFrameInkPadding` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:758` |
| 0.0% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/resolve-block-map.js:6` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1242` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1397` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `isArray` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1078` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:28` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:794` |
| 0.0% | 1.4ms | 0.0% | 0us | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:585` |
| 0.0% | 1.4ms | 0.0% | 0us | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:174` |
| 0.0% | 1.4ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1128` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:554` |
| 0.0% | 1.4ms | 0.0% | 0us | `snapshotCapabilityCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1559` |
| 0.0% | 1.4ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1584` |
| 0.0% | 1.4ms | 0.0% | 0us | `escapeDisplayAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:115` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:745` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `stripTrailingComment` | `/tmp/pr449-main-integration-20261029-762/src/shared/trailing-comment.ts:52` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `trailingCommentStart` | `/tmp/pr449-main-integration-20261029-762/src/shared/trailing-comment.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `findErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:665` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:23` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `assertMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/journey/config-diagnostics.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/journey/config-diagnostics.ts:7` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:285` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `declareFamilyScenePrimitiveEvidence` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:254` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `resolveSvgColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1384` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:14` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `unionSceneBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:213` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `commandAtCursor` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:172` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `nativePaintSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:228` |
| 0.0% | 1.4ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:145` |
| 0.0% | 1.4ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:284` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:150` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts:4` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `connectorSubpaths` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1206` |
| 0.0% | 1.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:255` |
| 0.0% | 1.4ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:132` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:151` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:9` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:840` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:473` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:568` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `nativeAttributeValue` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:59` |
| 0.0% | 1.3ms | 0.0% | 0us | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:408` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:8` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:18` |
| 0.0% | 1.3ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:188` |
| 0.0% | 1.3ms | 0.0% | 0us | `toHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:44` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `relationshipFrom` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1107` |
| 0.0% | 1.3ms | 0.0% | 0us | `parseErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:898` |
| 0.0% | 1.3ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:689` |
| 0.0% | 1.3ms | 0.0% | 0us | `erCardinalityPieces` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:113` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:387` |
| 0.0% | 1.3ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:167` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `isErKeywordName` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:326` |
| 0.0% | 1.3ms | 0.0% | 0us | `erLabelUnread` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1063` |
| 0.0% | 1.3ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:580` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `preparedInterTextBounds` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:704` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `writtenPolylineProjectionOf` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:194` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `uncertain` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `boxAt` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:168` |
| 0.0% | 1.3ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:157` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1213` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:605` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:244` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/YAMLMap.js:3` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:529` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/util.js:7` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:6` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:696` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `assignPorts` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:701` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `reorder` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:432` |
| 0.0% | 1.3ms | 0.0% | 0us | `erFrameInkPadding` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:767` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:335` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `paintPrimitiveSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:156` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:273` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `inRanges` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `isWideRange` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:128` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:18` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readErStatement` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:907` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:367` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `escapeDisplayAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:504` |
| 0.0% | 1.3ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:651` |
| 0.0% | 1.3ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1365` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:182` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1517` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:155` |
| 0.0% | 1.3ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:174` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parseInlineFormatting` | `/tmp/pr449-main-integration-20261029-762/src/shared/inline-format.ts:29` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1298` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:758` |
| 0.0% | 1.3ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:436` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:402` |
| 0.0% | 1.3ms | 0.0% | 0us | `internal:streams/end-of-stream` | `internal:streams/end-of-stream:17` |
| 0.0% | 1.3ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1389` |
| 0.0% | 1.3ms | 0.0% | 0us | `internal:streams/operators` | `internal:streams/operators:2` |
| 0.0% | 1.3ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:313` |
| 0.0% | 1.3ms | 0.0% | 0us | `displayText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:82` |
| 0.0% | 1.3ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:113` |
| 0.0% | 1.3ms | 0.0% | 0us | `from` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:707` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:665` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pathMoveCount` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:237` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:838` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `captureNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:100` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:315` |
| 0.0% | 1.3ms | 0.0% | 0us | `typedIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:75` |
| 0.0% | 1.3ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1490` |
| 0.0% | 1.3ms | 0.0% | 0us | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:13` |
| 0.0% | 1.3ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1527` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:167` |
| 0.0% | 1.3ms | 0.0% | 0us | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:435` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:452` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:60` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:384` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:284` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `xmlRange` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `safeCssPaint` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:129` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `emissionRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:76` |
| 0.0% | 1.3ms | 0.0% | 0us | `connector/subpaths/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:660` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1149` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:418` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:506` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` |
| 0.0% | 1.3ms | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:523` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:573` |
| 0.0% | 1.3ms | 0.0% | 0us | `internal:streams/destroy` | `internal:streams/destroy:2` |
| 0.0% | 1.3ms | 0.0% | 0us | `internal:errors` | `internal:errors:2` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `createPngOutputOptionFieldDescriptors` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:105` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:173` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:796` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:17` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/state/parse-core.ts:154` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:91` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:140` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:49` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `reorder` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:409` |
| 0.0% | 1.3ms | 0.0% | 0us | `graphicalBackendCapabilityClaims` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:249` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:122` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:851` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:258` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `ActualTextPaintWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:393` |
| 0.0% | 1.3ms | 0.0% | 0us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:258` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:751` |
| 0.0% | 1.3ms | 0.0% | 0us | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:400` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:11` |
| 0.0% | 1.3ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:307` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `assertBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:497` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `unsafeActiveCss` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `inspectSecurityTail` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:687` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `getCharWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:286` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `resolveLabelContent` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:58` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:299` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1498` |
| 0.0% | 1.2ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1582` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `element` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:476` |
| 0.0% | 1.2ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:676` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:5` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/default-backend.ts:5` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `freezeBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:470` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:115` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1490` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1380` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderResolvedMermaidSVG` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1488` |
| 0.0% | 1.2ms | 0.0% | 0us | `backendSupportsCapability` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1378` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:107` |
| 0.0% | 1.2ms | 0.0% | 0us | `connectorInlineLabelSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:781` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:197` |
| 0.0% | 1.2ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:829` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:111` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:528` |
| 0.0% | 1.2ms | 0.0% | 0us | `captureNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:98` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/lexer.js:84` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:81` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:656` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:317` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `nativePaintSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:201` |
| 0.0% | 1.2ms | 0.0% | 0us | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:442` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1391` |
| 0.0% | 1.2ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:436` |
| 0.0% | 1.2ms | 0.0% | 0us | `builtinFamilyConformanceReport` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1915` |
| 0.0% | 1.2ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1882` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1798` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:608` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `fieldJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:508` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:46` |
| 0.0% | 1.2ms | 0.0% | 0us | `styleSpecJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:608` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:208` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `transferSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:751` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:191` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `replaceField` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:835` |
| 0.0% | 1.2ms | 0.0% | 0us | `parseErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:810` |
| 0.0% | 1.2ms | 0.0% | 0us | `textTones` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:545` |
| 0.0% | 1.2ms | 0.0% | 0us | `legibleOnEvery` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:559` |
| 0.0% | 1.2ms | 0.0% | 0us | `deriveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:505` |
| 0.0% | 1.2ms | 0.0% | 0us | `scanAccessibilityDirectives` | `/tmp/pr449-main-integration-20261029-762/src/shared/accessibility-directives.ts:124` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `statementEndAt` | `/tmp/pr449-main-integration-20261029-762/src/shared/accessibility-directives.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:212` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1246` |
| 0.0% | 1.2ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:155` |
| 0.0% | 1.2ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:135` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:315` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `chargeInkSort` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:17` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `install` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:41` |
| 0.0% | 1.2ms | 0.0% | 0us | `setConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:59` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parseErRelationshipSyntax` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1075` |
| 0.0% | 1.2ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:291` |
| 0.0% | 1.2ms | 0.0% | 0us | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:626` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:251` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `indexedPlacedCollides` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:123` |
| 0.0% | 1.2ms | 0.0% | 0us | `normalizeMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:659` |
| 0.0% | 1.2ms | 0.0% | 0us | `collides` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:172` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:833` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `nativeAccessibilityEdits` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:673` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:8` |
| 0.0% | 1.2ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1221` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `canonicalErContacts` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:236` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `advanceAttrs` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:263` |
| 0.0% | 1.2ms | 0.0% | 0us | `relationshipPairKey` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:160` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `/[-#:[\]",\u0000-\u001f]/` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:120` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ownsParts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:424` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `withRenderStageObserver` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:146` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:206` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:609` |
| 0.0% | 1.2ms | 0.0% | 0us | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:59` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:698` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `serialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:199` |
| 0.0% | 1.2ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:601` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:123` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:390` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1037` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:5` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:136` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `Transform` | `internal:streams/transform:21` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `internal:streams/readable:525` |
| 0.0% | 1.2ms | 0.0% | 0us | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:33` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `imul` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 0us | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:278` |
| 0.0% | 1.2ms | 0.0% | 0us | `resolveCss` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:736` |
| 0.0% | 1.2ms | 0.0% | 0us | `mixHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:52` |
| 0.0% | 1.2ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:705` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `parseHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:25` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `transferNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:512` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:761` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:260` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:762` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `resolveRoleStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:240` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:363` |
| 0.0% | 1.2ms | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1656` |
| 0.0% | 1.2ms | 0.0% | 0us | `applyFamilyRequestNormalization` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1075` |
| 0.0% | 1.2ms | 0.0% | 0us | `assertFamilyGeometryOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:850` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `serializableOptionCandidate` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `safeCssToken` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:69` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:472` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:560` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1066` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:3` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/anchors.js:3` |
| 0.0% | 1.2ms | 0.0% | 0us | `applyReplacements` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:242` |
| 0.0% | 1.2ms | 0.0% | 0us | `Transform` | `internal:streams/transform:14` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Duplex` | `internal:streams/duplex` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:733` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1766` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorEndpointAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:443` |
| 0.0% | 1.2ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:600` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-scalar.js:6` |
| 0.0% | 1.2ms | 0.0% | 0us | `findIndex` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `graphicalBackendCapabilityClaims` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:267` |
| 0.0% | 1.2ms | 0.0% | 0us | `createSketchBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:547` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/hybrid-backend.ts:193` |
| 0.0% | 1.2ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:222` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:246` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateJsonConfigAdmission` | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:565` |
| 0.0% | 1.2ms | 0.0% | 0us | `renderOptionsAdmissionMessages` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:403` |
| 0.0% | 1.2ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1715` |
| 0.0% | 1.2ms | 0.0% | 0us | `connectorInlineLabelText` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:427` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:276` |
| 0.0% | 1.2ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:312` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:503` |
| 0.0% | 1.2ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:712` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:11` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `py` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:173` |
| 0.0% | 1.1ms | 0.0% | 0us | `preparedInterTextBounds` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:105` |
| 0.0% | 1.1ms | 0.0% | 0us | `preparedTextLineGeometry` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:136` |
| 0.0% | 1.1ms | 0.0% | 0us | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:235` |
| 0.0% | 1.1ms | 0.0% | 0us | `checkRect` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:229` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `/^(?:class\|data-[a-z][a-z0-9-]*\|role\|aria-[a-z]+\|tabindex\|pointer-events\|transform\|style)$/` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:43` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1802` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `createNativePaintEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:110` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:148` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:54` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `retainTextPaintPresence` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:79` |
| 0.0% | 1.1ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:204` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1759` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateRawThemeCss` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `replaceSvgRootStartTag` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:319` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:780` |
| 0.0% | 1.1ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:637` |
| 0.0% | 1.1ms | 0.0% | 0us | `geometryElements` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:66` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `serializeMarkerResource` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:141` |
| 0.0% | 1.1ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:191` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:269` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:654` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:200` |
| 0.0% | 1.1ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:585` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `value` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:128` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:58` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:734` |
| 0.0% | 1.1ms | 0.0% | 0us | `connectorProjectedField` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:486` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `visibleSketchProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:438` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `decodeWithTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:442` |
| 0.0% | 1.1ms | 0.0% | 0us | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:60` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:262` |
| 0.0% | 1.1ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:158` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:30` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:619` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:13` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/c4/parser.ts:27` |
| 0.0% | 1.1ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:754` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:287` |
| 0.0% | 1.1ms | 0.0% | 0us | `sceneValidationMode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1402` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1608` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `parseExtensionId` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:202` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:731` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `prepared` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:321` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `erLabelPillGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `renderRelationshipLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:537` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1700` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `collectNativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:164` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `/[-+]?(?:(?:\d+(?:\.\d*)?)\|(?:\.\d+))(?:[eE][-+]?\d+)?/y` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringify.js:6` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `decodeWithTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:456` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `consumePointBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:434` |
| 0.0% | 1.1ms | 0.0% | 0us | `SvgWriter` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:471` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `XmlLeafWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:298` |
| 0.0% | 1.1ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:426` |
| 0.0% | 1.1ms | 0.0% | 0us | `numericStrokeWidth` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:196` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1518` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1848` |
| 0.0% | 1.1ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:201` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `preventExtensions` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1045` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:335` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `createOwnedNativePaintRecorder` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `inspectPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:61` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/gantt/dependency-paint.ts:16` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:226` |
| 0.0% | 1.1ms | 0.0% | 0us | `mermaidFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:149` |
| 0.0% | 1.1ms | 0.0% | 0us | `normalizeMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:663` |
| 0.0% | 1.1ms | 0.0% | 0us | `stripMermaidDirectives` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:93` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:42` |
| 0.0% | 1.1ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:232` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:703` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1023` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:290` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `srgbToLinear` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:63` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `canonicalizeSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:168` |
| 0.0% | 1.1ms | 0.0% | 0us | `attachSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:495` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:4` |
| 0.0% | 1.1ms | 0.0% | 0us | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:25` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `apply` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `has` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:10` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:69` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:562` |
| 0.0% | 1.1ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:162` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isWhitespace` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:31` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:270` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `ownerOf` | `/tmp/pr449-main-integration-20261029-762/src/shared/subgraph-membership.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/er/creation.ts:115` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolvedColorValue` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:599` |
| 0.0% | 1.0ms | 0.0% | 0us | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:800` |
| 0.0% | 1.0ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:268` |
| 0.0% | 1.0ms | 0.0% | 0us | `erCommentColumnWidth` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:430` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:250` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:879` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:214` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `erCharge` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:204` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1519` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:4` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:10` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/directives.js:175` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:508` |
| 0.0% | 1.0ms | 0.0% | 0us | `textTransform` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts:242` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finiteString` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `layoutErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1109` |
| 0.0% | 1.0ms | 0.0% | 0us | `resolveRenderStyle` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts:289` |
| 0.0% | 1.0ms | 0.0% | 0us | `documentOpen` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:132` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `header` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `nativeOrEmulated` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:472` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:115` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `erCharge` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `intersects` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1216` |
| 0.0% | 1.0ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:636` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `ownFragment` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:107` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `connectorTerminalStrokeLosses` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1395` |
| 0.0% | 1.0ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:64` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `schemaRecord` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:465` |
| 0.0% | 1.0ms | 0.0% | 0us | `resolveRenderStyle` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts:304` |
| 0.0% | 1.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:10` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finiteString` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts:234` |
| 0.0% | 1.0ms | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:527` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:181` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:330` |
| 0.0% | 1.0ms | 0.0% | 0us | `rejectUnknownKeys` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:153` |
| 0.0% | 1.0ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:579` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `keys` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 0us | `renderDisplayRuns` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:152` |
| 0.0% | 1.0ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:180` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `graphemes` | `/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1636` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `checkArchitectureRenderOptionColors` | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1777` |
| 0.0% | 1.0ms | 0.0% | 0us | `xmlIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:24` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `xmlTokenAt` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:17` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:670` |
| 0.0% | 1.0ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:688` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:35` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:436` |
| 0.0% | 1.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:581` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `safeCssFontFamily` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-font.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:734` |
| 0.0% | 1.0ms | 0.0% | 0us | `emitGraphLayoutDecision` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:42` |
| 0.0% | 1.0ms | 0.0% | 0us | `runMeasuredGraphBackend` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:89` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `immutableDecision` | `/tmp/pr449-main-integration-20261029-762/src/layout/decision-evidence.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:735` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:674` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `renderDisplayRuns` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:148` |
| 0.0% | 1.0ms | 0.0% | 0us | `internal:fs/streams` | `internal:fs/streams:2` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:248` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts:308` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `expandSceneBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:35` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `cliRenderFormats` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `projectErPositioned` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:25` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:26` |
| 0.0% | 1.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:218` |
| 0.0% | 1.0ms | 0.0% | 0us | `paintedBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:525` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:417` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:606` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:56` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:796` |
| 0.0% | 1.0ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:194` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `emissionRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1040` |
| 0.0% | 1.0ms | 0.0% | 0us | `inertRectangleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:319` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:6` |
| 0.0% | 1.0ms | 0.0% | 0us | `rectangleInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:349` |
| 0.0% | 1.0ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:644` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `WriteStream` | `internal:fs/streams` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:616` |
| 0.0% | 1.0ms | 0.0% | 0us | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:57` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `/\sdata-from="([^"]*)"/` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `textPaints` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:169` |
| 0.0% | 1.0ms | 0.0% | 0us | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:196` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1241` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:14` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/util.js:8` |
| 0.0% | 1.0ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1576` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `snapshotIdentityRecord` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `snapshotFamilyIdentity` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1516` |
| 0.0% | 1.0ms | 0.0% | 0us | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:114` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:190` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:51` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:881` |
| 0.0% | 1.0ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:583` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:174` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:300` |
| 0.0% | 999us | 0.0% | 999us | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:15` |
| 0.0% | 999us | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:144` |
| 0.0% | 997us | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1718` |
| 0.0% | 997us | 0.0% | 997us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:241` |
| 0.0% | 994us | 0.0% | 994us | `optional` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:49` |
| 0.0% | 994us | 0.0% | 0us | `terminalEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:66` |
| 0.0% | 994us | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:139` |
| 0.0% | 994us | 0.0% | 0us | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1351` |
| 0.0% | 992us | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:218` |
| 0.0% | 991us | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:50` |
| 0.0% | 991us | 0.0% | 991us | `performIteration` | `[native code]` |
| 0.0% | 991us | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:48` |
| 0.0% | 990us | 0.0% | 990us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` |
| 0.0% | 989us | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:416` |
| 0.0% | 988us | 0.0% | 988us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:642` |
| 0.0% | 986us | 0.0% | 986us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 979us | 0.0% | 979us | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` |
| 0.0% | 979us | 0.0% | 979us | `xmlHasColon` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:85` |
| 0.0% | 979us | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:382` |
| 0.0% | 978us | 0.0% | 978us | `defineProperties` | `[native code]` |
| 0.0% | 978us | 0.0% | 0us | `tag` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:151` |
| 0.0% | 976us | 0.0% | 976us | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 974us | 0.0% | 0us | `sharedRenderOptionsJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:485` |
| 0.0% | 971us | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:314` |
| 0.0% | 971us | 0.0% | 0us | `relationAccessibility` | `/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:29` |
| 0.0% | 968us | 0.0% | 0us | `assertKnownConnectorFields` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:160` |
| 0.0% | 967us | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:209` |
| 0.0% | 966us | 0.0% | 0us | `verifyNoExternalRefs` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:701` |
| 0.0% | 966us | 0.0% | 0us | `inspectSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:673` |
| 0.0% | 966us | 0.0% | 0us | `deriveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:517` |
| 0.0% | 966us | 0.0% | 966us | `startTags` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:65` |
| 0.0% | 966us | 0.0% | 0us | `ensureContrast` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:120` |
| 0.0% | 966us | 0.0% | 966us | `mixedChannels` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.0% | 966us | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1049` |
| 0.0% | 964us | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:603` |
| 0.0% | 964us | 0.0% | 964us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 961us | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1052` |
| 0.0% | 960us | 0.0% | 960us | `erFrameInkPadding` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:768` |
| 0.0% | 943us | 0.0% | 943us | `nodeWorldBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |

## Function Details

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:7` | Self: 16.0% (563.0ms) | Total: 16.0% (563.0ms) | Samples: 1

**Called by:**
- `o` (1)

### `anonymous`
`[native code]` | Self: 7.5% (262.3ms) | Total: 13.5% (472.7ms) | Samples: 50

**Called by:**
- `require` (124)
- `node:zlib` (8)
- `internal:stream` (7)
- `node:stream` (7)
- `internal:streams/pipeline` (6)
- `internal:streams/compose` (6)
- `internal:streams/duplex` (4)
- `get WriteStream` (2)
- `internal:fs/streams` (1)
- `internal:streams/destroy` (1)
- `internal:errors` (1)
- `internal:streams/end-of-stream` (1)
- `node:fs` (1)
- `internal:streams/operators` (1)

**Calls:**
- `(anonymous)` (8)
- `(anonymous)` (8)
- `(anonymous)` (8)
- `(anonymous)` (8)
- `(anonymous)` (7)
- `node:stream` (7)
- `internal:stream` (7)
- `internal:streams/compose` (6)
- `internal:streams/pipeline` (6)
- `(anonymous)` (4)
- `internal:streams/duplex` (4)
- `(anonymous)` (4)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:streams/destroy` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:fs/streams` (1)
- `internal:errors` (1)
- `internal:streams/operators` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:streams/end-of-stream` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:fs/binding` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `gc`
`[native code]` | Self: 5.3% (187.2ms) | Total: 5.3% (187.2ms) | Samples: 109

**Called by:**
- `(module)` (95)
- `(module)` (14)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:510` | Self: 4.5% (159.7ms) | Total: 4.5% (159.7ms) | Samples: 3

**Called by:**
- `markerBoundsAt` (3)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts` | Self: 2.0% (70.2ms) | Total: 2.0% (70.2ms) | Samples: 1

**Called by:**
- `map` (1)

### `isBuiltinFamilyId`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1414` | Self: 1.9% (67.6ms) | Total: 1.9% (67.6ms) | Samples: 1

**Called by:**
- `validateDescriptor` (1)

### `decodeBase64`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:21` | Self: 1.7% (62.4ms) | Total: 1.7% (62.4ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `some`
`[native code]` | Self: 1.6% (56.3ms) | Total: 2.4% (85.8ms) | Samples: 3

**Called by:**
- `some` (8)
- `repairErFrameRoutes` (8)
- `nonPainting` (2)
- `filter` (1)
- `validateDescriptor` (1)
- `finishErGeometry` (1)
- `checkInertGroup` (1)
- `validateDescriptor` (1)

**Calls:**
- `some` (8)
- `segmentThroughShape` (5)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `segmentThroughShape` (1)

### `xmlAsciiLetter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` | Self: 1.4% (51.0ms) | Total: 1.4% (51.0ms) | Samples: 26

**Called by:**
- `xmlNameCharacter` (21)
- `readXmlNameEnd` (5)

### `stringify`
`[native code]` | Self: 1.3% (46.1ms) | Total: 1.9% (66.6ms) | Samples: 23

**Called by:**
- `consume` (16)
- `renderedSvgDigest` (5)
- `validateNode` (5)
- `prepareDisplayText` (2)
- `preparePixelText` (2)
- `(module)` (1)
- `validateNode` (1)
- `canonicalJson` (1)
- `validateNode` (1)

**Calls:**
- `get receipt` (11)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:170` | Self: 1.1% (41.9ms) | Total: 1.4% (49.8ms) | Samples: 26

**Called by:**
- `copyInner` (23)
- `leaf` (9)

**Calls:**
- `defineProperty` (6)

### `map`
`[native code]` | Self: 1.1% (40.2ms) | Total: 11.3% (398.0ms) | Samples: 27

**Called by:**
- `flatIntoArrayWithCallback` (24)
- `repairErFrameRoutes` (8)
- `prepareMarkerTerminals` (8)
- `cloneValue` (6)
- `tryParseCssColor` (6)
- `renderPreparedLine` (4)
- `transformSvgCssValues` (4)
- `connector` (3)
- `runBackendConformance` (3)
- `toHex` (3)
- `(anonymous)` (2)
- `snapshot` (2)
- `renderMultilineText` (2)
- `captureFields` (2)
- `projectErPositioned` (2)
- `prepareDisplayText` (2)
- `sanitizeDisplayLines` (2)
- `pointsBounds` (1)
- `repairErFrameRoutes` (1)
- `(anonymous)` (1)
- `text` (1)
- `writeSceneNode` (1)
- `validateSceneDocument` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `(module)` (1)
- `styleSpecJsonSchema` (1)
- `builtinFamilyConformanceReport` (1)
- `extractErLayout` (1)
- `(module)` (1)
- `parseErDiagram` (1)
- `layoutLayeredGraph` (1)
- `finishErGeometry` (1)
- `(module)` (1)
- `crowsFootMark` (1)
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)
- `deriveConnectorTerminalProjection` (1)
- `graphicalBackendCapabilityClaims` (1)
- `finishErGeometry` (1)
- `styledRunLayout` (1)
- `glyphBox` (1)
- `erCommentColumnWidth` (1)
- `renderMultilineText` (1)
- `projectErPositioned` (1)
- `terminalDepth` (1)
- `displayText` (1)
- `extractErLayout` (1)
- `renderPreparedLine` (1)

**Calls:**
- `(anonymous)` (20)
- `(anonymous)` (8)
- `(anonymous)` (7)
- `(anonymous)` (5)
- `(anonymous)` (4)
- `(anonymous)` (4)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `cloneValue` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `preparePixelText` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `assignChannelTracks` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `@lazy`
`[native code]` | Self: 1.0% (38.4ms) | Total: 1.0% (38.4ms) | Samples: 1

**Called by:**
- `internal:fs/binding` (1)

### `getOwnPropertyDescriptor`
`[native code]` | Self: 0.9% (32.6ms) | Total: 0.9% (32.6ms) | Samples: 21

**Called by:**
- `copyInner` (12)
- `deferredTerminalProjectionInput` (4)
- `group` (2)
- `captureNativeGroupEmission` (1)
- `copyInner` (1)
- `replaceField` (1)

### `has`
`[native code]` | Self: 0.8% (31.0ms) | Total: 0.8% (31.0ms) | Samples: 15

**Called by:**
- `validateAggregateReferences` (2)
- `hasOwned` (2)
- `verifyDocumentEnvelope` (2)
- `scanStartTags` (2)
- `rejectUnknownKeys` (1)
- `inspectOwnedSvgOnce` (1)
- `serializeSceneNode` (1)
- `inertRectangleRecord` (1)
- `transferRetainedPixelText` (1)
- `toneOnFill` (1)
- `drawNative` (1)

### `copyDataProperties`
`[native code]` | Self: 0.8% (29.1ms) | Total: 0.8% (29.1ms) | Samples: 17

**Called by:**
- `text` (2)
- `text` (2)
- `group` (2)
- `relationAccessibility` (1)
- `typedIdentity` (1)
- `connector` (1)
- `group` (1)
- `semanticIdentityForSvg` (1)
- `(anonymous)` (1)
- `renderEntityBox` (1)
- `erCardinalityPieces` (1)
- `connector` (1)
- `connector` (1)
- `shape` (1)

### `filter`
`[native code]` | Self: 0.7% (26.2ms) | Total: 1.1% (40.3ms) | Samples: 15

**Called by:**
- `repairErFrameRoutes` (9)
- `finishErGeometry` (5)
- `semanticIdentityForSvg` (4)
- `finishErGeometry` (2)
- `assignChannelTracks` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `backendSupportsCapability` (1)
- `freezeDescriptor` (1)

**Calls:**
- `(anonymous)` (5)
- `(anonymous)` (3)
- `some` (1)
- `(anonymous)` (1)

### `set`
`[native code]` | Self: 0.6% (23.2ms) | Total: 0.6% (23.2ms) | Samples: 11

**Called by:**
- `leaf` (3)
- `diagramColorVariables` (1)
- `writeShapeSvg` (1)
- `registerGroupEmission` (1)
- `parseEncodeTrie` (1)
- `serializeSceneNode` (1)
- `validateNode` (1)
- `diagramColorVariables` (1)
- `diagramColorVariables` (1)

### `consume`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:17` | Self: 0.6% (21.2ms) | Total: 0.6% (21.2ms) | Samples: 13

**Called by:**
- `(module)` (13)

### `freeze`
`[native code]` | Self: 0.6% (21.1ms) | Total: 0.6% (21.1ms) | Samples: 15

**Called by:**
- `group` (4)
- `geometryAttributes` (2)
- `finish` (2)
- `deepFreeze` (2)
- `parts` (1)
- `qualify` (1)
- `nativePaintAncestors` (1)
- `issue` (1)
- `registerBuiltInStyle` (1)

### `segmentThroughShape`
`/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:170` | Self: 0.6% (21.0ms) | Total: 0.6% (21.0ms) | Samples: 15

**Called by:**
- `finishErGeometry` (10)
- `some` (5)

### `cloneObject`
`[native code]` | Self: 0.5% (20.0ms) | Total: 0.5% (20.0ms) | Samples: 13

**Called by:**
- `(anonymous)` (7)
- `finishErGeometry` (5)
- `leaf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.5% (19.2ms) | Total: 0.5% (19.2ms) | Samples: 13

**Called by:**
- `map` (4)
- `filter` (3)
- `flatIntoArrayWithCallback` (3)
- `some` (1)
- `build` (1)
- `find` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:519` | Self: 0.5% (19.2ms) | Total: 0.5% (19.2ms) | Samples: 2

**Called by:**
- `writeShapeSvg` (2)

### `xmlSlice`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` | Self: 0.4% (17.4ms) | Total: 0.4% (17.4ms) | Samples: 11

**Called by:**
- `verifyDocumentEnvelope` (5)
- `verifyDocumentEnvelope` (5)
- `verifyDocumentEnvelope` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:407` | Self: 0.4% (17.2ms) | Total: 0.6% (24.2ms) | Samples: 10

**Called by:**
- `(anonymous)` (12)

**Calls:**
- `has` (2)

### `boundedUtf8ByteLength`
`/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` | Self: 0.4% (17.2ms) | Total: 0.6% (21.1ms) | Samples: 12

**Called by:**
- `write` (10)
- `serialization` (5)

**Calls:**
- `/[^\x00-\x7f]/` (3)

### `add`
`[native code]` | Self: 0.4% (15.6ms) | Total: 0.4% (15.6ms) | Samples: 7

**Called by:**
- `qualify` (2)
- `verifyDocumentEnvelope` (2)
- `validateNode` (1)
- `validateDescriptor` (1)
- `visit` (1)

### `every`
`[native code]` | Self: 0.4% (14.6ms) | Total: 0.4% (14.6ms) | Samples: 7

**Called by:**
- `finite` (3)
- `erCardinalityInk` (2)
- `transformedBounds` (1)
- `renderDisplayRuns` (1)

### `test`
`[native code]` | Self: 0.4% (14.6ms) | Total: 0.9% (32.8ms) | Samples: 11

**Called by:**
- `renderMultilineText` (2)
- `checkInertGroup` (2)
- `checkInertGroup` (2)
- `inspectAttributeSecurity` (1)
- `safeCssToken` (1)
- `group` (1)
- `pathBounds` (1)
- `inspectSecurityTail` (1)
- `isErKeywordName` (1)
- `pathBounds` (1)
- `relationshipPairKey` (1)
- `renderPreparedLine` (1)
- `copyInner` (1)

**Calls:**
- `/[^\x20-\x7e]/u` (2)
- `/<(?:[^\s<>/:]+:)?iframe\b/i` (1)
- `/[-#:[\]",\u0000-\u001f]/` (1)
- `/^\s*<g\b[^>]*>(?:<title>[^<]*<\/title>)?$/` (1)

### `sourceIndexOf`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` | Self: 0.4% (14.5ms) | Total: 0.4% (14.5ms) | Samples: 10

**Called by:**
- `scanTagEnd` (5)
- `scanStartTags` (3)
- `scanStartTags` (1)
- `scanTagEnd` (1)

### `issue`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:92` | Self: 0.4% (14.2ms) | Total: 0.4% (14.2ms) | Samples: 8

**Called by:**
- `writeTextSvg` (8)

### `join`
`[native code]` | Self: 0.3% (12.7ms) | Total: 0.3% (12.7ms) | Samples: 10

**Called by:**
- `serializeSceneNode` (3)
- `resolveSvgColors` (3)
- `group` (2)
- `tryParseCssColor` (1)
- `toHex` (1)

### `defineProperty`
`[native code]` | Self: 0.3% (12.6ms) | Total: 0.3% (12.6ms) | Samples: 10

**Called by:**
- `copyInner` (6)
- `replaceField` (1)
- `append` (1)
- `value` (1)
- `geometryAttributes` (1)

### `get`
`[native code]` | Self: 0.3% (12.4ms) | Total: 0.3% (12.4ms) | Samples: 8

**Called by:**
- `validateNode` (2)
- `(anonymous)` (2)
- `finishErGeometry` (1)
- `(anonymous)` (1)
- `lowerErDrawing` (1)
- `(anonymous)` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:109` | Self: 0.3% (11.8ms) | Total: 0.3% (13.0ms) | Samples: 9

**Called by:**
- `leaf` (7)
- `snapshot` (3)

**Calls:**
- `pay` (1)

### `xmlRange`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:48` | Self: 0.3% (11.6ms) | Total: 0.3% (11.6ms) | Samples: 9

**Called by:**
- `writeTextSvg` (9)

### `indent`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` | Self: 0.3% (10.7ms) | Total: 0.3% (10.7ms) | Samples: 9

**Called by:**
- `(anonymous)` (9)

### `/^\s*<g\b[^>]*>(?:<title>[^<]*<\/title>)?$/`
`[native code]` | Self: 0.3% (10.5ms) | Total: 0.3% (10.5ms) | Samples: 1

**Called by:**
- `test` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:485` | Self: 0.2% (10.4ms) | Total: 0.2% (10.4ms) | Samples: 5

**Called by:**
- `paintAttribute` (5)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:420` | Self: 0.2% (9.9ms) | Total: 0.5% (19.2ms) | Samples: 4

**Called by:**
- `(anonymous)` (10)

**Calls:**
- `readXmlDataEnd` (3)
- `readXmlDataEnd` (3)

### `writeSync`
`[native code]` | Self: 0.2% (9.6ms) | Total: 0.2% (9.6ms) | Samples: 5

**Called by:**
- `processChunkSync` (5)

### `positiveNumber`
`/tmp/pr449-main-integration-20261029-762/src/styles.ts:216` | Self: 0.2% (9.5ms) | Total: 0.2% (9.5ms) | Samples: 1

**Called by:**
- `resolveRenderStyle` (1)

### `arrayIteratorNextHelper`
`[native code]` | Self: 0.2% (9.3ms) | Total: 0.2% (9.3ms) | Samples: 3

**Called by:**
- `next` (3)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:228` | Self: 0.2% (9.2ms) | Total: 1.4% (52.4ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (28)

**Calls:**
- `leaf` (22)
- `shape` (4)
- `leaf` (1)

### `isFrozen`
`[native code]` | Self: 0.2% (8.5ms) | Total: 0.2% (8.5ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (2)

### `canonicalTextDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1171` | Self: 0.2% (8.5ms) | Total: 0.2% (8.5ms) | Samples: 5

**Called by:**
- `(anonymous)` (5)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:96` | Self: 0.2% (8.4ms) | Total: 0.2% (8.4ms) | Samples: 6

**Called by:**
- `materializeText` (5)
- `copyInner` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:162` | Self: 0.2% (8.3ms) | Total: 0.2% (9.4ms) | Samples: 7

**Called by:**
- `paintedStrokeExtent` (3)
- `relativeLuminance` (3)
- `compositeCssColor` (2)

**Calls:**
- `hasOwn` (1)

### `lazyGraphicalArtifact`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:344` | Self: 0.2% (8.3ms) | Total: 0.2% (8.3ms) | Samples: 1

**Called by:**
- `withSvgInspectionCache` (1)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:20` | Self: 0.2% (7.9ms) | Total: 0.2% (7.9ms) | Samples: 6

**Called by:**
- `renderMultilineText` (5)
- `(anonymous)` (1)

### `ownerSnapshot`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.2% (7.9ms) | Total: 0.2% (7.9ms) | Samples: 3

**Called by:**
- `nativePaintAncestors` (3)

### `node`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1447` | Self: 0.2% (7.6ms) | Total: 0.2% (7.6ms) | Samples: 2

**Called by:**
- `group` (2)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1801` | Self: 0.2% (7.5ms) | Total: 0.2% (7.5ms) | Samples: 2

**Called by:**
- `positionedPaintCertification` (2)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:203` | Self: 0.2% (7.4ms) | Total: 0.2% (7.4ms) | Samples: 2

**Called by:**
- `paintBounds` (2)

### `importModule`
`[native code]` | Self: 0.2% (7.4ms) | Total: 0.2% (7.4ms) | Samples: 2

**Called by:**
- `(module)` (1)
- `(module)` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` | Self: 0.2% (7.4ms) | Total: 0.2% (7.4ms) | Samples: 3

**Called by:**
- `validateNodeSerialization` (3)

### `find`
`[native code]` | Self: 0.2% (7.2ms) | Total: 0.3% (11.4ms) | Samples: 5

**Called by:**
- `resolveRoleStyle` (5)
- `finishErGeometry` (2)
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `boundedUtf8ByteLength`
`/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` | Self: 0.2% (7.2ms) | Total: 0.2% (7.2ms) | Samples: 5

**Called by:**
- `serialization` (3)
- `consumeStringBudget` (1)
- `write` (1)

### `RegExp`
`[native code]` | Self: 0.1% (6.9ms) | Total: 0.1% (6.9ms) | Samples: 5

**Called by:**
- `set` (2)
- `mermaidInitDirectives` (1)
- `attr` (1)
- `(module)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:295` | Self: 0.1% (6.9ms) | Total: 0.1% (6.9ms) | Samples: 5

**Called by:**
- `filter` (5)

### `Segmenter`
`[native code]` | Self: 0.1% (6.7ms) | Total: 0.1% (6.7ms) | Samples: 2

**Called by:**
- `(module)` (2)

### `inertRectangleRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:316` | Self: 0.1% (6.6ms) | Total: 0.1% (6.6ms) | Samples: 3

**Called by:**
- `(anonymous)` (2)
- `leaf` (1)

### `Set`
`[native code]` | Self: 0.1% (6.3ms) | Total: 0.4% (17.0ms) | Samples: 5

**Called by:**
- `resolveRoleStyle` (6)
- `(anonymous)` (1)
- `validateDescriptor` (1)
- `(module)` (1)

**Calls:**
- `next` (4)

### `segmentThroughShape`
`/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:205` | Self: 0.1% (6.3ms) | Total: 0.1% (6.3ms) | Samples: 1

**Called by:**
- `finishErGeometry` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:161` | Self: 0.1% (6.2ms) | Total: 10.6% (372.0ms) | Samples: 5

**Called by:**
- `copyInner` (163)
- `leaf` (76)
- `copy` (13)
- `snapshot` (2)

**Calls:**
- `copyInner` (163)
- `copyInner` (23)
- `copy` (14)
- `copyInner` (12)
- `materializeText` (7)
- `copyInner` (4)
- `copyInner` (4)
- `copyInner` (3)
- `copy` (2)
- `copyInner` (2)
- `copy` (2)
- `copyInner` (2)
- `copyInner` (2)
- `copy` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `materializeText` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)

### `slice`
`[native code]` | Self: 0.1% (5.8ms) | Total: 0.1% (5.8ms) | Samples: 4

**Called by:**
- `(anonymous)` (1)
- `build` (1)
- `replaceSvgRootStartTag` (1)
- `applyReplacements` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:66` | Self: 0.1% (5.8ms) | Total: 0.1% (5.8ms) | Samples: 3

**Called by:**
- `visit` (3)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:95` | Self: 0.1% (5.7ms) | Total: 0.1% (5.7ms) | Samples: 2

**Called by:**
- `shape` (2)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:176` | Self: 0.1% (5.6ms) | Total: 0.1% (5.6ms) | Samples: 1

**Called by:**
- `projectSvgCss` (1)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.1% (5.5ms) | Total: 0.1% (5.5ms) | Samples: 4

**Called by:**
- `validateGeometry` (2)
- `validateNode` (1)
- `validatePoint` (1)

### `escapeAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` | Self: 0.1% (5.3ms) | Total: 0.1% (5.3ms) | Samples: 3

**Called by:**
- `attribute` (2)
- `set` (1)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.1% (5.2ms) | Total: 0.1% (5.2ms) | Samples: 4

**Called by:**
- `geometryBounds` (1)
- `markerBoundsAt` (1)
- `lineStrokeBox` (1)
- `paintBounds` (1)

### `xmlScalarCharacter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:88` | Self: 0.1% (5.2ms) | Total: 0.1% (5.2ms) | Samples: 3

**Called by:**
- `readXmlDataEnd` (3)

### `append`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:239` | Self: 0.1% (5.1ms) | Total: 0.1% (6.0ms) | Samples: 4

**Called by:**
- `leaf` (5)

**Calls:**
- `defineProperty` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:173` | Self: 0.1% (5.1ms) | Total: 0.2% (7.3ms) | Samples: 3

**Called by:**
- `paintedStrokeExtent` (3)
- `compositeCssColor` (1)

**Calls:**
- `parseInt` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1462` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 3

**Called by:**
- `serialize` (3)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 4

**Called by:**
- `validateSceneDocument` (4)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1456` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:156` | Self: 0.1% (4.8ms) | Total: 0.2% (9.7ms) | Samples: 4

**Called by:**
- `projectSvgCss` (8)

**Calls:**
- `isAsciiXmlNameChar` (3)
- `isAsciiXmlNameChar` (1)

### `deferredTerminalProjectionInput`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 4

**Called by:**
- `copyInner` (4)

### `collectPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1374` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 3

**Called by:**
- `localPaintResourceReferences` (3)

### `issue`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:93` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 3

**Called by:**
- `serializeSceneNode` (2)
- `writeTextSvg` (1)

### `snapshotBoundedExternalData`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 1

**Called by:**
- `admitSceneDocumentWith` (1)

### `compare`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:33` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 2

**Called by:**
- `chargeInkSort` (2)

### `/[^\x20-\x7e]/u`
`[native code]` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 2

**Called by:**
- `test` (2)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:173` | Self: 0.1% (4.6ms) | Total: 0.2% (7.0ms) | Samples: 3

**Called by:**
- `projectSvgCss` (5)

**Calls:**
- `has` (2)

### `crowsFootMark`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:618` | Self: 0.1% (4.6ms) | Total: 0.1% (4.6ms) | Samples: 1

**Called by:**
- `renderCardinality` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:179` | Self: 0.1% (4.6ms) | Total: 0.1% (4.6ms) | Samples: 1

**Called by:**
- `map` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.1% (4.6ms) | Total: 0.1% (4.6ms) | Samples: 3

**Called by:**
- `positionedPaintCertification` (3)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` | Self: 0.1% (4.5ms) | Total: 0.1% (4.5ms) | Samples: 2

**Called by:**
- `erCardinalityInk` (2)

### `segmentThroughShape`
`/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts` | Self: 0.1% (4.5ms) | Total: 0.1% (4.5ms) | Samples: 4

**Called by:**
- `finishErGeometry` (4)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1091` | Self: 0.1% (4.4ms) | Total: 0.1% (4.4ms) | Samples: 3

**Called by:**
- `write` (3)

### `hasOwn`
`[native code]` | Self: 0.1% (4.4ms) | Total: 0.1% (4.4ms) | Samples: 4

**Called by:**
- `validateNode` (1)
- `assertKnownConnectorFields` (1)
- `copyInner` (1)
- `tryParseCssColor` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:122` | Self: 0.1% (4.4ms) | Total: 0.2% (8.5ms) | Samples: 1

**Called by:**
- `projectSvgCss` (3)
- `visitSvgFirstTagAttributes` (1)

**Calls:**
- `sourceIndexOf` (3)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:413` | Self: 0.1% (4.4ms) | Total: 0.1% (4.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:163` | Self: 0.1% (4.3ms) | Total: 0.1% (4.3ms) | Samples: 3

**Called by:**
- `projectSvgCss` (3)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1491` | Self: 0.1% (4.3ms) | Total: 0.9% (34.1ms) | Samples: 3

**Called by:**
- `nativeCandidate` (23)

**Calls:**
- `segmentThroughShape` (10)
- `cloneObject` (5)
- `segmentThroughShape` (4)
- `segmentThroughShape` (1)

### `flatIntoArray`
`[native code]` | Self: 0.1% (4.3ms) | Total: 0.1% (4.3ms) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:116` | Self: 0.1% (4.3ms) | Total: 0.1% (4.3ms) | Samples: 3

**Called by:**
- `shape` (3)

### `xmlNameCharacter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:87` | Self: 0.1% (4.2ms) | Total: 1.3% (47.4ms) | Samples: 1

**Called by:**
- `readXmlNameEnd` (22)

**Calls:**
- `xmlAsciiLetter` (21)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.1% (4.2ms) | Total: 0.1% (4.2ms) | Samples: 3

**Called by:**
- `copyInner` (1)
- `copyInner` (1)
- `materializeText` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:171` | Self: 0.1% (4.2ms) | Total: 0.3% (13.4ms) | Samples: 2

**Called by:**
- `paintedStrokeExtent` (9)

**Calls:**
- `map` (6)
- `join` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:681` | Self: 0.1% (4.2ms) | Total: 0.1% (4.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `localPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.1% (4.2ms) | Total: 0.1% (4.2ms) | Samples: 3

**Called by:**
- `validateNode` (3)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` | Self: 0.1% (4.1ms) | Total: 0.1% (4.1ms) | Samples: 3

**Called by:**
- `preparedTextLineGeometry` (1)
- `advanceAttrs` (1)
- `renderMultilineText` (1)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` | Self: 0.1% (4.1ms) | Total: 0.1% (4.1ms) | Samples: 1

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

### `Buffer`
`[native code]` | Self: 0.1% (4.1ms) | Total: 0.1% (4.1ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:533` | Self: 0.1% (4.0ms) | Total: 0.1% (4.0ms) | Samples: 3

**Called by:**
- `write` (3)

### `push`
`[native code]` | Self: 0.1% (4.0ms) | Total: 0.1% (4.0ms) | Samples: 3

**Called by:**
- `group` (1)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)

### `ownFragment`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:116` | Self: 0.1% (4.0ms) | Total: 0.1% (4.0ms) | Samples: 3

**Called by:**
- `renderEntityBox` (2)
- `lowerErDrawing` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:235` | Self: 0.1% (4.0ms) | Total: 0.1% (4.0ms) | Samples: 3

**Called by:**
- `verifyDocumentEnvelope` (3)

### `charge`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.1% (4.0ms) | Total: 0.1% (4.0ms) | Samples: 2

**Called by:**
- `finishErGeometry` (1)
- `finishErGeometry` (1)

### `validateChannels`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:580` | Self: 0.1% (4.0ms) | Total: 0.1% (4.0ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.1% (4.0ms) | Total: 0.1% (4.0ms) | Samples: 2

**Called by:**
- `leaf` (2)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:711` | Self: 0.1% (3.9ms) | Total: 0.1% (6.6ms) | Samples: 3

**Called by:**
- `serializeSceneNode` (5)

**Calls:**
- `SvgWriter` (1)
- `SvgWriter` (1)

### `consume`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` | Self: 0.1% (3.9ms) | Total: 0.1% (3.9ms) | Samples: 2

**Called by:**
- `(module)` (2)

### `/[^\x00-\x7f]/`
`[native code]` | Self: 0.1% (3.9ms) | Total: 0.1% (3.9ms) | Samples: 3

**Called by:**
- `boundedUtf8ByteLength` (3)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:643` | Self: 0.1% (3.9ms) | Total: 0.1% (3.9ms) | Samples: 3

**Called by:**
- `(anonymous)` (3)

### `assign`
`[native code]` | Self: 0.1% (3.9ms) | Total: 0.1% (3.9ms) | Samples: 3

**Called by:**
- `leaf` (3)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` | Self: 0.1% (3.9ms) | Total: 0.1% (3.9ms) | Samples: 1

**Called by:**
- `captureNativeGroupParse` (1)

### `isAsciiXmlNameChar`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` | Self: 0.1% (3.8ms) | Total: 0.1% (3.8ms) | Samples: 3

**Called by:**
- `scanStartTags` (3)

### `localPaintResourceId`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:373` | Self: 0.1% (3.8ms) | Total: 0.1% (3.8ms) | Samples: 2

**Called by:**
- `localPaintResourceReferences` (1)
- `collectPaintResourceReferences` (1)

### `sceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` | Self: 0.1% (3.8ms) | Total: 0.1% (3.8ms) | Samples: 1

**Called by:**
- `hasDomSvgIdentityRole` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:67` | Self: 0.1% (3.7ms) | Total: 0.1% (3.7ms) | Samples: 3

**Called by:**
- `visit` (2)
- `inspectPaint` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:461` | Self: 0.1% (3.7ms) | Total: 0.1% (3.7ms) | Samples: 2

**Called by:**
- `connector` (2)

### `inverseMatrix`
`/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:23` | Self: 0.1% (3.7ms) | Total: 0.1% (3.7ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `boundedString`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:268` | Self: 0.1% (3.7ms) | Total: 0.1% (5.2ms) | Samples: 3

**Called by:**
- `validateNode` (2)
- `validateNode` (1)
- `validateChannels` (1)

**Calls:**
- `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:176` | Self: 0.1% (3.7ms) | Total: 0.1% (3.7ms) | Samples: 3

**Called by:**
- `relativeLuminance` (2)
- `paintedStrokeExtent` (1)

### `record`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.1% (3.7ms) | Total: 0.1% (3.7ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `includes`
`[native code]` | Self: 0.1% (3.6ms) | Total: 0.1% (3.6ms) | Samples: 2

**Called by:**
- `canonicalizeSceneNodeSerialization` (1)
- `validateNode` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:639` | Self: 0.1% (3.6ms) | Total: 5.1% (179.8ms) | Samples: 3

**Called by:**
- `leaf` (109)

**Calls:**
- `serialize` (106)

### `replace`
`[native code]` | Self: 0.1% (3.6ms) | Total: 0.1% (6.0ms) | Samples: 3

**Called by:**
- `formatSvgNumericAttribute` (2)
- `normalizeCssObfuscation` (1)
- `resolveCss` (1)
- `stripMermaidDirectives` (1)

**Calls:**
- `mixHex` (1)
- `(anonymous)` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:304` | Self: 0.1% (3.6ms) | Total: 0.1% (3.6ms) | Samples: 2

**Called by:**
- `attribute` (2)

### `transferRetainedPixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:88` | Self: 0.1% (3.6ms) | Total: 0.1% (6.3ms) | Samples: 2

**Called by:**
- `copyInner` (3)

**Calls:**
- `has` (1)

### `isWhitespace`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` | Self: 0.1% (3.6ms) | Total: 0.1% (3.6ms) | Samples: 2

**Called by:**
- `scanStartTags` (2)

### `nodeWorldBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:460` | Self: 0.1% (3.6ms) | Total: 0.1% (3.6ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `hasSceneWriteEmissionOccurrence`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.1% (3.5ms) | Total: 0.1% (3.5ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `values`
`[native code]` | Self: 0.1% (3.5ms) | Total: 0.1% (3.5ms) | Samples: 3

**Called by:**
- `erCardinalityInk` (3)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:113` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 2

**Called by:**
- `shape` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:844` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 3

**Called by:**
- `write` (3)

### `inRanges`
`/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:114` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 2

**Called by:**
- `isWideRange` (1)
- `isZeroWidth` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:40` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 3

**Called by:**
- `scanStartTags` (3)

### `topRoundedRectPath`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:844` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 1

**Called by:**
- `renderEntityBox` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:193` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 2

**Called by:**
- `copyInner` (2)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 3

**Called by:**
- `layoutLayeredGraph` (3)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:662` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:297` | Self: 0.0% (3.3ms) | Total: 0.4% (16.4ms) | Samples: 1

**Called by:**
- `map` (8)

**Calls:**
- `cloneObject` (7)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:481` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `validateNode` (1)
- `validateGeometry` (1)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:87` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `ensureSvgIdentity` (2)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 1

**Called by:**
- `markerBoundsAt` (1)

### `trim`
`[native code]` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `validateDescriptor` (1)
- `tryParseCssColor` (1)

### `sort`
`[native code]` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 2

**Called by:**
- `applyReplacements` (2)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 2

**Called by:**
- `connector` (2)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:336` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `inertRectangleRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:309` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:800` | Self: 0.0% (3.1ms) | Total: 0.2% (8.8ms) | Samples: 2

**Called by:**
- `write` (5)
- `node` (1)

**Calls:**
- `validateMarkAttributes` (2)
- `validateMarkAttributes` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 2

**Called by:**
- `snapshotDescriptorArray` (1)
- `some` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:501` | Self: 0.0% (3.0ms) | Total: 0.1% (4.5ms) | Samples: 2

**Called by:**
- `text` (3)

**Calls:**
- `assertMarkAttributes` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:776` | Self: 0.0% (3.0ms) | Total: 0.1% (6.6ms) | Samples: 2

**Called by:**
- `write` (3)

**Calls:**
- `stringify` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 2

**Called by:**
- `copyInner` (1)
- `leaf` (1)

### `writeStructuredSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:594` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:147` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `withDeferredTerminalProjections` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:271` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 2

**Called by:**
- `writeTextSvg` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:590` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `min`
`[native code]` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 2

**Called by:**
- `segmentThroughShape` (1)
- `validateNode` (1)

### `ArrayBuffer`
`[native code]` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `node:zlib` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2361` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:845` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 2

**Called by:**
- `write` (2)

### `nonPainting`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:134` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 2

**Called by:**
- `leaf` (2)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:36` | Self: 0.0% (2.9ms) | Total: 0.1% (5.7ms) | Samples: 1

**Called by:**
- `group` (3)

**Calls:**
- `test` (2)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:685` | Self: 0.0% (2.9ms) | Total: 0.2% (7.9ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (4)

**Calls:**
- `identityAttributes` (2)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:207` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `geometryBounds` (1)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` | Self: 0.0% (2.8ms) | Total: 0.3% (11.7ms) | Samples: 2

**Called by:**
- `scanStartTags` (8)

**Calls:**
- `sourceIndexOf` (5)
- `xmlIndexOf` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:106` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 2

**Called by:**
- `copyInner` (2)

### `parseErRelationshipSyntax`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `readErStatement` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:207` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `renderRelationshipLine`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:443` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `lowerErDrawing` (2)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:283` | Self: 0.0% (2.7ms) | Total: 2.7% (96.0ms) | Samples: 2

**Called by:**
- `lowerErDrawing` (63)

**Calls:**
- `leaf` (56)
- `text` (3)
- `ownFragment` (2)

### `skipSeparators`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:168` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `svgPathDataProblem` (1)
- `svgPathDataProblem` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:214` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `copyInner` (2)

### `isSupportedSemVerRange`
`/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `evaluateExtensionCompatibility` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:327` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `map` (1)
- `measureErEntities` (1)

### `localPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1395` | Self: 0.0% (2.7ms) | Total: 0.2% (9.6ms) | Samples: 2

**Called by:**
- `validateNode` (6)

**Calls:**
- `collectPaintResourceReferences` (3)
- `collectPaintResourceReferences` (1)

### `flatMap`
`[native code]` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:128` | Self: 0.0% (2.7ms) | Total: 0.1% (6.1ms) | Samples: 2

**Called by:**
- `copyInner` (4)
- `leaf` (1)

**Calls:**
- `pay` (2)
- `pay` (1)

### `readXmlNameEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:104` | Self: 0.0% (2.7ms) | Total: 1.4% (50.2ms) | Samples: 2

**Called by:**
- `verifyDocumentEnvelope` (22)
- `verifyDocumentEnvelope` (2)

**Calls:**
- `xmlNameCharacter` (22)

### `overlaps`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:56` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `visit` (2)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:154` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `lowerErDrawing` (1)
- `renderCardinality` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `renderMultilineText` (2)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:663` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (2)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` | Self: 0.0% (2.6ms) | Total: 0.2% (10.2ms) | Samples: 2

**Called by:**
- `leaf` (7)

**Calls:**
- `nonPainting` (3)
- `nonPainting` (2)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `certifyNativePaint` (2)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:130` | Self: 0.0% (2.6ms) | Total: 0.6% (22.6ms) | Samples: 2

**Called by:**
- `copyInner` (12)
- `leaf` (2)

**Calls:**
- `getOwnPropertyDescriptor` (12)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` | Self: 0.0% (2.6ms) | Total: 0.3% (13.1ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (11)

**Calls:**
- `geometryAttributes` (6)
- `geometryAttributes` (2)
- `geometryAttributes` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:778` | Self: 0.0% (2.6ms) | Total: 0.2% (9.5ms) | Samples: 2

**Called by:**
- `write` (5)

**Calls:**
- `validateChannels` (2)
- `validateChannels` (1)

### `entries`
`[native code]` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `validateMarkAttributes` (2)

### `appendPrivate`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:55` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `group` (2)

### `consumeStringBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:406` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `write` (2)

### `Number`
`[native code]` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 2

**Called by:**
- `(anonymous)` (1)
- `numericCss` (1)

### `nativePaintAncestors`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 2

**Called by:**
- `visit` (2)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `admitSceneDocumentWith` (1)

### `box`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:59` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `label` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 2

**Called by:**
- `map` (1)
- `findIndex` (1)

### `split`
`[native code]` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 2

**Called by:**
- `semanticIdentityForSvg` (2)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` | Self: 0.0% (2.5ms) | Total: 0.1% (3.7ms) | Samples: 1

**Called by:**
- `compositeCssColor` (1)
- `relativeLuminance` (1)

**Calls:**
- `trim` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `map` (1)
- `from` (1)

### `erCardinalityPieces`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:110` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `erCardinalityInk` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:114` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `copyInner` (2)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `expectedCapabilityState`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1641` | Self: 0.0% (2.4ms) | Total: 0.1% (4.5ms) | Samples: 1

**Called by:**
- `validateDescriptor` (2)

**Calls:**
- `hasPublicVerificationProjection` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `join` (1)
- `serialize` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:894` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `write` (1)
- `node` (1)

### `chargeInkSort`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:7` | Self: 0.0% (2.4ms) | Total: 0.2% (9.9ms) | Samples: 2

**Called by:**
- `build` (5)
- `chargeInkSort` (1)

**Calls:**
- `compare` (2)
- `compare` (1)
- `charge` (1)

### `erCardinalityInk`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:125` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `erCardinalityEnvelope` (2)

### `completeBuiltinDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1374` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:638` | Self: 0.0% (2.3ms) | Total: 4.2% (149.9ms) | Samples: 2

**Called by:**
- `leaf` (101)

**Calls:**
- `copyInner` (76)
- `copyInner` (9)
- `copyInner` (7)
- `copyInner` (2)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copy` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 2

**Called by:**
- `validateMarker` (1)
- `validateNode` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:552` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:440` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 2

**Called by:**
- `connector` (2)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1516` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `nativeCandidate` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:117` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `shape` (1)

### `Transform`
`internal:streams/transform` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `ZlibBase` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 2

**Called by:**
- `visit` (1)
- `leaf` (1)

### `recordAdmittedScene`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-admission-state.ts` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `admitSceneDocumentWith` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/flowchart-lexer.ts` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `map` (1)

### `compositeCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:275` | Self: 0.0% (2.2ms) | Total: 0.2% (8.2ms) | Samples: 2

**Called by:**
- `toneOnFill` (6)

**Calls:**
- `tryParseCssColor` (2)
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)

### `snapshotScenePrimitiveCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1541` | Self: 0.0% (2.2ms) | Total: 0.1% (4.9ms) | Samples: 2

**Called by:**
- `snapshotDescriptorArray` (4)

**Calls:**
- `captureFields` (2)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:275` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 2

**Called by:**
- `connector` (2)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:51` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 2

**Called by:**
- `copyInner` (2)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:581` | Self: 0.0% (2.2ms) | Total: 0.3% (12.1ms) | Samples: 2

**Called by:**
- `write` (4)
- `drawn` (1)

**Calls:**
- `isFrozen` (2)
- `set` (1)

### `serialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1499` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `serialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1500` | Self: 0.0% (2.2ms) | Total: 0.3% (12.6ms) | Samples: 1

**Called by:**
- `group` (9)

**Calls:**
- `boundedUtf8ByteLength` (5)
- `boundedUtf8ByteLength` (3)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:145` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 2

**Called by:**
- `visitSvgFirstTagAttributes` (1)
- `svgStyleRanges` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:488` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `writeConnectorSvg` (1)

### `parseInt`
`[native code]` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `tryParseCssColor` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:331` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 2

**Called by:**
- `map` (2)

### `node`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1452` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 2

**Called by:**
- `group` (2)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:303` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `f`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/geometry.ts:16` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 2

**Called by:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:224` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 2

**Called by:**
- `withTextMeasurementExecution` (2)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:311` | Self: 0.0% (2.1ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `validateNode` (2)

**Calls:**
- `safeCssPaint` (1)

### `finiteRect`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:159` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 2

**Called by:**
- `assessFamilyLayout` (1)
- `checkRect` (1)

### `init`
`[native code]` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `Zlib` (1)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:660` | Self: 0.0% (2.1ms) | Total: 0.1% (3.9ms) | Samples: 1

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `test` (1)

### `terminalDepth`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `finishErGeometry` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:150` | Self: 0.0% (2.1ms) | Total: 0.0% (3.3ms) | Samples: 2

**Called by:**
- `lowerErDrawing` (1)
- `renderCardinality` (1)
- `renderCardinality` (1)

**Calls:**
- `(anonymous)` (1)

### `getOwnPropertyNames`
`[native code]` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `replaceField` (1)

### `parseFloat`
`[native code]` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 2

**Called by:**
- `numericStrokeWidth` (1)
- `renderEntityBox` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1664` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `toPrecision`
`[native code]` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 2

**Called by:**
- `formatSvgNumber` (2)

### `hasPublicLayoutProjection`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `hasPublicVerificationProjection` (1)

### `ownedTextPaintRoster`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `finish` (1)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `connectorMarkerPaintRegions`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:355` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:356` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:824` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `indentLines`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:744` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `group` (1)

### `terminalDepth`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1251` | Self: 0.0% (1.8ms) | Total: 0.1% (4.3ms) | Samples: 1

**Called by:**
- `finishErGeometry` (1)
- `finishErGeometry` (1)

**Calls:**
- `map` (1)

### `xmlSlice`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1356` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `find` (1)

### `shortenMeasuredRoutes`
`/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:214` | Self: 0.0% (1.8ms) | Total: 0.1% (5.4ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (4)

**Calls:**
- `connector` (1)
- `connector` (1)
- `connector` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:708` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:841` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `write` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:254` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:410` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `group` (1)

### `pushTickAt`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:55` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `erCardinalityPieces` (1)

### `skipSpace`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:667` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `findErStatements` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:118` | Self: 0.0% (1.7ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `copyInner` (1)
- `leaf` (1)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `sceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` | Self: 0.0% (1.7ms) | Total: 0.1% (5.6ms) | Samples: 1

**Called by:**
- `relationAccessibility` (2)
- `hasDomSvgIdentityRole` (2)

**Calls:**
- `resolveSceneRoleTraits` (1)
- `resolveSceneRoleTraits` (1)
- `resolveSceneRoleTraits` (1)

### `admitWritableSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:501` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `shape` (1)

### `validateRole`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:150` | Self: 0.0% (1.6ms) | Total: 1.5% (53.7ms) | Samples: 1

**Called by:**
- `withDeferredTerminalProjections` (36)

**Calls:**
- `renderRelationshipLabel` (25)
- `renderRelationshipLabel` (7)
- `renderRelationshipLabel` (2)
- `renderRelationshipLabel` (1)

### `renderCardinality`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `/<(?:[^\s<>/:]+:)?iframe\b/i`
`[native code]` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `test` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Scalar.js:8` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `installedFamilyStatementEnds`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `normalizeSource` (1)

### `capturedRequestFamily`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `compare`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `chargeInkSort` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/generated-identity.ts:7` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:848` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `write` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:582` | Self: 0.0% (1.6ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `resolvedColorValue` (2)

**Calls:**
- `set` (1)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:700` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:670` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:118` | Self: 0.0% (1.6ms) | Total: 16.3% (570.8ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (106)
- `renderEntityBox` (72)
- `renderEntityBox` (56)
- `renderEntityBox` (41)
- `crowsFootMark` (30)
- `renderRelationshipLabel` (23)
- `renderEntityBox` (22)
- `renderEntityBox` (16)
- `renderRelationshipLabel` (7)
- `lowerErDrawing` (1)

**Calls:**
- `leaf` (138)
- `leaf` (109)
- `leaf` (101)
- `leaf` (6)
- `leaf` (4)
- `leaf` (2)
- `leaf` (2)
- `leaf` (2)
- `leaf` (2)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)

### `finiteNumber`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:175` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `svgPathDataProblem` (1)

### `createTextMeasurementExecution`
`/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `resolveExecutionPlan` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:487` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `paintAttribute` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:298` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:830` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `write` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:538` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `tag`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:152` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:259` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `tag`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:148` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `projectSvgCss`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `colorResolution` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:26` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `build` (1)

### `get`
`/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `resolveColors` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:298` | Self: 0.0% (1.5ms) | Total: 0.1% (5.4ms) | Samples: 1

**Called by:**
- `connector` (4)

**Calls:**
- `map` (3)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `group` (1)

### `typographyAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:694` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `erLabelUnread`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1059` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `parseErRelationshipSyntax` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:405` | Self: 0.0% (1.5ms) | Total: 0.2% (8.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (6)

**Calls:**
- `xmlSlice` (5)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:922` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `map` (1)

### `numberIsValid`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:280` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `validateStyleSpec` (1)

### `intersects`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `finishErGeometry` (1)

### `finishXmlLeaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:277` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `SvgWriter`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `_close`
`node:zlib` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `processChunkSync` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1391` | Self: 0.0% (1.5ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `nativeCandidate` (2)

**Calls:**
- `filter` (1)

### `renderPreparedLine`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:171` | Self: 0.0% (1.5ms) | Total: 0.1% (3.9ms) | Samples: 1

**Called by:**
- `renderMultilineText` (3)

**Calls:**
- `map` (1)
- `test` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1715` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `some` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:253` | Self: 0.0% (1.5ms) | Total: 0.2% (7.6ms) | Samples: 1

**Called by:**
- `leaf` (5)

**Calls:**
- `finite` (3)
- `finite` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1004` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `node` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:518` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `visit` (1)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `finalizeErRelationshipLabels` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1242` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `isArray`
`[native code]` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:39` | Self: 0.0% (1.4ms) | Total: 1.2% (43.5ms) | Samples: 1

**Called by:**
- `group` (10)
- `captureNativeGroupParse` (9)
- `captureNativeGroupEmission` (3)
- `validateNode` (1)

**Calls:**
- `visitSvgFirstTagAttributes` (11)
- `(anonymous)` (9)
- `test` (2)

### `strokedBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:543` | Self: 0.0% (1.4ms) | Total: 0.1% (5.4ms) | Samples: 1

**Called by:**
- `paintBounds` (4)

**Calls:**
- `lineStrokeBox` (2)
- `lineStrokeBox` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:28` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `renderRelationshipLine`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:446` | Self: 0.0% (1.4ms) | Total: 0.1% (4.5ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (3)

**Calls:**
- `prepareDisplayText` (2)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:794` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `validateChannels`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:581` | Self: 0.0% (1.4ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `validateNode` (2)

**Calls:**
- `boundedString` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:554` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:726` | Self: 0.0% (1.4ms) | Total: 0.4% (14.4ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (11)

**Calls:**
- `xmlRange` (9)
- `xmlRange` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `map` (1)

### `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/`
`[native code]` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `boundedString` (1)

### `value`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:127` | Self: 0.0% (1.4ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `nativeGroup` (2)

**Calls:**
- `tagRecord` (1)

### `resolveSceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `sceneRoleTraits` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `finish` (1)

### `trailingCommentStart`
`/tmp/pr449-main-integration-20261029-762/src/shared/trailing-comment.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `stripTrailingComment` (1)

### `decodeBase64`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:23` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `assertMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `text` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/journey/config-diagnostics.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `map` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:285` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `declareFamilyScenePrimitiveEvidence`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:254` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `completeBuiltinDescriptor` (1)

### `ensureContrast`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:102` | Self: 0.0% (1.4ms) | Total: 0.3% (13.1ms) | Samples: 1

**Called by:**
- `toneOnFill` (10)
- `legibleOnEvery` (1)

**Calls:**
- `contrastRatio` (8)
- `contrastRatio` (2)

### `resolveSvgColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `serialize` (1)

### `unionSceneBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `reduce` (1)

### `transformedBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:471` | Self: 0.0% (1.4ms) | Total: 0.1% (6.0ms) | Samples: 1

**Called by:**
- `paintBounds` (2)

**Calls:**
- `every` (1)

### `commandAtCursor`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:172` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `svgPathDataProblem` (1)

### `nativePaintSource`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:228` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:739` | Self: 0.0% (1.4ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `ActualTextPaintWrite` (1)

### `connectorSubpaths`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `connectorGeometryEndpoints` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts:4` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1206` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `write` (1)

### `finiteNumber`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:177` | Self: 0.0% (1.4ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `svgPathDataProblem` (2)

**Calls:**
- `/[-+]?(?:(?:\d+(?:\.\d*)?)\|(?:\.\d+))(?:[eE][-+]?\d+)?/y` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:840` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `write` (1)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:473` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `diagramColorVariables` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:568` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `resolvedColorValue` (1)

### `nativeAttributeValue`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:59` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `nativeGroup` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:18` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `prepareDisplayText` (1)

### `relationshipFrom`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1107` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `parseErDiagram` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:387` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector` (1)

### `lineStrokeBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:535` | Self: 0.0% (1.3ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `strokedBox` (2)

**Calls:**
- `geometryBounds` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `preparedInterTextBounds`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:526` | Self: 0.0% (1.3ms) | Total: 0.1% (4.3ms) | Samples: 1

**Called by:**
- `text` (3)

**Calls:**
- `copyDataProperties` (2)

### `forEach`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.2% (8.0ms) | Samples: 1

**Called by:**
- `validateNode` (2)
- `preparePixelText` (2)
- `extractErLayout` (1)

**Calls:**
- `validatePaint` (2)
- `qualify` (1)
- `(anonymous)` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:193` | Self: 0.0% (1.3ms) | Total: 0.1% (4.5ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (2)
- `renderCardinality` (1)

**Calls:**
- `push` (1)
- `indentLines` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:298` | Self: 0.0% (1.3ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `some` (2)

**Calls:**
- `erCharge` (1)

### `writtenPolylineProjectionOf`
`/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:517` | Self: 0.0% (1.3ms) | Total: 0.1% (4.1ms) | Samples: 1

**Called by:**
- `validateGeometry` (2)
- `validateNode` (1)

**Calls:**
- `finite` (2)

### `uncertain`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `group` (1)

### `boxAt`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:168` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `placeRelationshipLabels` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:605` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1213` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `write` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:244` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:175` | Self: 0.0% (1.3ms) | Total: 0.3% (12.0ms) | Samples: 1

**Called by:**
- `checkInertGroup` (9)

**Calls:**
- `collectNativeGroup` (7)
- `collectNativeGroup` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:529` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `text` (1)

### `assignPorts`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `nativeCandidate` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` | Self: 0.0% (1.3ms) | Total: 0.8% (28.4ms) | Samples: 1

**Called by:**
- `paintBounds` (18)
- `markerBoundsAt` (1)

**Calls:**
- `tryParseCssColor` (9)
- `tryParseCssColor` (3)
- `tryParseCssColor` (3)
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)

### `reorder`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:432` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:893` | Self: 0.0% (1.3ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `node` (2)

**Calls:**
- `hasDomSvgIdentityRole` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:335` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:273` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `paintPrimitiveSource`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `solidInteriors` (1)

### `inRanges`
`/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `isWideRange` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:18` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `sameRectanglePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:367` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `readErStatement`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `readErOuterStatements` (1)

### `escapeDisplayAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `renderEntityBox` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:504` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `finiteNumber`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:182` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `svgPathDataProblem` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:155` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1517` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `nativeCandidate` (1)

### `parseInlineFormatting`
`/tmp/pr449-main-integration-20261029-762/src/shared/inline-format.ts:29` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `prepareDisplayText` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1298` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `map` (1)

### `readErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:758` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `parseErDiagram` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:402` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:431` | Self: 0.0% (1.3ms) | Total: 0.3% (12.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (8)

**Calls:**
- `(anonymous)` (7)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `snapshot` (1)

### `captureNativeGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `groupValidation` (1)

### `pathMoveCount`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:838` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `write` (1)

### `inertRectangleRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:315` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` | Self: 0.0% (1.3ms) | Total: 0.2% (10.1ms) | Samples: 1

**Called by:**
- `write` (5)
- `node` (2)

**Calls:**
- `stringify` (5)
- `add` (1)

### `renderPreparedLine`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:167` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `renderMultilineText` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1386` | Self: 0.0% (1.3ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `nativeCandidate` (2)

**Calls:**
- `(anonymous)` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:452` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:60` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `visit` (1)

### `xmlRange`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:384` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:284` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector` (1)

### `safeCssPaint`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:129` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `completeBuiltinDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `emissionRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:76` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `registerGroupEmission` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` | Self: 0.0% (1.3ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `map` (2)

**Calls:**
- `get` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:418` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector` (1)

### `sceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:506` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `drawn` (1)

### `consumeStringBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:573` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `resolvedColorValue` (1)

### `resolveSceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `sceneRoleTraits` (1)

### `createPngOutputOptionFieldDescriptors`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:105` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:796` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:197` | Self: 0.0% (1.3ms) | Total: 0.2% (9.6ms) | Samples: 1

**Called by:**
- `renderEntityBox` (4)
- `renderEntityBox` (3)

**Calls:**
- `compositeCssColor` (6)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:91` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `materializeText` (1)

### `reorder`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:409` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `sceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `drawn` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:122` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `renderEntityBox` (1)

### `ActualTextPaintWrite`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:393` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:851` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `write` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:774` | Self: 0.0% (1.3ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `write` (2)

**Calls:**
- `validateRole` (1)

### `readErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:751` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `parseErDiagram` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:652` | Self: 0.0% (1.3ms) | Total: 0.8% (29.6ms) | Samples: 1

**Called by:**
- `erCardinalityInk` (16)
- `leaf` (4)

**Calls:**
- `paintedStrokeExtent` (18)
- `paintedStrokeExtent` (1)

### `assertBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `retainedNativeDrawing` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:497` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `text` (1)

### `unsafeActiveCss`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `inspectSecurityTail` (1)

### `getCharWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `measureText` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1468` | Self: 0.0% (1.2ms) | Total: 4.0% (141.3ms) | Samples: 1

**Called by:**
- `serialize` (97)

**Calls:**
- `validateNode` (14)
- `validateNode` (8)
- `validateNode` (5)
- `validateNode` (5)
- `validateNode` (5)
- `validateNode` (5)
- `validateNode` (3)
- `validateNode` (3)
- `validateNode` (3)
- `validateNode` (3)
- `validateNode` (3)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `resolveLabelContent`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:58` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `tagRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:25` | Self: 0.0% (1.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `tag` (1)
- `value` (1)

**Calls:**
- `defineProperties` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:128` | Self: 0.0% (1.2ms) | Total: 18.8% (659.3ms) | Samples: 1

**Called by:**
- `withDeferredTerminalProjections` (376)

**Calls:**
- `renderEntityBox` (80)
- `renderEntityBox` (63)
- `renderEntityBox` (44)
- `renderEntityBox` (28)
- `group` (26)
- `group` (25)
- `renderEntityBox` (19)
- `renderEntityBox` (18)
- `renderEntityBox` (16)
- `group` (12)
- `group` (7)
- `group` (6)
- `group` (3)
- `group` (3)
- `group` (3)
- `renderEntityBox` (2)
- `group` (2)
- `group` (2)
- `group` (1)
- `group` (1)
- `renderEntityBox` (1)
- `group` (1)
- `renderEntityBox` (1)
- `renderEntityBox` (1)
- `group` (1)
- `group` (1)
- `group` (1)
- `renderEntityBox` (1)
- `renderEntityBox` (1)
- `group` (1)
- `renderEntityBox` (1)
- `renderEntityBox` (1)
- `group` (1)
- `renderEntityBox` (1)

### `snapshotDescriptorArray`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1498` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `freezeDescriptor` (1)

### `element`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:476` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `freezeBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `registerBuiltInBackend` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `scopeSvgStyles` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `paintedStrokeExtent` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1380` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `some` (1)

### `renderResolvedMermaidSVG`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `consumeResolvedGraphicalRequest` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:107` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `shape` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `connectorInlineLabelSvg` (1)

### `nativePaintAncestors`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:197` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `visit` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:528` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `text` (1)

### `next`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.3% (10.6ms) | Samples: 1

**Called by:**
- `Set` (4)

**Calls:**
- `arrayIteratorNextHelper` (3)

### `ensureSvgIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:81` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:317` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:656` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `nativePaintSource`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1391` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `filter` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1917` | Self: 0.0% (1.2ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `map` (1)
- `find` (1)

**Calls:**
- `find` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1798` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `measureRenderStage` (1)

### `lineStrokeBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `strokedBox` (1)

### `fieldJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:508` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `transferSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:751` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `replaceField`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:835` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `write` (1)

### `statementEndAt`
`/tmp/pr449-main-integration-20261029-762/src/shared/accessibility-directives.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `scanAccessibilityDirectives` (1)

### `srgbRelativeLuminance`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:68` | Self: 0.0% (1.2ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `contrastRatio` (1)
- `contrastRatio` (1)

**Calls:**
- `srgbToLinear` (1)

### `reduce`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.2% (8.8ms) | Samples: 1

**Called by:**
- `advance` (5)
- `nativePlacement` (1)

**Calls:**
- `(anonymous)` (4)
- `unionSceneBounds` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1246` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `map` (1)

### `glyphBox`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1314` | Self: 0.0% (1.2ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `map` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:315` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `connector` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:536` | Self: 0.0% (1.2ms) | Total: 0.1% (5.0ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (2)

**Calls:**
- `hasDomSvgIdentityRole` (1)

### `install`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:41` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `setConnectorTerminalProjection` (1)

### `chargeInkSort`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:17` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `chargeInkSort` (1)

### `parseErRelationshipSyntax`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1075` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `readErStatement` (1)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:251` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `indexedPlacedCollides`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:123` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `collides` (1)

### `nativeAccessibilityEdits`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:673` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `normalizeMermaidSource` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:486` | Self: 0.0% (1.2ms) | Total: 0.1% (6.5ms) | Samples: 1

**Called by:**
- `hooks` (2)
- `writeConnectorSvg` (1)
- `geometryAttributes` (1)

**Calls:**
- `attribute` (2)
- `attribute` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `map` (1)

### `canonicalErContacts`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:236` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `finishErGeometry` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `paintedStrokeExtent` (1)

### `advanceAttrs`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:263` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `renderMultilineText` (1)

### `replaceField`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:294` | Self: 0.0% (1.2ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `defineProperty` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:229` | Self: 0.0% (1.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `connector` (2)

**Calls:**
- `assertKnownConnectorFields` (1)

### `/[-#:[\]",\u0000-\u001f]/`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `test` (1)

### `withRenderStageObserver`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `withPerformanceObserver` (1)

### `ownsParts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:424` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:206` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `visit` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:698` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `serialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `assessFamilyLayout`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:265` | Self: 0.0% (1.2ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `assessRenderedLayoutHardViolations` (2)

**Calls:**
- `finiteRect` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:390` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:136` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `visit` (1)

### `(anonymous)`
`internal:streams/readable:525` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Transform` (1)

### `imul`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `scopeHash` (1)

### `validateConnectorProjectionConsistency`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `transferNativeGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `snapshot` (1)

### `parseHex`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:25` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `mixHex` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:512` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:260` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `resolveRoleStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:240` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `nativePlacement` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:762` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `write` (1)

### `sameRectanglePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:363` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `serializableOptionCandidate`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `assertFamilyGeometryOptions` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:61` | Self: 0.0% (1.2ms) | Total: 0.8% (28.6ms) | Samples: 1

**Called by:**
- `visit` (18)
- `(anonymous)` (4)

**Calls:**
- `visit` (18)
- `visit` (2)
- `visit` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1066` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `write` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:517` | Self: 0.0% (1.2ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (2)

**Calls:**
- `paintAttribute` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:763` | Self: 0.0% (1.2ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `write` (1)
- `node` (1)

**Calls:**
- `set` (1)

### `Duplex`
`internal:streams/duplex` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Transform` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:733` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `write` (1)

### `connectorEndpointAnchors`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:443` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `connectorPaintBounds` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `finish` (1)

### `layoutMeasuredForest`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:246` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:565` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `validateJsonConfigAdmission`
`/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `renderOptionsAdmissionMessages` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:276` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:420` | Self: 0.0% (1.2ms) | Total: 0.1% (6.6ms) | Samples: 1

**Called by:**
- `measureErEntities` (4)
- `connectorInlineLabelText` (1)

**Calls:**
- `advance` (4)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:503` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:49` | Self: 0.0% (1.2ms) | Total: 0.4% (14.1ms) | Samples: 1

**Called by:**
- `join` (11)
- `group` (1)

**Calls:**
- `indent` (9)
- `issue` (1)
- `indent` (1)

### `py`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `pathBounds` (1)

### `/^(?:class\|data-[a-z][a-z0-9-]*\|role\|aria-[a-z]+\|tabindex\|pointer-events\|transform\|style)$/`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1802` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `write` (1)

### `createNativePaintEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `transferRetainedPixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:54` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `formatSvgNumericAttribute` (1)

### `retainTextPaintPresence`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:79` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `connectorGeometryEndpoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:174` | Self: 0.0% (1.1ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `connector` (2)

**Calls:**
- `connectorSubpaths` (1)

### `validateRawThemeCss`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `geometryElements` (1)

### `boundedString`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:269` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:200` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:654` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `geometryAttributes` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:58` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:734` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `visibleSketchProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:438` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `connectorProjectedField` (1)

### `decodeWithTrie`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:442` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `semanticIdentityForSvg` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:262` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `xmlSlice`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:30` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:200` | Self: 0.0% (1.1ms) | Total: 0.5% (18.5ms) | Samples: 1

**Called by:**
- `renderEntityBox` (9)
- `renderEntityBox` (6)

**Calls:**
- `ensureContrast` (10)
- `toHex` (3)
- `toHex` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/c4/parser.ts:27` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `extractErLayout` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:287` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `parseExtensionId`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:202` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `sceneValidationMode` (1)

### `prepared`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:321` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:276` | Self: 0.0% (1.1ms) | Total: 0.2% (7.2ms) | Samples: 1

**Called by:**
- `leaf` (6)

**Calls:**
- `append` (5)

### `erLabelPillGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `renderRelationshipLabel` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1700` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `collectNativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:164` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `/[-+]?(?:(?:\d+(?:\.\d*)?)\|(?:\.\d+))(?:[eE][-+]?\d+)?/y`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `finiteNumber` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:142` | Self: 0.0% (1.1ms) | Total: 0.1% (3.9ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)
- `renderCardinality` (1)
- `renderCardinality` (1)

**Calls:**
- `getOwnPropertyDescriptor` (2)

### `decodeWithTrie`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js:456` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `semanticIdentityForSvg` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:315` | Self: 0.0% (1.1ms) | Total: 0.1% (6.0ms) | Samples: 1

**Called by:**
- `forEach` (2)
- `validateNode` (2)
- `validateMarker` (1)

**Calls:**
- `numericCss` (1)
- `numericCss` (1)
- `numericCss` (1)
- `numericCss` (1)

### `consumePointBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validatePoint` (1)

### `XmlLeafWrite`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:298` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `SvgWriter` (1)

### `replaceField`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:293` | Self: 0.0% (1.1ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1518` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `nativeCandidate` (1)

### `charge`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `chargeInkSort` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1848` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `preventExtensions`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:335` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `inspectOwnedSvgOnce` (1)

### `createOwnedNativePaintRecorder`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `inspectPaint` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:144` | Self: 0.0% (1.1ms) | Total: 0.2% (7.3ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)
- `renderCardinality` (1)
- `renderCardinality` (1)

**Calls:**
- `copyDataProperties` (2)

### `pointsBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:13` | Self: 0.0% (1.1ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `geometryBounds` (1)
- `markerTerminalDepth` (1)

**Calls:**
- `map` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:640` | Self: 0.0% (1.1ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `transferSceneNodeSerialization` (1)

### `indent`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:226` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:42` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `replace` (1)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:703` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `node` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1023` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `write` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:290` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `canonicalizeSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `attachSceneNodeSerialization` (1)

### `srgbToLinear`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:63` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `srgbRelativeLuminance` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:281` | Self: 0.0% (1.1ms) | Total: 0.1% (3.7ms) | Samples: 1

**Called by:**
- `connector` (3)

**Calls:**
- `connectorGeometryEndpoints` (2)

### `erCardinalityPieces`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:66` | Self: 0.0% (1.1ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `erCardinalityInk` (2)

**Calls:**
- `pushTickAt` (1)

### `apply`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `has` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:69` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `inspectPaint` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:562` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `finish` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:270` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `isWhitespace`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:31` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `resolvedColorValue`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:599` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `toneOnFill` (1)

### `ownerOf`
`/tmp/pr449-main-integration-20261029-762/src/shared/subgraph-membership.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `finish` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:250` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `resolveSceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:214` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `sceneRoleTraits` (1)

### `erCharge`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:204` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1519` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `nativeCandidate` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/directives.js:175` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `issue`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:91` | Self: 0.0% (1.0ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)
- `(anonymous)` (1)

**Calls:**
- `freeze` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:508` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `group` (1)

### `finiteString`
`/tmp/pr449-main-integration-20261029-762/src/styles.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `textTransform` (1)

### `header`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `documentOpen` (1)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `diagramColorVariables` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `nativeOrEmulated` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:115` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `erCharge`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `intersects` (1)

### `ownFragment`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `writeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` | Self: 0.0% (1.0ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `map` (1)

### `connectorTerminalStrokeLosses`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `deriveConnectorTerminalProjection` (1)

### `schemaRecord`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validate` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:813` | Self: 0.0% (1.0ms) | Total: 0.5% (19.5ms) | Samples: 1

**Called by:**
- `write` (14)

**Calls:**
- `validateGeometry` (6)
- `validateGeometry` (3)
- `validateGeometry` (1)
- `validateGeometry` (1)
- `validateGeometry` (1)
- `validateGeometry` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:759` | Self: 0.0% (1.0ms) | Total: 0.1% (3.6ms) | Samples: 1

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `get` (2)

### `finiteString`
`/tmp/pr449-main-integration-20261029-762/src/styles.ts:234` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `resolveRenderStyle` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:181` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:330` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `keys`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `rejectUnknownKeys` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1104` | Self: 0.0% (1.0ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `write` (2)

**Calls:**
- `numericCss` (1)

### `graphemes`
`/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `prepareDisplayText` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:221` | Self: 0.0% (1.0ms) | Total: 0.2% (9.0ms) | Samples: 1

**Called by:**
- `visit` (4)
- `visit` (2)
- `admitSceneDocumentWith` (2)

**Calls:**
- `visit` (4)
- `visit` (2)
- `visit` (1)

### `checkArchitectureRenderOptionColors`
`/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `xmlTokenAt`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:17` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `xmlIndexOf` (1)

### `ensureSvgIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:92` | Self: 0.0% (1.0ms) | Total: 0.2% (9.5ms) | Samples: 1

**Called by:**
- `group` (6)

**Calls:**
- `set` (2)
- `set` (2)
- `set` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:670` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:35` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `group` (1)

### `safeCssFontFamily`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-font.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validateStyleSpec` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:735` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `map` (1)

### `immutableDecision`
`/tmp/pr449-main-integration-20261029-762/src/layout/decision-evidence.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `emitGraphLayoutDecision` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:674` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `renderDisplayRuns`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:148` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `renderMultilineText` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:653` | Self: 0.0% (1.0ms) | Total: 0.1% (4.9ms) | Samples: 1

**Called by:**
- `leaf` (4)

**Calls:**
- `assign` (3)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:248` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts:308` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

### `expandSceneBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:35` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `paintedBox` (1)

### `cliRenderFormats`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:796` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `node` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:606` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:417` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `group` (1)

### `emissionRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `registerGroupEmission` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1040` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `write` (1)

### `isAsciiXmlNameChar`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:6` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `WriteStream`
`internal:fs/streams` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `writeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:616` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `/\sdata-from="([^"]*)"/`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `attr` (1)

### `textPaints`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `nonPainting` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:169` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `relativeLuminance` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1241` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `snapshotIdentityRecord`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `snapshotFamilyIdentity` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:653` | Self: 0.0% (1.0ms) | Total: 0.3% (13.5ms) | Samples: 1

**Called by:**
- `erCardinalityInk` (7)
- `leaf` (1)

**Calls:**
- `strokedBox` (4)
- `transformedBounds` (2)
- `paintedBox` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:190` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` | Self: 0.0% (1.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `attribute` (2)
- `(anonymous)` (1)

**Calls:**
- `toPrecision` (2)

### `sanitizeDisplayLines`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` | Self: 0.0% (1.0ms) | Total: 0.1% (3.9ms) | Samples: 1

**Called by:**
- `escapeDisplayAttr` (1)
- `(anonymous)` (1)
- `renderRelationshipLine` (1)

**Calls:**
- `map` (2)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:174` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `relativeLuminance` (1)

### `deepFreeze`
`/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:15` | Self: 0.0% (999us) | Total: 0.0% (999us) | Samples: 1

**Called by:**
- `deepFreeze` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:241` | Self: 0.0% (997us) | Total: 0.0% (997us) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `optional`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:49` | Self: 0.0% (994us) | Total: 0.0% (994us) | Samples: 1

**Called by:**
- `terminalEndpoint` (1)

### `performIteration`
`[native code]` | Self: 0.0% (991us) | Total: 0.0% (991us) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` | Self: 0.0% (990us) | Total: 0.0% (990us) | Samples: 1

**Called by:**
- `measureRenderStage` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:642` | Self: 0.0% (988us) | Total: 0.0% (988us) | Samples: 1

**Called by:**
- `erCardinalityInk` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (986us) | Total: 0.0% (986us) | Samples: 1

**Called by:**
- `measureErEntities` (1)

### `xmlHasColon`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:85` | Self: 0.0% (979us) | Total: 0.0% (979us) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` | Self: 0.0% (979us) | Total: 0.0% (979us) | Samples: 1

**Called by:**
- `validateNode` (1)

### `defineProperties`
`[native code]` | Self: 0.0% (978us) | Total: 0.0% (978us) | Samples: 1

**Called by:**
- `tagRecord` (1)

### `pointsBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (976us) | Total: 0.0% (976us) | Samples: 1

**Called by:**
- `geometryBounds` (1)

### `mixedChannels`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` | Self: 0.0% (966us) | Total: 0.0% (966us) | Samples: 1

**Called by:**
- `ensureContrast` (1)

### `startTags`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:65` | Self: 0.0% (966us) | Total: 0.0% (966us) | Samples: 1

**Called by:**
- `inspectSecurity` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (964us) | Total: 0.0% (964us) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `erFrameInkPadding`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:768` | Self: 0.0% (960us) | Total: 0.0% (960us) | Samples: 1

**Called by:**
- `extractErLayout` (1)

### `nodeWorldBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (943us) | Total: 0.0% (943us) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:155` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `test` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:173` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `createPngOutputOptionFieldDescriptors` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:258` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `writeTextSvg` (1)

**Calls:**
- `map` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:205` | Self: 0.0% (0us) | Total: 30.5% (1.07s) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (652)

**Calls:**
- `withDeferredTerminalProjections` (652)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:4` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `erCommentColumnWidth`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:430` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `renderEntityBox` (1)

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1160` | Self: 0.0% (0us) | Total: 0.1% (6.3ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (3)

**Calls:**
- `preparePixelText` (1)
- `erRelationshipBlock` (1)
- `preparePixelText` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:169` | Self: 0.0% (0us) | Total: 0.2% (7.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (3)
- `renderCardinality` (2)

**Calls:**
- `snapshot` (5)

### `deepFreeze`
`/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` | Self: 0.0% (0us) | Total: 0.7% (24.5ms) | Samples: 0

**Called by:**
- `deepFreeze` (18)
- `(module)` (1)
- `validateSerializableRenderOptions` (1)
- `(module)` (1)

**Calls:**
- `deepFreeze` (18)
- `freeze` (2)
- `deepFreeze` (1)

### `consumeStringBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:400` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `boundedUtf8ByteLength` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/createNode.js:3` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `renderRelationshipLine`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:440` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (2)

**Calls:**
- `resolveRoleStyle` (1)
- `resolveRoleStyle` (1)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1637` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (4)

**Calls:**
- `applyOutputSecurityPolicy` (4)

### `measureRenderStage`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:30` | Self: 0.0% (0us) | Total: 52.8% (1.84s) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (777)
- `renderResolvedMermaidSVG` (226)
- `renderPositionedWithTextMeasurement` (80)
- `nativePlacement` (18)
- `executeInspectedGraphicalRequest` (18)
- `renderPositionedWithTextMeasurement` (15)

**Calls:**
- `retainedNativeDrawing` (731)
- `positionFamilyForNativeRender` (226)
- `applyOutputSecurityPolicy` (80)
- `retainedNativeDrawing` (45)
- `layoutLayeredGraph` (17)
- `positionedPaintCertification` (15)
- `resolveRenderRequestForExecution` (6)
- `resolveRenderRequestForExecution` (3)
- `resolveRenderRequestForExecution` (2)
- `resolveRenderRequestForExecution` (2)
- `resolveRenderRequestForExecution` (1)
- `layoutLayeredGraph` (1)
- `resolveRenderRequestForExecution` (1)
- `resolveRenderRequestForExecution` (1)
- `resolveRenderRequestForExecution` (1)
- `resolveRenderRequestForExecution` (1)
- `retainedNativeDrawing` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:739` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `includes` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:218` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `cliRenderFormats` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` | Self: 0.0% (0us) | Total: 0.1% (6.1ms) | Samples: 0

**Called by:**
- `reduce` (4)

**Calls:**
- `measureTextWidth` (4)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1328` | Self: 0.0% (0us) | Total: 0.5% (17.9ms) | Samples: 0

**Called by:**
- `nativeCandidate` (13)

**Calls:**
- `flatIntoArrayWithCallback` (13)

### `scanAccessibilityDirectives`
`/tmp/pr449-main-integration-20261029-762/src/shared/accessibility-directives.ts:124` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `parseErDiagram` (1)

**Calls:**
- `statementEndAt` (1)

### `node`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1453` | Self: 0.0% (0us) | Total: 1.2% (43.2ms) | Samples: 0

**Called by:**
- `group` (28)

**Calls:**
- `validateNode` (15)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `emitGraphLayoutDecision`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:42` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `immutableDecision` (1)

### `mermaidInitDirectives`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:558` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `sourceEnvelopeMetadata` (1)

**Calls:**
- `RegExp` (1)

### `readXmlNameEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:102` | Self: 0.0% (0us) | Total: 0.2% (7.8ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (4)
- `verifyDocumentEnvelope` (1)

**Calls:**
- `xmlAsciiLetter` (5)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:307` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `copyDataProperties` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:22` | Self: 0.0% (0us) | Total: 0.6% (21.2ms) | Samples: 0

**Calls:**
- `gc` (14)

### `hasDomSvgIdentityRole`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:69` | Self: 0.0% (0us) | Total: 0.1% (6.3ms) | Samples: 0

**Called by:**
- `validateNode` (1)
- `identityAttributes` (1)
- `validateNode` (1)

**Calls:**
- `sceneRoleTraits` (2)
- `sceneRoleTraits` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1765` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `measureRenderStage` (2)

**Calls:**
- `resolveAppearance` (1)
- `resolveAppearance` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:644` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `rectangleInput` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1930` | Self: 0.0% (0us) | Total: 0.1% (3.7ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `inverseMatrix` (1)

### `connectorInlineLabelText`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:427` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `preparePixelText` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1188` | Self: 0.0% (0us) | Total: 1.5% (52.5ms) | Samples: 0

**Called by:**
- `nativeCandidate` (36)

**Calls:**
- `nativePlacement` (18)
- `nativePlacement` (12)
- `nativePlacement` (3)
- `nativePlacement` (3)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:242` | Self: 0.0% (0us) | Total: 3.4% (119.5ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (80)

**Calls:**
- `leaf` (72)
- `text` (8)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:688` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `(anonymous)` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:171` | Self: 0.0% (0us) | Total: 0.1% (5.9ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (5)

**Calls:**
- `(anonymous)` (3)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:495` | Self: 0.0% (0us) | Total: 0.1% (4.3ms) | Samples: 0

**Called by:**
- `text` (2)

**Calls:**
- `copyDataProperties` (2)

### `inspectSecurityTail`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:687` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `unsafeActiveCss` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:515` | Self: 0.0% (0us) | Total: 0.3% (13.7ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (6)
- `writeTextSvg` (1)

**Calls:**
- `paintAttribute` (7)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:268` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `erCommentColumnWidth` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:676` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `element` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1534` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `(anonymous)` (1)

### `builtinFamilyConformanceReport`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1915` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `map` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:436` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureErEntities` (1)

**Calls:**
- `qualify` (1)

### `collectNativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:146` | Self: 0.0% (0us) | Total: 0.2% (9.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (7)

**Calls:**
- `visitSvgStartTagsFresh` (7)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1395` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `map` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:220` | Self: 0.0% (0us) | Total: 0.6% (23.2ms) | Samples: 0

**Called by:**
- `copyInner` (14)

**Calls:**
- `copyInner` (13)
- `copyInner` (1)

### `validateConnectorProjectionConsistency`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1351` | Self: 0.0% (0us) | Total: 0.0% (994us) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `deriveConnectorTerminalProjection` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:7` | Self: 0.0% (0us) | Total: 0.1% (6.3ms) | Samples: 0

**Calls:**
- `importModule` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:745` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `finish` (1)

### `serializeMarkerResource`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:141` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `geometryElements` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:278` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `extractErLayout` (1)

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:16` | Self: 0.0% (0us) | Total: 0.1% (5.6ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `bound require` (4)

### `paintedBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:525` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `expandSceneBounds` (1)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1636` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (1)

**Calls:**
- `map` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:405` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `measureErEntities` (1)

**Calls:**
- `styledRunLayout` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:45` | Self: 0.0% (0us) | Total: 4.7% (165.9ms) | Samples: 0

**Calls:**
- `gc` (95)

### `isWideRange`
`/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:127` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `getCharWidth` (1)

**Calls:**
- `inRanges` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:311` | Self: 0.0% (0us) | Total: 0.3% (11.7ms) | Samples: 0

**Called by:**
- `extractErLayout` (8)

**Calls:**
- `some` (8)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:251` | Self: 0.0% (0us) | Total: 0.2% (7.1ms) | Samples: 0

**Called by:**
- `writeTextSvg` (4)

**Calls:**
- `map` (2)
- `test` (2)

### `nativePlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1139` | Self: 0.0% (0us) | Total: 0.5% (18.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (12)

**Calls:**
- `erCardinalityEnvelope` (11)
- `reduce` (1)

### `readErOuterStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:514` | Self: 0.0% (0us) | Total: 0.2% (8.3ms) | Samples: 0

**Called by:**
- `findErStatements` (5)

**Calls:**
- `readErStatement` (4)
- `readErStatement` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` | Self: 0.0% (0us) | Total: 0.3% (11.2ms) | Samples: 0

**Called by:**
- `geometryAttributes` (6)
- `geometryAttributes` (2)
- `hooks` (1)
- `geometryAttributes` (1)

**Calls:**
- `formatSvgNumericAttribute` (6)
- `formatSvgNumber` (2)
- `formatSvgNumber` (1)
- `formatSvgNumericAttribute` (1)

### `readErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:800` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `parseErDiagram` (1)

**Calls:**
- `finish` (1)

### `snapshot`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:277` | Self: 0.0% (0us) | Total: 0.2% (8.5ms) | Samples: 0

**Called by:**
- `group` (5)
- `drawNative` (1)

**Calls:**
- `copyInner` (3)
- `copyInner` (2)
- `copyInner` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1052` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)
- `write` (1)

**Calls:**
- `validateGeometry` (1)
- `validateGeometry` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:532` | Self: 0.0% (0us) | Total: 0.1% (3.5ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `has` (1)

### `node:stream`
`node:stream:2` | Self: 0.0% (0us) | Total: 0.3% (10.5ms) | Samples: 0

**Called by:**
- `anonymous` (7)

**Calls:**
- `anonymous` (7)

### `rectangleInput`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:349` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `inertRectangleRecord` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:651` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `advanceAttrs`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:264` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `renderMultilineText` (1)

**Calls:**
- `formatSvgNumber` (1)

### `renderRelationshipLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:527` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (2)

**Calls:**
- `resolveRoleStyle` (1)
- `resolveRoleStyle` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:715` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `map` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:585` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `resolvedColorValue` (1)

**Calls:**
- `set` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:213` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `copyInner` (2)

**Calls:**
- `hasOwned` (2)

### `captureNativeGroupParse`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:173` | Self: 0.0% (0us) | Total: 0.4% (15.9ms) | Samples: 0

**Called by:**
- `captureNativeGroupEmission` (10)

**Calls:**
- `checkInertGroup` (9)
- `checkInertGroup` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:50` | Self: 0.0% (0us) | Total: 0.0% (991us) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `performIteration` (1)

### `cloneValue`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` | Self: 0.0% (0us) | Total: 0.1% (5.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)
- `map` (2)
- `sharedRenderOptionsJsonSchema` (1)

**Calls:**
- `map` (6)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:8` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `withRenderStageObserver`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:20` | Self: 0.0% (0us) | Total: 54.2% (1.89s) | Samples: 0

**Called by:**
- `withPerformanceObserver` (1161)

**Calls:**
- `withSvgInspectionCache` (1161)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:83` | Self: 0.0% (0us) | Total: 0.3% (12.8ms) | Samples: 0

**Called by:**
- `inspectPaint` (7)

**Calls:**
- `nativePaintAncestors` (3)
- `nativePaintAncestors` (2)
- `nativePaintAncestors` (1)
- `nativePaintAncestors` (1)

### `readErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:739` | Self: 0.0% (0us) | Total: 0.3% (11.6ms) | Samples: 0

**Called by:**
- `parseErDiagram` (7)

**Calls:**
- `findErStatements` (5)
- `findErStatements` (1)
- `findErStatements` (1)

### `hasOwned`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:11` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `copy` (2)

**Calls:**
- `has` (2)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:208` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:85` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `ensureSvgIdentity` (1)

**Calls:**
- `escapeAttr` (1)

### `findErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:665` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `readErStatements` (1)

**Calls:**
- `stripTrailingComment` (1)

### `erCardinalityPieces`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:113` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `erCardinalityInk` (1)

**Calls:**
- `copyDataProperties` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:222` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `layoutMeasuredForest` (1)

### `erCardinalityInk`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:123` | Self: 0.0% (0us) | Total: 0.1% (6.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)
- `enoughLead` (1)
- `(anonymous)` (1)

**Calls:**
- `erCardinalityPieces` (2)
- `erCardinalityPieces` (1)
- `erCardinalityPieces` (1)

### `assessRenderedLayoutHardViolations`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:211` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `assessFamilyLayout` (2)
- `assessFamilyLayout` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:376` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `readXmlNameEnd` (2)
- `readXmlNameEnd` (1)

### `resolveRoleStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:244` | Self: 0.0% (0us) | Total: 0.2% (7.2ms) | Samples: 0

**Called by:**
- `nativePlacement` (2)
- `renderRelationshipLine` (1)
- `erRelationshipBlock` (1)
- `renderRelationshipLabel` (1)

**Calls:**
- `find` (5)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:5` | Self: 0.0% (0us) | Total: 0.1% (5.6ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `bound require` (4)

### `layoutErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1109` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `resolveRenderStyle` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:26` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Calls:**
- `(anonymous)` (3)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1078` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `isArray` (1)

### `graphicalBackendCapabilityClaims`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:267` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `createSketchBackend` (1)

**Calls:**
- `findIndex` (1)

### `captureNativeGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:101` | Self: 0.0% (0us) | Total: 0.4% (15.9ms) | Samples: 0

**Called by:**
- `groupValidation` (10)

**Calls:**
- `captureNativeGroupParse` (10)

### `internal:streams/duplex`
`internal:streams/duplex:2` | Self: 0.0% (0us) | Total: 0.1% (6.6ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `anonymous` (4)

### `geometryElements`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:66` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `serializeMarkerResource` (1)

**Calls:**
- `paintAttributes` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:581` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `serialize`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:631` | Self: 0.0% (0us) | Total: 10.9% (382.1ms) | Samples: 0

**Called by:**
- `leaf` (138)
- `leaf` (106)

**Calls:**
- `write` (128)
- `write` (97)
- `write` (11)
- `write` (3)
- `write` (3)
- `(anonymous)` (1)
- `write` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:200` | Self: 0.0% (0us) | Total: 0.4% (14.3ms) | Samples: 0

**Called by:**
- `group` (12)

**Calls:**
- `(anonymous)` (11)
- `(anonymous)` (1)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:59` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `scanStartTags` (1)

**Calls:**
- `sourceIndexOf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:710` | Self: 0.0% (0us) | Total: 4.5% (159.4ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (82)

**Calls:**
- `verifyDocumentEnvelope` (26)
- `verifyDocumentEnvelope` (12)
- `verifyDocumentEnvelope` (10)
- `verifyDocumentEnvelope` (8)
- `verifyDocumentEnvelope` (6)
- `verifyDocumentEnvelope` (6)
- `verifyDocumentEnvelope` (3)
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)

### `escapeDisplayAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:115` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `renderEntityBox` (1)

**Calls:**
- `sanitizeDisplayLines` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:123` | Self: 0.0% (0us) | Total: 9.6% (338.4ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (220)

**Calls:**
- `withGraphLayoutDecisionObserver` (220)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:123` | Self: 0.0% (0us) | Total: 5.8% (206.3ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (147)

**Calls:**
- `leaf` (106)
- `connector` (31)
- `renderRelationshipLine` (3)
- `renderRelationshipLine` (2)
- `renderRelationshipLine` (2)
- `push` (1)
- `ownFragment` (1)
- `renderRelationshipLine` (1)

### `groupValidation`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:506` | Self: 0.0% (0us) | Total: 0.6% (22.6ms) | Samples: 0

**Called by:**
- `validateNode` (15)

**Calls:**
- `captureNativeGroupEmission` (10)
- `captureNativeGroupEmission` (3)
- `captureNativeGroupEmission` (1)
- `captureNativeGroupEmission` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:252` | Self: 0.0% (0us) | Total: 0.9% (32.4ms) | Samples: 0

**Called by:**
- `leaf` (21)

**Calls:**
- `paintBounds` (6)
- `paintBounds` (4)
- `paintBounds` (2)
- `paintBounds` (2)
- `connectorPaintBounds` (2)
- `connectorPaintBounds` (1)
- `connectorPaintBounds` (1)
- `paintBounds` (1)
- `connectorPaintBounds` (1)
- `paintBounds` (1)

### `Transform`
`internal:streams/transform:14` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `ZlibBase` (1)

**Calls:**
- `Duplex` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:713` | Self: 0.0% (0us) | Total: 0.3% (10.6ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (7)

**Calls:**
- `inspectAttributeSecurity` (3)
- `inspectAttributeSecurity` (2)
- `inspectAttributeSecurity` (1)
- `inspectAttributeSecurity` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:94` | Self: 0.0% (0us) | Total: 0.6% (21.8ms) | Samples: 0

**Called by:**
- `measureRenderStage` (17)

**Calls:**
- `layoutLayeredGraph` (3)
- `layoutLayeredGraph` (2)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)

### `hasPublicVerificationProjection`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1620` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `expectedCapabilityState` (1)

**Calls:**
- `hasPublicLayoutProjection` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:173` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `markerBoundsAt` (1)

**Calls:**
- `py` (1)

### `deferredTerminalProjectionInput`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:66` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `validateNode` (3)
- `copyInner` (1)

**Calls:**
- `getOwnPropertyDescriptor` (4)

### `processChunkSync`
`node:zlib:229` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `zlibBufferSync` (1)

**Calls:**
- `_close` (1)

### `resolveRenderStyle`
`/tmp/pr449-main-integration-20261029-762/src/styles.ts:304` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `finiteString` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:696` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `assignChannelTracks`
`/tmp/pr449-main-integration-20261029-762/src/layout/channel-tracks.ts:27` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `filter` (1)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:701` | Self: 0.0% (0us) | Total: 1.0% (36.6ms) | Samples: 0

**Called by:**
- `inlineResolvedColors` (24)

**Calls:**
- `projectSvgCss` (23)
- `projectSvgCss` (1)

### `get WriteStream`
`node:fs:667` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `anonymous` (2)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1389` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `(anonymous)` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:166` | Self: 0.0% (0us) | Total: 3.4% (121.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (25)
- `renderCardinality` (10)
- `renderCardinality` (3)

**Calls:**
- `group` (14)
- `group` (11)
- `group` (8)
- `group` (4)
- `group` (1)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:702` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `sourceEnvelopeMetadata` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1759` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `validateRawThemeCss` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:64` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `validateSerializableRenderOptions` (1)

**Calls:**
- `schemaRecord` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:725` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `identityAttributes` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:10` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `importModule` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:7` | Self: 0.0% (0us) | Total: 0.2% (10.4ms) | Samples: 0

**Called by:**
- `anonymous` (7)

**Calls:**
- `bound require` (7)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:92` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `inspectPaint` (1)

**Calls:**
- `observe` (1)

### `parseErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:810` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `scanAccessibilityDirectives` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:5` | Self: 0.0% (0us) | Total: 0.7% (27.8ms) | Samples: 0

**Calls:**
- `(anonymous)` (9)

### `parseEncodeTrie`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:85` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `set` (1)

### `completeBuiltinDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1384` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `declareFamilyScenePrimitiveEvidence` (1)

### `withPerformanceObserver`
`/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts:42` | Self: 0.0% (0us) | Total: 54.2% (1.89s) | Samples: 0

**Called by:**
- `(module)` (1162)

**Calls:**
- `withRenderStageObserver` (1161)
- `withRenderStageObserver` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:588` | Self: 0.0% (0us) | Total: 0.5% (17.9ms) | Samples: 0

**Called by:**
- `group` (11)

**Calls:**
- `semanticIdentityForSvg` (8)
- `semanticIdentityForSvg` (1)
- `semanticIdentityForSvg` (1)
- `semanticIdentityForSvg` (1)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:213` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `paintBounds` (2)

**Calls:**
- `geometryBounds` (1)
- `geometryBounds` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1392` | Self: 0.0% (0us) | Total: 0.2% (7.4ms) | Samples: 0

**Called by:**
- `nativeCandidate` (5)

**Calls:**
- `filter` (5)

### `consumeResolvedGraphicalRequest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:316` | Self: 0.0% (0us) | Total: 53.2% (1.86s) | Samples: 0

**Called by:**
- `withSvgInspectionCache` (1142)

**Calls:**
- `withTextMeasurementExecution` (915)
- `renderResolvedMermaidSVG` (226)
- `renderResolvedMermaidSVG` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:186` | Self: 0.0% (0us) | Total: 0.2% (7.5ms) | Samples: 0

**Called by:**
- `copyInner` (3)
- `copy` (1)

**Calls:**
- `transferRetainedPixelText` (3)
- `transferRetainedPixelText` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:879` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `node` (1)

**Calls:**
- `hasDomSvgIdentityRole` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:259` | Self: 0.0% (0us) | Total: 0.7% (26.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (18)

**Calls:**
- `leaf` (16)
- `shape` (2)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:209` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `connectorPaintBounds` (2)

**Calls:**
- `pointsBounds` (1)
- `pointsBounds` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:881` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `node` (1)

**Calls:**
- `stringify` (1)

### `localPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1385` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `localPaintResourceId` (1)

### `erFrameInkPadding`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:767` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `extractErLayout` (1)

**Calls:**
- `resolveRoleStyle` (1)

### `collides`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:172` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `placeRelationshipLabels` (1)

**Calls:**
- `indexedPlacedCollides` (1)

### `withGraphLayoutDecisionObserver`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:37` | Self: 0.0% (0us) | Total: 9.6% (338.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (220)

**Calls:**
- `layout` (207)
- `layout` (13)

### `validateMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:353` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `validateNode` (2)

**Calls:**
- `rejectUnknownKeys` (1)
- `rejectUnknownKeys` (1)

### `findErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:670` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `readErStatements` (1)

**Calls:**
- `skipSpace` (1)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:434` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `consumePointBudget` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:426` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `numericStrokeWidth` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:600` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `connectorEndpointAnchors` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:62` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `visit` (2)

**Calls:**
- `overlaps` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:111` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (1)

**Calls:**
- `erCardinalityInk` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:199` | Self: 0.0% (0us) | Total: 0.1% (6.6ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (3)
- `renderCardinality` (1)

**Calls:**
- `freeze` (4)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:10` | Self: 0.0% (0us) | Total: 4.7% (166.6ms) | Samples: 0

**Called by:**
- `map` (7)

**Calls:**
- `markerTerminalDepth` (7)

### `assertKnownConnectorFields`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:160` | Self: 0.0% (0us) | Total: 0.0% (968us) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `hasOwn` (1)

### `advance`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` | Self: 0.0% (0us) | Total: 0.2% (7.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (4)
- `(anonymous)` (1)

**Calls:**
- `reduce` (5)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:225` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `topRoundedRectPath` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:32` | Self: 0.0% (0us) | Total: 1.6% (58.7ms) | Samples: 0

**Calls:**
- `consume` (16)
- `consume` (13)
- `consume` (2)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:185` | Self: 0.0% (0us) | Total: 0.1% (4.1ms) | Samples: 0

**Called by:**
- `preparePixelText` (2)

**Calls:**
- `map` (2)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:702` | Self: 0.0% (0us) | Total: 0.3% (13.3ms) | Samples: 0

**Called by:**
- `node` (8)

**Calls:**
- `serializeSceneNode` (5)
- `serializeSceneNode` (3)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:252` | Self: 0.0% (0us) | Total: 4.6% (160.9ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (80)

**Calls:**
- `measureRenderStage` (80)

### `sourceEnvelopeMetadata`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:789` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `normalizeSource` (1)

**Calls:**
- `mermaidInitDirectives` (1)

### `renderRelationshipLine`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:471` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `sanitizeDisplayLines` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:13` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `f` (1)

### `internal:streams/end-of-stream`
`internal:streams/end-of-stream:17` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:693` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `inertRectangleRecord` (1)
- `inertRectangleRecord` (1)

### `render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:394` | Self: 0.0% (0us) | Total: 0.9% (34.0ms) | Samples: 0

**Called by:**
- `rendered` (23)

**Calls:**
- `admitSceneDocumentWith` (18)
- `admitSceneDocumentWith` (4)
- `admitSceneDocumentWith` (1)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:474` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `diagramColorVariables` (1)

**Calls:**
- `get` (1)

### `deriveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:505` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveColors` (1)

**Calls:**
- `textTones` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:123` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `add` (1)

### `mermaidFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:149` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `normalizeMermaidSource` (1)

**Calls:**
- `stripMermaidDirectives` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1879` | Self: 0.0% (0us) | Total: 2.3% (83.8ms) | Samples: 0

**Called by:**
- `(module)` (11)

**Calls:**
- `validateDescriptor` (2)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)

### `applyFamilyRequestNormalization`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1075` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveAppearance` (1)

**Calls:**
- `assertFamilyGeometryOptions` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:250` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `finish` (1)
- `finish` (1)

### `snapshotFamilyIdentity`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1516` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `freezeDescriptor` (1)

**Calls:**
- `snapshotIdentityRecord` (1)

### `isCombiningMark`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:49` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `getCharWidth` (1)

**Calls:**
- `isZeroWidth` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `resolveSvgColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:758` | Self: 0.0% (0us) | Total: 0.3% (13.1ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (10)

**Calls:**
- `transformSvgCssValues` (4)
- `join` (3)
- `applyReplacements` (2)
- `applyReplacements` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1878` | Self: 0.0% (0us) | Total: 0.4% (15.5ms) | Samples: 0

**Called by:**
- `(module)` (11)

**Calls:**
- `freezeDescriptor` (4)
- `freezeDescriptor` (1)
- `completeBuiltinDescriptor` (1)
- `completeBuiltinDescriptor` (1)
- `freezeDescriptor` (1)
- `completeBuiltinDescriptor` (1)
- `freezeDescriptor` (1)
- `freezeDescriptor` (1)

### `inlineResolvedColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:636` | Self: 0.0% (0us) | Total: 1.0% (36.6ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (24)

**Calls:**
- `colorResolution` (24)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:713` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `typographyAttributes` (1)

### `registerBuiltInStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:292` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `validateStyleSpec` (1)
- `validateStyleSpec` (1)
- `freeze` (1)
- `validateStyleSpec` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/YAMLMap.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:71` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `collides` (2)
- `finishErGeometry` (1)
- `finishErGeometry` (1)

**Calls:**
- `visit` (4)

### `validateStyleSpec`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:436` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (1)

**Calls:**
- `safeCssFontFamily` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:633` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `group` (4)

**Calls:**
- `registerGroupEmission` (3)
- `copyDataProperties` (1)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:465` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `validate` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:8` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `node`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1456` | Self: 0.0% (0us) | Total: 0.4% (14.4ms) | Samples: 0

**Called by:**
- `group` (9)

**Calls:**
- `validateNodeSerialization` (8)
- `validateNodeSerialization` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1128` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `finite` (1)

### `normalizeMermaidSourceWithOverrides`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:762` | Self: 0.0% (0us) | Total: 0.3% (11.6ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (6)

**Calls:**
- `normalizeSource` (1)
- `normalizeSource` (1)
- `normalizeSource` (1)
- `normalizeMermaidSource` (1)
- `normalizeSource` (1)
- `normalizeMermaidSource` (1)

### `createExtensionIdentity`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:246` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `evaluateExtensionCompatibility` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:208` | Self: 0.0% (0us) | Total: 2.0% (70.0ms) | Samples: 0

**Called by:**
- `visit` (29)
- `visit` (20)

**Calls:**
- `leaf` (21)
- `leaf` (7)
- `leaf` (6)
- `leaf` (5)
- `leaf` (3)
- `leaf` (2)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)

### `nativePlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1137` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `resolveRoleStyle` (2)
- `resolveRoleStyle` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1394` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `nativeCandidate` (2)

**Calls:**
- `filter` (1)
- `(anonymous)` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:171` | Self: 0.0% (0us) | Total: 0.2% (9.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (7)

**Calls:**
- `group` (6)
- `group` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:8` | Self: 0.0% (0us) | Total: 0.3% (12.0ms) | Samples: 0

**Called by:**
- `anonymous` (8)

**Calls:**
- `bound require` (8)

### `semanticIdentityForSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:60` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `decodeWithTrie` (1)

### `semanticIdentityForSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:57` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `attr` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1576` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `snapshotFamilyIdentity` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:127` | Self: 0.0% (0us) | Total: 1.1% (40.5ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (31)

**Calls:**
- `connector` (4)
- `connector` (3)
- `connector` (2)
- `connector` (2)
- `connector` (2)
- `connector` (2)
- `connector` (2)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:803` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (3)

**Calls:**
- `hooks` (3)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:291` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `extractErLayout` (1)

**Calls:**
- `resolveRoleStyle` (1)

### `segmentThroughShape`
`/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:174` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `some` (1)

**Calls:**
- `min` (1)

### `layout`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:23` | Self: 0.0% (0us) | Total: 0.5% (19.5ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (13)

**Calls:**
- `parseErDiagram` (10)
- `parseErDiagram` (1)
- `parseErDiagram` (1)
- `parseErDiagram` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:608` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `fieldJsonSchema` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:27` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `has`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:10` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `qualify` (1)

**Calls:**
- `apply` (1)

### `inspectOwnedSvgOnce`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:44` | Self: 0.0% (0us) | Total: 0.1% (4.6ms) | Samples: 0

**Called by:**
- `applyOutputSecurityPolicy` (1)

**Calls:**
- `has` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:689` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `sameRectanglePaint` (1)
- `sameRectanglePaint` (1)

### `nativeCandidate`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1115` | Self: 0.0% (0us) | Total: 8.3% (291.1ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (186)

**Calls:**
- `finish` (42)
- `(anonymous)` (36)
- `finishErGeometry` (23)
- `finishErGeometry` (18)
- `finishErGeometry` (13)
- `finishErGeometry` (9)
- `finishErGeometry` (5)
- `finishErGeometry` (5)
- `finishErGeometry` (3)
- `finishErGeometry` (2)
- `finishErGeometry` (2)
- `finishErGeometry` (2)
- `finishErGeometry` (2)
- `finishErGeometry` (2)
- `finishErGeometry` (2)
- `finishErGeometry` (2)
- `finishErGeometry` (2)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:172` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `visit` (4)

**Calls:**
- `visit` (4)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:330` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `get receipt` (1)

**Calls:**
- `receiptOf` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:114` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `test` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1737` | Self: 0.0% (0us) | Total: 0.3% (11.6ms) | Samples: 0

**Called by:**
- `measureRenderStage` (6)

**Calls:**
- `normalizeMermaidSourceWithOverrides` (6)

### `stripMermaidDirectives`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:93` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `mermaidFirstLine` (1)

**Calls:**
- `replace` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:416` | Self: 0.0% (0us) | Total: 0.0% (989us) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `copyDataProperties` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `serializeSceneNode` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:156` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `paintPrimitiveSource` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/default-backend.ts:5` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `registerBuiltInBackend` (1)

### `applyReplacements`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:242` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveSvgColors` (1)

**Calls:**
- `slice` (1)

### `rejectUnknownKeys`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:153` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `validateMarkAttributes` (1)

**Calls:**
- `keys` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:314` | Self: 0.0% (0us) | Total: 0.0% (971us) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `relationAccessibility` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:761` | Self: 0.0% (0us) | Total: 0.1% (4.6ms) | Samples: 0

**Called by:**
- `write` (2)

**Calls:**
- `get` (2)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:581` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (2)

**Calls:**
- `attribute` (2)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1582` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `snapshotDescriptorArray` (1)

### `svgStyleRanges`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:294` | Self: 0.0% (0us) | Total: 0.2% (7.2ms) | Samples: 0

**Called by:**
- `scopeSvgStyles` (5)

**Calls:**
- `scanStartTags` (4)
- `scanStartTags` (1)

### `nonPainting`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:130` | Self: 0.0% (0us) | Total: 0.1% (4.6ms) | Samples: 0

**Called by:**
- `leaf` (3)

**Calls:**
- `some` (2)
- `textPaints` (1)

### `normalizeCssObfuscation`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:29` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `unsafeCssReferences` (1)

**Calls:**
- `replace` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:560` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `validateNode` (3)

**Calls:**
- `validateGeometry` (2)
- `validateGeometry` (1)

### `evaluateExtensionCompatibility`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:110` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `createExtensionIdentity` (1)

**Calls:**
- `isSupportedSemVerRange` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:328` | Self: 0.0% (0us) | Total: 0.5% (18.9ms) | Samples: 0

**Called by:**
- `get receipt` (10)

**Calls:**
- `renderedSvgDigest` (5)
- `canonicalTextDigest` (5)

### `captureNativeGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:94` | Self: 0.0% (0us) | Total: 0.1% (4.1ms) | Samples: 0

**Called by:**
- `groupValidation` (3)

**Calls:**
- `checkInertGroup` (3)

### `rejectUnknownKeys`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:154` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `validateMarkAttributes` (1)

**Calls:**
- `has` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/encode-html.js:10` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Calls:**
- `parseEncodeTrie` (1)

### `snapshot`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1318` | Self: 0.0% (0us) | Total: 0.3% (12.7ms) | Samples: 0

**Called by:**
- `finishErGeometry` (7)

**Calls:**
- `flatIntoArrayWithCallback` (7)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:213` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `validateGeometry` (1)

**Calls:**
- `commandAtCursor` (1)

### `readErStatement`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:298` | Self: 0.0% (0us) | Total: 0.2% (7.0ms) | Samples: 0

**Called by:**
- `readErOuterStatements` (4)

**Calls:**
- `parseErRelationshipSyntax` (2)
- `parseErRelationshipSyntax` (1)
- `parseErRelationshipSyntax` (1)

### `findErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:698` | Self: 0.0% (0us) | Total: 0.2% (8.3ms) | Samples: 0

**Called by:**
- `readErStatements` (5)

**Calls:**
- `readErOuterStatements` (5)

### `enoughLead`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:300` | Self: 0.0% (0us) | Total: 0.2% (8.6ms) | Samples: 0

**Called by:**
- `repairErFrameRoutes` (2)
- `repairErFrameRoutes` (2)

**Calls:**
- `erCardinalityInk` (3)
- `erCardinalityInk` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1029` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `write` (2)

**Calls:**
- `validatePoint` (1)
- `validatePoint` (1)

### `deriveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:517` | Self: 0.0% (0us) | Total: 0.0% (966us) | Samples: 0

**Called by:**
- `resolveColors` (1)

**Calls:**
- `ensureContrast` (1)

### `parseErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:832` | Self: 0.0% (0us) | Total: 0.4% (15.3ms) | Samples: 0

**Called by:**
- `layout` (10)

**Calls:**
- `readErStatements` (7)
- `readErStatements` (1)
- `readErStatements` (1)
- `readErStatements` (1)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:93` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `materializeText` (1)

**Calls:**
- `pay` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:56` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `formatSvgNumericAttribute` (1)

**Calls:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:14` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Calls:**
- `bound require` (2)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:312` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `connectorInlineLabelText` (1)

### `ensureContrast`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:120` | Self: 0.0% (0us) | Total: 0.0% (966us) | Samples: 0

**Called by:**
- `deriveColors` (1)

**Calls:**
- `mixedChannels` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1472` | Self: 0.0% (0us) | Total: 6.0% (212.6ms) | Samples: 0

**Called by:**
- `serialize` (128)

**Calls:**
- `serializeSceneNode` (119)
- `serializeSceneNode` (4)
- `serializeSceneNode` (3)
- `serializeSceneNode` (1)
- `serializeSceneNode` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:144` | Self: 0.0% (0us) | Total: 0.0% (999us) | Samples: 0

**Calls:**
- `deepFreeze` (1)

### `applyReplacements`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:233` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `resolveSvgColors` (2)

**Calls:**
- `sort` (2)

### `backendSupportsCapability`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1378` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `filter` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:279` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `(anonymous)` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:247` | Self: 0.0% (0us) | Total: 2.9% (103.0ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (70)

**Calls:**
- `inspectPaint` (67)
- `finish` (2)
- `inspectPaint` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:145` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (3)

**Calls:**
- `parts` (1)
- `parts` (1)
- `parts` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:601` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `contrastRatio`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:84` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `ensureContrast` (2)

**Calls:**
- `srgbRelativeLuminance` (1)
- `relativeLuminance` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:125` | Self: 0.0% (0us) | Total: 0.1% (6.1ms) | Samples: 0

**Called by:**
- `copyInner` (4)
- `leaf` (1)

**Calls:**
- `deferredTerminalProjectionInput` (4)
- `deferredTerminalProjectionInput` (1)

### `terminalEndpoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:66` | Self: 0.0% (0us) | Total: 0.0% (994us) | Samples: 0

**Called by:**
- `deriveConnectorTerminalProjection` (1)

**Calls:**
- `optional` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/agent/families.ts:8` | Self: 0.0% (0us) | Total: 2.8% (100.6ms) | Samples: 0

**Calls:**
- `installBuiltinFamily` (11)
- `installBuiltinFamily` (11)
- `installBuiltinFamily` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:158` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `visitSvgStartTagsFresh` (1)

**Calls:**
- `xmlSlice` (1)

### `nativePlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1154` | Self: 0.0% (0us) | Total: 0.1% (6.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `flatIntoArrayWithCallback` (3)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `map` (5)

**Calls:**
- `cloneValue` (3)
- `map` (2)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:49` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `stringify` (1)

### `projectErPositioned`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:25` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `map` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1049` | Self: 0.0% (0us) | Total: 0.0% (966us) | Samples: 0

**Called by:**
- `report` (1)

**Calls:**
- `verifyNoExternalRefs` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:34` | Self: 0.0% (0us) | Total: 0.3% (11.1ms) | Samples: 0

**Called by:**
- `build` (4)
- `(anonymous)` (3)

**Calls:**
- `chargeInkSort` (5)
- `chargeInkSort` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:5` | Self: 0.0% (0us) | Total: 0.3% (11.4ms) | Samples: 0

**Called by:**
- `anonymous` (8)

**Calls:**
- `bound require` (8)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/decode-data-html.js:3` | Self: 0.0% (0us) | Total: 1.8% (63.9ms) | Samples: 0

**Calls:**
- `decodeBase64` (1)
- `decodeBase64` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:167` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `projectSvgCss` (1)

**Calls:**
- `sourceIndexOf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:151` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (1)

**Calls:**
- `slice` (1)

### `markerTerminalDepth`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:294` | Self: 0.0% (0us) | Total: 4.7% (167.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (7)
- `(anonymous)` (1)

**Calls:**
- `markerBoundsAt` (4)
- `markerBoundsAt` (3)
- `pointsBounds` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:139` | Self: 0.0% (0us) | Total: 0.0% (994us) | Samples: 0

**Called by:**
- `validateConnectorProjectionConsistency` (1)

**Calls:**
- `terminalEndpoint` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:140` | Self: 0.0% (0us) | Total: 0.4% (15.0ms) | Samples: 0

**Called by:**
- `svgStyleRanges` (4)
- `visitSvgFirstTagAttributes` (2)
- `projectSvgCss` (2)
- `visitSvgStartTagsFresh` (2)

**Calls:**
- `scanTagEnd` (8)
- `scanTagEnd` (1)
- `scanTagEnd` (1)

### `normalizeMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:659` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `nativeAccessibilityEdits` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1245` | Self: 0.0% (0us) | Total: 0.8% (30.8ms) | Samples: 0

**Called by:**
- `map` (20)

**Calls:**
- `erCardinalityInk` (13)
- `erCardinalityInk` (5)
- `erCardinalityInk` (2)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:484` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `paintAttribute` (1)
- `geometryAttributes` (1)

**Calls:**
- `escapeAttr` (2)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:313` | Self: 0.0% (0us) | Total: 0.1% (5.9ms) | Samples: 0

**Called by:**
- `extractErLayout` (2)

**Calls:**
- `enoughLead` (2)

### `gzipSync`
`node:zlib:360` | Self: 0.0% (0us) | Total: 0.1% (6.9ms) | Samples: 0

**Called by:**
- `(module)` (4)

**Calls:**
- `Gzip` (4)

### `value`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:128` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `nativeGroup` (1)

**Calls:**
- `defineProperty` (1)

### `r`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 16.0% (563.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `o` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/resolve-block-map.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:116` | Self: 0.0% (0us) | Total: 0.2% (7.0ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (2)

**Calls:**
- `flatIntoArrayWithCallback` (1)
- `flatMap` (1)

### `erRelationshipBlock`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:19` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `erFrameInkPadding` (1)
- `(anonymous)` (1)

**Calls:**
- `resolveRoleStyle` (1)
- `resolveRoleStyle` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:94` | Self: 0.0% (0us) | Total: 0.7% (25.3ms) | Samples: 0

**Called by:**
- `inspectPaint` (20)

**Calls:**
- `leaf` (20)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/gantt/dependency-paint.ts:16` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `node:zlib`
`node:zlib:2` | Self: 0.0% (0us) | Total: 0.3% (13.7ms) | Samples: 0

**Calls:**
- `anonymous` (8)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:641` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (2)

**Calls:**
- `freeze` (2)

### `renderOptionsAdmissionMessages`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:403` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `validateJsonConfigAdmission` (1)

### `nativePlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1163` | Self: 0.0% (0us) | Total: 0.6% (23.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (18)

**Calls:**
- `measureRenderStage` (18)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1356` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `nativeCandidate` (2)

**Calls:**
- `find` (2)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1480` | Self: 0.0% (0us) | Total: 0.1% (3.9ms) | Samples: 0

**Called by:**
- `serialize` (3)

**Calls:**
- `consumeStringBudget` (2)
- `consumeStringBudget` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:729` | Self: 0.0% (0us) | Total: 1.3% (47.9ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (32)

**Calls:**
- `renderMultilineText` (12)
- `renderMultilineText` (6)
- `renderMultilineText` (4)
- `renderMultilineText` (3)
- `renderMultilineText` (2)
- `renderMultilineText` (1)
- `renderMultilineText` (1)
- `renderMultilineText` (1)
- `renderMultilineText` (1)
- `renderMultilineText` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:760` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `ownedTextPaintRoster` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1507` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `drawNative` (2)

**Calls:**
- `validateAggregateReferences` (2)

### `internal:streams/compose`
`internal:streams/compose:2` | Self: 0.0% (0us) | Total: 0.2% (9.1ms) | Samples: 0

**Called by:**
- `anonymous` (6)

**Calls:**
- `anonymous` (6)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:5` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `(anonymous)` (2)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:277` | Self: 0.0% (0us) | Total: 0.1% (3.8ms) | Samples: 0

**Called by:**
- `writeTextSvg` (3)

**Calls:**
- `(anonymous)` (2)
- `(anonymous)` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1766` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `add` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:833` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `finite` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:258` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `map` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1584` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `snapshotDescriptorArray` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1357` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `nativeCandidate` (3)

**Calls:**
- `filter` (2)
- `get` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:195` | Self: 0.0% (0us) | Total: 0.5% (19.8ms) | Samples: 0

**Called by:**
- `renderEntityBox` (6)
- `renderEntityBox` (3)

**Calls:**
- `resolvedColorValue` (8)
- `resolvedColorValue` (1)

### `numericStrokeWidth`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:196` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `parseFloat` (1)

### `measureText`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:188` | Self: 0.0% (0us) | Total: 0.1% (6.1ms) | Samples: 0

**Called by:**
- `measureTextWidth` (4)

**Calls:**
- `getCharWidth` (2)
- `getCharWidth` (1)
- `getCharWidth` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:9` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1473` | Self: 0.0% (0us) | Total: 0.4% (16.7ms) | Samples: 0

**Called by:**
- `serialize` (11)

**Calls:**
- `boundedUtf8ByteLength` (10)
- `boundedUtf8ByteLength` (1)

### `runMeasuredGraphBackend`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:73` | Self: 0.0% (0us) | Total: 8.3% (291.1ms) | Samples: 0

**Called by:**
- `layout` (186)

**Calls:**
- `nativeCandidate` (186)

### `projectErPositioned`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:11` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `map` (2)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:436` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `copyDataProperties` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:11` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:563` | Self: 0.0% (0us) | Total: 0.2% (8.8ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (4)

**Calls:**
- `(anonymous)` (4)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:585` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `(anonymous)` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:754` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `map` (1)

### `internal:fs/streams`
`internal:fs/streams:2` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1520` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `nativeCandidate` (2)

**Calls:**
- `intersects` (1)
- `intersects` (1)

### `bound require`
`[native code]` | Self: 0.0% (0us) | Total: 10.4% (365.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (19)
- `(anonymous)` (9)
- `(anonymous)` (8)
- `(anonymous)` (8)
- `(anonymous)` (8)
- `(anonymous)` (8)
- `(anonymous)` (7)
- `(anonymous)` (4)
- `(anonymous)` (4)
- `(anonymous)` (4)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

**Calls:**
- `require` (124)

### `intersects`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1216` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `finishErGeometry` (1)

**Calls:**
- `erCharge` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:100` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `shape` (1)

**Calls:**
- `typedIdentity` (1)

### `consume`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:15` | Self: 0.0% (0us) | Total: 0.9% (33.5ms) | Samples: 0

**Called by:**
- `(module)` (16)

**Calls:**
- `stringify` (16)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:719` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `leaf` (6)

**Calls:**
- `replaceField` (2)
- `replaceField` (2)
- `replaceField` (1)
- `replaceField` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1783` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `measureRenderStage` (2)

**Calls:**
- `resolveExecutionPlan` (1)
- `resolveExecutionPlan` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:33` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `scopeSvgStyles` (1)

**Calls:**
- `imul` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1944` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `connectorMarkerPaintRegions` (1)

### `renderCardinality`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:590` | Self: 0.0% (0us) | Total: 2.1% (76.0ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (47)

**Calls:**
- `crowsFootMark` (22)
- `group` (10)
- `group` (6)
- `group` (2)
- `group` (1)
- `group` (1)
- `crowsFootMark` (1)
- `group` (1)
- `group` (1)
- `group` (1)
- `group` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1037` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `hasOwn` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:609` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `validateGeometry` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1569` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `(anonymous)` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:135` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `hasOwn` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/journey/config-diagnostics.ts:7` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Calls:**
- `map` (1)

### `validateStyleSpec`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:472` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (1)

**Calls:**
- `safeCssToken` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:195` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `renderCardinality` (2)

**Calls:**
- `join` (2)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:107` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (1)

**Calls:**
- `connectorTerminalStrokeLosses` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1355` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Calls:**
- `map` (1)

### `require`
`[native code]` | Self: 0.0% (0us) | Total: 10.4% (365.8ms) | Samples: 0

**Called by:**
- `bound require` (124)

**Calls:**
- `anonymous` (124)

### `connectorInlineLabelSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:781` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `renderMultilineText` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:701` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `assignPorts` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/er/creation.ts:115` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `readErStatements` (1)

**Calls:**
- `ownerOf` (1)

### `admitSceneDocumentWith`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:268` | Self: 0.0% (0us) | Total: 0.2% (9.6ms) | Samples: 0

**Called by:**
- `render` (4)

**Calls:**
- `visit` (2)
- `snapshotBoundedExternalData` (1)
- `visit` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1185` | Self: 0.0% (0us) | Total: 1.9% (68.2ms) | Samples: 0

**Called by:**
- `nativeCandidate` (42)

**Calls:**
- `extractErLayout` (32)
- `extractErLayout` (3)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts:3` | Self: 0.0% (0us) | Total: 0.1% (6.7ms) | Samples: 0

**Calls:**
- `Segmenter` (2)

### `Gzip`
`node:zlib:328` | Self: 0.0% (0us) | Total: 0.1% (6.9ms) | Samples: 0

**Called by:**
- `gzipSync` (4)

**Calls:**
- `Zlib` (4)

### `attachSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:495` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `canonicalizeSceneNodeSerialization` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/hybrid-backend.ts:193` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `createSketchBackend` (1)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:476` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `diagramColorVariables` (2)

**Calls:**
- `deriveColors` (1)
- `deriveColors` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:527` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `text` (1)

**Calls:**
- `map` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:672` | Self: 0.0% (0us) | Total: 5.8% (206.0ms) | Samples: 0

**Called by:**
- `leaf` (138)

**Calls:**
- `serialize` (138)

### `admitSceneDocumentWith`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:271` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `render` (1)

**Calls:**
- `recordAdmittedScene` (1)

### `semanticIdentityForSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:56` | Self: 0.0% (0us) | Total: 0.4% (14.1ms) | Samples: 0

**Called by:**
- `group` (8)

**Calls:**
- `filter` (4)
- `split` (2)
- `decodeWithTrie` (1)
- `attr` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:199` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `group` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/terminal-contract.ts:29` | Self: 0.0% (0us) | Total: 0.1% (6.4ms) | Samples: 0

**Calls:**
- `Set` (1)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1608` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (1)

**Calls:**
- `sceneValidationMode` (1)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:95` | Self: 0.0% (0us) | Total: 0.7% (25.3ms) | Samples: 0

**Called by:**
- `materializeText` (10)
- `copyInner` (7)

**Calls:**
- `materializeText` (10)
- `materializeText` (5)
- `materializeText` (1)
- `materializeText` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/omap.js:7` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:112` | Self: 0.0% (0us) | Total: 0.2% (8.7ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (3)

**Calls:**
- `erCardinalityInk` (2)
- `erCardinalityInk` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:736` | Self: 0.0% (0us) | Total: 0.5% (17.6ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (10)

**Calls:**
- `issue` (8)
- `issue` (1)
- `issue` (1)

### `renderCardinality`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:589` | Self: 0.0% (0us) | Total: 1.4% (52.3ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (36)

**Calls:**
- `crowsFootMark` (12)
- `group` (9)
- `group` (4)
- `group` (3)
- `group` (2)
- `crowsFootMark` (1)
- `group` (1)
- `group` (1)
- `group` (1)
- `group` (1)
- `group` (1)

### `internal:errors`
`internal:errors:2` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:712` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `cloneObject` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/architecture/markers.ts:16` | Self: 0.0% (0us) | Total: 4.5% (159.7ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (3)

### `canonicalJson`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1097` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `stringify` (1)

### `textTones`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:545` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `deriveColors` (1)

**Calls:**
- `legibleOnEvery` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:15` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1267` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (2)

**Calls:**
- `validateConnectorProjectionConsistency` (1)
- `validateConnectorProjectionConsistency` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1319` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `map` (2)

**Calls:**
- `glyphBox` (2)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:201` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `preventExtensions` (1)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:98` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `leaf` (3)

**Calls:**
- `every` (3)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:219` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `finish` (2)

### `relationAccessibility`
`/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `text` (1)
- `shape` (1)

**Calls:**
- `sceneRoleTraits` (2)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:575` | Self: 0.0% (0us) | Total: 6.0% (211.3ms) | Samples: 0

**Called by:**
- `write` (119)
- `validateNodeSerialization` (5)
- `drawn` (4)
- `(anonymous)` (1)

**Calls:**
- `writeTextSvg` (32)
- `writeShapeSvg` (13)
- `writeTextSvg` (11)
- `writeConnectorSvg` (11)
- `writeTextSvg` (10)
- `writeShapeSvg` (10)
- `writeTextSvg` (5)
- `writeShapeSvg` (4)
- `writeConnectorSvg` (3)
- `join` (3)
- `writeShapeSvg` (2)
- `issue` (2)
- `writeShapeSvg` (2)
- `writeTextSvg` (2)
- `writeSceneNode` (2)
- `writeShapeSvg` (1)
- `writeStructuredSceneNode` (1)
- `writeConnectorSvg` (1)
- `writeConnectorSvg` (1)
- `writeShapeSvg` (1)
- `finishXmlLeaf` (1)
- `writeTextSvg` (1)
- `writeShapeSvg` (1)
- `writeConnectorSvg` (1)
- `writeTextSvg` (1)
- `writeTextSvg` (1)
- `writeTextSvg` (1)
- `writeSceneNode` (1)
- `writeTextSvg` (1)
- `writeConnectorSvg` (1)
- `writeConnectorSvg` (1)
- `writeConnectorSvg` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `filter` (1)

### `connectorProjectedField`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:486` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `visibleSketchProjection` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/createNode.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:153` | Self: 0.0% (0us) | Total: 0.1% (3.6ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (2)

**Calls:**
- `isWhitespace` (2)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:275` | Self: 0.0% (0us) | Total: 0.5% (19.6ms) | Samples: 0

**Called by:**
- `writeTextSvg` (12)

**Calls:**
- `renderPreparedLine` (4)
- `renderPreparedLine` (3)
- `advanceAttrs` (1)
- `renderDisplayRuns` (1)
- `renderPreparedLine` (1)
- `renderDisplayRuns` (1)
- `advanceAttrs` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:817` | Self: 0.0% (0us) | Total: 0.2% (7.0ms) | Samples: 0

**Called by:**
- `write` (5)

**Calls:**
- `validatePaint` (2)
- `validatePaint` (2)
- `validatePaint` (1)

### `layoutErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1128` | Self: 0.0% (0us) | Total: 0.7% (25.5ms) | Samples: 0

**Called by:**
- `layout` (19)

**Calls:**
- `measureErEntities` (17)
- `measureErEntities` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:14` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `f` (1)

### `transformSvgCssValues`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:308` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `resolveSvgColors` (4)

**Calls:**
- `map` (4)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1148` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `boundedString` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:382` | Self: 0.0% (0us) | Total: 0.0% (979us) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `xmlHasColon` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:108` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `shape` (1)

**Calls:**
- `copyDataProperties` (1)

### `collides`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:173` | Self: 0.0% (0us) | Total: 0.3% (12.4ms) | Samples: 0

**Called by:**
- `placeRelationshipLabels` (8)

**Calls:**
- `(anonymous)` (6)
- `(anonymous)` (2)

### `executeInspectedGraphicalRequest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:297` | Self: 0.0% (0us) | Total: 0.7% (26.7ms) | Samples: 0

**Called by:**
- `withSvgInspectionCache` (18)

**Calls:**
- `measureRenderStage` (18)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1558` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `terminalDepth` (1)

### `findIndex`
`[native code]` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `graphicalBackendCapabilityClaims` (1)

**Calls:**
- `(anonymous)` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:13` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `freeze` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:142` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (3)

**Calls:**
- `projectErPositioned` (2)
- `projectErPositioned` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:184` | Self: 0.0% (0us) | Total: 0.4% (14.3ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (12)

**Calls:**
- `join` (12)

### `internal:stream`
`internal:stream:2` | Self: 0.0% (0us) | Total: 0.3% (10.5ms) | Samples: 0

**Called by:**
- `anonymous` (7)

**Calls:**
- `anonymous` (7)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:464` | Self: 0.0% (0us) | Total: 0.1% (3.7ms) | Samples: 0

**Called by:**
- `createFixture` (1)
- `connector` (1)
- `createFixture` (1)

**Calls:**
- `setConnectorTerminalProjection` (2)
- `setConnectorTerminalProjection` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1460` | Self: 0.0% (0us) | Total: 0.1% (3.5ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `hasSceneWriteEmissionOccurrence` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1031` | Self: 0.0% (0us) | Total: 0.9% (34.0ms) | Samples: 0

**Called by:**
- `report` (23)

**Calls:**
- `rendered` (23)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:689` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `set` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:722` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `paintAttributes` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:659` | Self: 0.0% (0us) | Total: 0.2% (8.8ms) | Samples: 0

**Called by:**
- `geometryAttributes` (4)

**Calls:**
- `inertRectangleRecord` (2)
- `inertRectangleRecord` (2)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:203` | Self: 0.0% (0us) | Total: 0.3% (13.7ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (9)

**Calls:**
- `collides` (8)
- `collides` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:237` | Self: 0.0% (0us) | Total: 0.7% (25.3ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (19)

**Calls:**
- `toneOnFill` (6)
- `toneOnFill` (6)
- `toneOnFill` (4)
- `toneOnFill` (2)
- `toneOnFill` (1)

### `inspectSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:673` | Self: 0.0% (0us) | Total: 0.0% (966us) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `startTags` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:126` | Self: 0.0% (0us) | Total: 0.5% (19.5ms) | Samples: 0

**Called by:**
- `renderEntityBox` (8)
- `renderEntityBox` (3)
- `renderRelationshipLabel` (2)

**Calls:**
- `text` (3)
- `text` (3)
- `text` (2)
- `text` (1)
- `text` (1)
- `text` (1)
- `text` (1)
- `text` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:85` | Self: 0.0% (0us) | Total: 1.6% (56.5ms) | Samples: 0

**Called by:**
- `inspectPaint` (37)

**Calls:**
- `visit` (31)
- `visit` (3)
- `visit` (2)
- `visit` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:411` | Self: 0.0% (0us) | Total: 0.2% (9.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `add` (2)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:145` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (1)

**Calls:**
- `map` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:146` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `ownsParts` (1)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:218` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `validateGeometry` (1)

**Calls:**
- `skipSeparators` (1)

### `toHex`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:44` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `toneOnFill` (1)

**Calls:**
- `join` (1)

### `receiptOf`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:757` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:156` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (2)

**Calls:**
- `appendPrivate` (2)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:111` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `test` (1)

### `snapshotCapabilityCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1559` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `snapshotDescriptorArray` (1)

**Calls:**
- `snapshotDescriptorArray` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` | Self: 0.0% (0us) | Total: 0.1% (5.7ms) | Samples: 0

**Called by:**
- `markerTerminalDepth` (3)

**Calls:**
- `geometryBounds` (1)
- `pathBounds` (1)
- `pathBounds` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:617` | Self: 0.0% (0us) | Total: 0.3% (12.4ms) | Samples: 0

**Called by:**
- `group` (8)

**Calls:**
- `ensureSvgIdentity` (6)
- `canonicalizeSceneNodeSerialization` (1)
- `ensureSvgIdentity` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:489` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `paintAttribute` (1)

**Calls:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/lexer.js:84` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `Set` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:96` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `shortenMeasuredRoutes` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:218` | Self: 0.0% (0us) | Total: 0.0% (992us) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `has` (1)

### `validateStyleSpec`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:445` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (1)

**Calls:**
- `numberIsValid` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:197` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (2)

**Calls:**
- `escapeDisplayAttr` (1)
- `escapeDisplayAttr` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:424` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `measureErEntities` (2)

**Calls:**
- `qualify` (1)
- `qualify` (1)

### `Zlib`
`node:zlib:298` | Self: 0.0% (0us) | Total: 0.1% (6.9ms) | Samples: 0

**Called by:**
- `Gzip` (4)

**Calls:**
- `ZlibBase` (3)
- `init` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:125` | Self: 0.0% (0us) | Total: 0.6% (24.4ms) | Samples: 0

**Called by:**
- `renderEntityBox` (4)
- `crowsFootMark` (4)
- `renderEntityBox` (3)
- `renderEntityBox` (2)

**Calls:**
- `shape` (3)
- `shape` (2)
- `shape` (2)
- `shape` (1)
- `shape` (1)
- `shape` (1)
- `shape` (1)
- `shape` (1)
- `shape` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:3` | Self: 0.0% (0us) | Total: 0.7% (27.1ms) | Samples: 0

**Calls:**
- `bound require` (19)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:821` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `write` (2)

**Calls:**
- `forEach` (2)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:215` | Self: 0.0% (0us) | Total: 2.4% (87.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (44)

**Calls:**
- `leaf` (41)
- `shape` (3)

### `applyOutputSecurityPolicy`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:727` | Self: 0.0% (0us) | Total: 4.7% (167.0ms) | Samples: 0

**Called by:**
- `measureRenderStage` (80)
- `validateSceneDocument` (4)
- `runBackendConformance` (1)

**Calls:**
- `inspectOwnedSvgOnce` (84)
- `inspectOwnedSvgOnce` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1131` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `receiptOf` (1)

**Calls:**
- `canonicalJson` (1)

### `renderRelationshipLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:534` | Self: 0.0% (0us) | Total: 0.2% (9.0ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (7)

**Calls:**
- `leaf` (7)

### `flatIntoArrayWithCallback`
`[native code]` | Self: 0.0% (0us) | Total: 2.1% (75.1ms) | Samples: 0

**Called by:**
- `finishErGeometry` (13)
- `snapshot` (7)
- `placeRelationshipLabels` (6)
- `finishErGeometry` (5)
- `nativePlacement` (3)
- `finishErGeometry` (2)
- `connectorPaintBounds` (1)
- `connectorPaintBounds` (1)
- `resolveExecutionPlan` (1)
- `extractErLayout` (1)
- `placeRelationshipLabels` (1)
- `extractErLayout` (1)
- `(anonymous)` (1)

**Calls:**
- `map` (24)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `flatIntoArray` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:665` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:605` | Self: 0.0% (0us) | Total: 0.1% (6.6ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (6)

**Calls:**
- `attribute` (6)

### `Transform`
`internal:streams/transform:21` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `ZlibBase` (1)

**Calls:**
- `(anonymous)` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:810` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `assessFamilyLayout`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:235` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `assessRenderedLayoutHardViolations` (1)

**Calls:**
- `checkRect` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:380` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `xmlSlice` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1322` | Self: 0.0% (0us) | Total: 0.4% (15.4ms) | Samples: 0

**Called by:**
- `nativeCandidate` (9)

**Calls:**
- `snapshot` (7)
- `snapshot` (2)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:80` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (3)

**Calls:**
- `leaf` (1)
- `ownFragment` (1)
- `documentOpen` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:137` | Self: 0.0% (0us) | Total: 3.7% (131.4ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (85)

**Calls:**
- `renderCardinality` (47)
- `renderCardinality` (36)
- `push` (1)
- `renderCardinality` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1224` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `write` (3)

**Calls:**
- `deferredTerminalProjectionInput` (3)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:875` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `write` (2)

**Calls:**
- `validatePaint` (1)
- `validatePaint` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 64.3% (2.25s) | Samples: 0

**Called by:**
- `(anonymous)` (2)
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (2)
- `r` (1)
- `o` (1)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:397` | Self: 0.0% (0us) | Total: 0.1% (3.9ms) | Samples: 0

**Called by:**
- `group` (3)

**Calls:**
- `value` (2)
- `value` (1)

### `measureErEntities`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:451` | Self: 0.0% (0us) | Total: 0.6% (21.3ms) | Samples: 0

**Called by:**
- `layoutErDiagram` (17)

**Calls:**
- `preparePixelText` (6)
- `preparePixelText` (4)
- `preparePixelText` (2)
- `preparePixelText` (2)
- `preparePixelText` (1)
- `preparePixelText` (1)
- `preparePixelText` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:8` | Self: 0.0% (0us) | Total: 0.3% (11.4ms) | Samples: 0

**Called by:**
- `anonymous` (8)

**Calls:**
- `bound require` (8)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:150` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `copyDataProperties` (1)

### `graphicalBackendCapabilityClaims`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:249` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `map` (1)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:49` | Self: 0.0% (0us) | Total: 1.5% (52.7ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `some` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1773` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `some` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:296` | Self: 0.0% (0us) | Total: 0.4% (16.4ms) | Samples: 0

**Called by:**
- `extractErLayout` (8)

**Calls:**
- `map` (8)

### `label`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1492` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `box` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:509` | Self: 0.0% (0us) | Total: 0.2% (8.1ms) | Samples: 0

**Called by:**
- `group` (6)

**Calls:**
- `nativeGroup` (3)
- `nativeGroup` (1)
- `nativeGroup` (1)
- `nativeGroup` (1)

### `processChunkSync`
`node:zlib:203` | Self: 0.0% (0us) | Total: 0.2% (9.6ms) | Samples: 0

**Called by:**
- `zlibBufferSync` (5)

**Calls:**
- `writeSync` (5)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:204` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `retainTextPaintPresence` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:317` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `drawNative` (2)

**Calls:**
- `freeze` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:760` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `write` (3)

**Calls:**
- `boundedString` (2)
- `boundedString` (1)

### `semanticIdentityForSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:62` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `copyDataProperties` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:115` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:636` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `withDeferredTerminalProjections`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:16` | Self: 0.0% (0us) | Total: 30.5% (1.07s) | Samples: 0

**Called by:**
- `drawNative` (652)

**Calls:**
- `lowerErDrawing` (376)
- `lowerErDrawing` (147)
- `lowerErDrawing` (85)
- `lowerErDrawing` (36)
- `lowerErDrawing` (3)
- `lowerErDrawing` (2)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:148` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `get` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:761` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `resolveCss` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1008` | Self: 0.0% (0us) | Total: 0.3% (13.8ms) | Samples: 0

**Called by:**
- `report` (6)

**Calls:**
- `drawn` (6)

### `textTransform`
`/tmp/pr449-main-integration-20261029-762/src/styles.ts:242` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `resolveRenderStyle` (1)

**Calls:**
- `finiteString` (1)

### `o`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 32.1% (1.12s) | Samples: 0

**Called by:**
- `r` (1)
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:3` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `bound require` (1)
- `(anonymous)` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:191` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `serializeMarkerResource` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6538` | Self: 0.0% (0us) | Total: 16.0% (563.0ms) | Samples: 0

**Called by:**
- `o` (1)

**Calls:**
- `(anonymous)` (1)

### `setConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:59` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `install` (1)

### `paintAttribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:493` | Self: 0.0% (0us) | Total: 0.4% (14.9ms) | Samples: 0

**Called by:**
- `paintAttributes` (7)
- `paintAttributes` (1)

**Calls:**
- `attribute` (5)
- `attribute` (1)
- `attribute` (1)
- `attribute` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1882` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `builtinFamilyConformanceReport` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:627` | Self: 0.0% (0us) | Total: 1.5% (54.2ms) | Samples: 0

**Called by:**
- `finish` (32)

**Calls:**
- `repairErFrameRoutes` (9)
- `repairErFrameRoutes` (8)
- `repairErFrameRoutes` (8)
- `repairErFrameRoutes` (2)
- `repairErFrameRoutes` (2)
- `repairErFrameRoutes` (1)
- `repairErFrameRoutes` (1)
- `repairErFrameRoutes` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1052` | Self: 0.0% (0us) | Total: 0.0% (961us) | Samples: 0

**Called by:**
- `report` (1)

**Calls:**
- `applyOutputSecurityPolicy` (1)

### `renderDisplayRuns`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:152` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `renderMultilineText` (1)

**Calls:**
- `every` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/util.js:7` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:300` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `sanitizeDisplayLines` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:25` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `forEach` (1)

**Calls:**
- `has` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1495` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `label` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:10` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `report`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:235` | Self: 0.0% (0us) | Total: 1.9% (67.4ms) | Samples: 0

**Called by:**
- `retainedNativeDrawing` (44)

**Calls:**
- `runBackendConformance` (23)
- `runBackendConformance` (9)
- `runBackendConformance` (6)
- `runBackendConformance` (3)
- `runBackendConformance` (1)
- `runBackendConformance` (1)
- `runBackendConformance` (1)

### `legibleOnEvery`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:559` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `textTones` (1)

**Calls:**
- `ensureContrast` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1728` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `measureRenderStage` (3)

**Calls:**
- `validateSerializableRenderOptions` (2)
- `validateSerializableRenderOptions` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:580` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `map` (1)

### `resolveRenderStyle`
`/tmp/pr449-main-integration-20261029-762/src/styles.ts:289` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `layoutErDiagram` (1)

**Calls:**
- `textTransform` (1)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:442` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `freeze` (1)

### `renderPreparedLine`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:178` | Self: 0.0% (0us) | Total: 0.2% (9.1ms) | Samples: 0

**Called by:**
- `renderMultilineText` (4)

**Calls:**
- `map` (4)

### `captureNativeGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:98` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `groupValidation` (1)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `typedIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:75` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `shape` (1)

**Calls:**
- `copyDataProperties` (1)

### `rendered`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:427` | Self: 0.0% (0us) | Total: 0.9% (34.0ms) | Samples: 0

**Called by:**
- `runBackendConformance` (23)

**Calls:**
- `render` (23)

### `hooks`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:507` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (3)

**Calls:**
- `attribute` (2)
- `attribute` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:646` | Self: 0.0% (0us) | Total: 0.4% (16.7ms) | Samples: 0

**Called by:**
- `leaf` (6)
- `erCardinalityInk` (2)

**Calls:**
- `geometryBounds` (2)
- `geometryBounds` (2)
- `geometryBounds` (1)
- `pathBounds` (1)
- `pathBounds` (1)
- `pathBounds` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:180` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `graphemes` (1)

### `contrastRatio`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:85` | Self: 0.0% (0us) | Total: 0.2% (9.2ms) | Samples: 0

**Called by:**
- `ensureContrast` (8)

**Calls:**
- `relativeLuminance` (7)
- `srgbRelativeLuminance` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:523` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `text` (1)

**Calls:**
- `relationAccessibility` (1)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:132` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:777` | Self: 0.0% (0us) | Total: 0.1% (3.7ms) | Samples: 0

**Called by:**
- `node` (1)

**Calls:**
- `record` (1)

### `projectSvgCss`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:287` | Self: 0.0% (0us) | Total: 1.0% (35.0ms) | Samples: 0

**Called by:**
- `colorResolution` (23)

**Calls:**
- `scanStartTags` (8)
- `scanStartTags` (5)
- `scanStartTags` (3)
- `scanStartTags` (3)
- `scanStartTags` (2)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `nativeOrEmulated`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:472` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:157` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `uncertain` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:560` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/util.js:5` | Self: 0.0% (0us) | Total: 0.1% (3.7ms) | Samples: 0

**Calls:**
- `bound require` (3)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:232` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `copyDataProperties` (1)

### `unsafeCssReferences`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:599` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `inspectAttributeSecurity` (1)

**Calls:**
- `normalizeCssObfuscation` (1)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1621` | Self: 0.0% (0us) | Total: 0.4% (14.7ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (12)

**Calls:**
- `validateNode` (4)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:162` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `visitSvgStartTagsFresh` (1)

**Calls:**
- `isWhitespace` (1)

### `erCardinalityInk`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:126` | Self: 0.0% (0us) | Total: 1.4% (49.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (13)
- `erCardinalityEnvelope` (9)
- `enoughLead` (3)
- `(anonymous)` (2)
- `(anonymous)` (1)

**Calls:**
- `paintBounds` (16)
- `paintBounds` (7)
- `paintBounds` (2)
- `paintBounds` (2)
- `paintBounds` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:31` | Self: 0.0% (0us) | Total: 54.2% (1.89s) | Samples: 0

**Calls:**
- `withPerformanceObserver` (1162)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:110` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `createNativePaintEmission` (1)

### `resolvedColorValue`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:601` | Self: 0.0% (0us) | Total: 0.6% (23.2ms) | Samples: 0

**Called by:**
- `toneOnFill` (8)
- `toneOnFill` (3)

**Calls:**
- `diagramColorVariables` (5)
- `diagramColorVariables` (2)
- `diagramColorVariables` (1)
- `diagramColorVariables` (1)
- `diagramColorVariables` (1)
- `diagramColorVariables` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:530` | Self: 0.0% (0us) | Total: 0.2% (9.7ms) | Samples: 0

**Called by:**
- `validateNode` (6)
- `validateNode` (1)

**Calls:**
- `svgPathDataProblem` (4)
- `svgPathDataProblem` (1)
- `svgPathDataProblem` (1)
- `svgPathDataProblem` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-doc.js:4` | Self: 0.0% (0us) | Total: 0.3% (12.0ms) | Samples: 0

**Called by:**
- `anonymous` (8)

**Calls:**
- `bound require` (8)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/util.js:3` | Self: 0.0% (0us) | Total: 5.2% (181.9ms) | Samples: 0

**Calls:**
- `bound require` (4)

### `nativePaintAncestors`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:190` | Self: 0.0% (0us) | Total: 0.2% (7.9ms) | Samples: 0

**Called by:**
- `visit` (3)

**Calls:**
- `ownerSnapshot` (3)

### `nativePaintAncestors`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:196` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `freeze` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:569` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `resolvedColorValue` (5)

**Calls:**
- `resolveColors` (2)
- `resolveColors` (1)
- `resolveColors` (1)
- `resolveColors` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:592` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `geometryBounds` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:13` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Calls:**
- `bound require` (2)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:829` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `connectorInlineLabelSvg` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:475` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (2)

**Calls:**
- `reorder` (1)
- `reorder` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1527` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `map` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:587` | Self: 0.0% (0us) | Total: 2.4% (85.5ms) | Samples: 0

**Called by:**
- `group` (14)
- `createFixture` (1)

**Calls:**
- `checkInertGroup` (10)
- `checkInertGroup` (3)
- `checkInertGroup` (1)
- `checkInertGroup` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:113` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `snapshot` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:46` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `formatSvgNumericAttribute` (1)

**Calls:**
- `Number` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:185` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Calls:**
- `map` (1)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:86` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `ensureSvgIdentity` (2)

**Calls:**
- `RegExp` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:73` | Self: 0.0% (0us) | Total: 0.3% (10.6ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (2)

**Calls:**
- `resolveRenderStyle` (1)
- `resolveRenderStyle` (1)

### `createSketchBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:547` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `graphicalBackendCapabilityClaims` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:69` | Self: 0.0% (0us) | Total: 0.5% (18.2ms) | Samples: 0

**Called by:**
- `collides` (6)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)

**Calls:**
- `build` (6)
- `build` (3)
- `build` (1)
- `build` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:209` | Self: 0.0% (0us) | Total: 0.0% (967us) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `parseFloat` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:907` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `checkInertGroup` (1)

### `finalizeErRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:28` | Self: 0.0% (0us) | Total: 1.0% (35.1ms) | Samples: 0

**Called by:**
- `finishErGeometry` (18)

**Calls:**
- `placeRelationshipLabels` (9)
- `placeRelationshipLabels` (6)
- `placeRelationshipLabels` (1)
- `placeRelationshipLabels` (1)
- `placeRelationshipLabels` (1)

### `drawn`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:421` | Self: 0.0% (0us) | Total: 0.4% (15.1ms) | Samples: 0

**Called by:**
- `runBackendConformance` (6)
- `connector/subpaths/render` (1)

**Calls:**
- `serializeSceneNode` (4)
- `sceneNodeSerialization` (1)
- `sceneNodeSerialization` (1)
- `serializeSceneNode` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1561` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `nativeCandidate` (2)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:14` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:218` | Self: 0.0% (0us) | Total: 1.4% (51.2ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (35)

**Calls:**
- `inlineResolvedColors` (24)
- `resolveSvgColors` (10)
- `resolveSvgColors` (1)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:181` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (2)

**Calls:**
- `scopeHash` (1)
- `scopeHash` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:974` | Self: 0.0% (0us) | Total: 0.1% (3.5ms) | Samples: 0

**Called by:**
- `map` (3)

**Calls:**
- `nativeOrEmulated` (1)
- `connector/subpaths/render` (1)
- `connectorProjectedField` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1826` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (2)

**Calls:**
- `expectedCapabilityState` (2)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:212` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateGeometry` (1)

**Calls:**
- `skipSeparators` (1)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:106` | Self: 0.0% (0us) | Total: 0.4% (17.1ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (6)

**Calls:**
- `flatIntoArrayWithCallback` (6)

### `stripTrailingComment`
`/tmp/pr449-main-integration-20261029-762/src/shared/trailing-comment.ts:52` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `findErStatements` (1)

**Calls:**
- `trailingCommentStart` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1397` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `some` (1)

### `attr`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:53` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `semanticIdentityForSvg` (1)
- `semanticIdentityForSvg` (1)

**Calls:**
- `RegExp` (1)
- `/\sdata-from="([^"]*)"/` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1365` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `resolveRoleStyle` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1045` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `report` (1)

**Calls:**
- `inspectOwnedSvgOnce` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:51` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `formatSvgNumericAttribute` (1)

**Calls:**
- `formatSvgNumber` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:253` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `advance` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/flowchart-lexer.ts:115` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Calls:**
- `map` (1)

### `verifyNoExternalRefs`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:701` | Self: 0.0% (0us) | Total: 0.0% (966us) | Samples: 0

**Called by:**
- `runBackendConformance` (1)

**Calls:**
- `inspectOwnedSvgOnce` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:674` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `nodeWorldBounds` (1)
- `nodeWorldBounds` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1718` | Self: 0.0% (0us) | Total: 0.0% (997us) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `Set` (1)

### `erCardinalityEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:134` | Self: 0.0% (0us) | Total: 0.4% (17.1ms) | Samples: 0

**Called by:**
- `nativePlacement` (11)

**Calls:**
- `erCardinalityInk` (9)
- `erCardinalityInk` (2)

### `resolveRoleStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:251` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `renderRelationshipLine` (1)
- `erFrameInkPadding` (1)
- `renderRelationshipLabel` (1)
- `repairErFrameRoutes` (1)
- `erRelationshipBlock` (1)
- `finishErGeometry` (1)

**Calls:**
- `Set` (6)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:678` | Self: 0.0% (0us) | Total: 0.6% (21.7ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (13)

**Calls:**
- `geometryAttributes` (4)
- `geometryAttributes` (2)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:111` | Self: 0.0% (0us) | Total: 1.9% (68.7ms) | Samples: 0

**Called by:**
- `measureRenderStage` (45)

**Calls:**
- `report` (44)
- `assertBackendConformance` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringify.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1209` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `min` (1)

### `styledRunLayout`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:252` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:7` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `renderRelationshipLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:543` | Self: 0.0% (0us) | Total: 1.1% (39.1ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (25)

**Calls:**
- `leaf` (23)
- `text` (2)

### `assertFamilyGeometryOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:850` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `applyFamilyRequestNormalization` (1)

**Calls:**
- `serializableOptionCandidate` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:186` | Self: 0.0% (0us) | Total: 1.0% (37.1ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (15)

**Calls:**
- `measureRenderStage` (15)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:181` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `formatSvgNumber` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:167` | Self: 0.0% (0us) | Total: 1.9% (67.4ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (26)
- `renderCardinality` (9)
- `renderCardinality` (6)

**Calls:**
- `node` (28)
- `node` (9)
- `node` (2)
- `node` (2)

### `from`
`[native code]` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `(anonymous)` (1)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:697` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `installedFamilyStatementEnds` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:583` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `get receipt`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:347` | Self: 0.0% (0us) | Total: 0.5% (20.4ms) | Samples: 0

**Called by:**
- `stringify` (11)

**Calls:**
- `(anonymous)` (10)
- `(anonymous)` (1)

### `relationAccessibility`
`/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:29` | Self: 0.0% (0us) | Total: 0.0% (971us) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `copyDataProperties` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:8` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `assertAdmissibleSceneDoc`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation.ts:247` | Self: 0.0% (0us) | Total: 0.6% (22.1ms) | Samples: 0

**Called by:**
- `admitSceneDocumentWith` (18)

**Calls:**
- `validateSceneDocument` (12)
- `validateSceneDocument` (4)
- `validateSceneDocument` (1)
- `validateSceneDocument` (1)

### `erFrameInkPadding`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:758` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `extractErLayout` (1)

**Calls:**
- `erRelationshipBlock` (1)

### `captureFields`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `snapshotScenePrimitiveCell` (2)

**Calls:**
- `map` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1149` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `consumeStringBudget` (1)

### `zlibBufferSync`
`node:zlib:88` | Self: 0.0% (0us) | Total: 0.1% (4.1ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `(anonymous)` (2)

### `replaceSvgRootStartTag`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:319` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

**Calls:**
- `slice` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1715` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `renderOptionsAdmissionMessages` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:704` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `writtenPolylineProjectionOf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringifyPair.js:5` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `preparedInterTextBounds`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:105` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `preparedTextLineGeometry` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:188` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `qualify` (1)

### `documentOpen`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:132` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `header` (1)

### `isZeroWidth`
`/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:137` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `isCombiningMark` (1)

**Calls:**
- `inRanges` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:5` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `chargeInkSort`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:11` | Self: 0.0% (0us) | Total: 0.3% (13.2ms) | Samples: 0

**Called by:**
- `chargeInkSort` (10)
- `build` (2)

**Calls:**
- `chargeInkSort` (10)
- `chargeInkSort` (1)
- `chargeInkSort` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:707` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `from` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:43` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `scanStartTags` (1)

**Calls:**
- `/^(?:class\|data-[a-z][a-z0-9-]*\|role\|aria-[a-z]+\|tabindex\|pointer-events\|transform\|style)$/` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:619` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `validatePaint` (1)

### `collectPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1376` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `localPaintResourceReferences` (1)

**Calls:**
- `localPaintResourceId` (1)

### `sharedRenderOptionsJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:485` | Self: 0.0% (0us) | Total: 0.0% (974us) | Samples: 0

**Called by:**
- `validateSerializableRenderOptions` (1)

**Calls:**
- `cloneValue` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:579` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `map` (1)

### `node:zlib`
`node:zlib:159` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Calls:**
- `ArrayBuffer` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:174` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `parseInlineFormatting` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:998` | Self: 0.0% (0us) | Total: 0.3% (12.8ms) | Samples: 0

**Called by:**
- `report` (9)

**Calls:**
- `withTextMeasurementExecution` (9)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:191` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `styleSpecJsonSchema` (1)

### `relativeLuminance`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:78` | Self: 0.0% (0us) | Total: 0.2% (9.3ms) | Samples: 0

**Called by:**
- `contrastRatio` (7)
- `contrastRatio` (1)

**Calls:**
- `tryParseCssColor` (3)
- `tryParseCssColor` (2)
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)
- `tryParseCssColor` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:780` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `validateNodeSerialization` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:408` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `nativeAttributeValue` (1)

### `tag`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:151` | Self: 0.0% (0us) | Total: 0.0% (978us) | Samples: 0

**Called by:**
- `scanStartTags` (1)

**Calls:**
- `tagRecord` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:255` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Calls:**
- `deepFreeze` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:268` | Self: 0.0% (0us) | Total: 0.1% (3.8ms) | Samples: 0

**Called by:**
- `leaf` (3)

**Calls:**
- `set` (3)

### `isWideRange`
`/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:128` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `getCharWidth` (1)

**Calls:**
- `inRanges` (1)

### `getCharWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:91` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `measureText` (2)

**Calls:**
- `isWideRange` (1)
- `isWideRange` (1)

### `(anonymous)`
`[native code]` | Self: 0.0% (0us) | Total: 0.2% (7.4ms) | Samples: 0

**Called by:**
- `(module)` (3)
- `zlibBufferSync` (2)

**Calls:**
- `get WriteStream` (2)
- `Buffer` (2)
- `WriteStream` (1)

### `positionedPaintCertification`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:154` | Self: 0.0% (0us) | Total: 1.0% (37.1ms) | Samples: 0

**Called by:**
- `measureRenderStage` (15)

**Calls:**
- `certifyNativePaint` (3)
- `certifyNativePaint` (3)
- `certifyNativePaint` (2)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:582` | Self: 0.0% (0us) | Total: 0.1% (3.8ms) | Samples: 0

**Called by:**
- `finish` (3)

**Calls:**
- `erFrameInkPadding` (1)
- `erFrameInkPadding` (1)
- `erFrameInkPadding` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:36` | Self: 0.0% (0us) | Total: 0.6% (22.2ms) | Samples: 0

**Calls:**
- `zlibBufferSync` (6)
- `gzipSync` (4)
- `zlibBufferSync` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:11` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `markerTerminalDepth` (1)

### `SvgWriter`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:471` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `writeTextSvg` (1)

**Calls:**
- `XmlLeafWrite` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:240` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (3)

**Calls:**
- `xmlScalarCharacter` (3)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1490` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `charge` (1)

### `withSvgInspectionCache`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:20` | Self: 0.0% (0us) | Total: 54.2% (1.89s) | Samples: 0

**Called by:**
- `withRenderStageObserver` (1161)

**Calls:**
- `consumeResolvedGraphicalRequest` (1142)
- `executeInspectedGraphicalRequest` (18)
- `lazyGraphicalArtifact` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1777` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `checkArchitectureRenderOptionColors` (1)

### `getCharWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:88` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `measureText` (1)

**Calls:**
- `isCombiningMark` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:237` | Self: 0.0% (0us) | Total: 0.3% (10.9ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (8)

**Calls:**
- `scopeSvgStyles` (5)
- `scopeSvgStyles` (2)
- `replaceSvgRootStartTag` (1)

### `relationshipPairKey`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:160` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `test` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1502` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (3)

**Calls:**
- `solidInteriors` (2)
- `solidInteriors` (1)

### `xmlIndexOf`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:24` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `scanTagEnd` (1)

**Calls:**
- `xmlTokenAt` (1)

### `registerBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:470` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `freezeBuiltInBackend` (1)

### `styleSpecJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:608` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `map` (1)

### `runMeasuredGraphBackend`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:89` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `emitGraphLayoutDecision` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:295` | Self: 0.0% (0us) | Total: 0.3% (13.2ms) | Samples: 0

**Called by:**
- `extractErLayout` (9)

**Calls:**
- `filter` (9)

### `setConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:53` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `connector` (2)

**Calls:**
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:734` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `map` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:286` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `Number` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1715` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `some` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:808` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `attribute` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` | Self: 0.0% (0us) | Total: 0.3% (10.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (6)

**Calls:**
- `xmlSlice` (5)
- `xmlSlice` (1)

### `registerGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:87` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `group` (3)

**Calls:**
- `emissionRecord` (1)
- `set` (1)
- `emissionRecord` (1)

### `inspectSecurityTail`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:691` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `test` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:247` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `nativePaintSource` (1)
- `nativePaintSource` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:194` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `renderEntityBox` (1)

**Calls:**
- `has` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1535` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `charge` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:603` | Self: 0.0% (0us) | Total: 0.0% (964us) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1782` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `trim` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:16` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Calls:**
- `bound require` (2)

### `renderResolvedMermaidSVG`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:270` | Self: 0.0% (0us) | Total: 9.8% (345.0ms) | Samples: 0

**Called by:**
- `consumeResolvedGraphicalRequest` (226)

**Calls:**
- `measureRenderStage` (226)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:26` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `get` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:48` | Self: 0.0% (0us) | Total: 0.0% (991us) | Samples: 0

**Calls:**
- `map` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:103` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `shape` (1)

**Calls:**
- `admitWritableSceneNode` (1)

### `parseErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:898` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `relationshipFrom` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:37` | Self: 0.0% (0us) | Total: 0.9% (34.8ms) | Samples: 0

**Called by:**
- `build` (12)
- `(anonymous)` (6)

**Calls:**
- `build` (12)
- `build` (4)
- `build` (1)
- `slice` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:6` | Self: 0.0% (0us) | Total: 0.1% (4.1ms) | Samples: 0

**Called by:**
- `anonymous` (3)

**Calls:**
- `bound require` (3)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:435` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `finite` (1)

### `mixHex`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:52` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `replace` (1)

**Calls:**
- `parseHex` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:245` | Self: 0.0% (0us) | Total: 4.6% (161.0ms) | Samples: 0

**Called by:**
- `markerTerminalDepth` (4)

**Calls:**
- `paintedStrokeExtent` (3)
- `paintedStrokeExtent` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:120` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `relationshipPairKey` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:941` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (2)

**Calls:**
- `validateMarker` (1)
- `validateMarker` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/util.js:8` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts:47` | Self: 0.0% (0us) | Total: 2.0% (70.2ms) | Samples: 0

**Calls:**
- `map` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:140` | Self: 0.0% (0us) | Total: 33.8% (1.18s) | Samples: 0

**Called by:**
- `measureRenderStage` (731)

**Calls:**
- `withTextMeasurementExecution` (731)

### `displayText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:82` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `map` (1)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:178` | Self: 0.0% (0us) | Total: 0.2% (7.2ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (5)

**Calls:**
- `svgStyleRanges` (5)

### `measureErEntities`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:453` | Self: 0.0% (0us) | Total: 0.1% (4.1ms) | Samples: 0

**Called by:**
- `layoutErDiagram` (2)

**Calls:**
- `preparePixelText` (1)
- `preparePixelText` (1)

### `prepareMarkerTerminals`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:9` | Self: 0.0% (0us) | Total: 4.7% (167.8ms) | Samples: 0

**Called by:**
- `(module)` (3)
- `(module)` (2)
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `map` (8)

### `normalizeMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:663` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `mermaidFirstLine` (1)

### `resolveCss`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:736` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `replace` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1488` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `admitSceneDocumentWith`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:270` | Self: 0.0% (0us) | Total: 0.6% (22.1ms) | Samples: 0

**Called by:**
- `render` (18)

**Calls:**
- `assertAdmissibleSceneDoc` (18)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:140` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `graphicalBackendCapabilityClaims` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:198` | Self: 0.0% (0us) | Total: 0.4% (16.1ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (6)
- `renderCardinality` (4)
- `renderCardinality` (1)

**Calls:**
- `serialization` (9)
- `serialization` (1)
- `serialization` (1)

### `canonicalizeSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:458` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `includes` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:14` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:906` | Self: 0.0% (0us) | Total: 0.6% (22.6ms) | Samples: 0

**Called by:**
- `node` (15)

**Calls:**
- `groupValidation` (15)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:237` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `pathMoveCount` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:279` | Self: 0.0% (0us) | Total: 0.8% (28.1ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (16)

**Calls:**
- `toneOnFill` (9)
- `toneOnFill` (3)
- `toneOnFill` (3)
- `toneOnFill` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:3` | Self: 0.0% (0us) | Total: 0.7% (27.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (9)

**Calls:**
- `bound require` (9)

### `connector/subpaths/render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:660` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `drawn` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:403` | Self: 0.0% (0us) | Total: 1.5% (53.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (26)

**Calls:**
- `readXmlNameEnd` (22)
- `readXmlNameEnd` (4)

### `checkRect`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:229` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `assessFamilyLayout` (1)

**Calls:**
- `finiteRect` (1)

### `renderRelationshipLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:537` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `erLabelPillGeometry` (1)

### `validateMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:365` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `validateNode` (2)

**Calls:**
- `entries` (2)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:454` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (2)

**Calls:**
- `sharedRenderOptionsJsonSchema` (1)
- `deepFreeze` (1)

### `parseErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:918` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `map` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:323` | Self: 0.0% (0us) | Total: 0.2% (10.0ms) | Samples: 0

**Called by:**
- `measureErEntities` (6)
- `(anonymous)` (1)

**Calls:**
- `prepareDisplayText` (2)
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:229` | Self: 0.0% (0us) | Total: 0.1% (5.5ms) | Samples: 0

**Called by:**
- `validateGeometry` (4)

**Calls:**
- `finiteNumber` (2)
- `finiteNumber` (1)
- `finiteNumber` (1)

### `inertRectangleRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:319` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `rectangleInput` (1)

**Calls:**
- `has` (1)

### `crowsFootMark`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:626` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `renderCardinality` (1)

**Calls:**
- `map` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1583` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (4)

**Calls:**
- `snapshotDescriptorArray` (4)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:196` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `renderEntityBox` (2)
- `renderEntityBox` (1)

**Calls:**
- `resolvedColorValue` (3)

### `renderedSvgDigest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:61` | Self: 0.0% (0us) | Total: 0.2% (10.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `stringify` (5)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:101` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `shape` (1)

**Calls:**
- `relationAccessibility` (1)

### `erCardinalityInk`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:127` | Self: 0.0% (0us) | Total: 0.2% (7.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `values` (3)
- `every` (2)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1663` | Self: 0.0% (0us) | Total: 1.9% (67.6ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `isBuiltinFamilyId` (1)

### `internal:streams/operators`
`internal:streams/operators:2` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `crowsFootMark`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:621` | Self: 0.0% (0us) | Total: 1.4% (49.3ms) | Samples: 0

**Called by:**
- `renderCardinality` (22)
- `renderCardinality` (12)

**Calls:**
- `leaf` (30)
- `shape` (4)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/anchors.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1553` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `createTextMeasurementExecution` (1)

### `inspectPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:61` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `createOwnedNativePaintRecorder` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:168` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `attachSceneNodeSerialization` (1)

### `snapshot`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:278` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `transferNativeGroupEmission` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:274` | Self: 0.0% (0us) | Total: 0.2% (7.4ms) | Samples: 0

**Called by:**
- `writeTextSvg` (6)

**Calls:**
- `formatSvgNumber` (5)
- `formatSvgNumber` (1)

### `snapshotDescriptorArray`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1501` | Self: 0.0% (0us) | Total: 0.2% (7.8ms) | Samples: 0

**Called by:**
- `freezeDescriptor` (4)
- `freezeDescriptor` (1)
- `snapshotCapabilityCell` (1)

**Calls:**
- `snapshotScenePrimitiveCell` (4)
- `(anonymous)` (1)
- `snapshotCapabilityCell` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:186` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `createExtensionIdentity` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:4` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `resolveRenderStyle`
`/tmp/pr449-main-integration-20261029-762/src/styles.ts:283` | Self: 0.0% (0us) | Total: 0.2% (9.5ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `positiveNumber` (1)

### `internal:streams/pipeline`
`internal:streams/pipeline:2` | Self: 0.0% (0us) | Total: 0.2% (9.1ms) | Samples: 0

**Called by:**
- `anonymous` (6)

**Calls:**
- `anonymous` (6)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:201` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `renderCardinality` (1)

**Calls:**
- `test` (1)

### `internal:streams/destroy`
`internal:streams/destroy:2` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1336` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `nativeCandidate` (2)

**Calls:**
- `flatIntoArrayWithCallback` (2)

### `parseErRelationshipSyntax`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1086` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `readErStatement` (2)

**Calls:**
- `erLabelUnread` (1)
- `erLabelUnread` (1)

### `toHex`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:43` | Self: 0.0% (0us) | Total: 0.1% (4.1ms) | Samples: 0

**Called by:**
- `toneOnFill` (3)

**Calls:**
- `map` (3)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:310` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `map` (4)

**Calls:**
- `(anonymous)` (3)
- `(anonymous)` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:402` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `measureErEntities` (2)

**Calls:**
- `forEach` (2)

### `isErKeywordName`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:326` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `erLabelUnread` (1)

**Calls:**
- `test` (1)

### `snapshot`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1319` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `finishErGeometry` (2)

**Calls:**
- `map` (2)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:662` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `unsafeCssReferences` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:284` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `connector` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:143` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (3)

**Calls:**
- `assessRenderedLayoutHardViolations` (3)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:313` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `displayText` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1367` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `nativeCandidate` (2)

**Calls:**
- `terminalDepth` (1)
- `terminalDepth` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:731` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `renderMultilineText` (1)

**Calls:**
- `prepared` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:705` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `snapshot` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:590` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `forEach` (1)

### `withTextMeasurementExecution`
`/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:135` | Self: 0.0% (0us) | Total: 87.4% (3.05s) | Samples: 0

**Called by:**
- `consumeResolvedGraphicalRequest` (915)
- `retainedNativeDrawing` (731)
- `positionFamilyForNativeRender` (226)
- `runBackendConformance` (9)

**Calls:**
- `renderPositionedWithTextMeasurement` (777)
- `drawNative` (652)
- `(anonymous)` (220)
- `renderPositionedWithTextMeasurement` (80)
- `drawNative` (70)
- `renderPositionedWithTextMeasurement` (35)
- `renderPositionedWithTextMeasurement` (15)
- `renderPositionedWithTextMeasurement` (8)
- `createFixture` (4)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `drawNative` (2)
- `drawNative` (2)
- `drawNative` (2)
- `createFixture` (1)
- `createFixture` (1)
- `drawNative` (1)
- `createFixture` (1)
- `createFixture` (1)
- `drawNative` (1)
- `createFixture` (1)
- `drawNative` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:321` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `measureErEntities` (1)
- `(anonymous)` (1)

**Calls:**
- `stringify` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-scalar.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:194` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (1)

**Calls:**
- `boxAt` (1)

### `erLabelUnread`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1063` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `parseErRelationshipSyntax` (1)

**Calls:**
- `isErKeywordName` (1)

### `positionFamilyForNativeRender`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:67` | Self: 0.0% (0us) | Total: 9.8% (345.0ms) | Samples: 0

**Called by:**
- `measureRenderStage` (226)

**Calls:**
- `withTextMeasurementExecution` (226)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:807` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `attribute` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:676` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `preparedInterTextBounds` (1)
- `preparedInterTextBounds` (1)

### `layout`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:27` | Self: 0.0% (0us) | Total: 9.1% (318.8ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (207)

**Calls:**
- `runMeasuredGraphBackend` (186)
- `layoutErDiagram` (19)
- `layoutErDiagram` (1)
- `runMeasuredGraphBackend` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:572` | Self: 0.0% (0us) | Total: 0.2% (9.7ms) | Samples: 0

**Called by:**
- `resolvedColorValue` (1)

**Calls:**
- `set` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:90` | Self: 0.0% (0us) | Total: 1.3% (47.0ms) | Samples: 0

**Called by:**
- `visit` (31)

**Calls:**
- `leaf` (29)
- `leaf` (1)
- `leaf` (1)

### `sceneValidationMode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1402` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `parseExtensionId` (1)

### `visitSvgFirstTagAttributes`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:106` | Self: 0.0% (0us) | Total: 0.5% (18.2ms) | Samples: 0

**Called by:**
- `checkInertGroup` (11)

**Calls:**
- `scanStartTags` (5)
- `scanStartTags` (2)
- `scanStartTags` (2)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:299` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `resolveLabelContent` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:4` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1221` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `canonicalErContacts` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:183` | Self: 0.0% (0us) | Total: 35.8% (1.25s) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (777)

**Calls:**
- `measureRenderStage` (777)

### `node:fs`
`node:fs:8` | Self: 0.0% (0us) | Total: 1.0% (38.4ms) | Samples: 0

**Calls:**
- `anonymous` (1)

### `ZlibBase`
`node:zlib:123` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `Zlib` (3)

**Calls:**
- `Transform` (1)
- `Transform` (1)
- `Transform` (1)

### `safeCssToken`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:69` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateStyleSpec` (1)

**Calls:**
- `test` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/block/markers.ts:10` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (2)

### `preparedTextLineGeometry`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:136` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `preparedInterTextBounds` (1)

**Calls:**
- `formatSvgNumber` (1)

### `validateAggregateReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1525` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `finish` (2)

**Calls:**
- `has` (2)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1088` | Self: 0.0% (0us) | Total: 0.1% (3.5ms) | Samples: 0

**Called by:**
- `report` (3)

**Calls:**
- `map` (3)

### `inspectOwnedSvgOnce`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:46` | Self: 0.0% (0us) | Total: 4.7% (164.5ms) | Samples: 0

**Called by:**
- `applyOutputSecurityPolicy` (84)
- `runBackendConformance` (1)
- `verifyNoExternalRefs` (1)

**Calls:**
- `(anonymous)` (82)
- `inspectSecurityTail` (1)
- `verifyDocumentEnvelope` (1)
- `inspectSecurityTail` (1)
- `inspectSecurity` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:153` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `renderRelationshipLine` (2)

**Calls:**
- `stringify` (2)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1483` | Self: 0.0% (0us) | Total: 0.1% (6.6ms) | Samples: 0

**Called by:**
- `nativeCandidate` (5)

**Calls:**
- `flatIntoArrayWithCallback` (5)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:682` | Self: 0.0% (0us) | Total: 0.9% (33.7ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (10)

**Calls:**
- `paintAttributes` (6)
- `paintAttributes` (2)
- `paintAttributes` (2)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:148` | Self: 0.0% (0us) | Total: 0.1% (4.1ms) | Samples: 0

**Called by:**
- `visitSvgStartTagsFresh` (3)

**Calls:**
- `tag` (1)
- `tag` (1)
- `tag` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/state/parse-core.ts:154` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `RegExp` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1301` | Self: 0.0% (0us) | Total: 1.0% (35.1ms) | Samples: 0

**Called by:**
- `nativeCandidate` (18)

**Calls:**
- `finalizeErRelationshipLabels` (18)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:41` | Self: 0.0% (0us) | Total: 0.1% (6.6ms) | Samples: 0

**Called by:**
- `attribute` (6)

**Calls:**
- `replace` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:27` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)
- `preparePixelText` (1)

**Calls:**
- `add` (2)

### `zlibBufferSync`
`node:zlib:94` | Self: 0.0% (0us) | Total: 0.3% (11.1ms) | Samples: 0

**Called by:**
- `(module)` (6)

**Calls:**
- `processChunkSync` (5)
- `processChunkSync` (1)

### `measureTextWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:206` | Self: 0.0% (0us) | Total: 0.1% (6.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (4)

**Calls:**
- `measureText` (4)

### `internal:fs/binding`
`internal:fs/binding:3` | Self: 0.0% (0us) | Total: 1.0% (38.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `@lazy` (1)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1656` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `applyFamilyRequestNormalization` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1749` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `capturedRequestFamily` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:738` | Self: 0.0% (0us) | Total: 0.4% (15.6ms) | Samples: 0

**Called by:**
- `write` (8)
- `validateSceneDocument` (1)
- `node` (1)

**Calls:**
- `localPaintResourceReferences` (6)
- `localPaintResourceReferences` (3)
- `localPaintResourceReferences` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:312` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `extractErLayout` (2)

**Calls:**
- `enoughLead` (2)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:637` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `defineProperty` (1)

### `visitSvgStartTagsFresh`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:116` | Self: 0.0% (0us) | Total: 0.2% (9.4ms) | Samples: 0

**Called by:**
- `collectNativeGroup` (7)

**Calls:**
- `scanStartTags` (3)
- `scanStartTags` (2)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:562` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:17` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1490` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (1)

**Calls:**
- `backendSupportsCapability` (1)

### `inspectPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:98` | Self: 0.0% (0us) | Total: 2.8% (98.7ms) | Samples: 0

**Called by:**
- `drawNative` (67)

**Calls:**
- `visit` (37)
- `visit` (20)
- `visit` (7)
- `visit` (1)
- `visit` (1)
- `visit` (1)

### `replaceField`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:286` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `getOwnPropertyNames` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 30.5% | 1.06s | `[native code]` |
| 16.0% | 563.0ms | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 6.0% | 213.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 4.4% | 155.9ms | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 4.3% | 153.8ms | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 3.9% | 138.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 3.5% | 124.7ms | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 2.6% | 93.4ms | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 2.1% | 75.3ms | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 2.0% | 70.2ms | `/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts` |
| 1.8% | 63.9ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js` |
| 1.5% | 54.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 1.4% | 52.0ms | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 1.3% | 46.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 1.1% | 39.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 1.0% | 36.8ms | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 1.0% | 35.9ms | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.9% | 31.9ms | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts` |
| 0.8% | 28.8ms | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.8% | 28.6ms | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.7% | 27.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.7% | 26.4ms | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.7% | 26.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.7% | 25.1ms | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` |
| 0.7% | 24.5ms | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` |
| 0.5% | 18.5ms | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.5% | 18.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.5% | 17.9ms | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.4% | 15.4ms | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.4% | 14.3ms | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.3% | 11.7ms | `/tmp/pr449-main-integration-20261029-762/src/styles.ts` |
| 0.3% | 11.1ms | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.3% | 10.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.2% | 10.4ms | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.2% | 9.6ms | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.2% | 8.9ms | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts` |
| 0.2% | 8.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 0.2% | 7.0ms | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.1% | 6.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.1% | 6.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.1% | 5.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.1% | 5.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.1% | 5.2ms | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.1% | 5.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.1% | 4.8ms | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts` |
| 0.1% | 3.7ms | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts` |
| 0.0% | 3.3ms | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts` |
| 0.0% | 3.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts` |
| 0.0% | 2.8ms | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` |
| 0.0% | 2.7ms | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 2.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 2.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` |
| 0.0% | 2.4ms | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` |
| 0.0% | 2.4ms | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.0% | 2.3ms | `internal:streams/transform` |
| 0.0% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/decode.js` |
| 0.0% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-admission-state.ts` |
| 0.0% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/flowchart-lexer.ts` |
| 0.0% | 2.1ms | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/geometry.ts` |
| 0.0% | 2.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.0% | 1.8ms | `/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts` |
| 0.0% | 1.6ms | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Scalar.js` |
| 0.0% | 1.6ms | `/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts` |
| 0.0% | 1.6ms | `/tmp/pr449-main-integration-20261029-762/src/shared/generated-identity.ts` |
| 0.0% | 1.6ms | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts` |
| 0.0% | 1.5ms | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts` |
| 0.0% | 1.5ms | `node:zlib` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/shared/trailing-comment.ts` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/journey/config-diagnostics.ts` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/inline-format.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/shared/accessibility-directives.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts` |
| 0.0% | 1.2ms | `internal:streams/readable` |
| 0.0% | 1.2ms | `internal:streams/duplex` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/c4/parser.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/shared/subgraph-membership.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/directives.js` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/shared/css-font.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/layout/decision-evidence.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 1.0ms | `internal:fs/streams` |
| 0.0% | 999us | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts` |
| 0.0% | 990us | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` |
