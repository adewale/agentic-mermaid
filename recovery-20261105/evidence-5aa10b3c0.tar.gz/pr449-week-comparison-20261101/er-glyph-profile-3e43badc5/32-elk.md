# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 3.85s | 1323 | 1.0ms | 2119 |

**Top 10:** `anonymous` 12.3%, `(anonymous)` 6.5%, `xmlSlice` 6.0%, `gc` 3.9%, `add` 3.1%, `WC` 3.0%, `set` 2.6%, `decodeBase64` 2.3%, `(module)` 1.5%, `(anonymous)` 1.0%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 12.3% | 476.8ms | 24.6% | 948.1ms | `anonymous` | `[native code]` |
| 6.5% | 253.6ms | 6.5% | 253.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 6.0% | 232.7ms | 6.0% | 232.7ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` |
| 3.9% | 150.6ms | 3.9% | 150.6ms | `gc` | `[native code]` |
| 3.1% | 122.9ms | 3.1% | 122.9ms | `add` | `[native code]` |
| 3.0% | 115.6ms | 3.0% | 115.6ms | `WC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4239` |
| 2.6% | 102.8ms | 2.6% | 102.8ms | `set` | `[native code]` |
| 2.3% | 90.8ms | 2.3% | 90.8ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js` |
| 1.5% | 60.9ms | 1.5% | 60.9ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/shapes/corners.ts:41` |
| 1.0% | 41.5ms | 1.0% | 41.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:129` |
| 0.8% | 33.6ms | 0.8% | 33.6ms | `defineProperty` | `[native code]` |
| 0.8% | 31.2ms | 0.8% | 31.2ms | `connectorInlineLabelSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:757` |
| 0.7% | 28.2ms | 0.7% | 28.2ms | `getOwnPropertyDescriptor` | `[native code]` |
| 0.7% | 27.9ms | 0.7% | 27.9ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` |
| 0.6% | 25.7ms | 0.9% | 36.6ms | `test` | `[native code]` |
| 0.6% | 25.4ms | 0.8% | 31.5ms | `stringify` | `[native code]` |
| 0.6% | 24.6ms | 0.9% | 36.9ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:170` |
| 0.6% | 24.5ms | 4.6% | 180.9ms | `map` | `[native code]` |
| 0.6% | 23.1ms | 0.9% | 35.9ms | `r1d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.5% | 22.7ms | 0.5% | 22.7ms | `replaceField` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:294` |
| 0.5% | 20.2ms | 0.5% | 20.2ms | `freeze` | `[native code]` |
| 0.4% | 19.2ms | 0.4% | 19.2ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.4% | 17.7ms | 0.4% | 17.7ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.3% | 14.5ms | 0.3% | 14.5ms | `@lazy` | `[native code]` |
| 0.3% | 13.4ms | 0.5% | 19.9ms | `q_b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6380` |
| 0.2% | 11.3ms | 0.2% | 11.3ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.2% | 11.3ms | 0.2% | 11.3ms | `get` | `[native code]` |
| 0.2% | 10.7ms | 0.2% | 10.7ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:96` |
| 0.2% | 10.6ms | 0.2% | 10.6ms | `ID` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.2% | 10.1ms | 0.2% | 10.1ms | `OFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2138` |
| 0.2% | 9.5ms | 0.2% | 9.5ms | `ownFragment` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:116` |
| 0.2% | 9.2ms | 0.3% | 11.7ms | `(unknown)` | `[native code]` |
| 0.2% | 9.1ms | 0.2% | 9.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:114` |
| 0.2% | 9.1ms | 0.2% | 10.4ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:471` |
| 0.2% | 9.1ms | 0.2% | 9.1ms | `withPerformanceObserver` | `/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts:44` |
| 0.2% | 9.0ms | 0.2% | 9.0ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.2% | 8.9ms | 0.2% | 8.9ms | `Byb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.2% | 8.7ms | 0.2% | 8.7ms | `assign` | `[native code]` |
| 0.2% | 8.3ms | 0.2% | 8.3ms | `has` | `[native code]` |
| 0.2% | 8.3ms | 0.2% | 8.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.2% | 8.2ms | 0.2% | 8.2ms | `Hmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1049` |
| 0.2% | 8.0ms | 0.2% | 9.4ms | `Set` | `[native code]` |
| 0.2% | 8.0ms | 0.2% | 8.0ms | `connectorSegments` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.2% | 8.0ms | 0.2% | 8.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.2% | 7.9ms | 10.1% | 389.5ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:161` |
| 0.2% | 7.8ms | 0.2% | 7.8ms | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:272` |
| 0.1% | 7.6ms | 0.1% | 7.6ms | `xmlNameCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:87` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:796` |
| 0.1% | 7.2ms | 0.1% | 7.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.1% | 7.1ms | 0.1% | 7.1ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:129` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:446` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:205` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `RegExp` | `[native code]` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `join` | `[native code]` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 6.8ms | 0.1% | 6.8ms | `Erb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4055` |
| 0.1% | 6.8ms | 0.1% | 6.8ms | `estimatedResidency` | `/tmp/pr449-main-integration-20261029-762/src/experimental/cache-residency.ts` |
| 0.1% | 6.6ms | 0.2% | 7.9ms | `teb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1540` |
| 0.1% | 6.5ms | 0.1% | 6.5ms | `ID` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4818` |
| 0.1% | 6.4ms | 0.1% | 6.4ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:110` |
| 0.1% | 6.4ms | 0.1% | 6.4ms | `xpd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 6.4ms | 0.1% | 6.4ms | `flatIntoArray` | `[native code]` |
| 0.1% | 6.3ms | 0.1% | 6.3ms | `hasOwn` | `[native code]` |
| 0.1% | 6.3ms | 0.1% | 6.3ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:92` |
| 0.1% | 6.3ms | 1.4% | 56.7ms | `captureNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:101` |
| 0.1% | 6.2ms | 0.1% | 6.2ms | `outcome` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:526` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:308` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `Wr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 5.9ms | 0.2% | 11.0ms | `every` | `[native code]` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `cgd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 5.6ms | 0.1% | 5.6ms | `Dwd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 5.6ms | 0.1% | 5.6ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 5.5ms | 0.1% | 5.5ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` |
| 0.1% | 5.5ms | 0.1% | 5.5ms | `importModule` | `[native code]` |
| 0.1% | 5.5ms | 0.1% | 5.5ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 5.5ms | 0.1% | 5.5ms | `slice` | `[native code]` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `min` | `[native code]` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `compositeCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:277` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `Jmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 5.3ms | 0.1% | 6.5ms | `sourceSlice` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:55` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `rb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4337` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `Gsd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5992` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:304` |
| 0.1% | 5.2ms | 1.5% | 59.8ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:166` |
| 0.1% | 5.1ms | 0.2% | 7.9ms | `Rc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5459` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:174` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:94` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:444` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `owb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2807` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `sceneGroupOpacity` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:234` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `defineProperties` | `[native code]` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `connectorMarkerPaintRegions` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1467` |
| 0.1% | 4.8ms | 0.1% | 6.6ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:175` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `p1d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 4.8ms | 0.9% | 37.9ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:85` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:8` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `UBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `transformMatrix` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `intersects` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:479` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `Vr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4327` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `/^\s*$/` | `[native code]` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:203` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:161` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `ownData` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:48` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:177` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `createNativePaintEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `attributeRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `tree` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `inspectOwnedSvgOnce` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts` |
| 0.1% | 4.5ms | 0.2% | 7.8ms | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` |
| 0.1% | 4.4ms | 0.2% | 11.4ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:156` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `RAd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2285` |
| 0.1% | 4.3ms | 0.1% | 5.6ms | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:17` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `endpointOwner` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:118` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:128` |
| 0.1% | 4.2ms | 0.2% | 8.5ms | `writeFileSync` | `[native code]` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:277` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:118` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `polylineLength` | `/tmp/pr449-main-integration-20261029-762/src/layout/geometry.ts:67` |
| 0.1% | 4.1ms | 0.1% | 4.1ms | `split` | `[native code]` |
| 0.1% | 4.1ms | 0.1% | 7.0ms | `Meb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3984` |
| 0.1% | 4.1ms | 0.1% | 4.1ms | `startsWith` | `[native code]` |
| 0.1% | 4.0ms | 0.1% | 5.3ms | `replace` | `[native code]` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `possibleShapeStroke` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:133` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `arrayIteratorNextHelper` | `[native code]` |
| 0.1% | 3.9ms | 0.2% | 8.2ms | `aXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6207` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:88` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:163` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `TC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4909` |
| 0.1% | 3.8ms | 0.1% | 3.8ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `inverseMatrix` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:25` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `endpointRelation` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:145` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `startTags` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:65` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:53` |
| 0.0% | 3.7ms | 0.2% | 10.9ms | `xKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6339` |
| 0.0% | 3.7ms | 1.0% | 42.1ms | `flatIntoArrayWithCallback` | `[native code]` |
| 0.0% | 3.7ms | 0.1% | 5.1ms | `Ieb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5583` |
| 0.0% | 3.7ms | 0.3% | 13.4ms | `sceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `xmlIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:22` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `possibleShapeStroke` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1597` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:155` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `parseInt` | `[native code]` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:596` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `copyDataProperties` | `[native code]` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `oD` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6204` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `textSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1654` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:309` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `Segmenter` | `[native code]` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:247` |
| 0.0% | 3.5ms | 0.1% | 4.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `sanitizeTextControls` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:9` |
| 0.0% | 3.5ms | 0.2% | 10.9ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:596` |
| 0.0% | 3.5ms | 0.1% | 5.3ms | `value` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:124` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `Qjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3372` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:236` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `collectNativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:164` |
| 0.0% | 3.4ms | 0.1% | 5.6ms | `compare` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:33` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `hasInheritedPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:799` |
| 0.0% | 3.4ms | 0.1% | 4.7ms | `TEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5052` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `internal:streams/destroy` | `internal:streams/destroy:16` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:32` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `seedFrom` | `/tmp/pr449-main-integration-20261029-762/src/scene/seed.ts` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `/[&<>"'\t\n\r]/` | `[native code]` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `isPlainFontFamily` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `Rse` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 3.2ms | 1.0% | 38.7ms | `cJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6363` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `/<(?:[^\s<>/:]+:)?image\b/i` | `[native code]` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `append` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:239` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 3.2ms | 0.8% | 32.8ms | `p_b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6372` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `x7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6110` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `createNativeSceneValidator` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:485` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:232` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `recordPaintField` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `fPc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2891` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:106` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `hasImmutablePaintRoster` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 3.1ms | 0.3% | 11.8ms | `jGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `isOwnedDisplayTextPart` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:30` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:18` |
| 0.0% | 3.0ms | 0.1% | 6.4ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:200` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:170` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `RXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `yd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3912` |
| 0.0% | 3.0ms | 0.6% | 25.6ms | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.9ms | 0.8% | 34.6ms | `collectNativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:146` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `displayRunAttributes` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `isHexColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:143` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1038` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` |
| 0.0% | 2.9ms | 0.1% | 5.3ms | `(anonymous)` | `[native code]` |
| 0.0% | 2.8ms | 0.2% | 7.9ms | `filter` | `[native code]` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:198` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `VC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2915` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `GAd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `Keb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:20` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `UHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5196` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `ijd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `hasOwned` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `drawNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `TJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5486` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `fKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2151` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `v6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `PEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `svgOpenTag` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:178` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:117` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:55` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `dKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `PHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5783` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `registerCanonicalStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `boundedNonNegative` | `/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:207` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `iHc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.7ms | 5.7% | 220.2ms | `kWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6128` |
| 0.0% | 2.7ms | 0.1% | 3.9ms | `ltb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3516` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `at` | `[native code]` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:189` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `ActualTextPaintWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:393` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:117` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:609` |
| 0.0% | 2.6ms | 0.5% | 22.4ms | `some` | `[native code]` |
| 0.0% | 2.6ms | 0.1% | 5.2ms | `next` | `[native code]` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:285` |
| 0.0% | 2.6ms | 0.4% | 18.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `resolveRoleStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:240` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `MFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4458` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `jDb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5481` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `canonicalizeSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:465` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `pWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1390` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `relationshipPairKey` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:162` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `header` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:526` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `SC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `isInteger` | `[native code]` |
| 0.0% | 2.4ms | 0.5% | 20.2ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:729` |
| 0.0% | 2.4ms | 0.3% | 13.2ms | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` |
| 0.0% | 2.4ms | 0.4% | 16.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:49` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:154` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `interTextEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/shared/inter-text-envelope.ts:20` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `Tad` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `nud` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `kXb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `Le` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.3ms | 0.1% | 6.6ms | `Pe` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.3ms | 0.2% | 9.3ms | `Usd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3200` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `reserve` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 2.3ms | 0.1% | 4.5ms | `opaqueOutlineWidth` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:149` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `withDeferredTerminalProjections` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1089` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `node:events` | `node:events:577` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `PromisedWorker` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:232` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `_Ud` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 2.2ms | 0.6% | 26.5ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:130` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `uncurryThis` | `internal:primordials` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `kWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `assertMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:54` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `push` | `[native code]` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `sceneValidationMode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:267` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `Z7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `createEmissionContext` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/set.js:7` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 2.1ms | 0.1% | 4.5ms | `mdb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5533` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `WC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `exec` | `[native code]` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 2.1ms | 0.1% | 5.8ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `tb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `setName` | `node:fs:696` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:357` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:120` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:900` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `consumePointBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:1126` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `iub` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1660` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `Aeb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:778` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `themePaint` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:47` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `lC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3498` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:229` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:320` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `create` | `[native code]` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:711` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `inspectSecurityTail` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:644` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `pb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4466` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `AQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.9ms | 0.1% | 5.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:109` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:578` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `themePaint` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `serializeLinearGradientResources` | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts:117` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `mbd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.8ms | 0.0% | 3.2ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:202` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `isRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:86` |
| 0.0% | 1.8ms | 0.1% | 5.0ms | `_x` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4182` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `boxAt` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:168` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `dZd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.8ms | 0.4% | 19.0ms | `JD` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2608` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:207` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:658` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `createSafeIterator` | `internal:primordials` |
| 0.0% | 1.8ms | 0.1% | 5.1ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:484` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:575` |
| 0.0% | 1.8ms | 0.1% | 6.7ms | `relationAccessibility` | `/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `value` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:128` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `connector/subpaths/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `kd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `mXb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `appendPrivate` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.7ms | 2.9% | 115.3ms | `SC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3689` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:196` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:521` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `connectorMidpointMarkerAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:295` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.7ms | 0.1% | 7.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:778` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `xNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5494` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `makeSafe` | `internal:primordials` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:204` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `enclosure` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1495` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `assertRenderableMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:217` |
| 0.0% | 1.7ms | 27.3% | 1.05s | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:140` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `N$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `vgb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `aod` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `_Td` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3967` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `entries` | `[native code]` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `erCardinalityPieces` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:17` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1009` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `Pg` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `inlineResolvedColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `i6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `oKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2213` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `erCardinalityInk` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `skipSeparators` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:168` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:232` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `xsb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5521` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `vBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:668` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `groupValidation` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `match` | `[native code]` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `tagRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:194` |
| 0.0% | 1.5ms | 0.0% | 3.1ms | `Srb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3494` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `inspectSecurityTail` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:686` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/YAMLMap.js:147` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `preparedInterTextBounds` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `tCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:990` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:593` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `Qrb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3853` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `/[^\x20-\x7e]/u` | `[native code]` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `Fmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3333` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `Fk` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `D$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `ohb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:269` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `BWb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3113` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:13` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `iYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2730` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1033` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `TUd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.5ms | 0.1% | 3.9ms | `pjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `rNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6111` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:598` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `erRelationshipBlock` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:20` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `Bwb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `$u` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `osb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.2% | 8.1ms | `CIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4866` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `Rc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `g0d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `checkFamilyConfigColors` | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:501` |
| 0.0% | 1.4ms | 0.1% | 4.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:40` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `lyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4217` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `processChunkSync` | `node:zlib` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `sourceEnvelopeMetadata` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:802` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:333` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `compareCodePointStrings` | `/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts:4` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:854` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `collectPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateJsonConfigAdmission` | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:126` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `eub` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:204` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `rD` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2794` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `kNb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `SBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `assertFamilyGeometryOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `preventExtensions` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `parseInlineFormatting` | `/tmp/pr449-main-integration-20261029-762/src/shared/inline-format.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `rWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3492` |
| 0.0% | 1.4ms | 0.0% | 2.8ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:87` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `admitRenderOptionsInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.4ms | 0.0% | 2.9ms | `De` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4889` |
| 0.0% | 1.4ms | 0.2% | 10.7ms | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:702` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `createPngOutputOptionFieldDescriptors` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `VWb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `ownConnectorEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `nativeParseRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:132` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `i_d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `zKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4783` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `MJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4125` |
| 0.0% | 1.4ms | 0.1% | 6.5ms | `xCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3738` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:395` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `collectNativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:143` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `BIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 2.7ms | `tYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5390` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `HQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `finishXmlLeaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:277` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `readDiff` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `N0d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4048` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:138` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `KYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4850` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `ibd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `/\sdata-role="[^"]*"/` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `$Yd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `escapeXml` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `uyb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `GNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parseFloat` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `append` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `ZTd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4478` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:633` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Kz` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `mermaidInitDirectives` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `lbd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `vNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `qwb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `ued` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.3% | 13.5ms | `fVb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6002` |
| 0.0% | 1.3ms | 14.1% | 544.8ms | `require` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `bqc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Xfc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `evaluateExtensionCompatibility` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:109` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `overlaps` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:56` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readDiff` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:16` |
| 0.0% | 1.3ms | 0.1% | 5.3ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:251` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:115` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Beb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `dCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Iac` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:400` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Dl` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 2.9ms | `mEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4780` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5863` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `PHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `textBaseRatio` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `erCardinalityPieces` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:82` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:49` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `gce` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `yc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3789` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Eoc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `amb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Reb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `primitiveCapabilityId` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:552` |
| 0.0% | 1.3ms | 0.4% | 16.2ms | `edd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4340` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Hf` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.7% | 28.9ms | `mQc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6283` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `cvc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `SEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6337` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `bHd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Yxb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5782` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `xeb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1095` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Mzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `fNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6404` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `recordPaintField` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:312` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Xr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pageRectFor` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `R5b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1761` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:136` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `bBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 2.6% | 100.4ms | `wsb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5362` |
| 0.0% | 1.3ms | 0.7% | 28.4ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:94` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Ueb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `cjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:660` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `hub` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Jgc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2728` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Q$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sPc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4570` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Qpb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Ijb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3061` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `imul` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `matchMermaidFrontmatter` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `inRanges` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:114` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1747` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `vkb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `negotiateCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:90` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:313` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:501` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `padStart` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `t9c` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `sourceIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:484` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `tipAnchoredArrow` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:29` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `SGb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.7% | 29.5ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `cyc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:286` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Vwd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:170` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `vmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Rlb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.1% | 5.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:310` |
| 0.0% | 1.2ms | 4.7% | 183.4ms | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:137` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `primitiveCapabilityClaimKey` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `arrayFromFastWithoutMapFn` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `SYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `intersects` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1217` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `erRelationshipStyle` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:15` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `mzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4037` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Ckd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1488` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` |
| 0.0% | 1.2ms | 0.1% | 4.4ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:517` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Esb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1917` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `stripTrailingComment` | `/tmp/pr449-main-integration-20261029-762/src/shared/trailing-comment.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:129` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `_B` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.3% | 15.3ms | `yCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `lNb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `limitJsonConfigDiagnostics` | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts:325` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `outputDescriptorsById` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Wcd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `wgd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `prepareWrittenCompoundShape` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:61` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorTerminalStrokeLosses` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ddd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6264` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorEndpointAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts:32` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `trim` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `a4d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4534` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `gJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `BGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 3.7ms | `PJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4763` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `oEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ensureEntity` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ytb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2613` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:51` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `hooks` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:507` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `iUd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Fzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5681` |
| 0.0% | 1.2ms | 4.0% | 157.6ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:638` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `vMd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts:1436` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `writeFast` | `internal:fs/streams` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `i0b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `open` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `init` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `erCharge` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:204` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ulb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1440` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Wc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1595` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Wd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `yfd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5328` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `vWb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `unionSceneBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:28` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `BGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `xmlHasColon` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:85` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `rGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Lcd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `hjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2804` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `B4d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3192` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `_Pb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Jjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `mdb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1171` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Yjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `dereferenceSchema` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `RFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5055` |
| 0.0% | 1.1ms | 0.0% | 3.4ms | `tree` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:71` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `u6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `SLd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4644` |
| 0.0% | 1.1ms | 0.1% | 6.4ms | `performIteration` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `XDc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `i7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.1% | 6.4ms | `tb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4108` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `OC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 2.5ms | `tEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Drb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 2.7ms | `Oce` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3806` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1172` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `PUd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorGeometryHasCurves` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:370` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Iwd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `EGb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:32` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `gVb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `qZb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3229` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `fromEntries` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `ped` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `qc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Pcb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4170` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Gzip` | `node:zlib:326` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `UHd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `cloneObject` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `$qb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3001` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `legibleInk` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:137` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Afd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Krc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `collides` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `X8d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `lub` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `POc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `IDb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `sZb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:273` |
| 0.0% | 1.1ms | 0.0% | 2.1ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:315` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `VJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5879` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/generated-identity.ts` |
| 0.0% | 1.1ms | 0.6% | 24.2ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:652` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `ubd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `qlb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3495` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Xb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `evc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `createConvenienceMethod` | `node:zlib` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `JJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Kwd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `yNd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3045` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:519` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Te` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `layoutElkGraph` | `/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `uYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:706` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/block/tokens.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `snapshotCapabilityCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1556` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `createErCreationFold` | `/tmp/pr449-main-integration-20261029-762/src/er/creation.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `fHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `parseErEntityReference` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `fzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `inspectSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:674` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `isForbiddenJsonConfigKey` | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `dmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3792` |
| 0.0% | 1.0ms | 0.0% | 2.3ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:169` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `KFc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.1% | 4.9ms | `UJc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6160` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Emb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `o8b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `hmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4752` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `CBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3403` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `UXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `gyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `contains` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `lld` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 2.3ms | `descriptorOwnsDetectionLine` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2072` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `WXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:212` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `FYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolveRenderStyle` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Jcd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6064` |
| 0.0% | 1.0ms | 0.5% | 19.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `sse` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2293` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `vgb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4328` |
| 0.0% | 1.0ms | 0.1% | 4.0ms | `Dd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1384` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `CYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `transferNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Ogd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `separateErCompounds` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1356` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `r_b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `performanceExperimentEnabled` | `/tmp/pr449-main-integration-20261029-762/src/experimental-performance.ts:12` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:193` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `J$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Qr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `eOc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts` |
| 0.0% | 1.0ms | 0.1% | 6.2ms | `cGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `receiptOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:711` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `xmlScalarCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:88` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Pud` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Fr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:955` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `hasInheritedSvgTextPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `hYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `xxd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/shapes/index.ts:36` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `EJd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 2.3ms | `Cjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4145` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `graphicalSvgArtifact` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `W7d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `XD` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolveRoleStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `_bd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2231` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `expectedCapabilityState` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1641` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:643` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `gAd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 999us | 0.0% | 999us | `writeSync` | `[native code]` |
| 0.0% | 997us | 0.4% | 17.6ms | `IGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5714` |
| 0.0% | 984us | 0.0% | 984us | `snapshotBoundedExternalData` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 98.2% | 3.78s | 0.0% | 0us | `withTextMeasurementExecution` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:135` |
| 93.4% | 3.59s | 0.0% | 0us | `measureRenderStage` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:30` |
| 71.6% | 2.75s | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:31` |
| 71.3% | 2.74s | 0.0% | 0us | `withPerformanceObserver` | `/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts:42` |
| 71.3% | 2.74s | 0.0% | 0us | `withRenderStageObserver` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:20` |
| 71.3% | 2.74s | 0.0% | 0us | `withSvgInspectionCache` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:20` |
| 70.4% | 2.71s | 0.0% | 0us | `consumeResolvedGraphicalRequest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:316` |
| 35.0% | 1.35s | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6428` |
| 30.6% | 1.18s | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:183` |
| 27.3% | 1.05s | 0.0% | 1.7ms | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:140` |
| 25.9% | 1.00s | 0.0% | 0us | `positionFamilyForNativeRender` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:67` |
| 25.9% | 1.00s | 0.0% | 0us | `renderResolvedMermaidSVG` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:270` |
| 25.8% | 994.0ms | 0.0% | 0us | `withGraphLayoutDecisionObserver` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:37` |
| 25.8% | 994.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:123` |
| 25.6% | 987.0ms | 0.0% | 0us | `layout` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:27` |
| 25.3% | 974.5ms | 0.0% | 0us | `runMeasuredGraphBackend` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:83` |
| 24.6% | 948.1ms | 12.3% | 476.8ms | `anonymous` | `[native code]` |
| 24.3% | 937.9ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:205` |
| 24.2% | 935.6ms | 0.0% | 0us | `withDeferredTerminalProjections` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:16` |
| 23.0% | 885.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1188` |
| 22.7% | 875.5ms | 0.0% | 0us | `elkPlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1178` |
| 17.1% | 662.2ms | 0.0% | 0us | `layoutElkGraph` | `/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts:167` |
| 17.1% | 662.2ms | 0.0% | 0us | `SGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6198` |
| 14.1% | 544.8ms | 0.0% | 0us | `bound require` | `[native code]` |
| 14.1% | 544.8ms | 0.0% | 1.3ms | `require` | `[native code]` |
| 12.2% | 471.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 11.9% | 461.8ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:118` |
| 10.7% | 414.0ms | 0.0% | 0us | `inspectOwnedSvgOnce` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:46` |
| 10.7% | 412.4ms | 0.0% | 0us | `applyOutputSecurityPolicy` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:727` |
| 10.3% | 399.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:710` |
| 10.2% | 394.0ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:252` |
| 10.1% | 389.5ms | 0.2% | 7.9ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:161` |
| 10.0% | 386.1ms | 0.0% | 0us | `kbd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5286` |
| 9.8% | 377.7ms | 0.0% | 0us | `lbd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6501` |
| 9.7% | 375.1ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:123` |
| 9.3% | 361.8ms | 0.0% | 0us | `ibd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4754` |
| 9.2% | 356.4ms | 0.0% | 0us | `NQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 9.0% | 346.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:3` |
| 9.0% | 346.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:5` |
| 7.8% | 302.1ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:128` |
| 7.5% | 290.0ms | 0.0% | 0us | `lQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5563` |
| 7.4% | 287.9ms | 0.0% | 0us | `o` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 7.0% | 273.1ms | 0.0% | 0us | `nQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6180` |
| 7.0% | 269.9ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:672` |
| 6.9% | 268.5ms | 0.0% | 0us | `serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:631` |
| 6.5% | 253.6ms | 6.5% | 253.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 6.0% | 232.7ms | 6.0% | 232.7ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` |
| 5.7% | 220.2ms | 0.0% | 2.7ms | `kWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6128` |
| 5.6% | 217.8ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:405` |
| 5.5% | 212.2ms | 0.0% | 0us | `layoutElkGraph` | `/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts:148` |
| 5.2% | 201.4ms | 0.0% | 0us | `$Bd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5423` |
| 5.1% | 198.6ms | 0.0% | 0us | `ensureElk` | `/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts:70` |
| 5.1% | 197.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6513` |
| 5.0% | 196.3ms | 0.0% | 0us | `ELKNode` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6564` |
| 5.0% | 194.2ms | 0.0% | 0us | `Rud` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4804` |
| 4.7% | 184.4ms | 0.0% | 0us | `sBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3732` |
| 4.7% | 184.4ms | 0.0% | 0us | `Efb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3553` |
| 4.7% | 184.4ms | 0.0% | 0us | `TCd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 4.7% | 184.4ms | 0.0% | 0us | `OBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4755` |
| 4.7% | 184.4ms | 0.0% | 0us | `bCd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5164` |
| 4.7% | 183.4ms | 0.0% | 1.2ms | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:137` |
| 4.7% | 183.2ms | 0.0% | 0us | `avd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 4.6% | 180.9ms | 0.6% | 24.5ms | `map` | `[native code]` |
| 4.6% | 178.6ms | 0.0% | 0us | `ysd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6448` |
| 4.6% | 178.6ms | 0.0% | 0us | `hzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5150` |
| 4.6% | 178.6ms | 0.0% | 0us | `msd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1534` |
| 4.2% | 164.6ms | 0.0% | 0us | `gzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5526` |
| 4.2% | 164.6ms | 0.0% | 0us | `jRd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2894` |
| 4.2% | 164.6ms | 0.0% | 0us | `Myd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5212` |
| 4.0% | 157.6ms | 0.0% | 1.2ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:638` |
| 3.9% | 150.6ms | 3.9% | 150.6ms | `gc` | `[native code]` |
| 3.8% | 147.4ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:575` |
| 3.7% | 144.8ms | 0.0% | 0us | `hxd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2249` |
| 3.6% | 139.6ms | 0.0% | 0us | `yyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4942` |
| 3.6% | 139.3ms | 0.0% | 0us | `_8d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5013` |
| 3.6% | 139.1ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1472` |
| 3.5% | 138.3ms | 0.0% | 0us | `PWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 3.4% | 132.8ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:45` |
| 3.3% | 127.7ms | 0.0% | 0us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:111` |
| 3.3% | 127.7ms | 0.0% | 0us | `report` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:235` |
| 3.1% | 122.9ms | 3.1% | 122.9ms | `add` | `[native code]` |
| 3.0% | 117.0ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:186` |
| 3.0% | 115.6ms | 3.0% | 115.6ms | `WC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4239` |
| 3.0% | 115.6ms | 0.0% | 0us | `positionedPaintCertification` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:154` |
| 2.9% | 115.3ms | 0.0% | 1.7ms | `SC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3689` |
| 2.9% | 115.2ms | 0.0% | 0us | `$Ed` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2886` |
| 2.9% | 114.9ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:127` |
| 2.9% | 114.4ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:411` |
| 2.8% | 110.9ms | 0.0% | 0us | `g6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 2.8% | 110.9ms | 0.0% | 0us | `dHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2035` |
| 2.8% | 110.9ms | 0.0% | 0us | `e6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5938` |
| 2.8% | 109.1ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:464` |
| 2.8% | 108.9ms | 0.0% | 0us | `dFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3207` |
| 2.8% | 107.8ms | 0.0% | 0us | `_lb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3916` |
| 2.8% | 107.8ms | 0.0% | 0us | `iHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 2.8% | 107.8ms | 0.0% | 0us | `gHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6343` |
| 2.7% | 104.9ms | 0.0% | 0us | `Otb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2701` |
| 2.6% | 102.8ms | 2.6% | 102.8ms | `set` | `[native code]` |
| 2.6% | 102.2ms | 0.0% | 0us | `xe` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4085` |
| 2.6% | 102.0ms | 0.0% | 0us | `setConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:59` |
| 2.6% | 100.4ms | 0.0% | 1.3ms | `wsb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5362` |
| 2.6% | 100.4ms | 0.0% | 0us | `ejb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2996` |
| 2.5% | 98.1ms | 0.0% | 0us | `bsb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2846` |
| 2.5% | 96.8ms | 0.0% | 0us | `stb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 2.5% | 96.8ms | 0.0% | 0us | `isb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 2.5% | 96.8ms | 0.0% | 0us | `itb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4761` |
| 2.4% | 95.8ms | 0.0% | 0us | `renderCardinality` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:590` |
| 2.4% | 93.4ms | 0.0% | 0us | `install` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:40` |
| 2.3% | 91.6ms | 0.0% | 0us | `r` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 2.3% | 91.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6538` |
| 2.3% | 90.8ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/decode-data-html.js:3` |
| 2.3% | 90.8ms | 2.3% | 90.8ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js` |
| 2.3% | 88.8ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1468` |
| 2.2% | 86.2ms | 0.0% | 0us | `renderCardinality` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:589` |
| 2.1% | 84.5ms | 0.0% | 0us | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:39` |
| 2.1% | 83.5ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:247` |
| 2.1% | 80.9ms | 0.0% | 0us | `inspectPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:98` |
| 1.9% | 77.0ms | 0.0% | 0us | `node:zlib` | `node:zlib:2` |
| 1.9% | 74.2ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:167` |
| 1.8% | 72.9ms | 0.0% | 0us | `rendered` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:427` |
| 1.8% | 72.9ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1031` |
| 1.8% | 71.6ms | 0.0% | 0us | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1453` |
| 1.8% | 70.4ms | 0.0% | 0us | `render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:394` |
| 1.7% | 68.2ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1502` |
| 1.6% | 64.3ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:283` |
| 1.6% | 63.7ms | 0.0% | 0us | `node:stream` | `node:stream:2` |
| 1.6% | 63.7ms | 0.0% | 0us | `assertAdmissibleSceneDoc` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation.ts:247` |
| 1.6% | 63.7ms | 0.0% | 0us | `admitSceneDocumentWith` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:270` |
| 1.6% | 61.9ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:906` |
| 1.5% | 60.9ms | 1.5% | 60.9ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/shapes/corners.ts:41` |
| 1.5% | 60.3ms | 0.0% | 0us | `groupValidation` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:506` |
| 1.5% | 60.0ms | 0.0% | 0us | `dte` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4303` |
| 1.5% | 59.8ms | 0.1% | 5.2ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:166` |
| 1.4% | 57.4ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:242` |
| 1.4% | 56.7ms | 0.1% | 6.3ms | `captureNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:101` |
| 1.4% | 56.7ms | 0.0% | 0us | `internal:stream` | `internal:stream:2` |
| 1.4% | 56.6ms | 0.0% | 0us | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:95` |
| 1.3% | 53.5ms | 0.0% | 0us | `vGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5628` |
| 1.3% | 53.4ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:208` |
| 1.3% | 50.4ms | 0.0% | 0us | `captureNativeGroupParse` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:173` |
| 1.2% | 49.3ms | 0.0% | 0us | `internal:streams/compose` | `internal:streams/compose:2` |
| 1.2% | 47.2ms | 0.0% | 0us | `YEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3717` |
| 1.1% | 44.4ms | 0.0% | 0us | `node:fs` | `node:fs:8` |
| 1.1% | 43.0ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:587` |
| 1.1% | 43.0ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1621` |
| 1.0% | 42.1ms | 0.0% | 3.7ms | `flatIntoArrayWithCallback` | `[native code]` |
| 1.0% | 41.5ms | 1.0% | 41.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:129` |
| 1.0% | 40.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:175` |
| 1.0% | 40.7ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:150` |
| 1.0% | 40.6ms | 0.0% | 0us | `internal:streams/pipeline` | `internal:streams/pipeline:2` |
| 1.0% | 39.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:3` |
| 1.0% | 39.1ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1185` |
| 1.0% | 38.7ms | 0.0% | 3.2ms | `cJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6363` |
| 0.9% | 37.9ms | 0.1% | 4.8ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:85` |
| 0.9% | 36.9ms | 0.6% | 24.6ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:170` |
| 0.9% | 36.6ms | 0.6% | 25.7ms | `test` | `[native code]` |
| 0.9% | 36.1ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:829` |
| 0.9% | 36.0ms | 0.0% | 0us | `MGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.9% | 35.9ms | 0.6% | 23.1ms | `r1d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.9% | 34.8ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:184` |
| 0.9% | 34.7ms | 0.0% | 0us | `BGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5991` |
| 0.8% | 34.6ms | 0.0% | 2.9ms | `collectNativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:146` |
| 0.8% | 33.6ms | 0.8% | 33.6ms | `defineProperty` | `[native code]` |
| 0.8% | 33.0ms | 0.0% | 0us | `executeInspectedGraphicalRequest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:297` |
| 0.8% | 32.8ms | 0.0% | 3.2ms | `p_b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6372` |
| 0.8% | 32.5ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:215` |
| 0.8% | 32.4ms | 0.0% | 0us | `J$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6138` |
| 0.8% | 31.7ms | 0.0% | 0us | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:621` |
| 0.8% | 31.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/families.ts:8` |
| 0.8% | 31.6ms | 0.0% | 0us | `visitSvgStartTagsFresh` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:116` |
| 0.8% | 31.5ms | 0.6% | 25.4ms | `stringify` | `[native code]` |
| 0.8% | 31.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:5` |
| 0.8% | 31.2ms | 0.8% | 31.2ms | `connectorInlineLabelSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:757` |
| 0.7% | 29.5ms | 0.0% | 1.2ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` |
| 0.7% | 28.9ms | 0.0% | 0us | `sOc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.7% | 28.9ms | 0.0% | 1.3ms | `mQc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6283` |
| 0.7% | 28.9ms | 0.0% | 0us | `pOc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6169` |
| 0.7% | 28.4ms | 0.0% | 1.3ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:94` |
| 0.7% | 28.2ms | 0.7% | 28.2ms | `getOwnPropertyDescriptor` | `[native code]` |
| 0.7% | 27.9ms | 0.7% | 27.9ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` |
| 0.7% | 27.9ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1473` |
| 0.6% | 26.5ms | 0.0% | 2.2ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:130` |
| 0.6% | 26.3ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:90` |
| 0.6% | 26.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:974` |
| 0.6% | 26.0ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1088` |
| 0.6% | 25.6ms | 0.0% | 3.0ms | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` |
| 0.6% | 25.4ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:2` |
| 0.6% | 25.3ms | 0.0% | 0us | `Z8d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5453` |
| 0.6% | 25.0ms | 0.0% | 0us | `xGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4342` |
| 0.6% | 24.8ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:627` |
| 0.6% | 24.6ms | 0.0% | 0us | `NFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3609` |
| 0.6% | 24.4ms | 0.0% | 0us | `BNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.6% | 24.2ms | 0.0% | 1.1ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:652` |
| 0.6% | 24.1ms | 0.0% | 0us | `visitSvgFirstTagAttributes` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:106` |
| 0.6% | 23.6ms | 0.0% | 0us | `renderRelationshipLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:543` |
| 0.5% | 23.0ms | 0.0% | 0us | `vNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6480` |
| 0.5% | 22.8ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:252` |
| 0.5% | 22.7ms | 0.5% | 22.7ms | `replaceField` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:294` |
| 0.5% | 22.7ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:719` |
| 0.5% | 22.4ms | 0.0% | 2.6ms | `some` | `[native code]` |
| 0.5% | 21.5ms | 0.0% | 0us | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` |
| 0.5% | 21.2ms | 0.0% | 0us | `forEach` | `[native code]` |
| 0.5% | 21.1ms | 0.0% | 0us | `cloneValue` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.5% | 20.8ms | 0.0% | 0us | `Wr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5534` |
| 0.5% | 20.2ms | 0.0% | 2.4ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:729` |
| 0.5% | 20.2ms | 0.5% | 20.2ms | `freeze` | `[native code]` |
| 0.5% | 19.9ms | 0.3% | 13.4ms | `q_b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6380` |
| 0.5% | 19.8ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:825` |
| 0.5% | 19.7ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.5% | 19.3ms | 0.0% | 0us | `erCardinalityInk` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:126` |
| 0.5% | 19.3ms | 0.0% | 0us | `Old` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5211` |
| 0.4% | 19.2ms | 0.4% | 19.2ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.4% | 19.2ms | 0.0% | 0us | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:537` |
| 0.4% | 19.1ms | 0.0% | 0us | `walk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1749` |
| 0.4% | 19.0ms | 0.0% | 1.8ms | `JD` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2608` |
| 0.4% | 18.7ms | 0.0% | 2.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.4% | 18.7ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:228` |
| 0.4% | 18.5ms | 0.0% | 0us | `Crb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4568` |
| 0.4% | 18.4ms | 0.0% | 0us | `I$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6360` |
| 0.4% | 18.4ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1637` |
| 0.4% | 18.0ms | 0.0% | 0us | `textSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1651` |
| 0.4% | 18.0ms | 0.0% | 0us | `hMd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5046` |
| 0.4% | 17.8ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:22` |
| 0.4% | 17.8ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:817` |
| 0.4% | 17.7ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:221` |
| 0.4% | 17.7ms | 0.4% | 17.7ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.4% | 17.6ms | 0.0% | 997us | `IGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5714` |
| 0.4% | 17.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` |
| 0.4% | 17.6ms | 0.0% | 0us | `expandLocalReferences` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` |
| 0.4% | 17.4ms | 0.0% | 0us | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:471` |
| 0.4% | 17.4ms | 0.0% | 0us | `eNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6124` |
| 0.4% | 17.4ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:420` |
| 0.4% | 17.3ms | 0.0% | 0us | `rwb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.4% | 17.3ms | 0.0% | 0us | `dwb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1561` |
| 0.4% | 17.2ms | 0.0% | 0us | `UWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.4% | 17.2ms | 0.0% | 0us | `rJd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5517` |
| 0.4% | 17.2ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:998` |
| 0.4% | 17.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:32` |
| 0.4% | 17.1ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:172` |
| 0.4% | 17.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:8` |
| 0.4% | 16.9ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:653` |
| 0.4% | 16.9ms | 0.0% | 0us | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:200` |
| 0.4% | 16.9ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:49` |
| 0.4% | 16.9ms | 0.0% | 0us | `kFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.4% | 16.8ms | 0.0% | 0us | `AIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6065` |
| 0.4% | 16.8ms | 0.0% | 0us | `X8d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6508` |
| 0.4% | 16.3ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` |
| 0.4% | 16.3ms | 0.0% | 0us | `Drb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2736` |
| 0.4% | 16.2ms | 0.0% | 1.3ms | `edd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4340` |
| 0.4% | 16.0ms | 0.0% | 0us | `eGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.4% | 15.9ms | 0.0% | 0us | `AGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6121` |
| 0.4% | 15.9ms | 0.0% | 0us | `OGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.4% | 15.9ms | 0.0% | 0us | `pGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6096` |
| 0.4% | 15.8ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1879` |
| 0.4% | 15.7ms | 0.0% | 0us | `zNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4723` |
| 0.4% | 15.6ms | 0.0% | 0us | `_Dc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6262` |
| 0.4% | 15.6ms | 0.0% | 0us | `cEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.4% | 15.5ms | 0.0% | 0us | `XBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5602` |
| 0.3% | 15.3ms | 0.0% | 1.2ms | `yCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.3% | 15.3ms | 0.0% | 0us | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:220` |
| 0.3% | 15.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1245` |
| 0.3% | 15.2ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:195` |
| 0.3% | 15.2ms | 0.0% | 0us | `renderRelationshipLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:534` |
| 0.3% | 14.5ms | 0.3% | 14.5ms | `@lazy` | `[native code]` |
| 0.3% | 14.2ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:195` |
| 0.3% | 14.1ms | 0.0% | 0us | `Mz` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3395` |
| 0.3% | 14.1ms | 0.0% | 0us | `jdb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5091` |
| 0.3% | 14.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6511` |
| 0.3% | 14.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3550` |
| 0.3% | 14.0ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:171` |
| 0.3% | 14.0ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:509` |
| 0.3% | 13.8ms | 0.0% | 0us | `oWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6117` |
| 0.3% | 13.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6429` |
| 0.3% | 13.6ms | 0.0% | 0us | `UGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6210` |
| 0.3% | 13.6ms | 0.0% | 0us | `ensureElk` | `/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts:78` |
| 0.3% | 13.6ms | 0.0% | 0us | `internal:streams/legacy` | `internal:streams/legacy:2` |
| 0.3% | 13.5ms | 0.0% | 1.3ms | `fVb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6002` |
| 0.3% | 13.5ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1878` |
| 0.3% | 13.4ms | 0.0% | 3.7ms | `sceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` |
| 0.3% | 13.2ms | 0.0% | 0us | `KKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5701` |
| 0.3% | 13.2ms | 0.0% | 0us | `JKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4417` |
| 0.3% | 13.2ms | 0.0% | 2.4ms | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` |
| 0.3% | 13.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:780` |
| 0.3% | 13.2ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:403` |
| 0.3% | 13.2ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:80` |
| 0.3% | 13.1ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:218` |
| 0.3% | 12.9ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:279` |
| 0.3% | 12.8ms | 0.0% | 0us | `zpd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5264` |
| 0.3% | 12.8ms | 0.0% | 0us | `connector/transform/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:631` |
| 0.3% | 12.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:7` |
| 0.3% | 12.7ms | 0.0% | 0us | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:277` |
| 0.3% | 12.7ms | 0.0% | 0us | `sdb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1284` |
| 0.3% | 12.7ms | 0.0% | 0us | `gdd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3990` |
| 0.3% | 12.7ms | 0.0% | 0us | `g` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5090` |
| 0.3% | 12.7ms | 0.0% | 0us | `OGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1536` |
| 0.3% | 12.7ms | 0.0% | 0us | `Jz` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2343` |
| 0.3% | 12.6ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:259` |
| 0.3% | 12.6ms | 0.0% | 0us | `finalizeErRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:28` |
| 0.3% | 12.6ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1301` |
| 0.3% | 12.5ms | 0.0% | 0us | `VBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1652` |
| 0.3% | 12.5ms | 0.0% | 0us | `E$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6045` |
| 0.3% | 12.4ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` |
| 0.3% | 12.3ms | 0.0% | 0us | `kyb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.3% | 12.3ms | 0.0% | 0us | `H7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.3% | 12.3ms | 0.0% | 0us | `A7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5768` |
| 0.3% | 12.3ms | 0.0% | 0us | `C7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5795` |
| 0.3% | 11.8ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:92` |
| 0.3% | 11.8ms | 0.0% | 3.1ms | `jGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.3% | 11.7ms | 0.2% | 9.2ms | `(unknown)` | `[native code]` |
| 0.3% | 11.6ms | 0.0% | 0us | `dBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5445` |
| 0.3% | 11.6ms | 0.0% | 0us | `VBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5912` |
| 0.2% | 11.4ms | 0.1% | 4.4ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:156` |
| 0.2% | 11.4ms | 0.0% | 0us | `layoutErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1128` |
| 0.2% | 11.4ms | 0.0% | 0us | `lQc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5558` |
| 0.2% | 11.4ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:172` |
| 0.2% | 11.3ms | 0.2% | 11.3ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.2% | 11.3ms | 0.2% | 11.3ms | `get` | `[native code]` |
| 0.2% | 11.3ms | 0.0% | 0us | `resolvedColorValue` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:601` |
| 0.2% | 11.0ms | 0.0% | 0us | `paintAttribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:493` |
| 0.2% | 11.0ms | 0.1% | 5.9ms | `every` | `[native code]` |
| 0.2% | 10.9ms | 0.0% | 3.7ms | `xKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6339` |
| 0.2% | 10.9ms | 0.0% | 3.5ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:596` |
| 0.2% | 10.7ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:148` |
| 0.2% | 10.7ms | 0.2% | 10.7ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:96` |
| 0.2% | 10.7ms | 0.0% | 1.4ms | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:702` |
| 0.2% | 10.6ms | 0.2% | 10.6ms | `ID` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.2% | 10.6ms | 0.0% | 0us | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:102` |
| 0.2% | 10.6ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:237` |
| 0.2% | 10.4ms | 0.2% | 9.1ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:471` |
| 0.2% | 10.4ms | 0.0% | 0us | `internal:streams/destroy` | `internal:streams/destroy:2` |
| 0.2% | 10.4ms | 0.0% | 0us | `internal:errors` | `internal:errors:2` |
| 0.2% | 10.2ms | 0.0% | 0us | `elkPlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1177` |
| 0.2% | 10.1ms | 0.2% | 10.1ms | `OFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2138` |
| 0.2% | 10.1ms | 0.0% | 0us | `QKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4743` |
| 0.2% | 10.1ms | 0.0% | 0us | `PKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6335` |
| 0.2% | 10.0ms | 0.0% | 0us | `PBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3518` |
| 0.2% | 9.9ms | 0.0% | 0us | `DQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6282` |
| 0.2% | 9.9ms | 0.0% | 0us | `SBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5223` |
| 0.2% | 9.9ms | 0.0% | 0us | `lDd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 9.9ms | 0.0% | 0us | `VAd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6163` |
| 0.2% | 9.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:713` |
| 0.2% | 9.9ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:431` |
| 0.2% | 9.8ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:941` |
| 0.2% | 9.8ms | 0.0% | 0us | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1501` |
| 0.2% | 9.6ms | 0.0% | 0us | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:569` |
| 0.2% | 9.6ms | 0.0% | 0us | `BIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6071` |
| 0.2% | 9.5ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1322` |
| 0.2% | 9.5ms | 0.2% | 9.5ms | `ownFragment` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:116` |
| 0.2% | 9.4ms | 0.2% | 8.0ms | `Set` | `[native code]` |
| 0.2% | 9.4ms | 0.0% | 0us | `A6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6285` |
| 0.2% | 9.4ms | 0.0% | 0us | `C6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 9.3ms | 0.0% | 0us | `Ltd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 9.3ms | 0.0% | 2.3ms | `Usd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3200` |
| 0.2% | 9.3ms | 0.0% | 0us | `Nr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 9.2ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:237` |
| 0.2% | 9.1ms | 0.0% | 0us | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:530` |
| 0.2% | 9.1ms | 0.2% | 9.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:114` |
| 0.2% | 9.1ms | 0.0% | 0us | `a7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 9.1ms | 0.0% | 0us | `U6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6274` |
| 0.2% | 9.1ms | 0.0% | 0us | `QGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 9.1ms | 0.0% | 0us | `yGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4405` |
| 0.2% | 9.1ms | 0.2% | 9.1ms | `withPerformanceObserver` | `/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts:44` |
| 0.2% | 9.1ms | 0.0% | 0us | `tag` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:152` |
| 0.2% | 9.1ms | 0.0% | 0us | `crb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4586` |
| 0.2% | 9.0ms | 0.0% | 0us | `measureErEntities` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:451` |
| 0.2% | 9.0ms | 0.2% | 9.0ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.2% | 8.9ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:125` |
| 0.2% | 8.9ms | 0.0% | 0us | `_Bb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3794` |
| 0.2% | 8.9ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` |
| 0.2% | 8.9ms | 0.2% | 8.9ms | `Byb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.2% | 8.9ms | 0.0% | 0us | `Izb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 8.9ms | 0.0% | 0us | `TKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6412` |
| 0.2% | 8.9ms | 0.0% | 0us | `rg` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 8.9ms | 0.0% | 0us | `clb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 8.9ms | 0.0% | 0us | `ed` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2773` |
| 0.2% | 8.9ms | 0.0% | 0us | `Mg` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2595` |
| 0.2% | 8.8ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:738` |
| 0.2% | 8.8ms | 0.0% | 0us | `sort` | `[native code]` |
| 0.2% | 8.8ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:169` |
| 0.2% | 8.7ms | 0.2% | 8.7ms | `assign` | `[native code]` |
| 0.2% | 8.7ms | 0.0% | 0us | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:315` |
| 0.2% | 8.6ms | 0.0% | 0us | `o_b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6317` |
| 0.2% | 8.5ms | 0.0% | 0us | `install` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:41` |
| 0.2% | 8.5ms | 0.1% | 4.2ms | `writeFileSync` | `[native code]` |
| 0.2% | 8.5ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1737` |
| 0.2% | 8.5ms | 0.0% | 0us | `normalizeMermaidSourceWithOverrides` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:762` |
| 0.2% | 8.5ms | 0.0% | 0us | `tCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 8.4ms | 0.0% | 0us | `KIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 8.4ms | 0.0% | 0us | `IKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6016` |
| 0.2% | 8.3ms | 0.2% | 8.3ms | `has` | `[native code]` |
| 0.2% | 8.3ms | 0.2% | 8.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.2% | 8.3ms | 0.0% | 0us | `o8b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6246` |
| 0.2% | 8.3ms | 0.0% | 0us | `$Dc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5966` |
| 0.2% | 8.2ms | 0.0% | 0us | `Qr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 8.2ms | 0.2% | 8.2ms | `Hmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1049` |
| 0.2% | 8.2ms | 0.0% | 0us | `MZb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 8.2ms | 0.0% | 0us | `OZb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3622` |
| 0.2% | 8.2ms | 0.0% | 0us | `El` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 8.2ms | 0.0% | 0us | `HKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6196` |
| 0.2% | 8.2ms | 0.0% | 0us | `wGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5747` |
| 0.2% | 8.2ms | 0.0% | 0us | `jXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.2% | 8.2ms | 0.1% | 3.9ms | `aXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6207` |
| 0.2% | 8.2ms | 0.0% | 0us | `Vvb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3875` |
| 0.2% | 8.2ms | 0.0% | 0us | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:397` |
| 0.2% | 8.1ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:311` |
| 0.2% | 8.1ms | 0.0% | 0us | `cBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5045` |
| 0.2% | 8.1ms | 0.0% | 0us | `UBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4216` |
| 0.2% | 8.1ms | 0.0% | 0us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:275` |
| 0.2% | 8.1ms | 0.0% | 0us | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1318` |
| 0.2% | 8.1ms | 0.0% | 1.4ms | `CIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4866` |
| 0.2% | 8.1ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:201` |
| 0.2% | 8.0ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:617` |
| 0.2% | 8.0ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1592` |
| 0.2% | 8.0ms | 0.0% | 0us | `transformedHitDistance` | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:27` |
| 0.2% | 8.0ms | 0.2% | 8.0ms | `connectorSegments` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.2% | 8.0ms | 0.0% | 0us | `hitsTransformed` | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:47` |
| 0.2% | 8.0ms | 0.0% | 0us | `kQc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5354` |
| 0.2% | 8.0ms | 0.2% | 8.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.2% | 7.9ms | 0.0% | 0us | `E7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5366` |
| 0.2% | 7.9ms | 0.0% | 2.8ms | `filter` | `[native code]` |
| 0.2% | 7.9ms | 0.1% | 5.1ms | `Rc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5459` |
| 0.2% | 7.9ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:214` |
| 0.2% | 7.9ms | 0.1% | 6.6ms | `teb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1540` |
| 0.2% | 7.8ms | 0.0% | 0us | `yIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5435` |
| 0.2% | 7.8ms | 0.0% | 0us | `SBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3015` |
| 0.2% | 7.8ms | 0.2% | 7.8ms | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:272` |
| 0.2% | 7.8ms | 0.0% | 0us | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:515` |
| 0.2% | 7.8ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:722` |
| 0.2% | 7.8ms | 0.1% | 4.5ms | `escapeAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` |
| 0.2% | 7.7ms | 0.0% | 0us | `mWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5832` |
| 0.1% | 7.6ms | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:126` |
| 0.1% | 7.6ms | 0.0% | 0us | `documentOpen` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:135` |
| 0.1% | 7.6ms | 0.0% | 0us | `attachSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:495` |
| 0.1% | 7.6ms | 0.0% | 0us | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:104` |
| 0.1% | 7.6ms | 0.1% | 7.6ms | `xmlNameCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:87` |
| 0.1% | 7.4ms | 0.0% | 1.7ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:778` |
| 0.1% | 7.4ms | 0.0% | 0us | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:213` |
| 0.1% | 7.4ms | 0.0% | 0us | `CGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 7.3ms | 0.0% | 0us | `W8d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6489` |
| 0.1% | 7.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:6` |
| 0.1% | 7.3ms | 0.1% | 7.3ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:796` |
| 0.1% | 7.2ms | 0.0% | 0us | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:15` |
| 0.1% | 7.2ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:678` |
| 0.1% | 7.2ms | 0.1% | 7.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.1% | 7.1ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1783` |
| 0.1% | 7.1ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:761` |
| 0.1% | 7.1ms | 0.1% | 7.1ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:129` |
| 0.1% | 7.1ms | 0.0% | 0us | `Lac` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5876` |
| 0.1% | 7.1ms | 0.0% | 0us | `Nac` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:446` |
| 0.1% | 7.0ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:685` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:205` |
| 0.1% | 7.0ms | 0.0% | 0us | `setConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:53` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `RegExp` | `[native code]` |
| 0.1% | 7.0ms | 0.1% | 7.0ms | `join` | `[native code]` |
| 0.1% | 7.0ms | 0.1% | 4.1ms | `Meb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3984` |
| 0.1% | 7.0ms | 0.0% | 0us | `zeb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2904` |
| 0.1% | 6.9ms | 0.0% | 0us | `resolveRoleStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:251` |
| 0.1% | 6.9ms | 0.1% | 6.9ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 6.9ms | 0.0% | 0us | `layout` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:23` |
| 0.1% | 6.9ms | 0.0% | 0us | `dPc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5348` |
| 0.1% | 6.8ms | 0.0% | 0us | `_Hb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 6.8ms | 0.0% | 0us | `ngc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4403` |
| 0.1% | 6.8ms | 0.1% | 6.8ms | `Erb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4055` |
| 0.1% | 6.8ms | 0.1% | 6.8ms | `estimatedResidency` | `/tmp/pr449-main-integration-20261029-762/src/experimental/cache-residency.ts` |
| 0.1% | 6.8ms | 0.0% | 0us | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:477` |
| 0.1% | 6.7ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:88` |
| 0.1% | 6.7ms | 0.0% | 0us | `Wlb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2046` |
| 0.1% | 6.7ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:110` |
| 0.1% | 6.7ms | 0.0% | 1.8ms | `relationAccessibility` | `/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` |
| 0.1% | 6.7ms | 0.0% | 0us | `nWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6100` |
| 0.1% | 6.7ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1765` |
| 0.1% | 6.6ms | 0.0% | 0us | `admitSceneDocumentWith` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:268` |
| 0.1% | 6.6ms | 0.0% | 2.3ms | `Pe` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 6.6ms | 0.1% | 4.8ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:175` |
| 0.1% | 6.5ms | 0.0% | 0us | `N$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6487` |
| 0.1% | 6.5ms | 0.1% | 6.5ms | `ID` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4818` |
| 0.1% | 6.5ms | 0.0% | 0us | `lHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4600` |
| 0.1% | 6.5ms | 0.0% | 0us | `oHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6406` |
| 0.1% | 6.5ms | 0.0% | 0us | `i4b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4121` |
| 0.1% | 6.5ms | 0.0% | 0us | `k4b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 6.5ms | 0.0% | 0us | `Dyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4148` |
| 0.1% | 6.5ms | 0.1% | 5.3ms | `sourceSlice` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:55` |
| 0.1% | 6.5ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:158` |
| 0.1% | 6.5ms | 0.0% | 1.4ms | `xCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3738` |
| 0.1% | 6.5ms | 0.0% | 0us | `fHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6333` |
| 0.1% | 6.5ms | 0.0% | 0us | `Xr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3590` |
| 0.1% | 6.5ms | 0.0% | 0us | `markerTerminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:294` |
| 0.1% | 6.5ms | 0.0% | 0us | `prepareMarkerTerminals` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:9` |
| 0.1% | 6.5ms | 0.0% | 0us | `fzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6506` |
| 0.1% | 6.4ms | 0.1% | 6.4ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:110` |
| 0.1% | 6.4ms | 0.0% | 0us | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:701` |
| 0.1% | 6.4ms | 0.0% | 0us | `projectSvgCss` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:287` |
| 0.1% | 6.4ms | 0.0% | 0us | `inlineResolvedColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:636` |
| 0.1% | 6.4ms | 0.1% | 6.4ms | `xpd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 6.4ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:609` |
| 0.1% | 6.4ms | 0.0% | 1.1ms | `tb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4108` |
| 0.1% | 6.4ms | 0.0% | 1.1ms | `performIteration` | `[native code]` |
| 0.1% | 6.4ms | 0.1% | 6.4ms | `flatIntoArray` | `[native code]` |
| 0.1% | 6.4ms | 0.0% | 3.0ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:200` |
| 0.1% | 6.4ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:140` |
| 0.1% | 6.3ms | 0.0% | 0us | `sDb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1477` |
| 0.1% | 6.3ms | 0.0% | 0us | `kDb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2355` |
| 0.1% | 6.3ms | 0.0% | 0us | `XC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3749` |
| 0.1% | 6.3ms | 0.1% | 6.3ms | `hasOwn` | `[native code]` |
| 0.1% | 6.3ms | 0.1% | 6.3ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:92` |
| 0.1% | 6.3ms | 0.0% | 0us | `drawn` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:421` |
| 0.1% | 6.2ms | 0.0% | 0us | `find` | `[native code]` |
| 0.1% | 6.2ms | 0.1% | 6.2ms | `outcome` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.1% | 6.2ms | 0.0% | 0us | `AKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5853` |
| 0.1% | 6.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:16` |
| 0.1% | 6.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1267` |
| 0.1% | 6.2ms | 0.0% | 1.0ms | `cGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 6.2ms | 0.0% | 0us | `Rsd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4802` |
| 0.1% | 6.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:875` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:526` |
| 0.1% | 6.1ms | 0.0% | 0us | `$lb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4223` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:308` |
| 0.1% | 6.1ms | 0.0% | 0us | `_vb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 6.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:36` |
| 0.1% | 6.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1520` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `Wr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 6.0ms | 0.0% | 0us | `get receipt` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:347` |
| 0.1% | 6.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1483` |
| 0.1% | 5.9ms | 0.0% | 0us | `KFc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6289` |
| 0.1% | 5.9ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:645` |
| 0.1% | 5.9ms | 0.0% | 0us | `KKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3969` |
| 0.1% | 5.9ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:164` |
| 0.1% | 5.8ms | 0.0% | 0us | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:171` |
| 0.1% | 5.8ms | 0.0% | 0us | `lZb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3303` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `cgd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 5.8ms | 0.0% | 2.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` |
| 0.1% | 5.8ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:132` |
| 0.1% | 5.7ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:813` |
| 0.1% | 5.7ms | 0.0% | 0us | `CZd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 5.7ms | 0.0% | 1.9ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:109` |
| 0.1% | 5.7ms | 0.0% | 0us | `imb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1255` |
| 0.1% | 5.7ms | 0.0% | 0us | `bwb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 5.6ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1583` |
| 0.1% | 5.6ms | 0.1% | 4.3ms | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:17` |
| 0.1% | 5.6ms | 0.1% | 5.6ms | `Dwd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 5.6ms | 0.0% | 3.4ms | `compare` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:33` |
| 0.1% | 5.6ms | 0.1% | 5.6ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 5.5ms | 0.1% | 5.5ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` |
| 0.1% | 5.5ms | 0.1% | 5.5ms | `importModule` | `[native code]` |
| 0.1% | 5.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:7` |
| 0.1% | 5.5ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:682` |
| 0.1% | 5.5ms | 0.0% | 0us | `lgc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5300` |
| 0.1% | 5.5ms | 0.0% | 0us | `IHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4388` |
| 0.1% | 5.5ms | 0.0% | 0us | `GIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 5.5ms | 0.1% | 5.5ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 5.5ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:219` |
| 0.1% | 5.5ms | 0.0% | 0us | `zgc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 5.5ms | 0.1% | 5.5ms | `slice` | `[native code]` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `min` | `[native code]` |
| 0.1% | 5.4ms | 0.0% | 0us | `MQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1322` |
| 0.1% | 5.4ms | 0.0% | 0us | `EQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2079` |
| 0.1% | 5.4ms | 0.0% | 0us | `yqd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3153` |
| 0.1% | 5.4ms | 0.0% | 0us | `qQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3348` |
| 0.1% | 5.4ms | 0.0% | 0us | `dyc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 5.4ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:197` |
| 0.1% | 5.4ms | 0.1% | 5.4ms | `compositeCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:277` |
| 0.1% | 5.4ms | 0.0% | 0us | `internal:streams/operators` | `internal:streams/operators:2` |
| 0.1% | 5.4ms | 0.0% | 0us | `internal:streams/end-of-stream` | `internal:streams/end-of-stream:17` |
| 0.1% | 5.3ms | 0.0% | 0us | `V6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5950` |
| 0.1% | 5.3ms | 0.0% | 0us | `N6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5204` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `Jmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 5.3ms | 0.0% | 1.3ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:251` |
| 0.1% | 5.3ms | 0.0% | 0us | `t6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 5.3ms | 0.0% | 0us | `q6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6309` |
| 0.1% | 5.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:8` |
| 0.1% | 5.3ms | 0.1% | 4.0ms | `replace` | `[native code]` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `rb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4337` |
| 0.1% | 5.3ms | 0.1% | 5.3ms | `Gsd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5992` |
| 0.1% | 5.3ms | 0.0% | 2.9ms | `(anonymous)` | `[native code]` |
| 0.1% | 5.3ms | 0.0% | 3.5ms | `value` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:124` |
| 0.1% | 5.2ms | 0.1% | 5.2ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:304` |
| 0.1% | 5.2ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:486` |
| 0.1% | 5.2ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:181` |
| 0.1% | 5.2ms | 0.0% | 0us | `uBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5562` |
| 0.1% | 5.2ms | 0.0% | 0us | `ZBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4297` |
| 0.1% | 5.2ms | 0.0% | 2.6ms | `next` | `[native code]` |
| 0.1% | 5.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:10` |
| 0.1% | 5.2ms | 0.0% | 0us | `enoughLead` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:300` |
| 0.1% | 5.1ms | 0.0% | 0us | `asb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 5.1ms | 0.0% | 0us | `LFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4883` |
| 0.1% | 5.1ms | 0.0% | 0us | `Cyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3389` |
| 0.1% | 5.1ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1728` |
| 0.1% | 5.1ms | 0.0% | 0us | `AEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4868` |
| 0.1% | 5.1ms | 0.0% | 0us | `BEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5967` |
| 0.1% | 5.1ms | 0.0% | 0us | `IEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 5.1ms | 0.0% | 0us | `FVd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5449` |
| 0.1% | 5.1ms | 0.0% | 3.7ms | `Ieb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5583` |
| 0.1% | 5.1ms | 0.0% | 0us | `seb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2298` |
| 0.1% | 5.1ms | 0.0% | 1.8ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:484` |
| 0.1% | 5.1ms | 0.0% | 0us | `vsb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2743` |
| 0.1% | 5.1ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1782` |
| 0.1% | 5.1ms | 0.1% | 5.1ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:174` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:94` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:444` |
| 0.1% | 5.0ms | 0.0% | 0us | `canonicalizeSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:485` |
| 0.1% | 5.0ms | 0.0% | 0us | `canonicalOpeningTag` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:443` |
| 0.1% | 5.0ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:376` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.1% | 5.0ms | 0.0% | 1.8ms | `_x` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4182` |
| 0.1% | 5.0ms | 0.0% | 0us | `detectorClaims` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1596` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `owb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2807` |
| 0.1% | 5.0ms | 0.0% | 0us | `resolveSvgColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:758` |
| 0.1% | 5.0ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:310` |
| 0.1% | 5.0ms | 0.0% | 0us | `transformSvgCssValues` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:308` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `sceneGroupOpacity` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:234` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.1% | 4.9ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:284` |
| 0.1% | 4.9ms | 0.0% | 0us | `wbd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6225` |
| 0.1% | 4.9ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:101` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.1% | 4.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:142` |
| 0.1% | 4.9ms | 0.0% | 0us | `projectErPositioned` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:25` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `defineProperties` | `[native code]` |
| 0.1% | 4.9ms | 0.0% | 0us | `buildErElkGraph` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:491` |
| 0.1% | 4.9ms | 0.0% | 0us | `K0b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5530` |
| 0.1% | 4.9ms | 0.0% | 0us | `L0b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6004` |
| 0.1% | 4.9ms | 0.0% | 0us | `Ftd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 4.9ms | 0.0% | 0us | `yXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 4.9ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1049` |
| 0.1% | 4.9ms | 0.0% | 0us | `verifyNoExternalRefs` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:701` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `connectorMarkerPaintRegions` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 4.9ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1944` |
| 0.1% | 4.9ms | 0.0% | 1.0ms | `UJc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6160` |
| 0.1% | 4.8ms | 0.0% | 0us | `gjd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6493` |
| 0.1% | 4.8ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:156` |
| 0.1% | 4.8ms | 0.0% | 0us | `hjd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:920` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1467` |
| 0.1% | 4.8ms | 0.0% | 0us | `pWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6069` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `p1d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:8` |
| 0.1% | 4.8ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:156` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `UBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 4.8ms | 0.0% | 0us | `hitsTransformed` | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:43` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `transformMatrix` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts` |
| 0.1% | 4.8ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:171` |
| 0.1% | 4.8ms | 0.1% | 4.8ms | `intersects` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.1% | 4.7ms | 0.0% | 0us | `NGb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5952` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` |
| 0.1% | 4.7ms | 0.0% | 0us | `Uvb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2801` |
| 0.1% | 4.7ms | 0.0% | 0us | `ijd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 4.7ms | 0.0% | 0us | `gFc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 4.7ms | 0.0% | 3.4ms | `TEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5052` |
| 0.1% | 4.7ms | 0.0% | 0us | `fFc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:479` |
| 0.1% | 4.7ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:40` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `Vr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4327` |
| 0.1% | 4.7ms | 0.0% | 0us | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:36` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `/^\s*$/` | `[native code]` |
| 0.1% | 4.7ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:774` |
| 0.1% | 4.7ms | 0.0% | 0us | `validateRole` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:693` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` |
| 0.1% | 4.7ms | 0.1% | 4.7ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:203` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:161` |
| 0.1% | 4.6ms | 0.0% | 3.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.1% | 4.6ms | 0.0% | 0us | `jIc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4928` |
| 0.1% | 4.6ms | 0.0% | 0us | `OIc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5759` |
| 0.1% | 4.6ms | 0.0% | 0us | `qGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5356` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `ownData` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:48` |
| 0.1% | 4.6ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:276` |
| 0.1% | 4.6ms | 0.0% | 0us | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:91` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:177` |
| 0.1% | 4.5ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:177` |
| 0.1% | 4.5ms | 0.0% | 0us | `UHd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5496` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `attributeRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `createNativePaintEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 4.5ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:158` |
| 0.1% | 4.5ms | 0.0% | 0us | `dnb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2739` |
| 0.1% | 4.5ms | 0.0% | 0us | `gmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2068` |
| 0.1% | 4.5ms | 0.0% | 0us | `bnb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3751` |
| 0.1% | 4.5ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:90` |
| 0.1% | 4.5ms | 0.0% | 2.3ms | `opaqueOutlineWidth` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:149` |
| 0.1% | 4.5ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:163` |
| 0.1% | 4.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/zenuml/native-parser.ts:13` |
| 0.1% | 4.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:69` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `tree` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.1% | 4.5ms | 0.0% | 0us | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:34` |
| 0.1% | 4.5ms | 0.0% | 0us | `chargeInkSort` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:7` |
| 0.1% | 4.5ms | 0.0% | 2.1ms | `mdb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5533` |
| 0.1% | 4.5ms | 0.1% | 4.5ms | `inspectOwnedSvgOnce` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts` |
| 0.1% | 4.5ms | 0.0% | 0us | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:618` |
| 0.1% | 4.5ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:487` |
| 0.1% | 4.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:208` |
| 0.1% | 4.4ms | 0.0% | 1.2ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:517` |
| 0.1% | 4.4ms | 0.0% | 0us | `RC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5077` |
| 0.1% | 4.4ms | 0.0% | 0us | `QC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2691` |
| 0.1% | 4.4ms | 0.0% | 0us | `ete` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3854` |
| 0.1% | 4.4ms | 0.0% | 0us | `ate` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1932` |
| 0.1% | 4.4ms | 0.0% | 0us | `mDd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2857` |
| 0.1% | 4.4ms | 0.0% | 0us | `BBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6354` |
| 0.1% | 4.4ms | 0.0% | 0us | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:178` |
| 0.1% | 4.3ms | 0.0% | 0us | `nCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 4.3ms | 0.0% | 0us | `bBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5555` |
| 0.1% | 4.3ms | 0.0% | 0us | `IBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5924` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `RAd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2285` |
| 0.1% | 4.3ms | 0.0% | 0us | `D7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5965` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `endpointOwner` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:118` |
| 0.1% | 4.3ms | 0.0% | 0us | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:443` |
| 0.1% | 4.3ms | 0.0% | 0us | `internal:streams/readable` | `internal:streams/readable:2` |
| 0.1% | 4.3ms | 0.0% | 0us | `RHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5003` |
| 0.1% | 4.3ms | 0.1% | 4.3ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:128` |
| 0.1% | 4.2ms | 0.0% | 0us | `Ce` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2774` |
| 0.1% | 4.2ms | 0.0% | 0us | `kmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2438` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:277` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:118` |
| 0.1% | 4.2ms | 0.0% | 0us | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:316` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `polylineLength` | `/tmp/pr449-main-integration-20261029-762/src/layout/geometry.ts:67` |
| 0.1% | 4.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:194` |
| 0.1% | 4.2ms | 0.0% | 0us | `calculatePathMidpoint` | `/tmp/pr449-main-integration-20261029-762/src/layout/geometry.ts:107` |
| 0.1% | 4.2ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:643` |
| 0.1% | 4.2ms | 0.0% | 0us | `pointAtPathDistance` | `/tmp/pr449-main-integration-20261029-762/src/layout/geometry.ts:76` |
| 0.1% | 4.1ms | 0.1% | 4.1ms | `split` | `[native code]` |
| 0.1% | 4.1ms | 0.0% | 0us | `JEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3971` |
| 0.1% | 4.1ms | 0.0% | 0us | `lNb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5215` |
| 0.1% | 4.1ms | 0.1% | 4.1ms | `startsWith` | `[native code]` |
| 0.1% | 4.1ms | 0.0% | 0us | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:82` |
| 0.1% | 4.0ms | 0.0% | 0us | `jKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5384` |
| 0.1% | 4.0ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:54` |
| 0.1% | 4.0ms | 0.0% | 1.0ms | `Dd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1384` |
| 0.1% | 4.0ms | 0.0% | 0us | `kd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 4.0ms | 0.0% | 0us | `node:events` | `node:events:657` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.1% | 4.0ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:162` |
| 0.1% | 4.0ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:125` |
| 0.1% | 4.0ms | 0.0% | 0us | `deferredTerminalProjectionInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:66` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `possibleShapeStroke` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:133` |
| 0.1% | 4.0ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:181` |
| 0.1% | 4.0ms | 0.0% | 0us | `bjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2919` |
| 0.1% | 4.0ms | 0.1% | 4.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.1% | 3.9ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:776` |
| 0.1% | 3.9ms | 0.0% | 0us | `gVb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6307` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `arrayIteratorNextHelper` | `[native code]` |
| 0.1% | 3.9ms | 0.0% | 0us | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:454` |
| 0.1% | 3.9ms | 0.0% | 1.5ms | `pjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.1% | 3.9ms | 0.0% | 0us | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:92` |
| 0.1% | 3.9ms | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1655` |
| 0.1% | 3.9ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:186` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:88` |
| 0.1% | 3.9ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:113` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:163` |
| 0.1% | 3.9ms | 0.0% | 2.7ms | `ltb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3516` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.1% | 3.9ms | 0.0% | 0us | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:520` |
| 0.1% | 3.9ms | 0.1% | 3.9ms | `TC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4909` |
| 0.1% | 3.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-doc.js:4` |
| 0.1% | 3.8ms | 0.0% | 0us | `snapshotScenePrimitiveCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1548` |
| 0.1% | 3.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:328` |
| 0.1% | 3.8ms | 0.1% | 3.8ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 3.8ms | 0.0% | 0us | `registerBuiltInStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:294` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `inverseMatrix` | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:25` |
| 0.0% | 3.8ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:643` |
| 0.0% | 3.8ms | 0.0% | 0us | `wyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4408` |
| 0.0% | 3.8ms | 0.0% | 0us | `walk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1757` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `endpointRelation` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 3.8ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1764` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:145` |
| 0.0% | 3.8ms | 0.0% | 0us | `inspectSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:673` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `startTags` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:65` |
| 0.0% | 3.8ms | 0.0% | 0us | `erCardinalityEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:134` |
| 0.0% | 3.8ms | 0.0% | 3.8ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:53` |
| 0.0% | 3.7ms | 0.0% | 0us | `reduce` | `[native code]` |
| 0.0% | 3.7ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:200` |
| 0.0% | 3.7ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:418` |
| 0.0% | 3.7ms | 0.0% | 1.2ms | `PJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4763` |
| 0.0% | 3.7ms | 0.0% | 0us | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:536` |
| 0.0% | 3.7ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:323` |
| 0.0% | 3.7ms | 0.0% | 0us | `hasDomSvgIdentityRole` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:69` |
| 0.0% | 3.7ms | 0.0% | 0us | `R6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5592` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `xmlIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:22` |
| 0.0% | 3.7ms | 0.0% | 0us | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:59` |
| 0.0% | 3.7ms | 0.0% | 0us | `gCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2724` |
| 0.0% | 3.7ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:182` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `possibleShapeStroke` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1597` |
| 0.0% | 3.7ms | 0.0% | 0us | `WBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6424` |
| 0.0% | 3.7ms | 0.0% | 3.7ms | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:155` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `parseInt` | `[native code]` |
| 0.0% | 3.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:3` |
| 0.0% | 3.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:26` |
| 0.0% | 3.6ms | 0.0% | 0us | `wCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2802` |
| 0.0% | 3.6ms | 0.0% | 0us | `ACb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:596` |
| 0.0% | 3.6ms | 0.0% | 0us | `qyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4180` |
| 0.0% | 3.6ms | 0.0% | 0us | `Bwb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1961` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `copyDataProperties` | `[native code]` |
| 0.0% | 3.6ms | 0.0% | 0us | `MBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3417` |
| 0.0% | 3.6ms | 0.0% | 0us | `Vcb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4548` |
| 0.0% | 3.6ms | 0.0% | 0us | `xo` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5921` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `oD` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6204` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `textSurfaces` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1654` |
| 0.0% | 3.6ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1679` |
| 0.0% | 3.6ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1860` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:309` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `Segmenter` | `[native code]` |
| 0.0% | 3.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts:3` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:247` |
| 0.0% | 3.5ms | 0.0% | 0us | `kIc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5236` |
| 0.0% | 3.5ms | 0.0% | 0us | `MIc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4296` |
| 0.0% | 3.5ms | 0.0% | 0us | `CIc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3741` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `sanitizeTextControls` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:9` |
| 0.0% | 3.5ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1008` |
| 0.0% | 3.5ms | 0.0% | 0us | `aMd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4646` |
| 0.0% | 3.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/c4/config.ts:71` |
| 0.0% | 3.4ms | 0.0% | 1.1ms | `tree` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:71` |
| 0.0% | 3.4ms | 0.0% | 0us | `Pud` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5568` |
| 0.0% | 3.4ms | 0.0% | 0us | `Dk` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 3.4ms | 0.0% | 0us | `Ykb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 3.4ms | 0.0% | 0us | `Cyb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4092` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `Qjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3372` |
| 0.0% | 3.4ms | 0.0% | 0us | `AQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5029` |
| 0.0% | 3.4ms | 0.0% | 0us | `Byb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3374` |
| 0.0% | 3.4ms | 0.0% | 0us | `qkb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:236` |
| 0.0% | 3.4ms | 0.0% | 0us | `parseErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:832` |
| 0.0% | 3.4ms | 0.0% | 0us | `the` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 3.4ms | 0.0% | 0us | `WLd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4847` |
| 0.0% | 3.4ms | 0.0% | 0us | `vhe` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `collectNativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:164` |
| 0.0% | 3.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:5` |
| 0.0% | 3.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:3` |
| 0.0% | 3.4ms | 0.0% | 0us | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:619` |
| 0.0% | 3.4ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:250` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `hasInheritedPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:799` |
| 0.0% | 3.4ms | 0.0% | 3.4ms | `internal:streams/destroy` | `internal:streams/destroy:16` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:32` |
| 0.0% | 3.3ms | 0.0% | 0us | `hashId` | `/tmp/pr449-main-integration-20261029-762/src/scene/seed.ts:24` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `seedFrom` | `/tmp/pr449-main-integration-20261029-762/src/scene/seed.ts` |
| 0.0% | 3.3ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:74` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 3.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:152` |
| 0.0% | 3.3ms | 0.0% | 0us | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:229` |
| 0.0% | 3.3ms | 0.0% | 0us | `HXb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6152` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `/[&<>"'\t\n\r]/` | `[native code]` |
| 0.0% | 3.3ms | 0.0% | 0us | `buildStyleBlock` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:357` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `isPlainFontFamily` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 3.3ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:91` |
| 0.0% | 3.3ms | 0.0% | 3.3ms | `Rse` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 3.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:800` |
| 0.0% | 3.3ms | 0.0% | 0us | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:37` |
| 0.0% | 3.2ms | 0.0% | 0us | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1097` |
| 0.0% | 3.2ms | 0.0% | 0us | `internal:stream` | `internal:stream:46` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `/<(?:[^\s<>/:]+:)?image\b/i` | `[native code]` |
| 0.0% | 3.2ms | 0.0% | 0us | `inspectSecurityTail` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:691` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `append` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:239` |
| 0.0% | 3.2ms | 0.0% | 0us | `M$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6127` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 3.2ms | 0.0% | 0us | `x$d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 3.2ms | 0.0% | 0us | `qJd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5497` |
| 0.0% | 3.2ms | 0.0% | 0us | `TWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 3.2ms | 0.0% | 0us | `p$d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2291` |
| 0.0% | 3.2ms | 0.0% | 0us | `XEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4490` |
| 0.0% | 3.2ms | 0.0% | 1.8ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:202` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `x7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6110` |
| 0.0% | 3.2ms | 0.0% | 0us | `u7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5599` |
| 0.0% | 3.2ms | 0.0% | 0us | `y7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5490` |
| 0.0% | 3.2ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:197` |
| 0.0% | 3.2ms | 0.0% | 0us | `escapeDisplayAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:115` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `createNativeSceneValidator` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 3.1ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:114` |
| 0.0% | 3.1ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:808` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:485` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:232` |
| 0.0% | 3.1ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:646` |
| 0.0% | 3.1ms | 0.0% | 0us | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:41` |
| 0.0% | 3.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:4` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `recordPaintField` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `fPc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2891` |
| 0.0% | 3.1ms | 0.0% | 1.5ms | `Srb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3494` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:106` |
| 0.0% | 3.1ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:605` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `hasImmutablePaintRoster` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 3.1ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1591` |
| 0.0% | 3.1ms | 0.0% | 0us | `appendPrivate` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:55` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `isOwnedDisplayTextPart` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:30` |
| 0.0% | 3.1ms | 0.0% | 0us | `emissionRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:75` |
| 0.0% | 3.0ms | 0.0% | 0us | `Fyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4000` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:18` |
| 0.0% | 3.0ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:561` |
| 0.0% | 3.0ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:702` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:170` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `RXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 3.0ms | 0.0% | 0us | `erCardinalityInk` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:123` |
| 0.0% | 3.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:49` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 3.0ms | 0.0% | 3.0ms | `yd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3912` |
| 0.0% | 3.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:840` |
| 0.0% | 2.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:4` |
| 0.0% | 2.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/common/map.js:4` |
| 0.0% | 2.9ms | 0.0% | 0us | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:710` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `displayRunAttributes` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 2.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:179` |
| 0.0% | 2.9ms | 0.0% | 0us | `ypd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6076` |
| 0.0% | 2.9ms | 0.0% | 1.4ms | `De` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4889` |
| 0.0% | 2.9ms | 0.0% | 0us | `Qe` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `isHexColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:143` |
| 0.0% | 2.9ms | 0.0% | 0us | `resolvedColorValue` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:598` |
| 0.0% | 2.9ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:676` |
| 0.0% | 2.9ms | 0.0% | 1.3ms | `mEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4780` |
| 0.0% | 2.9ms | 0.0% | 0us | `renderContractDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1118` |
| 0.0% | 2.9ms | 0.0% | 0us | `lzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5707` |
| 0.0% | 2.9ms | 0.0% | 0us | `izd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2766` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` |
| 0.0% | 2.9ms | 0.0% | 2.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1038` |
| 0.0% | 2.8ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:588` |
| 0.0% | 2.8ms | 0.0% | 0us | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:56` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:198` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `VC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2915` |
| 0.0% | 2.8ms | 0.0% | 0us | `gBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4114` |
| 0.0% | 2.8ms | 0.0% | 0us | `fBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3402` |
| 0.0% | 2.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:5` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `GAd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.8ms | 0.0% | 0us | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:473` |
| 0.0% | 2.8ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:436` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `Keb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.8ms | 0.0% | 0us | `Geb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3196` |
| 0.0% | 2.8ms | 0.0% | 0us | `registerBuiltInStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:292` |
| 0.0% | 2.8ms | 0.0% | 1.4ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:87` |
| 0.0% | 2.8ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:763` |
| 0.0% | 2.8ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:312` |
| 0.0% | 2.8ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:555` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:20` |
| 0.0% | 2.8ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:760` |
| 0.0% | 2.8ms | 0.0% | 2.8ms | `UHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5196` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `hasOwned` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `ijd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `drawNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 2.7ms | 0.0% | 0us | `connectorProjectedField` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:485` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `TJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5486` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `fKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2151` |
| 0.0% | 2.7ms | 0.0% | 0us | `CYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.7ms | 0.0% | 0us | `ILd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.7ms | 0.0% | 0us | `AKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2214` |
| 0.0% | 2.7ms | 0.0% | 0us | `vEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/encode-html.js:10` |
| 0.0% | 2.7ms | 0.0% | 0us | `parseEncodeTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:41` |
| 0.0% | 2.7ms | 0.0% | 0us | `buildErElkGraph` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:530` |
| 0.0% | 2.7ms | 0.0% | 0us | `erRelationshipBlock` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:19` |
| 0.0% | 2.7ms | 0.0% | 1.4ms | `tYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5390` |
| 0.0% | 2.7ms | 0.0% | 0us | `Xq` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2104` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `v6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.7ms | 0.0% | 0us | `Ar` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4250` |
| 0.0% | 2.7ms | 0.0% | 0us | `Q$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6346` |
| 0.0% | 2.7ms | 0.0% | 0us | `cLb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4995` |
| 0.0% | 2.7ms | 0.0% | 0us | `bLb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6374` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 2.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/directives.js:4` |
| 0.0% | 2.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:4` |
| 0.0% | 2.7ms | 0.0% | 0us | `_mb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4572` |
| 0.0% | 2.7ms | 0.0% | 0us | `cnb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5372` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `PEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `svgOpenTag` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:178` |
| 0.0% | 2.7ms | 0.0% | 0us | `detectRegisteredFamilyDescriptorFromFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2083` |
| 0.0% | 2.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1739` |
| 0.0% | 2.7ms | 0.0% | 0us | `classifyMermaidFamilyDescriptorFromFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/family-detection.ts:39` |
| 0.0% | 2.7ms | 0.0% | 0us | `detectInstalledFamilyDescriptorFromFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts:60` |
| 0.0% | 2.7ms | 0.0% | 0us | `normalizeMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:665` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:117` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:55` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `dKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `PHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5783` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `registerCanonicalStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` |
| 0.0% | 2.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:548` |
| 0.0% | 2.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/radar/config-diagnostics.ts:11` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `boundedNonNegative` | `/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` |
| 0.0% | 2.7ms | 0.0% | 1.1ms | `Oce` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3806` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:207` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `iHc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.7ms | 0.0% | 0us | `dvc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:900` |
| 0.0% | 2.7ms | 0.0% | 0us | `internal:validators` | `internal:validators:2` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `at` | `[native code]` |
| 0.0% | 2.7ms | 0.0% | 0us | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:16` |
| 0.0% | 2.6ms | 0.0% | 0us | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` |
| 0.0% | 2.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/block/markers.ts:10` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:189` |
| 0.0% | 2.6ms | 0.0% | 0us | `FIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4733` |
| 0.0% | 2.6ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:739` |
| 0.0% | 2.6ms | 0.0% | 0us | `admitRenderContractDigestInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1150` |
| 0.0% | 2.6ms | 0.0% | 0us | `boundedImmutableJsonSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1242` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `ActualTextPaintWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:393` |
| 0.0% | 2.6ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:317` |
| 0.0% | 2.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` |
| 0.0% | 2.6ms | 0.0% | 0us | `measureTextWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:206` |
| 0.0% | 2.6ms | 0.0% | 0us | `advance` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:117` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:609` |
| 0.0% | 2.6ms | 0.0% | 0us | `relativeLuminance` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:78` |
| 0.0% | 2.6ms | 0.0% | 0us | `contrastRatio` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:84` |
| 0.0% | 2.6ms | 0.0% | 0us | `ensureContrast` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:102` |
| 0.0% | 2.6ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:821` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:285` |
| 0.0% | 2.6ms | 0.0% | 0us | `sqd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4983` |
| 0.0% | 2.6ms | 0.0% | 0us | `Gyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4943` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `resolveRoleStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:240` |
| 0.0% | 2.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringifyPair.js:5` |
| 0.0% | 2.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:4` |
| 0.0% | 2.6ms | 0.0% | 0us | `sJd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4645` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `MFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4458` |
| 0.0% | 2.6ms | 0.0% | 0us | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:134` |
| 0.0% | 2.6ms | 0.0% | 0us | `Kzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `jDb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5481` |
| 0.0% | 2.6ms | 0.0% | 0us | `mDb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2615` |
| 0.0% | 2.6ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:83` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `nativePaintAncestors` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 2.6ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:592` |
| 0.0% | 2.6ms | 0.0% | 0us | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:230` |
| 0.0% | 2.6ms | 0.0% | 2.6ms | `canonicalizeSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:465` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `pWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.5ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1365` |
| 0.0% | 2.5ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:199` |
| 0.0% | 2.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:5` |
| 0.0% | 2.5ms | 0.0% | 0us | `Krc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6492` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1390` |
| 0.0% | 2.5ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:134` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `relationshipPairKey` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:162` |
| 0.0% | 2.5ms | 0.0% | 0us | `jNb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4187` |
| 0.0% | 2.5ms | 0.0% | 0us | `Kac` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.5ms | 0.0% | 0us | `Hac` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5551` |
| 0.0% | 2.5ms | 0.0% | 0us | `Abd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4237` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `header` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 2.5ms | 0.0% | 0us | `documentOpen` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:132` |
| 0.0% | 2.5ms | 0.0% | 0us | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1456` |
| 0.0% | 2.5ms | 0.0% | 1.1ms | `tEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.5ms | 0.0% | 0us | `relationshipPairKey` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:160` |
| 0.0% | 2.5ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:120` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:526` |
| 0.0% | 2.5ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:98` |
| 0.0% | 2.5ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1853` |
| 0.0% | 2.5ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1917` |
| 0.0% | 2.5ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1488` |
| 0.0% | 2.5ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:194` |
| 0.0% | 2.5ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:206` |
| 0.0% | 2.5ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:156` |
| 0.0% | 2.5ms | 0.0% | 0us | `paintPrimitiveSource` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:72` |
| 0.0% | 2.5ms | 0.0% | 0us | `buildErElkGraph` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:486` |
| 0.0% | 2.5ms | 0.0% | 0us | `V0b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:353` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `SC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.4ms | 0.0% | 0us | `createExtensionIdentity` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:246` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `isInteger` | `[native code]` |
| 0.0% | 2.4ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1462` |
| 0.0% | 2.4ms | 0.0% | 0us | `depth` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1439` |
| 0.0% | 2.4ms | 0.0% | 0us | `freezeBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:403` |
| 0.0% | 2.4ms | 0.0% | 0us | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:470` |
| 0.0% | 2.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/builtin-backends.ts:20` |
| 0.0% | 2.4ms | 0.0% | 0us | `snapshotBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:330` |
| 0.0% | 2.4ms | 0.0% | 0us | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:664` |
| 0.0% | 2.4ms | 0.0% | 0us | `zlibBufferSync` | `node:zlib:94` |
| 0.0% | 2.4ms | 0.0% | 0us | `evc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.4ms | 0.0% | 0us | `sharedRenderOptionsJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:485` |
| 0.0% | 2.4ms | 0.0% | 0us | `jdd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6113` |
| 0.0% | 2.4ms | 0.0% | 0us | `FXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.4ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:144` |
| 0.0% | 2.4ms | 0.0% | 0us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:280` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 2.4ms | 0.0% | 0us | `connectorInlineLabelSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:781` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:154` |
| 0.0% | 2.4ms | 0.0% | 0us | `gyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5621` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 2.4ms | 0.0% | 0us | `get WriteStream` | `node:fs:667` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `interTextEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/shared/inter-text-envelope.ts:20` |
| 0.0% | 2.4ms | 0.0% | 0us | `connectorInlineLabelSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:761` |
| 0.0% | 2.4ms | 0.0% | 0us | `connectorInlineLabelText` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:427` |
| 0.0% | 2.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:433` |
| 0.0% | 2.4ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:430` |
| 0.0% | 2.4ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:264` |
| 0.0% | 2.4ms | 0.0% | 0us | `Xad` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `Tad` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.4ms | 0.0% | 0us | `rYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.4ms | 0.0% | 0us | `zsd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4165` |
| 0.0% | 2.4ms | 0.0% | 0us | `DXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `nud` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.4ms | 0.0% | 0us | `Vsd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2012` |
| 0.0% | 2.4ms | 0.0% | 0us | `bBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3702` |
| 0.0% | 2.4ms | 0.0% | 2.4ms | `kXb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.3ms | 0.0% | 0us | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:173` |
| 0.0% | 2.3ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:145` |
| 0.0% | 2.3ms | 0.0% | 0us | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:442` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `Le` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.3ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1328` |
| 0.0% | 2.3ms | 0.0% | 0us | `gzipSync` | `node:zlib:360` |
| 0.0% | 2.3ms | 0.0% | 0us | `xpd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5945` |
| 0.0% | 2.3ms | 0.0% | 1.0ms | `descriptorOwnsDetectionLine` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2072` |
| 0.0% | 2.3ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:313` |
| 0.0% | 2.3ms | 0.0% | 0us | `Cf` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.3ms | 0.0% | 0us | `wjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.3ms | 0.0% | 1.0ms | `Cjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4145` |
| 0.0% | 2.3ms | 0.0% | 1.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:169` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `reserve` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 2.3ms | 0.0% | 0us | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:385` |
| 0.0% | 2.3ms | 0.0% | 0us | `measureErEntities` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:453` |
| 0.0% | 2.3ms | 0.0% | 0us | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:739` |
| 0.0% | 2.3ms | 0.0% | 0us | `Gub` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4143` |
| 0.0% | 2.3ms | 0.0% | 0us | `lcd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:8` |
| 0.0% | 2.3ms | 0.0% | 0us | `CYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4538` |
| 0.0% | 2.3ms | 0.0% | 0us | `QCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.3ms | 0.0% | 0us | `OCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2420` |
| 0.0% | 2.3ms | 0.0% | 0us | `pdb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3193` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `withDeferredTerminalProjections` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.0% | 2.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:140` |
| 0.0% | 2.3ms | 0.0% | 0us | `connector/subpaths/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:662` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts` |
| 0.0% | 2.3ms | 0.0% | 0us | `builtinFamilyConformanceReport` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1915` |
| 0.0% | 2.3ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1882` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1089` |
| 0.0% | 2.3ms | 0.0% | 2.3ms | `node:events` | `node:events:577` |
| 0.0% | 2.3ms | 0.0% | 0us | `V8d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6474` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `PromisedWorker` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.2ms | 0.0% | 0us | `_callSuper` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6523` |
| 0.0% | 2.2ms | 0.0% | 0us | `construct` | `[native code]` |
| 0.0% | 2.2ms | 0.0% | 0us | `ELK` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:56` |
| 0.0% | 2.2ms | 0.0% | 0us | `ELKNode` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6570` |
| 0.0% | 2.2ms | 0.0% | 0us | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:35` |
| 0.0% | 2.2ms | 0.0% | 0us | `Ncd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:232` |
| 0.0% | 2.2ms | 0.0% | 0us | `t1d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `_Ud` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.2ms | 0.0% | 0us | `i1d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4177` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 2.2ms | 0.0% | 0us | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:102` |
| 0.0% | 2.2ms | 0.0% | 0us | `uyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3893` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `uncurryThis` | `internal:primordials` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `kWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.2ms | 0.0% | 0us | `YGb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6039` |
| 0.0% | 2.2ms | 0.0% | 0us | `normalizedErText` | `/tmp/pr449-main-integration-20261029-762/src/er/text.ts:87` |
| 0.0% | 2.2ms | 0.0% | 0us | `erDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/er/text.ts:94` |
| 0.0% | 2.2ms | 0.0% | 0us | `relationshipFrom` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1107` |
| 0.0% | 2.2ms | 0.0% | 0us | `erTextLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/text.ts:107` |
| 0.0% | 2.2ms | 0.0% | 0us | `normalizePlainLabel` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:47` |
| 0.0% | 2.2ms | 0.0% | 0us | `parseErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:898` |
| 0.0% | 2.2ms | 0.0% | 0us | `normalizeBrTags` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:25` |
| 0.0% | 2.2ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:315` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `assertMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:54` |
| 0.0% | 2.2ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:674` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `push` | `[native code]` |
| 0.0% | 2.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1216` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `sceneValidationMode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.2ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1608` |
| 0.0% | 2.2ms | 0.0% | 0us | `QOc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5643` |
| 0.0% | 2.2ms | 0.0% | 0us | `oQc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5143` |
| 0.0% | 2.2ms | 0.0% | 0us | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:581` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:267` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `Z7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.2ms | 0.0% | 0us | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:543` |
| 0.0% | 2.2ms | 0.0% | 0us | `createNativePaintEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:56` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `createEmissionContext` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/set.js:7` |
| 0.0% | 2.2ms | 0.0% | 0us | `renderDisplayRuns` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:152` |
| 0.0% | 2.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:14` |
| 0.0% | 2.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:17` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 2.2ms | 0.0% | 0us | `opaque` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:143` |
| 0.0% | 2.1ms | 0.0% | 1.1ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:315` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `WC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.1ms | 0.0% | 0us | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:310` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `exec` | `[native code]` |
| 0.0% | 2.1ms | 0.0% | 0us | `localPaintResourceId` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:373` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `tb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.1ms | 0.0% | 0us | `createWrittenPolyline` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:33` |
| 0.0% | 2.1ms | 0.0% | 0us | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:641` |
| 0.0% | 2.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:330` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `setName` | `node:fs:696` |
| 0.0% | 2.1ms | 0.0% | 0us | `node:fs` | `node:fs:782` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:357` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:120` |
| 0.0% | 2.0ms | 0.0% | 0us | `captureNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:99` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:900` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `consumePointBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 2.0ms | 0.0% | 0us | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:434` |
| 0.0% | 2.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1029` |
| 0.0% | 2.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:5` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:1126` |
| 0.0% | 2.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:3` |
| 0.0% | 2.0ms | 0.0% | 0us | `qub` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `iub` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1660` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `Aeb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 2.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:14` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:778` |
| 0.0% | 2.0ms | 0.0% | 0us | `resolveDiagramColors` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:54` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `themePaint` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:47` |
| 0.0% | 2.0ms | 0.0% | 0us | `kC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3879` |
| 0.0% | 2.0ms | 0.0% | 0us | `yAd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5199` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `lC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3498` |
| 0.0% | 2.0ms | 0.0% | 0us | `zAd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2650` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:229` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:320` |
| 0.0% | 2.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Node.js:3` |
| 0.0% | 2.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:6` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.9ms | 0.0% | 0us | `xmlParserList` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:129` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `create` | `[native code]` |
| 0.0% | 1.9ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:390` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:711` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `inspectSecurityTail` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:644` |
| 0.0% | 1.9ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:644` |
| 0.0% | 1.9ms | 0.0% | 0us | `Hb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2951` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `pb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4466` |
| 0.0% | 1.9ms | 0.0% | 0us | `fp` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4018` |
| 0.0% | 1.9ms | 0.0% | 0us | `oBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5012` |
| 0.0% | 1.9ms | 0.0% | 0us | `Bo` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4130` |
| 0.0% | 1.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:41` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `AQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:578` |
| 0.0% | 1.9ms | 0.0% | 0us | `node:zlib` | `node:zlib:449` |
| 0.0% | 1.9ms | 0.0% | 0us | `resolveDiagramColors` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:52` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `themePaint` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` |
| 0.0% | 1.9ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:993` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `serializeLinearGradientResources` | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts:117` |
| 0.0% | 1.9ms | 0.0% | 1.9ms | `mbd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `isRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:86` |
| 0.0% | 1.8ms | 0.0% | 0us | `bld` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5625` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.8ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:194` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `boxAt` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:168` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `dZd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.8ms | 0.0% | 0us | `Grb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2741` |
| 0.0% | 1.8ms | 0.0% | 0us | `Mrb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.8ms | 0.0% | 0us | `attributeRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:19` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:207` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:658` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `createSafeIterator` | `internal:primordials` |
| 0.0% | 1.8ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:658` |
| 0.0% | 1.8ms | 0.0% | 1.8ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:575` |
| 0.0% | 1.8ms | 0.0% | 0us | `svgOpenTag` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:429` |
| 0.0% | 1.8ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:314` |
| 0.0% | 1.7ms | 0.0% | 0us | `snapshotScenePrimitiveCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1541` |
| 0.0% | 1.7ms | 0.0% | 0us | `captureFields` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `value` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:128` |
| 0.0% | 1.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Collection.js:3` |
| 0.0% | 1.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/createNode.js:5` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `connector/subpaths/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `kd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.7ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:150` |
| 0.0% | 1.7ms | 0.0% | 0us | `plb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3425` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `mXb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `appendPrivate` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.7ms | 0.0% | 0us | `uZd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.7ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1578` |
| 0.0% | 1.7ms | 0.0% | 0us | `renderRelationshipLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:527` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.7ms | 0.0% | 0us | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:30` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:196` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:521` |
| 0.0% | 1.7ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:109` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `connectorMidpointMarkerAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.7ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:284` |
| 0.0% | 1.7ms | 0.0% | 0us | `YHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4655` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:295` |
| 0.0% | 1.7ms | 0.0% | 0us | `SvgWriter` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:471` |
| 0.0% | 1.7ms | 0.0% | 0us | `XmlLeafWrite` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:298` |
| 0.0% | 1.7ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:662` |
| 0.0% | 1.7ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1088` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.7ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1037` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `xNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5494` |
| 0.0% | 1.7ms | 0.0% | 0us | `strokedBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:543` |
| 0.0% | 1.7ms | 0.0% | 0us | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:535` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/default-backend.ts:5` |
| 0.0% | 1.7ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:76` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `makeSafe` | `internal:primordials` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:204` |
| 0.0% | 1.7ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:231` |
| 0.0% | 1.7ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:601` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `enclosure` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1495` |
| 0.0% | 1.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:4` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `assertRenderableMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 1.7ms | 0.0% | 0us | `tipAnchoredArrow` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:33` |
| 0.0% | 1.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:13` |
| 0.0% | 1.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:3` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:217` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `N$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.7ms | 0.0% | 0us | `hasInheritedTextPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:263` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `vgb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:15` |
| 0.0% | 1.7ms | 0.0% | 0us | `internal:streams/legacy` | `internal:streams/legacy:6` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `aod` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.7ms | 0.0% | 1.7ms | `_Td` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3967` |
| 0.0% | 1.7ms | 0.0% | 0us | `iyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4338` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `entries` | `[native code]` |
| 0.0% | 1.6ms | 0.0% | 0us | `expandLocalReferences` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:203` |
| 0.0% | 1.6ms | 0.0% | 0us | `identityAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:539` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `erCardinalityPieces` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:17` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1009` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.6ms | 0.0% | 0us | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:582` |
| 0.0% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:3` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `Pg` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `inlineResolvedColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `i6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.6ms | 0.0% | 0us | `VWb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `oKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2213` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `erCardinalityInk` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts` |
| 0.0% | 1.6ms | 0.0% | 0us | `possibleShapeFill` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:127` |
| 0.0% | 1.6ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:180` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `skipSeparators` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:168` |
| 0.0% | 1.6ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1052` |
| 0.0% | 1.6ms | 0.0% | 0us | `finiteNumber` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:175` |
| 0.0% | 1.6ms | 0.0% | 0us | `prepareWrittenCompoundShape` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:60` |
| 0.0% | 1.6ms | 0.0% | 0us | `prepareWrittenCompoundShape` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:57` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:232` |
| 0.0% | 1.6ms | 0.0% | 0us | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:559` |
| 0.0% | 1.6ms | 0.0% | 0us | `gjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3610` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `xsb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5521` |
| 0.0% | 1.6ms | 0.0% | 0us | `qjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `vBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:668` |
| 0.0% | 1.6ms | 0.0% | 1.6ms | `groupValidation` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `sourceEnvelopeMetadata` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:836` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `tagRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `match` | `[native code]` |
| 0.0% | 1.5ms | 0.0% | 0us | `tag` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:151` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:194` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `inspectSecurityTail` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:686` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/YAMLMap.js:147` |
| 0.0% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:10` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `preparedInterTextBounds` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `tCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:696` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:990` |
| 0.0% | 1.5ms | 0.0% | 0us | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:983` |
| 0.0% | 1.5ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1572` |
| 0.0% | 1.5ms | 0.0% | 0us | `nativeAttributeValue` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:57` |
| 0.0% | 1.5ms | 0.0% | 0us | `reserve` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:47` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:410` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:593` |
| 0.0% | 1.5ms | 0.0% | 0us | `registerGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:87` |
| 0.0% | 1.5ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:633` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `Qrb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3853` |
| 0.0% | 1.5ms | 0.0% | 0us | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:171` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `/[^\x20-\x7e]/u` | `[native code]` |
| 0.0% | 1.5ms | 0.0% | 0us | `Kmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `Fmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3333` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `D$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `Fk` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `ohb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 0us | `XFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4383` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:269` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `BWb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3113` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:31` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:13` |
| 0.0% | 1.5ms | 0.0% | 0us | `rYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2467` |
| 0.0% | 1.5ms | 0.0% | 0us | `HGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4706` |
| 0.0% | 1.5ms | 0.0% | 0us | `Vdd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `iYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2730` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1033` |
| 0.0% | 1.5ms | 0.0% | 0us | `qVd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `TUd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.5ms | 0.0% | 0us | `JHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4389` |
| 0.0% | 1.5ms | 0.0% | 0us | `captureNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:103` |
| 0.0% | 1.5ms | 0.0% | 0us | `$Hb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.5ms | 0.0% | 0us | `DIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4867` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `rNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6111` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:598` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `erRelationshipBlock` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:20` |
| 0.0% | 1.5ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:580` |
| 0.0% | 1.5ms | 0.0% | 0us | `hasOwned` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:11` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.5ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` |
| 0.0% | 1.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:15` |
| 0.0% | 1.5ms | 0.0% | 0us | `renderedSvgDigest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:61` |
| 0.0% | 1.5ms | 0.0% | 0us | `zIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5436` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `Bwb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `$u` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.5ms | 0.0% | 0us | `wIc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4469` |
| 0.0% | 1.5ms | 0.0% | 0us | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:628` |
| 0.0% | 1.5ms | 0.0% | 0us | `Wfc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4959` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `Xfc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5131` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `osb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `Rc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `g0d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `checkFamilyConfigColors` | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1762` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:501` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `lyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4217` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `processChunkSync` | `node:zlib` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `sourceEnvelopeMetadata` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:802` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:333` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `compareCodePointStrings` | `/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts:4` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:854` |
| 0.0% | 1.4ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1715` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `collectPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1391` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `renderOptionsAdmissionMessages` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:403` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateJsonConfigAdmission` | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:126` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `eub` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 0us | `au` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4805` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:204` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/resolve-block-map.js:7` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:7` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `rD` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2794` |
| 0.0% | 1.4ms | 0.0% | 0us | `eQd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6172` |
| 0.0% | 1.4ms | 0.0% | 0us | `Ycb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3321` |
| 0.0% | 1.4ms | 0.0% | 0us | `wQd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4639` |
| 0.0% | 1.4ms | 0.0% | 0us | `qNb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `kNb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `SBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1221` |
| 0.0% | 1.4ms | 0.0% | 0us | `canonicalErContacts` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:246` |
| 0.0% | 1.4ms | 0.0% | 0us | `applyFamilyRequestNormalization` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1075` |
| 0.0% | 1.4ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:201` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `preventExtensions` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1656` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `assertFamilyGeometryOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `parseInlineFormatting` | `/tmp/pr449-main-integration-20261029-762/src/shared/inline-format.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:174` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `formatSvgNumber` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:181` |
| 0.0% | 1.4ms | 0.0% | 0us | `L$d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 0us | `OHd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `rWd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3492` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1709` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `admitRenderOptionsInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `createPngOutputOptionFieldDescriptors` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1319` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1319` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/omap.js:7` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:14` |
| 0.0% | 1.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:173` |
| 0.0% | 1.4ms | 0.0% | 0us | `glyphBox` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1314` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `VWb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `ownConnectorEndpoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:291` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `nativeParseRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:132` |
| 0.0% | 1.4ms | 0.0% | 0us | `ryd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4181` |
| 0.0% | 1.4ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1856` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `i_d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 0us | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:111` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `zKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4783` |
| 0.0% | 1.4ms | 0.0% | 0us | `BKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 0us | `kKd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:9` |
| 0.0% | 1.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ishikawa/renderer.ts:63` |
| 0.0% | 1.4ms | 0.0% | 0us | `sceneLowering` | `/tmp/pr449-main-integration-20261029-762/src/scene/drawing.ts:18` |
| 0.0% | 1.4ms | 0.0% | 0us | `textPaints` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:119` |
| 0.0% | 1.4ms | 0.0% | 0us | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:130` |
| 0.0% | 1.4ms | 0.0% | 0us | `absentPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:102` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `MJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4125` |
| 0.0% | 1.4ms | 0.0% | 0us | `JJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6497` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:395` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `collectNativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:143` |
| 0.0% | 1.4ms | 0.0% | 0us | `prepareWrittenCompoundShape` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:58` |
| 0.0% | 1.4ms | 0.0% | 0us | `measureRenderStage` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:34` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `BIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.4ms | 0.0% | 0us | `ctb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2833` |
| 0.0% | 1.4ms | 0.0% | 0us | `Imb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 0us | `vYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 0us | `Wxd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4079` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `HQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `finishXmlLeaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:277` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `N0d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4048` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `KYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4850` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `readDiff` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js` |
| 0.0% | 1.4ms | 0.0% | 0us | `V0d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:138` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `/\sdata-role="[^"]*"/` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `ibd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `$Yd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `documentText` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:552` |
| 0.0% | 1.3ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:177` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `escapeXml` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `uyb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `Fzb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 0us | `vzb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2847` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `ENc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6063` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `GNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:209` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parseFloat` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:633` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `ZTd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4478` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `append` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Kz` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `XBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3017` |
| 0.0% | 1.3ms | 0.0% | 0us | `twb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1959` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `mermaidInitDirectives` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `DCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3626` |
| 0.0% | 1.3ms | 0.0% | 0us | `extractInitDirectives` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:1112` |
| 0.0% | 1.3ms | 0.0% | 0us | `preprocessMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:869` |
| 0.0% | 1.3ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:688` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `lbd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `vNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:5` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:745` |
| 0.0% | 1.3ms | 0.0% | 0us | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:209` |
| 0.0% | 1.3ms | 0.0% | 0us | `cCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3269` |
| 0.0% | 1.3ms | 0.0% | 0us | `dCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3897` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `qwb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `ued` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:199` |
| 0.0% | 1.3ms | 0.0% | 0us | `cvc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6498` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` |
| 0.0% | 1.3ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:85` |
| 0.0% | 1.3ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:214` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `bqc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1776` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Xfc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `Eyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3027` |
| 0.0% | 1.3ms | 0.0% | 0us | `Agc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `overlaps` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:56` |
| 0.0% | 1.3ms | 0.0% | 0us | `collides` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:173` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:185` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `evaluateExtensionCompatibility` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:109` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readDiff` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:16` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:66` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:186` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:115` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `dCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Beb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:618` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:43` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Iac` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:831` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Dl` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `iNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6268` |
| 0.0% | 1.3ms | 0.0% | 0us | `YNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 0us | `UNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6157` |
| 0.0% | 1.3ms | 0.0% | 0us | `VNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6025` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:400` |
| 0.0% | 1.3ms | 0.0% | 0us | `jNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6421` |
| 0.0% | 1.3ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:259` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5863` |
| 0.0% | 1.3ms | 0.0% | 0us | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:589` |
| 0.0% | 1.3ms | 0.0% | 0us | `Hyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5370` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/addPairToJSMap.js:4` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `PHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:420` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `erCardinalityPieces` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:82` |
| 0.0% | 1.3ms | 0.0% | 0us | `measureText` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:183` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `textBaseRatio` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:49` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `gce` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `yc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3789` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringify.js:6` |
| 0.0% | 1.3ms | 0.0% | 0us | `zjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4226` |
| 0.0% | 1.3ms | 0.0% | 0us | `Bc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 0us | `Bsb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3705` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Eoc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:156` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `amb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/common/seq.js:4` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Reb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/YAMLSeq.js:4` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:5` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:202` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:12` |
| 0.0% | 1.3ms | 0.0% | 0us | `iIc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5235` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `primitiveCapabilityId` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `DGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4076` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1489` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:552` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Hf` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `renderRelationshipLine` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `SEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6337` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `cvc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `fdd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5881` |
| 0.0% | 1.3ms | 0.0% | 0us | `GGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3246` |
| 0.0% | 1.3ms | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1682` |
| 0.0% | 1.3ms | 0.0% | 0us | `JGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3187` |
| 0.0% | 1.3ms | 0.0% | 0us | `uyb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `xeb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `$xb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4288` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Yxb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5782` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `bHd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1095` |
| 0.0% | 1.3ms | 0.0% | 0us | `OC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1478` |
| 0.0% | 1.3ms | 0.0% | 0us | `hyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2970` |
| 0.0% | 1.3ms | 0.0% | 0us | `Eeb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3224` |
| 0.0% | 1.3ms | 0.0% | 0us | `KGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1926` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Mzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `fNc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6404` |
| 0.0% | 1.3ms | 0.0% | 0us | `zEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3581` |
| 0.0% | 1.3ms | 0.0% | 0us | `DEc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6237` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `recordPaintField` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:312` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Xr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `include` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:110` |
| 0.0% | 1.3ms | 0.0% | 0us | `preparedInterTextBounds` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:123` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `pageRectFor` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:146` |
| 0.0% | 1.3ms | 0.0% | 0us | `Q5b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6494` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:136` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `R5b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1761` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `bBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Ueb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `rCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `cjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:660` |
| 0.0% | 1.3ms | 0.0% | 0us | `oub` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `hub` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `ye` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4617` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:55` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:11` |
| 0.0% | 1.3ms | 0.0% | 0us | `Ogc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5852` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Jgc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2728` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Q$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sPc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4570` |
| 0.0% | 1.3ms | 0.0% | 0us | `wpb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2988` |
| 0.0% | 1.3ms | 0.0% | 0us | `kn` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 0us | `Wl` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 0us | `_n` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4375` |
| 0.0% | 1.3ms | 0.0% | 0us | `Dn` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 0us | `Un` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 0us | `bn` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2777` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Qpb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.3ms | 0.0% | 0us | `Xpb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1469` |
| 0.0% | 1.3ms | 0.0% | 0us | `awd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5043` |
| 0.0% | 1.3ms | 0.0% | 0us | `jlb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 0us | `fBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5408` |
| 0.0% | 1.3ms | 0.0% | 0us | `zyb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2250` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `Ijb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3061` |
| 0.0% | 1.3ms | 0.0% | 0us | `Bd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `imul` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `matchMermaidFrontmatter` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `normalizeMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:663` |
| 0.0% | 1.3ms | 0.0% | 0us | `mermaidFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:149` |
| 0.0% | 1.3ms | 0.0% | 0us | `measureText` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:188` |
| 0.0% | 1.3ms | 0.0% | 0us | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:28` |
| 0.0% | 1.3ms | 0.0% | 0us | `styledRunLayout` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:252` |
| 0.0% | 1.3ms | 0.0% | 0us | `isWideRange` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:127` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1747` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:253` |
| 0.0% | 1.3ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:405` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `inRanges` | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:114` |
| 0.0% | 1.3ms | 0.0% | 0us | `getCharWidth` | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:91` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `vkb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 0us | `Fk` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `negotiateCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `executionCapabilityDecision` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1453` |
| 0.0% | 1.3ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1546` |
| 0.0% | 1.3ms | 0.0% | 0us | `HEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3462` |
| 0.0% | 1.3ms | 0.0% | 0us | `wwd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5669` |
| 0.0% | 1.3ms | 0.0% | 0us | `aIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 0us | `THb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4914` |
| 0.0% | 1.3ms | 0.0% | 0us | `LIb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:90` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:312` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:313` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:501` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:761` |
| 0.0% | 1.2ms | 0.0% | 0us | `mixHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:52` |
| 0.0% | 1.2ms | 0.0% | 0us | `parseHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:28` |
| 0.0% | 1.2ms | 0.0% | 0us | `resolveCss` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:736` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `padStart` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 0us | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:39` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `sourceIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` |
| 0.0% | 1.2ms | 0.0% | 0us | `styleSpecJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:595` |
| 0.0% | 1.2ms | 0.0% | 0us | `roleStyleJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:495` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:191` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:597` |
| 0.0% | 1.2ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:173` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:484` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `t9c` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `rolePropertyJsonSchemas` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:484` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:114` |
| 0.0% | 1.2ms | 0.0% | 0us | `arrowMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:36` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `tipAnchoredArrow` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:29` |
| 0.0% | 1.2ms | 0.0% | 0us | `flowchartMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:80` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `SGb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:713` |
| 0.0% | 1.2ms | 0.0% | 0us | `_xc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6503` |
| 0.0% | 1.2ms | 0.0% | 0us | `typographyAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:698` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `cyc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Vwd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:176` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:286` |
| 0.0% | 1.2ms | 0.0% | 0us | `svgRootStartTag` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:202` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:170` |
| 0.0% | 1.2ms | 0.0% | 0us | `Uwd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2026` |
| 0.0% | 1.2ms | 0.0% | 0us | `IUd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 0us | `mmd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6379` |
| 0.0% | 1.2ms | 0.0% | 0us | `tmd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3549` |
| 0.0% | 1.2ms | 0.0% | 0us | `vyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4081` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `vmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Rlb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `F7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5612` |
| 0.0% | 1.2ms | 0.0% | 0us | `graphicalBackendCapabilityClaims` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:271` |
| 0.0% | 1.2ms | 0.0% | 0us | `validatePrimitiveCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:333` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `primitiveCapabilityClaimKey` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:fs/streams` | `internal:fs/streams:2` |
| 0.0% | 1.2ms | 0.0% | 0us | `RYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4629` |
| 0.0% | 1.2ms | 0.0% | 0us | `from` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `SYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `arrayFromFastWithoutMapFn` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `intersects` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1217` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `erRelationshipStyle` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:15` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Ckd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `mzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4037` |
| 0.0% | 1.2ms | 0.0% | 0us | `Bkd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4360` |
| 0.0% | 1.2ms | 0.0% | 0us | `usb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3557` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:fs/binding` | `internal:fs/binding:3` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1488` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1308` |
| 0.0% | 1.2ms | 0.0% | 0us | `erCardinalityInk` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:127` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` |
| 0.0% | 1.2ms | 0.0% | 0us | `Fjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1763` |
| 0.0% | 1.2ms | 0.0% | 0us | `bcd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2017` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Esb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `Ge` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 0us | `Wbd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4150` |
| 0.0% | 1.2ms | 0.0% | 0us | `lkb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 0us | `Ajb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4072` |
| 0.0% | 1.2ms | 0.0% | 0us | `CQb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6456` |
| 0.0% | 1.2ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:153` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1314` |
| 0.0% | 1.2ms | 0.0% | 0us | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:383` |
| 0.0% | 1.2ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1585` |
| 0.0% | 1.2ms | 0.0% | 0us | `boundedString` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:268` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 0us | `snapshotFamilyConfig` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1532` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `stripTrailingComment` | `/tmp/pr449-main-integration-20261029-762/src/shared/trailing-comment.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `findErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:665` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:129` |
| 0.0% | 1.2ms | 0.0% | 0us | `xAd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3087` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `_B` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `lNb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `RFc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5639` |
| 0.0% | 1.2ms | 0.0% | 0us | `ECb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 0us | `CCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2418` |
| 0.0% | 1.2ms | 0.0% | 0us | `VFc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 0us | `mwb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1560` |
| 0.0% | 1.2ms | 0.0% | 0us | `iKb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5383` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `limitJsonConfigDiagnostics` | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts:325` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `outputDescriptorsById` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:787` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:153` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Wcd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `wgd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `prepareWrittenCompoundShape` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:61` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorEndpointAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ddd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6264` |
| 0.0% | 1.2ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:107` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1303` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connectorTerminalStrokeLosses` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts:32` |
| 0.0% | 1.2ms | 0.0% | 0us | `assertRenderableLinearGradient` | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts:65` |
| 0.0% | 1.2ms | 0.0% | 0us | `safeCssToken` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:67` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `trim` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:975` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `a4d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4534` |
| 0.0% | 1.2ms | 0.0% | 0us | `Qxb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4331` |
| 0.0% | 1.2ms | 0.0% | 0us | `Qc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3605` |
| 0.0% | 1.2ms | 0.0% | 0us | `nyb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 0us | `Qkb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `gJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `YJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5342` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `BGc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `ZJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4924` |
| 0.0% | 1.2ms | 0.0% | 0us | `ensureStyledEntity` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:838` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `oEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ensureEntity` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `parseErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:902` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ytb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2613` |
| 0.0% | 1.2ms | 0.0% | 0us | `hasInheritedPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:254` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:51` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `hooks` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:507` |
| 0.0% | 1.2ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:712` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `iUd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `x2d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Fzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5681` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `writeFast` | `internal:fs/streams` |
| 0.0% | 1.2ms | 0.0% | 0us | `yrd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts:1436` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `vMd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `i0b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `n0b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 0us | `k0b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4153` |
| 0.0% | 1.2ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1461` |
| 0.0% | 1.2ms | 0.0% | 0us | `Zlib` | `node:zlib:298` |
| 0.0% | 1.2ms | 0.0% | 0us | `Gzip` | `node:zlib:328` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `init` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `open` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `Ky` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3096` |
| 0.0% | 1.2ms | 0.0% | 0us | `XGb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5141` |
| 0.0% | 1.2ms | 0.0% | 0us | `My` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3014` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ulb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1440` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `ui` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1389` |
| 0.0% | 1.2ms | 0.0% | 0us | `Yh` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1387` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `erCharge` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:204` |
| 0.0% | 1.2ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1569` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Wc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1595` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Wd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `yfd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5328` |
| 0.0% | 1.2ms | 0.0% | 0us | `U8d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6455` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `vWb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `unionSceneBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:28` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `BGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `xmlHasColon` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:85` |
| 0.0% | 1.2ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:382` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `rGd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `RTd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Lcd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `Yrb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1256` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `hjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2804` |
| 0.0% | 1.2ms | 0.0% | 0us | `o_d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 0us | `ezd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6286` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `B4d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `xce` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4736` |
| 0.0% | 1.2ms | 0.0% | 0us | `YLd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5467` |
| 0.0% | 1.2ms | 0.0% | 0us | `pde` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3192` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `_Pb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `qPb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:876` |
| 0.0% | 1.2ms | 0.0% | 0us | `pPb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4957` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Jjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:268` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `mdb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1171` |
| 0.0% | 1.1ms | 0.0% | 0us | `validate` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:75` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `dereferenceSchema` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Yjb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:465` |
| 0.0% | 1.1ms | 0.0% | 0us | `node:zlib` | `node:zlib:161` |
| 0.0% | 1.1ms | 0.0% | 0us | `schemaMatchesRuntimeKind` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:39` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `RFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5055` |
| 0.0% | 1.1ms | 0.0% | 0us | `zbd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4621` |
| 0.0% | 1.1ms | 0.0% | 0us | `s6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:881` |
| 0.0% | 1.1ms | 0.0% | 0us | `Obd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `u6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `o6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1676` |
| 0.0% | 1.1ms | 0.0% | 0us | `xbd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2263` |
| 0.0% | 1.1ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:346` |
| 0.0% | 1.1ms | 0.0% | 0us | `S5b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1802` |
| 0.0% | 1.1ms | 0.0% | 0us | `Qud` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3681` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `SLd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4644` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `XDc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `i7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `OC` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Drb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:796` |
| 0.0% | 1.1ms | 0.0% | 0us | `h4d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `PUd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1172` |
| 0.0% | 1.1ms | 0.0% | 0us | `backendSupportsCapability` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1378` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1490` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:665` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorGeometryHasCurves` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:370` |
| 0.0% | 1.1ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:357` |
| 0.0% | 1.1ms | 0.0% | 0us | `_wd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 0us | `MEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5740` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Iwd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `IEd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4248` |
| 0.0% | 1.1ms | 0.0% | 0us | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1372` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `EGb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 0us | `dGb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4382` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:32` |
| 0.0% | 1.1ms | 0.0% | 0us | `RAb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isAsciiXmlNameChar` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `gVb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `qZb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3229` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `fromEntries` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `ped` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 0us | `tud` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 0us | `Jl` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2185` |
| 0.0% | 1.1ms | 0.0% | 0us | `Gl` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2840` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `qc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `pc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1451` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Pcb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4170` |
| 0.0% | 1.1ms | 0.0% | 0us | `Pvb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3336` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Gzip` | `node:zlib:326` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `UHd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `r0d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:313` |
| 0.0% | 1.1ms | 0.0% | 0us | `displayText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:82` |
| 0.0% | 1.1ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1391` |
| 0.0% | 1.1ms | 0.0% | 0us | `NIc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4070` |
| 0.0% | 1.1ms | 0.0% | 0us | `SCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 0us | `NCb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1767` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `$qb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3001` |
| 0.0% | 1.1ms | 0.0% | 0us | `HIc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2923` |
| 0.0% | 1.1ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:717` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `legibleInk` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:137` |
| 0.0% | 1.1ms | 0.0% | 0us | `Z6b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2315` |
| 0.0% | 1.1ms | 0.0% | 0us | `k7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `cloneObject` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `e7b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5905` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Krc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Afd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `collides` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `Wtb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4770` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `lub` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `X8d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `POc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `sZb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `IDb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `Gtb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3815` |
| 0.0% | 1.1ms | 0.0% | 0us | `Ktb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 0us | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:273` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:273` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:115` |
| 0.0% | 1.1ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1386` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `VJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5879` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/generated-identity.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:279` |
| 0.0% | 1.1ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:278` |
| 0.0% | 1.1ms | 0.0% | 0us | `IZb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `ubd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `acd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2966` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `qlb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3495` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Xb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `xc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4047` |
| 0.0% | 1.1ms | 0.0% | 0us | `Jr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 0us | `zc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3583` |
| 0.0% | 1.1ms | 0.0% | 0us | `Ac` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 0us | `Zb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:407` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `evc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `evaluateExtensionCompatibility` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:144` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:560` |
| 0.0% | 1.1ms | 0.0% | 0us | `node:zlib` | `node:zlib:485` |
| 0.0% | 1.1ms | 0.0% | 0us | `registerCanonicalStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:235` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `createConvenienceMethod` | `node:zlib` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `JJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:159` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `$rb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1967` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Kwd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `Ld` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4127` |
| 0.0% | 1.1ms | 0.0% | 0us | `uNd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `yNd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3045` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:318` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Te` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:519` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `layoutElkGraph` | `/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:291` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts:87` |
| 0.0% | 1.1ms | 0.0% | 0us | `iac` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5969` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `uYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `pac` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:706` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/block/tokens.ts:41` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/block/tokens.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `createErCreationFold` | `/tmp/pr449-main-integration-20261029-762/src/er/creation.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `snapshotCapabilityCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1556` |
| 0.0% | 1.1ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1584` |
| 0.0% | 1.1ms | 0.0% | 0us | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:749` |
| 0.0% | 1.1ms | 0.0% | 0us | `findErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:698` |
| 0.0% | 1.1ms | 0.0% | 0us | `readErOuterStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:514` |
| 0.0% | 1.1ms | 0.0% | 0us | `readErStatement` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:298` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `parseErEntityReference` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `fHb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `erFrameInkPadding` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:767` |
| 0.0% | 1.1ms | 0.0% | 0us | `parseErRelationshipSyntax` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1075` |
| 0.0% | 1.1ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:582` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `fzd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `inspectSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:674` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1131` |
| 0.0% | 1.0ms | 0.0% | 0us | `deferredRenderContractDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1127` |
| 0.0% | 1.0ms | 0.0% | 0us | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1091` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `isForbiddenJsonConfigKey` | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:982` |
| 0.0% | 1.0ms | 0.0% | 0us | `receiptOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:758` |
| 0.0% | 1.0ms | 0.0% | 0us | `gGb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2197` |
| 0.0% | 1.0ms | 0.0% | 0us | `deferredRequestReceiptDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1108` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `dmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3792` |
| 0.0% | 1.0ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1821` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `KFc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Emb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `hmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4752` |
| 0.0% | 1.0ms | 0.0% | 0us | `DWb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5128` |
| 0.0% | 1.0ms | 0.0% | 0us | `UXb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3335` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `o8b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `CBb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3403` |
| 0.0% | 1.0ms | 0.0% | 0us | `ROc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6109` |
| 0.0% | 1.0ms | 0.0% | 0us | `internal:stream` | `internal:stream:47` |
| 0.0% | 1.0ms | 0.0% | 0us | `kYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `UXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 0us | `cYd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4647` |
| 0.0% | 1.0ms | 0.0% | 0us | `dXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4831` |
| 0.0% | 1.0ms | 0.0% | 0us | `TFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4968` |
| 0.0% | 1.0ms | 0.0% | 0us | `LWb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 0us | `bJb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5818` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `gyd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `contains` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2362` |
| 0.0% | 1.0ms | 0.0% | 0us | `value` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:125` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `lld` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `WXd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `svgPathDataProblem` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:212` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolveRenderStyle` | `/tmp/pr449-main-integration-20261029-762/src/styles.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `layoutErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1109` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `FYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 0us | `Lcd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3501` |
| 0.0% | 1.0ms | 0.0% | 0us | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Jcd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6064` |
| 0.0% | 1.0ms | 0.0% | 0us | `mNb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2252` |
| 0.0% | 1.0ms | 0.0% | 0us | `_ib` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2837` |
| 0.0% | 1.0ms | 0.0% | 0us | `OWb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 0us | `jDd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 0us | `JBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5698` |
| 0.0% | 1.0ms | 0.0% | 0us | `jmb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3645` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `sse` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2293` |
| 0.0% | 1.0ms | 0.0% | 0us | `Xu` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2228` |
| 0.0% | 1.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1397` |
| 0.0% | 1.0ms | 0.0% | 0us | `RBd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5222` |
| 0.0% | 1.0ms | 0.0% | 0us | `TAd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4750` |
| 0.0% | 1.0ms | 0.0% | 0us | `rXb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `vgb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4328` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `CYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 0us | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:278` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `transferNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:705` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Ogd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 0us | `Qgd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:921` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `separateErCompounds` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:588` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1356` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `r_b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `performanceExperimentEnabled` | `/tmp/pr449-main-integration-20261029-762/src/experimental-performance.ts:12` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:193` |
| 0.0% | 1.0ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:106` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:112` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `J$b` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Qr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `eOc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:185` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `graphicalBackendCapabilityClaims` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:249` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `receiptOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:711` |
| 0.0% | 1.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1534` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `xmlScalarCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:88` |
| 0.0% | 1.0ms | 0.0% | 0us | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:240` |
| 0.0% | 1.0ms | 0.0% | 0us | `qQc` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6292` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Pud` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `Fr` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:955` |
| 0.0% | 1.0ms | 0.0% | 0us | `Er` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3745` |
| 0.0% | 1.0ms | 0.0% | 0us | `ho` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `hasInheritedSvgTextPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `hYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `xxd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 0us | `ksd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1535` |
| 0.0% | 1.0ms | 0.0% | 0us | `oYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1335` |
| 0.0% | 1.0ms | 0.0% | 0us | `sZb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5274` |
| 0.0% | 1.0ms | 0.0% | 0us | `Vxd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5021` |
| 0.0% | 1.0ms | 0.0% | 0us | `sYb` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1336` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:8` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `EJd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 0us | `iFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4324` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/shapes/index.ts:36` |
| 0.0% | 1.0ms | 0.0% | 0us | `JFd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:6` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `graphicalSvgArtifact` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `Esd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `W7d` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 0us | `rId` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3812` |
| 0.0% | 1.0ms | 0.0% | 0us | `SId` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `XD` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `resolveRoleStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `_bd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2231` |
| 0.0% | 1.0ms | 0.0% | 0us | `Xbd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2685` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `expectedCapabilityState` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1641` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1826` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `inspectAttributeSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:643` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `gAd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.0% | 1.0ms | 0.0% | 0us | `Txd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 1.0ms | 0.0% | 0us | `MTd` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` |
| 0.0% | 999us | 0.0% | 999us | `writeSync` | `[native code]` |
| 0.0% | 999us | 0.0% | 0us | `processChunkSync` | `node:zlib:203` |
| 0.0% | 984us | 0.0% | 984us | `snapshotBoundedExternalData` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |

## Function Details

### `anonymous`
`[native code]` | Self: 12.3% (476.8ms) | Total: 24.6% (948.1ms) | Samples: 54

**Called by:**
- `require` (129)
- `node:zlib` (27)
- `node:stream` (27)
- `internal:stream` (23)
- `internal:streams/compose` (20)
- `internal:streams/pipeline` (16)
- `internal:streams/duplex` (9)
- `internal:streams/destroy` (5)
- `internal:errors` (5)
- `node:fs` (4)
- `internal:streams/legacy` (4)
- `internal:stream` (2)
- `internal:streams/end-of-stream` (2)
- `internal:streams/operators` (2)
- `get WriteStream` (2)
- `internal:stream` (1)
- `internal:streams/readable` (1)
- `internal:validators` (1)
- `internal:fs/streams` (1)

**Calls:**
- `node:stream` (27)
- `internal:stream` (23)
- `internal:streams/compose` (20)
- `(anonymous)` (20)
- `internal:streams/pipeline` (16)
- `(anonymous)` (11)
- `internal:streams/duplex` (9)
- `(anonymous)` (8)
- `(anonymous)` (5)
- `internal:streams/destroy` (5)
- `internal:errors` (5)
- `internal:streams/legacy` (4)
- `(anonymous)` (4)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `internal:streams/end-of-stream` (2)
- `internal:stream` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `internal:primordials` (2)
- `internal:streams/operators` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:streams/legacy` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:validators` (1)
- `(anonymous)` (1)
- `internal:streams/destroy` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:primordials` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `node:events` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `node:events` (1)
- `internal:fs/binding` (1)
- `(anonymous)` (1)
- `internal:streams/readable` (1)
- `internal:fs/streams` (1)
- `(anonymous)` (1)
- `internal:stream` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 6.5% (253.6ms) | Total: 6.5% (253.6ms) | Samples: 119

**Called by:**
- `o` (70)
- `(anonymous)` (48)
- `(anonymous)` (1)

### `xmlSlice`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` | Self: 6.0% (232.7ms) | Total: 6.0% (232.7ms) | Samples: 3

**Called by:**
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (1)

### `gc`
`[native code]` | Self: 3.9% (150.6ms) | Total: 3.9% (150.6ms) | Samples: 90

**Called by:**
- `(module)` (78)
- `(module)` (12)

### `add`
`[native code]` | Self: 3.1% (122.9ms) | Total: 3.1% (122.9ms) | Samples: 6

**Called by:**
- `verifyDocumentEnvelope` (2)
- `validateNode` (1)
- `qualify` (1)
- `(anonymous)` (1)
- `copyInner` (1)

### `WC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4239` | Self: 3.0% (115.6ms) | Total: 3.0% (115.6ms) | Samples: 23

**Called by:**
- `SC` (18)
- `THb` (1)
- `tmd` (1)
- `RHb` (1)
- `XC` (1)
- `RC` (1)

### `set`
`[native code]` | Self: 2.6% (102.8ms) | Total: 2.6% (102.8ms) | Samples: 6

**Called by:**
- `leaf` (1)
- `sceneLowering` (1)
- `diagramColorVariables` (1)
- `validateNode` (1)
- `leaf` (1)
- `install` (1)

### `decodeBase64`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js` | Self: 2.3% (90.8ms) | Total: 2.3% (90.8ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/ascii/shapes/corners.ts:41` | Self: 1.5% (60.9ms) | Total: 1.5% (60.9ms) | Samples: 4

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:129` | Self: 1.0% (41.5ms) | Total: 1.0% (41.5ms) | Samples: 3

### `defineProperty`
`[native code]` | Self: 0.8% (33.6ms) | Total: 0.8% (33.6ms) | Samples: 11

**Called by:**
- `tag` (3)
- `copyInner` (3)
- `attribute` (1)
- `value` (1)
- `install` (1)
- `(anonymous)` (1)
- `appendPrivate` (1)

### `connectorInlineLabelSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:757` | Self: 0.8% (31.2ms) | Total: 0.8% (31.2ms) | Samples: 1

**Called by:**
- `writeConnectorSvg` (1)

### `getOwnPropertyDescriptor`
`[native code]` | Self: 0.7% (28.2ms) | Total: 0.7% (28.2ms) | Samples: 10

**Called by:**
- `copyInner` (9)
- `deferredTerminalProjectionInput` (1)

### `boundedUtf8ByteLength`
`/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` | Self: 0.7% (27.9ms) | Total: 0.7% (27.9ms) | Samples: 2

**Called by:**
- `write` (2)

### `test`
`[native code]` | Self: 0.6% (25.7ms) | Total: 0.9% (36.6ms) | Samples: 5

**Called by:**
- `set` (1)
- `inspectSecurityTail` (1)
- `inspectAttributeSecurity` (1)
- `checkInertGroup` (1)
- `relationshipPairKey` (1)
- `checkInertGroup` (1)
- `formatSvgNumericAttribute` (1)
- `renderPreparedLine` (1)
- `pathBounds` (1)

**Calls:**
- `/[^\x20-\x7e]/u` (1)
- `/^\s*$/` (1)
- `/\sdata-role="[^"]*"/` (1)
- `/<(?:[^\s<>/:]+:)?image\b/i` (1)

### `stringify`
`[native code]` | Self: 0.6% (25.4ms) | Total: 0.8% (31.5ms) | Samples: 14

**Called by:**
- `consume` (6)
- `solidInteriors` (4)
- `solidInteriors` (2)
- `renderedSvgDigest` (1)
- `(anonymous)` (1)
- `validateNode` (1)
- `(module)` (1)
- `validateNode` (1)
- `prepareDisplayText` (1)
- `canonicalJson` (1)

**Calls:**
- `get receipt` (5)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:170` | Self: 0.6% (24.6ms) | Total: 0.9% (36.9ms) | Samples: 8

**Called by:**
- `copyInner` (9)
- `leaf` (2)
- `snapshot` (1)

**Calls:**
- `defineProperty` (3)
- `copyInner` (1)

### `map`
`[native code]` | Self: 0.6% (24.5ms) | Total: 4.6% (180.9ms) | Samples: 15

**Called by:**
- `cloneValue` (17)
- `flatIntoArrayWithCallback` (11)
- `expandLocalReferences` (11)
- `runBackendConformance` (8)
- `prepareMarkerTerminals` (5)
- `(anonymous)` (4)
- `sanitizeDisplayLines` (3)
- `transformSvgCssValues` (3)
- `(anonymous)` (2)
- `pointsBounds` (2)
- `builtinFamilyConformanceReport` (2)
- `deriveConnectorTerminalProjection` (2)
- `tryParseCssColor` (2)
- `renderPreparedLine` (2)
- `projectErPositioned` (2)
- `extractErLayout` (1)
- `styledRunLayout` (1)
- `node:zlib` (1)
- `repairErFrameRoutes` (1)
- `displayText` (1)
- `snapshot` (1)
- `(anonymous)` (1)
- `rolePropertyJsonSchemas` (1)
- `crowsFootMark` (1)
- `glyphBox` (1)
- `markerBoundsAt` (1)
- `renderMultilineText` (1)
- `graphicalBackendCapabilityClaims` (1)
- `extractErLayout` (1)
- `canonicalJson` (1)
- `snapshotBackendCapabilities` (1)
- `solidInteriors` (1)
- `styleSpecJsonSchema` (1)
- `solidInteriors` (1)
- `writeSceneNode` (1)
- `prepareDisplayText` (1)
- `captureFields` (1)
- `(module)` (1)
- `solidInteriors` (1)

**Calls:**
- `(anonymous)` (16)
- `(anonymous)` (11)
- `(anonymous)` (8)
- `(anonymous)` (8)
- `(anonymous)` (4)
- `cloneValue` (4)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `canonicalJson` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `expandLocalReferences` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `possibleShapeStroke` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `erRelationshipBlock` (1)
- `sanitizeTextControls` (1)

### `r1d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.6% (23.1ms) | Total: 0.9% (35.9ms) | Samples: 17

**Called by:**
- `vGd` (23)
- `i1d` (1)

**Calls:**
- `Ltd` (5)
- `_Ud` (1)
- `PUd` (1)

### `replaceField`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:294` | Self: 0.5% (22.7ms) | Total: 0.5% (22.7ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `freeze`
`[native code]` | Self: 0.5% (20.2ms) | Total: 0.5% (20.2ms) | Samples: 11

**Called by:**
- `snapshotScenePrimitiveCell` (2)
- `leaf` (1)
- `leaf` (1)
- `finish` (1)
- `measureRenderStage` (1)
- `group` (1)
- `deepFreeze` (1)
- `createWrittenPolyline` (1)
- `parts` (1)
- `registerBuiltInStyle` (1)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` | Self: 0.4% (19.2ms) | Total: 0.4% (19.2ms) | Samples: 2

**Called by:**
- `attribute` (2)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.4% (17.7ms) | Total: 0.4% (17.7ms) | Samples: 6

**Called by:**
- `positionedPaintCertification` (6)

### `@lazy`
`[native code]` | Self: 0.3% (14.5ms) | Total: 0.3% (14.5ms) | Samples: 3

**Called by:**
- `node:zlib` (2)
- `internal:fs/binding` (1)

### `q_b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6380` | Self: 0.3% (13.4ms) | Total: 0.5% (19.9ms) | Samples: 3

**Called by:**
- `p_b` (5)

**Calls:**
- `Rud` (2)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.2% (11.3ms) | Total: 0.2% (11.3ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `get`
`[native code]` | Self: 0.2% (11.3ms) | Total: 0.2% (11.3ms) | Samples: 4

**Called by:**
- `validateNode` (2)
- `hasInheritedTextPaint` (1)
- `paintPrimitiveSource` (1)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:96` | Self: 0.2% (10.7ms) | Total: 0.2% (10.7ms) | Samples: 5

**Called by:**
- `materializeText` (4)
- `copyInner` (1)

### `ID`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.2% (10.6ms) | Total: 0.2% (10.6ms) | Samples: 4

**Called by:**
- `JD` (4)

### `OFd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2138` | Self: 0.2% (10.1ms) | Total: 0.2% (10.1ms) | Samples: 1

**Called by:**
- `NFd` (1)

### `ownFragment`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:116` | Self: 0.2% (9.5ms) | Total: 0.2% (9.5ms) | Samples: 2

**Called by:**
- `renderEntityBox` (1)
- `renderEntityBox` (1)

### `(unknown)`
`[native code]` | Self: 0.2% (9.2ms) | Total: 0.3% (11.7ms) | Samples: 4

**Called by:**
- `(anonymous)` (1)
- `V0b` (1)

**Calls:**
- `SC` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:114` | Self: 0.2% (9.1ms) | Total: 0.2% (9.1ms) | Samples: 2

**Called by:**
- `copyInner` (2)

### `transformedBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:471` | Self: 0.2% (9.1ms) | Total: 0.2% (10.4ms) | Samples: 4

**Called by:**
- `paintBounds` (5)

**Calls:**
- `every` (1)

### `withPerformanceObserver`
`/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts:44` | Self: 0.2% (9.1ms) | Total: 0.2% (9.1ms) | Samples: 2

**Called by:**
- `(module)` (2)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.2% (9.0ms) | Total: 0.2% (9.0ms) | Samples: 2

**Called by:**
- `validatePaint` (1)
- `validatePaint` (1)

### `Byb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.2% (8.9ms) | Total: 0.2% (8.9ms) | Samples: 1

**Called by:**
- `kyb` (1)

### `assign`
`[native code]` | Self: 0.2% (8.7ms) | Total: 0.2% (8.7ms) | Samples: 2

**Called by:**
- `node:events` (1)
- `issue` (1)

### `has`
`[native code]` | Self: 0.2% (8.3ms) | Total: 0.2% (8.3ms) | Samples: 5

**Called by:**
- `validateDescriptor` (1)
- `(anonymous)` (1)
- `verifyDocumentEnvelope` (1)
- `hasOwned` (1)
- `validateDescriptor` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.2% (8.3ms) | Total: 0.2% (8.3ms) | Samples: 5

**Called by:**
- `validateSceneDocument` (5)

### `Hmb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1049` | Self: 0.2% (8.2ms) | Total: 0.2% (8.2ms) | Samples: 1

**Called by:**
- `OZb` (1)

### `Set`
`[native code]` | Self: 0.2% (8.0ms) | Total: 0.2% (9.4ms) | Samples: 5

**Called by:**
- `resolveRoleStyle` (4)
- `(module)` (1)
- `validateDescriptor` (1)

**Calls:**
- `arrayIteratorNextHelper` (1)

### `connectorSegments`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` | Self: 0.2% (8.0ms) | Total: 0.2% (8.0ms) | Samples: 2

**Called by:**
- `transformedHitDistance` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.2% (8.0ms) | Total: 0.2% (8.0ms) | Samples: 3

**Called by:**
- `serialize` (1)
- `(anonymous)` (1)
- `group` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:161` | Self: 0.2% (7.9ms) | Total: 10.1% (389.5ms) | Samples: 2

**Called by:**
- `copyInner` (80)
- `leaf` (44)
- `copy` (7)
- `snapshot` (4)
- `copy` (1)

**Calls:**
- `copyInner` (80)
- `copyInner` (9)
- `copyInner` (9)
- `materializeText` (7)
- `copy` (7)
- `copy` (3)
- `copy` (2)
- `copyInner` (2)
- `copyInner` (2)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `materializeText` (1)
- `copy` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `materializeText` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:272` | Self: 0.2% (7.8ms) | Total: 0.2% (7.8ms) | Samples: 1

**Called by:**
- `extractErLayout` (1)

### `xmlNameCharacter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:87` | Self: 0.1% (7.6ms) | Total: 0.1% (7.6ms) | Samples: 1

**Called by:**
- `readXmlNameEnd` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:796` | Self: 0.1% (7.3ms) | Total: 0.1% (7.3ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` | Self: 0.1% (7.2ms) | Total: 0.1% (7.2ms) | Samples: 3

**Called by:**
- `attribute` (1)
- `checkInertGroup` (1)
- `scanStartTags` (1)

### `nonPainting`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:129` | Self: 0.1% (7.1ms) | Total: 0.1% (7.1ms) | Samples: 2

**Called by:**
- `leaf` (2)

### `renderRelationshipLine`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:446` | Self: 0.1% (7.0ms) | Total: 0.1% (7.0ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:205` | Self: 0.1% (7.0ms) | Total: 0.1% (7.0ms) | Samples: 2

**Called by:**
- `group` (2)

### `RegExp`
`[native code]` | Self: 0.1% (7.0ms) | Total: 0.1% (7.0ms) | Samples: 3

**Called by:**
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)

### `join`
`[native code]` | Self: 0.1% (7.0ms) | Total: 0.1% (7.0ms) | Samples: 4

**Called by:**
- `escapeDisplayAttr` (1)
- `resolveColors` (1)
- `serializeSceneNode` (1)
- `tryParseCssColor` (1)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.1% (6.9ms) | Total: 0.1% (6.9ms) | Samples: 2

**Called by:**
- `copyInner` (1)
- `materializeText` (1)

### `Erb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4055` | Self: 0.1% (6.8ms) | Total: 0.1% (6.8ms) | Samples: 2

**Called by:**
- `Crb` (2)

### `estimatedResidency`
`/tmp/pr449-main-integration-20261029-762/src/experimental/cache-residency.ts` | Self: 0.1% (6.8ms) | Total: 0.1% (6.8ms) | Samples: 1

**Called by:**
- `resolveColors` (1)

### `teb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1540` | Self: 0.1% (6.6ms) | Total: 0.2% (7.9ms) | Samples: 1

**Called by:**
- `Crb` (2)

**Calls:**
- `tmd` (1)

### `ID`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4818` | Self: 0.1% (6.5ms) | Total: 0.1% (6.5ms) | Samples: 4

**Called by:**
- `JD` (4)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:110` | Self: 0.1% (6.4ms) | Total: 0.1% (6.4ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `xpd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.1% (6.4ms) | Total: 0.1% (6.4ms) | Samples: 2

**Called by:**
- `lbd` (2)

### `flatIntoArray`
`[native code]` | Self: 0.1% (6.4ms) | Total: 0.1% (6.4ms) | Samples: 3

**Called by:**
- `flatIntoArrayWithCallback` (3)

### `hasOwn`
`[native code]` | Self: 0.1% (6.3ms) | Total: 0.1% (6.3ms) | Samples: 4

**Called by:**
- `validateNode` (1)
- `captureNativeGroupEmission` (1)
- `validateNode` (1)
- `observe` (1)

### `issue`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:92` | Self: 0.1% (6.3ms) | Total: 0.1% (6.3ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (1)
- `(anonymous)` (1)

### `captureNativeGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:101` | Self: 0.1% (6.3ms) | Total: 1.4% (56.7ms) | Samples: 2

**Called by:**
- `groupValidation` (21)

**Calls:**
- `captureNativeGroupParse` (19)

### `outcome`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.1% (6.2ms) | Total: 0.1% (6.2ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:526` | Self: 0.1% (6.1ms) | Total: 0.1% (6.1ms) | Samples: 2

**Called by:**
- `text` (2)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` | Self: 0.1% (6.1ms) | Total: 0.1% (6.1ms) | Samples: 1

**Called by:**
- `paintedStrokeExtent` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:308` | Self: 0.1% (6.1ms) | Total: 0.1% (6.1ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `Wr`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.1% (6.0ms) | Total: 0.1% (6.0ms) | Samples: 1

**Called by:**
- `$Dc` (1)

### `every`
`[native code]` | Self: 0.1% (5.9ms) | Total: 0.2% (11.0ms) | Samples: 4

**Called by:**
- `include` (1)
- `transformedBounds` (1)
- `renderDisplayRuns` (1)
- `evaluateExtensionCompatibility` (1)
- `preparePixelText` (1)
- `erCardinalityInk` (1)
- `leaf` (1)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `cgd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.1% (5.8ms) | Total: 0.1% (5.8ms) | Samples: 1

**Called by:**
- `lZb` (1)

### `Dwd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.1% (5.6ms) | Total: 0.1% (5.6ms) | Samples: 2

**Called by:**
- `Usd` (2)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.1% (5.6ms) | Total: 0.1% (5.6ms) | Samples: 2

**Called by:**
- `leaf` (2)

### `xmlAsciiLetter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` | Self: 0.1% (5.5ms) | Total: 0.1% (5.5ms) | Samples: 1

**Called by:**
- `readXmlNameEnd` (1)

### `importModule`
`[native code]` | Self: 0.1% (5.5ms) | Total: 0.1% (5.5ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.1% (5.5ms) | Total: 0.1% (5.5ms) | Samples: 2

**Called by:**
- `drawNative` (2)

### `slice`
`[native code]` | Self: 0.1% (5.5ms) | Total: 0.1% (5.5ms) | Samples: 3

**Called by:**
- `tryParseCssColor` (1)
- `bnb` (1)
- `(anonymous)` (1)

### `sanitizeDisplayLines`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` | Self: 0.1% (5.4ms) | Total: 0.1% (5.4ms) | Samples: 1

**Called by:**
- `renderRelationshipLine` (1)

### `min`
`[native code]` | Self: 0.1% (5.4ms) | Total: 0.1% (5.4ms) | Samples: 3

**Called by:**
- `DEc` (1)
- `validateGeometry` (1)
- `visit` (1)

### `compositeCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:277` | Self: 0.1% (5.4ms) | Total: 0.1% (5.4ms) | Samples: 1

**Called by:**
- `toneOnFill` (1)

### `Jmb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.1% (5.3ms) | Total: 0.1% (5.3ms) | Samples: 1

**Called by:**
- `Wr` (1)

### `sourceSlice`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:55` | Self: 0.1% (5.3ms) | Total: 0.1% (6.5ms) | Samples: 1

**Called by:**
- `scanStartTags` (2)

**Calls:**
- `isAsciiXmlNameChar` (1)

### `rb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4337` | Self: 0.1% (5.3ms) | Total: 0.1% (5.3ms) | Samples: 1

**Called by:**
- `XC` (1)

### `Gsd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5992` | Self: 0.1% (5.3ms) | Total: 0.1% (5.3ms) | Samples: 3

**Called by:**
- `izd` (1)
- `r0d` (1)
- `IUd` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:304` | Self: 0.1% (5.2ms) | Total: 0.1% (5.2ms) | Samples: 3

**Called by:**
- `attribute` (3)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:166` | Self: 0.1% (5.2ms) | Total: 1.5% (59.8ms) | Samples: 1

**Called by:**
- `renderCardinality` (7)
- `renderCardinality` (7)
- `lowerErDrawing` (4)

**Calls:**
- `group` (10)
- `group` (4)
- `group` (1)
- `group` (1)
- `group` (1)

### `Rc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5459` | Self: 0.1% (5.1ms) | Total: 0.2% (7.9ms) | Samples: 2

**Called by:**
- `JKb` (4)

**Calls:**
- `Fzb` (1)
- `uyb` (1)

### `segmentThroughShape`
`/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:174` | Self: 0.1% (5.1ms) | Total: 0.1% (5.1ms) | Samples: 1

**Called by:**
- `some` (1)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:94` | Self: 0.1% (5.0ms) | Total: 0.1% (5.0ms) | Samples: 1

**Called by:**
- `materializeText` (1)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.1% (5.0ms) | Total: 0.1% (5.0ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:444` | Self: 0.1% (5.0ms) | Total: 0.1% (5.0ms) | Samples: 1

**Called by:**
- `sort` (1)

### `xmlAsciiLetter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.1% (5.0ms) | Total: 0.1% (5.0ms) | Samples: 1

**Called by:**
- `readXmlNameEnd` (1)

### `owb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2807` | Self: 0.1% (5.0ms) | Total: 0.1% (5.0ms) | Samples: 3

**Called by:**
- `Bwb` (2)
- `twb` (1)

### `sceneGroupOpacity`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 2

**Called by:**
- `group` (1)
- `possibleShapeFill` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:234` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `resolveSceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 2

**Called by:**
- `sceneRoleTraits` (2)

### `defineProperties`
`[native code]` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 3

**Called by:**
- `emissionRecord` (2)
- `attributeRecord` (1)

### `connectorMarkerPaintRegions`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1467` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 1

**Called by:**
- `serialize` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:175` | Self: 0.1% (4.8ms) | Total: 0.1% (6.6ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)
- `renderCardinality` (1)

**Calls:**
- `enclosure` (1)

### `p1d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 1

**Called by:**
- `CGd` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:85` | Self: 0.1% (4.8ms) | Total: 0.9% (37.9ms) | Samples: 1

**Called by:**
- `inspectPaint` (16)

**Calls:**
- `visit` (11)
- `visit` (4)

### `isAsciiXmlNameChar`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:8` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `UBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 1

**Called by:**
- `mQc` (1)

### `localPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `transformMatrix`
`/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 1

**Called by:**
- `hitsTransformed` (1)

### `intersects`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.1% (4.8ms) | Total: 0.1% (4.8ms) | Samples: 1

**Called by:**
- `finishErGeometry` (1)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 2

**Called by:**
- `validateGeometry` (2)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 2

**Called by:**
- `paintedStrokeExtent` (2)

### `transformedBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:479` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `Vr`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4327` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 1

**Called by:**
- `Wr` (1)

### `/^\s*$/`
`[native code]` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 1

**Called by:**
- `test` (1)

### `resolveSceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:213` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 1

**Called by:**
- `sceneRoleTraits` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:203` | Self: 0.1% (4.7ms) | Total: 0.1% (4.7ms) | Samples: 1

**Called by:**
- `group` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:161` | Self: 0.1% (4.6ms) | Total: 0.1% (4.6ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `ownData`
`/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:48` | Self: 0.1% (4.6ms) | Total: 0.1% (4.6ms) | Samples: 3

**Called by:**
- `prepareWrittenCompoundShape` (1)
- `prepareWrittenCompoundShape` (1)
- `prepareWrittenCompoundShape` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:177` | Self: 0.1% (4.5ms) | Total: 0.1% (4.5ms) | Samples: 1

**Called by:**
- `map` (1)

### `createNativePaintEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.1% (4.5ms) | Total: 0.1% (4.5ms) | Samples: 3

**Called by:**
- `drawNative` (3)

### `attributeRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` | Self: 0.1% (4.5ms) | Total: 0.1% (4.5ms) | Samples: 2

**Called by:**
- `attribute` (2)

### `tree`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.1% (4.5ms) | Total: 0.1% (4.5ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `inspectOwnedSvgOnce`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts` | Self: 0.1% (4.5ms) | Total: 0.1% (4.5ms) | Samples: 1

**Called by:**
- `applyOutputSecurityPolicy` (1)

### `escapeAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:108` | Self: 0.1% (4.5ms) | Total: 0.2% (7.8ms) | Samples: 1

**Called by:**
- `attribute` (1)
- `crowsFootMark` (1)

**Calls:**
- `/[&<>"'\t\n\r]/` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:156` | Self: 0.1% (4.4ms) | Total: 0.2% (11.4ms) | Samples: 2

**Called by:**
- `scanStartTags` (4)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `RAd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2285` | Self: 0.1% (4.3ms) | Total: 0.1% (4.3ms) | Samples: 1

**Called by:**
- `bBd` (1)

### `consume`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:17` | Self: 0.1% (4.3ms) | Total: 0.1% (5.6ms) | Samples: 4

**Called by:**
- `(module)` (5)

**Calls:**
- `imul` (1)

### `endpointOwner`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:118` | Self: 0.1% (4.3ms) | Total: 0.1% (4.3ms) | Samples: 2

**Called by:**
- `renderRelationshipLine` (2)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:128` | Self: 0.1% (4.3ms) | Total: 0.1% (4.3ms) | Samples: 2

**Called by:**
- `copyInner` (1)
- `leaf` (1)

### `writeFileSync`
`[native code]` | Self: 0.1% (4.2ms) | Total: 0.2% (8.5ms) | Samples: 2

**Called by:**
- `writeFileSync` (2)
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `writeFileSync` (2)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:277` | Self: 0.1% (4.2ms) | Total: 0.1% (4.2ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:118` | Self: 0.1% (4.2ms) | Total: 0.1% (4.2ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `polylineLength`
`/tmp/pr449-main-integration-20261029-762/src/layout/geometry.ts:67` | Self: 0.1% (4.2ms) | Total: 0.1% (4.2ms) | Samples: 1

**Called by:**
- `pointAtPathDistance` (1)

### `split`
`[native code]` | Self: 0.1% (4.1ms) | Total: 0.1% (4.1ms) | Samples: 2

**Called by:**
- `sanitizeDisplayLines` (1)
- `Ieb` (1)

### `Meb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3984` | Self: 0.1% (4.1ms) | Total: 0.1% (7.0ms) | Samples: 1

**Called by:**
- `zeb` (2)

**Calls:**
- `Geb` (1)

### `startsWith`
`[native code]` | Self: 0.1% (4.1ms) | Total: 0.1% (4.1ms) | Samples: 2

**Called by:**
- `ensureSvgIdentity` (2)

### `replace`
`[native code]` | Self: 0.1% (4.0ms) | Total: 0.1% (5.3ms) | Samples: 2

**Called by:**
- `formatSvgNumericAttribute` (1)
- `normalizePlainLabel` (1)
- `resolveCss` (1)

**Calls:**
- `mixHex` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` | Self: 0.1% (4.0ms) | Total: 0.1% (4.0ms) | Samples: 2

**Called by:**
- `map` (2)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` | Self: 0.1% (4.0ms) | Total: 0.1% (4.0ms) | Samples: 2

**Called by:**
- `absentPaint` (1)
- `relativeLuminance` (1)

### `possibleShapeStroke`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:133` | Self: 0.1% (4.0ms) | Total: 0.1% (4.0ms) | Samples: 1

**Called by:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` | Self: 0.1% (4.0ms) | Total: 0.1% (4.0ms) | Samples: 1

**Called by:**
- `map` (1)

### `arrayIteratorNextHelper`
`[native code]` | Self: 0.1% (3.9ms) | Total: 0.1% (3.9ms) | Samples: 2

**Called by:**
- `next` (1)
- `Set` (1)

### `aXd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6207` | Self: 0.1% (3.9ms) | Total: 0.2% (8.2ms) | Samples: 2

**Called by:**
- `jXd` (4)

**Calls:**
- `RFd` (1)
- `RXd` (1)

### `transferRetainedPixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:88` | Self: 0.1% (3.9ms) | Total: 0.1% (3.9ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:163` | Self: 0.1% (3.9ms) | Total: 0.1% (3.9ms) | Samples: 1

**Called by:**
- `projectSvgCss` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.1% (3.9ms) | Total: 0.1% (3.9ms) | Samples: 1

**Called by:**
- `observe` (1)

### `TC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4909` | Self: 0.1% (3.9ms) | Total: 0.1% (3.9ms) | Samples: 2

**Called by:**
- `RC` (1)
- `SC` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.1% (3.8ms) | Total: 0.1% (3.8ms) | Samples: 2

**Called by:**
- `certifyNativePaint` (2)

### `inverseMatrix`
`/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts:25` | Self: 0.0% (3.8ms) | Total: 0.0% (3.8ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `endpointRelation`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (3.8ms) | Total: 0.0% (3.8ms) | Samples: 1

**Called by:**
- `walk` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:145` | Self: 0.0% (3.8ms) | Total: 0.0% (3.8ms) | Samples: 1

**Called by:**
- `visitSvgFirstTagAttributes` (1)

### `startTags`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:65` | Self: 0.0% (3.8ms) | Total: 0.0% (3.8ms) | Samples: 1

**Called by:**
- `inspectSecurity` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:53` | Self: 0.0% (3.8ms) | Total: 0.0% (3.8ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `xKb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6339` | Self: 0.0% (3.7ms) | Total: 0.2% (10.9ms) | Samples: 1

**Called by:**
- `gHb` (5)

**Calls:**
- `kd` (2)
- `kd` (1)
- `Bd` (1)

### `flatIntoArrayWithCallback`
`[native code]` | Self: 0.0% (3.7ms) | Total: 1.0% (42.1ms) | Samples: 1

**Called by:**
- `snapshot` (4)
- `finishErGeometry` (3)
- `resolveExecutionPlan` (2)
- `finishErGeometry` (2)
- `placeRelationshipLabels` (2)
- `extractErLayout` (1)
- `connectorPaintBounds` (1)
- `extractErLayout` (1)
- `placeRelationshipLabels` (1)
- `connector` (1)
- `(module)` (1)
- `extractErLayout` (1)

**Calls:**
- `map` (11)
- `flatIntoArray` (3)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `Ieb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5583` | Self: 0.0% (3.7ms) | Total: 0.1% (5.1ms) | Samples: 2

**Called by:**
- `seb` (3)

**Calls:**
- `split` (1)

### `sceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` | Self: 0.0% (3.7ms) | Total: 0.3% (13.4ms) | Samples: 1

**Called by:**
- `relationAccessibility` (2)
- `validateRole` (1)
- `hasDomSvgIdentityRole` (1)

**Calls:**
- `resolveSceneRoleTraits` (2)
- `resolveSceneRoleTraits` (1)

### `xmlIndexOf`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:22` | Self: 0.0% (3.7ms) | Total: 0.0% (3.7ms) | Samples: 1

**Called by:**
- `scanTagEnd` (1)

### `possibleShapeStroke`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (3.7ms) | Total: 0.0% (3.7ms) | Samples: 1

**Called by:**
- `solidInteriors` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1597` | Self: 0.0% (3.7ms) | Total: 0.0% (3.7ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `validateConnectorProjectionConsistency`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (3.7ms) | Total: 0.0% (3.7ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:155` | Self: 0.0% (3.6ms) | Total: 0.0% (3.6ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `parseInt`
`[native code]` | Self: 0.0% (3.6ms) | Total: 0.0% (3.6ms) | Samples: 3

**Called by:**
- `tryParseCssColor` (2)
- `parseHex` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:596` | Self: 0.0% (3.6ms) | Total: 0.0% (3.6ms) | Samples: 1

**Called by:**
- `writeConnectorSvg` (1)

### `copyDataProperties`
`[native code]` | Self: 0.0% (3.6ms) | Total: 0.0% (3.6ms) | Samples: 2

**Called by:**
- `completeBuiltinDescriptor` (1)
- `group` (1)

### `oD`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6204` | Self: 0.0% (3.6ms) | Total: 0.0% (3.6ms) | Samples: 1

**Called by:**
- `Vcb` (1)

### `textSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1654` | Self: 0.0% (3.6ms) | Total: 0.0% (3.6ms) | Samples: 1

**Called by:**
- `textSurfaces` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:309` | Self: 0.0% (3.5ms) | Total: 0.0% (3.5ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `Segmenter`
`[native code]` | Self: 0.0% (3.5ms) | Total: 0.0% (3.5ms) | Samples: 3

**Called by:**
- `(module)` (3)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:247` | Self: 0.0% (3.5ms) | Total: 0.0% (3.5ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.0% (3.5ms) | Total: 0.1% (4.6ms) | Samples: 3

**Called by:**
- `compare` (2)
- `map` (1)
- `some` (1)

**Calls:**
- `(unknown)` (1)

### `sanitizeTextControls`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:9` | Self: 0.0% (3.5ms) | Total: 0.0% (3.5ms) | Samples: 1

**Called by:**
- `map` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:596` | Self: 0.0% (3.5ms) | Total: 0.2% (10.9ms) | Samples: 2

**Called by:**
- `visit` (4)
- `visit` (2)

**Calls:**
- `hasInheritedSvgTextPaint` (1)
- `hasInheritedPaint` (1)
- `hasInheritedTextPaint` (1)
- `hasInheritedPaint` (1)

### `value`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:124` | Self: 0.0% (3.5ms) | Total: 0.1% (5.3ms) | Samples: 1

**Called by:**
- `nativeGroup` (2)

**Calls:**
- `attributeRecord` (1)

### `Qjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3372` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `Cyb` (1)

### `indent`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:236` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `collectNativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:164` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `compare`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:33` | Self: 0.0% (3.4ms) | Total: 0.1% (5.6ms) | Samples: 2

**Called by:**
- `chargeInkSort` (3)
- `sort` (1)

**Calls:**
- `(anonymous)` (2)

### `hasInheritedPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `observe` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:799` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `TEc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5052` | Self: 0.0% (3.4ms) | Total: 0.1% (4.7ms) | Samples: 1

**Called by:**
- `fFc` (2)

**Calls:**
- `SEc` (1)

### `internal:streams/destroy`
`internal:streams/destroy:16` | Self: 0.0% (3.4ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:32` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 1

**Called by:**
- `map` (1)

### `seedFrom`
`/tmp/pr449-main-integration-20261029-762/src/scene/seed.ts` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 1

**Called by:**
- `hashId` (1)

### `charge`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `/[&<>"'\t\n\r]/`
`[native code]` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 1

**Called by:**
- `escapeAttr` (1)

### `isPlainFontFamily`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 1

**Called by:**
- `buildStyleBlock` (1)

### `Rse`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (3.3ms) | Total: 0.0% (3.3ms) | Samples: 1

**Called by:**
- `cBd` (1)

### `crowsFootMark`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 1

**Called by:**
- `renderCardinality` (1)

### `cJb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6363` | Self: 0.0% (3.2ms) | Total: 1.0% (38.7ms) | Samples: 1

**Called by:**
- `gHb` (11)
- `fHb` (5)

**Calls:**
- `Old` (6)
- `crb` (4)
- `sqd` (2)
- `bld` (1)
- `My` (1)
- `yrd` (1)

### `/<(?:[^\s<>/:]+:)?image\b/i`
`[native code]` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 1

**Called by:**
- `test` (1)

### `append`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:239` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `leaf` (2)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `lowerErDrawing` (2)

### `p_b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6372` | Self: 0.0% (3.2ms) | Total: 0.8% (32.8ms) | Samples: 1

**Called by:**
- `NQb` (12)

**Calls:**
- `q_b` (5)
- `o_b` (5)
- `r_b` (1)

### `x7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6110` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 1

**Called by:**
- `y7b` (1)

### `createNativeSceneValidator`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:485` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `writeConnectorSvg` (1)

### `consume`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:232` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `visit` (1)

### `recordPaintField`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `fPc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2891` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `dPc` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:106` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `hasImmutablePaintRoster`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `jGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (3.1ms) | Total: 0.3% (11.8ms) | Samples: 2

**Called by:**
- `NFd` (6)
- `LFd` (1)

**Calls:**
- `FXd` (2)
- `uZd` (1)
- `W7d` (1)
- `the` (1)

### `isOwnedDisplayTextPart`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:30` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `copy` (1)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:18` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:200` | Self: 0.0% (3.0ms) | Total: 0.1% (6.4ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (2)

**Calls:**
- `sceneGroupOpacity` (1)

### `segmentThroughShape`
`/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:170` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `some` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `RXd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `aXd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 2

**Called by:**
- `snapshotDescriptorArray` (2)

### `yd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3912` | Self: 0.0% (3.0ms) | Total: 0.0% (3.0ms) | Samples: 1

**Called by:**
- `Dd` (1)

### `deepFreeze`
`/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` | Self: 0.0% (3.0ms) | Total: 0.6% (25.6ms) | Samples: 1

**Called by:**
- `deepFreeze` (9)
- `report` (1)
- `validateSerializableRenderOptions` (1)
- `withTextMeasurementExecution` (1)

**Calls:**
- `deepFreeze` (9)
- `freeze` (1)
- `deepFreeze` (1)

### `consumeStringBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `validateNodeSerialization` (1)

### `collectNativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:146` | Self: 0.0% (2.9ms) | Total: 0.8% (34.6ms) | Samples: 1

**Called by:**
- `(anonymous)` (13)

**Calls:**
- `visitSvgStartTagsFresh` (12)

### `displayRunAttributes`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `isHexColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:143` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `resolvedColorValue` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1038` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `write` (1)

### `indent`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` | Self: 0.0% (2.9ms) | Total: 0.0% (2.9ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `(anonymous)`
`[native code]` | Self: 0.0% (2.9ms) | Total: 0.1% (5.3ms) | Samples: 2

**Called by:**
- `(module)` (2)
- `internal:streams/legacy` (1)
- `node:zlib` (1)

**Calls:**
- `get WriteStream` (2)

### `filter`
`[native code]` | Self: 0.0% (2.8ms) | Total: 0.2% (7.9ms) | Samples: 1

**Called by:**
- `(module)` (1)
- `placeRelationshipLabels` (1)
- `validate` (1)
- `backendSupportsCapability` (1)
- `semanticIdentityForSvg` (1)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `schemaMatchesRuntimeKind` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:198` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `renderCardinality` (1)

### `VC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2915` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 2

**Called by:**
- `wsb` (1)
- `plb` (1)

### `GAd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `$Bd` (1)

### `Keb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `Geb` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `scopeSvgStyles` (1)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:20` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `UHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5196` | Self: 0.0% (2.8ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `RHb` (1)

### `ijd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `edd` (2)

### `hasOwned`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `copy` (1)

### `drawNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `drawn` (1)

### `TJb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5486` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `JKb` (1)

### `fKd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2151` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `AKd` (2)

### `v6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `Ar` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `group` (1)

### `PEc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `_mb` (1)

### `svgOpenTag`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:178` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `copyInner` (2)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:117` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:55` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `captureNativeGroupParse` (1)

### `dKd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `I$b` (1)

### `PHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5783` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `_Hb` (1)

### `registerCanonicalStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `registerBuiltInStyle` (1)

### `boundedNonNegative`
`/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:207` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `copyInner` (2)

### `iHc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `UJc` (2)

### `kWd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6128` | Self: 0.0% (2.7ms) | Total: 5.7% (220.2ms) | Samples: 2

**Called by:**
- `kWd` (21)
- `PWd` (21)

**Calls:**
- `kWd` (21)
- `$Ed` (16)
- `YEd` (1)
- `OHd` (1)
- `pjb` (1)

### `ltb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3516` | Self: 0.0% (2.7ms) | Total: 0.1% (3.9ms) | Samples: 1

**Called by:**
- `Otb` (2)

**Calls:**
- `Yrb` (1)

### `at`
`[native code]` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 2

**Called by:**
- `canonicalErContacts` (1)
- `connectorContourSemantics` (1)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:189` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

### `ActualTextPaintWrite`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:393` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:117` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `shape` (1)

### `crowsFootMark`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:609` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `renderCardinality` (1)

### `some`
`[native code]` | Self: 0.0% (2.6ms) | Total: 0.5% (22.4ms) | Samples: 2

**Called by:**
- `detectorClaims` (2)
- `some` (2)
- `repairErFrameRoutes` (2)
- `finishErGeometry` (1)
- `connector/subpaths/render` (1)

**Calls:**
- `some` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `segmentThroughShape` (1)
- `segmentThroughShape` (1)

### `next`
`[native code]` | Self: 0.0% (2.6ms) | Total: 0.1% (5.2ms) | Samples: 2

**Called by:**
- `performIteration` (3)

**Calls:**
- `arrayIteratorNextHelper` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:285` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (2.6ms) | Total: 0.4% (18.7ms) | Samples: 2

**Called by:**
- `(anonymous)` (10)

**Calls:**
- `mdb` (3)
- `zeb` (2)
- `Beb` (1)
- `mdb` (1)
- `Aeb` (1)

### `resolveRoleStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:240` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `repairErFrameRoutes` (1)
- `erRelationshipBlock` (1)

### `MFd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4458` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `sJd` (2)

### `jDb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5481` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 2

**Called by:**
- `mDb` (2)

### `nativePaintAncestors`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `visit` (1)

### `canonicalizeSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:465` | Self: 0.0% (2.6ms) | Total: 0.0% (2.6ms) | Samples: 1

**Called by:**
- `attachSceneNodeSerialization` (1)

### `pWd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 2

**Called by:**
- `tud` (1)
- `PWd` (1)

### `localPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1390` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `relationshipPairKey`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:162` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `header`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `documentOpen` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:526` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `validateNodeSerialization` (1)

### `SC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `(unknown)` (1)

### `isInteger`
`[native code]` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `depth` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:729` | Self: 0.0% (2.4ms) | Total: 0.5% (20.2ms) | Samples: 2

**Called by:**
- `serializeSceneNode` (9)

**Calls:**
- `renderMultilineText` (4)
- `renderMultilineText` (2)
- `renderMultilineText` (1)

### `sanitizeDisplayLines`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` | Self: 0.0% (2.4ms) | Total: 0.3% (13.2ms) | Samples: 2

**Called by:**
- `renderRelationshipLine` (5)
- `escapeDisplayAttr` (1)

**Calls:**
- `map` (3)
- `split` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:49` | Self: 0.0% (2.4ms) | Total: 0.4% (16.9ms) | Samples: 1

**Called by:**
- `join` (7)

**Calls:**
- `indent` (2)
- `issue` (1)
- `(anonymous)` (1)
- `issue` (1)
- `indent` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:154` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `map` (1)

### `renderPreparedLine`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `renderMultilineText` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `visit` (1)

### `interTextEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/shared/inter-text-envelope.ts:20` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `Tad`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 2

**Called by:**
- `Xad` (2)

### `nud`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `Vsd` (1)

### `kXb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (2.4ms) | Total: 0.0% (2.4ms) | Samples: 1

**Called by:**
- `oHb` (1)

### `Le`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 2

**Called by:**
- `YJb` (1)
- `e7b` (1)

### `Pe`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (2.3ms) | Total: 0.1% (6.6ms) | Samples: 1

**Called by:**
- `$lb` (2)
- `kmb` (2)

**Calls:**
- `Ce` (3)

### `Usd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3200` | Self: 0.0% (2.3ms) | Total: 0.2% (9.3ms) | Samples: 2

**Called by:**
- `Ltd` (5)

**Calls:**
- `Dwd` (2)
- `Mzd` (1)

### `reserve`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `nativeGroup` (1)

### `opaqueOutlineWidth`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:149` | Self: 0.0% (2.3ms) | Total: 0.1% (4.5ms) | Samples: 1

**Called by:**
- `solidInteriors` (2)

**Calls:**
- `opaque` (1)

### `withDeferredTerminalProjections`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `some` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1089` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `write` (1)

### `node:events`
`node:events:577` | Self: 0.0% (2.3ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `PromisedWorker`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `ELK` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:232` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `_Ud`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `r1d` (1)

### `transferRetainedPixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `materializeText` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:130` | Self: 0.0% (2.2ms) | Total: 0.6% (26.5ms) | Samples: 1

**Called by:**
- `copyInner` (9)
- `leaf` (1)

**Calls:**
- `getOwnPropertyDescriptor` (9)

### `uncurryThis`
`internal:primordials` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `internal:primordials` (1)

### `kWd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `PWd` (1)

### `assertMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:54` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `connector` (1)

### `push`
`[native code]` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `sceneValidationMode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `boundedString`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:267` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `validateChannels` (1)

### `Z7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `nQb` (1)

### `createEmissionContext`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `createNativePaintEmission` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/set.js:7` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `opaque` (1)

### `mdb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5533` | Self: 0.0% (2.1ms) | Total: 0.1% (4.5ms) | Samples: 1

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `pdb` (2)

### `WC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 2

**Called by:**
- `SC` (1)
- `CIb` (1)

### `exec`
`[native code]` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `localPaintResourceId` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 2

**Called by:**
- `runMeasuredGraphBackend` (2)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` | Self: 0.0% (2.1ms) | Total: 0.1% (5.8ms) | Samples: 1

**Called by:**
- `copyInner` (1)
- `leaf` (1)

**Calls:**
- `add` (1)

### `tb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 2

**Called by:**
- `asb` (2)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `setName`
`node:fs:696` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `node:fs` (1)

### `validateMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:357` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:120` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `renderRelationshipLabel` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:900` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `validateSceneDocument` (1)

### `consumePointBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `validatePoint` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:1126` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `iub`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `qub` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1660` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `Aeb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:778` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `themePaint`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:47` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `resolveDiagramColors` (1)

### `lC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3498` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `kC` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:229` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:320` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `withDeferredTerminalProjections` (1)

### `create`
`[native code]` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `xmlParserList` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:333` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:711` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `inspectSecurityTail`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `inspectOwnedSvgOnce` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:644` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `map` (1)

### `pb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4466` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `Hb` (1)

### `AQb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `EQb` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:109` | Self: 0.0% (1.9ms) | Total: 0.1% (5.7ms) | Samples: 1

**Called by:**
- `copyInner` (1)
- `leaf` (1)

**Calls:**
- `pay` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:578` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `validateNodeSerialization` (1)

### `themePaint`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `resolveDiagramColors` (1)

### `serializeLinearGradientResources`
`/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts:117` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `mbd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.9ms) | Total: 0.0% (1.9ms) | Samples: 1

**Called by:**
- `lbd` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:202` | Self: 0.0% (1.8ms) | Total: 0.0% (3.2ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (2)

**Calls:**
- `map` (1)

### `isRetainedPixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:86` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `_x`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4182` | Self: 0.0% (1.8ms) | Total: 0.1% (5.0ms) | Samples: 1

**Called by:**
- `Old` (2)
- `bld` (1)

**Calls:**
- `Srb` (2)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `group` (1)

### `boxAt`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:168` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `placeRelationshipLabels` (1)

### `dZd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `LFd` (1)

### `JD`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2608` | Self: 0.0% (1.8ms) | Total: 0.4% (19.0ms) | Samples: 1

**Called by:**
- `Wr` (1)
- `qQc` (1)
- `Lac` (1)
- `Hac` (1)
- `IZb` (1)
- `KKd` (1)
- `Crb` (1)
- `q6b` (1)
- `Grb` (1)

**Calls:**
- `ID` (4)
- `ID` (4)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:207` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:658` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `map` (1)

### `createSafeIterator`
`internal:primordials` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `internal:primordials` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:484` | Self: 0.0% (1.8ms) | Total: 0.1% (5.1ms) | Samples: 1

**Called by:**
- `identityAttributes` (1)
- `paintAttribute` (1)

**Calls:**
- `escapeAttr` (1)

### `validateChannels`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:575` | Self: 0.0% (1.8ms) | Total: 0.0% (1.8ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `relationAccessibility`
`/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` | Self: 0.0% (1.8ms) | Total: 0.1% (6.7ms) | Samples: 1

**Called by:**
- `shape` (2)
- `connector` (1)

**Calls:**
- `sceneRoleTraits` (2)

### `value`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:128` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `nativeGroup` (1)

### `connector/subpaths/render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `kd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `xKb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `map` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `mXb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `oHb` (1)

### `appendPrivate`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `group` (1)

### `SC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3689` | Self: 0.0% (1.7ms) | Total: 2.9% (115.3ms) | Samples: 1

**Called by:**
- `wsb` (12)
- `Wlb` (4)
- `Bsb` (1)
- `FIb` (1)
- `usb` (1)
- `uZd` (1)
- `KKd` (1)
- `Ce` (1)

**Calls:**
- `WC` (18)
- `TC` (1)
- `WC` (1)
- `OC` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `renderRelationshipLabel` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:196` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `group` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:521` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `connectorMidpointMarkerAnchors`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `deriveConnectorTerminalProjection` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:295` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `XmlLeafWrite` (1)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:778` | Self: 0.0% (1.7ms) | Total: 0.1% (7.4ms) | Samples: 1

**Called by:**
- `write` (2)
- `validateSceneDocument` (1)
- `node` (1)

**Calls:**
- `validateChannels` (1)
- `validateChannels` (1)
- `validateChannels` (1)

### `registerBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `xNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5494` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `eNc` (1)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `lineStrokeBox` (1)

### `makeSafe`
`internal:primordials` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `internal:primordials` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:204` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `enclosure`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1495` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `group` (1)

### `assertRenderableMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `tipAnchoredArrow` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:217` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:140` | Self: 0.0% (1.7ms) | Total: 27.3% (1.05s) | Samples: 1

**Called by:**
- `measureRenderStage` (345)

**Calls:**
- `withTextMeasurementExecution` (344)

### `N$b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `I$b` (1)

### `validateChannels`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `vgb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `vEd` (1)

### `aod`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `lQb` (1)

### `_Td`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3967` | Self: 0.0% (1.7ms) | Total: 0.0% (1.7ms) | Samples: 1

**Called by:**
- `Fyd` (1)

### `entries`
`[native code]` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `expandLocalReferences` (1)

### `erCardinalityPieces`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:17` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `erCardinalityInk` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1009` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `write` (1)

### `finiteNumber`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `svgPathDataProblem` (1)

### `Pg`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `bLb` (1)

### `inlineResolvedColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

### `i6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `VWb` (1)

### `oKd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2213` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `ypd` (1)

### `erCardinalityInk`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `skipSeparators`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:168` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `finiteNumber` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:232` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `xsb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5521` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `gjb` (1)

### `vBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `fBb` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:668` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `groupValidation`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.6ms) | Total: 0.0% (1.6ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `match`
`[native code]` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `sourceEnvelopeMetadata` (1)

### `tagRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `tag` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:194` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `group` (1)

### `Srb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3494` | Self: 0.0% (1.5ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `_x` (2)

**Calls:**
- `Qrb` (1)

### `inspectSecurityTail`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:686` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `inspectOwnedSvgOnce` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/YAMLMap.js:147` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `preparedInterTextBounds`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `tCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `yCb` (1)

### `omitUndefinedObjectFields`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:990` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `omitUndefinedObjectFields` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `reserve` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:593` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `Qrb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3853` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `Srb` (1)

### `/[^\x20-\x7e]/u`
`[native code]` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `test` (1)

### `Fmb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3333` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `Kmb` (1)

### `Fk`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `yCb` (1)

### `D$b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `J$b` (1)

### `ohb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `XFd` (1)

### `boundedString`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:269` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `BWb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3113` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `N$b` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `map` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:13` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `iYb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2730` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `rYb` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1033` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `write` (1)

### `TUd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `Oce` (1)

### `pjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.5ms) | Total: 0.1% (3.9ms) | Samples: 1

**Called by:**
- `oWd` (1)
- `bsb` (1)
- `kWd` (1)

**Calls:**
- `ejb` (2)

### `rNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6111` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `vNc` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:598` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `group` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `erRelationshipBlock`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:20` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `Bwb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `xCb` (1)

### `$u`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `wIc` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `map` (1)

### `deepFreeze`
`/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `deepFreeze` (1)

### `osb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `De` (1)

### `CIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4866` | Self: 0.0% (1.4ms) | Total: 0.2% (8.1ms) | Samples: 1

**Called by:**
- `BIb` (5)
- `yIb` (1)

**Calls:**
- `IHb` (4)
- `WC` (1)

### `Rc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `JKb` (1)

### `g0d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `mWd` (1)

### `checkFamilyConfigColors`
`/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:501` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `text` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:40` | Self: 0.0% (1.4ms) | Total: 0.1% (4.7ms) | Samples: 1

**Called by:**
- `attribute` (1)
- `scanStartTags` (1)

**Calls:**
- `has` (1)

### `lyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4217` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `X8d` (1)

### `processChunkSync`
`node:zlib` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `zlibBufferSync` (1)

### `sourceEnvelopeMetadata`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:802` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `normalizeSource` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:333` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `connector` (1)

### `compareCodePointStrings`
`/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts:4` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `sort` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:854` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

### `collectPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `localPaintResourceReferences` (1)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `group` (1)

### `validateJsonConfigAdmission`
`/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `renderOptionsAdmissionMessages` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:126` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `eub`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `au` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:204` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `rD`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2794` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `Ycb` (1)

### `kNb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `qNb` (1)

### `SBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `gHb` (1)

### `assertFamilyGeometryOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `applyFamilyRequestNormalization` (1)

### `preventExtensions`
`[native code]` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `parseInlineFormatting`
`/tmp/pr449-main-integration-20261029-762/src/shared/inline-format.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `prepareDisplayText` (1)

### `formatSvgNumber`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:22` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `rWd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3492` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `L$d` (1)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:87` | Self: 0.0% (1.4ms) | Total: 0.0% (2.8ms) | Samples: 1

**Called by:**
- `ensureSvgIdentity` (2)

**Calls:**
- `test` (1)

### `xmlSlice`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `admitRenderOptionsInput`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `De`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4889` | Self: 0.0% (1.4ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `Qe` (2)

**Calls:**
- `osb` (1)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:702` | Self: 0.0% (1.4ms) | Total: 0.2% (10.7ms) | Samples: 1

**Called by:**
- `validateNode` (4)
- `node` (2)

**Calls:**
- `serializeSceneNode` (3)
- `serializeSceneNode` (1)
- `serializeSceneNode` (1)

### `createPngOutputOptionFieldDescriptors`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `VWb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `dHb` (1)

### `ownConnectorEndpoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `connector` (1)

### `nativeParseRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:132` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `i_d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `ryd` (1)

### `zKd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4783` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `BKd` (1)

### `MJb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4125` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `JJb` (1)

### `xCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3738` | Self: 0.0% (1.4ms) | Total: 0.1% (6.5ms) | Samples: 1

**Called by:**
- `SBb` (4)

**Calls:**
- `Bwb` (2)
- `Bwb` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:395` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `collectNativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:143` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `BIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `HKb` (1)

### `tYd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5390` | Self: 0.0% (1.4ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `Hyd` (1)
- `vYd` (1)

**Calls:**
- `pYd` (1)

### `HQb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `ctb` (1)

### `finishXmlLeaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:277` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `readDiff`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `parseEncodeTrie` (1)

### `N0d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4048` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `V0d` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:138` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `visitSvgFirstTagAttributes` (1)

### `KYb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4850` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `Q$b` (1)

### `ibd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `lbd` (1)

### `/\sdata-role="[^"]*"/`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `test` (1)

### `$Yd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `oWd` (1)

### `escapeXml`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `documentText` (1)

### `uyb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `vzb` (1)

### `completeBuiltinDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `GNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `ENc` (1)

### `parseFloat`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `renderEntityBox` (1)

### `append`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `ZTd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4478` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Fyd` (1)

### `serialize`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:633` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `Kz`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Mz` (1)

### `mermaidInitDirectives`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `extractInitDirectives` (1)

### `lbd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `kbd` (1)

### `vNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `BNc` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `markerTerminalDepth` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `finish` (1)

### `qwb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `dCb` (1)

### `ued`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `ijd` (1)

### `fVb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6002` | Self: 0.0% (1.3ms) | Total: 0.3% (13.5ms) | Samples: 1

**Called by:**
- `fVb` (8)
- `gVb` (2)

**Calls:**
- `fVb` (8)
- `Gl` (1)

### `require`
`[native code]` | Self: 0.0% (1.3ms) | Total: 14.1% (544.8ms) | Samples: 1

**Called by:**
- `bound require` (130)

**Calls:**
- `anonymous` (129)

### `bqc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `cvc` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `filter` (1)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `Xfc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `lgc` (1)

### `evaluateExtensionCompatibility`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:109` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `createExtensionIdentity` (1)

### `overlaps`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:56` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `readDiff`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:16` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `parseEncodeTrie` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:251` | Self: 0.0% (1.3ms) | Total: 0.1% (5.3ms) | Samples: 1

**Called by:**
- `writeTextSvg` (2)

**Calls:**
- `map` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:115` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `shape` (1)

### `Beb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `dCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Abd` (1)

### `Iac`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Hac` (1)

### `consumeStringBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:400` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `Dl`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `VNc` (1)

### `mEd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4780` | Self: 0.0% (1.3ms) | Total: 0.0% (2.9ms) | Samples: 1

**Called by:**
- `tEd` (1)
- `sqd` (1)

**Calls:**
- `HGd` (1)

### `pYd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5863` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `tYd` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `PHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `_Hb` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `extractErLayout` (1)

### `textBaseRatio`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `measureText` (1)

### `erCardinalityPieces`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:82` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `erCardinalityInk` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:49` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `gce`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `rJd` (1)

### `yc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3789` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Bc` (1)

### `Eoc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Krc` (1)

### `amb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `_Dc` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `finish` (1)

### `Reb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `xpd` (1)

### `primitiveCapabilityId`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:552` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `edd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4340` | Self: 0.0% (1.3ms) | Total: 0.4% (16.2ms) | Samples: 1

**Called by:**
- `UGd` (8)
- `gdd` (5)

**Calls:**
- `ijd` (4)
- `jdd` (2)
- `ijd` (2)
- `evc` (2)
- `evc` (1)
- `t9c` (1)

### `Hf`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `WBd` (1)

### `mQc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6283` | Self: 0.0% (1.3ms) | Total: 0.7% (28.9ms) | Samples: 1

**Called by:**
- `pOc` (17)

**Calls:**
- `lQc` (7)
- `kQc` (5)
- `oQc` (2)
- `UBb` (1)
- `qQc` (1)

### `renderRelationshipLine`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `cvc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `dvc` (1)

### `SEc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6337` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `TEc` (1)

### `bHd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `UHd` (1)

### `Yxb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5782` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `$xb` (1)

### `xeb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Eeb` (1)

### `canonicalJson`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1095` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `renderContractDigest` (1)

### `Mzd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Usd` (1)

### `fNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6404` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `vNc` (1)

### `recordPaintField`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:312` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `Xr`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `zNc` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `every` (1)

### `pageRectFor`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `render` (1)

### `R5b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1761` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Q5b` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:136` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `every` (1)

### `bBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `gCb` (1)

### `wsb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5362` | Self: 0.0% (1.3ms) | Total: 2.6% (100.4ms) | Samples: 1

**Called by:**
- `ejb` (15)

**Calls:**
- `SC` (12)
- `VC` (1)
- `asb` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:94` | Self: 0.0% (1.3ms) | Total: 0.7% (28.4ms) | Samples: 1

**Called by:**
- `inspectPaint` (15)

**Calls:**
- `leaf` (14)

### `Ueb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `tb` (1)

### `cjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `hzd` (1)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:660` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `hub`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `oub` (1)

### `Jgc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2728` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Ogc` (1)

### `Q$b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `I$b` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `sPc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4570` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `dPc` (1)

### `Qpb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Xpb` (1)

### `Ijb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3061` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `zyb` (1)

### `imul`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `consume` (1)

### `matchMermaidFrontmatter`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `mermaidFirstLine` (1)

### `inRanges`
`/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:114` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `isWideRange` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1747` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `vkb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `Vvb` (1)

### `negotiateCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `executionCapabilityDecision` (1)

### `issue`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:90` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:313` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `filter` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:501` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `padStart`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `scopeHash` (1)

### `t9c`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `edd` (1)

### `sourceIndexOf`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:484` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `map` (1)

### `tipAnchoredArrow`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:29` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `arrowMarkerResources` (1)

### `SGb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `NGb` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` | Self: 0.0% (1.2ms) | Total: 0.7% (29.5ms) | Samples: 1

**Called by:**
- `geometryAttributes` (2)
- `identityAttributes` (1)
- `geometryAttributes` (1)
- `paintAttribute` (1)
- `geometryAttributes` (1)
- `typographyAttributes` (1)

**Calls:**
- `formatSvgNumericAttribute` (2)
- `formatSvgNumber` (1)
- `formatSvgNumericAttribute` (1)
- `formatSvgNumericAttribute` (1)
- `formatSvgNumber` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `cyc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `_xc` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:286` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `Vwd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Uwd` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:170` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `inspectOwnedSvgOnce` (1)

### `vmb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Uvb` (1)

### `Rlb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `F7b` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:310` | Self: 0.0% (1.2ms) | Total: 0.1% (5.0ms) | Samples: 1

**Called by:**
- `map` (3)

**Calls:**
- `slice` (1)
- `(anonymous)` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:137` | Self: 0.0% (1.2ms) | Total: 4.7% (183.4ms) | Samples: 1

**Called by:**
- `withDeferredTerminalProjections` (72)

**Calls:**
- `renderCardinality` (36)
- `renderCardinality` (35)

### `primitiveCapabilityClaimKey`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validatePrimitiveCapabilities` (1)

### `arrayFromFastWithoutMapFn`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `from` (1)

### `SYd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `RYd` (1)

### `intersects`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1217` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `finishErGeometry` (1)

### `erRelationshipStyle`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:15` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `erRelationshipBlock` (1)

### `mzd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4037` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `JEd` (1)

### `Ckd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Bkd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `snapshotDescriptorArray`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1488` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `snapshotScenePrimitiveCell` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `markerBoundsAt` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `connector` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:517` | Self: 0.0% (1.2ms) | Total: 0.1% (4.4ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (3)

**Calls:**
- `paintAttribute` (2)

### `Esb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Ajb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1917` | Self: 0.0% (1.2ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `map` (1)
- `find` (1)

**Calls:**
- `find` (1)

### `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `boundedString` (1)

### `stripTrailingComment`
`/tmp/pr449-main-integration-20261029-762/src/shared/trailing-comment.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `findErStatements` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:129` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `projectSvgCss` (1)

### `_B`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `xAd` (1)

### `yCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.2ms) | Total: 0.3% (15.3ms) | Samples: 1

**Called by:**
- `dwb` (7)
- `OCb` (2)
- `CCb` (1)

**Calls:**
- `tCb` (4)
- `nCb` (2)
- `Fk` (1)
- `Fk` (1)
- `tCb` (1)

### `lNb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `RFc` (1)

### `limitJsonConfigDiagnostics`
`/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts:325` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `registerBuiltInStyle` (1)

### `outputDescriptorsById`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `Wcd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `ijd` (1)

### `wgd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `gjd` (1)

### `prepareWrittenCompoundShape`
`/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:61` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `connectorTerminalStrokeLosses`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `deriveConnectorTerminalProjection` (1)

### `ddd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6264` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `OBd` (1)

### `connectorEndpointAnchors`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateConnectorProjectionConsistency` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts:32` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

### `trim`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `safeCssToken` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateMarker` (1)

### `a4d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4534` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Gyd` (1)

### `gJb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Qxb` (1)

### `BGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `MGc` (1)

### `PJb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4763` | Self: 0.0% (1.2ms) | Total: 0.0% (3.7ms) | Samples: 1

**Called by:**
- `crb` (3)

**Calls:**
- `JJb` (1)
- `JJb` (1)

### `oEd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Krc` (1)

### `ensureEntity`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `ensureStyledEntity` (1)

### `ytb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2613` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `itb` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:51` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `hasInheritedPaint` (1)

### `hooks`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:507` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `iUd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `hxd` (1)

### `Fzd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5681` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `$Bd` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:638` | Self: 0.0% (1.2ms) | Total: 4.0% (157.6ms) | Samples: 1

**Called by:**
- `leaf` (54)

**Calls:**
- `copyInner` (44)
- `copyInner` (2)
- `copy` (2)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)

### `vMd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `aMd` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts:1436` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

### `writeFast`
`internal:fs/streams` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `i0b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `k0b` (1)

### `open`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `write` (1)

### `init`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Zlib` (1)

### `erCharge`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:204` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `chargeInkSort` (1)

### `validateMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `ulb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1440` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `XGb` (1)

### `Wc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1595` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Yh` (1)

### `Wd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `bjb` (1)

### `yfd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5328` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `oHb` (1)

### `vWb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `$Dc` (1)

### `unionSceneBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:28` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `connectorPaintBounds` (1)

### `BGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `zpd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `rendered` (1)

### `xmlHasColon`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:85` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `rGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `RTd` (1)

### `Lcd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Ncd` (1)

### `hjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2804` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `Yrb` (1)

### `B4d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `YLd` (1)

### `b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3192` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `pdb` (1)

### `_Pb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `pPb` (1)

### `Jjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `q6b` (1)

### `mdb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `canonicalTextDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1171` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `Yjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `CYb` (1)

### `dereferenceSchema`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `schemaMatchesRuntimeKind` (1)

### `RFd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5055` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `aXd` (1)

### `tree`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:71` | Self: 0.0% (1.1ms) | Total: 0.0% (3.4ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (2)

**Calls:**
- `build` (1)

### `connectorContourSemantics`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `connector` (1)

### `u6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `o6b` (1)

### `SLd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4644` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `Qud` (1)

### `performIteration`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.1% (6.4ms) | Samples: 1

**Called by:**
- `validateDescriptor` (2)
- `descriptorOwnsDetectionLine` (1)
- `nonPainting` (1)

**Calls:**
- `next` (3)

### `XDc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `_Dc` (1)

### `i7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `wCb` (1)

### `tb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4108` | Self: 0.0% (1.1ms) | Total: 0.1% (6.4ms) | Samples: 1

**Called by:**
- `asb` (2)
- `hMd` (2)
- `aMd` (1)

**Calls:**
- `vEd` (2)
- `Ueb` (1)
- `ped` (1)

### `OC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `RC` (1)

### `tEd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.1ms) | Total: 0.0% (2.5ms) | Samples: 1

**Called by:**
- `Pud` (1)
- `lNb` (1)

**Calls:**
- `mEd` (1)

### `Drb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `Old` (1)

### `Oce`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3806` | Self: 0.0% (1.1ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `qVd` (1)
- `h4d` (1)

**Calls:**
- `TUd` (1)

### `canonicalTextDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1172` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `PUd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `r1d` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `filter` (1)

### `connectorGeometryHasCurves`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:370` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `connector` (1)

### `Iwd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `_wd` (1)

### `EGb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `$lb` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:32` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `scopeSvgStyles` (1)

### `isAsciiXmlNameChar`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `sourceSlice` (1)

### `gVb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `lQb` (1)

### `qZb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3229` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `HXb` (1)

### `fromEntries`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `freezeDescriptor` (1)

### `ped`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `tb` (1)

### `qc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `pc` (1)

### `Pcb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4170` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `Pvb` (1)

### `Gzip`
`node:zlib:326` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `gzipSync` (1)

### `UHd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `CZd` (1)

### `cloneObject`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `$qb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3001` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `CYb` (1)

### `legibleInk`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:137` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `toneOnFill` (1)

### `Afd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `oHb` (1)

### `Krc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `E$b` (1)

### `collides`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `placeRelationshipLabels` (1)

### `X8d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `Z8d` (1)

### `lub`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `Wtb` (1)

### `POc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `QOc` (1)

### `IDb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `Gtb` (1)

### `sZb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `HXb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:273` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:315` | Self: 0.0% (1.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `measureErEntities` (1)
- `measureErEntities` (1)

**Calls:**
- `performanceExperimentEnabled` (1)

### `VJb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5879` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `gHb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/generated-identity.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:652` | Self: 0.0% (1.1ms) | Total: 0.6% (24.2ms) | Samples: 1

**Called by:**
- `erCardinalityInk` (9)
- `leaf` (2)
- `(anonymous)` (1)

**Calls:**
- `paintedStrokeExtent` (10)
- `paintedStrokeExtent` (1)

### `ubd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `acd` (1)

### `qlb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3495` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `D7b` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `reduce` (1)

### `Xb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `Zb` (1)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `ensureSvgIdentity` (1)

### `evc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `edd` (1)

### `createConvenienceMethod`
`node:zlib` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `node:zlib` (1)

### `b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `pdb` (1)

### `isRetainedPixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `JJb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `PJb` (1)

### `Kwd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `BBd` (1)

### `yNd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3045` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `uNd` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:519` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `Te`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `dFd` (1)

### `layoutElkGraph`
`/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `measureRenderStage` (1)

### `uYb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `iac` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:706` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `inspectOwnedSvgOnce` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/block/tokens.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `snapshotCapabilityCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1556` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `snapshotDescriptorArray` (1)

### `createErCreationFold`
`/tmp/pr449-main-integration-20261029-762/src/er/creation.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `readErStatements` (1)

### `fHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `E$b` (1)

### `parseErEntityReference`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `parseErRelationshipSyntax` (1)

### `fzd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `hzd` (1)

### `inspectSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:674` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `inspectOwnedSvgOnce` (1)

### `isForbiddenJsonConfigKey`
`/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `omitUndefinedObjectFields` (1)

### `dmb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3792` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `gGb` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:169` | Self: 0.0% (1.0ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `paintedStrokeExtent` (2)

**Calls:**
- `slice` (1)

### `KFc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `wGc` (1)

### `UJc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6160` | Self: 0.0% (1.0ms) | Total: 0.1% (4.9ms) | Samples: 1

**Called by:**
- `KFc` (4)

**Calls:**
- `iHc` (2)
- `Emb` (1)

### `Emb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `UJc` (1)

### `o8b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `A6b` (1)

### `hmb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4752` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `UXb` (1)

### `CBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3403` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `ROc` (1)

### `UXd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `TFd` (1)

### `gyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `V8d` (1)

### `contains`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `lld`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `gjd` (1)

### `descriptorOwnsDetectionLine`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2072` | Self: 0.0% (1.0ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `detectorClaims` (2)

**Calls:**
- `performIteration` (1)

### `WXd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `rJd` (1)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:212` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validateGeometry` (1)

### `FYb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `AEc` (1)

### `resolveRenderStyle`
`/tmp/pr449-main-integration-20261029-762/src/styles.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `layoutErDiagram` (1)

### `Jcd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6064` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `Lcd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` | Self: 0.0% (1.0ms) | Total: 0.5% (19.7ms) | Samples: 1

**Called by:**
- `map` (16)

**Calls:**
- `cloneValue` (11)
- `map` (4)

### `sse`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2293` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `JBd` (1)

### `vgb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4328` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `vEd` (1)

### `Dd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1384` | Self: 0.0% (1.0ms) | Total: 0.1% (4.0ms) | Samples: 1

**Called by:**
- `kd` (2)

**Calls:**
- `yd` (1)

### `CYb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `OIc` (1)

### `transferNativeGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `snapshot` (1)

### `Ogd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `Qgd` (1)

### `separateErCompounds`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `extractErLayout` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1356` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `runMeasuredGraphBackend` (1)

### `r_b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `p_b` (1)

### `performanceExperimentEnabled`
`/tmp/pr449-main-integration-20261029-762/src/experimental-performance.ts:12` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:193` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `J$b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `NQb` (1)

### `Qr`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `Nr` (1)

### `eOc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `DQb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `cGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.0ms) | Total: 0.1% (6.2ms) | Samples: 1

**Called by:**
- `$Ed` (4)

**Calls:**
- `LFd` (3)

### `receiptOf`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:711` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `xmlScalarCharacter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:88` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `readXmlDataEnd` (1)

### `Pud`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `xpd` (1)

### `Fr`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:955` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `Er` (1)

### `hasInheritedSvgTextPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `observe` (1)

### `hYb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `oYb` (1)

### `xxd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `Vxd` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/ascii/shapes/index.ts:36` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

### `EJd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `iFd` (1)

### `Cjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4145` | Self: 0.0% (1.0ms) | Total: 0.0% (2.3ms) | Samples: 1

**Called by:**
- `wjb` (2)

**Calls:**
- `zjb` (1)

### `graphicalSvgArtifact`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `withSvgInspectionCache` (1)

### `W7d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `jGd` (1)

### `XD`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `M$b` (1)

### `resolveRoleStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `buildErElkGraph` (1)

### `_bd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2231` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `Xbd` (1)

### `expectedCapabilityState`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1641` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `validateDescriptor` (1)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:643` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `gAd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `Txd` (1)

### `writeSync`
`[native code]` | Self: 0.0% (999us) | Total: 0.0% (999us) | Samples: 1

**Called by:**
- `processChunkSync` (1)

### `IGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5714` | Self: 0.0% (997us) | Total: 0.4% (17.6ms) | Samples: 1

**Called by:**
- `yGc` (6)
- `AGc` (5)

**Calls:**
- `zgc` (4)
- `IEc` (3)
- `gFc` (2)
- `VFc` (1)

### `snapshotBoundedExternalData`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` | Self: 0.0% (984us) | Total: 0.0% (984us) | Samples: 1

**Called by:**
- `admitSceneDocumentWith` (1)

### `calculatePathMidpoint`
`/tmp/pr449-main-integration-20261029-762/src/layout/geometry.ts:107` | Self: 0.0% (0us) | Total: 0.1% (4.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `pointAtPathDistance` (1)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:95` | Self: 0.0% (0us) | Total: 1.4% (56.6ms) | Samples: 0

**Called by:**
- `materializeText` (15)
- `copyInner` (7)

**Calls:**
- `materializeText` (15)
- `materializeText` (4)
- `materializeText` (1)
- `materializeText` (1)
- `materializeText` (1)

### `nQb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6180` | Self: 0.0% (0us) | Total: 7.0% (273.1ms) | Samples: 0

**Called by:**
- `lQb` (141)

**Calls:**
- `g6b` (52)
- `MGc` (26)
- `sOc` (17)
- `BNc` (10)
- `cEc` (9)
- `H7b` (6)
- `k4b` (4)
- `a7b` (4)
- `C6b` (4)
- `t6b` (3)
- `Kac` (2)
- `Z7b` (1)
- `pac` (1)
- `n0b` (1)
- `Nac` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:279` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `(anonymous)` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:221` | Self: 0.0% (0us) | Total: 0.4% (17.7ms) | Samples: 0

**Called by:**
- `visit` (2)
- `visit` (2)
- `admitSceneDocumentWith` (2)

**Calls:**
- `visit` (4)
- `visit` (2)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1534` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/createNode.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `H7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.3% (12.3ms) | Samples: 0

**Called by:**
- `nQb` (6)

**Calls:**
- `A7b` (6)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:4` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `Cyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3389` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `fzd` (2)
- `X8d` (1)

**Calls:**
- `Dyd` (3)

### `opaque`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:143` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `opaqueOutlineWidth` (1)

**Calls:**
- `(anonymous)` (1)

### `tag`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:152` | Self: 0.0% (0us) | Total: 0.2% (9.1ms) | Samples: 0

**Called by:**
- `scanStartTags` (3)

**Calls:**
- `defineProperty` (3)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:4` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Calls:**
- `tipAnchoredArrow` (1)

### `mmd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6379` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `gjd` (1)

**Calls:**
- `Drb` (1)

### `canonicalJson`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1091` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `canonicalJson` (1)

**Calls:**
- `map` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:275` | Self: 0.0% (0us) | Total: 0.2% (8.1ms) | Samples: 0

**Called by:**
- `writeTextSvg` (4)

**Calls:**
- `renderPreparedLine` (2)
- `renderPreparedLine` (1)
- `renderDisplayRuns` (1)

### `internal:streams/compose`
`internal:streams/compose:2` | Self: 0.0% (0us) | Total: 1.2% (49.3ms) | Samples: 0

**Called by:**
- `anonymous` (20)

**Calls:**
- `anonymous` (20)

### `oYb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1335` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `sYb` (1)

**Calls:**
- `hYb` (1)

### `HKb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6196` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `gHb` (6)

**Calls:**
- `BIb` (5)
- `BIb` (1)

### `uNd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Ld` (1)

**Calls:**
- `yNd` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:515` | Self: 0.0% (0us) | Total: 0.2% (7.8ms) | Samples: 0

**Called by:**
- `writeTextSvg` (3)

**Calls:**
- `paintAttribute` (3)

### `Bc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `o8b` (1)

**Calls:**
- `yc` (1)

### `renderOptionsAdmissionMessages`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:403` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `validateJsonConfigAdmission` (1)

### `qNb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `jNb` (1)

**Calls:**
- `kNb` (1)

### `k4b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `nQb` (4)

**Calls:**
- `i4b` (4)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:182` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `possibleShapeStroke` (1)

### `aIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `BIb` (1)

**Calls:**
- `THb` (1)

### `measureErEntities`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:451` | Self: 0.0% (0us) | Total: 0.2% (9.0ms) | Samples: 0

**Called by:**
- `layoutErDiagram` (7)

**Calls:**
- `preparePixelText` (3)
- `preparePixelText` (2)
- `preparePixelText` (1)
- `preparePixelText` (1)

### `detectorClaims`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1596` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `find` (4)

**Calls:**
- `descriptorOwnsDetectionLine` (2)
- `some` (2)

### `$Hb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `JHb` (1)

**Calls:**
- `RHb` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1776` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `Set` (1)

### `createWrittenPolyline`
`/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:33` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `geometryAttributes` (1)

**Calls:**
- `freeze` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1569` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `(anonymous)` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1037` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `hasOwn` (1)

### `ate`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1932` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `VAd` (3)

**Calls:**
- `ete` (3)

### `fBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5408` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `VBd` (1)

**Calls:**
- `YEd` (1)

### `expandLocalReferences`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` | Self: 0.0% (0us) | Total: 0.4% (17.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (8)
- `(module)` (2)
- `map` (1)

**Calls:**
- `map` (11)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:641` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `createWrittenPolyline` (1)

### `pc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1451` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Jl` (1)

**Calls:**
- `qc` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:796` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `node` (1)

**Calls:**
- `hasOwn` (1)

### `IUd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `Rsd` (1)

**Calls:**
- `Gsd` (1)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:477` | Self: 0.0% (0us) | Total: 0.1% (6.8ms) | Samples: 0

**Called by:**
- `diagramColorVariables` (1)

**Calls:**
- `estimatedResidency` (1)

### `Cyb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4092` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `Byb` (1)

**Calls:**
- `Qjb` (1)

### `UXb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3335` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `DWb` (1)

**Calls:**
- `hmb` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1472` | Self: 0.0% (0us) | Total: 3.6% (139.1ms) | Samples: 0

**Called by:**
- `serialize` (40)

**Calls:**
- `serializeSceneNode` (40)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:173` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `projectSvgCss` (1)

**Calls:**
- `sourceIndexOf` (1)

### `r0d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Rsd` (1)

**Calls:**
- `Gsd` (1)

### `jXd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `YEd` (4)

**Calls:**
- `aXd` (4)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/agent/families.ts:8` | Self: 0.0% (0us) | Total: 0.8% (31.6ms) | Samples: 0

**Calls:**
- `installBuiltinFamily` (12)
- `installBuiltinFamily` (10)
- `installBuiltinFamily` (2)

### `pointAtPathDistance`
`/tmp/pr449-main-integration-20261029-762/src/layout/geometry.ts:76` | Self: 0.0% (0us) | Total: 0.1% (4.2ms) | Samples: 0

**Called by:**
- `calculatePathMidpoint` (1)

**Calls:**
- `polylineLength` (1)

### `Z8d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5453` | Self: 0.0% (0us) | Total: 0.6% (25.3ms) | Samples: 0

**Called by:**
- `jRd` (19)

**Calls:**
- `X8d` (13)
- `W8d` (5)
- `X8d` (1)

### `dXd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4831` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `cYd` (1)

**Calls:**
- `TFd` (1)

### `Geb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3196` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `Meb` (1)

**Calls:**
- `Keb` (1)

### `contrastRatio`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:84` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `ensureContrast` (1)

**Calls:**
- `relativeLuminance` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:144` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `renderCardinality` (1)

**Calls:**
- `copyDataProperties` (1)

### `uZd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `jGd` (1)

**Calls:**
- `SC` (1)

### `ZJb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4924` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `gHb` (1)

**Calls:**
- `YJb` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:123` | Self: 0.0% (0us) | Total: 9.7% (375.1ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (69)

**Calls:**
- `leaf` (50)
- `connector` (9)
- `renderRelationshipLine` (6)
- `renderRelationshipLine` (2)
- `renderRelationshipLine` (1)
- `renderRelationshipLine` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:548` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `gjd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6493` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `hjd` (4)

**Calls:**
- `Bkd` (1)
- `mmd` (1)
- `lld` (1)
- `wgd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:13` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `get WriteStream`
`node:fs:667` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `anonymous` (2)

### `qjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `oWd` (1)

**Calls:**
- `gjb` (1)

### `evc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `edd` (2)

**Calls:**
- `_xc` (1)
- `Crb` (1)

### `detectInstalledFamilyDescriptorFromFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts:60` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `classifyMermaidFamilyDescriptorFromFirstLine` (2)

**Calls:**
- `detectRegisteredFamilyDescriptorFromFirstLine` (2)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:185` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `map` (1)

### `seb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2298` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `FVd` (3)

**Calls:**
- `Ieb` (3)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:702` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (2)

**Calls:**
- `sourceEnvelopeMetadata` (1)
- `sourceEnvelopeMetadata` (1)

### `value`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:125` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `nativeGroup` (1)

**Calls:**
- `defineProperty` (1)

### `Wlb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2046` | Self: 0.0% (0us) | Total: 0.1% (6.7ms) | Samples: 0

**Called by:**
- `imb` (3)
- `jmb` (1)

**Calls:**
- `SC` (4)

### `transformSvgCssValues`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:308` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `resolveSvgColors` (3)

**Calls:**
- `map` (3)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:382` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `xmlHasColon` (1)

### `Wxd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4079` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `Dyd` (1)

**Calls:**
- `zsd` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:825` | Self: 0.0% (0us) | Total: 0.5% (19.8ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (3)

**Calls:**
- `identityAttributes` (1)
- `identityAttributes` (1)
- `identityAttributes` (1)

### `gyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5621` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `V8d` (1)
- `U8d` (1)

**Calls:**
- `hMd` (2)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:171` | Self: 0.0% (0us) | Total: 0.1% (5.8ms) | Samples: 0

**Called by:**
- `paintedStrokeExtent` (3)

**Calls:**
- `map` (2)
- `join` (1)

### `x2d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `hxd` (1)

**Calls:**
- `hxd` (1)

### `node:events`
`node:events:657` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `assign` (1)

### `lineStrokeBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:535` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `strokedBox` (1)

**Calls:**
- `geometryBounds` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:284` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `forEach` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:253` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `advance` (1)

### `connectorContourSemantics`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:383` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateConnectorProjectionConsistency` (1)

**Calls:**
- `at` (1)

### `renderDisplayRuns`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:152` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `renderMultilineText` (1)

**Calls:**
- `every` (1)

### `readErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:749` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `parseErDiagram` (1)

**Calls:**
- `createErCreationFold` (1)

### `ROc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6109` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `QOc` (1)

**Calls:**
- `CBb` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:115` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `withPerformanceObserver`
`/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts:42` | Self: 0.0% (0us) | Total: 71.3% (2.74s) | Samples: 0

**Called by:**
- `(module)` (1062)

**Calls:**
- `withRenderStageObserver` (1062)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:126` | Self: 0.0% (0us) | Total: 0.1% (7.6ms) | Samples: 0

**Called by:**
- `renderEntityBox` (1)
- `renderEntityBox` (1)
- `renderRelationshipLabel` (1)

**Calls:**
- `text` (2)
- `text` (1)

### `deferredRenderContractDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1127` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `deferredRequestReceiptDigest` (1)

**Calls:**
- `admitRenderContractDigestInput` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` | Self: 0.0% (0us) | Total: 0.3% (12.4ms) | Samples: 0

**Called by:**
- `leaf` (5)

**Calls:**
- `nonPainting` (2)
- `nonPainting` (1)
- `every` (1)
- `nonPainting` (1)

### `RTd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `hMd` (1)

**Calls:**
- `rGd` (1)

### `canonicalJson`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1097` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `map` (1)
- `canonicalJson` (1)
- `(anonymous)` (1)

**Calls:**
- `stringify` (1)
- `canonicalJson` (1)
- `canonicalJson` (1)

### `Pud`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5568` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `M$b` (2)
- `yrd` (1)

**Calls:**
- `aMd` (2)
- `tEd` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:158` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `scanStartTags` (2)

**Calls:**
- `attributeRecord` (2)

### `fdd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5881` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `gdd` (1)

**Calls:**
- `JGd` (1)

### `qPb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:876` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `UGd` (1)

**Calls:**
- `pPb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:15` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `xc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4047` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Ac` (1)

**Calls:**
- `zc` (1)

### `RHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5003` | Self: 0.0% (0us) | Total: 0.1% (4.3ms) | Samples: 0

**Called by:**
- `$Hb` (1)
- `_Hb` (1)

**Calls:**
- `WC` (1)
- `UHb` (1)

### `Efb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3553` | Self: 0.0% (0us) | Total: 4.7% (184.4ms) | Samples: 0

**Called by:**
- `bCd` (75)

**Calls:**
- `TCd` (75)

### `LWb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `bJb` (1)

**Calls:**
- `lNb` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts:87` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `Set` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:311` | Self: 0.0% (0us) | Total: 0.2% (8.1ms) | Samples: 0

**Called by:**
- `extractErLayout` (2)

**Calls:**
- `some` (2)

### `uyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3893` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `W8d` (2)

**Calls:**
- `YEd` (2)

### `vEd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `tb` (2)

**Calls:**
- `vgb` (1)
- `vgb` (1)

### `rolePropertyJsonSchemas`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:484` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `roleStyleJsonSchema` (1)

**Calls:**
- `map` (1)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:30` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `attribute` (1)

**Calls:**
- `test` (1)

### `kQc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5354` | Self: 0.0% (0us) | Total: 0.2% (8.0ms) | Samples: 0

**Called by:**
- `mQc` (5)

**Calls:**
- `dPc` (3)
- `vsb` (1)
- `Ac` (1)

### `documentOpen`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:135` | Self: 0.0% (0us) | Total: 0.1% (7.6ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (2)

**Calls:**
- `attachSceneNodeSerialization` (2)

### `zbd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4621` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `xbd` (1)

**Calls:**
- `S5b` (1)

### `k7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `NCb` (1)

**Calls:**
- `Z6b` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:7` | Self: 0.0% (0us) | Total: 0.1% (5.5ms) | Samples: 0

**Calls:**
- `importModule` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:390` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `xmlParserList` (1)

### `xpd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5945` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `lbd` (2)

**Calls:**
- `Reb` (1)
- `Pud` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:205` | Self: 0.0% (0us) | Total: 24.3% (937.9ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (293)

**Calls:**
- `withDeferredTerminalProjections` (292)
- `withDeferredTerminalProjections` (1)

### `measureRenderStage`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:30` | Self: 0.0% (0us) | Total: 93.4% (3.59s) | Samples: 0

**Called by:**
- `renderResolvedMermaidSVG` (559)
- `elkPlacement` (486)
- `renderPositionedWithTextMeasurement` (404)
- `renderPositionedWithTextMeasurement` (41)
- `executeInspectedGraphicalRequest` (23)
- `renderPositionedWithTextMeasurement` (20)

**Calls:**
- `positionFamilyForNativeRender` (559)
- `retainedNativeDrawing` (345)
- `layoutElkGraph` (333)
- `layoutElkGraph` (152)
- `retainedNativeDrawing` (59)
- `positionedPaintCertification` (41)
- `applyOutputSecurityPolicy` (20)
- `resolveRenderRequestForExecution` (6)
- `resolveRenderRequestForExecution` (5)
- `resolveRenderRequestForExecution` (4)
- `resolveRenderRequestForExecution` (4)
- `resolveRenderRequestForExecution` (1)
- `resolveRenderRequestForExecution` (1)
- `resolveRenderRequestForExecution` (1)
- `resolveRenderRequestForExecution` (1)
- `layoutElkGraph` (1)

### `NCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1767` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `SCb` (1)

**Calls:**
- `k7b` (1)

### `UWd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.4% (17.2ms) | Samples: 0

**Called by:**
- `YEd` (11)

**Calls:**
- `rJd` (11)

### `JFd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `NFd` (1)

**Calls:**
- `iFd` (1)

### `sort`
`[native code]` | Self: 0.0% (0us) | Total: 0.2% (8.8ms) | Samples: 0

**Called by:**
- `detectRegisteredFamilyDescriptorFromFirstLine` (1)
- `build` (1)
- `canonicalOpeningTag` (1)

**Calls:**
- `compareCodePointStrings` (1)
- `compare` (1)
- `(anonymous)` (1)

### `renderRelationshipLine`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:471` | Self: 0.0% (0us) | Total: 0.4% (17.4ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (6)

**Calls:**
- `sanitizeDisplayLines` (5)
- `sanitizeDisplayLines` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:17` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `freezeBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:403` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `registerBuiltInBackend` (1)

**Calls:**
- `snapshotBackendCapabilities` (1)

### `render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:394` | Self: 0.0% (0us) | Total: 1.8% (70.4ms) | Samples: 0

**Called by:**
- `rendered` (33)

**Calls:**
- `admitSceneDocumentWith` (30)
- `admitSceneDocumentWith` (3)

### `Vcb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4548` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `xo` (1)

**Calls:**
- `oD` (1)

### `Jz`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2343` | Self: 0.0% (0us) | Total: 0.3% (12.7ms) | Samples: 0

**Called by:**
- `Mz` (10)

**Calls:**
- `g` (10)

### `Q$b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6346` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `I$b` (2)

**Calls:**
- `KYb` (1)
- `lNb` (1)

### `_mb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4572` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `cnb` (1)

**Calls:**
- `PEc` (1)

### `Ltd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (9.3ms) | Samples: 0

**Called by:**
- `r1d` (5)

**Calls:**
- `Usd` (5)

### `Nac`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (7.1ms) | Samples: 0

**Called by:**
- `nQb` (1)

**Calls:**
- `Lac` (1)

### `$Ed`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2886` | Self: 0.0% (0us) | Total: 2.9% (115.2ms) | Samples: 0

**Called by:**
- `kWd` (16)
- `nWd` (3)
- `oWd` (2)
- `pWd` (2)
- `mWd` (1)

**Calls:**
- `dFd` (20)
- `cGd` (4)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:183` | Self: 0.0% (0us) | Total: 30.6% (1.18s) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (404)

**Calls:**
- `measureRenderStage` (404)

### `Qkb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `Qc` (1)

**Calls:**
- `nyb` (1)

### `XFd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4383` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `pWd` (1)

**Calls:**
- `ohb` (1)

### `TKb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6412` | Self: 0.0% (0us) | Total: 0.2% (8.9ms) | Samples: 0

**Called by:**
- `PKb` (1)

**Calls:**
- `rg` (1)

### `nonPainting`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:130` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `textPaints` (1)

### `node:fs`
`node:fs:8` | Self: 0.0% (0us) | Total: 1.1% (44.4ms) | Samples: 0

**Calls:**
- `anonymous` (4)

### `ensureContrast`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:102` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `toneOnFill` (1)

**Calls:**
- `contrastRatio` (1)

### `dte`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4303` | Self: 0.0% (0us) | Total: 1.5% (60.0ms) | Samples: 0

**Called by:**
- `SGd` (30)

**Calls:**
- `vGd` (24)
- `lDd` (5)
- `jDd` (1)

### `dvc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:900` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `UGd` (2)

**Calls:**
- `cvc` (1)
- `cvc` (1)

### `Ogc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5852` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `ngc` (1)

**Calls:**
- `Jgc` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:55` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `zyb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2250` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `jlb` (1)

**Calls:**
- `Ijb` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:199` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `renderCardinality` (1)

**Calls:**
- `freeze` (1)

### `zlibBufferSync`
`node:zlib:94` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `processChunkSync` (1)
- `processChunkSync` (1)

### `QC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2691` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `lgc` (2)
- `YHb` (1)

**Calls:**
- `RC` (3)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:173` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `paintedStrokeExtent` (2)

**Calls:**
- `parseInt` (2)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:434` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `consumePointBudget` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:739` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `ActualTextPaintWrite` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:8` | Self: 0.0% (0us) | Total: 0.1% (5.3ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `bound require` (4)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:171` | Self: 0.0% (0us) | Total: 0.3% (14.0ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (3)
- `renderCardinality` (3)
- `renderCardinality` (1)

**Calls:**
- `group` (7)

### `CYd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `ILd` (2)

**Calls:**
- `AKd` (2)

### `forEach`
`[native code]` | Self: 0.0% (0us) | Total: 0.5% (21.2ms) | Samples: 0

**Called by:**
- `ensureElk` (11)
- `validateNode` (1)
- `leaf` (1)

**Calls:**
- `(anonymous)` (11)
- `validatePaint` (1)
- `(anonymous)` (1)

### `assertAdmissibleSceneDoc`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation.ts:247` | Self: 0.0% (0us) | Total: 1.6% (63.7ms) | Samples: 0

**Called by:**
- `admitSceneDocumentWith` (30)

**Calls:**
- `validateSceneDocument` (23)
- `validateSceneDocument` (6)
- `validateSceneDocument` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:8` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `validateConnectorProjectionConsistency`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1303` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `connectorEndpointAnchors` (1)

### `kFd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.4% (16.9ms) | Samples: 0

**Called by:**
- `hMd` (6)
- `WLd` (1)

**Calls:**
- `YEd` (7)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:31` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `map` (1)

### `internal:stream`
`internal:stream:46` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `usb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3557` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `vsb` (1)

**Calls:**
- `SC` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/ishikawa/renderer.ts:63` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Calls:**
- `sceneLowering` (1)

### `positionedPaintCertification`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:154` | Self: 0.0% (0us) | Total: 3.0% (115.6ms) | Samples: 0

**Called by:**
- `measureRenderStage` (41)

**Calls:**
- `certifyNativePaint` (25)
- `certifyNativePaint` (6)
- `certifyNativePaint` (3)
- `certifyNativePaint` (2)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:191` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `styleSpecJsonSchema` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:172` | Self: 0.0% (0us) | Total: 0.2% (11.4ms) | Samples: 0

**Called by:**
- `visit` (4)

**Calls:**
- `visit` (2)
- `visit` (1)
- `visit` (1)

### `Xr`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3590` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `dPc` (1)
- `N6b` (1)

**Calls:**
- `Wr` (1)
- `IZb` (1)

### `validateChannels`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:581` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `boundedString` (1)

### `R6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5592` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `U6b` (3)

**Calls:**
- `VBb` (2)
- `SBb` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:561` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:487` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `paintAttribute` (2)

**Calls:**
- `recordPaintField` (1)
- `recordPaintField` (1)

### `p$d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2291` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `x$d` (3)

**Calls:**
- `XEd` (3)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:273` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `markerTerminalDepth` (1)

**Calls:**
- `map` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:619` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `validateNode` (2)

**Calls:**
- `validatePaint` (1)
- `validatePaint` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:589` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `hasOwn` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:418` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `readErStatement`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:298` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `readErOuterStatements` (1)

**Calls:**
- `parseErRelationshipSyntax` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1860` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (3)

**Calls:**
- `find` (3)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:761` | Self: 0.0% (0us) | Total: 0.1% (7.1ms) | Samples: 0

**Called by:**
- `write` (2)

**Calls:**
- `get` (2)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1592` | Self: 0.0% (0us) | Total: 0.2% (8.0ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (3)

**Calls:**
- `tree` (2)
- `tree` (1)

### `Hac`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5551` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `Kac` (2)

**Calls:**
- `Iac` (1)
- `JD` (1)

### `ete`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3854` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `ate` (3)

**Calls:**
- `mDd` (3)

### `kIc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5236` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Called by:**
- `jIc` (3)

**Calls:**
- `CIc` (3)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:3` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/block/markers.ts:10` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (2)

### `layoutElkGraph`
`/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts:148` | Self: 0.0% (0us) | Total: 5.5% (212.2ms) | Samples: 0

**Called by:**
- `measureRenderStage` (152)

**Calls:**
- `ensureElk` (141)
- `ensureElk` (11)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:39` | Self: 0.0% (0us) | Total: 2.1% (84.5ms) | Samples: 0

**Called by:**
- `captureNativeGroupParse` (17)
- `group` (10)

**Calls:**
- `(anonymous)` (16)
- `visitSvgFirstTagAttributes` (9)
- `test` (1)
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6513` | Self: 0.0% (0us) | Total: 5.1% (197.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (70)
- `o` (70)

**Calls:**
- `(anonymous)` (70)
- `(anonymous)` (48)
- `(anonymous)` (11)
- `(anonymous)` (10)
- `(anonymous)` (1)

### `FVd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5449` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `Dyd` (3)

**Calls:**
- `seb` (3)

### `snapshot`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:278` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `transferNativeGroupEmission` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:4` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `N6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5204` | Self: 0.0% (0us) | Total: 0.1% (5.3ms) | Samples: 0

**Called by:**
- `V6b` (1)

**Calls:**
- `Xr` (1)

### `internal:streams/pipeline`
`internal:streams/pipeline:2` | Self: 0.0% (0us) | Total: 1.0% (40.6ms) | Samples: 0

**Called by:**
- `anonymous` (16)

**Calls:**
- `anonymous` (16)

### `dyc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `yqd` (4)

**Calls:**
- `MQb` (4)

### `bsb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2846` | Self: 0.0% (0us) | Total: 2.5% (98.1ms) | Samples: 0

**Called by:**
- `isb` (12)
- `rCb` (1)

**Calls:**
- `stb` (12)
- `pjb` (1)

### `gCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2724` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `L0b` (1)
- `SBb` (1)

**Calls:**
- `bBb` (1)
- `bBb` (1)

### `nyb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `Qkb` (1)

**Calls:**
- `Qxb` (1)

### `canonicalErContacts`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:246` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `finishErGeometry` (1)

**Calls:**
- `at` (1)

### `plb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3425` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `E7b` (1)

**Calls:**
- `VC` (1)

### `ejb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2996` | Self: 0.0% (0us) | Total: 2.6% (100.4ms) | Samples: 0

**Called by:**
- `itb` (11)
- `pjb` (2)
- `uBd` (1)
- `KGd` (1)

**Calls:**
- `wsb` (15)

### `rg`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (8.9ms) | Samples: 0

**Called by:**
- `TKb` (1)

**Calls:**
- `Mg` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1783` | Self: 0.0% (0us) | Total: 0.1% (7.1ms) | Samples: 0

**Called by:**
- `measureRenderStage` (5)

**Calls:**
- `resolveExecutionPlan` (2)
- `resolveExecutionPlan` (1)
- `resolveExecutionPlan` (1)
- `resolveExecutionPlan` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:250` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `finish` (1)
- `finish` (1)

### `bn`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2777` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `kn` (1)

**Calls:**
- `Dn` (1)

### `PKb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6335` | Self: 0.0% (0us) | Total: 0.2% (10.1ms) | Samples: 0

**Called by:**
- `QKb` (2)

**Calls:**
- `TKb` (1)
- `Qc` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1131` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `receiptOf` (1)

**Calls:**
- `canonicalJson` (1)

### `kyb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.3% (12.3ms) | Samples: 0

**Called by:**
- `clb` (1)
- `Ykb` (1)

**Calls:**
- `Byb` (1)
- `Byb` (1)

### `Zlib`
`node:zlib:298` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `Gzip` (1)

**Calls:**
- `init` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:430` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `connectorInlineLabelText` (1)

**Calls:**
- `every` (1)

### `QOc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5643` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `oQc` (2)

**Calls:**
- `POc` (1)
- `ROc` (1)

### `walk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1757` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `walk` (1)

**Calls:**
- `endpointRelation` (1)

### `Lcd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3501` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `Ncd` (1)

**Calls:**
- `Jcd` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:111` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `markerBoundsAt` (1)

**Calls:**
- `test` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:646` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `pathBounds` (1)
- `geometryBounds` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:156` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `renderCardinality` (2)

**Calls:**
- `appendPrivate` (1)
- `appendPrivate` (1)

### `localPaintResourceId`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:373` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `validatePaint` (1)

**Calls:**
- `exec` (1)

### `attachSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:495` | Self: 0.0% (0us) | Total: 0.1% (7.6ms) | Samples: 0

**Called by:**
- `documentOpen` (2)

**Calls:**
- `canonicalizeSceneNodeSerialization` (1)
- `canonicalizeSceneNodeSerialization` (1)

### `JJb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6497` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `PJb` (1)

**Calls:**
- `MJb` (1)

### `bld`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5625` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `cJb` (1)

**Calls:**
- `_x` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:323` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `measureErEntities` (3)

**Calls:**
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:208` | Self: 0.0% (0us) | Total: 1.3% (53.4ms) | Samples: 0

**Called by:**
- `visit` (14)
- `visit` (11)

**Calls:**
- `leaf` (12)
- `leaf` (5)
- `leaf` (3)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:177` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:41` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `scanStartTags` (1)

**Calls:**
- `add` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:633` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `registerGroupEmission` (1)

### `ye`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4617` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `jdd` (1)

**Calls:**
- `oub` (1)

### `sOc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.7% (28.9ms) | Samples: 0

**Called by:**
- `nQb` (17)

**Calls:**
- `pOc` (17)

### `iFd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4324` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `JFd` (1)

**Calls:**
- `EJd` (1)

### `zsd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4165` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `Esd` (1)
- `Wxd` (1)

**Calls:**
- `rYd` (2)

### `normalizeMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:665` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (2)

**Calls:**
- `(anonymous)` (2)

### `graphicalBackendCapabilityClaims`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:271` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `validatePrimitiveCapabilities` (1)

### `sDb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1477` | Self: 0.0% (0us) | Total: 0.1% (6.3ms) | Samples: 0

**Called by:**
- `kDb` (2)

**Calls:**
- `XC` (2)

### `svgPathDataProblem`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:229` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `validateGeometry` (2)

**Calls:**
- `finiteNumber` (1)
- `finiteNumber` (1)

### `zeb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2904` | Self: 0.0% (0us) | Total: 0.1% (7.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `Meb` (2)

### `L0b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6004` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `K0b` (2)

**Calls:**
- `gCb` (1)
- `V0b` (1)

### `mwb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1560` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `fBb` (1)

**Calls:**
- `ECb` (1)

### `admitSceneDocumentWith`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:268` | Self: 0.0% (0us) | Total: 0.1% (6.6ms) | Samples: 0

**Called by:**
- `render` (3)

**Calls:**
- `visit` (2)
- `snapshotBoundedExternalData` (1)

### `glyphBox`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1314` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `map` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:713` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `typographyAttributes` (1)

### `h4d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `hxd` (1)

**Calls:**
- `Oce` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:195` | Self: 0.0% (0us) | Total: 0.3% (15.2ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (4)

**Calls:**
- `paintBounds` (3)
- `paintBounds` (1)

### `depth`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1439` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `isInteger` (1)

### `Xad`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `zpd` (2)

**Calls:**
- `Tad` (2)

### `resolveSvgColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:758` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (3)

**Calls:**
- `transformSvgCssValues` (3)

### `gGb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2197` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `YGb` (1)

**Calls:**
- `dmb` (1)

### `erDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/er/text.ts:94` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `erTextLabel` (1)

**Calls:**
- `normalizedErText` (1)

### `RFc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5639` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `VFc` (1)

**Calls:**
- `lNb` (1)

### `V8d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6474` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `_8d` (2)

**Calls:**
- `gyd` (1)
- `gyd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:5` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `VBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5912` | Self: 0.0% (0us) | Total: 0.3% (11.6ms) | Samples: 0

**Called by:**
- `dBd` (8)

**Calls:**
- `ZBd` (3)
- `WBd` (3)
- `HEd` (1)
- `fBd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1489` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (1)

**Calls:**
- `primitiveCapabilityId` (1)

### `jDd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `dte` (1)

**Calls:**
- `RBd` (1)

### `Kmb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `LFd` (1)

**Calls:**
- `Fmb` (1)

### `oWd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6117` | Self: 0.0% (0us) | Total: 0.3% (13.8ms) | Samples: 0

**Called by:**
- `PWd` (5)
- `oWd` (4)

**Calls:**
- `oWd` (4)
- `$Ed` (2)
- `$Yd` (1)
- `qjb` (1)
- `pjb` (1)

### `A6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6285` | Self: 0.0% (0us) | Total: 0.2% (9.4ms) | Samples: 0

**Called by:**
- `C6b` (4)

**Calls:**
- `o8b` (3)
- `o8b` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1490` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (1)

**Calls:**
- `backendSupportsCapability` (1)

### `inspectPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:98` | Self: 0.0% (0us) | Total: 2.1% (80.9ms) | Samples: 0

**Called by:**
- `drawNative` (37)

**Calls:**
- `visit` (16)
- `visit` (15)
- `visit` (5)
- `visit` (1)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:206` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (2)

**Calls:**
- `collides` (1)
- `collides` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1856` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `find` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1031` | Self: 0.0% (0us) | Total: 1.8% (72.9ms) | Samples: 0

**Called by:**
- `report` (35)

**Calls:**
- `rendered` (35)

### `C7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5795` | Self: 0.0% (0us) | Total: 0.3% (12.3ms) | Samples: 0

**Called by:**
- `A7b` (6)

**Calls:**
- `E7b` (4)
- `D7b` (2)

### `XEd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4490` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `p$d` (3)

**Calls:**
- `TWd` (3)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:91` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `buildStyleBlock` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:787` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `_Dc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6262` | Self: 0.0% (0us) | Total: 0.4% (15.6ms) | Samples: 0

**Called by:**
- `cEc` (9)

**Calls:**
- `NGb` (4)
- `$Dc` (3)
- `amb` (1)
- `XDc` (1)

### `layout`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:27` | Self: 0.0% (0us) | Total: 25.6% (987.0ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (551)

**Calls:**
- `runMeasuredGraphBackend` (541)
- `layoutErDiagram` (9)
- `layoutErDiagram` (1)

### `E$b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6045` | Self: 0.0% (0us) | Total: 0.3% (12.5ms) | Samples: 0

**Called by:**
- `J$b` (10)

**Calls:**
- `fHb` (5)
- `Krc` (2)
- `jNb` (1)
- `Krc` (1)
- `fHb` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:150` | Self: 0.0% (0us) | Total: 1.0% (40.7ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (15)

**Calls:**
- `renderRelationshipLabel` (8)
- `renderRelationshipLabel` (6)
- `renderRelationshipLabel` (1)

### `AEc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4868` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `BEc` (3)

**Calls:**
- `zEc` (1)
- `FYb` (1)
- `gmb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:142` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `projectErPositioned` (2)

### `Kac`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `nQb` (2)

**Calls:**
- `Hac` (2)

### `createNativePaintEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:56` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `createEmissionContext` (1)

### `prepareWrittenCompoundShape`
`/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:60` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `ownData` (1)

### `Xbd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2685` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `AQb` (1)

**Calls:**
- `_bd` (1)

### `S5b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `zbd` (1)

**Calls:**
- `s6b` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:164` | Self: 0.0% (0us) | Total: 0.1% (5.9ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (2)

**Calls:**
- `stringify` (2)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:159` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `scanStartTags` (1)

**Calls:**
- `defineProperty` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:738` | Self: 0.0% (0us) | Total: 0.2% (8.8ms) | Samples: 0

**Called by:**
- `write` (3)

**Calls:**
- `localPaintResourceReferences` (1)
- `localPaintResourceReferences` (1)
- `localPaintResourceReferences` (1)

### `fHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6333` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `E$b` (5)

**Calls:**
- `cJb` (5)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:618` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `defineProperty` (1)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1656` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `applyFamilyRequestNormalization` (1)

### `HXb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6152` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `N$b` (3)

**Calls:**
- `sZb` (1)
- `sZb` (1)
- `qZb` (1)

### `renderPreparedLine`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:171` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `renderMultilineText` (1)

**Calls:**
- `test` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:6` | Self: 0.0% (0us) | Total: 0.1% (7.3ms) | Samples: 0

**Called by:**
- `anonymous` (5)

**Calls:**
- `bound require` (5)

### `Uwd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2026` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `ypd` (1)

**Calls:**
- `Vwd` (1)

### `fp`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4018` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `XBd` (1)

**Calls:**
- `Bo` (1)

### `cvc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6498` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `dvc` (1)

**Calls:**
- `bqc` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:998` | Self: 0.0% (0us) | Total: 0.4% (17.2ms) | Samples: 0

**Called by:**
- `report` (11)

**Calls:**
- `withTextMeasurementExecution` (11)

### `vyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4081` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `W8d` (1)

**Calls:**
- `YEd` (1)

### `OIc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5759` | Self: 0.0% (0us) | Total: 0.1% (4.6ms) | Samples: 0

**Called by:**
- `MIc` (3)
- `NIc` (1)

**Calls:**
- `CYb` (2)
- `$lb` (1)
- `CYb` (1)

### `Vxd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5021` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `ksd` (1)

**Calls:**
- `xxd` (1)

### `zpd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5264` | Self: 0.0% (0us) | Total: 0.3% (12.8ms) | Samples: 0

**Called by:**
- `kbd` (6)
- `SGd` (5)

**Calls:**
- `vGd` (4)
- `Xad` (2)
- `lcd` (2)
- `Ncd` (2)
- `BGd` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:110` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `preparedInterTextBounds` (1)

**Calls:**
- `every` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:177` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `documentText` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:69` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)

**Calls:**
- `build` (2)
- `build` (2)

### `Drb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2736` | Self: 0.0% (0us) | Total: 0.4% (16.3ms) | Samples: 0

**Called by:**
- `Old` (3)
- `mmd` (1)

**Calls:**
- `Crb` (4)

### `yXd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `rJd` (3)
- `qJd` (1)

**Calls:**
- `Ftd` (4)

### `gzd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5526` | Self: 0.0% (0us) | Total: 4.2% (164.6ms) | Samples: 0

**Called by:**
- `hzd` (61)

**Calls:**
- `Myd` (61)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:587` | Self: 0.0% (0us) | Total: 1.1% (43.0ms) | Samples: 0

**Called by:**
- `group` (10)
- `createFixture` (1)

**Calls:**
- `checkInertGroup` (10)
- `checkInertGroup` (1)

### `yIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5435` | Self: 0.0% (0us) | Total: 0.2% (7.8ms) | Samples: 0

**Called by:**
- `GIb` (4)
- `jKb` (1)
- `iKb` (1)

**Calls:**
- `gBb` (2)
- `SBb` (2)
- `CIb` (1)
- `XBb` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:31` | Self: 0.0% (0us) | Total: 71.6% (2.75s) | Samples: 0

**Calls:**
- `withPerformanceObserver` (1062)
- `withPerformanceObserver` (2)

### `getCharWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:91` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureText` (1)

**Calls:**
- `isWideRange` (1)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:41` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `attribute` (1)
- `svgOpenTag` (1)

**Calls:**
- `replace` (1)
- `(anonymous)` (1)

### `rYb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2467` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `Vdd` (1)

**Calls:**
- `iYb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:12` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `eGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.4% (16.0ms) | Samples: 0

**Called by:**
- `YEd` (4)

**Calls:**
- `NFd` (4)

### `mDb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2615` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `$lb` (1)
- `kmb` (1)

**Calls:**
- `jDb` (2)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:397` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `group` (4)

**Calls:**
- `value` (2)
- `value` (1)
- `value` (1)

### `preparedInterTextBounds`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:123` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `include` (1)

### `ensureSvgIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:92` | Self: 0.0% (0us) | Total: 0.1% (3.9ms) | Samples: 0

**Called by:**
- `group` (3)

**Calls:**
- `set` (2)
- `set` (1)

### `collides`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:173` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `placeRelationshipLabels` (1)

**Calls:**
- `(anonymous)` (1)

### `sharedRenderOptionsJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:485` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `validateSerializableRenderOptions` (2)

**Calls:**
- `cloneValue` (2)

### `gFc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `IGc` (2)

**Calls:**
- `fFc` (2)

### `executeInspectedGraphicalRequest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:297` | Self: 0.0% (0us) | Total: 0.8% (33.0ms) | Samples: 0

**Called by:**
- `withSvgInspectionCache` (23)

**Calls:**
- `measureRenderStage` (23)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:5` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `Qe`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `Ce` (2)

**Calls:**
- `De` (2)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:120` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `relationshipPairKey` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:817` | Self: 0.0% (0us) | Total: 0.4% (17.8ms) | Samples: 0

**Called by:**
- `write` (5)

**Calls:**
- `validatePaint` (2)
- `validatePaint` (1)
- `validatePaint` (1)
- `validatePaint` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1322` | Self: 0.0% (0us) | Total: 0.2% (9.5ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (5)

**Calls:**
- `snapshot` (4)
- `snapshot` (1)

### `LIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `BIb` (1)

**Calls:**
- `BIb` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:875` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `write` (2)

**Calls:**
- `validatePaint` (1)
- `validatePaint` (1)

### `fFc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `gFc` (2)

**Calls:**
- `TEc` (2)

### `$Bd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5423` | Self: 0.0% (0us) | Total: 5.2% (201.4ms) | Samples: 0

**Called by:**
- `SGd` (80)
- `cBd` (2)

**Calls:**
- `bCd` (75)
- `UBd` (3)
- `Fzd` (1)
- `ksd` (1)
- `GAd` (1)
- `MBd` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:172` | Self: 0.0% (0us) | Total: 0.4% (17.1ms) | Samples: 0

**Called by:**
- `visitSvgStartTagsFresh` (7)

**Calls:**
- `attribute` (4)
- `attribute` (2)
- `attribute` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:80` | Self: 0.0% (0us) | Total: 0.3% (13.2ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (4)

**Calls:**
- `documentOpen` (2)
- `leaf` (1)
- `documentOpen` (1)

### `W8d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6489` | Self: 0.0% (0us) | Total: 0.1% (7.3ms) | Samples: 0

**Called by:**
- `Z8d` (5)

**Calls:**
- `uyd` (2)
- `ryd` (1)
- `vyd` (1)
- `qyd` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:555` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `attribute` (1)

### `Ky`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3096` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `My` (1)

**Calls:**
- `ui` (1)

### `gjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3610` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `qjb` (1)

**Calls:**
- `xsb` (1)

### `My`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3014` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `cJb` (1)

**Calls:**
- `Ky` (1)

### `isb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 2.5% (96.8ms) | Samples: 0

**Called by:**
- `xe` (12)

**Calls:**
- `bsb` (12)

### `snapshot`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1319` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `finishErGeometry` (1)

**Calls:**
- `map` (1)

### `captureNativeGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:99` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `groupValidation` (1)

**Calls:**
- `hasOwn` (1)

### `jdd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6113` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `edd` (2)

**Calls:**
- `ye` (1)
- `Ktb` (1)

### `internal:streams/legacy`
`internal:streams/legacy:2` | Self: 0.0% (0us) | Total: 0.3% (13.6ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `anonymous` (4)

### `hashId`
`/tmp/pr449-main-integration-20261029-762/src/scene/seed.ts:24` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `seedFrom` (1)

### `Krc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6492` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `E$b` (2)

**Calls:**
- `Eoc` (1)
- `oEd` (1)

### `HEd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3462` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `VBd` (1)

**Calls:**
- `wwd` (1)

### `renderRelationshipLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:534` | Self: 0.0% (0us) | Total: 0.3% (15.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (6)

**Calls:**
- `leaf` (3)
- `shape` (2)
- `shape` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:831` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `consumeStringBudget` (1)

### `crowsFootMark`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:621` | Self: 0.0% (0us) | Total: 0.8% (31.7ms) | Samples: 0

**Called by:**
- `renderCardinality` (10)
- `renderCardinality` (7)

**Calls:**
- `leaf` (16)
- `shape` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:509` | Self: 0.0% (0us) | Total: 0.3% (14.0ms) | Samples: 0

**Called by:**
- `group` (7)

**Calls:**
- `nativeGroup` (4)
- `nativeGroup` (1)
- `nativeGroup` (1)
- `nativeGroup` (1)

### `MGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.9% (36.0ms) | Samples: 0

**Called by:**
- `nQb` (26)

**Calls:**
- `BGc` (25)
- `BGc` (1)

### `Fyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4000` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `iyd` (1)
- `X8d` (1)

**Calls:**
- `_Td` (1)
- `ZTd` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:215` | Self: 0.0% (0us) | Total: 0.8% (32.5ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (11)

**Calls:**
- `leaf` (11)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:821` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `forEach` (1)

### `nativeAttributeValue`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:57` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `nativeGroup` (1)

**Calls:**
- `reserve` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:125` | Self: 0.0% (0us) | Total: 0.2% (8.9ms) | Samples: 0

**Called by:**
- `renderRelationshipLabel` (2)
- `renderEntityBox` (1)
- `crowsFootMark` (1)

**Calls:**
- `shape` (2)
- `shape` (1)
- `shape` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:197` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (2)

**Calls:**
- `escapeDisplayAttr` (2)

### `y7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5490` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `u7b` (1)

**Calls:**
- `x7b` (1)

### `buildErElkGraph`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:486` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `elkPlacement` (2)

**Calls:**
- `resolveRoleStyle` (1)
- `resolveRoleStyle` (1)

### `renderedSvgDigest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:61` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `stringify` (1)

### `TFd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4968` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `dXd` (1)

**Calls:**
- `UXd` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:148` | Self: 0.0% (0us) | Total: 0.2% (10.7ms) | Samples: 0

**Called by:**
- `visitSvgStartTagsFresh` (4)

**Calls:**
- `tag` (3)
- `tag` (1)

### `transformedHitDistance`
`/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:27` | Self: 0.0% (0us) | Total: 0.2% (8.0ms) | Samples: 0

**Called by:**
- `hitsTransformed` (2)

**Calls:**
- `connectorSegments` (2)

### `F7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5612` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `E7b` (1)

**Calls:**
- `Rlb` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1483` | Self: 0.0% (0us) | Total: 0.1% (6.0ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (3)

**Calls:**
- `flatIntoArrayWithCallback` (3)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1608` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (1)

**Calls:**
- `sceneValidationMode` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:112` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (1)

**Calls:**
- `erCardinalityInk` (1)

### `jNb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4187` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `E$b` (1)
- `gVb` (1)

**Calls:**
- `qNb` (1)
- `$rb` (1)

### `canonicalOpeningTag`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:443` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `canonicalizeSceneNodeSerialization` (1)

**Calls:**
- `sort` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:199` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `group` (1)
- `group` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1088` | Self: 0.0% (0us) | Total: 0.6% (26.0ms) | Samples: 0

**Called by:**
- `report` (8)

**Calls:**
- `map` (8)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:181` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `map` (1)

### `rCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `wCb` (1)

**Calls:**
- `bsb` (1)

### `arrowMarkerResources`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:36` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `flowchartMarkerResources` (1)

**Calls:**
- `tipAnchoredArrow` (1)

### `connector/transform/render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:631` | Self: 0.0% (0us) | Total: 0.3% (12.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `hitsTransformed` (2)
- `hitsTransformed` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1585` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `snapshotFamilyConfig` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1583` | Self: 0.0% (0us) | Total: 0.1% (5.6ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (4)

**Calls:**
- `snapshotDescriptorArray` (4)

### `wbd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6225` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `DQb` (3)

**Calls:**
- `Abd` (2)
- `SBb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1319` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `glyphBox` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:201` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `preventExtensions` (1)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:454` | Self: 0.0% (0us) | Total: 0.1% (3.9ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (3)

**Calls:**
- `sharedRenderOptionsJsonSchema` (2)
- `deepFreeze` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:575` | Self: 0.0% (0us) | Total: 3.8% (147.4ms) | Samples: 0

**Called by:**
- `write` (40)
- `validateNodeSerialization` (3)
- `drawn` (2)

**Calls:**
- `writeTextSvg` (9)
- `writeShapeSvg` (4)
- `writeConnectorSvg` (4)
- `writeConnectorSvg` (3)
- `writeTextSvg` (3)
- `writeConnectorSvg` (3)
- `writeShapeSvg` (3)
- `writeShapeSvg` (2)
- `writeTextSvg` (1)
- `issue` (1)
- `writeConnectorSvg` (1)
- `issue` (1)
- `finishXmlLeaf` (1)
- `writeTextSvg` (1)
- `writeConnectorSvg` (1)
- `writeSceneNode` (1)
- `writeTextSvg` (1)
- `writeTextSvg` (1)
- `writeShapeSvg` (1)
- `writeConnectorSvg` (1)
- `join` (1)
- `writeShapeSvg` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1573` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `fromEntries` (1)

### `admitSceneDocumentWith`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:270` | Self: 0.0% (0us) | Total: 1.6% (63.7ms) | Samples: 0

**Called by:**
- `render` (30)

**Calls:**
- `assertAdmissibleSceneDoc` (30)

### `Gyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4943` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `X8d` (2)

**Calls:**
- `a4d` (1)
- `Hyd` (1)

### `preprocessMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:869` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `normalizeSource` (1)

**Calls:**
- `extractInitDirectives` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:3` | Self: 0.0% (0us) | Total: 9.0% (346.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `bound require` (5)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:906` | Self: 0.0% (0us) | Total: 1.6% (61.9ms) | Samples: 0

**Called by:**
- `node` (24)

**Calls:**
- `groupValidation` (23)
- `groupValidation` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:184` | Self: 0.0% (0us) | Total: 0.9% (34.8ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (10)
- `renderCardinality` (2)
- `renderCardinality` (1)

**Calls:**
- `join` (7)
- `join` (2)
- `join` (1)
- `join` (1)
- `join` (1)
- `join` (1)

### `g`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5090` | Self: 0.0% (0us) | Total: 0.3% (12.7ms) | Samples: 0

**Called by:**
- `Jz` (10)

**Calls:**
- `sdb` (10)

### `tud`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `CGd` (1)

**Calls:**
- `pWd` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:278` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `extractErLayout` (1)

**Calls:**
- `map` (1)

### `isWideRange`
`/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts:127` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `getCharWidth` (1)

**Calls:**
- `inRanges` (1)

### `gmb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2068` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `AEc` (1)
- `tCb` (1)

**Calls:**
- `dnb` (2)

### `snapshotScenePrimitiveCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1541` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `snapshotDescriptorArray` (1)

**Calls:**
- `captureFields` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:45` | Self: 0.0% (0us) | Total: 3.4% (132.8ms) | Samples: 0

**Calls:**
- `gc` (78)

### `DEc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6237` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `zEc` (1)

**Calls:**
- `min` (1)

### `zgc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (5.5ms) | Samples: 0

**Called by:**
- `IGc` (4)

**Calls:**
- `ngc` (4)

### `eNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6124` | Self: 0.0% (0us) | Total: 0.4% (17.4ms) | Samples: 0

**Called by:**
- `vNc` (5)

**Calls:**
- `zNc` (4)
- `xNc` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:16` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `anonymous` (3)

**Calls:**
- `bound require` (3)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:39` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `scopeSvgStyles` (1)

**Calls:**
- `padStart` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:10` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `pWd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6069` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `PWd` (3)
- `pWd` (1)

**Calls:**
- `$Ed` (2)
- `pWd` (1)
- `XFd` (1)

### `Qxb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4331` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `nyb` (1)

**Calls:**
- `gJb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1308` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (1)

**Calls:**
- `paintBounds` (1)

### `YLd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5467` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `aMd` (1)

**Calls:**
- `B4d` (1)

### `groupValidation`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:506` | Self: 0.0% (0us) | Total: 1.5% (60.3ms) | Samples: 0

**Called by:**
- `validateNode` (23)

**Calls:**
- `captureNativeGroupEmission` (21)
- `captureNativeGroupEmission` (1)
- `captureNativeGroupEmission` (1)

### `BNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.6% (24.4ms) | Samples: 0

**Called by:**
- `nQb` (10)

**Calls:**
- `vNc` (9)
- `vNc` (1)

### `UGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6210` | Self: 0.0% (0us) | Total: 0.3% (13.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (11)

**Calls:**
- `edd` (8)
- `dvc` (2)
- `qPb` (1)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1621` | Self: 0.0% (0us) | Total: 1.1% (43.0ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (23)

**Calls:**
- `validateNode` (5)
- `validateNode` (5)
- `validateNode` (4)
- `validateNode` (3)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1188` | Self: 0.0% (0us) | Total: 23.0% (885.8ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (494)

**Calls:**
- `elkPlacement` (486)
- `elkPlacement` (8)

### `Jl`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2185` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Gl` (1)

**Calls:**
- `pc` (1)

### `XBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5602` | Self: 0.0% (0us) | Total: 0.4% (15.5ms) | Samples: 0

**Called by:**
- `SGd` (9)
- `oBd` (1)

**Calls:**
- `dBd` (8)
- `oBd` (1)
- `fp` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6538` | Self: 0.0% (0us) | Total: 2.3% (91.6ms) | Samples: 0

**Called by:**
- `o` (1)

**Calls:**
- `(anonymous)` (1)

### `Mg`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2595` | Self: 0.0% (0us) | Total: 0.2% (8.9ms) | Samples: 0

**Called by:**
- `rg` (1)

**Calls:**
- `ed` (1)

### `vGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5628` | Self: 0.0% (0us) | Total: 1.3% (53.5ms) | Samples: 0

**Called by:**
- `dte` (24)
- `zpd` (4)

**Calls:**
- `r1d` (23)
- `CGd` (3)
- `YEd` (1)
- `t1d` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Collection.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `internal:fs/binding`
`internal:fs/binding:3` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `@lazy` (1)

### `BEc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5967` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `IEc` (3)

**Calls:**
- `AEc` (3)

### `i1d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4177` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `t1d` (1)

**Calls:**
- `r1d` (1)

### `RYd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4629` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `mWd` (1)

**Calls:**
- `SYd` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1802` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `has` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:761` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `resolveCss` (1)

### `Gl`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2840` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `fVb` (1)

**Calls:**
- `Jl` (1)

### `wpb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2988` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Un` (1)

**Calls:**
- `Xpb` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1728` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `measureRenderStage` (4)

**Calls:**
- `validateSerializableRenderOptions` (3)
- `validateSerializableRenderOptions` (1)

### `IKb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6016` | Self: 0.0% (0us) | Total: 0.2% (8.4ms) | Samples: 0

**Called by:**
- `gHb` (4)

**Calls:**
- `AIb` (4)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:59` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `scanStartTags` (1)

**Calls:**
- `xmlIndexOf` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:200` | Self: 0.0% (0us) | Total: 0.4% (16.9ms) | Samples: 0

**Called by:**
- `group` (7)

**Calls:**
- `(anonymous)` (7)

### `Bsb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3705` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `zjb` (1)

**Calls:**
- `SC` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:8` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1461` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `serialize` (1)

**Calls:**
- `open` (1)

### `CZd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (5.7ms) | Samples: 0

**Called by:**
- `YEd` (5)

**Calls:**
- `UHd` (4)
- `UHd` (1)

### `issue`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:91` | Self: 0.0% (0us) | Total: 0.1% (4.6ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `assign` (1)

### `bCd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5164` | Self: 0.0% (0us) | Total: 4.7% (184.4ms) | Samples: 0

**Called by:**
- `$Bd` (75)

**Calls:**
- `Efb` (75)

### `connectorInlineLabelSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:761` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `connectorInlineLabelText` (1)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:132` | Self: 0.0% (0us) | Total: 0.1% (5.8ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (2)

**Calls:**
- `flatIntoArrayWithCallback` (2)

### `zAd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2650` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `yAd` (1)

**Calls:**
- `kC` (1)

### `i4b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4121` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `k4b` (4)

**Calls:**
- `lHb` (4)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:5` | Self: 0.0% (0us) | Total: 9.0% (346.6ms) | Samples: 0

**Calls:**
- `(anonymous)` (5)

### `deferredRequestReceiptDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1108` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `deferredRenderContractDigest` (1)

### `lbd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6501` | Self: 0.0% (0us) | Total: 9.8% (377.7ms) | Samples: 0

**Called by:**
- `kbd` (202)

**Calls:**
- `ibd` (194)
- `$lb` (2)
- `xpd` (2)
- `xpd` (2)
- `ibd` (1)
- `mbd` (1)

### `IHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4388` | Self: 0.0% (0us) | Total: 0.1% (5.5ms) | Samples: 0

**Called by:**
- `CIb` (4)

**Calls:**
- `GIb` (4)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:376` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `readXmlNameEnd` (1)

### `buildErElkGraph`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:530` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `elkPlacement` (2)

**Calls:**
- `erRelationshipBlock` (2)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:442` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `freeze` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:653` | Self: 0.0% (0us) | Total: 0.4% (16.9ms) | Samples: 0

**Called by:**
- `solidInteriors` (3)
- `erCardinalityInk` (3)
- `leaf` (1)

**Calls:**
- `transformedBounds` (5)
- `strokedBox` (1)
- `transformedBounds` (1)

### `zNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4723` | Self: 0.0% (0us) | Total: 0.4% (15.7ms) | Samples: 0

**Called by:**
- `eNc` (4)

**Calls:**
- `Wr` (3)
- `Xr` (1)

### `erCardinalityInk`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:123` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `enoughLead` (2)

**Calls:**
- `erCardinalityPieces` (1)
- `erCardinalityPieces` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:201` | Self: 0.0% (0us) | Total: 0.2% (8.1ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (4)

**Calls:**
- `stringify` (4)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:436` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `measureErEntities` (2)

**Calls:**
- `qualify` (1)
- `qualify` (1)

### `stb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 2.5% (96.8ms) | Samples: 0

**Called by:**
- `bsb` (12)

**Calls:**
- `itb` (12)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1546` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `executionCapabilityDecision` (1)

### `cloneValue`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` | Self: 0.0% (0us) | Total: 0.5% (21.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (11)
- `map` (4)
- `sharedRenderOptionsJsonSchema` (2)

**Calls:**
- `map` (17)

### `serialize`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:631` | Self: 0.0% (0us) | Total: 6.9% (268.5ms) | Samples: 0

**Called by:**
- `leaf` (84)

**Calls:**
- `write` (40)
- `write` (38)
- `write` (2)
- `write` (1)
- `write` (1)
- `(anonymous)` (1)
- `write` (1)

### `vNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6480` | Self: 0.0% (0us) | Total: 0.5% (23.0ms) | Samples: 0

**Called by:**
- `BNc` (9)

**Calls:**
- `eNc` (5)
- `iNc` (1)
- `rNc` (1)
- `fNc` (1)
- `ENc` (1)

### `oub`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `ye` (1)

**Calls:**
- `hub` (1)

### `Cf`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `WBd` (2)

**Calls:**
- `wjb` (2)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1853` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (2)

**Calls:**
- `performIteration` (2)

### `AKb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5853` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `gHb` (3)

**Calls:**
- `YHb` (1)
- `Mrb` (1)
- `FIb` (1)

### `uBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5562` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `ZBd` (3)

**Calls:**
- `JEd` (2)
- `ejb` (1)

### `documentOpen`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:132` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `header` (1)

### `ILd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `xe` (2)

**Calls:**
- `CYd` (2)

### `ensureElk`
`/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts:78` | Self: 0.0% (0us) | Total: 0.3% (13.6ms) | Samples: 0

**Called by:**
- `layoutElkGraph` (11)

**Calls:**
- `forEach` (11)

### `xAd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3087` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `BBd` (1)

**Calls:**
- `_B` (1)

### `kC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3879` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `zAd` (1)

**Calls:**
- `lC` (1)

### `verifyNoExternalRefs`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:701` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `runBackendConformance` (2)

**Calls:**
- `inspectOwnedSvgOnce` (2)

### `connector/subpaths/render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:662` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `some` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:37` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)
- `build` (1)

**Calls:**
- `build` (2)
- `build` (1)

### `drawn`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:421` | Self: 0.0% (0us) | Total: 0.1% (6.3ms) | Samples: 0

**Called by:**
- `runBackendConformance` (2)
- `connectorProjectedField` (1)

**Calls:**
- `serializeSceneNode` (2)
- `drawNode` (1)

### `iNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6268` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `vNc` (1)

**Calls:**
- `jNc` (1)

### `Vsd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2012` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `DXd` (1)

**Calls:**
- `nud` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1365` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `resolveRoleStyle` (1)

### `measureErEntities`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:453` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `layoutErDiagram` (2)

**Calls:**
- `preparePixelText` (1)
- `preparePixelText` (1)

### `prepareMarkerTerminals`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:9` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `(module)` (2)
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `map` (5)

### `_8d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5013` | Self: 0.0% (0us) | Total: 3.6% (139.3ms) | Samples: 0

**Called by:**
- `jRd` (42)

**Calls:**
- `yyd` (39)
- `V8d` (2)
- `U8d` (1)

### `captureFields`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `snapshotScenePrimitiveCell` (1)

**Calls:**
- `map` (1)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:410` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `nativeAttributeValue` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:202` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `stringify` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:110` | Self: 0.0% (0us) | Total: 0.1% (6.7ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (4)

**Calls:**
- `createNativePaintEmission` (3)
- `createNativePaintEmission` (1)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:102` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `materializeText` (1)

**Calls:**
- `transferRetainedPixelText` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:530` | Self: 0.0% (0us) | Total: 0.2% (9.1ms) | Samples: 0

**Called by:**
- `validateMarker` (3)
- `validateNode` (1)
- `validateNode` (1)

**Calls:**
- `svgPathDataProblem` (2)
- `svgPathDataProblem` (2)
- `svgPathDataProblem` (1)

### `QCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `dwb` (2)

**Calls:**
- `OCb` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-doc.js:4` | Self: 0.0% (0us) | Total: 0.1% (3.9ms) | Samples: 0

**Called by:**
- `anonymous` (3)

**Calls:**
- `bound require` (3)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1578` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `snapshotDescriptorArray` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:186` | Self: 0.0% (0us) | Total: 3.0% (117.0ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (42)

**Calls:**
- `measureRenderStage` (41)
- `measureRenderStage` (1)

### `aMd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4646` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Called by:**
- `Pud` (2)
- `xce` (1)

**Calls:**
- `tb` (1)
- `vMd` (1)
- `YLd` (1)

### `ysd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6448` | Self: 0.0% (0us) | Total: 4.6% (178.6ms) | Samples: 0

**Called by:**
- `Rud` (70)

**Calls:**
- `msd` (70)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:592` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `geometryBounds` (1)
- `unionSceneBounds` (1)

### `ui`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1389` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `Ky` (1)

**Calls:**
- `Yh` (1)

### `SvgWriter`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:471` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `XmlLeafWrite` (1)

### `node:zlib`
`node:zlib:485` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `createConvenienceMethod` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:3` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `bound require` (1)
- `(anonymous)` (1)

### `OGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1536` | Self: 0.0% (0us) | Total: 0.3% (12.7ms) | Samples: 0

**Called by:**
- `sdb` (10)

**Calls:**
- `gdd` (10)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` | Self: 0.0% (0us) | Total: 0.4% (16.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `xmlSlice` (2)
- `xmlSlice` (1)

### `vhe`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `NFd` (1)

**Calls:**
- `WLd` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:808` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `attribute` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:4` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:11` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `markerTerminalDepth` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:163` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (2)

**Calls:**
- `opaqueOutlineWidth` (2)

### `Nr`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (9.3ms) | Samples: 0

**Called by:**
- `Wr` (2)

**Calls:**
- `Qr` (1)
- `Qr` (1)

### `Er`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3745` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `ho` (1)

**Calls:**
- `Fr` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:66` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `collides` (1)

**Calls:**
- `overlaps` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1502` | Self: 0.0% (0us) | Total: 1.7% (68.2ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (25)

**Calls:**
- `solidInteriors` (4)
- `solidInteriors` (4)
- `solidInteriors` (2)
- `solidInteriors` (2)
- `solidInteriors` (2)
- `solidInteriors` (2)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)

### `Uvb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2801` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `_vb` (2)

**Calls:**
- `vmb` (1)
- `qkb` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:975` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `assertRenderableLinearGradient` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:75` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `validateSerializableRenderOptions` (1)

**Calls:**
- `filter` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1488` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (2)

**Calls:**
- `flatIntoArrayWithCallback` (2)

### `normalizeMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:663` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `mermaidFirstLine` (1)

### `internal:stream`
`internal:stream:47` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `pPb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4957` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `qPb` (1)

**Calls:**
- `_Pb` (1)

### `bcd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2017` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `CQb` (1)

**Calls:**
- `Wbd` (1)

### `RBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5222` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `jDd` (1)

**Calls:**
- `TAd` (1)

### `UNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6157` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `YNc` (1)

**Calls:**
- `VNc` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:674` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `set` (1)

### `nCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (4.3ms) | Samples: 0

**Called by:**
- `yCb` (2)
- `dwb` (1)

**Calls:**
- `bwb` (3)

### `Txd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `MTd` (1)

**Calls:**
- `gAd` (1)

### `OGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.4% (15.9ms) | Samples: 0

**Called by:**
- `xGc` (10)

**Calls:**
- `pGc` (10)

### `ed`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2773` | Self: 0.0% (0us) | Total: 0.2% (8.9ms) | Samples: 0

**Called by:**
- `Mg` (1)

**Calls:**
- `Izb` (1)

### `Byb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3374` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `kyb` (1)

**Calls:**
- `Cyb` (1)

### `rYd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `zsd` (2)

**Calls:**
- `YEd` (1)
- `vYd` (1)

### `UHd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5496` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `CZd` (4)

**Calls:**
- `x$d` (3)
- `bHd` (1)

### `o`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 7.4% (287.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (140)
- `r` (1)

**Calls:**
- `(anonymous)` (70)
- `(anonymous)` (70)
- `(anonymous)` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:218` | Self: 0.0% (0us) | Total: 0.3% (13.1ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (7)

**Calls:**
- `inlineResolvedColors` (3)
- `resolveSvgColors` (3)
- `inlineResolvedColors` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:14` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:114` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `flowchartMarkerResources` (1)

### `report`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:235` | Self: 0.0% (0us) | Total: 3.3% (127.7ms) | Samples: 0

**Called by:**
- `retainedNativeDrawing` (59)

**Calls:**
- `runBackendConformance` (35)
- `runBackendConformance` (11)
- `runBackendConformance` (8)
- `runBackendConformance` (2)
- `runBackendConformance` (2)
- `deepFreeze` (1)

### `e6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5938` | Self: 0.0% (0us) | Total: 2.8% (110.9ms) | Samples: 0

**Called by:**
- `g6b` (52)

**Calls:**
- `dHb` (52)

### `renderContractDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1118` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `resolveExecutionPlan` (1)
- `resolveAppearance` (1)

**Calls:**
- `admitRenderContractDigestInput` (1)
- `canonicalJson` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:627` | Self: 0.0% (0us) | Total: 0.6% (24.8ms) | Samples: 0

**Called by:**
- `finish` (10)

**Calls:**
- `repairErFrameRoutes` (2)
- `repairErFrameRoutes` (2)
- `repairErFrameRoutes` (2)
- `repairErFrameRoutes` (1)
- `repairErFrameRoutes` (1)
- `repairErFrameRoutes` (1)
- `repairErFrameRoutes` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:315` | Self: 0.0% (0us) | Total: 0.2% (8.7ms) | Samples: 0

**Called by:**
- `validateNode` (2)
- `forEach` (1)

**Calls:**
- `numericCss` (1)
- `numericCss` (1)
- `numericCss` (1)

### `internal:streams/readable`
`internal:streams/readable:2` | Self: 0.0% (0us) | Total: 0.1% (4.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `QGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (9.1ms) | Samples: 0

**Called by:**
- `xGc` (7)

**Calls:**
- `yGc` (7)

### `setConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:59` | Self: 0.0% (0us) | Total: 2.6% (102.0ms) | Samples: 0

**Called by:**
- `connector` (2)

**Calls:**
- `install` (1)
- `install` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:317` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `freeze` (1)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:181` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (3)

**Calls:**
- `scopeHash` (1)
- `scopeHash` (1)
- `scopeHash` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1008` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Called by:**
- `report` (2)

**Calls:**
- `drawn` (2)

### `vYd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `rYd` (1)

**Calls:**
- `tYd` (1)

### `nWd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6100` | Self: 0.0% (0us) | Total: 0.1% (6.7ms) | Samples: 0

**Called by:**
- `PWd` (3)
- `nWd` (2)

**Calls:**
- `$Ed` (3)
- `nWd` (2)

### `snapshotBackendCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:330` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `freezeBuiltInBackend` (1)

**Calls:**
- `map` (1)

### `withDeferredTerminalProjections`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:16` | Self: 0.0% (0us) | Total: 24.2% (935.6ms) | Samples: 0

**Called by:**
- `drawNative` (292)

**Calls:**
- `lowerErDrawing` (124)
- `lowerErDrawing` (72)
- `lowerErDrawing` (69)
- `lowerErDrawing` (15)
- `lowerErDrawing` (4)
- `lowerErDrawing` (2)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)

### `kbd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5286` | Self: 0.0% (0us) | Total: 10.0% (386.1ms) | Samples: 0

**Called by:**
- `SGd` (209)

**Calls:**
- `lbd` (202)
- `zpd` (6)
- `lbd` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:760` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `write` (2)

**Calls:**
- `boundedString` (1)
- `boundedString` (1)

### `erCardinalityInk`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:126` | Self: 0.0% (0us) | Total: 0.5% (19.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (6)
- `erCardinalityEnvelope` (3)
- `enoughLead` (2)
- `(anonymous)` (1)

**Calls:**
- `paintBounds` (9)
- `paintBounds` (3)

### `XC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3749` | Self: 0.0% (0us) | Total: 0.1% (6.3ms) | Samples: 0

**Called by:**
- `sDb` (2)

**Calls:**
- `WC` (1)
- `rb` (1)

### `yGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4405` | Self: 0.0% (0us) | Total: 0.2% (9.1ms) | Samples: 0

**Called by:**
- `QGc` (7)

**Calls:**
- `IGc` (6)
- `Agc` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:520` | Self: 0.0% (0us) | Total: 0.1% (3.9ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `connector` (1)

### `projectSvgCss`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:287` | Self: 0.0% (0us) | Total: 0.1% (6.4ms) | Samples: 0

**Called by:**
- `colorResolution` (3)

**Calls:**
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `hitsTransformed`
`/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:47` | Self: 0.0% (0us) | Total: 0.2% (8.0ms) | Samples: 0

**Called by:**
- `connector/transform/render` (2)

**Calls:**
- `transformedHitDistance` (2)

### `Ktb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `jdd` (1)

**Calls:**
- `Gtb` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:569` | Self: 0.0% (0us) | Total: 0.2% (9.6ms) | Samples: 0

**Called by:**
- `resolvedColorValue` (2)

**Calls:**
- `resolveColors` (1)
- `resolveColors` (1)

### `YNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `jNc` (1)

**Calls:**
- `UNc` (1)

### `MTd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `hMd` (1)

**Calls:**
- `Txd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/YAMLSeq.js:4` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `Un`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Wl` (1)

**Calls:**
- `wpb` (1)

### `wCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2802` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `ACb` (3)

**Calls:**
- `i7b` (1)
- `rCb` (1)
- `SCb` (1)

### `resolvedColorValue`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:601` | Self: 0.0% (0us) | Total: 0.2% (11.3ms) | Samples: 0

**Called by:**
- `toneOnFill` (3)

**Calls:**
- `diagramColorVariables` (2)
- `diagramColorVariables` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringify.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `El`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `Qr` (1)

**Calls:**
- `MZb` (1)

### `relationshipFrom`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1107` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `parseErDiagram` (1)

**Calls:**
- `erTextLabel` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:678` | Self: 0.0% (0us) | Total: 0.1% (7.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (3)

**Calls:**
- `geometryAttributes` (1)
- `geometryAttributes` (1)
- `geometryAttributes` (1)

### `ijd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `edd` (4)

**Calls:**
- `Crb` (1)
- `Wcd` (1)
- `Qgd` (1)
- `ued` (1)

### `erCardinalityEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:134` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `buildErElkGraph` (3)

**Calls:**
- `erCardinalityInk` (3)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:582` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `resolvedColorValue` (1)

**Calls:**
- `set` (1)

### `snapshotFamilyConfig`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1532` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `freezeDescriptor` (1)

**Calls:**
- `snapshotDescriptorArray` (1)

### `Bwb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1961` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `xCb` (2)

**Calls:**
- `owb` (2)

### `wIc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4469` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `Wfc` (1)

**Calls:**
- `$u` (1)

### `I$b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6360` | Self: 0.0% (0us) | Total: 0.4% (18.4ms) | Samples: 0

**Called by:**
- `J$b` (13)

**Calls:**
- `N$b` (5)
- `M$b` (3)
- `Q$b` (2)
- `N$b` (1)
- `dKd` (1)
- `Q$b` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1397` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `some` (1)

### `OHd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `kWd` (1)

**Calls:**
- `L$d` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:645` | Self: 0.0% (0us) | Total: 0.1% (5.9ms) | Samples: 0

**Called by:**
- `leaf` (4)

**Calls:**
- `prepareWrittenCompoundShape` (1)
- `prepareWrittenCompoundShape` (1)
- `prepareWrittenCompoundShape` (1)
- `prepareWrittenCompoundShape` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1826` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `expectedCapabilityState` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:974` | Self: 0.0% (0us) | Total: 0.6% (26.0ms) | Samples: 0

**Called by:**
- `map` (8)

**Calls:**
- `connector/transform/render` (3)
- `outcome` (2)
- `connector/subpaths/render` (1)
- `connector/subpaths/render` (1)
- `connectorProjectedField` (1)

### `attributeRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:19` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `value` (1)

**Calls:**
- `defineProperties` (1)

### `PWd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 3.5% (138.3ms) | Samples: 0

**Called by:**
- `hxd` (40)

**Calls:**
- `kWd` (21)
- `oWd` (5)
- `mWd` (3)
- `pWd` (3)
- `hxd` (3)
- `nWd` (3)
- `pWd` (1)
- `kWd` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:543` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `validateConnectorProjectionConsistency`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1314` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `connectorContourSemantics` (1)

### `Wfc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4959` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `Xfc` (1)

**Calls:**
- `wIc` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:209` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `parseFloat` (1)

### `ENc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6063` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `vNc` (1)

**Calls:**
- `GNc` (1)

### `Dk`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `VBb` (1)

**Calls:**
- `_vb` (1)

### `internal:stream`
`internal:stream:2` | Self: 0.0% (0us) | Total: 1.4% (56.7ms) | Samples: 0

**Called by:**
- `anonymous` (23)

**Calls:**
- `anonymous` (23)

### `readXmlNameEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:104` | Self: 0.0% (0us) | Total: 0.1% (7.6ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (1)

**Calls:**
- `xmlNameCharacter` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:464` | Self: 0.0% (0us) | Total: 2.8% (109.1ms) | Samples: 0

**Called by:**
- `createFixture` (3)
- `connector` (2)
- `createFixture` (1)

**Calls:**
- `setConnectorTerminalProjection` (4)
- `setConnectorTerminalProjection` (2)

### `YJb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5342` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `ZJb` (1)

**Calls:**
- `Le` (1)

### `wjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `Cf` (2)

**Calls:**
- `Cjb` (2)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:214` | Self: 0.0% (0us) | Total: 0.2% (7.9ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (5)

**Calls:**
- `connector` (3)
- `connector` (1)
- `connector` (1)

### `JGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3187` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `fdd` (1)

**Calls:**
- `GGd` (1)

### `_n`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4375` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Dn` (1)

**Calls:**
- `Wl` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/omap.js:7` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `possibleShapeFill`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:127` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `solidInteriors` (1)

**Calls:**
- `sceneGroupOpacity` (1)

### `IEc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `IGc` (3)

**Calls:**
- `BEc` (3)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1391` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `(anonymous)` (1)

### `xGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4342` | Self: 0.0% (0us) | Total: 0.6% (25.0ms) | Samples: 0

**Called by:**
- `BGc` (17)

**Calls:**
- `OGc` (10)
- `QGc` (7)

### `ZBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4297` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `VBd` (3)

**Calls:**
- `uBd` (3)

### `sdb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1284` | Self: 0.0% (0us) | Total: 0.3% (12.7ms) | Samples: 0

**Called by:**
- `g` (10)

**Calls:**
- `OGd` (10)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:605` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (2)

**Calls:**
- `attribute` (2)

### `VWb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `dHb` (1)

**Calls:**
- `i6b` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 12.2% (471.3ms) | Samples: 0

**Called by:**
- `ELKNode` (140)
- `(anonymous)` (2)

**Calls:**
- `o` (140)
- `(anonymous)` (2)
- `r` (1)

### `graphicalBackendCapabilityClaims`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:249` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `map` (1)

### `paintAttribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:493` | Self: 0.0% (0us) | Total: 0.2% (11.0ms) | Samples: 0

**Called by:**
- `paintAttributes` (3)
- `paintAttributes` (2)

**Calls:**
- `attribute` (2)
- `attribute` (1)
- `attribute` (1)
- `attribute` (1)

### `UBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4216` | Self: 0.0% (0us) | Total: 0.2% (8.1ms) | Samples: 0

**Called by:**
- `$Bd` (3)

**Calls:**
- `cBd` (3)

### `THb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4914` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `aIb` (1)

**Calls:**
- `WC` (1)

### `rendered`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:427` | Self: 0.0% (0us) | Total: 1.8% (72.9ms) | Samples: 0

**Called by:**
- `runBackendConformance` (35)

**Calls:**
- `render` (33)
- `render` (1)
- `(anonymous)` (1)

### `node:zlib`
`node:zlib:449` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Calls:**
- `map` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:580` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `map` (1)

### `renderPreparedLine`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:178` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `renderMultilineText` (2)

**Calls:**
- `map` (2)

### `JBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5698` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `TAd` (1)

**Calls:**
- `sse` (1)

### `KGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1926` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `GGd` (1)

**Calls:**
- `ejb` (1)

### `pGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6096` | Self: 0.0% (0us) | Total: 0.4% (15.9ms) | Samples: 0

**Called by:**
- `OGc` (10)

**Calls:**
- `AGc` (10)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:560` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `kd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `xKb` (2)

**Calls:**
- `Dd` (2)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1764` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `walk` (1)

### `HGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4706` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `mEd` (1)

**Calls:**
- `Vdd` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1882` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `builtinFamilyConformanceReport` (2)

### `resolvedColorValue`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:598` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `toneOnFill` (1)

**Calls:**
- `isHexColor` (1)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:106` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `resolveRoleStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:251` | Self: 0.0% (0us) | Total: 0.1% (6.9ms) | Samples: 0

**Called by:**
- `buildErElkGraph` (1)
- `erFrameInkPadding` (1)
- `finishErGeometry` (1)
- `renderRelationshipLabel` (1)

**Calls:**
- `Set` (4)

### `Dn`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `bn` (1)

**Calls:**
- `_n` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:111` | Self: 0.0% (0us) | Total: 3.3% (127.7ms) | Samples: 0

**Called by:**
- `measureRenderStage` (59)

**Calls:**
- `report` (59)

### `itb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4761` | Self: 0.0% (0us) | Total: 2.5% (96.8ms) | Samples: 0

**Called by:**
- `stb` (12)

**Calls:**
- `ejb` (11)
- `ytb` (1)

### `dwb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1561` | Self: 0.0% (0us) | Total: 0.4% (17.3ms) | Samples: 0

**Called by:**
- `rwb` (11)

**Calls:**
- `yCb` (7)
- `QCb` (2)
- `nCb` (1)
- `tCb` (1)

### `Ce`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2774` | Self: 0.0% (0us) | Total: 0.1% (4.2ms) | Samples: 0

**Called by:**
- `Pe` (3)

**Calls:**
- `Qe` (2)
- `SC` (1)

### `E7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5366` | Self: 0.0% (0us) | Total: 0.2% (7.9ms) | Samples: 0

**Called by:**
- `C7b` (4)

**Calls:**
- `K0b` (2)
- `F7b` (1)
- `plb` (1)

### `documentText`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:552` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `escapeXml` (1)

### `dHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2035` | Self: 0.0% (0us) | Total: 2.8% (110.9ms) | Samples: 0

**Called by:**
- `e6b` (52)

**Calls:**
- `_lb` (50)
- `VWb` (1)
- `VWb` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:313` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `displayText` (1)

### `sYb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1336` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `sZb` (1)

**Calls:**
- `oYb` (1)

### `extractInitDirectives`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:1112` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `preprocessMermaidSource` (1)

**Calls:**
- `mermaidInitDirectives` (1)

### `iHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 2.8% (107.8ms) | Samples: 0

**Called by:**
- `_lb` (50)

**Calls:**
- `gHb` (50)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/zenuml/native-parser.ts:13` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Calls:**
- `RegExp` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` | Self: 0.0% (0us) | Total: 0.4% (17.6ms) | Samples: 0

**Called by:**
- `map` (11)

**Calls:**
- `expandLocalReferences` (8)
- `map` (2)
- `expandLocalReferences` (1)

### `internal:streams/operators`
`internal:streams/operators:2` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `Crb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4568` | Self: 0.0% (0us) | Total: 0.4% (18.5ms) | Samples: 0

**Called by:**
- `Drb` (4)
- `ijd` (1)
- `evc` (1)

**Calls:**
- `Erb` (2)
- `teb` (2)
- `kDb` (1)
- `JD` (1)

### `walk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1749` | Self: 0.0% (0us) | Total: 0.4% (19.1ms) | Samples: 0

**Called by:**
- `walk` (4)
- `visit` (1)

**Calls:**
- `walk` (4)
- `walk` (1)

### `Z6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2315` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `k7b` (1)

**Calls:**
- `e7b` (1)

### `$xb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4288` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `uyb` (1)

**Calls:**
- `Yxb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:186` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `createExtensionIdentity` (1)

### `absentPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:102` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `textPaints` (1)

**Calls:**
- `tryParseCssColor` (1)

### `xmlParserList`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:129` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (1)

**Calls:**
- `create` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:3` | Self: 0.0% (0us) | Total: 1.0% (39.4ms) | Samples: 0

**Calls:**
- `bound require` (25)

### `ypd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6076` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `o_b` (2)

**Calls:**
- `oKd` (1)
- `Uwd` (1)

### `normalizedErText`
`/tmp/pr449-main-integration-20261029-762/src/er/text.ts:87` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `erDisplayText` (1)

**Calls:**
- `normalizeBrTags` (1)

### `Bkd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4360` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `gjd` (1)

**Calls:**
- `Ckd` (1)

### `xe`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4085` | Self: 0.0% (0us) | Total: 2.6% (102.2ms) | Samples: 0

**Called by:**
- `Otb` (15)
- `Ge` (1)

**Calls:**
- `isb` (12)
- `ILd` (2)
- `lkb` (1)
- `kKd` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:617` | Self: 0.0% (0us) | Total: 0.2% (8.0ms) | Samples: 0

**Called by:**
- `group` (4)
- `createFixture` (1)

**Calls:**
- `ensureSvgIdentity` (3)
- `ensureSvgIdentity` (2)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `markerTerminalDepth` (2)

**Calls:**
- `pathBounds` (1)
- `pathBounds` (1)

### `YGb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6039` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `NGb` (2)

**Calls:**
- `dGb` (1)
- `gGb` (1)

### `iKb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5383` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `gHb` (1)

**Calls:**
- `yIb` (1)

### `gBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4114` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `yIb` (2)

**Calls:**
- `fBb` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:179` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `displayRunAttributes` (1)

### `o_b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6317` | Self: 0.0% (0us) | Total: 0.2% (8.6ms) | Samples: 0

**Called by:**
- `p_b` (5)

**Calls:**
- `Rud` (2)
- `ypd` (2)
- `MEd` (1)

### `qGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5356` | Self: 0.0% (0us) | Total: 0.1% (4.6ms) | Samples: 0

**Called by:**
- `AGc` (4)

**Calls:**
- `jIc` (4)

### `rId`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3812` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `SId` (1)

**Calls:**
- `Esd` (1)

### `Vdd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `HGd` (1)

**Calls:**
- `rYb` (1)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:473` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `diagramColorVariables` (1)

**Calls:**
- `join` (1)

### `sJd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4645` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `Kzd` (1)
- `awd` (1)

**Calls:**
- `MFd` (2)

### `measureTextWidth`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:206` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `measureText` (1)
- `measureText` (1)

### `yyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4942` | Self: 0.0% (0us) | Total: 3.6% (139.6ms) | Samples: 0

**Called by:**
- `_8d` (39)
- `hzd` (2)

**Calls:**
- `hxd` (41)

### `ensureSvgIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:82` | Self: 0.0% (0us) | Total: 0.1% (4.1ms) | Samples: 0

**Called by:**
- `group` (2)

**Calls:**
- `startsWith` (2)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1301` | Self: 0.0% (0us) | Total: 0.3% (12.6ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (7)

**Calls:**
- `finalizeErRelationshipLabels` (7)

### `t1d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `vGd` (1)

**Calls:**
- `i1d` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:153` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `stringify` (1)

### `inspectOwnedSvgOnce`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:46` | Self: 0.0% (0us) | Total: 10.7% (414.0ms) | Samples: 0

**Called by:**
- `applyOutputSecurityPolicy` (25)
- `verifyNoExternalRefs` (2)
- `svgRootStartTag` (1)

**Calls:**
- `(anonymous)` (21)
- `inspectSecurityTail` (1)
- `inspectSecurity` (1)
- `(anonymous)` (1)
- `inspectSecurityTail` (1)
- `inspectSecurityTail` (1)
- `scanStartTags` (1)
- `inspectSecurity` (1)

### `NGb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5952` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `_Dc` (4)

**Calls:**
- `YGb` (2)
- `XGb` (1)
- `SGb` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:101` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `shape` (2)

**Calls:**
- `relationAccessibility` (2)

### `BKd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `kKd` (1)

**Calls:**
- `zKd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:597` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `roleStyleJsonSchema` (1)

### `$lb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4223` | Self: 0.0% (0us) | Total: 0.1% (6.1ms) | Samples: 0

**Called by:**
- `lbd` (2)
- `dGb` (1)
- `OIc` (1)

**Calls:**
- `Pe` (2)
- `EGb` (1)
- `mDb` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:200` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `renderEntityBox` (2)

**Calls:**
- `legibleInk` (1)
- `ensureContrast` (1)

### `acd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2966` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `AQb` (1)

**Calls:**
- `ubd` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:279` | Self: 0.0% (0us) | Total: 0.3% (12.9ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (4)

**Calls:**
- `toneOnFill` (3)
- `toneOnFill` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:840` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Called by:**
- `write` (2)

**Calls:**
- `isRetainedPixelText` (1)
- `isRetainedPixelText` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:14` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `measureText`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:183` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureTextWidth` (1)

**Calls:**
- `textBaseRatio` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:140` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Calls:**
- `graphicalBackendCapabilityClaims` (1)
- `graphicalBackendCapabilityClaims` (1)

### `layoutElkGraph`
`/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts:167` | Self: 0.0% (0us) | Total: 17.1% (662.2ms) | Samples: 0

**Called by:**
- `measureRenderStage` (333)

**Calls:**
- `(anonymous)` (333)

### `TWd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `XEd` (3)

**Calls:**
- `qJd` (3)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:237` | Self: 0.0% (0us) | Total: 0.2% (10.6ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (3)

**Calls:**
- `toneOnFill` (2)
- `toneOnFill` (1)

### `VBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1652` | Self: 0.0% (0us) | Total: 0.3% (12.5ms) | Samples: 0

**Called by:**
- `gHb` (3)
- `DQb` (2)
- `R6b` (2)
- `Abd` (1)

**Calls:**
- `rwb` (5)
- `_vb` (2)
- `Dk` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:291` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `ownConnectorEndpoint` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:722` | Self: 0.0% (0us) | Total: 0.2% (7.8ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (3)

**Calls:**
- `paintAttributes` (3)

### `connectorProjectedField`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:485` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `drawn` (1)

### `Pvb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3336` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `wGc` (1)

**Calls:**
- `Pcb` (1)

### `DWb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5128` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `KFc` (1)

**Calls:**
- `UXb` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:800` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `write` (2)

**Calls:**
- `validateMarkAttributes` (1)
- `validateMarkAttributes` (1)

### `erTextLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/text.ts:107` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `relationshipFrom` (1)

**Calls:**
- `erDisplayText` (1)

### `kn`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Gub` (1)

**Calls:**
- `bn` (1)

### `Fk`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `yCb` (1)

**Calls:**
- `bwb` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1709` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `admitRenderOptionsInput` (1)

### `inspectSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:673` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `startTags` (1)

### `layoutErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1128` | Self: 0.0% (0us) | Total: 0.2% (11.4ms) | Samples: 0

**Called by:**
- `layout` (9)

**Calls:**
- `measureErEntities` (7)
- `measureErEntities` (2)

### `IBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5924` | Self: 0.0% (0us) | Total: 0.1% (4.3ms) | Samples: 0

**Called by:**
- `VAd` (1)

**Calls:**
- `bBd` (1)

### `finalizeErRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:28` | Self: 0.0% (0us) | Total: 0.3% (12.6ms) | Samples: 0

**Called by:**
- `finishErGeometry` (7)

**Calls:**
- `placeRelationshipLabels` (2)
- `placeRelationshipLabels` (2)
- `placeRelationshipLabels` (1)
- `placeRelationshipLabels` (1)
- `placeRelationshipLabels` (1)

### `find`
`[native code]` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `validateDescriptor` (3)
- `(anonymous)` (1)
- `validateDescriptor` (1)

**Calls:**
- `detectorClaims` (4)
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `registerBuiltInStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:294` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `registerCanonicalStyle` (1)
- `registerCanonicalStyle` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:113` | Self: 0.0% (0us) | Total: 0.1% (3.9ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `snapshot` (1)

### `jmb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3645` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `Xu` (1)

**Calls:**
- `Wlb` (1)

### `bjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2919` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `lNb` (2)
- `KKd` (1)

**Calls:**
- `vsb` (2)
- `Wd` (1)

### `normalizeBrTags`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:25` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `normalizedErText` (1)

**Calls:**
- `normalizePlainLabel` (1)

### `roleStyleJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:495` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `rolePropertyJsonSchemas` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:829` | Self: 0.0% (0us) | Total: 0.9% (36.1ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (3)

**Calls:**
- `connectorInlineLabelSvg` (1)
- `connectorInlineLabelSvg` (1)
- `connectorInlineLabelSvg` (1)

### `_ib`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2837` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `mNb` (1)

**Calls:**
- `vsb` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1763` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `has` (1)

### `kDb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2355` | Self: 0.0% (0us) | Total: 0.1% (6.3ms) | Samples: 0

**Called by:**
- `crb` (1)
- `Crb` (1)

**Calls:**
- `sDb` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:8` | Self: 0.0% (0us) | Total: 0.4% (17.1ms) | Samples: 0

**Called by:**
- `anonymous` (11)

**Calls:**
- `bound require` (11)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:88` | Self: 0.0% (0us) | Total: 0.1% (6.7ms) | Samples: 0

**Called by:**
- `visit` (4)

**Calls:**
- `observe` (4)

### `elkPlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1178` | Self: 0.0% (0us) | Total: 22.7% (875.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (486)

**Calls:**
- `measureRenderStage` (486)

### `qyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4180` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `W8d` (1)
- `ezd` (1)

**Calls:**
- `YEd` (2)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1679` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `textSurfaces` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:310` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `validateMarker` (1)

**Calls:**
- `localPaintResourceId` (1)

### `parseEncodeTrie`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js:41` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `readDiff` (1)
- `readDiff` (1)

### `Grb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2741` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `Mrb` (1)

**Calls:**
- `JD` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:665` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `ELKNode`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6570` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `ensureElk` (1)

**Calls:**
- `_callSuper` (1)

### `ensureStyledEntity`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:838` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `parseErDiagram` (1)

**Calls:**
- `ensureEntity` (1)

### `cEc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.4% (15.6ms) | Samples: 0

**Called by:**
- `nQb` (9)

**Calls:**
- `_Dc` (9)

### `dGb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4382` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `YGb` (1)

**Calls:**
- `$lb` (1)

### `rJd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5517` | Self: 0.0% (0us) | Total: 0.4% (17.2ms) | Samples: 0

**Called by:**
- `UWd` (11)

**Calls:**
- `NFd` (5)
- `yXd` (3)
- `WXd` (1)
- `gce` (1)
- `DXd` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:219` | Self: 0.0% (0us) | Total: 0.1% (5.5ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `finish` (2)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1267` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (3)

**Calls:**
- `validateConnectorProjectionConsistency` (1)
- `validateConnectorProjectionConsistency` (1)
- `validateConnectorProjectionConsistency` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/c4/config.ts:71` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `internal:errors`
`internal:errors:2` | Self: 0.0% (0us) | Total: 0.2% (10.4ms) | Samples: 0

**Called by:**
- `anonymous` (5)

**Calls:**
- `anonymous` (5)

### `renderCardinality`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:589` | Self: 0.0% (0us) | Total: 2.2% (86.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (35)

**Calls:**
- `group` (11)
- `group` (7)
- `crowsFootMark` (7)
- `group` (2)
- `group` (2)
- `group` (1)
- `group` (1)
- `crowsFootMark` (1)
- `group` (1)
- `group` (1)
- `group` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:776` | Self: 0.0% (0us) | Total: 0.1% (3.9ms) | Samples: 0

**Called by:**
- `write` (1)
- `node` (1)

**Calls:**
- `stringify` (1)
- `add` (1)

### `finiteNumber`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:175` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `svgPathDataProblem` (1)

**Calls:**
- `skipSeparators` (1)

### `Ycb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3321` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `wQd` (1)

**Calls:**
- `rD` (1)

### `fzd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6506` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `hzd` (4)

**Calls:**
- `Cyd` (2)
- `iyd` (1)
- `wyd` (1)

### `K0b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5530` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `E7b` (2)

**Calls:**
- `L0b` (2)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1821` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `deferredRequestReceiptDigest` (1)

### `measureRenderStage`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:34` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

**Calls:**
- `freeze` (1)

### `_xc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6503` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `evc` (1)

**Calls:**
- `cyc` (1)

### `Izb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (8.9ms) | Samples: 0

**Called by:**
- `ed` (1)

**Calls:**
- `clb` (1)

### `cnb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5372` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `bnb` (1)

**Calls:**
- `_mb` (1)

### `avd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 4.7% (183.2ms) | Samples: 0

**Called by:**
- `OBd` (74)

**Calls:**
- `Rud` (74)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:34` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)
- `build` (2)

**Calls:**
- `chargeInkSort` (4)

### `sBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3732` | Self: 0.0% (0us) | Total: 4.7% (184.4ms) | Samples: 0

**Called by:**
- `TCd` (75)

**Calls:**
- `OBd` (75)

### `DGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4076` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `AGc` (1)

**Calls:**
- `iIc` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `stringify` (1)

### `_Bb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3794` | Self: 0.0% (0us) | Total: 0.2% (8.9ms) | Samples: 0

**Called by:**
- `PBb` (5)

**Calls:**
- `rwb` (5)

### `cBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5045` | Self: 0.0% (0us) | Total: 0.2% (8.1ms) | Samples: 0

**Called by:**
- `UBd` (3)

**Calls:**
- `$Bd` (2)
- `Rse` (1)

### `Xu`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2228` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `rXb` (1)

**Calls:**
- `jmb` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:107` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (1)

**Calls:**
- `connectorTerminalStrokeLosses` (1)

### `VNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6025` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `UNc` (1)

**Calls:**
- `Dl` (1)

### `renderRelationshipLine`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:443` | Self: 0.0% (0us) | Total: 0.1% (4.3ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (2)

**Calls:**
- `endpointOwner` (2)

### `connectorInlineLabelSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:781` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `renderMultilineText` (1)

### `renderCardinality`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:590` | Self: 0.0% (0us) | Total: 2.4% (95.8ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (36)

**Calls:**
- `crowsFootMark` (10)
- `group` (8)
- `group` (7)
- `group` (3)
- `group` (2)
- `group` (1)
- `crowsFootMark` (1)
- `crowsFootMark` (1)
- `group` (1)
- `group` (1)
- `crowsFootMark` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1185` | Self: 0.0% (0us) | Total: 1.0% (39.1ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (18)

**Calls:**
- `extractErLayout` (10)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts:3` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Calls:**
- `Segmenter` (3)

### `Gzip`
`node:zlib:328` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `gzipSync` (1)

**Calls:**
- `Zlib` (1)

### `jdb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5091` | Self: 0.0% (0us) | Total: 0.3% (14.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (11)

**Calls:**
- `(anonymous)` (11)

### `qQc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6292` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `mQc` (1)

**Calls:**
- `JD` (1)

### `lzd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5707` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `JEd` (1)

**Calls:**
- `izd` (1)

### `Ac`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `kQc` (1)

**Calls:**
- `xc` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:405` | Self: 0.0% (0us) | Total: 5.6% (217.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `xmlSlice` (1)

### `consumeResolvedGraphicalRequest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:316` | Self: 0.0% (0us) | Total: 70.4% (2.71s) | Samples: 0

**Called by:**
- `withSvgInspectionCache` (1038)

**Calls:**
- `renderResolvedMermaidSVG` (559)
- `withTextMeasurementExecution` (479)

### `mDd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2857` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `ete` (3)

**Calls:**
- `BBd` (3)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:4` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `Otb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2701` | Self: 0.0% (0us) | Total: 2.7% (104.9ms) | Samples: 0

**Called by:**
- `dFd` (17)

**Calls:**
- `xe` (15)
- `ltb` (2)

### `LFd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4883` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `cGd` (3)

**Calls:**
- `dZd` (1)
- `jGd` (1)
- `Kmb` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:220` | Self: 0.0% (0us) | Total: 0.3% (15.3ms) | Samples: 0

**Called by:**
- `copyInner` (7)

**Calls:**
- `copyInner` (7)

### `TCd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 4.7% (184.4ms) | Samples: 0

**Called by:**
- `Efb` (75)

**Calls:**
- `sBd` (75)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:745` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `finish` (1)

### `lDd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (9.9ms) | Samples: 0

**Called by:**
- `dte` (5)

**Calls:**
- `SBd` (5)

### `parseHex`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:28` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `mixHex` (1)

**Calls:**
- `parseInt` (1)

### `CGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (7.4ms) | Samples: 0

**Called by:**
- `vGd` (3)

**Calls:**
- `tud` (1)
- `p1d` (1)
- `V0d` (1)

### `resolveDiagramColors`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:52` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `resolveAppearance` (1)

**Calls:**
- `themePaint` (1)

### `crowsFootMark`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:628` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `renderCardinality` (1)

**Calls:**
- `map` (1)

### `appendPrivate`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:55` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `defineProperty` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:420` | Self: 0.0% (0us) | Total: 0.4% (17.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `readXmlDataEnd` (1)
- `readXmlDataEnd` (1)
- `readXmlDataEnd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1245` | Self: 0.0% (0us) | Total: 0.3% (15.2ms) | Samples: 0

**Called by:**
- `map` (8)

**Calls:**
- `erCardinalityInk` (6)
- `erCardinalityInk` (1)
- `erCardinalityInk` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:313` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `extractErLayout` (2)

**Calls:**
- `enoughLead` (2)

### `gzipSync`
`node:zlib:360` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `Gzip` (1)
- `Gzip` (1)

### `r`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 2.3% (91.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `o` (1)

### `zEc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3581` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `AEc` (1)

**Calls:**
- `DEc` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:114` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `createNativeSceneValidator` (1)

### `Agc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `yGc` (1)

**Calls:**
- `ngc` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1216` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `push` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:601` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `u7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5599` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `D7b` (1)

**Calls:**
- `y7b` (1)

### `n0b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `nQb` (1)

**Calls:**
- `k0b` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:32` | Self: 0.0% (0us) | Total: 0.4% (17.1ms) | Samples: 0

**Calls:**
- `consume` (6)
- `consume` (5)
- `consume` (1)
- `stringify` (1)

### `Qud`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3681` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `VAd` (1)

**Calls:**
- `SLd` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:407` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `has` (1)

### `mNb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2252` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `OWb` (1)

**Calls:**
- `_ib` (1)

### `SId`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `qJd` (1)

**Calls:**
- `rId` (1)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1682` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `renderContractDigest` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/encode-html.js:10` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Calls:**
- `parseEncodeTrie` (2)

### `findErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:698` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `readErStatements` (1)

**Calls:**
- `readErOuterStatements` (1)

### `oQc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5143` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `mQc` (2)

**Calls:**
- `QOc` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6511` | Self: 0.0% (0us) | Total: 0.3% (14.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (11)

**Calls:**
- `jdb` (11)

### `AQb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5029` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `EQb` (3)

**Calls:**
- `Q5b` (1)
- `acd` (1)
- `Xbd` (1)

### `ELKNode`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6564` | Self: 0.0% (0us) | Total: 5.0% (196.3ms) | Samples: 0

**Called by:**
- `ensureElk` (140)

**Calls:**
- `(anonymous)` (140)

### `writeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `map` (1)

### `reserve`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:47` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `nativeAttributeValue` (1)

**Calls:**
- `pay` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3550` | Self: 0.0% (0us) | Total: 0.3% (14.1ms) | Samples: 0

**Called by:**
- `jdb` (11)

**Calls:**
- `Mz` (11)

### `wwd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5669` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `HEd` (1)

**Calls:**
- `Rsd` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:993` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `serializeLinearGradientResources` (1)

### `textPaints`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:119` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `nonPainting` (1)

**Calls:**
- `absentPaint` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:662` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `SvgWriter` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:98` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `leaf` (1)

### `VAd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6163` | Self: 0.0% (0us) | Total: 0.2% (9.9ms) | Samples: 0

**Called by:**
- `SBd` (5)

**Calls:**
- `ate` (3)
- `Qud` (1)
- `IBd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:330` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `get receipt` (2)

**Calls:**
- `receiptOf` (1)
- `receiptOf` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:314` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `relationAccessibility` (1)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:36` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `captureNativeGroupParse` (1)

**Calls:**
- `test` (1)

### `inlineResolvedColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:636` | Self: 0.0% (0us) | Total: 0.1% (6.4ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (3)

**Calls:**
- `colorResolution` (3)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:672` | Self: 0.0% (0us) | Total: 7.0% (269.9ms) | Samples: 0

**Called by:**
- `leaf` (85)

**Calls:**
- `serialize` (84)
- `serialize` (1)

### `o8b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6246` | Self: 0.0% (0us) | Total: 0.2% (8.3ms) | Samples: 0

**Called by:**
- `A6b` (3)

**Calls:**
- `Bc` (1)
- `lZb` (1)
- `Wtb` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:195` | Self: 0.0% (0us) | Total: 0.3% (14.2ms) | Samples: 0

**Called by:**
- `renderEntityBox` (3)
- `renderEntityBox` (1)

**Calls:**
- `resolvedColorValue` (3)
- `resolvedColorValue` (1)

### `measureText`
`/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts:188` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureTextWidth` (1)

**Calls:**
- `getCharWidth` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1473` | Self: 0.0% (0us) | Total: 0.7% (27.9ms) | Samples: 0

**Called by:**
- `serialize` (2)

**Calls:**
- `boundedUtf8ByteLength` (2)

### `Gub`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4143` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `lcd` (2)

**Calls:**
- `kn` (1)
- `ho` (1)

### `buildStyleBlock`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:357` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `isPlainFontFamily` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1520` | Self: 0.0% (0us) | Total: 0.1% (6.0ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (2)

**Calls:**
- `intersects` (1)
- `intersects` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:719` | Self: 0.0% (0us) | Total: 0.5% (22.7ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `replaceField` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1878` | Self: 0.0% (0us) | Total: 0.3% (13.5ms) | Samples: 0

**Called by:**
- `(module)` (10)

**Calls:**
- `freezeDescriptor` (4)
- `freezeDescriptor` (1)
- `completeBuiltinDescriptor` (1)
- `completeBuiltinDescriptor` (1)
- `freezeDescriptor` (1)
- `freezeDescriptor` (1)
- `freezeDescriptor` (1)

### `Ar`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4250` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `Xq` (1)

**Calls:**
- `v6b` (1)

### `lQc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5558` | Self: 0.0% (0us) | Total: 0.2% (11.4ms) | Samples: 0

**Called by:**
- `mQc` (7)

**Calls:**
- `PBb` (6)
- `cCb` (1)

### `Yrb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1256` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `ltb` (1)

**Calls:**
- `hjb` (1)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:465` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `validate` (1)

### `node`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1456` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `group` (2)

**Calls:**
- `validateNodeSerialization` (2)

### `normalizeMermaidSourceWithOverrides`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:762` | Self: 0.0% (0us) | Total: 0.2% (8.5ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (6)

**Calls:**
- `normalizeMermaidSource` (2)
- `normalizeSource` (2)
- `normalizeSource` (1)
- `normalizeMermaidSource` (1)

### `createExtensionIdentity`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:246` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)
- `registerCanonicalStyle` (1)

**Calls:**
- `evaluateExtensionCompatibility` (1)
- `evaluateExtensionCompatibility` (1)

### `GGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3246` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `JGd` (1)

**Calls:**
- `KGd` (1)

### `Vvb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3875` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `bwb` (4)
- `tCb` (2)

**Calls:**
- `ACb` (3)
- `qub` (1)
- `Obd` (1)
- `vkb` (1)

### `Lac`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5876` | Self: 0.0% (0us) | Total: 0.1% (7.1ms) | Samples: 0

**Called by:**
- `Nac` (1)

**Calls:**
- `JD` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:10` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `map` (4)

**Calls:**
- `markerTerminalDepth` (4)

### `SBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5223` | Self: 0.0% (0us) | Total: 0.2% (9.9ms) | Samples: 0

**Called by:**
- `lDd` (5)

**Calls:**
- `VAd` (5)

### `kmb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2438` | Self: 0.0% (0us) | Total: 0.1% (4.2ms) | Samples: 0

**Called by:**
- `dFd` (2)
- `iIc` (1)

**Calls:**
- `Pe` (2)
- `mDb` (1)

### `advance`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)
- `(anonymous)` (1)

**Calls:**
- `reduce` (2)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2362` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `contains` (1)

### `V0b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:353` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `L0b` (1)

**Calls:**
- `(unknown)` (1)

### `o_d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `hxd` (1)

**Calls:**
- `pde` (1)

### `flowchartMarkerResources`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:80` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `arrowMarkerResources` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:774` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `node` (1)

**Calls:**
- `validateRole` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:682` | Self: 0.0% (0us) | Total: 0.1% (5.5ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (4)

**Calls:**
- `paintAttributes` (3)
- `paintAttributes` (1)

### `internal:streams/legacy`
`internal:streams/legacy:6` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `(anonymous)` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:431` | Self: 0.0% (0us) | Total: 0.2% (9.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `(anonymous)` (5)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:180` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `possibleShapeFill` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/class/parser.ts:156` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `RegExp` (1)

### `CCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2418` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `ECb` (1)

**Calls:**
- `yCb` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:676` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `preparedInterTextBounds` (1)
- `preparedInterTextBounds` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:90` | Self: 0.0% (0us) | Total: 0.6% (26.3ms) | Samples: 0

**Called by:**
- `visit` (11)

**Calls:**
- `leaf` (11)

### `Yh`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1387` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `ui` (1)

**Calls:**
- `Wc` (1)

### `lQb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5563` | Self: 0.0% (0us) | Total: 7.5% (290.0ms) | Samples: 0

**Called by:**
- `NQb` (153)

**Calls:**
- `nQb` (141)
- `DQb` (7)
- `gVb` (3)
- `aod` (1)
- `gVb` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1221` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `canonicalErContacts` (1)

### `visitSvgFirstTagAttributes`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:106` | Self: 0.0% (0us) | Total: 0.6% (24.1ms) | Samples: 0

**Called by:**
- `checkInertGroup` (9)

**Calls:**
- `scanStartTags` (3)
- `scanStartTags` (2)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `ho`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `Gub` (1)

**Calls:**
- `Er` (1)

### `ezd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6286` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `hzd` (1)

**Calls:**
- `qyd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/common/seq.js:4` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `Ncd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `zpd` (2)

**Calls:**
- `Lcd` (1)
- `Lcd` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:174` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `parseInlineFormatting` (1)

### `normalizePlainLabel`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:47` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `normalizeBrTags` (1)

**Calls:**
- `replace` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:346` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `connectorContourSemantics` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:582` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `erFrameInkPadding` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:36` | Self: 0.0% (0us) | Total: 0.1% (6.1ms) | Samples: 0

**Calls:**
- `gzipSync` (2)
- `zlibBufferSync` (2)
- `writeFileSync` (1)

### `snapshotDescriptorArray`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1501` | Self: 0.0% (0us) | Total: 0.2% (9.8ms) | Samples: 0

**Called by:**
- `freezeDescriptor` (4)
- `freezeDescriptor` (1)
- `freezeDescriptor` (1)
- `snapshotFamilyConfig` (1)

**Calls:**
- `snapshotScenePrimitiveCell` (3)
- `(anonymous)` (2)
- `snapshotCapabilityCell` (1)
- `snapshotScenePrimitiveCell` (1)

### `processChunkSync`
`node:zlib:203` | Self: 0.0% (0us) | Total: 0.0% (999us) | Samples: 0

**Called by:**
- `zlibBufferSync` (1)

**Calls:**
- `writeSync` (1)

### `o6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1676` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `s6b` (1)

**Calls:**
- `u6b` (1)

### `QKb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4743` | Self: 0.0% (0us) | Total: 0.2% (10.1ms) | Samples: 0

**Called by:**
- `gHb` (2)

**Calls:**
- `PKb` (2)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:411` | Self: 0.0% (0us) | Total: 2.9% (114.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `add` (2)

### `IEd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4248` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `MEd` (1)

**Calls:**
- `YEd` (1)

### `MEd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5740` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `o_b` (1)

**Calls:**
- `IEd` (1)

### `yrd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `cJb` (1)

**Calls:**
- `Pud` (1)

### `applyOutputSecurityPolicy`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:727` | Self: 0.0% (0us) | Total: 10.7% (412.4ms) | Samples: 0

**Called by:**
- `measureRenderStage` (20)
- `validateSceneDocument` (6)

**Calls:**
- `inspectOwnedSvgOnce` (25)
- `inspectOwnedSvgOnce` (1)

### `Eyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3027` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `X8d` (1)

**Calls:**
- `Dyd` (1)

### `YEd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3717` | Self: 0.0% (0us) | Total: 1.2% (47.2ms) | Samples: 0

**Called by:**
- `kFd` (7)
- `X8d` (4)
- `qyd` (2)
- `wyd` (2)
- `uyd` (2)
- `IEd` (1)
- `rYd` (1)
- `fBd` (1)
- `kWd` (1)
- `vyd` (1)
- `hyd` (1)
- `vGd` (1)

**Calls:**
- `UWd` (11)
- `CZd` (5)
- `jXd` (4)
- `eGd` (4)

### `install`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:40` | Self: 0.0% (0us) | Total: 2.4% (93.4ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (1)

**Calls:**
- `set` (1)

### `paintPrimitiveSource`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:72` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `solidInteriors` (1)

**Calls:**
- `get` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:283` | Self: 0.0% (0us) | Total: 1.6% (64.3ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (23)

**Calls:**
- `leaf` (22)
- `text` (1)

### `internal:streams/destroy`
`internal:streams/destroy:2` | Self: 0.0% (0us) | Total: 0.2% (10.4ms) | Samples: 0

**Called by:**
- `anonymous` (5)

**Calls:**
- `anonymous` (5)

### `bBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3702` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `gCb` (1)

**Calls:**
- `imb` (1)

### `XGb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5141` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `NGb` (1)

**Calls:**
- `ulb` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:284` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `connector` (1)

### `s6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:881` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `S5b` (1)

**Calls:**
- `o6b` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:403` | Self: 0.0% (0us) | Total: 0.3% (13.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `readXmlNameEnd` (1)
- `readXmlNameEnd` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:658` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `parseErRelationshipSyntax`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1075` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `readErStatement` (1)

**Calls:**
- `parseErEntityReference` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:35` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `tree` (1)

**Calls:**
- `sort` (1)

### `validateRole`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:693` | Self: 0.0% (0us) | Total: 0.1% (4.7ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `sceneRoleTraits` (1)

### `erCardinalityInk`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:127` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `every` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1088` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `validatePoint` (1)

### `readErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:739` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `parseErDiagram` (2)

**Calls:**
- `findErStatements` (1)
- `findErStatements` (1)

### `deferredTerminalProjectionInput`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:66` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `hasOwned`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:11` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `copy` (1)

**Calls:**
- `has` (1)

### `OZb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3622` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `MZb` (1)

**Calls:**
- `Hmb` (1)

### `sceneLowering`
`/tmp/pr449-main-integration-20261029-762/src/scene/drawing.ts:18` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `set` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:26` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Calls:**
- `(anonymous)` (2)
- `writeFast` (1)

### `kKd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `xe` (1)

**Calls:**
- `BKd` (1)

### `imb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1255` | Self: 0.0% (0us) | Total: 0.1% (5.7ms) | Samples: 0

**Called by:**
- `RAb` (1)
- `bBb` (1)
- `tCb` (1)

**Calls:**
- `Wlb` (3)

### `awd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5043` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Kzd` (1)

**Calls:**
- `sJd` (1)

### `Ftd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `yXd` (4)

**Calls:**
- `Rsd` (4)

### `fBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3402` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `gBb` (2)

**Calls:**
- `vBb` (1)
- `mwb` (1)

### `node:stream`
`node:stream:2` | Self: 0.0% (0us) | Total: 1.6% (63.7ms) | Samples: 0

**Called by:**
- `anonymous` (27)

**Calls:**
- `anonymous` (27)

### `runMeasuredGraphBackend`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:83` | Self: 0.0% (0us) | Total: 25.3% (974.5ms) | Samples: 0

**Called by:**
- `layout` (541)

**Calls:**
- `(anonymous)` (494)
- `finish` (18)
- `finishErGeometry` (7)
- `finishErGeometry` (5)
- `finishErGeometry` (3)
- `finishErGeometry` (2)
- `finishErGeometry` (2)
- `finishErGeometry` (2)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)

### `pOc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6169` | Self: 0.0% (0us) | Total: 0.7% (28.9ms) | Samples: 0

**Called by:**
- `sOc` (17)

**Calls:**
- `mQc` (17)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:208` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Calls:**
- `expandLocalReferences` (2)
- `(anonymous)` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:717` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `cloneObject` (1)

### `findErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:665` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `readErStatements` (1)

**Calls:**
- `stripTrailingComment` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1572` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `renderContractDigest` (1)

### `localPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1391` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `collectPaintResourceReferences` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:588` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `semanticIdentityForSvg` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` | Self: 0.0% (0us) | Total: 0.2% (8.9ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (4)

**Calls:**
- `geometryAttributes` (2)
- `geometryAttributes` (1)
- `geometryAttributes` (1)

### `DQb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6282` | Self: 0.0% (0us) | Total: 0.2% (9.9ms) | Samples: 0

**Called by:**
- `lQb` (7)

**Calls:**
- `wbd` (3)
- `VBb` (2)
- `eOc` (1)
- `CQb` (1)

### `Fzb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Rc` (1)

**Calls:**
- `vzb` (1)

### `tipAnchoredArrow`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts:33` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `assertRenderableMarker` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:276` | Self: 0.0% (0us) | Total: 0.1% (4.6ms) | Samples: 0

**Called by:**
- `leaf` (3)

**Calls:**
- `append` (2)
- `append` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:252` | Self: 0.0% (0us) | Total: 0.5% (22.8ms) | Samples: 0

**Called by:**
- `leaf` (12)

**Calls:**
- `paintBounds` (2)
- `connectorPaintBounds` (2)
- `paintBounds` (2)
- `paintBounds` (2)
- `paintBounds` (1)
- `connectorPaintBounds` (1)
- `paintBounds` (1)
- `connectorPaintBounds` (1)

### `KKb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5701` | Self: 0.0% (0us) | Total: 0.3% (13.2ms) | Samples: 0

**Called by:**
- `gHb` (7)

**Calls:**
- `JKb` (7)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:7` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `MQb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1322` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `dyc` (4)

**Calls:**
- `qQb` (4)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:181` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `formatSvgNumber` (1)

### `Gtb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3815` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Ktb` (1)

**Calls:**
- `IDb` (1)

### `relativeLuminance`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:78` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `contrastRatio` (1)

**Calls:**
- `tryParseCssColor` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:194` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `min` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6429` | Self: 0.0% (0us) | Total: 0.3% (13.6ms) | Samples: 0

**Called by:**
- `forEach` (11)

**Calls:**
- `(anonymous)` (11)

### `MBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3417` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `$Bd` (1)

**Calls:**
- `xo` (1)

### `sZb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5274` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `HXb` (1)

**Calls:**
- `sYb` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:153` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `outputDescriptorsById` (1)

### `Ykb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `qkb` (1)

**Calls:**
- `kyb` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:240` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (1)

**Calls:**
- `xmlScalarCharacter` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:312` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `extractErLayout` (2)

**Calls:**
- `enoughLead` (2)

### `withSvgInspectionCache`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:20` | Self: 0.0% (0us) | Total: 71.3% (2.74s) | Samples: 0

**Called by:**
- `withRenderStageObserver` (1062)

**Calls:**
- `consumeResolvedGraphicalRequest` (1038)
- `executeInspectedGraphicalRequest` (23)
- `graphicalSvgArtifact` (1)

### `buildErElkGraph`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:491` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `elkPlacement` (4)

**Calls:**
- `erCardinalityEnvelope` (3)
- `reduce` (1)

### `lkb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `xe` (1)

**Calls:**
- `Fjb` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:237` | Self: 0.0% (0us) | Total: 0.2% (9.2ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (5)

**Calls:**
- `scopeSvgStyles` (3)
- `scopeSvgStyles` (1)
- `scopeSvgStyles` (1)

### `connectorInlineLabelText`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:427` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `connectorInlineLabelSvg` (1)

**Calls:**
- `preparePixelText` (1)

### `hasInheritedPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:254` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `observe` (1)

**Calls:**
- `pay` (1)

### `readXmlNameEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:102` | Self: 0.0% (0us) | Total: 0.2% (10.6ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)

**Calls:**
- `xmlAsciiLetter` (1)
- `xmlAsciiLetter` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:405` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureErEntities` (1)

**Calls:**
- `styledRunLayout` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:280` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `connectorInlineLabelSvg` (1)

**Calls:**
- `renderPreparedLine` (1)

### `node`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1453` | Self: 0.0% (0us) | Total: 1.8% (71.6ms) | Samples: 0

**Called by:**
- `group` (28)

**Calls:**
- `validateNode` (24)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `hxd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2249` | Self: 0.0% (0us) | Total: 3.7% (144.8ms) | Samples: 0

**Called by:**
- `yyd` (41)
- `PWd` (3)
- `x2d` (1)

**Calls:**
- `PWd` (40)
- `x2d` (1)
- `qVd` (1)
- `h4d` (1)
- `o_d` (1)
- `iUd` (1)

### `Rsd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4802` | Self: 0.0% (0us) | Total: 0.1% (6.2ms) | Samples: 0

**Called by:**
- `Ftd` (4)
- `wwd` (1)

**Calls:**
- `Kzd` (2)
- `_wd` (1)
- `r0d` (1)
- `IUd` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:643` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `solidInteriors` (1)

**Calls:**
- `inverseMatrix` (1)

### `tCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (8.5ms) | Samples: 0

**Called by:**
- `yCb` (4)
- `dwb` (1)

**Calls:**
- `Vvb` (2)
- `rwb` (1)
- `gmb` (1)
- `imb` (1)

### `AGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6121` | Self: 0.0% (0us) | Total: 0.4% (15.9ms) | Samples: 0

**Called by:**
- `pGc` (10)

**Calls:**
- `IGc` (5)
- `qGc` (4)
- `DGc` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:3` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1591` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `hasImmutablePaintRoster` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1462` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `serialize` (1)

**Calls:**
- `depth` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:127` | Self: 0.0% (0us) | Total: 2.9% (114.9ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (9)

**Calls:**
- `connector` (2)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)
- `connector` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1762` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `checkFamilyConfigColors` (1)

### `U6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6274` | Self: 0.0% (0us) | Total: 0.2% (9.1ms) | Samples: 0

**Called by:**
- `a7b` (4)

**Calls:**
- `R6b` (3)
- `V6b` (1)

### `BIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6071` | Self: 0.0% (0us) | Total: 0.2% (9.6ms) | Samples: 0

**Called by:**
- `HKb` (5)
- `jKb` (1)
- `LIb` (1)

**Calls:**
- `CIb` (5)
- `LIb` (1)
- `aIb` (1)

### `jKb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5384` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `gHb` (3)

**Calls:**
- `yIb` (1)
- `zIb` (1)
- `BIb` (1)

### `msd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1534` | Self: 0.0% (0us) | Total: 4.6% (178.6ms) | Samples: 0

**Called by:**
- `ysd` (70)

**Calls:**
- `hzd` (70)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1737` | Self: 0.0% (0us) | Total: 0.2% (8.5ms) | Samples: 0

**Called by:**
- `measureRenderStage` (6)

**Calls:**
- `normalizeMermaidSourceWithOverrides` (6)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:176` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

**Calls:**
- `svgRootStartTag` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1029` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `validatePoint` (1)

### `t6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (5.3ms) | Samples: 0

**Called by:**
- `nQb` (3)

**Calls:**
- `q6b` (3)

### `vsb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2743` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `bjb` (2)
- `kQc` (1)
- `_ib` (1)

**Calls:**
- `asb` (3)
- `usb` (1)

### `Dyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4148` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `Cyd` (3)
- `Eyd` (1)

**Calls:**
- `FVd` (3)
- `Wxd` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:128` | Self: 0.0% (0us) | Total: 7.8% (302.1ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (124)

**Calls:**
- `renderEntityBox` (27)
- `renderEntityBox` (23)
- `group` (11)
- `renderEntityBox` (11)
- `group` (10)
- `renderEntityBox` (8)
- `renderEntityBox` (7)
- `group` (4)
- `renderEntityBox` (4)
- `group` (3)
- `group` (3)
- `renderEntityBox` (3)
- `group` (2)
- `renderEntityBox` (2)
- `group` (2)
- `group` (1)
- `renderEntityBox` (1)
- `renderEntityBox` (1)
- `renderEntityBox` (1)

### `JHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4389` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `DIb` (1)

**Calls:**
- `$Hb` (1)

### `internal:primordials`
`internal:primordials:54` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `createSafeIterator` (1)
- `uncurryThis` (1)

### `kYd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `qJd` (1)

**Calls:**
- `cYd` (1)

### `textSurfaces`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1651` | Self: 0.0% (0us) | Total: 0.4% (18.0ms) | Samples: 0

**Called by:**
- `textSurfaces` (4)
- `certifyNativePaint` (1)

**Calls:**
- `textSurfaces` (4)
- `textSurfaces` (1)

### `N$b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6487` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `I$b` (5)

**Calls:**
- `HXb` (3)
- `lNb` (1)
- `BWb` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:264` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `freeze` (1)

### `snapshotScenePrimitiveCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1548` | Self: 0.0% (0us) | Total: 0.1% (3.8ms) | Samples: 0

**Called by:**
- `snapshotDescriptorArray` (3)

**Calls:**
- `freeze` (2)
- `snapshotDescriptorArray` (1)

### `q6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6309` | Self: 0.0% (0us) | Total: 0.1% (5.3ms) | Samples: 0

**Called by:**
- `t6b` (3)

**Calls:**
- `Jjb` (1)
- `JD` (1)
- `Xq` (1)

### `PBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3518` | Self: 0.0% (0us) | Total: 0.2% (10.0ms) | Samples: 0

**Called by:**
- `lQc` (6)

**Calls:**
- `_Bb` (5)
- `RAb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:328` | Self: 0.0% (0us) | Total: 0.1% (3.8ms) | Samples: 0

**Called by:**
- `get receipt` (3)

**Calls:**
- `canonicalTextDigest` (1)
- `renderedSvgDigest` (1)
- `canonicalTextDigest` (1)

### `snapshot`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1318` | Self: 0.0% (0us) | Total: 0.2% (8.1ms) | Samples: 0

**Called by:**
- `finishErGeometry` (4)

**Calls:**
- `flatIntoArrayWithCallback` (4)

### `Ajb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4072` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `Fjb` (1)

**Calls:**
- `Esb` (1)

### `enoughLead`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:300` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `repairErFrameRoutes` (2)
- `repairErFrameRoutes` (2)

**Calls:**
- `erCardinalityInk` (2)
- `erCardinalityInk` (2)

### `captureNativeGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:103` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `groupValidation` (1)

**Calls:**
- `emissionRecord` (1)

### `svgRootStartTag`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:202` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `scopeSvgStyles` (1)

**Calls:**
- `inspectOwnedSvgOnce` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/addPairToJSMap.js:4` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `parseErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:832` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `layout` (3)

**Calls:**
- `readErStatements` (2)
- `readErStatements` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:14` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1739` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `normalizeMermaidSource` (2)

**Calls:**
- `classifyMermaidFamilyDescriptorFromFirstLine` (2)

### `pde`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `o_d` (1)

**Calls:**
- `xce` (1)

### `ctb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2833` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `Imb` (1)

**Calls:**
- `HQb` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:291` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `extractErLayout` (1)

**Calls:**
- `resolveRoleStyle` (1)

### `layout`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:23` | Self: 0.0% (0us) | Total: 0.1% (6.9ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (5)

**Calls:**
- `parseErDiagram` (3)
- `parseErDiagram` (1)
- `parseErDiagram` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:539` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `cLb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4995` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `gHb` (2)

**Calls:**
- `bLb` (2)

### `OBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4755` | Self: 0.0% (0us) | Total: 4.7% (184.4ms) | Samples: 0

**Called by:**
- `sBd` (75)

**Calls:**
- `avd` (74)
- `ddd` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/default-backend.ts:5` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Calls:**
- `registerBuiltInBackend` (1)

### `parseErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:902` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `ensureStyledEntity` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:156` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `paintPrimitiveSource` (1)

### `detectRegisteredFamilyDescriptorFromFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:2083` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `detectInstalledFamilyDescriptorFromFirstLine` (2)

**Calls:**
- `from` (1)
- `sort` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:194` | Self: 0.0% (0us) | Total: 0.1% (4.2ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (1)

**Calls:**
- `calculatePathMidpoint` (1)

### `uyb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Rc` (1)

**Calls:**
- `$xb` (1)

### `FIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4733` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `AKb` (1)

**Calls:**
- `SC` (1)

### `Esd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `rId` (1)

**Calls:**
- `zsd` (1)

### `bwb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (5.7ms) | Samples: 0

**Called by:**
- `nCb` (3)
- `Fk` (1)

**Calls:**
- `Vvb` (4)

### `x$d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `UHd` (3)

**Calls:**
- `p$d` (3)

### `bound require`
`[native code]` | Self: 0.0% (0us) | Total: 14.1% (544.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (25)
- `(anonymous)` (20)
- `(anonymous)` (11)
- `(anonymous)` (8)
- `(anonymous)` (5)
- `(anonymous)` (5)
- `(anonymous)` (4)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

**Calls:**
- `require` (130)

### `internal:fs/streams`
`internal:fs/streams:2` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1468` | Self: 0.0% (0us) | Total: 2.3% (88.8ms) | Samples: 0

**Called by:**
- `serialize` (38)

**Calls:**
- `validateNode` (5)
- `validateNode` (4)
- `validateNode` (3)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (2)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `xo`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5921` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `MBd` (1)

**Calls:**
- `Vcb` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:763` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `set` (1)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1655` | Self: 0.0% (0us) | Total: 0.1% (3.9ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (2)

**Calls:**
- `resolveDiagramColors` (1)
- `resolveDiagramColors` (1)

### `Jr`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `zc` (1)

**Calls:**
- `Zb` (1)

### `hjd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:920` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `gdd` (4)

**Calls:**
- `gjd` (4)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1584` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `snapshotDescriptorArray` (1)

### `consume`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:15` | Self: 0.0% (0us) | Total: 0.1% (7.2ms) | Samples: 0

**Called by:**
- `(module)` (6)

**Calls:**
- `stringify` (6)

### `semanticIdentityForSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:56` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `filter` (1)

### `render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:146` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `rendered` (1)

**Calls:**
- `pageRectFor` (1)

### `AKd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2214` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `CYd` (2)

**Calls:**
- `fKd` (2)

### `L$d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `OHd` (1)

**Calls:**
- `rWd` (1)

### `qQb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3348` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `MQb` (4)

**Calls:**
- `EQb` (4)

### `bnb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3751` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `dnb` (2)

**Calls:**
- `cnb` (1)
- `slice` (1)

### `SCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `wCb` (1)

**Calls:**
- `NCb` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:312` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `filter` (1)

### `lZb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3303` | Self: 0.0% (0us) | Total: 0.1% (5.8ms) | Samples: 0

**Called by:**
- `o8b` (1)

**Calls:**
- `cgd` (1)

### `Qr`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `Nr` (1)

**Calls:**
- `El` (1)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:710` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `consumeStringBudget` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1386` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (1)

**Calls:**
- `(anonymous)` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1782` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (2)

**Calls:**
- `visit` (1)
- `visit` (1)

### `mermaidFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:149` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `normalizeMermaidSource` (1)

**Calls:**
- `matchMermaidFrontmatter` (1)

### `dFd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3207` | Self: 0.0% (0us) | Total: 2.8% (108.9ms) | Samples: 0

**Called by:**
- `$Ed` (20)

**Calls:**
- `Otb` (17)
- `kmb` (2)
- `Te` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:252` | Self: 0.0% (0us) | Total: 10.2% (394.0ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (20)

**Calls:**
- `measureRenderStage` (20)

### `KKd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3969` | Self: 0.0% (0us) | Total: 0.1% (5.9ms) | Samples: 0

**Called by:**
- `FXd` (2)
- `the` (1)

**Calls:**
- `bjb` (1)
- `SC` (1)
- `JD` (1)

### `$rb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1967` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `jNb` (1)

**Calls:**
- `Ld` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:156` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (1)

**Calls:**
- `isAsciiXmlNameChar` (1)

### `ACb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (3.6ms) | Samples: 0

**Called by:**
- `Vvb` (3)

**Calls:**
- `wCb` (3)

### `hMd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5046` | Self: 0.0% (0us) | Total: 0.4% (18.0ms) | Samples: 0

**Called by:**
- `Rud` (8)
- `gyd` (2)

**Calls:**
- `kFd` (6)
- `tb` (2)
- `MTd` (1)
- `RTd` (1)

### `ibd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4754` | Self: 0.0% (0us) | Total: 9.3% (361.8ms) | Samples: 0

**Called by:**
- `lbd` (194)

**Calls:**
- `NQb` (190)
- `yqd` (4)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/builtin-backends.ts:20` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Calls:**
- `registerBuiltInBackend` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:357` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `connectorGeometryHasCurves` (1)

### `classifyMermaidFamilyDescriptorFromFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/family-detection.ts:39` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `detectInstalledFamilyDescriptorFromFirstLine` (2)

### `Abd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4237` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `wbd` (2)

**Calls:**
- `VBb` (1)
- `dCb` (1)

### `_lb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3916` | Self: 0.0% (0us) | Total: 2.8% (107.8ms) | Samples: 0

**Called by:**
- `dHb` (50)

**Calls:**
- `iHb` (50)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:316` | Self: 0.0% (0us) | Total: 0.1% (4.2ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `numericCss` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1879` | Self: 0.0% (0us) | Total: 0.4% (15.8ms) | Samples: 0

**Called by:**
- `(module)` (12)

**Calls:**
- `validateDescriptor` (3)
- `validateDescriptor` (2)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)

### `dPc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5348` | Self: 0.0% (0us) | Total: 0.1% (6.9ms) | Samples: 0

**Called by:**
- `kQc` (3)
- `dPc` (1)

**Calls:**
- `sPc` (1)
- `dPc` (1)
- `fPc` (1)
- `Xr` (1)

### `registerBuiltInStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:292` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `freeze` (1)
- `limitJsonConfigDiagnostics` (1)

### `cCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3269` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `lQc` (1)

**Calls:**
- `dCb` (1)

### `dnb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2739` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `gmb` (2)

**Calls:**
- `bnb` (2)

### `applyFamilyRequestNormalization`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1075` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `resolveAppearance` (1)

**Calls:**
- `assertFamilyGeometryOptions` (1)

### `pointsBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:16` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `geometryBounds` (1)
- `markerTerminalDepth` (1)

**Calls:**
- `map` (2)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1944` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `connectorMarkerPaintRegions` (1)

### `Qc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3605` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `PKb` (1)

**Calls:**
- `Qkb` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:92` | Self: 0.0% (0us) | Total: 0.3% (11.8ms) | Samples: 0

**Called by:**
- `inspectPaint` (5)

**Calls:**
- `observe` (2)
- `observe` (1)
- `observe` (1)
- `observe` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:74` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `hashId` (1)

### `Q5b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6494` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `AQb` (1)

**Calls:**
- `R5b` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:259` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `freeze` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:213` | Self: 0.0% (0us) | Total: 0.1% (7.4ms) | Samples: 0

**Called by:**
- `copyInner` (3)

**Calls:**
- `hasOwned` (1)
- `isOwnedDisplayTextPart` (1)
- `hasOwned` (1)

### `HIc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2923` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `jIc` (1)

**Calls:**
- `NIc` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:83` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `inspectPaint` (1)

**Calls:**
- `nativePaintAncestors` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:15` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `ryd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4181` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `W8d` (1)

**Calls:**
- `i_d` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:7` | Self: 0.0% (0us) | Total: 0.3% (12.7ms) | Samples: 0

**Called by:**
- `anonymous` (8)

**Calls:**
- `bound require` (8)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/directives.js:4` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `hyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2970` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `X8d` (1)

**Calls:**
- `YEd` (1)

### `twb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1959` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `DCb` (1)

**Calls:**
- `owb` (1)

### `layoutErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1109` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `resolveRenderStyle` (1)

### `V0d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `CGd` (1)

**Calls:**
- `N0d` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:186` | Self: 0.0% (0us) | Total: 0.1% (3.9ms) | Samples: 0

**Called by:**
- `snapshot` (1)

**Calls:**
- `transferRetainedPixelText` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:259` | Self: 0.0% (0us) | Total: 0.3% (12.6ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (7)

**Calls:**
- `leaf` (7)

### `svgOpenTag`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:429` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `formatSvgNumericAttribute` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6428` | Self: 0.0% (0us) | Total: 35.0% (1.35s) | Samples: 0

**Called by:**
- `(anonymous)` (344)
- `layoutElkGraph` (333)
- `(anonymous)` (11)

**Calls:**
- `(anonymous)` (344)
- `SGd` (333)
- `UGd` (11)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:713` | Self: 0.0% (0us) | Total: 0.2% (9.9ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (5)

**Calls:**
- `inspectAttributeSecurity` (2)
- `inspectAttributeSecurity` (1)
- `inspectAttributeSecurity` (1)
- `inspectAttributeSecurity` (1)

### `wQd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4639` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `eQd` (1)

**Calls:**
- `Ycb` (1)

### `vzb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2847` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Fzb` (1)

**Calls:**
- `uyb` (1)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1637` | Self: 0.0% (0us) | Total: 0.4% (18.4ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (6)

**Calls:**
- `applyOutputSecurityPolicy` (6)

### `M$b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6127` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `I$b` (3)

**Calls:**
- `Pud` (2)
- `XD` (1)

### `mWd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5832` | Self: 0.0% (0us) | Total: 0.2% (7.7ms) | Samples: 0

**Called by:**
- `mWd` (3)
- `PWd` (3)

**Calls:**
- `mWd` (3)
- `g0d` (1)
- `RYd` (1)
- `$Ed` (1)

### `VFc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `IGc` (1)

**Calls:**
- `RFc` (1)

### `omitUndefinedObjectFields`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:982` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `boundedImmutableJsonSnapshot` (1)

**Calls:**
- `isForbiddenJsonConfigKey` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/stringify/stringifyPair.js:5` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `DXd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `rJd` (1)

**Calls:**
- `Vsd` (1)

### `parseErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:898` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `relationshipFrom` (1)

### `Wtb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4770` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `o8b` (1)

**Calls:**
- `lub` (1)

### `D7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5965` | Self: 0.0% (0us) | Total: 0.1% (4.3ms) | Samples: 0

**Called by:**
- `C7b` (2)

**Calls:**
- `u7b` (1)
- `qlb` (1)

### `JKb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4417` | Self: 0.0% (0us) | Total: 0.3% (13.2ms) | Samples: 0

**Called by:**
- `KKb` (7)

**Calls:**
- `Rc` (4)
- `Rc` (1)
- `rXb` (1)
- `TJb` (1)

### `WBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6424` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `VBd` (3)

**Calls:**
- `Cf` (2)
- `Hf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:43` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `formatSvgNumericAttribute` (1)

**Calls:**
- `(anonymous)` (1)

### `mixHex`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:52` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `replace` (1)

**Calls:**
- `parseHex` (1)

### `hzd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5150` | Self: 0.0% (0us) | Total: 4.6% (178.6ms) | Samples: 0

**Called by:**
- `msd` (70)

**Calls:**
- `gzd` (61)
- `fzd` (4)
- `yyd` (2)
- `ezd` (1)
- `cjb` (1)
- `fzd` (1)

### `resolveCss`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:736` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `replace` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:228` | Self: 0.0% (0us) | Total: 0.4% (18.7ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (8)

**Calls:**
- `leaf` (6)
- `ownFragment` (1)
- `shape` (1)

### `xbd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2263` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Obd` (1)

**Calls:**
- `zbd` (1)

### `setConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:53` | Self: 0.0% (0us) | Total: 0.1% (7.0ms) | Samples: 0

**Called by:**
- `connector` (4)

**Calls:**
- `deriveConnectorTerminalProjection` (2)
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)

### `registerBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:470` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `freezeBuiltInBackend` (1)

### `inspectSecurityTail`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:691` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `test` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:643` | Self: 0.0% (0us) | Total: 0.1% (4.2ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:537` | Self: 0.0% (0us) | Total: 0.4% (19.2ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)
- `attribute` (1)

### `assertRenderableLinearGradient`
`/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts:65` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `safeCssToken` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1328` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (2)

**Calls:**
- `flatIntoArrayWithCallback` (2)

### `lHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4600` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `i4b` (4)

**Calls:**
- `oHb` (4)

### `iIc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5235` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `DGc` (1)

**Calls:**
- `kmb` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:123` | Self: 0.0% (0us) | Total: 25.8% (994.0ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (556)

**Calls:**
- `withGraphLayoutDecisionObserver` (556)

### `reduce`
`[native code]` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `advance` (2)
- `buildErElkGraph` (1)

**Calls:**
- `(anonymous)` (2)
- `(anonymous)` (1)

### `SGd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6198` | Self: 0.0% (0us) | Total: 17.1% (662.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (333)

**Calls:**
- `kbd` (209)
- `$Bd` (80)
- `dte` (30)
- `XBd` (9)
- `zpd` (5)

### `xce`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4736` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `pde` (1)

**Calls:**
- `aMd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:152` | Self: 0.0% (0us) | Total: 0.0% (3.3ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `charge` (1)

### `clb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (8.9ms) | Samples: 0

**Called by:**
- `Izb` (1)

**Calls:**
- `kyb` (1)

### `izd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2766` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `lzd` (1)

**Calls:**
- `Gsd` (1)

### `styleSpecJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:595` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `map` (1)

### `bBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5555` | Self: 0.0% (0us) | Total: 0.1% (4.3ms) | Samples: 0

**Called by:**
- `IBd` (1)

**Calls:**
- `RAd` (1)

### `strokedBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:543` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `lineStrokeBox` (1)

### `Myd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5212` | Self: 0.0% (0us) | Total: 4.2% (164.6ms) | Samples: 0

**Called by:**
- `gzd` (61)

**Calls:**
- `jRd` (61)

### `BBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6354` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `mDd` (3)

**Calls:**
- `Kwd` (1)
- `xAd` (1)
- `yAd` (1)

### `Bd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `xKb` (1)

**Calls:**
- `jlb` (1)

### `resolveDiagramColors`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:54` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `resolveAppearance` (1)

**Calls:**
- `themePaint` (1)

### `dBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5445` | Self: 0.0% (0us) | Total: 0.3% (11.6ms) | Samples: 0

**Called by:**
- `XBd` (8)

**Calls:**
- `VBd` (8)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-collection.js:9` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `Ge`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `Wbd` (1)

**Calls:**
- `xe` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/block/tokens.ts:41` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `pdb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3193` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `mdb` (2)

**Calls:**
- `b` (1)
- `b` (1)

### `omitUndefinedObjectFields`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:983` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `boundedImmutableJsonSnapshot` (1)

**Calls:**
- `omitUndefinedObjectFields` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:185` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `map` (1)

### `WLd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4847` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `vhe` (1)

**Calls:**
- `kFd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:175` | Self: 0.0% (0us) | Total: 1.0% (40.8ms) | Samples: 0

**Called by:**
- `checkInertGroup` (16)

**Calls:**
- `collectNativeGroup` (13)
- `collectNativeGroup` (1)
- `collectNativeGroup` (1)
- `nativeParseRecord` (1)

### `XBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3017` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `yIb` (1)

**Calls:**
- `DCb` (1)

### `cYd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4647` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `kYd` (1)

**Calls:**
- `dXd` (1)

### `inspectAttributeSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:664` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `test` (1)

### `X8d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6508` | Self: 0.0% (0us) | Total: 0.4% (16.8ms) | Samples: 0

**Called by:**
- `Z8d` (13)

**Calls:**
- `YEd` (4)
- `Gyd` (2)
- `wyd` (2)
- `lyd` (1)
- `hyd` (1)
- `Fyd` (1)
- `Cyd` (1)
- `Eyd` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:433` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `every` (1)

**Calls:**
- `interTextEnvelope` (1)

### `internal:streams/end-of-stream`
`internal:streams/end-of-stream:17` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:712` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `hooks` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `ksd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1535` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `$Bd` (1)

**Calls:**
- `Vxd` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:318` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `RegExp` (1)

### `zc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3583` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `xc` (1)

**Calls:**
- `Jr` (1)

### `ECb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `mwb` (1)

**Calls:**
- `CCb` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:22` | Self: 0.0% (0us) | Total: 0.4% (17.8ms) | Samples: 0

**Calls:**
- `gc` (12)

### `a7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (9.1ms) | Samples: 0

**Called by:**
- `nQb` (4)

**Calls:**
- `U6b` (4)

### `wyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4408` | Self: 0.0% (0us) | Total: 0.0% (3.8ms) | Samples: 0

**Called by:**
- `X8d` (2)
- `fzd` (1)

**Calls:**
- `YEd` (2)
- `eQd` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` | Self: 0.0% (0us) | Total: 0.5% (21.5ms) | Samples: 0

**Called by:**
- `paintBounds` (10)

**Calls:**
- `tryParseCssColor` (3)
- `tryParseCssColor` (2)
- `tryParseCssColor` (2)
- `tryParseCssColor` (2)
- `tryParseCssColor` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:5` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `(anonymous)` (2)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/png-contract.ts:173` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Calls:**
- `createPngOutputOptionFieldDescriptors` (1)

### `eQd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6172` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `wyd` (1)

**Calls:**
- `wQd` (1)

### `Mz`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3395` | Self: 0.0% (0us) | Total: 0.3% (14.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (11)

**Calls:**
- `Jz` (10)
- `Kz` (1)

### `backendSupportsCapability`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1378` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `filter` (1)

### `CYb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4538` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `OIc` (2)

**Calls:**
- `$qb` (1)
- `Yjb` (1)

### `Hb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2951` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `Bo` (1)

**Calls:**
- `pb` (1)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:559` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `min` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:813` | Self: 0.0% (0us) | Total: 0.1% (5.7ms) | Samples: 0

**Called by:**
- `write` (4)

**Calls:**
- `validateGeometry` (1)
- `validateGeometry` (1)
- `validateGeometry` (1)
- `validateGeometry` (1)

### `OWb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `sqd` (1)

**Calls:**
- `mNb` (1)

### `Wl`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `_n` (1)

**Calls:**
- `Un` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `projectErPositioned`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:25` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `map` (2)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1049` | Self: 0.0% (0us) | Total: 0.1% (4.9ms) | Samples: 0

**Called by:**
- `report` (2)

**Calls:**
- `verifyNoExternalRefs` (2)

### `qub`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `Vvb` (1)

**Calls:**
- `iub` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:214` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `parts` (1)

### `boundedString`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:268` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/` (1)

### `jlb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Bd` (1)

**Calls:**
- `zyb` (1)

### `relationshipPairKey`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:160` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `test` (1)

### `$Dc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5966` | Self: 0.0% (0us) | Total: 0.2% (8.3ms) | Samples: 0

**Called by:**
- `_Dc` (3)

**Calls:**
- `Wr` (1)
- `Wr` (1)
- `vWb` (1)

### `jNc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6421` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `iNc` (1)

**Calls:**
- `YNc` (1)

### `admitRenderContractDigestInput`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1150` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `renderContractDigest` (1)
- `deferredRenderContractDigest` (1)

**Calls:**
- `boundedImmutableJsonSnapshot` (2)

### `yqd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3153` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `ibd` (4)

**Calls:**
- `dyc` (4)

### `Old`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5211` | Self: 0.0% (0us) | Total: 0.5% (19.3ms) | Samples: 0

**Called by:**
- `cJb` (6)

**Calls:**
- `Drb` (3)
- `_x` (2)
- `Drb` (1)

### `yAd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5199` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `BBd` (1)

**Calls:**
- `zAd` (1)

### `Eeb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3224` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `OC` (1)

**Calls:**
- `xeb` (1)

### `CQb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6456` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `DQb` (1)

**Calls:**
- `bcd` (1)

### `displayText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:82` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `map` (1)

### `emissionRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:75` | Self: 0.0% (0us) | Total: 0.0% (3.1ms) | Samples: 0

**Called by:**
- `registerGroupEmission` (1)
- `captureNativeGroupEmission` (1)

**Calls:**
- `defineProperties` (2)

### `bLb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6374` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `cLb` (2)

**Calls:**
- `bJb` (1)
- `Pg` (1)

### `node:zlib`
`node:zlib:161` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:941` | Self: 0.0% (0us) | Total: 0.2% (9.8ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (5)

**Calls:**
- `validateMarker` (3)
- `validateMarker` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `Wbd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4150` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `bcd` (1)

**Calls:**
- `Ge` (1)

### `internal:primordials`
`internal:primordials:76` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeSafe` (1)

### `rwb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.4% (17.3ms) | Samples: 0

**Called by:**
- `VBb` (5)
- `_Bb` (5)
- `tCb` (1)

**Calls:**
- `dwb` (11)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:134` | Self: 0.0% (0us) | Total: 0.0% (2.5ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `relationshipPairKey` (1)

### `prepareWrittenCompoundShape`
`/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:57` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `ownData` (1)

### `schemaMatchesRuntimeKind`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts:39` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `filter` (1)

**Calls:**
- `dereferenceSchema` (1)

### `Imb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `_vb` (1)

**Calls:**
- `ctb` (1)

### `iac`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5969` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `pac` (1)

**Calls:**
- `uYb` (1)

### `bJb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5818` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `bLb` (1)

**Calls:**
- `LWb` (1)

### `captureNativeGroupParse`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:173` | Self: 0.0% (0us) | Total: 1.3% (50.4ms) | Samples: 0

**Called by:**
- `captureNativeGroupEmission` (19)

**Calls:**
- `checkInertGroup` (17)
- `checkInertGroup` (1)
- `checkInertGroup` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1052` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `validateGeometry` (1)

### `renderRelationshipLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:527` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `resolveRoleStyle` (1)

### `erFrameInkPadding`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:767` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `extractErLayout` (1)

**Calls:**
- `resolveRoleStyle` (1)

### `OC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1478` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `SC` (1)

**Calls:**
- `Eeb` (1)

### `zIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5436` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `jKb` (1)

**Calls:**
- `SBb` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:315` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `assertMarkAttributes` (1)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:701` | Self: 0.0% (0us) | Total: 0.1% (6.4ms) | Samples: 0

**Called by:**
- `inlineResolvedColors` (3)

**Calls:**
- `projectSvgCss` (3)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:206` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `reduce` (2)

**Calls:**
- `measureTextWidth` (2)

### `CIc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3741` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Called by:**
- `kIc` (3)

**Calls:**
- `MIc` (3)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/common/map.js:4` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `J$b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6138` | Self: 0.0% (0us) | Total: 0.8% (32.4ms) | Samples: 0

**Called by:**
- `NQb` (24)

**Calls:**
- `I$b` (13)
- `E$b` (10)
- `D$b` (1)

### `renderResolvedMermaidSVG`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:270` | Self: 0.0% (0us) | Total: 25.9% (1.00s) | Samples: 0

**Called by:**
- `consumeResolvedGraphicalRequest` (559)

**Calls:**
- `measureRenderStage` (559)

### `Qgd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:921` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `ijd` (1)

**Calls:**
- `Ogd` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1765` | Self: 0.0% (0us) | Total: 0.1% (6.7ms) | Samples: 0

**Called by:**
- `measureRenderStage` (4)

**Calls:**
- `resolveAppearance` (2)
- `resolveAppearance` (1)
- `resolveAppearance` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:118` | Self: 0.0% (0us) | Total: 11.9% (461.8ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (50)
- `renderEntityBox` (25)
- `renderEntityBox` (22)
- `crowsFootMark` (16)
- `renderEntityBox` (11)
- `renderEntityBox` (7)
- `renderEntityBox` (6)
- `renderRelationshipLabel` (6)
- `renderRelationshipLabel` (3)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)

**Calls:**
- `leaf` (85)
- `leaf` (54)
- `leaf` (4)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)

### `builtinFamilyConformanceReport`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1915` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (2)

**Calls:**
- `map` (2)

### `construct`
`[native code]` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `_callSuper` (1)

**Calls:**
- `ELK` (1)

### `JEd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3971` | Self: 0.0% (0us) | Total: 0.1% (4.1ms) | Samples: 0

**Called by:**
- `uBd` (2)

**Calls:**
- `mzd` (1)
- `lzd` (1)

### `NQb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 9.2% (356.4ms) | Samples: 0

**Called by:**
- `ibd` (190)

**Calls:**
- `lQb` (153)
- `J$b` (24)
- `p_b` (12)
- `J$b` (1)

### `XmlLeafWrite`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:298` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `SvgWriter` (1)

**Calls:**
- `(anonymous)` (1)

### `au`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4805` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `BGc` (1)

**Calls:**
- `eub` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:685` | Self: 0.0% (0us) | Total: 0.1% (7.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `identityAttributes` (1)
- `identityAttributes` (1)

### `registerGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:87` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `emissionRecord` (1)

### `ngc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4403` | Self: 0.0% (0us) | Total: 0.1% (6.8ms) | Samples: 0

**Called by:**
- `zgc` (4)
- `Agc` (1)

**Calls:**
- `lgc` (4)
- `Ogc` (1)

### `_callSuper`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6523` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `ELKNode` (1)

**Calls:**
- `construct` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:268` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `set` (1)

### `YHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4655` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `AKb` (1)

**Calls:**
- `QC` (1)

### `tag`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:151` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `scanStartTags` (1)

**Calls:**
- `tagRecord` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:780` | Self: 0.0% (0us) | Total: 0.3% (13.2ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (4)
- `write` (2)

**Calls:**
- `validateNodeSerialization` (4)
- `validateNodeSerialization` (1)
- `validateNodeSerialization` (1)

### `AIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6065` | Self: 0.0% (0us) | Total: 0.4% (16.8ms) | Samples: 0

**Called by:**
- `KIb` (4)
- `IKb` (4)

**Calls:**
- `KIb` (4)
- `_Hb` (3)
- `DIb` (1)

### `wGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5747` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `BGc` (7)

**Calls:**
- `KFc` (5)
- `Pvb` (1)
- `KFc` (1)

### `boundedImmutableJsonSnapshot`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1242` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `admitRenderContractDigestInput` (2)

**Calls:**
- `omitUndefinedObjectFields` (1)
- `omitUndefinedObjectFields` (1)

### `Wr`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5534` | Self: 0.0% (0us) | Total: 0.5% (20.8ms) | Samples: 0

**Called by:**
- `zNc` (3)
- `$Dc` (1)
- `Xr` (1)

**Calls:**
- `Nr` (2)
- `Jmb` (1)
- `JD` (1)
- `Vr` (1)

### `lgc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5300` | Self: 0.0% (0us) | Total: 0.1% (5.5ms) | Samples: 0

**Called by:**
- `ngc` (4)

**Calls:**
- `QC` (2)
- `Xfc` (1)
- `Xfc` (1)

### `GIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (5.5ms) | Samples: 0

**Called by:**
- `IHb` (4)

**Calls:**
- `yIb` (4)

### `qVd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `hxd` (1)

**Calls:**
- `Oce` (1)

### `oHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6406` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `lHb` (4)

**Calls:**
- `mXb` (1)
- `kXb` (1)
- `yfd` (1)
- `Afd` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/radar/config-diagnostics.ts:11` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Calls:**
- `boundedNonNegative` (1)

### `positionFamilyForNativeRender`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:67` | Self: 0.0% (0us) | Total: 25.9% (1.00s) | Samples: 0

**Called by:**
- `measureRenderStage` (559)

**Calls:**
- `withTextMeasurementExecution` (559)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:194` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (1)

**Calls:**
- `boxAt` (1)

### `zjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4226` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Cjb` (1)

**Calls:**
- `Bsb` (1)

### `lcd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `zpd` (2)

**Calls:**
- `Gub` (2)

### `withTextMeasurementExecution`
`/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:135` | Self: 0.0% (0us) | Total: 98.2% (3.78s) | Samples: 0

**Called by:**
- `positionFamilyForNativeRender` (559)
- `consumeResolvedGraphicalRequest` (479)
- `retainedNativeDrawing` (344)
- `runBackendConformance` (11)

**Calls:**
- `(anonymous)` (556)
- `renderPositionedWithTextMeasurement` (404)
- `drawNative` (293)
- `renderPositionedWithTextMeasurement` (42)
- `drawNative` (38)
- `renderPositionedWithTextMeasurement` (20)
- `renderPositionedWithTextMeasurement` (7)
- `renderPositionedWithTextMeasurement` (5)
- `createFixture` (5)
- `drawNative` (4)
- `drawNative` (2)
- `createFixture` (2)
- `drawNative` (2)
- `(anonymous)` (2)
- `createFixture` (1)
- `drawNative` (1)
- `(anonymous)` (1)
- `drawNative` (1)
- `(anonymous)` (1)
- `createFixture` (1)
- `drawNative` (1)
- `(anonymous)` (1)
- `drawNative` (1)
- `createFixture` (1)
- `deepFreeze` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:705` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `snapshot` (1)

### `ensureElk`
`/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts:70` | Self: 0.0% (0us) | Total: 5.1% (198.6ms) | Samples: 0

**Called by:**
- `layoutElkGraph` (141)

**Calls:**
- `ELKNode` (140)
- `ELKNode` (1)

### `rXb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `JKb` (1)

**Calls:**
- `Xu` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Node.js:3` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:486` | Self: 0.0% (0us) | Total: 0.1% (5.2ms) | Samples: 0

**Called by:**
- `paintAttribute` (1)
- `identityAttributes` (1)
- `identityAttributes` (1)

**Calls:**
- `attribute` (3)

### `visitSvgStartTagsFresh`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:116` | Self: 0.0% (0us) | Total: 0.8% (31.6ms) | Samples: 0

**Called by:**
- `collectNativeGroup` (12)

**Calls:**
- `scanStartTags` (7)
- `scanStartTags` (4)
- `scanStartTags` (1)

### `Bo`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4130` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `fp` (1)

**Calls:**
- `Hb` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:162` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (2)

**Calls:**
- `map` (2)

### `KIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (8.4ms) | Samples: 0

**Called by:**
- `AIb` (4)

**Calls:**
- `AIb` (4)

### `Rud`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4804` | Self: 0.0% (0us) | Total: 5.0% (194.2ms) | Samples: 0

**Called by:**
- `avd` (74)
- `q_b` (2)
- `o_b` (2)

**Calls:**
- `ysd` (70)
- `hMd` (8)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:385` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `reserve` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:6` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1715` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `renderOptionsAdmissionMessages` (1)

### `expandLocalReferences`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:203` | Self: 0.0% (0us) | Total: 0.0% (1.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `entries` (1)

### `Fjb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `lkb` (1)

**Calls:**
- `Ajb` (1)

### `get receipt`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:347` | Self: 0.0% (0us) | Total: 0.1% (6.0ms) | Samples: 0

**Called by:**
- `stringify` (5)

**Calls:**
- `(anonymous)` (3)
- `(anonymous)` (2)

### `from`
`[native code]` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `detectRegisteredFamilyDescriptorFromFirstLine` (1)

**Calls:**
- `arrayFromFastWithoutMapFn` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:167` | Self: 0.0% (0us) | Total: 1.9% (74.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (11)
- `renderCardinality` (11)
- `renderCardinality` (8)

**Calls:**
- `node` (28)
- `node` (2)

### `identityAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:536` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `hasDomSvgIdentityRole` (1)

### `e7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5905` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Z6b` (1)

**Calls:**
- `Le` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:644` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `map` (1)

### `KFc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6289` | Self: 0.0% (0us) | Total: 0.1% (5.9ms) | Samples: 0

**Called by:**
- `wGc` (5)

**Calls:**
- `UJc` (4)
- `DWb` (1)

### `renderRelationshipLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:543` | Self: 0.0% (0us) | Total: 0.6% (23.6ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (8)

**Calls:**
- `leaf` (6)
- `text` (1)
- `leaf` (1)

### `gHb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6343` | Self: 0.0% (0us) | Total: 2.8% (107.8ms) | Samples: 0

**Called by:**
- `iHb` (50)

**Calls:**
- `cJb` (11)
- `KKb` (7)
- `HKb` (6)
- `xKb` (5)
- `IKb` (4)
- `jKb` (3)
- `AKb` (3)
- `VBb` (3)
- `cLb` (2)
- `QKb` (2)
- `ZJb` (1)
- `iKb` (1)
- `VJb` (1)
- `SBb` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:420` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureErEntities` (1)

**Calls:**
- `advance` (1)

### `styledRunLayout`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:252` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `map` (1)

### `evaluateExtensionCompatibility`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts:144` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `createExtensionIdentity` (1)

**Calls:**
- `every` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/resolve-block-map.js:7` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `Hyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5370` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `Gyd` (1)

**Calls:**
- `tYd` (1)

### `nonPainting`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:134` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `performIteration` (1)

### `V6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5950` | Self: 0.0% (0us) | Total: 0.1% (5.3ms) | Samples: 0

**Called by:**
- `U6b` (1)

**Calls:**
- `N6b` (1)

### `U8d`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6455` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `_8d` (1)

**Calls:**
- `gyd` (1)

### `pac`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `nQb` (1)

**Calls:**
- `iac` (1)

### `A7b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5768` | Self: 0.0% (0us) | Total: 0.3% (12.3ms) | Samples: 0

**Called by:**
- `H7b` (6)

**Calls:**
- `C7b` (6)

### `node:fs`
`node:fs:782` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Calls:**
- `setName` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:5` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `(anonymous)` (1)

### `MZb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `El` (1)

**Calls:**
- `OZb` (1)

### `EQb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2079` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `qQb` (4)

**Calls:**
- `AQb` (3)
- `AQb` (1)

### `the`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `jGd` (1)

**Calls:**
- `KKd` (1)

### `node:zlib`
`node:zlib:2` | Self: 0.0% (0us) | Total: 1.9% (77.0ms) | Samples: 0

**Calls:**
- `anonymous` (27)
- `@lazy` (2)

### `install`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:41` | Self: 0.0% (0us) | Total: 0.2% (8.5ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (1)

**Calls:**
- `defineProperty` (1)

### `erRelationshipBlock`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:19` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `buildErElkGraph` (2)

**Calls:**
- `erRelationshipStyle` (1)
- `resolveRoleStyle` (1)

### `qkb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `Uvb` (1)

**Calls:**
- `Ykb` (1)

### `NIc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4070` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `HIc` (1)

**Calls:**
- `OIc` (1)

### `MIc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4296` | Self: 0.0% (0us) | Total: 0.0% (3.5ms) | Samples: 0

**Called by:**
- `CIc` (3)

**Calls:**
- `OIc` (3)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:247` | Self: 0.0% (0us) | Total: 2.1% (83.5ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (38)

**Calls:**
- `inspectPaint` (37)
- `finish` (1)

### `canonicalizeSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:485` | Self: 0.0% (0us) | Total: 0.1% (5.0ms) | Samples: 0

**Called by:**
- `attachSceneNodeSerialization` (1)

**Calls:**
- `canonicalOpeningTag` (1)

### `crowsFootMark`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:618` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `renderCardinality` (1)

**Calls:**
- `escapeAttr` (1)

### `Xpb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1469` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `wpb` (1)

**Calls:**
- `Qpb` (1)

### `typographyAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:698` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `writeTextSvg` (1)

**Calls:**
- `attribute` (1)

### `hitsTransformed`
`/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:43` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `connector/transform/render` (1)

**Calls:**
- `transformMatrix` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:171` | Self: 0.0% (0us) | Total: 0.1% (4.8ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (3)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:150` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `renderCardinality` (1)

**Calls:**
- `(anonymous)` (1)

### `qJd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5497` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `TWd` (3)

**Calls:**
- `yXd` (1)
- `SId` (1)
- `kYd` (1)

### `elkPlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1177` | Self: 0.0% (0us) | Total: 0.2% (10.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (8)

**Calls:**
- `buildErElkGraph` (4)
- `buildErElkGraph` (2)
- `buildErElkGraph` (2)

### `BGc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5991` | Self: 0.0% (0us) | Total: 0.9% (34.7ms) | Samples: 0

**Called by:**
- `MGc` (25)

**Calls:**
- `xGc` (17)
- `wGc` (7)
- `au` (1)

### `gdd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3990` | Self: 0.0% (0us) | Total: 0.3% (12.7ms) | Samples: 0

**Called by:**
- `OGd` (10)

**Calls:**
- `edd` (5)
- `hjd` (4)
- `fdd` (1)

### `hasDomSvgIdentityRole`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:69` | Self: 0.0% (0us) | Total: 0.0% (3.7ms) | Samples: 0

**Called by:**
- `identityAttributes` (1)

**Calls:**
- `sceneRoleTraits` (1)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:85` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (1)

**Calls:**
- `filter` (1)

### `C6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.2% (9.4ms) | Samples: 0

**Called by:**
- `nQb` (4)

**Calls:**
- `A6b` (4)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:688` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `preprocessMermaidSource` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:197` | Self: 0.0% (0us) | Total: 0.1% (5.4ms) | Samples: 0

**Called by:**
- `renderEntityBox` (1)

**Calls:**
- `compositeCssColor` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:609` | Self: 0.0% (0us) | Total: 0.1% (6.4ms) | Samples: 0

**Called by:**
- `validateNode` (3)

**Calls:**
- `validateGeometry` (3)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:90` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (2)

**Calls:**
- `svgOpenTag` (1)
- `svgOpenTag` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:28` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `add` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:140` | Self: 0.0% (0us) | Total: 0.1% (6.4ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (1)
- `visitSvgStartTagsFresh` (1)

**Calls:**
- `scanTagEnd` (1)
- `scanTagEnd` (1)

### `markerTerminalDepth`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:294` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (4)
- `(anonymous)` (1)

**Calls:**
- `markerBoundsAt` (2)
- `markerBoundsAt` (1)
- `markerBoundsAt` (1)
- `pointsBounds` (1)

### `IZb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Xr` (1)

**Calls:**
- `JD` (1)

### `FXd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `jGd` (2)

**Calls:**
- `KKd` (2)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/decode-data-html.js:3` | Self: 0.0% (0us) | Total: 2.3% (90.8ms) | Samples: 0

**Calls:**
- `decodeBase64` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:231` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `join` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:242` | Self: 0.0% (0us) | Total: 1.4% (57.4ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (27)

**Calls:**
- `leaf` (25)
- `ownFragment` (1)
- `text` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:230` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `copyInner` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:5` | Self: 0.0% (0us) | Total: 0.8% (31.3ms) | Samples: 0

**Called by:**
- `anonymous` (20)

**Calls:**
- `bound require` (20)

### `Zb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Jr` (1)

**Calls:**
- `Xb` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:49` | Self: 0.0% (0us) | Total: 0.0% (3.0ms) | Samples: 0

**Calls:**
- `writeFileSync` (1)

### `jIc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4928` | Self: 0.0% (0us) | Total: 0.1% (4.6ms) | Samples: 0

**Called by:**
- `qGc` (4)

**Calls:**
- `kIc` (3)
- `HIc` (1)

### `SBb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3015` | Self: 0.0% (0us) | Total: 0.2% (7.8ms) | Samples: 0

**Called by:**
- `yIb` (2)
- `R6b` (1)
- `zIb` (1)
- `wbd` (1)

**Calls:**
- `xCb` (4)
- `gCb` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:158` | Self: 0.0% (0us) | Total: 0.1% (6.5ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (2)

**Calls:**
- `sourceSlice` (2)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:125` | Self: 0.0% (0us) | Total: 0.1% (4.0ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `deferredTerminalProjectionInput` (1)

### `_Hb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (6.8ms) | Samples: 0

**Called by:**
- `AIb` (3)

**Calls:**
- `PHb` (1)
- `PHb` (1)
- `RHb` (1)

### `Obd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Vvb` (1)

**Calls:**
- `xbd` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:145` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `renderCardinality` (1)

**Calls:**
- `parts` (1)

### `TAd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4750` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `RBd` (1)

**Calls:**
- `JBd` (1)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:209` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `connectorPaintBounds` (1)

**Calls:**
- `pointsBounds` (1)

### `gVb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6307` | Self: 0.0% (0us) | Total: 0.1% (3.9ms) | Samples: 0

**Called by:**
- `lQb` (3)

**Calls:**
- `fVb` (2)
- `jNb` (1)

### `RAb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `PBb` (1)

**Calls:**
- `imb` (1)

### `completeBuiltinDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1372` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `copyDataProperties` (1)

### `ELK`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:56` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `construct` (1)

**Calls:**
- `PromisedWorker` (1)

### `internal:validators`
`internal:validators:2` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `dCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3897` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `cCb` (1)

**Calls:**
- `qwb` (1)

### `Ld`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4127` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `$rb` (1)

**Calls:**
- `uNd` (1)

### `chargeInkSort`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:7` | Self: 0.0% (0us) | Total: 0.1% (4.5ms) | Samples: 0

**Called by:**
- `build` (4)

**Calls:**
- `compare` (3)
- `erCharge` (1)

### `iyd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4338` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `fzd` (1)

**Calls:**
- `Fyd` (1)

### `Xq`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2104` | Self: 0.0% (0us) | Total: 0.0% (2.7ms) | Samples: 0

**Called by:**
- `q6b` (1)

**Calls:**
- `Ar` (1)

### `withRenderStageObserver`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:20` | Self: 0.0% (0us) | Total: 71.3% (2.74s) | Samples: 0

**Called by:**
- `withPerformanceObserver` (1062)

**Calls:**
- `withSvgInspectionCache` (1062)

### `NFd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3609` | Self: 0.0% (0us) | Total: 0.6% (24.6ms) | Samples: 0

**Called by:**
- `rJd` (5)
- `eGd` (4)

**Calls:**
- `jGd` (6)
- `OFd` (1)
- `vhe` (1)
- `JFd` (1)

### `DCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3626` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `XBb` (1)

**Calls:**
- `twb` (1)

### `Xfc`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5131` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `lgc` (1)

**Calls:**
- `Wfc` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:710` | Self: 0.0% (0us) | Total: 10.3% (399.9ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (21)

**Calls:**
- `verifyDocumentEnvelope` (5)
- `verifyDocumentEnvelope` (3)
- `verifyDocumentEnvelope` (3)
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)

### `receiptOf`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:758` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:109` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (1)

**Calls:**
- `connectorMidpointMarkerAnchors` (1)

### `registerCanonicalStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:235` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (1)

**Calls:**
- `createExtensionIdentity` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:5` | Self: 0.0% (0us) | Total: 0.0% (2.8ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `_wd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Rsd` (1)

**Calls:**
- `Iwd` (1)

### `tmd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:3549` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `teb` (1)

**Calls:**
- `WC` (1)

### `executionCapabilityDecision`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1453` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `resolveExecutionPlan` (1)

**Calls:**
- `negotiateCapabilities` (1)

### `internal:streams/duplex`
`internal:streams/duplex:2` | Self: 0.0% (0us) | Total: 0.6% (25.4ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `anonymous` (9)

### `escapeDisplayAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:115` | Self: 0.0% (0us) | Total: 0.0% (3.2ms) | Samples: 0

**Called by:**
- `renderEntityBox` (2)

**Calls:**
- `join` (1)
- `sanitizeDisplayLines` (1)

### `crb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4586` | Self: 0.0% (0us) | Total: 0.2% (9.1ms) | Samples: 0

**Called by:**
- `cJb` (4)

**Calls:**
- `PJb` (3)
- `kDb` (1)

### `snapshot`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:277` | Self: 0.0% (0us) | Total: 0.3% (12.7ms) | Samples: 0

**Called by:**
- `group` (5)
- `drawNative` (1)

**Calls:**
- `copyInner` (4)
- `copyInner` (1)
- `copyInner` (1)

### `readErOuterStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:514` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `findErStatements` (1)

**Calls:**
- `readErStatement` (1)

### `DIb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4867` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `AIb` (1)

**Calls:**
- `JHb` (1)

### `sqd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4983` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `cJb` (2)

**Calls:**
- `mEd` (1)
- `OWb` (1)

### `jRd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2894` | Self: 0.0% (0us) | Total: 4.2% (164.6ms) | Samples: 0

**Called by:**
- `Myd` (61)

**Calls:**
- `_8d` (42)
- `Z8d` (19)

### `oBd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5012` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `XBd` (1)

**Calls:**
- `XBd` (1)

### `OCb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:2420` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `QCb` (2)

**Calls:**
- `yCb` (2)

### `safeCssToken`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:67` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `assertRenderableLinearGradient` (1)

**Calls:**
- `trim` (1)

### `lNb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5215` | Self: 0.0% (0us) | Total: 0.1% (4.1ms) | Samples: 0

**Called by:**
- `LWb` (1)
- `Q$b` (1)
- `N$b` (1)

**Calls:**
- `bjb` (2)
- `tEd` (1)

### `prepareWrittenCompoundShape`
`/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts:58` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `ownData` (1)

### `validatePrimitiveCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:333` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `graphicalBackendCapabilityClaims` (1)

**Calls:**
- `primitiveCapabilityClaimKey` (1)

### `sourceEnvelopeMetadata`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:836` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `normalizeSource` (1)

**Calls:**
- `match` (1)

### `_vb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (6.1ms) | Samples: 0

**Called by:**
- `VBb` (2)
- `Dk` (1)

**Calls:**
- `Uvb` (2)
- `Imb` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:169` | Self: 0.0% (0us) | Total: 0.2% (8.8ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (3)
- `renderCardinality` (2)

**Calls:**
- `snapshot` (5)

### `Mrb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (1.8ms) | Samples: 0

**Called by:**
- `AKb` (1)

**Calls:**
- `Grb` (1)

### `Kzd`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.0% (2.6ms) | Samples: 0

**Called by:**
- `Rsd` (2)

**Calls:**
- `awd` (1)
- `sJd` (1)

### `g6b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 2.8% (110.9ms) | Samples: 0

**Called by:**
- `nQb` (52)

**Calls:**
- `e6b` (52)

### `hasInheritedTextPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:263` | Self: 0.0% (0us) | Total: 0.0% (1.7ms) | Samples: 0

**Called by:**
- `observe` (1)

**Calls:**
- `get` (1)

### `k0b`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:4153` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `n0b` (1)

**Calls:**
- `i0b` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:696` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `RC`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:5077` | Self: 0.0% (0us) | Total: 0.1% (4.4ms) | Samples: 0

**Called by:**
- `QC` (3)

**Calls:**
- `TC` (1)
- `WC` (1)
- `OC` (1)

### `withGraphLayoutDecisionObserver`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:37` | Self: 0.0% (0us) | Total: 25.8% (994.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (556)

**Calls:**
- `layout` (551)
- `layout` (5)

### `asb`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6509` | Self: 0.0% (0us) | Total: 0.1% (5.1ms) | Samples: 0

**Called by:**
- `vsb` (3)
- `wsb` (1)

**Calls:**
- `tb` (2)
- `tb` (2)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:588` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `separateErCompounds` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 31.6% | 1.21s | `[native code]` |
| 26.0% | 1.00s | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 6.3% | 243.9ms | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 4.2% | 163.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 2.9% | 114.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 2.9% | 113.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 2.3% | 90.8ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js` |
| 1.7% | 68.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 1.5% | 60.9ms | `/tmp/pr449-main-integration-20261029-762/src/ascii/shapes/corners.ts` |
| 1.4% | 55.3ms | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 1.3% | 51.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 1.1% | 45.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.9% | 34.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.8% | 32.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.7% | 29.5ms | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.7% | 29.0ms | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.7% | 27.9ms | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` |
| 0.6% | 26.6ms | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.6% | 25.5ms | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.5% | 22.3ms | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.5% | 20.9ms | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.5% | 19.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.4% | 17.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.4% | 15.8ms | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.3% | 15.0ms | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.3% | 13.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.3% | 13.2ms | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.3% | 13.2ms | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.3% | 12.9ms | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.3% | 12.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.3% | 12.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.3% | 11.7ms | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.2% | 9.9ms | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.2% | 9.1ms | `/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts` |
| 0.2% | 8.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/transforms.ts` |
| 0.2% | 8.1ms | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts` |
| 0.1% | 7.5ms | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` |
| 0.1% | 6.8ms | `/tmp/pr449-main-integration-20261029-762/src/experimental/cache-residency.ts` |
| 0.1% | 6.6ms | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.1% | 5.9ms | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts` |
| 0.1% | 5.8ms | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts` |
| 0.1% | 5.8ms | `internal:primordials` |
| 0.1% | 5.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.1% | 4.9ms | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts` |
| 0.1% | 4.8ms | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.1% | 4.7ms | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts` |
| 0.1% | 4.5ms | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts` |
| 0.1% | 4.5ms | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts` |
| 0.1% | 4.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` |
| 0.1% | 4.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.1% | 4.2ms | `/tmp/pr449-main-integration-20261029-762/src/layout/geometry.ts` |
| 0.1% | 4.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 0.1% | 3.9ms | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` |
| 0.0% | 3.8ms | `/tmp/pr449-main-integration-20261029-762/src/shared/json-config-admission.ts` |
| 0.0% | 3.7ms | `node:zlib` |
| 0.0% | 3.4ms | `internal:streams/destroy` |
| 0.0% | 3.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/seed.ts` |
| 0.0% | 3.1ms | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts` |
| 0.0% | 3.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-resources.ts` |
| 0.0% | 2.8ms | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.0% | 2.7ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js` |
| 0.0% | 2.7ms | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts` |
| 0.0% | 2.7ms | `/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` |
| 0.0% | 2.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.0% | 2.4ms | `/tmp/pr449-main-integration-20261029-762/src/shared/inter-text-envelope.ts` |
| 0.0% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.0% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts` |
| 0.0% | 2.3ms | `node:events` |
| 0.0% | 2.2ms | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.0% | 2.2ms | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/set.js` |
| 0.0% | 2.1ms | `node:fs` |
| 0.0% | 2.0ms | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js` |
| 0.0% | 1.9ms | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts` |
| 0.0% | 1.8ms | `/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts` |
| 0.0% | 1.5ms | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/YAMLMap.js` |
| 0.0% | 1.5ms | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/theme-color-admission.ts` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/shared/inline-format.ts` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/png-contract.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/text-metrics.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/unicode-ranges.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/shared/trailing-comment.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/role-style-contract.ts` |
| 0.0% | 1.2ms | `internal:fs/streams` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/layout-engine.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/shared/generated-identity.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/elk-instance.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/block/tokens.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/er/creation.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/styles.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/experimental-performance.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/ascii/shapes/index.ts` |
