# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 1.54s | 562 | 1.0ms | 964 |

**Top 10:** `require` 15.9%, `anonymous` 13.9%, `gc` 7.3%, `(anonymous)` 6.5%, `(anonymous)` 4.5%, `decodeBase64` 3.0%, `stringify` 1.0%, `indent` 0.8%, `map` 0.6%, `defineProperties` 0.6%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 15.9% | 246.0ms | 38.9% | 602.4ms | `require` | `[native code]` |
| 13.9% | 216.5ms | 35.3% | 547.2ms | `anonymous` | `[native code]` |
| 7.3% | 113.9ms | 7.3% | 113.9ms | `gc` | `[native code]` |
| 6.5% | 101.2ms | 20.5% | 317.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 4.5% | 70.1ms | 23.2% | 359.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` |
| 3.0% | 47.9ms | 3.0% | 47.9ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:22` |
| 1.0% | 15.9ms | 1.6% | 25.9ms | `stringify` | `[native code]` |
| 0.8% | 13.4ms | 0.8% | 13.4ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` |
| 0.6% | 9.8ms | 29.1% | 451.0ms | `map` | `[native code]` |
| 0.6% | 9.5ms | 0.6% | 9.5ms | `defineProperties` | `[native code]` |
| 0.6% | 9.5ms | 0.6% | 9.5ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.6% | 9.4ms | 0.6% | 9.4ms | `getOwnPropertyDescriptor` | `[native code]` |
| 0.5% | 8.8ms | 0.5% | 8.8ms | `retainOrder` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.5% | 7.8ms | 0.5% | 7.8ms | `freeze` | `[native code]` |
| 0.5% | 7.8ms | 0.5% | 7.8ms | `defineProperty` | `[native code]` |
| 0.4% | 7.5ms | 0.7% | 12.2ms | `Set` | `[native code]` |
| 0.4% | 7.3ms | 0.4% | 7.3ms | `hasOwn` | `[native code]` |
| 0.4% | 7.3ms | 0.6% | 10.7ms | `find` | `[native code]` |
| 0.4% | 6.6ms | 0.4% | 6.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:496` |
| 0.4% | 6.2ms | 0.4% | 6.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.4% | 6.2ms | 0.4% | 6.2ms | `receiptOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.3% | 6.1ms | 0.3% | 6.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` |
| 0.3% | 6.0ms | 0.3% | 6.0ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.3% | 5.8ms | 0.3% | 5.8ms | `compareCodePointStrings` | `/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts:3` |
| 0.3% | 5.8ms | 0.3% | 5.8ms | `cloneObject` | `[native code]` |
| 0.3% | 5.8ms | 0.3% | 5.8ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` |
| 0.3% | 5.3ms | 0.3% | 5.3ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.3% | 5.3ms | 0.3% | 5.3ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` |
| 0.3% | 4.9ms | 0.3% | 4.9ms | `has` | `[native code]` |
| 0.3% | 4.9ms | 0.3% | 4.9ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2365` |
| 0.3% | 4.8ms | 0.3% | 4.8ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:30` |
| 0.3% | 4.7ms | 0.3% | 4.7ms | `arrayIteratorNextHelper` | `[native code]` |
| 0.3% | 4.6ms | 0.6% | 9.3ms | `writeFileSync` | `[native code]` |
| 0.2% | 4.6ms | 0.3% | 5.7ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:240` |
| 0.2% | 4.4ms | 0.2% | 4.4ms | `WeakSet` | `[native code]` |
| 0.2% | 4.4ms | 0.2% | 4.4ms | `sourceIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` |
| 0.2% | 4.4ms | 0.7% | 11.2ms | `some` | `[native code]` |
| 0.2% | 4.3ms | 0.2% | 4.3ms | `trim` | `[native code]` |
| 0.2% | 4.2ms | 0.2% | 4.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:156` |
| 0.2% | 4.2ms | 0.2% | 4.2ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:596` |
| 0.2% | 4.1ms | 0.2% | 4.1ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:570` |
| 0.2% | 4.0ms | 7.1% | 110.5ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:161` |
| 0.2% | 4.0ms | 0.2% | 4.0ms | `finalizeFlatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.2% | 3.9ms | 0.2% | 3.9ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.2% | 3.9ms | 0.2% | 3.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.2% | 3.8ms | 0.2% | 3.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.2% | 3.7ms | 0.7% | 11.6ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:170` |
| 0.2% | 3.7ms | 0.4% | 7.5ms | `readFileSync` | `[native code]` |
| 0.2% | 3.7ms | 0.2% | 3.7ms | `xmlTokenAt` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:17` |
| 0.2% | 3.7ms | 0.2% | 3.7ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:171` |
| 0.2% | 3.6ms | 0.2% | 3.6ms | `traits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.2% | 3.6ms | 0.2% | 3.6ms | `mixedChannels` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:57` |
| 0.2% | 3.5ms | 0.3% | 4.8ms | `typographyAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:694` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1532` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:473` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:395` |
| 0.2% | 3.3ms | 0.4% | 7.0ms | `test` | `[native code]` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1289` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:109` |
| 0.2% | 3.1ms | 0.2% | 3.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `flatIntoArray` | `[native code]` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `graphicalSvgArtifact` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `nativeParseRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:132` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `layoutSharedFan` | `/tmp/pr449-main-integration-20261029-762/src/layout/shared-fan-core.ts` |
| 0.1% | 2.9ms | 0.1% | 2.9ms | `fromEntries` | `[native code]` |
| 0.1% | 2.9ms | 0.1% | 2.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/c4/config.ts` |
| 0.1% | 2.9ms | 0.2% | 4.0ms | `every` | `[native code]` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `Segmenter` | `[native code]` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `validateRoleStyleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:309` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `slice` | `[native code]` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `classMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:21` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:417` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:251` |
| 0.1% | 2.6ms | 0.1% | 2.6ms | `match` | `[native code]` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:27` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1498` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `exec` | `[native code]` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:40` |
| 0.1% | 2.5ms | 0.4% | 6.4ms | `filter` | `[native code]` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:535` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `transferSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `declareFamilyScenePrimitiveEvidence` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:253` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `finishXmlLeaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `runMeasuredGraphBackend` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `factOf` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `canonicalExtensionId` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `includes` | `[native code]` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` |
| 0.1% | 2.3ms | 1.3% | 21.2ms | `renderCardinality` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:590` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:55` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:485` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts:240` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `name` | `/tmp/pr449-main-integration-20261029-762/src/er/creation.ts` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `RegExp` | `[native code]` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `connectorUnitTangent` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `copyDataProperties` | `[native code]` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:672` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:66` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `admitWritableSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:501` |
| 0.1% | 2.1ms | 0.3% | 5.5ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:13` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:520` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:220` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `validSceneRoleDeclaration` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1603` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-named-colors.ts:3` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `buildInkTree` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `tag` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:152` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `bisector` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `retainOrder` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:77` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `erRelationshipStyle` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:15` |
| 0.1% | 1.9ms | 0.6% | 10.1ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `validateRoleStyles` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:581` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:646` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `invalidateFractionalCircle` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:93` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `isWhitespace` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `circleMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:229` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:96` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1161` |
| 0.1% | 1.8ms | 0.1% | 3.0ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:226` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `normalizePlainLabel` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:47` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:212` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `join` | `[native code]` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `advance` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:199` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:83` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `retainOrder` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:75` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:703` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `min` | `[native code]` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts:32` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `numericLike` | `/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1100` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:167` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `erRelationshipStyle` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:603` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 1.6ms | 0.4% | 6.7ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:381` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `hint` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:168` |
| 0.1% | 1.5ms | 1.3% | 20.3ms | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:618` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:173` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `stripMermaidDirectives` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` |
| 0.0% | 1.4ms | 0.1% | 2.9ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:593` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:27` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:763` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `create` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:532` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `connector/subpaths/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `sceneAssertionsEnabled` | `/tmp/pr449-main-integration-20261029-762/src/scene/assertions.ts:28` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `floor` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `assertRenderableLinearGradient` | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `erTextLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/text.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `element` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:301` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:580` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:100` |
| 0.0% | 1.4ms | 0.4% | 7.3ms | `attachSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:495` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `importModule` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `performIteration` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `createNativePaintEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `assertFamilyGeometryOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:858` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:611` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:114` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `inspectPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.3ms | 0.5% | 8.8ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:682` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `advance` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1385` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.3ms | 0.4% | 7.6ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:509` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `normalizeMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:667` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `startTags` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:65` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:181` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `detectsArchitectureFamily` | `/tmp/pr449-main-integration-20261029-762/src/shared/builtin-family-detection.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `/<(?:[^\s<>/:]+:)?foreignObject\b/i` | `[native code]` |
| 0.0% | 1.3ms | 0.2% | 3.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:144` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `preparedInterTextBounds` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:123` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `hitsTransformed` | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:48` |
| 0.0% | 1.3ms | 0.4% | 7.4ms | `paintAttribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:493` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parseInt` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:335` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `styledRunLayout` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:218` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `ArrayBuffer` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `safeCssPaint` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `terminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1251` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:224` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `serializeLinearGradientResources` | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:69` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:33` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `overlaps` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `isCapabilityId` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.2ms | 0.1% | 2.5ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:526` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:35` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `set` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `result` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:406` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:407` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `withDeferredTerminalProjections` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `/^(?:class\|data-[a-z][a-z0-9-]*\|role\|aria-[a-z]+\|tabindex\|pointer-events\|transform\|style)$/` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:765` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `checkAllClassLikeAuthoredStyles` | `/tmp/pr449-main-integration-20261029-762/src/shared/style-props.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:153` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:591` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:129` |
| 0.0% | 1.2ms | 0.1% | 3.0ms | `erDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/er/text.ts:94` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1066` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `primitiveCapabilityClaimKey` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ownsParts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:978` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:175` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `consumePointBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scenePrimitiveMatrix` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `setName` | `node:fs:696` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `makeSafe` | `internal:primordials` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:538` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:94` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.3% | 4.8ms | `replace` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:247` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `py` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:139` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isServerConfig` | `bun:main` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `factOf` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:97` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:219` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorEndpointMarkerAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:106` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `possibleShapeStroke` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:133` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:90` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:532` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:341` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:22` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:174` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:86` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `resolvedFamilyRenderContextOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `/\sdata-role="[^"]*"/` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `xmlScalarCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:88` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `renderCardinality` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:205` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `hypot` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `hooks` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:511` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:16` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `ownFragment` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:116` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `hasInheritedTextPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `get` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `safeCssToken` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:69` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `get` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Transform` | `internal:streams/transform` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:62` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1930` |
| 0.0% | 1.1ms | 0.1% | 2.3ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `admitRenderOptionsInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `add` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `sanitizeTextControls` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:9` |
| 0.0% | 1.1ms | 0.1% | 2.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1129` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:254` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:298` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1172` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `parseEncodeTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `normalizeMermaidRuntimeConfig` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1529` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `installedFamilyStatementEnds` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:431` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1397` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `erCharge` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:204` |
| 0.0% | 1.0ms | 1.2% | 19.6ms | `flatIntoArrayWithCallback` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:159` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `getStreamOptions` | `internal:fs/streams` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `result` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `createEmissionContext` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.0ms | 0.5% | 8.5ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:130` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `deferredTerminalProjectionInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `rectangleInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:342` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:31` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `snapshotBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `assertMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:54` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `readErStatement` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:367` |
| 0.0% | 1.0ms | 0.1% | 2.2ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:98` |
| 0.0% | 998us | 0.0% | 998us | `walk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1756` |
| 0.0% | 994us | 0.0% | 994us | `resolveDiagramColors` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` |
| 0.0% | 991us | 0.0% | 991us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:894` |
| 0.0% | 983us | 0.1% | 2.2ms | `collectPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1376` |
| 0.0% | 979us | 0.0% | 979us | `writeSync` | `[native code]` |
| 0.0% | 978us | 0.0% | 978us | `scopeCssSelector` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.0% | 976us | 0.0% | 976us | `applyReplacements` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 974us | 0.0% | 974us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/er/creation.ts` |
| 0.0% | 967us | 0.0% | 967us | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:17` |
| 0.0% | 961us | 0.0% | 961us | `safeCssToken` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:87` |
| 0.0% | 947us | 0.0% | 947us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:121` |
| 0.0% | 946us | 0.0% | 946us | `endpointRelation` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1629` |
| 0.0% | 943us | 0.0% | 943us | `prepareWrittenCompoundShape` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts` |
| 0.0% | 938us | 0.0% | 938us | `validatePoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:465` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 55.9% | 865.0ms | 0.0% | 0us | `withTextMeasurementExecution` | `/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:135` |
| 38.9% | 602.4ms | 0.0% | 0us | `bound require` | `[native code]` |
| 38.9% | 602.4ms | 15.9% | 246.0ms | `require` | `[native code]` |
| 38.6% | 597.4ms | 0.0% | 0us | `measureRenderStage` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:30` |
| 38.5% | 596.3ms | 0.0% | 0us | `withSvgInspectionCache` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:20` |
| 38.5% | 596.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:31` |
| 38.5% | 596.3ms | 0.0% | 0us | `withPerformanceObserver` | `/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts:42` |
| 38.5% | 596.3ms | 0.0% | 0us | `withRenderStageObserver` | `/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:20` |
| 37.2% | 575.4ms | 0.0% | 0us | `consumeResolvedGraphicalRequest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:316` |
| 35.3% | 547.2ms | 13.9% | 216.5ms | `anonymous` | `[native code]` |
| 29.1% | 451.0ms | 0.6% | 9.8ms | `map` | `[native code]` |
| 23.3% | 361.1ms | 0.0% | 0us | `expandLocalReferences` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` |
| 23.2% | 359.6ms | 4.5% | 70.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` |
| 20.8% | 322.0ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:183` |
| 20.5% | 317.2ms | 6.5% | 101.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 17.2% | 267.5ms | 0.0% | 0us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:140` |
| 16.6% | 256.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:3` |
| 16.6% | 256.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:5` |
| 14.2% | 220.4ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:205` |
| 14.1% | 219.1ms | 0.0% | 0us | `withDeferredTerminalProjections` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:16` |
| 8.1% | 126.4ms | 0.0% | 0us | `renderResolvedMermaidSVG` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:270` |
| 8.1% | 126.4ms | 0.0% | 0us | `positionFamilyForNativeRender` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:67` |
| 7.9% | 122.4ms | 0.0% | 0us | `withGraphLayoutDecisionObserver` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:37` |
| 7.9% | 122.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:123` |
| 7.7% | 119.7ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:128` |
| 7.3% | 113.9ms | 7.3% | 113.9ms | `gc` | `[native code]` |
| 7.3% | 113.5ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:118` |
| 7.1% | 110.5ms | 0.2% | 4.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:161` |
| 6.7% | 104.0ms | 0.0% | 0us | `layout` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:27` |
| 6.0% | 94.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:45` |
| 6.0% | 93.0ms | 0.0% | 0us | `nativeCandidate` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1115` |
| 6.0% | 93.0ms | 0.0% | 0us | `runMeasuredGraphBackend` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:73` |
| 5.9% | 91.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:14` |
| 5.0% | 78.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:208` |
| 4.4% | 69.5ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:672` |
| 4.3% | 67.2ms | 0.0% | 0us | `serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:631` |
| 3.9% | 61.3ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:186` |
| 3.9% | 61.3ms | 0.0% | 0us | `positionedPaintCertification` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:154` |
| 3.5% | 55.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:3` |
| 3.4% | 53.0ms | 0.0% | 0us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:111` |
| 3.4% | 53.0ms | 0.0% | 0us | `report` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:235` |
| 3.0% | 47.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/decode-data-html.js:3` |
| 3.0% | 47.9ms | 3.0% | 47.9ms | `decodeBase64` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:22` |
| 2.9% | 45.6ms | 0.0% | 0us | `inspectOwnedSvgOnce` | `/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:46` |
| 2.7% | 43.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1188` |
| 2.7% | 43.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/agent/families.ts:8` |
| 2.7% | 42.5ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:123` |
| 2.7% | 41.8ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:137` |
| 2.6% | 41.2ms | 0.0% | 0us | `applyOutputSecurityPolicy` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:727` |
| 2.5% | 38.7ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1472` |
| 2.4% | 38.6ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:252` |
| 2.4% | 38.3ms | 0.0% | 0us | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:575` |
| 2.4% | 38.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:710` |
| 2.4% | 37.8ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:638` |
| 2.3% | 37.0ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:247` |
| 2.3% | 35.6ms | 0.0% | 0us | `inspectPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:98` |
| 2.1% | 32.7ms | 0.0% | 0us | `node:zlib` | `node:zlib:2` |
| 2.1% | 32.7ms | 0.0% | 0us | `node:stream` | `node:stream:2` |
| 2.0% | 32.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:5` |
| 2.0% | 31.3ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:242` |
| 2.0% | 31.2ms | 0.0% | 0us | `internal:stream` | `internal:stream:2` |
| 2.0% | 31.0ms | 0.0% | 0us | `nativePlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1163` |
| 1.9% | 30.8ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1502` |
| 1.6% | 25.9ms | 1.0% | 15.9ms | `stringify` | `[native code]` |
| 1.6% | 25.4ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1879` |
| 1.6% | 25.3ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:94` |
| 1.6% | 25.2ms | 0.0% | 0us | `internal:streams/compose` | `internal:streams/compose:2` |
| 1.5% | 23.9ms | 0.0% | 0us | `internal:streams/pipeline` | `internal:streams/pipeline:2` |
| 1.5% | 23.2ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:85` |
| 1.4% | 23.1ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:998` |
| 1.4% | 23.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:8` |
| 1.4% | 22.7ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:2` |
| 1.4% | 22.2ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:283` |
| 1.4% | 22.0ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1468` |
| 1.3% | 21.2ms | 0.1% | 2.3ms | `renderCardinality` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:590` |
| 1.3% | 20.3ms | 0.1% | 1.5ms | `deepFreeze` | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` |
| 1.2% | 19.8ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:208` |
| 1.2% | 19.6ms | 0.0% | 1.0ms | `flatIntoArrayWithCallback` | `[native code]` |
| 1.2% | 19.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:22` |
| 1.2% | 19.4ms | 0.0% | 0us | `renderCardinality` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:589` |
| 1.2% | 18.6ms | 0.0% | 0us | `retainOrder` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:76` |
| 1.2% | 18.6ms | 0.0% | 0us | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:39` |
| 1.1% | 18.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:13` |
| 1.1% | 18.1ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:218` |
| 1.1% | 18.0ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:167` |
| 1.1% | 17.8ms | 0.0% | 0us | `executeInspectedGraphicalRequest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:297` |
| 1.1% | 17.6ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:184` |
| 1.1% | 17.1ms | 0.0% | 0us | `layout` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:23` |
| 1.0% | 16.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:49` |
| 1.0% | 16.5ms | 0.0% | 0us | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:200` |
| 0.9% | 15.4ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1185` |
| 0.9% | 15.2ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1592` |
| 0.9% | 14.8ms | 0.0% | 0us | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1453` |
| 0.9% | 14.3ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1031` |
| 0.9% | 14.3ms | 0.0% | 0us | `render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:394` |
| 0.9% | 14.3ms | 0.0% | 0us | `rendered` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:427` |
| 0.9% | 14.1ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1878` |
| 0.9% | 14.0ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:252` |
| 0.9% | 13.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/directives.js:3` |
| 0.9% | 13.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:4` |
| 0.8% | 13.4ms | 0.0% | 0us | `captureNativeGroupParse` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:173` |
| 0.8% | 13.4ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:906` |
| 0.8% | 13.4ms | 0.0% | 0us | `groupValidation` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:506` |
| 0.8% | 13.4ms | 0.0% | 0us | `captureNativeGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:101` |
| 0.8% | 13.4ms | 0.8% | 13.4ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` |
| 0.8% | 13.3ms | 0.0% | 0us | `cloneValue` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.8% | 12.5ms | 0.0% | 0us | `tree` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:79` |
| 0.8% | 12.5ms | 0.0% | 0us | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:95` |
| 0.8% | 12.4ms | 0.0% | 0us | `inlineResolvedColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:636` |
| 0.8% | 12.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:32` |
| 0.7% | 12.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:175` |
| 0.7% | 12.2ms | 0.4% | 7.5ms | `Set` | `[native code]` |
| 0.7% | 12.1ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:166` |
| 0.7% | 12.1ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:90` |
| 0.7% | 12.0ms | 0.0% | 0us | `erCardinalityInk` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:126` |
| 0.7% | 12.0ms | 0.0% | 0us | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:37` |
| 0.7% | 11.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` |
| 0.7% | 11.7ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:228` |
| 0.7% | 11.7ms | 0.0% | 0us | `admitSceneDocumentWith` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:270` |
| 0.7% | 11.7ms | 0.0% | 0us | `assertAdmissibleSceneDoc` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation.ts:247` |
| 0.7% | 11.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:7` |
| 0.7% | 11.6ms | 0.2% | 3.7ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:170` |
| 0.7% | 11.4ms | 0.0% | 0us | `projectSvgCss` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:287` |
| 0.7% | 11.4ms | 0.0% | 0us | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:701` |
| 0.7% | 11.4ms | 0.0% | 0us | `markerTerminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:294` |
| 0.7% | 11.4ms | 0.0% | 0us | `prepareMarkerTerminals` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:9` |
| 0.7% | 11.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:4` |
| 0.7% | 11.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/common/map.js:4` |
| 0.7% | 11.2ms | 0.2% | 4.4ms | `some` | `[native code]` |
| 0.7% | 11.1ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:88` |
| 0.7% | 11.0ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:201` |
| 0.6% | 10.7ms | 0.4% | 7.3ms | `find` | `[native code]` |
| 0.6% | 10.1ms | 0.1% | 1.9ms | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` |
| 0.6% | 9.9ms | 0.0% | 0us | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:15` |
| 0.6% | 9.9ms | 0.0% | 0us | `get receipt` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:347` |
| 0.6% | 9.9ms | 0.0% | 0us | `parseErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:832` |
| 0.6% | 9.7ms | 0.0% | 0us | `walk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1749` |
| 0.6% | 9.5ms | 0.6% | 9.5ms | `defineProperties` | `[native code]` |
| 0.6% | 9.5ms | 0.6% | 9.5ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.6% | 9.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:10` |
| 0.6% | 9.4ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:150` |
| 0.6% | 9.4ms | 0.6% | 9.4ms | `getOwnPropertyDescriptor` | `[native code]` |
| 0.6% | 9.3ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:420` |
| 0.6% | 9.3ms | 0.3% | 4.6ms | `writeFileSync` | `[native code]` |
| 0.5% | 9.2ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:215` |
| 0.5% | 9.2ms | 0.0% | 0us | `collectNativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:146` |
| 0.5% | 9.2ms | 0.0% | 0us | `visitSvgStartTagsFresh` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:116` |
| 0.5% | 9.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:8` |
| 0.5% | 9.1ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1621` |
| 0.5% | 8.8ms | 0.5% | 8.8ms | `retainOrder` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.5% | 8.8ms | 0.0% | 1.3ms | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:682` |
| 0.5% | 8.8ms | 0.0% | 0us | `renderPositionedWithTextMeasurement` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:237` |
| 0.5% | 8.6ms | 0.0% | 0us | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:621` |
| 0.5% | 8.5ms | 0.0% | 0us | `layoutErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1128` |
| 0.5% | 8.5ms | 0.0% | 1.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:130` |
| 0.5% | 8.4ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1301` |
| 0.5% | 8.4ms | 0.0% | 0us | `finalizeErRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:28` |
| 0.5% | 8.1ms | 0.0% | 0us | `sort` | `[native code]` |
| 0.5% | 8.0ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:127` |
| 0.5% | 7.9ms | 0.0% | 0us | `drawn` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:421` |
| 0.5% | 7.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:330` |
| 0.5% | 7.8ms | 0.5% | 7.8ms | `freeze` | `[native code]` |
| 0.5% | 7.8ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:627` |
| 0.5% | 7.8ms | 0.0% | 0us | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:220` |
| 0.5% | 7.8ms | 0.5% | 7.8ms | `defineProperty` | `[native code]` |
| 0.5% | 7.7ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:94` |
| 0.4% | 7.6ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:171` |
| 0.4% | 7.6ms | 0.0% | 1.3ms | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:509` |
| 0.4% | 7.5ms | 0.2% | 3.7ms | `readFileSync` | `[native code]` |
| 0.4% | 7.4ms | 0.0% | 1.3ms | `paintAttribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:493` |
| 0.4% | 7.4ms | 0.0% | 0us | `paintAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:519` |
| 0.4% | 7.3ms | 0.0% | 1.4ms | `attachSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:495` |
| 0.4% | 7.3ms | 0.4% | 7.3ms | `hasOwn` | `[native code]` |
| 0.4% | 7.3ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1854` |
| 0.4% | 7.2ms | 0.0% | 0us | `measureErEntities` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:451` |
| 0.4% | 7.0ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:403` |
| 0.4% | 7.0ms | 0.2% | 3.3ms | `test` | `[native code]` |
| 0.4% | 6.9ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:652` |
| 0.4% | 6.8ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1737` |
| 0.4% | 6.8ms | 0.0% | 0us | `normalizeMermaidSourceWithOverrides` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:762` |
| 0.4% | 6.7ms | 0.1% | 1.6ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` |
| 0.4% | 6.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:36` |
| 0.4% | 6.6ms | 0.4% | 6.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:496` |
| 0.4% | 6.6ms | 0.0% | 0us | `roleStyleJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:496` |
| 0.4% | 6.6ms | 0.0% | 0us | `styleSpecJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:609` |
| 0.4% | 6.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:191` |
| 0.4% | 6.6ms | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:126` |
| 0.4% | 6.4ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:587` |
| 0.4% | 6.4ms | 0.1% | 2.5ms | `filter` | `[native code]` |
| 0.4% | 6.2ms | 0.4% | 6.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.4% | 6.2ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:214` |
| 0.4% | 6.2ms | 0.4% | 6.2ms | `receiptOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.3% | 6.1ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` |
| 0.3% | 6.1ms | 0.0% | 0us | `snapshotFamilyIdentity` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1514` |
| 0.3% | 6.1ms | 0.3% | 6.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` |
| 0.3% | 6.1ms | 0.0% | 0us | `captureFields` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` |
| 0.3% | 6.1ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1576` |
| 0.3% | 6.0ms | 0.3% | 6.0ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.3% | 5.9ms | 0.0% | 0us | `o` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 0.3% | 5.8ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:168` |
| 0.3% | 5.8ms | 0.0% | 0us | `canonicalOpeningTag` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:443` |
| 0.3% | 5.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:446` |
| 0.3% | 5.8ms | 0.0% | 0us | `canonicalizeSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:485` |
| 0.3% | 5.8ms | 0.3% | 5.8ms | `compareCodePointStrings` | `/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts:3` |
| 0.3% | 5.8ms | 0.3% | 5.8ms | `cloneObject` | `[native code]` |
| 0.3% | 5.8ms | 0.0% | 0us | `registerBuiltInStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:292` |
| 0.3% | 5.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:16` |
| 0.3% | 5.8ms | 0.3% | 5.8ms | `xmlAsciiLetter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` |
| 0.3% | 5.7ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:140` |
| 0.3% | 5.7ms | 0.2% | 4.6ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:240` |
| 0.3% | 5.6ms | 0.0% | 0us | `resolveSvgColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:758` |
| 0.3% | 5.6ms | 0.0% | 0us | `snapshotScenePrimitiveCell` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1548` |
| 0.3% | 5.6ms | 0.0% | 0us | `freezeDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1583` |
| 0.3% | 5.6ms | 0.0% | 0us | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1501` |
| 0.3% | 5.5ms | 0.1% | 2.1ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` |
| 0.3% | 5.4ms | 0.0% | 0us | `resolveRoleStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:251` |
| 0.3% | 5.4ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1008` |
| 0.3% | 5.3ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1480` |
| 0.3% | 5.3ms | 0.3% | 5.3ms | `consumeStringBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.3% | 5.3ms | 0.3% | 5.3ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` |
| 0.3% | 5.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:974` |
| 0.3% | 5.3ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1088` |
| 0.3% | 5.2ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:729` |
| 0.3% | 5.1ms | 0.0% | 0us | `visitSvgFirstTagAttributes` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:106` |
| 0.3% | 5.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:8` |
| 0.3% | 5.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/core/float.js:4` |
| 0.3% | 5.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:4` |
| 0.3% | 5.0ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:653` |
| 0.3% | 4.9ms | 0.0% | 0us | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:589` |
| 0.3% | 4.9ms | 0.3% | 4.9ms | `has` | `[native code]` |
| 0.3% | 4.9ms | 0.3% | 4.9ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2365` |
| 0.3% | 4.8ms | 0.2% | 3.5ms | `typographyAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:694` |
| 0.3% | 4.8ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:713` |
| 0.3% | 4.8ms | 0.0% | 1.2ms | `replace` | `[native code]` |
| 0.3% | 4.8ms | 0.3% | 4.8ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:30` |
| 0.3% | 4.8ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:237` |
| 0.3% | 4.7ms | 0.0% | 0us | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:453` |
| 0.3% | 4.7ms | 0.3% | 4.7ms | `arrayIteratorNextHelper` | `[native code]` |
| 0.3% | 4.6ms | 0.0% | 0us | `transformSvgCssValues` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:308` |
| 0.3% | 4.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:310` |
| 0.3% | 4.6ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:92` |
| 0.2% | 4.5ms | 0.0% | 0us | `renderRelationshipLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:543` |
| 0.2% | 4.5ms | 0.0% | 0us | `relationshipFrom` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1107` |
| 0.2% | 4.5ms | 0.0% | 0us | `parseErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:898` |
| 0.2% | 4.5ms | 0.0% | 0us | `enoughLead` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:300` |
| 0.2% | 4.5ms | 0.0% | 0us | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:569` |
| 0.2% | 4.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:168` |
| 0.2% | 4.4ms | 0.2% | 4.4ms | `WeakSet` | `[native code]` |
| 0.2% | 4.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:69` |
| 0.2% | 4.4ms | 0.2% | 4.4ms | `sourceIndexOf` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` |
| 0.2% | 4.3ms | 0.2% | 4.3ms | `trim` | `[native code]` |
| 0.2% | 4.3ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1782` |
| 0.2% | 4.3ms | 0.0% | 0us | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:739` |
| 0.2% | 4.3ms | 0.0% | 0us | `readErOuterStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:514` |
| 0.2% | 4.3ms | 0.0% | 0us | `findErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:698` |
| 0.2% | 4.2ms | 0.2% | 4.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:156` |
| 0.2% | 4.2ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` |
| 0.2% | 4.2ms | 0.2% | 4.2ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:596` |
| 0.2% | 4.1ms | 0.2% | 4.1ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:570` |
| 0.2% | 4.1ms | 0.0% | 0us | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:104` |
| 0.2% | 4.1ms | 0.0% | 0us | `xmlNameCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:87` |
| 0.2% | 4.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:16` |
| 0.2% | 4.0ms | 0.2% | 4.0ms | `finalizeFlatMeasuredMarkers` | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.2% | 4.0ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:95` |
| 0.2% | 4.0ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1782` |
| 0.2% | 4.0ms | 0.1% | 2.9ms | `every` | `[native code]` |
| 0.2% | 3.9ms | 0.2% | 3.9ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.2% | 3.9ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:164` |
| 0.2% | 3.9ms | 0.0% | 0us | `nativeGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:397` |
| 0.2% | 3.9ms | 0.0% | 0us | `attributeRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:19` |
| 0.2% | 3.9ms | 0.0% | 0us | `value` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:124` |
| 0.2% | 3.9ms | 0.2% | 3.9ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.2% | 3.8ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:125` |
| 0.2% | 3.8ms | 0.0% | 0us | `r` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` |
| 0.2% | 3.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6538` |
| 0.2% | 3.8ms | 0.2% | 3.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 0.2% | 3.8ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:346` |
| 0.2% | 3.7ms | 0.0% | 0us | `internal:validators` | `internal:validators:2` |
| 0.2% | 3.7ms | 0.0% | 0us | `node:fs` | `node:fs:8` |
| 0.2% | 3.7ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1783` |
| 0.2% | 3.7ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1728` |
| 0.2% | 3.7ms | 0.0% | 0us | `registerGroupEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:87` |
| 0.2% | 3.7ms | 0.0% | 0us | `emissionRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:75` |
| 0.2% | 3.7ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:633` |
| 0.2% | 3.7ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` |
| 0.2% | 3.7ms | 0.0% | 0us | `resolvedColorValue` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:601` |
| 0.2% | 3.7ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:343` |
| 0.2% | 3.7ms | 0.2% | 3.7ms | `xmlTokenAt` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:17` |
| 0.2% | 3.7ms | 0.2% | 3.7ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:171` |
| 0.2% | 3.6ms | 0.2% | 3.6ms | `traits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.2% | 3.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:141` |
| 0.2% | 3.6ms | 0.2% | 3.6ms | `mixedChannels` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:57` |
| 0.2% | 3.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:761` |
| 0.2% | 3.6ms | 0.0% | 0us | `resolveCss` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:736` |
| 0.2% | 3.6ms | 0.0% | 0us | `mixHex` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:52` |
| 0.2% | 3.6ms | 0.0% | 0us | `renderRelationshipLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:534` |
| 0.2% | 3.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-doc.js:4` |
| 0.2% | 3.5ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:172` |
| 0.2% | 3.5ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:738` |
| 0.2% | 3.5ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:195` |
| 0.2% | 3.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:3` |
| 0.2% | 3.5ms | 0.0% | 0us | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:624` |
| 0.2% | 3.5ms | 0.0% | 0us | `freezeFamilyConformanceReport` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1903` |
| 0.2% | 3.5ms | 0.0% | 0us | `installBuiltinFamily` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1882` |
| 0.2% | 3.4ms | 0.0% | 0us | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:785` |
| 0.2% | 3.4ms | 0.0% | 0us | `internal:streams/operators` | `internal:streams/operators:2` |
| 0.2% | 3.4ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1386` |
| 0.2% | 3.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/block/markers.ts:10` |
| 0.2% | 3.3ms | 0.0% | 0us | `nativePlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1139` |
| 0.2% | 3.3ms | 0.0% | 0us | `strokedBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:543` |
| 0.2% | 3.3ms | 0.0% | 0us | `erCardinalityEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:134` |
| 0.2% | 3.3ms | 0.0% | 0us | `(anonymous)` | `[native code]` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1532` |
| 0.2% | 3.3ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:181` |
| 0.2% | 3.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:26` |
| 0.2% | 3.3ms | 0.0% | 0us | `ensureSvgIdentity` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:92` |
| 0.2% | 3.3ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:617` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:473` |
| 0.2% | 3.3ms | 0.0% | 0us | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1097` |
| 0.2% | 3.3ms | 0.2% | 3.3ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:395` |
| 0.2% | 3.3ms | 0.0% | 0us | `nativePlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1154` |
| 0.2% | 3.3ms | 0.0% | 0us | `erLabelUnread` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1063` |
| 0.2% | 3.3ms | 0.0% | 0us | `parseErRelationshipSyntax` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1086` |
| 0.2% | 3.3ms | 0.0% | 0us | `readErStatement` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:298` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1289` |
| 0.2% | 3.2ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1483` |
| 0.2% | 3.2ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:359` |
| 0.2% | 3.2ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:250` |
| 0.2% | 3.2ms | 0.0% | 1.3ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:144` |
| 0.2% | 3.2ms | 0.0% | 0us | `node` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1456` |
| 0.2% | 3.2ms | 0.2% | 3.2ms | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:109` |
| 0.2% | 3.1ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:420` |
| 0.2% | 3.1ms | 0.2% | 3.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` |
| 0.1% | 3.0ms | 0.0% | 0us | `erTextLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/text.ts:107` |
| 0.1% | 3.0ms | 0.0% | 1.2ms | `erDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/er/text.ts:94` |
| 0.1% | 3.0ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:228` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `flatIntoArray` | `[native code]` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `graphicalSvgArtifact` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `nativeParseRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:132` |
| 0.1% | 3.0ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1776` |
| 0.1% | 3.0ms | 0.1% | 1.8ms | `indent` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:226` |
| 0.1% | 3.0ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:220` |
| 0.1% | 3.0ms | 0.1% | 3.0ms | `layoutSharedFan` | `/tmp/pr449-main-integration-20261029-762/src/layout/shared-fan-core.ts` |
| 0.1% | 3.0ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:199` |
| 0.1% | 2.9ms | 0.0% | 1.4ms | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:593` |
| 0.1% | 2.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:14` |
| 0.1% | 2.9ms | 0.0% | 0us | `registerCanonicalStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:230` |
| 0.1% | 2.9ms | 0.0% | 0us | `registerBuiltInStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:294` |
| 0.1% | 2.9ms | 0.0% | 0us | `frozenRoleStyles` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:173` |
| 0.1% | 2.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:766` |
| 0.1% | 2.9ms | 0.1% | 2.9ms | `fromEntries` | `[native code]` |
| 0.1% | 2.9ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:191` |
| 0.1% | 2.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/c4/config.ts:91` |
| 0.1% | 2.9ms | 0.1% | 2.9ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/c4/config.ts` |
| 0.1% | 2.8ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:323` |
| 0.1% | 2.8ms | 0.0% | 0us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:258` |
| 0.1% | 2.7ms | 0.0% | 0us | `nativePlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1150` |
| 0.1% | 2.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts:3` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `Segmenter` | `[native code]` |
| 0.1% | 2.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:810` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `validateRoleStyleRecord` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:309` |
| 0.1% | 2.7ms | 0.0% | 0us | `validateRoleStyles` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:340` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `slice` | `[native code]` |
| 0.1% | 2.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:55` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `classMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:21` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:417` |
| 0.1% | 2.7ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:646` |
| 0.1% | 2.7ms | 0.1% | 2.7ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:251` |
| 0.1% | 2.7ms | 0.0% | 0us | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:435` |
| 0.1% | 2.7ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1088` |
| 0.1% | 2.6ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:145` |
| 0.1% | 2.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:15` |
| 0.1% | 2.6ms | 0.0% | 0us | `validateSceneDocument` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1637` |
| 0.1% | 2.6ms | 0.1% | 2.6ms | `match` | `[native code]` |
| 0.1% | 2.6ms | 0.0% | 0us | `tree` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:71` |
| 0.1% | 2.6ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:313` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:27` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `snapshotDescriptorArray` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1498` |
| 0.1% | 2.5ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:221` |
| 0.1% | 2.5ms | 0.0% | 0us | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:702` |
| 0.1% | 2.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:6` |
| 0.1% | 2.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:5` |
| 0.1% | 2.5ms | 0.0% | 0us | `admitSceneDocumentWith` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:268` |
| 0.1% | 2.5ms | 0.0% | 1.2ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:526` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `exec` | `[native code]` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:40` |
| 0.1% | 2.5ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:156` |
| 0.1% | 2.5ms | 0.1% | 2.5ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:535` |
| 0.1% | 2.5ms | 0.0% | 0us | `nativeOrEmulated` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:448` |
| 0.1% | 2.4ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:464` |
| 0.1% | 2.4ms | 0.0% | 0us | `setConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:53` |
| 0.1% | 2.4ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1328` |
| 0.1% | 2.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1245` |
| 0.1% | 2.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:4` |
| 0.1% | 2.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:14` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `transferSceneNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.1% | 2.4ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:110` |
| 0.1% | 2.4ms | 0.0% | 0us | `completeBuiltinDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1384` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `declareFamilyScenePrimitiveEvidence` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:253` |
| 0.1% | 2.4ms | 0.1% | 2.4ms | `finishXmlLeaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.1% | 2.3ms | 0.0% | 0us | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:628` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `runMeasuredGraphBackend` | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts` |
| 0.1% | 2.3ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1765` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `factOf` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.1% | 2.3ms | 0.0% | 0us | `read` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:258` |
| 0.1% | 2.3ms | 0.0% | 1.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` |
| 0.1% | 2.3ms | 0.0% | 0us | `serialize` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:633` |
| 0.1% | 2.3ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:674` |
| 0.1% | 2.3ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:202` |
| 0.1% | 2.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:202` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `canonicalExtensionId` | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts` |
| 0.1% | 2.3ms | 0.0% | 0us | `registerBuiltInStyle` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:291` |
| 0.1% | 2.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:548` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `includes` | `[native code]` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `xmlSlice` | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` |
| 0.1% | 2.3ms | 0.0% | 1.1ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` |
| 0.1% | 2.3ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:135` |
| 0.1% | 2.3ms | 0.1% | 2.3ms | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 0.1% | 2.3ms | 0.0% | 0us | `get WriteStream` | `node:fs:667` |
| 0.1% | 2.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:55` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:55` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:485` |
| 0.1% | 2.2ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:224` |
| 0.1% | 2.2ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:185` |
| 0.1% | 2.2ms | 0.0% | 0us | `scopeCss` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:118` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `transferRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.1% | 2.2ms | 0.0% | 0us | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:102` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts:240` |
| 0.1% | 2.2ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:311` |
| 0.1% | 2.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:786` |
| 0.1% | 2.2ms | 0.0% | 0us | `relationEnd` | `/tmp/pr449-main-integration-20261029-762/src/er/creation.ts:99` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `name` | `/tmp/pr449-main-integration-20261029-762/src/er/creation.ts` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `resolveSceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.1% | 2.2ms | 0.0% | 0us | `relationAccessibility` | `/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` |
| 0.1% | 2.2ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:193` |
| 0.1% | 2.2ms | 0.0% | 0us | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:101` |
| 0.1% | 2.2ms | 0.0% | 0us | `sceneRoleTraits` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` |
| 0.1% | 2.2ms | 0.0% | 983us | `collectPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1376` |
| 0.1% | 2.2ms | 0.0% | 0us | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1395` |
| 0.1% | 2.2ms | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:178` |
| 0.1% | 2.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:22` |
| 0.1% | 2.2ms | 0.0% | 0us | `svgStyleRanges` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:294` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `RegExp` | `[native code]` |
| 0.1% | 2.2ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:253` |
| 0.1% | 2.2ms | 0.0% | 1.0ms | `finite` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:98` |
| 0.1% | 2.2ms | 0.0% | 0us | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:387` |
| 0.1% | 2.2ms | 0.1% | 2.2ms | `connectorUnitTangent` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `copyDataProperties` | `[native code]` |
| 0.1% | 2.1ms | 0.0% | 0us | `next` | `[native code]` |
| 0.1% | 2.1ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1365` |
| 0.1% | 2.1ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:122` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:672` |
| 0.1% | 2.1ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:206` |
| 0.1% | 2.1ms | 0.0% | 0us | `collides` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:173` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:66` |
| 0.1% | 2.1ms | 0.0% | 0us | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:277` |
| 0.1% | 2.1ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:169` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `admitWritableSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:501` |
| 0.1% | 2.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/requirement/markers.ts:4` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:13` |
| 0.1% | 2.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:5` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.1% | 2.1ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:726` |
| 0.1% | 2.1ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1045` |
| 0.1% | 2.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:328` |
| 0.1% | 2.1ms | 0.1% | 2.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:520` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:220` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `validSceneRoleDeclaration` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1603` |
| 0.1% | 2.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1742` |
| 0.1% | 2.0ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1742` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-named-colors.ts:3` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.1% | 2.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/default-backend.ts:5` |
| 0.1% | 2.0ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:582` |
| 0.1% | 2.0ms | 0.0% | 0us | `erFrameInkPadding` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:767` |
| 0.1% | 2.0ms | 0.1% | 2.0ms | `buildInkTree` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.1% | 2.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:5` |
| 0.1% | 2.0ms | 0.0% | 0us | `internal:streams/legacy` | `internal:streams/legacy:2` |
| 0.1% | 2.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:665` |
| 0.1% | 2.0ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:163` |
| 0.1% | 2.0ms | 0.0% | 0us | `opaqueOutlineWidth` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:149` |
| 0.1% | 2.0ms | 0.0% | 0us | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:694` |
| 0.1% | 2.0ms | 0.0% | 0us | `opaque` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:143` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `tag` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:152` |
| 0.1% | 1.9ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:148` |
| 0.1% | 1.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:5` |
| 0.1% | 1.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:3` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `erRelationshipStyle` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:15` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `retainOrder` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:77` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `bisector` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js` |
| 0.1% | 1.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:78` |
| 0.1% | 1.9ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1322` |
| 0.1% | 1.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1256` |
| 0.1% | 1.9ms | 0.0% | 0us | `snapshot` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1318` |
| 0.1% | 1.9ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:11` |
| 0.1% | 1.9ms | 0.0% | 0us | `markerBoundsAt` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:245` |
| 0.1% | 1.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/architecture/markers.ts:16` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `validateRoleStyles` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` |
| 0.1% | 1.9ms | 0.0% | 0us | `hint` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:359` |
| 0.1% | 1.9ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:681` |
| 0.1% | 1.9ms | 0.0% | 0us | `ownValue` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:43` |
| 0.1% | 1.9ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1764` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:581` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:646` |
| 0.1% | 1.9ms | 0.0% | 0us | `inspectSecurityTail` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:697` |
| 0.1% | 1.9ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:312` |
| 0.1% | 1.9ms | 0.0% | 0us | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:626` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `invalidateFractionalCircle` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.1% | 1.9ms | 0.1% | 1.9ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:93` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `isWhitespace` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `circleMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts` |
| 0.1% | 1.8ms | 0.0% | 0us | `flowchartMarkerResources` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:81` |
| 0.1% | 1.8ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:114` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:229` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:96` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1161` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `normalizePlainLabel` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:47` |
| 0.1% | 1.8ms | 0.0% | 0us | `normalizeBrTags` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:25` |
| 0.1% | 1.8ms | 0.0% | 0us | `normalizedErText` | `/tmp/pr449-main-integration-20261029-762/src/er/text.ts:87` |
| 0.1% | 1.8ms | 0.0% | 0us | `internal:streams/readable` | `internal:streams/readable:703` |
| 0.1% | 1.8ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:9` |
| 0.1% | 1.8ms | 0.1% | 1.8ms | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:212` |
| 0.1% | 1.7ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:716` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `join` | `[native code]` |
| 0.1% | 1.7ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:115` |
| 0.1% | 1.7ms | 0.0% | 0us | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:15` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `advance` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:199` |
| 0.1% | 1.7ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:132` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `charge` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:83` |
| 0.1% | 1.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:152` |
| 0.1% | 1.7ms | 0.0% | 0us | `internal:streams/readable` | `internal:streams/readable:2` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `retainOrder` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:75` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `validateNodeSerialization` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:703` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `min` | `[native code]` |
| 0.1% | 1.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:143` |
| 0.1% | 1.7ms | 0.0% | 0us | `assessFamilyLayout` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:266` |
| 0.1% | 1.7ms | 0.0% | 0us | `assessRenderedLayoutHardViolations` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:211` |
| 0.1% | 1.7ms | 0.0% | 0us | `rectOverlap` | `/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:164` |
| 0.1% | 1.7ms | 0.0% | 0us | `parseErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:810` |
| 0.1% | 1.7ms | 0.0% | 0us | `scanAccessibilityDirectives` | `/tmp/pr449-main-integration-20261029-762/src/shared/accessibility-directives.ts:125` |
| 0.1% | 1.7ms | 0.1% | 1.7ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts:32` |
| 0.1% | 1.7ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:96` |
| 0.1% | 1.7ms | 0.0% | 0us | `shortenMeasuredRoutes` | `/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts:31` |
| 0.1% | 1.6ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/architecture/config-diagnostics.ts:6` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `numericLike` | `/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` |
| 0.1% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:111` |
| 0.1% | 1.6ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:106` |
| 0.1% | 1.6ms | 0.0% | 0us | `transformedBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:471` |
| 0.1% | 1.6ms | 0.0% | 0us | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1091` |
| 0.1% | 1.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1131` |
| 0.1% | 1.6ms | 0.0% | 0us | `receiptOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:758` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `canonicalJson` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1100` |
| 0.1% | 1.6ms | 0.0% | 0us | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:102` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:167` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.1% | 1.6ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1267` |
| 0.1% | 1.6ms | 0.0% | 0us | `structurallyEqual` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1280` |
| 0.1% | 1.6ms | 0.0% | 0us | `validateConnectorProjectionConsistency` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1364` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `erRelationshipStyle` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.1% | 1.6ms | 0.0% | 0us | `nativePlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1137` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:603` |
| 0.1% | 1.6ms | 0.1% | 1.6ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.1% | 1.6ms | 0.0% | 0us | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:442` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `connectorContourSemantics` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:381` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `hint` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:168` |
| 0.1% | 1.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:255` |
| 0.1% | 1.5ms | 0.1% | 1.5ms | `crowsFootMark` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:618` |
| 0.1% | 1.5ms | 0.0% | 0us | `semanticIdentityForSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:56` |
| 0.1% | 1.5ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:588` |
| 0.1% | 1.5ms | 0.0% | 0us | `attr` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:53` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:173` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 1.5ms | 0.0% | 0us | `createRenderOutputDescriptors` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:171` |
| 0.0% | 1.5ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:191` |
| 0.0% | 1.5ms | 0.0% | 0us | `normalizeMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:663` |
| 0.0% | 1.5ms | 0.0% | 0us | `mermaidFirstLine` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:149` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `stripMermaidDirectives` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `qualify` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:27` |
| 0.0% | 1.4ms | 0.0% | 0us | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:157` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `layoutMeasuredForest` | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:222` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:763` |
| 0.0% | 1.4ms | 0.0% | 0us | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:92` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `create` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:98` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:532` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `connector/subpaths/render` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `serializeLinearGradientResource` | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts:91` |
| 0.0% | 1.4ms | 0.0% | 0us | `paintedStrokeExtent` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:511` |
| 0.0% | 1.4ms | 0.0% | 0us | `retainedNativeDrawing` | `/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:90` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `sceneAssertionsEnabled` | `/tmp/pr449-main-integration-20261029-762/src/scene/assertions.ts:28` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `floor` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 0us | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:36` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `assertRenderableLinearGradient` | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `serializeLinearGradientResource` | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts:78` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `erTextLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/text.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `internal:stream` | `internal:stream:46` |
| 0.0% | 1.4ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:676` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `element` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:301` |
| 0.0% | 1.4ms | 0.0% | 0us | `element` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:477` |
| 0.0% | 1.4ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:778` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `validateChannels` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:580` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:100` |
| 0.0% | 1.4ms | 0.0% | 0us | `documentClose` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:140` |
| 0.0% | 1.4ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:153` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `importModule` | `[native code]` |
| 0.0% | 1.4ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:10` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:173` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.4ms | 0.0% | 0us | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:520` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:5` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `performIteration` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `createNativePaintEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `prepareDisplayText` | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:740` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `applyFamilyRequestNormalization` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1075` |
| 0.0% | 1.3ms | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1656` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `assertFamilyGeometryOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:858` |
| 0.0% | 1.3ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:611` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:611` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:739` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:114` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `inspectPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `advance` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `localPaintResourceReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1385` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `normalizeMermaidSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:667` |
| 0.0% | 1.3ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:80` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `inspectSecurity` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:673` |
| 0.0% | 1.3ms | 0.0% | 0us | `runBackendConformance` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1049` |
| 0.0% | 1.3ms | 0.0% | 0us | `verifyNoExternalRefs` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:701` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `startTags` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:65` |
| 0.0% | 1.3ms | 0.0% | 0us | `renderPreparedLine` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:178` |
| 0.0% | 1.3ms | 0.0% | 0us | `sharedRenderOptionsJsonSchema` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:485` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:181` |
| 0.0% | 1.3ms | 0.0% | 0us | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:275` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:454` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1841` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1841` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `detectsArchitectureFamily` | `/tmp/pr449-main-integration-20261029-762/src/shared/builtin-family-detection.ts` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `/<(?:[^\s<>/:]+:)?foreignObject\b/i` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 0us | `inspectSecurityTail` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:691` |
| 0.0% | 1.3ms | 0.0% | 0us | `paintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:676` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `preparedInterTextBounds` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:123` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `hitsTransformed` | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:48` |
| 0.0% | 1.3ms | 0.0% | 0us | `connector/interaction/hit-test` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:870` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:5` |
| 0.0% | 1.3ms | 0.0% | 0us | `tryParseCssColor` | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:3` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `parseInt` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:335` |
| 0.0% | 1.3ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:300` |
| 0.0% | 1.3ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:298` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:405` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `styledRunLayout` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `measureErEntities` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:453` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:218` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `ArrayBuffer` | `[native code]` |
| 0.0% | 1.3ms | 0.0% | 0us | `node:zlib` | `node:zlib:159` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `safeCssPaint` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts` |
| 0.0% | 1.3ms | 0.0% | 0us | `validatePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:311` |
| 0.0% | 1.3ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:817` |
| 0.0% | 1.3ms | 0.0% | 0us | `(module)` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:12` |
| 0.0% | 1.3ms | 0.0% | 0us | `placeRelationshipLabels` | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:198` |
| 0.0% | 1.3ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1558` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `terminalDepth` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1251` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:224` |
| 0.0% | 1.2ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:145` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `serializeLinearGradientResources` | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:993` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:69` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:33` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:71` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `overlaps` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:172` |
| 0.0% | 1.2ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:60` |
| 0.0% | 1.2ms | 0.0% | 0us | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:230` |
| 0.0% | 1.2ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1561` |
| 0.0% | 1.2ms | 0.0% | 0us | `scopedRule` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:131` |
| 0.0% | 1.2ms | 0.0% | 0us | `executionCapabilityDecision` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1453` |
| 0.0% | 1.2ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1546` |
| 0.0% | 1.2ms | 0.0% | 0us | `negotiateCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts:127` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `isCapabilityId` | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `checkInertGroup` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:35` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `set` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `result` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:406` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `readXmlNameEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:407` |
| 0.0% | 1.2ms | 0.0% | 0us | `issue` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:91` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `shape` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `requiredBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1363` |
| 0.0% | 1.2ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1485` |
| 0.0% | 1.2ms | 0.0% | 0us | `node:zlib` | `node:zlib:449` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `withDeferredTerminalProjections` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:43` |
| 0.0% | 1.2ms | 0.0% | 0us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:171` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `visit` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `/^(?:class\|data-[a-z][a-z0-9-]*\|role\|aria-[a-z]+\|tabindex\|pointer-events\|transform\|style)$/` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `checkAllClassLikeAuthoredStyles` | `/tmp/pr449-main-integration-20261029-762/src/shared/style-props.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `layout` | `/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:26` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:765` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:465` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validate` | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:153` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `diagramColorVariables` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:591` |
| 0.0% | 1.2ms | 0.0% | 0us | `toneOnFill` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:196` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` |
| 0.0% | 1.2ms | 0.0% | 0us | `localPaintResourceId` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:373` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:fs/streams` | `internal:fs/streams:2` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `nonPainting` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:129` |
| 0.0% | 1.2ms | 0.0% | 0us | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1944` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `include` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `connectorMarkerPaintRegions` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:352` |
| 0.0% | 1.2ms | 0.0% | 0us | `forEach` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1066` |
| 0.0% | 1.2ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1507` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateAggregateReferences` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1525` |
| 0.0% | 1.2ms | 0.0% | 0us | `drawNative` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:219` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:185` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:201` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:570` |
| 0.0% | 1.2ms | 0.0% | 0us | `graphicalBackendCapabilityClaims` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:271` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `primitiveCapabilityClaimKey` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `createSketchBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:547` |
| 0.0% | 1.2ms | 0.0% | 0us | `validatePrimitiveCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:333` |
| 0.0% | 1.2ms | 0.0% | 0us | `admitRenderContractDigestInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1150` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `omitUndefinedObjectFields` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:978` |
| 0.0% | 1.2ms | 0.0% | 0us | `group` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:146` |
| 0.0% | 1.2ms | 0.0% | 0us | `renderContractDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1118` |
| 0.0% | 1.2ms | 0.0% | 0us | `boundedImmutableJsonSnapshot` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1242` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `ownsParts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `resolveExecutionPlan` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1572` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:175` |
| 0.0% | 1.2ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1491` |
| 0.0% | 1.2ms | 0.0% | 0us | `renderRelationshipLabel` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:527` |
| 0.0% | 1.2ms | 0.0% | 0us | `validatePoint` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:434` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `consumePointBudget` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1094` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/resource-manifest.ts:64` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `writeTextSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:736` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `scenePrimitiveMatrix` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `outlineKey` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:154` |
| 0.0% | 1.2ms | 0.0% | 0us | `node:fs` | `node:fs:739` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `setName` | `node:fs:696` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `validateMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:800` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:errors` | `internal:errors:2` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `makeSafe` | `internal:primordials` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:76` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:6` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:streams/destroy` | `internal:streams/destroy:2` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:538` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `materializeText` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:94` |
| 0.0% | 1.2ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1106` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `numericCss` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.2ms | 0.0% | 0us | `formatSvgNumericAttribute` | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:41` |
| 0.0% | 1.2ms | 0.0% | 0us | `lowerErDrawing` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:90` |
| 0.0% | 1.2ms | 0.0% | 0us | `svgOpenTag` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:429` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:247` |
| 0.0% | 1.1ms | 0.0% | 0us | `pathBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:143` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `py` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:139` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isServerConfig` | `bun:main` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `bun:main:14` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `factOf` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:97` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:219` |
| 0.0% | 1.1ms | 0.0% | 0us | `deriveConnectorTerminalProjection` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:108` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `connectorEndpointMarkerAnchors` | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:106` |
| 0.0% | 1.1ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:181` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `possibleShapeStroke` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:133` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:90` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:532` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `createFixture` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:314` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateSerializableRenderOptions` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `prepareErText` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:151` |
| 0.0% | 1.1ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:339` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:341` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:22` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:174` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:840` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isRetainedPixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:86` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateDescriptor` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1763` |
| 0.0% | 1.1ms | 0.0% | 0us | `solidInteriors` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:215` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `resolvedFamilyRenderContextOf` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `layoutLayeredGraph` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:701` |
| 0.0% | 1.1ms | 0.0% | 0us | `positionFamily` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:94` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `assignPorts` | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:688` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `/\sdata-role="[^"]*"/` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:87` |
| 0.0% | 1.1ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:640` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `xmlScalarCharacter` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:88` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `renderCardinality` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `join` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:205` |
| 0.0% | 1.1ms | 0.0% | 0us | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:536` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `hypot` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:803` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `hooks` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:511` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `segmentThroughShape` | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `connectorPaintBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:592` |
| 0.0% | 1.1ms | 0.0% | 0us | `geometryBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:209` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `pointsBounds` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:16` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `ownFragment` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:116` |
| 0.0% | 1.1ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:259` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `hasInheritedTextPaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` |
| 0.0% | 1.1ms | 0.0% | 0us | `observe` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:596` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveColors` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:474` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioning.ts:142` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `projectErPositioned` | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:11` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `get` | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:745` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `serializeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateStyleSpec` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:472` |
| 0.0% | 1.1ms | 0.0% | 0us | `hasOwned` | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:11` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:560` |
| 0.0% | 1.1ms | 0.0% | 0us | `copy` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:213` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `safeCssToken` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:69` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `get` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `Transform` | `internal:streams/transform` |
| 0.0% | 1.1ms | 0.0% | 0us | `Zlib` | `node:zlib:298` |
| 0.0% | 1.1ms | 0.0% | 0us | `gzipSync` | `node:zlib:360` |
| 0.0% | 1.1ms | 0.0% | 0us | `ZlibBase` | `node:zlib:123` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:62` |
| 0.0% | 1.1ms | 0.0% | 0us | `Gzip` | `node:zlib:328` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateMarker` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:941` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `certifyNativePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1930` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `admitRenderOptionsInput` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `resolveRenderRequestForExecution` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1709` |
| 0.0% | 1.1ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:486` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `pay` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.1ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:805` |
| 0.0% | 1.1ms | 0.0% | 0us | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:304` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `sanitizeTextControls` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:9` |
| 0.0% | 1.1ms | 0.0% | 0us | `verifyDocumentEnvelope` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts:411` |
| 0.0% | 1.1ms | 0.0% | 0us | `sanitizeDisplayLines` | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `add` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `escapeDisplayAttr` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:115` |
| 0.0% | 1.1ms | 0.0% | 0us | `renderEntityBox` | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:197` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1129` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `renderMultilineText` | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:254` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:298` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `canonicalTextDigest` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1172` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `parseEncodeTrie` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js` |
| 0.0% | 1.0ms | 0.0% | 0us | `(module)` | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/encode-html.js:10` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `normalizeMermaidRuntimeConfig` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:744` |
| 0.0% | 1.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1527` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1529` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `installedFamilyStatementEnds` | `/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` |
| 0.0% | 1.0ms | 0.0% | 0us | `normalizeSource` | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:697` |
| 0.0% | 1.0ms | 0.0% | 0us | `connectorInlineLabelText` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:427` |
| 0.0% | 1.0ms | 0.0% | 0us | `connectorInlineLabelSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:761` |
| 0.0% | 1.0ms | 0.0% | 0us | `preparePixelText` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:430` |
| 0.0% | 1.0ms | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:780` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:431` |
| 0.0% | 1.0ms | 0.0% | 0us | `writeConnectorSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:829` |
| 0.0% | 1.0ms | 0.0% | 0us | `resolvedColorValue` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:599` |
| 0.0% | 1.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1397` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1397` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `readXmlDataEnd` | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `canonicalErContacts` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:249` |
| 0.0% | 1.0ms | 0.0% | 0us | `repairErFrameRoutes` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:273` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `erCharge` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:204` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Collection.js:3` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:4` |
| 0.0% | 1.0ms | 0.0% | 0us | `extractErLayout` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:634` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `attribute` | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:159` |
| 0.0% | 1.0ms | 0.0% | 0us | `WriteStream` | `internal:fs/streams:201` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `getStreamOptions` | `internal:fs/streams` |
| 0.0% | 1.0ms | 0.0% | 0us | `write` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1473` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `boundedUtf8ByteLength` | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `result` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `createNativePaintEmission` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:56` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `createEmissionContext` | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `nativePlacement` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1171` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `parts` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `deferredTerminalProjectionInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `copyInner` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:125` |
| 0.0% | 1.0ms | 0.0% | 0us | `writeShapeSvg` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:678` |
| 0.0% | 1.0ms | 0.0% | 0us | `writeSceneNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `geometryAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `lineStrokeBox` | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `rectangleInput` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:342` |
| 0.0% | 1.0ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:644` |
| 0.0% | 1.0ms | 0.0% | 0us | `chargeInkSort` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:7` |
| 0.0% | 1.0ms | 0.0% | 0us | `finishErGeometry` | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1389` |
| 0.0% | 1.0ms | 0.0% | 0us | `build` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:34` |
| 0.0% | 1.0ms | 0.0% | 0us | `compare` | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:33` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `set` | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `scopeHash` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:31` |
| 0.0% | 1.0ms | 0.0% | 0us | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:470` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `snapshotBackendCapabilities` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `freezeBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:403` |
| 0.0% | 1.0ms | 0.0% | 0us | `scanTagEnd` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:59` |
| 0.0% | 1.0ms | 0.0% | 0us | `connector` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:315` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `assertMarkAttributes` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:54` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `readErStatement` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:689` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `sameRectanglePaint` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:367` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `registerBuiltInBackend` | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.0% | 1.0ms | 0.0% | 0us | `renderedSvgDigest` | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:61` |
| 0.0% | 998us | 0.0% | 998us | `walk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1756` |
| 0.0% | 994us | 0.0% | 0us | `resolveAppearance` | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1655` |
| 0.0% | 994us | 0.0% | 994us | `resolveDiagramColors` | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` |
| 0.0% | 991us | 0.0% | 991us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:894` |
| 0.0% | 979us | 0.0% | 979us | `writeSync` | `[native code]` |
| 0.0% | 979us | 0.0% | 0us | `zlibBufferSync` | `node:zlib:94` |
| 0.0% | 979us | 0.0% | 0us | `processChunkSync` | `node:zlib:203` |
| 0.0% | 978us | 0.0% | 978us | `scopeCssSelector` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.0% | 978us | 0.0% | 0us | `scopedRule` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:137` |
| 0.0% | 976us | 0.0% | 976us | `applyReplacements` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 0.0% | 976us | 0.0% | 0us | `parseErDiagram` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:902` |
| 0.0% | 974us | 0.0% | 0us | `readErStatements` | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:800` |
| 0.0% | 974us | 0.0% | 974us | `finish` | `/tmp/pr449-main-integration-20261029-762/src/er/creation.ts` |
| 0.0% | 967us | 0.0% | 967us | `consume` | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:17` |
| 0.0% | 961us | 0.0% | 0us | `colorResolution` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:702` |
| 0.0% | 961us | 0.0% | 0us | `cssPaintDefinitions` | `/tmp/pr449-main-integration-20261029-762/src/theme.ts:613` |
| 0.0% | 961us | 0.0% | 961us | `safeCssToken` | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:87` |
| 0.0% | 947us | 0.0% | 947us | `scanStartTags` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:121` |
| 0.0% | 947us | 0.0% | 0us | `scopeSvgStyles` | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:176` |
| 0.0% | 947us | 0.0% | 0us | `svgRootStartTag` | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:202` |
| 0.0% | 946us | 0.0% | 0us | `walk` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1757` |
| 0.0% | 946us | 0.0% | 946us | `endpointRelation` | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1629` |
| 0.0% | 943us | 0.0% | 943us | `prepareWrittenCompoundShape` | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts` |
| 0.0% | 943us | 0.0% | 0us | `leaf` | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:645` |
| 0.0% | 938us | 0.0% | 0us | `validateNode` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1056` |
| 0.0% | 938us | 0.0% | 0us | `validateGeometry` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:524` |
| 0.0% | 938us | 0.0% | 938us | `validatePoints` | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:465` |
| 0.0% | 936us | 0.0% | 0us | `text` | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:495` |

## Function Details

### `require`
`[native code]` | Self: 15.9% (246.0ms) | Total: 38.9% (602.4ms) | Samples: 1

**Called by:**
- `bound require` (74)

**Calls:**
- `anonymous` (73)

### `anonymous`
`[native code]` | Self: 13.9% (216.5ms) | Total: 35.3% (547.2ms) | Samples: 40

**Called by:**
- `require` (73)
- `node:zlib` (14)
- `node:stream` (14)
- `internal:stream` (13)
- `internal:streams/compose` (11)
- `internal:streams/pipeline` (10)
- `internal:streams/duplex` (9)
- `get WriteStream` (2)
- `node:fs` (1)
- `internal:stream` (1)
- `internal:streams/legacy` (1)
- `internal:streams/operators` (1)
- `internal:fs/streams` (1)
- `internal:errors` (1)
- `internal:streams/readable` (1)
- `internal:validators` (1)
- `internal:streams/destroy` (1)

**Calls:**
- `node:stream` (14)
- `internal:stream` (13)
- `internal:streams/compose` (11)
- `internal:streams/pipeline` (10)
- `(anonymous)` (10)
- `internal:streams/duplex` (9)
- `(anonymous)` (5)
- `(anonymous)` (4)
- `(anonymous)` (4)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:streams/readable` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:primordials` (1)
- `internal:streams/readable` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:errors` (1)
- `(anonymous)` (1)
- `internal:streams/operators` (1)
- `internal:streams/legacy` (1)
- `(anonymous)` (1)
- `internal:validators` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `internal:stream` (1)
- `(anonymous)` (1)
- `internal:fs/streams` (1)
- `internal:streams/destroy` (1)

### `gc`
`[native code]` | Self: 7.3% (113.9ms) | Total: 7.3% (113.9ms) | Samples: 70

**Called by:**
- `(module)` (56)
- `(module)` (14)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 6.5% (101.2ms) | Total: 20.5% (317.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (6)
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (6)
- `r` (2)
- `o` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` | Self: 4.5% (70.1ms) | Total: 23.2% (359.6ms) | Samples: 5

**Called by:**
- `map` (31)

**Calls:**
- `expandLocalReferences` (26)

### `decodeBase64`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js:22` | Self: 3.0% (47.9ms) | Total: 3.0% (47.9ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `stringify`
`[native code]` | Self: 1.0% (15.9ms) | Total: 1.6% (25.9ms) | Samples: 7

**Called by:**
- `consume` (4)
- `solidInteriors` (3)
- `solidInteriors` (1)
- `(anonymous)` (1)
- `renderedSvgDigest` (1)
- `validateNode` (1)

**Calls:**
- `get receipt` (4)

### `indent`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:237` | Self: 0.8% (13.4ms) | Total: 0.8% (13.4ms) | Samples: 7

**Called by:**
- `(anonymous)` (7)

### `map`
`[native code]` | Self: 0.6% (9.8ms) | Total: 29.1% (451.0ms) | Samples: 6

**Called by:**
- `expandLocalReferences` (32)
- `cloneValue` (10)
- `prepareMarkerTerminals` (6)
- `runBackendConformance` (3)
- `(anonymous)` (2)
- `transformSvgCssValues` (2)
- `flatIntoArrayWithCallback` (2)
- `solidInteriors` (2)
- `captureFields` (1)
- `node:zlib` (1)
- `assignPorts` (1)
- `finishErGeometry` (1)
- `extractErLayout` (1)
- `renderPreparedLine` (1)
- `sanitizeDisplayLines` (1)
- `serializeLinearGradientResource` (1)
- `projectErPositioned` (1)
- `roleStyleJsonSchema` (1)
- `(module)` (1)
- `pointsBounds` (1)
- `crowsFootMark` (1)
- `connector` (1)
- `scopedRule` (1)
- `renderMultilineText` (1)
- `prepareErText` (1)
- `layoutLayeredGraph` (1)
- `nativePlacement` (1)
- `shortenMeasuredRoutes` (1)
- `deriveConnectorTerminalProjection` (1)
- `writeSceneNode` (1)
- `canonicalJson` (1)
- `createRenderOutputDescriptors` (1)
- `solidInteriors` (1)

**Calls:**
- `(anonymous)` (31)
- `(anonymous)` (9)
- `(anonymous)` (5)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `cloneValue` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `scopeCssSelector` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `sanitizeTextControls` (1)
- `possibleShapeStroke` (1)
- `canonicalJson` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `defineProperties`
`[native code]` | Self: 0.6% (9.5ms) | Total: 0.6% (9.5ms) | Samples: 4

**Called by:**
- `attributeRecord` (2)
- `emissionRecord` (1)
- `internal:streams/readable` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` | Self: 0.6% (9.5ms) | Total: 0.6% (9.5ms) | Samples: 5

**Called by:**
- `layoutLayeredGraph` (5)

### `getOwnPropertyDescriptor`
`[native code]` | Self: 0.6% (9.4ms) | Total: 0.6% (9.4ms) | Samples: 5

**Called by:**
- `copyInner` (4)
- `ownValue` (1)

### `retainOrder`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.5% (8.8ms) | Total: 0.5% (8.8ms) | Samples: 2

**Called by:**
- `tree` (2)

### `freeze`
`[native code]` | Self: 0.5% (7.8ms) | Total: 0.5% (7.8ms) | Samples: 5

**Called by:**
- `snapshotScenePrimitiveCell` (2)
- `inspectSecurityTail` (1)
- `issue` (1)
- `parts` (1)

### `defineProperty`
`[native code]` | Self: 0.5% (7.8ms) | Total: 0.5% (7.8ms) | Samples: 5

**Called by:**
- `copyInner` (5)

### `Set`
`[native code]` | Self: 0.4% (7.5ms) | Total: 0.7% (12.2ms) | Samples: 4

**Called by:**
- `resolveRoleStyle` (3)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `(module)` (1)

**Calls:**
- `arrayIteratorNextHelper` (1)
- `next` (1)

### `hasOwn`
`[native code]` | Self: 0.4% (7.3ms) | Total: 0.4% (7.3ms) | Samples: 3

**Called by:**
- `copyInner` (2)
- `observe` (1)

### `find`
`[native code]` | Self: 0.4% (7.3ms) | Total: 0.6% (10.7ms) | Samples: 1

**Called by:**
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:496` | Self: 0.4% (6.6ms) | Total: 0.4% (6.6ms) | Samples: 1

**Called by:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.4% (6.2ms) | Total: 0.4% (6.2ms) | Samples: 4

**Called by:**
- `flatIntoArrayWithCallback` (2)
- `map` (1)
- `compare` (1)

### `receiptOf`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.4% (6.2ms) | Total: 0.4% (6.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` | Self: 0.3% (6.1ms) | Total: 0.3% (6.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `xmlSlice`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` | Self: 0.3% (6.0ms) | Total: 0.3% (6.0ms) | Samples: 3

**Called by:**
- `verifyDocumentEnvelope` (2)
- `verifyDocumentEnvelope` (1)

### `compareCodePointStrings`
`/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts:3` | Self: 0.3% (5.8ms) | Total: 0.3% (5.8ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `cloneObject`
`[native code]` | Self: 0.3% (5.8ms) | Total: 0.3% (5.8ms) | Samples: 2

**Called by:**
- `freezeFamilyConformanceReport` (1)
- `paintBounds` (1)

### `xmlAsciiLetter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:86` | Self: 0.3% (5.8ms) | Total: 0.3% (5.8ms) | Samples: 4

**Called by:**
- `xmlNameCharacter` (3)
- `readXmlNameEnd` (1)

### `consumeStringBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.3% (5.3ms) | Total: 0.3% (5.3ms) | Samples: 1

**Called by:**
- `write` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:523` | Self: 0.3% (5.3ms) | Total: 0.3% (5.3ms) | Samples: 2

**Called by:**
- `write` (2)

### `has`
`[native code]` | Self: 0.3% (4.9ms) | Total: 0.3% (4.9ms) | Samples: 4

**Called by:**
- `hasOwned` (1)
- `validateAggregateReferences` (1)
- `validateDescriptor` (1)
- `scanStartTags` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:2365` | Self: 0.3% (4.9ms) | Total: 0.3% (4.9ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:30` | Self: 0.3% (4.8ms) | Total: 0.3% (4.8ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `arrayIteratorNextHelper`
`[native code]` | Self: 0.3% (4.7ms) | Total: 0.3% (4.7ms) | Samples: 2

**Called by:**
- `next` (1)
- `Set` (1)

### `writeFileSync`
`[native code]` | Self: 0.3% (4.6ms) | Total: 0.6% (9.3ms) | Samples: 1

**Called by:**
- `writeFileSync` (1)
- `(module)` (1)

**Calls:**
- `writeFileSync` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:240` | Self: 0.2% (4.6ms) | Total: 0.3% (5.7ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (2)

**Calls:**
- `xmlScalarCharacter` (1)

### `WeakSet`
`[native code]` | Self: 0.2% (4.4ms) | Total: 0.2% (4.4ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `sourceIndexOf`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:49` | Self: 0.2% (4.4ms) | Total: 0.2% (4.4ms) | Samples: 4

**Called by:**
- `scanStartTags` (2)
- `scanTagEnd` (1)
- `scanTagEnd` (1)

### `some`
`[native code]` | Self: 0.2% (4.4ms) | Total: 0.7% (11.2ms) | Samples: 3

**Called by:**
- `some` (2)
- `repairErFrameRoutes` (2)
- `finishErGeometry` (1)
- `finish` (1)
- `validateDescriptor` (1)
- `placeRelationshipLabels` (1)
- `crowsFootMark` (1)

**Calls:**
- `some` (2)
- `segmentThroughShape` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `trim`
`[native code]` | Self: 0.2% (4.3ms) | Total: 0.2% (4.3ms) | Samples: 1

**Called by:**
- `validateDescriptor` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:156` | Self: 0.2% (4.2ms) | Total: 0.2% (4.2ms) | Samples: 2

**Called by:**
- `projectSvgCss` (2)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:596` | Self: 0.2% (4.2ms) | Total: 0.2% (4.2ms) | Samples: 2

**Called by:**
- `writeConnectorSvg` (2)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:570` | Self: 0.2% (4.1ms) | Total: 0.2% (4.1ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:161` | Self: 0.2% (4.0ms) | Total: 7.1% (110.5ms) | Samples: 3

**Called by:**
- `copyInner` (44)
- `leaf` (25)
- `copy` (4)
- `snapshot` (1)

**Calls:**
- `copyInner` (44)
- `copyInner` (7)
- `copyInner` (4)
- `copy` (4)
- `materializeText` (4)
- `copyInner` (2)
- `copy` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copyInner` (1)
- `copy` (1)
- `materializeText` (1)

### `finalizeFlatMeasuredMarkers`
`/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` | Self: 0.2% (4.0ms) | Total: 0.2% (4.0ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.2% (3.9ms) | Total: 0.2% (3.9ms) | Samples: 3

**Called by:**
- `positionedPaintCertification` (3)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.2% (3.9ms) | Total: 0.2% (3.9ms) | Samples: 3

**Called by:**
- `validateSceneDocument` (3)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` | Self: 0.2% (3.8ms) | Total: 0.2% (3.8ms) | Samples: 2

**Called by:**
- `o` (1)
- `(anonymous)` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:170` | Self: 0.2% (3.7ms) | Total: 0.7% (11.6ms) | Samples: 3

**Called by:**
- `copyInner` (7)
- `leaf` (1)

**Calls:**
- `defineProperty` (5)

### `readFileSync`
`[native code]` | Self: 0.2% (3.7ms) | Total: 0.4% (7.5ms) | Samples: 2

**Called by:**
- `readFileSync` (2)
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `readFileSync` (2)

### `xmlTokenAt`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:17` | Self: 0.2% (3.7ms) | Total: 0.2% (3.7ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:171` | Self: 0.2% (3.7ms) | Total: 0.2% (3.7ms) | Samples: 2

**Called by:**
- `paintedStrokeExtent` (2)

### `traits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` | Self: 0.2% (3.6ms) | Total: 0.2% (3.6ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `mixedChannels`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:57` | Self: 0.2% (3.6ms) | Total: 0.2% (3.6ms) | Samples: 1

**Called by:**
- `mixHex` (1)

### `typographyAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:694` | Self: 0.2% (3.5ms) | Total: 0.3% (4.8ms) | Samples: 3

**Called by:**
- `writeTextSvg` (4)

**Calls:**
- `attribute` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1532` | Self: 0.2% (3.3ms) | Total: 0.2% (3.3ms) | Samples: 1

**Called by:**
- `nativeCandidate` (1)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:473` | Self: 0.2% (3.3ms) | Total: 0.2% (3.3ms) | Samples: 2

**Called by:**
- `diagramColorVariables` (2)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:395` | Self: 0.2% (3.3ms) | Total: 0.2% (3.3ms) | Samples: 2

**Called by:**
- `inspectOwnedSvgOnce` (1)
- `(anonymous)` (1)

### `test`
`[native code]` | Self: 0.2% (3.3ms) | Total: 0.4% (7.0ms) | Samples: 1

**Called by:**
- `set` (1)
- `inspectSecurityTail` (1)
- `erLabelUnread` (1)
- `(anonymous)` (1)

**Calls:**
- `/^(?:class\|data-[a-z][a-z0-9-]*\|role\|aria-[a-z]+\|tabindex\|pointer-events\|transform\|style)$/` (1)
- `/\sdata-role="[^"]*"/` (1)
- `/<(?:[^\s<>/:]+:)?foreignObject\b/i` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.2% (3.2ms) | Total: 0.2% (3.2ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1289` | Self: 0.2% (3.2ms) | Total: 0.2% (3.2ms) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:109` | Self: 0.2% (3.2ms) | Total: 0.2% (3.2ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.2% (3.1ms) | Total: 0.2% (3.1ms) | Samples: 1

**Called by:**
- `renderEntityBox` (1)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:161` | Self: 0.1% (3.0ms) | Total: 0.1% (3.0ms) | Samples: 2

**Called by:**
- `paintedStrokeExtent` (2)

### `flatIntoArray`
`[native code]` | Self: 0.1% (3.0ms) | Total: 0.1% (3.0ms) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `graphicalSvgArtifact`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` | Self: 0.1% (3.0ms) | Total: 0.1% (3.0ms) | Samples: 1

**Called by:**
- `withSvgInspectionCache` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:317` | Self: 0.1% (3.0ms) | Total: 0.1% (3.0ms) | Samples: 1

**Called by:**
- `connector` (1)

### `nativeParseRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:132` | Self: 0.1% (3.0ms) | Total: 0.1% (3.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `layoutSharedFan`
`/tmp/pr449-main-integration-20261029-762/src/layout/shared-fan-core.ts` | Self: 0.1% (3.0ms) | Total: 0.1% (3.0ms) | Samples: 2

**Called by:**
- `layoutLayeredGraph` (2)

### `fromEntries`
`[native code]` | Self: 0.1% (2.9ms) | Total: 0.1% (2.9ms) | Samples: 1

**Called by:**
- `frozenRoleStyles` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/c4/config.ts` | Self: 0.1% (2.9ms) | Total: 0.1% (2.9ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `every`
`[native code]` | Self: 0.1% (2.9ms) | Total: 0.2% (4.0ms) | Samples: 2

**Called by:**
- `preparePixelText` (1)
- `transformedBounds` (1)
- `finite` (1)

**Calls:**
- `(anonymous)` (1)

### `Segmenter`
`[native code]` | Self: 0.1% (2.7ms) | Total: 0.1% (2.7ms) | Samples: 2

**Called by:**
- `(module)` (2)

### `validateRoleStyleRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:309` | Self: 0.1% (2.7ms) | Total: 0.1% (2.7ms) | Samples: 1

**Called by:**
- `validateRoleStyles` (1)

### `slice`
`[native code]` | Self: 0.1% (2.7ms) | Total: 0.1% (2.7ms) | Samples: 2

**Called by:**
- `scanAccessibilityDirectives` (1)
- `(anonymous)` (1)

### `classMarkerResources`
`/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:21` | Self: 0.1% (2.7ms) | Total: 0.1% (2.7ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:417` | Self: 0.1% (2.7ms) | Total: 0.1% (2.7ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:251` | Self: 0.1% (2.7ms) | Total: 0.1% (2.7ms) | Samples: 1

**Called by:**
- `validatePoint` (1)

### `match`
`[native code]` | Self: 0.1% (2.6ms) | Total: 0.1% (2.6ms) | Samples: 2

**Called by:**
- `attr` (1)
- `resolvedColorValue` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:27` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 2

**Called by:**
- `build` (2)

### `snapshotDescriptorArray`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1498` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 1

**Called by:**
- `snapshotScenePrimitiveCell` (1)

### `exec`
`[native code]` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 2

**Called by:**
- `localPaintResourceId` (1)
- `scopedRule` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:40` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `filter`
`[native code]` | Self: 0.1% (2.5ms) | Total: 0.4% (6.4ms) | Samples: 2

**Called by:**
- `readErStatements` (2)
- `requiredBackendCapabilities` (1)
- `structurallyEqual` (1)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:535` | Self: 0.1% (2.5ms) | Total: 0.1% (2.5ms) | Samples: 1

**Called by:**
- `drawn` (1)

### `transferSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.1% (2.4ms) | Total: 0.1% (2.4ms) | Samples: 2

**Called by:**
- `visit` (1)
- `leaf` (1)

### `declareFamilyScenePrimitiveEvidence`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:253` | Self: 0.1% (2.4ms) | Total: 0.1% (2.4ms) | Samples: 1

**Called by:**
- `completeBuiltinDescriptor` (1)

### `finishXmlLeaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.1% (2.4ms) | Total: 0.1% (2.4ms) | Samples: 2

**Called by:**
- `writeTextSvg` (1)
- `serializeSceneNode` (1)

### `runMeasuredGraphBackend`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts` | Self: 0.1% (2.3ms) | Total: 0.1% (2.3ms) | Samples: 1

**Called by:**
- `layout` (1)

### `factOf`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.1% (2.3ms) | Total: 0.1% (2.3ms) | Samples: 1

**Called by:**
- `read` (1)

### `canonicalExtensionId`
`/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts` | Self: 0.1% (2.3ms) | Total: 0.1% (2.3ms) | Samples: 1

**Called by:**
- `registerBuiltInStyle` (1)

### `includes`
`[native code]` | Self: 0.1% (2.3ms) | Total: 0.1% (2.3ms) | Samples: 2

**Called by:**
- `parseErDiagram` (1)
- `validateNode` (1)

### `xmlSlice`
`/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts:32` | Self: 0.1% (2.3ms) | Total: 0.1% (2.3ms) | Samples: 2

**Called by:**
- `verifyDocumentEnvelope` (2)

### `renderCardinality`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:590` | Self: 0.1% (2.3ms) | Total: 1.3% (21.2ms) | Samples: 2

**Called by:**
- `lowerErDrawing` (15)

**Calls:**
- `group` (5)
- `crowsFootMark` (4)
- `crowsFootMark` (2)
- `group` (1)
- `group` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` | Self: 0.1% (2.3ms) | Total: 0.1% (2.3ms) | Samples: 1

**Called by:**
- `installBuiltinFamily` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:55` | Self: 0.1% (2.2ms) | Total: 0.1% (2.2ms) | Samples: 1

**Called by:**
- `sort` (1)

### `transformedBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:485` | Self: 0.1% (2.2ms) | Total: 0.1% (2.2ms) | Samples: 1

**Called by:**
- `solidInteriors` (1)

### `transferRetainedPixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.1% (2.2ms) | Total: 0.1% (2.2ms) | Samples: 1

**Called by:**
- `materializeText` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts:240` | Self: 0.1% (2.2ms) | Total: 0.1% (2.2ms) | Samples: 1

### `name`
`/tmp/pr449-main-integration-20261029-762/src/er/creation.ts` | Self: 0.1% (2.2ms) | Total: 0.1% (2.2ms) | Samples: 1

**Called by:**
- `relationEnd` (1)

### `resolveSceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` | Self: 0.1% (2.2ms) | Total: 0.1% (2.2ms) | Samples: 1

**Called by:**
- `sceneRoleTraits` (1)

### `RegExp`
`[native code]` | Self: 0.1% (2.2ms) | Total: 0.1% (2.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `connectorUnitTangent`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` | Self: 0.1% (2.2ms) | Total: 0.1% (2.2ms) | Samples: 2

**Called by:**
- `connectorContourSemantics` (2)

### `copyDataProperties`
`[native code]` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 2

**Called by:**
- `text` (1)
- `text` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:672` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:66` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 1

**Called by:**
- `collides` (1)

### `admitWritableSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:501` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 2

**Called by:**
- `text` (1)
- `shape` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:231` | Self: 0.1% (2.1ms) | Total: 0.3% (5.5ms) | Samples: 1

**Called by:**
- `markerTerminalDepth` (3)

**Calls:**
- `pointsBounds` (1)
- `pathBounds` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 2

**Called by:**
- `nativeCandidate` (2)

### `pointsBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:13` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 1

**Called by:**
- `markerBoundsAt` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 1

**Called by:**
- `markerTerminalDepth` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:520` | Self: 0.1% (2.1ms) | Total: 0.1% (2.1ms) | Samples: 1

**Called by:**
- `text` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:220` | Self: 0.1% (2.0ms) | Total: 0.1% (2.0ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `validSceneRoleDeclaration`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1603` | Self: 0.1% (2.0ms) | Total: 0.1% (2.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-named-colors.ts:3` | Self: 0.1% (2.0ms) | Total: 0.1% (2.0ms) | Samples: 1

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.1% (2.0ms) | Total: 0.1% (2.0ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `buildInkTree`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` | Self: 0.1% (2.0ms) | Total: 0.1% (2.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `tag`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:152` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `bisector`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `retainOrder`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:77` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `retainOrder` (1)

### `erRelationshipStyle`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:15` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:509` | Self: 0.1% (1.9ms) | Total: 0.6% (10.1ms) | Samples: 1

**Called by:**
- `paintBounds` (4)
- `solidInteriors` (1)
- `markerBoundsAt` (1)

**Calls:**
- `tryParseCssColor` (2)
- `tryParseCssColor` (2)
- `tryParseCssColor` (1)

### `validateRoleStyles`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `validateStyleSpec` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:581` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `finish` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:646` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `invalidateFractionalCircle`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `observe` (1)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:93` | Self: 0.1% (1.9ms) | Total: 0.1% (1.9ms) | Samples: 1

**Called by:**
- `materializeText` (1)

### `isWhitespace`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `circleMarkerResources`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `flowchartMarkerResources` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:229` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:96` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 2

**Called by:**
- `materializeText` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1161` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `indent`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:226` | Self: 0.1% (1.8ms) | Total: 0.1% (3.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `factOf` (1)

### `normalizePlainLabel`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:47` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `normalizeBrTags` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:212` | Self: 0.1% (1.8ms) | Total: 0.1% (1.8ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `join`
`[native code]` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `normalizeSource` (1)

### `advance`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:199` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `charge`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:83` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `retainOrder`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:75` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `retainOrder` (1)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:703` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `node` (1)

### `min`
`[native code]` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `rectOverlap` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts:32` | Self: 0.1% (1.7ms) | Total: 0.1% (1.7ms) | Samples: 1

**Called by:**
- `map` (1)

### `numericLike`
`/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `canonicalJson`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1100` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `map` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `withTextMeasurementExecution` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:167` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `projectSvgCss` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `filter` (1)

### `erRelationshipStyle`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `nativePlacement` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:603` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.1% (1.6ms) | Total: 0.1% (1.6ms) | Samples: 1

**Called by:**
- `visit` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:426` | Self: 0.1% (1.6ms) | Total: 0.4% (6.7ms) | Samples: 1

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `xmlSlice` (2)
- `xmlSlice` (2)

### `connectorContourSemantics`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:381` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `connector` (1)

### `hint`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `observe` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:168` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `deepFreeze`
`/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts:16` | Self: 0.1% (1.5ms) | Total: 1.3% (20.3ms) | Samples: 1

**Called by:**
- `deepFreeze` (12)
- `(module)` (1)

**Calls:**
- `deepFreeze` (12)

### `crowsFootMark`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:618` | Self: 0.1% (1.5ms) | Total: 0.1% (1.5ms) | Samples: 1

**Called by:**
- `renderCardinality` (1)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `finalizeErRelationshipLabels` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:173` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `map` (1)

### `stripMermaidDirectives`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `mermaidFirstLine` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:593` | Self: 0.0% (1.4ms) | Total: 0.1% (2.9ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `paintedStrokeExtent` (1)

### `qualify`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:27` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `prepareDisplayText` (1)

### `layoutMeasuredForest`
`/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `layoutLayeredGraph` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:763` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `write` (1)

### `create`
`[native code]` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `issue` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:532` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `validateNodeSerialization` (1)

### `connector/subpaths/render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `map` (1)

### `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/`
`[native code]` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `paintedStrokeExtent` (1)

### `sceneAssertionsEnabled`
`/tmp/pr449-main-integration-20261029-762/src/scene/assertions.ts:28` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `retainedNativeDrawing` (1)

### `floor`
`[native code]` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `build` (1)

### `assertRenderableLinearGradient`
`/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `serializeLinearGradientResource` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `visitSvgFirstTagAttributes` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `erTextLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/text.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `relationshipFrom` (1)

### `element`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:301` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `element` (1)

### `validateChannels`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:580` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:100` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `shape` (1)

### `attachSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:495` | Self: 0.0% (1.4ms) | Total: 0.4% (7.3ms) | Samples: 1

**Called by:**
- `createFixture` (1)
- `documentClose` (1)

**Calls:**
- `canonicalizeSceneNodeSerialization` (1)

### `consume`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `importModule`
`[native code]` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `map` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `observe` (1)

### `performIteration`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `createNativePaintEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `report` (1)

### `assertFamilyGeometryOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:858` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `applyFamilyRequestNormalization` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:611` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `map` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:114` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `shape` (1)

### `inspectPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:682` | Self: 0.0% (1.3ms) | Total: 0.5% (8.8ms) | Samples: 1

**Called by:**
- `serializeSceneNode` (4)

**Calls:**
- `paintAttributes` (3)

### `advance`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `localPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1385` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `typographyAttributes` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:509` | Self: 0.0% (1.3ms) | Total: 0.4% (7.6ms) | Samples: 1

**Called by:**
- `group` (5)

**Calls:**
- `nativeGroup` (2)
- `result` (1)
- `result` (1)

### `normalizeMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:667` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `startTags`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:65` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `inspectSecurity` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:181` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `map` (1)

### `detectsArchitectureFamily`
`/tmp/pr449-main-integration-20261029-762/src/shared/builtin-family-detection.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `/<(?:[^\s<>/:]+:)?foreignObject\b/i`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `test` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:144` | Self: 0.0% (1.3ms) | Total: 0.2% (3.2ms) | Samples: 1

**Called by:**
- `visitSvgFirstTagAttributes` (1)
- `projectSvgCss` (1)

**Calls:**
- `isWhitespace` (1)

### `preparedInterTextBounds`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:123` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `paintBounds` (1)

### `hitsTransformed`
`/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts:48` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector/interaction/hit-test` (1)

### `paintAttribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:493` | Self: 0.0% (1.3ms) | Total: 0.4% (7.4ms) | Samples: 1

**Called by:**
- `paintAttributes` (3)

**Calls:**
- `attribute` (2)

### `parseInt`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `tryParseCssColor` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:335` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `connector` (1)

### `sanitizeDisplayLines`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `styledRunLayout`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `preparePixelText` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:218` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `ArrayBuffer`
`[native code]` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `node:zlib` (1)

### `safeCssPaint`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `validatePaint` (1)

### `terminalDepth`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1251` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `finishErGeometry` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:224` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `map` (1)

### `serializeLinearGradientResources`
`/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:69` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `createFixture` (1)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:33` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `overlaps`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `visit` (1)

### `isCapabilityId`
`/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `negotiateCapabilities` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:526` | Self: 0.0% (1.2ms) | Total: 0.1% (2.5ms) | Samples: 1

**Called by:**
- `text` (2)

**Calls:**
- `copyDataProperties` (1)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:35` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `set`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `solidInteriors` (1)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `markerBoundsAt` (1)

### `result`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:406` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `readXmlNameEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `renderRelationshipLabel` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:407` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `withDeferredTerminalProjections`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `drawNative` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `admitSceneDocumentWith` (1)

### `/^(?:class\|data-[a-z][a-z0-9-]*\|role\|aria-[a-z]+\|tabindex\|pointer-events\|transform\|style)$/`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `test` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:765` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `write` (1)

### `checkAllClassLikeAuthoredStyles`
`/tmp/pr449-main-integration-20261029-762/src/shared/style-props.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `layout` (1)

### `validate`
`/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateSerializableRenderOptions` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:153` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `projectSvgCss` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:591` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `resolvedColorValue` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `measureErEntities` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `some` (1)

### `nonPainting`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:129` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `erDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/er/text.ts:94` | Self: 0.0% (1.2ms) | Total: 0.1% (3.0ms) | Samples: 1

**Called by:**
- `erTextLabel` (2)

**Calls:**
- `normalizedErText` (1)

### `include`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `forEach` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1066` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `write` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `certifyNativePaint` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `primitiveCapabilityClaimKey`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validatePrimitiveCapabilities` (1)

### `ownsParts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `group` (1)

### `omitUndefinedObjectFields`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:978` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `boundedImmutableJsonSnapshot` (1)

### `segmentThroughShape`
`/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts:175` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `finishErGeometry` (1)

### `consumePointBudget`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validatePoint` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `scopeSvgStyles` (1)

### `scenePrimitiveMatrix`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `outlineKey` (1)

### `setName`
`node:fs:696` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `node:fs` (1)

### `validateMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `makeSafe`
`internal:primordials` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `internal:primordials` (1)

### `lineStrokeBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:538` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `strokedBox` (1)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:94` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `materializeText` (1)

### `numericCss`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `replace`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.3% (4.8ms) | Samples: 1

**Called by:**
- `formatSvgNumericAttribute` (1)
- `resolveCss` (1)

**Calls:**
- `mixHex` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:247` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `py`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:139` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `pathBounds` (1)

### `isServerConfig`
`bun:main` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `factOf`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:97` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `indent` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:219` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `connectorEndpointMarkerAnchors`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `deriveConnectorTerminalProjection` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:106` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `possibleShapeStroke`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:133` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:90` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `ensureSvgIdentity` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:532` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `visit` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `createFixture` (1)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:341` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:22` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:174` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `checkInertGroup` (1)

### `isRetainedPixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:86` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `resolvedFamilyRenderContextOf`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `positionFamily` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `/\sdata-role="[^"]*"/`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `test` (1)

### `xmlScalarCharacter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:88` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `readXmlDataEnd` (1)

### `renderCardinality`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:205` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `group` (1)

### `hypot`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `lineStrokeBox` (1)

### `hooks`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:511` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `writeConnectorSvg` (1)

### `segmentThroughShape`
`/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `some` (1)

### `pointsBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:16` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `geometryBounds` (1)

### `ownFragment`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:116` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `lowerErDrawing` (1)

### `hasInheritedTextPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `observe` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `get`
`/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts:12` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `resolveColors` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `finish` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `drawn` (1)

### `safeCssToken`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:69` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateStyleSpec` (1)

### `get`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:30` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `scopeSvgStyles` (1)

### `Transform`
`internal:streams/transform` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `ZlibBase` (1)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:62` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `validateMarker`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `validateNode` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1930` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `positionedPaintCertification` (1)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:64` | Self: 0.0% (1.1ms) | Total: 0.1% (2.3ms) | Samples: 1

**Called by:**
- `scanStartTags` (2)

**Calls:**
- `sourceIndexOf` (1)

### `admitRenderOptionsInput`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `resolveRenderRequestForExecution` (1)

### `pay`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `attribute` (1)

### `add`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `sanitizeTextControls`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:9` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `map` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:248` | Self: 0.0% (1.1ms) | Total: 0.1% (2.3ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `nonPainting` (1)

### `readErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `parseErDiagram` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1129` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `write` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:254` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `writeTextSvg` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:298` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `some` (1)

### `canonicalTextDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1172` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `parseEncodeTrie`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `normalizeMermaidRuntimeConfig`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `normalizeSource` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1529` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `map` (1)

### `installedFamilyStatementEnds`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `normalizeSource` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:116` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:431` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `every` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1397` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `some` (1)

### `readXmlDataEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `verifyDocumentEnvelope` (1)

### `erCharge`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:204` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `canonicalErContacts` (1)

### `flatIntoArrayWithCallback`
`[native code]` | Self: 0.0% (1.0ms) | Total: 1.2% (19.6ms) | Samples: 1

**Called by:**
- `nativePlacement` (2)
- `nativePlacement` (1)
- `finishErGeometry` (1)
- `snapshot` (1)
- `extractErLayout` (1)
- `placeRelationshipLabels` (1)
- `finishErGeometry` (1)
- `layoutLayeredGraph` (1)
- `placeRelationshipLabels` (1)

**Calls:**
- `(anonymous)` (2)
- `map` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `flatIntoArray` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:159` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `scanStartTags` (1)

### `getStreamOptions`
`internal:fs/streams` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `WriteStream` (1)

### `boundedUtf8ByteLength`
`/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts:7` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `write` (1)

### `result`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `group` (1)

### `createEmissionContext`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `createNativePaintEmission` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:130` | Self: 0.0% (1.0ms) | Total: 0.5% (8.5ms) | Samples: 1

**Called by:**
- `copyInner` (4)
- `snapshot` (1)

**Calls:**
- `getOwnPropertyDescriptor` (4)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:440` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `group` (1)

### `deferredTerminalProjectionInput`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `copyInner` (1)

### `lineStrokeBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `strokedBox` (1)

### `geometryAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `writeShapeSvg` (1)

### `rectangleInput`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:342` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `ensureSvgIdentity` (1)

### `scopeHash`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:31` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `scopeSvgStyles` (1)

### `snapshotBackendCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `freezeBuiltInBackend` (1)

### `assertMarkAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:54` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `connector` (1)

### `readErStatement`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `readErOuterStatements` (1)

### `registerBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `sameRectanglePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:367` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `leaf` (1)

### `finite`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:98` | Self: 0.0% (1.0ms) | Total: 0.1% (2.2ms) | Samples: 1

**Called by:**
- `leaf` (2)

**Calls:**
- `every` (1)

### `walk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1756` | Self: 0.0% (998us) | Total: 0.0% (998us) | Samples: 1

**Called by:**
- `walk` (1)

### `resolveDiagramColors`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` | Self: 0.0% (994us) | Total: 0.0% (994us) | Samples: 1

**Called by:**
- `resolveAppearance` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:894` | Self: 0.0% (991us) | Total: 0.0% (991us) | Samples: 1

**Called by:**
- `write` (1)

### `collectPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1376` | Self: 0.0% (983us) | Total: 0.1% (2.2ms) | Samples: 1

**Called by:**
- `localPaintResourceReferences` (2)

**Calls:**
- `localPaintResourceId` (1)

### `writeSync`
`[native code]` | Self: 0.0% (979us) | Total: 0.0% (979us) | Samples: 1

**Called by:**
- `processChunkSync` (1)

### `scopeCssSelector`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` | Self: 0.0% (978us) | Total: 0.0% (978us) | Samples: 1

**Called by:**
- `map` (1)

### `applyReplacements`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` | Self: 0.0% (976us) | Total: 0.0% (976us) | Samples: 1

**Called by:**
- `resolveSvgColors` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/er/creation.ts` | Self: 0.0% (974us) | Total: 0.0% (974us) | Samples: 1

**Called by:**
- `readErStatements` (1)

### `consume`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:17` | Self: 0.0% (967us) | Total: 0.0% (967us) | Samples: 1

**Called by:**
- `(module)` (1)

### `safeCssToken`
`/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts:87` | Self: 0.0% (961us) | Total: 0.0% (961us) | Samples: 1

**Called by:**
- `cssPaintDefinitions` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:121` | Self: 0.0% (947us) | Total: 0.0% (947us) | Samples: 1

**Called by:**
- `inspectOwnedSvgOnce` (1)

### `endpointRelation`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1629` | Self: 0.0% (946us) | Total: 0.0% (946us) | Samples: 1

**Called by:**
- `walk` (1)

### `prepareWrittenCompoundShape`
`/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts` | Self: 0.0% (943us) | Total: 0.0% (943us) | Samples: 1

**Called by:**
- `leaf` (1)

### `validatePoints`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:465` | Self: 0.0% (938us) | Total: 0.0% (938us) | Samples: 1

**Called by:**
- `validateGeometry` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:464` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `createFixture` (2)

**Calls:**
- `setConnectorTerminalProjection` (2)

### `snapshot`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:277` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `group` (2)

**Calls:**
- `copyInner` (1)
- `copyInner` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:242` | Self: 0.0% (0us) | Total: 2.0% (31.3ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (18)

**Calls:**
- `leaf` (13)
- `text` (4)
- `text` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:214` | Self: 0.0% (0us) | Total: 0.4% (6.2ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (5)

**Calls:**
- `connector` (2)
- `connector` (1)
- `connector` (1)
- `connector` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:644` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `rectangleInput` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1056` | Self: 0.0% (0us) | Total: 0.0% (938us) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `validateGeometry` (1)

### `readErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:800` | Self: 0.0% (0us) | Total: 0.0% (974us) | Samples: 0

**Called by:**
- `parseErDiagram` (1)

**Calls:**
- `finish` (1)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:495` | Self: 0.0% (0us) | Total: 0.0% (936us) | Samples: 0

**Called by:**
- `text` (1)

**Calls:**
- `copyDataProperties` (1)

### `relationEnd`
`/tmp/pr449-main-integration-20261029-762/src/er/creation.ts:99` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `name` (1)

### `readXmlNameEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:104` | Self: 0.0% (0us) | Total: 0.2% (4.1ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (3)

**Calls:**
- `xmlNameCharacter` (3)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:171` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `visitSvgFirstTagAttributes` (1)

**Calls:**
- `(anonymous)` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:676` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `element` (1)

### `internal:stream`
`internal:stream:2` | Self: 0.0% (0us) | Total: 2.0% (31.2ms) | Samples: 0

**Called by:**
- `anonymous` (13)

**Calls:**
- `anonymous` (13)

### `transformSvgCssValues`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:308` | Self: 0.0% (0us) | Total: 0.3% (4.6ms) | Samples: 0

**Called by:**
- `resolveSvgColors` (2)

**Calls:**
- `map` (2)

### `value`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:124` | Self: 0.0% (0us) | Total: 0.2% (3.9ms) | Samples: 0

**Called by:**
- `nativeGroup` (2)

**Calls:**
- `attributeRecord` (2)

### `canonicalJson`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1097` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `canonicalJson` (1)
- `(anonymous)` (1)

**Calls:**
- `canonicalJson` (1)
- `canonicalJson` (1)

### `nativePlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1154` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `flatIntoArrayWithCallback` (2)

### `tryParseCssColor`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:175` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `paintedStrokeExtent` (1)

**Calls:**
- `parseInt` (1)

### `parts`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:442` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `freeze` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:651` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `performIteration` (1)

### `relationAccessibility`
`/tmp/pr449-main-integration-20261029-762/src/scene/accessibility.ts:24` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `shape` (1)

**Calls:**
- `sceneRoleTraits` (1)

### `internal:streams/readable`
`internal:streams/readable:703` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `defineProperties` (1)

### `sanitizeDisplayLines`
`/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts:23` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `escapeDisplayAttr` (1)

**Calls:**
- `map` (1)

### `compare`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:33` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `chargeInkSort` (1)

**Calls:**
- `(anonymous)` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:570` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `createSketchBackend` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:201` | Self: 0.0% (0us) | Total: 0.7% (11.0ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (3)

**Calls:**
- `stringify` (3)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:95` | Self: 0.0% (0us) | Total: 0.8% (12.5ms) | Samples: 0

**Called by:**
- `materializeText` (6)
- `copyInner` (4)

**Calls:**
- `materializeText` (6)
- `materializeText` (2)
- `materializeText` (1)
- `materializeText` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:311` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `extractErLayout` (2)

**Calls:**
- `some` (2)

### `nativePlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1139` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `erCardinalityEnvelope` (3)

### `readErOuterStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:514` | Self: 0.0% (0us) | Total: 0.2% (4.3ms) | Samples: 0

**Called by:**
- `findErStatements` (2)

**Calls:**
- `readErStatement` (1)
- `readErStatement` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:85` | Self: 0.0% (0us) | Total: 1.5% (23.2ms) | Samples: 0

**Called by:**
- `inspectPaint` (13)

**Calls:**
- `visit` (8)
- `visit` (5)

### `text`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:126` | Self: 0.0% (0us) | Total: 0.4% (6.6ms) | Samples: 0

**Called by:**
- `renderEntityBox` (4)
- `renderEntityBox` (1)

**Calls:**
- `text` (2)
- `text` (1)
- `admitWritableSceneNode` (1)
- `text` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:145` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)
- `renderCardinality` (1)

**Calls:**
- `parts` (1)
- `parts` (1)

### `canonicalJson`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1091` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `canonicalJson` (1)

**Calls:**
- `map` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1507` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `validateAggregateReferences` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1764` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (2)

**Calls:**
- `walk` (2)

### `nativePlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1163` | Self: 0.0% (0us) | Total: 2.0% (31.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (15)

**Calls:**
- `measureRenderStage` (15)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1480` | Self: 0.0% (0us) | Total: 0.3% (5.3ms) | Samples: 0

**Called by:**
- `serialize` (1)

**Calls:**
- `consumeStringBudget` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:115` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:640` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `transferSceneNodeSerialization` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:729` | Self: 0.0% (0us) | Total: 0.3% (5.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (3)

**Calls:**
- `renderMultilineText` (1)
- `renderMultilineText` (1)
- `renderMultilineText` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:4` | Self: 0.0% (0us) | Total: 0.7% (11.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:5` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `(anonymous)` (1)

### `renderPreparedLine`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:178` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `renderMultilineText` (1)

**Calls:**
- `map` (1)

### `opaque`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:143` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `opaqueOutlineWidth` (1)

**Calls:**
- `(anonymous)` (1)

### `internal:streams/compose`
`internal:streams/compose:2` | Self: 0.0% (0us) | Total: 1.6% (25.2ms) | Samples: 0

**Called by:**
- `anonymous` (11)

**Calls:**
- `anonymous` (11)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:560` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:198` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (1)

**Calls:**
- `some` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:273` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `extractErLayout` (1)

**Calls:**
- `canonicalErContacts` (1)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:132` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:646` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `pathBounds` (1)
- `pathBounds` (1)

### `paintAttributes`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:519` | Self: 0.0% (0us) | Total: 0.4% (7.4ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (3)

**Calls:**
- `paintAttribute` (3)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1561` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `(anonymous)` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:185` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:13` | Self: 0.0% (0us) | Total: 1.1% (18.2ms) | Samples: 0

**Calls:**
- `bound require` (3)

### `canonicalizeSceneNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:485` | Self: 0.0% (0us) | Total: 0.3% (5.8ms) | Samples: 0

**Called by:**
- `attachSceneNodeSerialization` (1)

**Calls:**
- `canonicalOpeningTag` (1)

### `node:zlib`
`node:zlib:449` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `map` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:247` | Self: 0.0% (0us) | Total: 2.3% (37.0ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (23)

**Calls:**
- `inspectPaint` (22)
- `inspectPaint` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:111` | Self: 0.0% (0us) | Total: 3.4% (53.0ms) | Samples: 0

**Called by:**
- `measureRenderStage` (33)

**Calls:**
- `report` (33)

### `resolveRoleStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:251` | Self: 0.0% (0us) | Total: 0.3% (5.4ms) | Samples: 0

**Called by:**
- `renderRelationshipLabel` (1)
- `erFrameInkPadding` (1)
- `finishErGeometry` (1)

**Calls:**
- `Set` (3)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:106` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:5` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1882` | Self: 0.0% (0us) | Total: 0.2% (3.5ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `freezeFamilyConformanceReport` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:304` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `attribute` (1)

**Calls:**
- `pay` (1)

### `node:zlib`
`node:zlib:2` | Self: 0.0% (0us) | Total: 2.1% (32.7ms) | Samples: 0

**Calls:**
- `anonymous` (14)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:178` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (2)

**Calls:**
- `svgStyleRanges` (2)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1728` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Called by:**
- `measureRenderStage` (3)

**Calls:**
- `validateSerializableRenderOptions` (1)
- `validateSerializableRenderOptions` (1)
- `validateSerializableRenderOptions` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:221` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `visit` (1)
- `admitSceneDocumentWith` (1)

**Calls:**
- `visit` (1)
- `visit` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:191` | Self: 0.0% (0us) | Total: 0.1% (2.9ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `serializeLinearGradientResource` (1)
- `serializeLinearGradientResource` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:142` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `projectErPositioned` (1)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:434` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `consumePointBudget` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1782` | Self: 0.0% (0us) | Total: 0.2% (4.0ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (3)

**Calls:**
- `visit` (2)
- `visit` (1)

### `ensureSvgIdentity`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:92` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `group` (3)

**Calls:**
- `set` (1)
- `set` (1)
- `set` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1854` | Self: 0.0% (0us) | Total: 0.4% (7.3ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `find` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1709` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `admitRenderOptionsInput` (1)

### `connectorContourSemantics`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts:387` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `connector` (2)

**Calls:**
- `connectorUnitTangent` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:111` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (1)

**Calls:**
- `erCardinalityInk` (1)

### `collides`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:173` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `placeRelationshipLabels` (1)

**Calls:**
- `(anonymous)` (1)

### `executeInspectedGraphicalRequest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:297` | Self: 0.0% (0us) | Total: 1.1% (17.8ms) | Samples: 0

**Called by:**
- `withSvgInspectionCache` (14)

**Calls:**
- `measureRenderStage` (14)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1558` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `terminalDepth` (1)

### `layoutErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1128` | Self: 0.0% (0us) | Total: 0.5% (8.5ms) | Samples: 0

**Called by:**
- `layout` (6)

**Calls:**
- `measureErEntities` (5)
- `measureErEntities` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:817` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `validatePaint` (1)

### `erTextLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/text.ts:107` | Self: 0.0% (0us) | Total: 0.1% (3.0ms) | Samples: 0

**Called by:**
- `relationshipFrom` (2)

**Calls:**
- `erDisplayText` (2)

### `scopeCss`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:118` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `scopeSvgStyles` (2)

**Calls:**
- `scopedRule` (1)
- `scopedRule` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:252` | Self: 0.0% (0us) | Total: 2.4% (38.6ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (22)

**Calls:**
- `measureRenderStage` (22)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:800` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `validateMarkAttributes` (1)

### `pointsBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:15` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `markerTerminalDepth` (1)

**Calls:**
- `map` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1031` | Self: 0.0% (0us) | Total: 0.9% (14.3ms) | Samples: 0

**Called by:**
- `report` (11)

**Calls:**
- `rendered` (11)

### `freezeBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:403` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `registerBuiltInBackend` (1)

**Calls:**
- `snapshotBackendCapabilities` (1)

### `render`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:394` | Self: 0.0% (0us) | Total: 0.9% (14.3ms) | Samples: 0

**Called by:**
- `rendered` (11)

**Calls:**
- `admitSceneDocumentWith` (9)
- `admitSceneDocumentWith` (2)

### `resolveColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:474` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `diagramColorVariables` (1)

**Calls:**
- `get` (1)

### `createSketchBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/rough-backend.ts:547` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `graphicalBackendCapabilityClaims` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:71` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `finishErGeometry` (1)

**Calls:**
- `visit` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:829` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `connectorInlineLabelSvg` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1879` | Self: 0.0% (0us) | Total: 1.6% (25.4ms) | Samples: 0

**Called by:**
- `(module)` (9)

**Calls:**
- `validateDescriptor` (2)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)
- `validateDescriptor` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:633` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `registerGroupEmission` (1)

### `normalizeBrTags`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:25` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `normalizedErText` (1)

**Calls:**
- `normalizePlainLabel` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:31` | Self: 0.0% (0us) | Total: 38.5% (596.3ms) | Samples: 0

**Calls:**
- `withPerformanceObserver` (372)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:587` | Self: 0.0% (0us) | Total: 0.4% (6.4ms) | Samples: 0

**Called by:**
- `group` (4)
- `createFixture` (1)

**Calls:**
- `checkInertGroup` (4)
- `checkInertGroup` (1)

### `registerBuiltInStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:294` | Self: 0.0% (0us) | Total: 0.1% (2.9ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `registerCanonicalStyle` (1)

### `tree`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:71` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (2)

**Calls:**
- `build` (2)

### `pathBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:143` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `py` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:681` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:208` | Self: 0.0% (0us) | Total: 1.2% (19.8ms) | Samples: 0

**Called by:**
- `visit` (8)
- `visit` (6)

**Calls:**
- `leaf` (9)
- `leaf` (2)
- `leaf` (2)
- `leaf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:69` | Self: 0.0% (0us) | Total: 0.2% (4.4ms) | Samples: 0

**Called by:**
- `finishErGeometry` (2)
- `finishErGeometry` (1)

**Calls:**
- `build` (2)
- `buildInkTree` (1)

### `element`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:477` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `writeShapeSvg` (1)

**Calls:**
- `element` (1)

### `WriteStream`
`internal:fs/streams:201` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `getStreamOptions` (1)

### `nativePlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1137` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `erRelationshipStyle` (1)

### `finalizeErRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:28` | Self: 0.0% (0us) | Total: 0.5% (8.4ms) | Samples: 0

**Called by:**
- `finishErGeometry` (5)

**Calls:**
- `placeRelationshipLabels` (1)
- `placeRelationshipLabels` (1)
- `placeRelationshipLabels` (1)
- `placeRelationshipLabels` (1)
- `placeRelationshipLabels` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:171` | Self: 0.0% (0us) | Total: 0.4% (7.6ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (2)
- `renderCardinality` (2)
- `renderCardinality` (1)

**Calls:**
- `group` (5)

### `nativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:397` | Self: 0.0% (0us) | Total: 0.2% (3.9ms) | Samples: 0

**Called by:**
- `group` (2)

**Calls:**
- `value` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:8` | Self: 0.0% (0us) | Total: 0.5% (9.1ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `bound require` (4)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1322` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `snapshot` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:219` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `finish` (1)

### `nativeCandidate`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1115` | Self: 0.0% (0us) | Total: 6.0% (93.0ms) | Samples: 0

**Called by:**
- `runMeasuredGraphBackend` (54)

**Calls:**
- `(anonymous)` (23)
- `finish` (11)
- `finishErGeometry` (5)
- `finishErGeometry` (2)
- `finishErGeometry` (2)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)
- `finishErGeometry` (1)

### `serializeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:575` | Self: 0.0% (0us) | Total: 2.4% (38.3ms) | Samples: 0

**Called by:**
- `write` (20)
- `drawn` (2)
- `(anonymous)` (1)
- `validateNodeSerialization` (1)

**Calls:**
- `writeShapeSvg` (4)
- `writeTextSvg` (4)
- `writeTextSvg` (3)
- `writeConnectorSvg` (2)
- `writeShapeSvg` (1)
- `writeConnectorSvg` (1)
- `writeTextSvg` (1)
- `writeSceneNode` (1)
- `writeShapeSvg` (1)
- `writeTextSvg` (1)
- `writeTextSvg` (1)
- `finishXmlLeaf` (1)
- `writeConnectorSvg` (1)
- `writeConnectorSvg` (1)
- `issue` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:127` | Self: 0.0% (0us) | Total: 0.5% (8.0ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (5)

**Calls:**
- `connector` (2)
- `connector` (1)
- `connector` (1)
- `connector` (1)

### `issue`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:92` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `create` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:184` | Self: 0.0% (0us) | Total: 1.1% (17.6ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (9)
- `renderCardinality` (1)

**Calls:**
- `join` (9)
- `join` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:803` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `hooks` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:810` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:3` | Self: 0.0% (0us) | Total: 0.2% (3.5ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:172` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `visit` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1267` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `validateConnectorProjectionConsistency` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:80` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `leaf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/directives.js:3` | Self: 0.0% (0us) | Total: 0.9% (13.9ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1737` | Self: 0.0% (0us) | Total: 0.4% (6.8ms) | Samples: 0

**Called by:**
- `measureRenderStage` (5)

**Calls:**
- `normalizeMermaidSourceWithOverrides` (5)

### `validateGeometry`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:524` | Self: 0.0% (0us) | Total: 0.0% (938us) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `validatePoints` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:60` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `overlaps` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:88` | Self: 0.0% (0us) | Total: 0.7% (11.1ms) | Samples: 0

**Called by:**
- `visit` (5)

**Calls:**
- `observe` (1)
- `observe` (1)
- `observe` (1)
- `observe` (1)
- `observe` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:8` | Self: 0.0% (0us) | Total: 1.4% (23.0ms) | Samples: 0

**Called by:**
- `anonymous` (5)

**Calls:**
- `bound require` (5)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:78` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `bisector` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:12` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `readFileSync` (1)

### `outlineKey`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:154` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `solidInteriors` (1)

**Calls:**
- `scenePrimitiveMatrix` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:736` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `finishXmlLeaf` (1)

### `sort`
`[native code]` | Self: 0.0% (0us) | Total: 0.5% (8.1ms) | Samples: 0

**Called by:**
- `(module)` (1)
- `canonicalOpeningTag` (1)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `mermaidFirstLine`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts:149` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `normalizeMermaidSource` (1)

**Calls:**
- `stripMermaidDirectives` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:237` | Self: 0.0% (0us) | Total: 0.3% (4.8ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (4)

**Calls:**
- `toneOnFill` (3)
- `toneOnFill` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:164` | Self: 0.0% (0us) | Total: 0.2% (3.9ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (3)

**Calls:**
- `outlineKey` (1)
- `stringify` (1)
- `set` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1722` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (2)

**Calls:**
- `some` (1)
- `Set` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js:3` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `inspectSecurity`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:673` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `startTags` (1)

### `serializeLinearGradientResource`
`/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts:91` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `map` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:128` | Self: 0.0% (0us) | Total: 7.7% (119.7ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (78)

**Calls:**
- `renderEntityBox` (18)
- `renderEntityBox` (16)
- `group` (9)
- `renderEntityBox` (8)
- `group` (6)
- `renderEntityBox` (5)
- `renderEntityBox` (4)
- `group` (3)
- `group` (2)
- `renderEntityBox` (1)
- `group` (1)
- `group` (1)
- `group` (1)
- `renderEntityBox` (1)
- `ownFragment` (1)
- `renderEntityBox` (1)

### `readErStatement`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:298` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `readErOuterStatements` (1)

**Calls:**
- `parseErRelationshipSyntax` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts:55` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Calls:**
- `sort` (1)

### `renderCardinality`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:589` | Self: 0.0% (0us) | Total: 1.2% (19.4ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (13)

**Calls:**
- `crowsFootMark` (3)
- `group` (3)
- `group` (2)
- `group` (2)
- `group` (1)
- `crowsFootMark` (1)
- `group` (1)

### `internal:errors`
`internal:errors:2` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:596` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `hasInheritedTextPaint` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/architecture/markers.ts:16` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:199` | Self: 0.0% (0us) | Total: 0.1% (3.0ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `group` (1)
- `group` (1)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:176` | Self: 0.0% (0us) | Total: 0.0% (947us) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (1)

**Calls:**
- `svgRootStartTag` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:589` | Self: 0.0% (0us) | Total: 0.3% (4.9ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `hasOwn` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:181` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `map` (1)

### `xmlNameCharacter`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:87` | Self: 0.0% (0us) | Total: 0.2% (4.1ms) | Samples: 0

**Called by:**
- `readXmlNameEnd` (3)

**Calls:**
- `xmlAsciiLetter` (3)

### `internal:streams/readable`
`internal:streams/readable:2` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `withDeferredTerminalProjections`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:16` | Self: 0.0% (0us) | Total: 14.1% (219.1ms) | Samples: 0

**Called by:**
- `drawNative` (145)

**Calls:**
- `lowerErDrawing` (78)
- `lowerErDrawing` (29)
- `lowerErDrawing` (26)
- `lowerErDrawing` (8)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)
- `lowerErDrawing` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1386` | Self: 0.0% (0us) | Total: 0.2% (3.4ms) | Samples: 0

**Called by:**
- `nativeCandidate` (2)

**Calls:**
- `(anonymous)` (2)

### `assessFamilyLayout`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:266` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `assessRenderedLayoutHardViolations` (1)

**Calls:**
- `rectOverlap` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:701` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `assignPorts` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:761` | Self: 0.0% (0us) | Total: 0.2% (3.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `resolveCss` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1008` | Self: 0.0% (0us) | Total: 0.3% (5.4ms) | Samples: 0

**Called by:**
- `report` (3)

**Calls:**
- `drawn` (3)

### `node:fs`
`node:fs:739` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `setName` (1)

### `admitSceneDocumentWith`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:268` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `render` (2)

**Calls:**
- `visit` (1)
- `visit` (1)

### `o`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 0.3% (5.9ms) | Samples: 0

**Called by:**
- `r` (2)
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (2)
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `validateStyleSpec`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:472` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (1)

**Calls:**
- `safeCssToken` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:4` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:163` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `opaqueOutlineWidth` (1)

### `snapshotFamilyIdentity`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1514` | Self: 0.0% (0us) | Total: 0.3% (6.1ms) | Samples: 0

**Called by:**
- `freezeDescriptor` (1)

**Calls:**
- `captureFields` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:627` | Self: 0.0% (0us) | Total: 0.5% (7.8ms) | Samples: 0

**Called by:**
- `finish` (6)

**Calls:**
- `repairErFrameRoutes` (2)
- `repairErFrameRoutes` (2)
- `repairErFrameRoutes` (1)
- `repairErFrameRoutes` (1)

### `walk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1757` | Self: 0.0% (0us) | Total: 0.0% (946us) | Samples: 0

**Called by:**
- `walk` (1)

**Calls:**
- `endpointRelation` (1)

### `semanticIdentityForSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:56` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `attr` (1)

### `renderContractDigest`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1118` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveExecutionPlan` (1)

**Calls:**
- `admitRenderContractDigestInput` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:300` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `sanitizeDisplayLines` (1)

### `report`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:235` | Self: 0.0% (0us) | Total: 3.4% (53.0ms) | Samples: 0

**Called by:**
- `retainedNativeDrawing` (33)

**Calls:**
- `runBackendConformance` (13)
- `runBackendConformance` (11)
- `runBackendConformance` (3)
- `runBackendConformance` (3)
- `runBackendConformance` (1)
- `runBackendConformance` (1)
- `runBackendConformance` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:114` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Calls:**
- `flowchartMarkerResources` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:520` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `connector` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:153` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `documentClose` (1)

### `ownValue`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:43` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `hint` (1)

**Calls:**
- `getOwnPropertyDescriptor` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1546` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `executionCapabilityDecision` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:125` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `deferredTerminalProjectionInput` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/agent/families.ts:8` | Self: 0.0% (0us) | Total: 2.7% (43.1ms) | Samples: 0

**Calls:**
- `installBuiltinFamily` (9)
- `installBuiltinFamily` (5)
- `installBuiltinFamily` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1472` | Self: 0.0% (0us) | Total: 2.5% (38.7ms) | Samples: 0

**Called by:**
- `serialize` (23)

**Calls:**
- `serializeSceneNode` (20)
- `serializeSceneNode` (2)
- `issue` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:314` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `text` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:638` | Self: 0.0% (0us) | Total: 2.4% (37.8ms) | Samples: 0

**Called by:**
- `leaf` (26)

**Calls:**
- `copyInner` (25)
- `copyInner` (1)

### `projectSvgCss`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:287` | Self: 0.0% (0us) | Total: 0.7% (11.4ms) | Samples: 0

**Called by:**
- `colorResolution` (7)

**Calls:**
- `scanStartTags` (2)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:5` | Self: 0.0% (0us) | Total: 2.0% (32.0ms) | Samples: 0

**Called by:**
- `anonymous` (10)

**Calls:**
- `bound require` (10)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/yaml-1.1/schema.js:14` | Self: 0.0% (0us) | Total: 0.1% (2.9ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/decode-data-html.js:3` | Self: 0.0% (0us) | Total: 3.0% (47.9ms) | Samples: 0

**Calls:**
- `decodeBase64` (1)

### `markerTerminalDepth`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:294` | Self: 0.0% (0us) | Total: 0.7% (11.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)
- `(anonymous)` (1)

**Calls:**
- `markerBoundsAt` (3)
- `markerBoundsAt` (1)
- `pointsBounds` (1)
- `markerBoundsAt` (1)

### `erCardinalityInk`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:126` | Self: 0.0% (0us) | Total: 0.7% (12.0ms) | Samples: 0

**Called by:**
- `enoughLead` (3)
- `erCardinalityEnvelope` (3)
- `(anonymous)` (1)
- `(anonymous)` (1)

**Calls:**
- `paintBounds` (4)
- `paintBounds` (4)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1621` | Self: 0.0% (0us) | Total: 0.5% (9.1ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (7)

**Calls:**
- `validateNode` (3)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:140` | Self: 0.0% (0us) | Total: 0.3% (5.7ms) | Samples: 0

**Called by:**
- `svgStyleRanges` (2)
- `visitSvgStartTagsFresh` (2)
- `visitSvgFirstTagAttributes` (1)

**Calls:**
- `scanTagEnd` (2)
- `scanTagEnd` (1)
- `scanTagEnd` (1)
- `scanTagEnd` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:90` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `svgOpenTag` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:6538` | Self: 0.0% (0us) | Total: 0.2% (3.8ms) | Samples: 0

**Called by:**
- `o` (2)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Collection.js:3` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1776` | Self: 0.0% (0us) | Total: 0.1% (3.0ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `Set` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Pair.js:5` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `verifyNoExternalRefs`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:701` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `runBackendConformance` (1)

**Calls:**
- `inspectOwnedSvgOnce` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:674` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `cloneObject` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1944` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (1)

**Calls:**
- `connectorMarkerPaintRegions` (1)

### `erCardinalityEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/er/cardinality-geometry.ts:134` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `nativePlacement` (3)

**Calls:**
- `erCardinalityInk` (3)

### `applyFamilyRequestNormalization`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1075` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `resolveAppearance` (1)

**Calls:**
- `assertFamilyGeometryOptions` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:250` | Self: 0.0% (0us) | Total: 0.2% (3.2ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `finish` (1)
- `finish` (1)

### `writeShapeSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:678` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `geometryAttributes` (1)

### `relationshipFrom`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1107` | Self: 0.0% (0us) | Total: 0.2% (4.5ms) | Samples: 0

**Called by:**
- `parseErDiagram` (3)

**Calls:**
- `erTextLabel` (2)
- `erTextLabel` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1527` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `map` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:191` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Calls:**
- `createRenderOutputDescriptors` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1783` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Called by:**
- `measureRenderStage` (3)

**Calls:**
- `resolveExecutionPlan` (1)
- `resolveExecutionPlan` (1)
- `resolveExecutionPlan` (1)

### `resolvedColorValue`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:601` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Called by:**
- `toneOnFill` (2)
- `toneOnFill` (1)

**Calls:**
- `diagramColorVariables` (2)
- `diagramColorVariables` (1)

### `resolveSvgColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:758` | Self: 0.0% (0us) | Total: 0.3% (5.6ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (3)

**Calls:**
- `transformSvgCssValues` (2)
- `applyReplacements` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:110` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (2)

**Calls:**
- `createNativePaintEmission` (1)
- `createNativePaintEmission` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-doc.js:4` | Self: 0.0% (0us) | Total: 0.2% (3.6ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `lineStrokeBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:536` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `strokedBox` (1)

**Calls:**
- `hypot` (1)

### `serializeLinearGradientResource`
`/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts:78` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `assertRenderableLinearGradient` (1)

### `diagramColorVariables`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:569` | Self: 0.0% (0us) | Total: 0.2% (4.5ms) | Samples: 0

**Called by:**
- `resolvedColorValue` (2)
- `colorResolution` (1)

**Calls:**
- `resolveColors` (2)
- `resolveColors` (1)

### `connectorPaintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:592` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `geometryBounds` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:713` | Self: 0.0% (0us) | Total: 0.3% (4.8ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (4)

**Calls:**
- `typographyAttributes` (4)

### `registerBuiltInStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:292` | Self: 0.0% (0us) | Total: 0.3% (5.8ms) | Samples: 0

**Called by:**
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `validateStyleSpec` (2)
- `validateStyleSpec` (1)

### `internal:fs/streams`
`internal:fs/streams:2` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `paintedStrokeExtent`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:511` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `connectorPaintBounds` (1)

**Calls:**
- `/^\s*(?:\d+\.?\d*\|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:218` | Self: 0.0% (0us) | Total: 1.1% (18.1ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (11)

**Calls:**
- `inlineResolvedColors` (8)
- `resolveSvgColors` (3)

### `attributeRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:19` | Self: 0.0% (0us) | Total: 0.2% (3.9ms) | Samples: 0

**Called by:**
- `value` (2)

**Calls:**
- `defineProperties` (2)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1655` | Self: 0.0% (0us) | Total: 0.0% (994us) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `resolveDiagramColors` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:974` | Self: 0.0% (0us) | Total: 0.3% (5.3ms) | Samples: 0

**Called by:**
- `map` (3)

**Calls:**
- `connector/subpaths/render` (1)
- `nativeOrEmulated` (1)
- `connector/interaction/hit-test` (1)

### `runMeasuredGraphBackend`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:73` | Self: 0.0% (0us) | Total: 6.0% (93.0ms) | Samples: 0

**Called by:**
- `layout` (54)

**Calls:**
- `nativeCandidate` (54)

### `projectErPositioned`
`/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts:11` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `map` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:359` | Self: 0.0% (0us) | Total: 0.2% (3.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `xmlSlice` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:645` | Self: 0.0% (0us) | Total: 0.0% (943us) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `prepareWrittenCompoundShape` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1468` | Self: 0.0% (0us) | Total: 1.4% (22.0ms) | Samples: 0

**Called by:**
- `serialize` (17)

**Calls:**
- `validateNode` (3)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)
- `validateNode` (1)

### `rendered`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:427` | Self: 0.0% (0us) | Total: 0.9% (14.3ms) | Samples: 0

**Called by:**
- `runBackendConformance` (11)

**Calls:**
- `render` (11)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1397` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `some` (1)

### `bound require`
`[native code]` | Self: 0.0% (0us) | Total: 38.9% (602.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (15)
- `(anonymous)` (10)
- `(anonymous)` (7)
- `(anonymous)` (5)
- `(anonymous)` (4)
- `(anonymous)` (4)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

**Calls:**
- `require` (74)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:181` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (3)

**Calls:**
- `scopeHash` (1)
- `scopeHash` (1)
- `scopeHash` (1)

### `attr`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:53` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `semanticIdentityForSvg` (1)

**Calls:**
- `match` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1365` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `resolveRoleStyle` (1)

### `drawn`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:421` | Self: 0.0% (0us) | Total: 0.5% (7.9ms) | Samples: 0

**Called by:**
- `runBackendConformance` (3)
- `nativeOrEmulated` (1)

**Calls:**
- `serializeSceneNode` (2)
- `serializeSceneNode` (1)
- `serializeSceneNode` (1)

### `consume`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:15` | Self: 0.0% (0us) | Total: 0.6% (9.9ms) | Samples: 0

**Called by:**
- `(module)` (4)

**Calls:**
- `stringify` (4)

### `scopeSvgStyles`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:185` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (2)

**Calls:**
- `scopeCss` (2)

### `flowchartMarkerResources`
`/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts:81` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `circleMarkerResources` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1841` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `find` (1)

**Calls:**
- `detectsArchitectureFamily` (1)

### `positionFamilyForNativeRender`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:67` | Self: 0.0% (0us) | Total: 8.1% (126.4ms) | Samples: 0

**Called by:**
- `measureRenderStage` (76)

**Calls:**
- `withTextMeasurementExecution` (75)
- `positionFamily` (1)

### `copyInner`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:135` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `copyInner` (2)

**Calls:**
- `hasOwn` (2)

### `layout`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:27` | Self: 0.0% (0us) | Total: 6.7% (104.0ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (61)

**Calls:**
- `runMeasuredGraphBackend` (54)
- `layoutErDiagram` (6)
- `runMeasuredGraphBackend` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:298` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `map` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:775` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `stringify` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:805` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `attribute` (1)

### `prepareDisplayText`
`/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts:157` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `preparePixelText` (1)

**Calls:**
- `qualify` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/parse/cst.js:4` | Self: 0.0% (0us) | Total: 0.3% (5.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:201` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:152` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `charge` (1)

### `ZlibBase`
`node:zlib:123` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Zlib` (1)

**Calls:**
- `Transform` (1)

### `erLabelUnread`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1063` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `parseErRelationshipSyntax` (1)

**Calls:**
- `test` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:150` | Self: 0.0% (0us) | Total: 0.6% (9.4ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (8)

**Calls:**
- `renderRelationshipLabel` (4)
- `renderRelationshipLabel` (3)
- `renderRelationshipLabel` (1)

### `scopedRule`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:137` | Self: 0.0% (0us) | Total: 0.0% (978us) | Samples: 0

**Called by:**
- `scopeCss` (1)

**Calls:**
- `map` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/eventmodeling/markers.ts:5` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:34` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `build` (1)

**Calls:**
- `chargeInkSort` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1049` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `report` (1)

**Calls:**
- `verifyNoExternalRefs` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:43` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `scanStartTags` (1)

**Calls:**
- `test` (1)

### `transformedBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:471` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `paintBounds` (1)

**Calls:**
- `every` (1)

### `sharedRenderOptionsJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:485` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validateSerializableRenderOptions` (1)

**Calls:**
- `cloneValue` (1)

### `opaqueOutlineWidth`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:149` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `solidInteriors` (1)

**Calls:**
- `opaque` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` | Self: 0.0% (0us) | Total: 0.7% (11.9ms) | Samples: 0

**Called by:**
- `map` (9)

**Calls:**
- `cloneValue` (7)
- `map` (2)

### `positionFamily`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:94` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `positionFamilyForNativeRender` (1)

**Calls:**
- `resolvedFamilyRenderContextOf` (1)

### `createNativePaintEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:56` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `createEmissionContext` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:6` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `write`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1473` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `serialize` (1)

**Calls:**
- `boundedUtf8ByteLength` (1)

### `resolveAppearance`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1656` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `applyFamilyRequestNormalization` (1)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:195` | Self: 0.0% (0us) | Total: 0.2% (3.5ms) | Samples: 0

**Called by:**
- `renderEntityBox` (3)

**Calls:**
- `resolvedColorValue` (2)
- `resolvedColorValue` (1)

### `styleSpecJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:609` | Self: 0.0% (0us) | Total: 0.4% (6.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `roleStyleJsonSchema` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:738` | Self: 0.0% (0us) | Total: 0.2% (3.5ms) | Samples: 0

**Called by:**
- `write` (3)

**Calls:**
- `localPaintResourceReferences` (2)
- `localPaintResourceReferences` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:312` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `extractErLayout` (1)

**Calls:**
- `enoughLead` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:672` | Self: 0.0% (0us) | Total: 4.4% (69.5ms) | Samples: 0

**Called by:**
- `leaf` (43)

**Calls:**
- `serialize` (42)
- `serialize` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:215` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `paintedStrokeExtent` (1)

### `writeTextSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:740` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `(anonymous)` (1)

### `visitSvgStartTagsFresh`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:116` | Self: 0.0% (0us) | Total: 0.5% (9.2ms) | Samples: 0

**Called by:**
- `collectNativeGroup` (6)

**Calls:**
- `scanStartTags` (2)
- `scanStartTags` (2)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `serialize`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:633` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `read` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:486` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `attribute` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1094` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `validatePoint` (1)

### `Gzip`
`node:zlib:328` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `gzipSync` (1)

**Calls:**
- `Zlib` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/shared/graphemes.ts:3` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Calls:**
- `Segmenter` (2)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1185` | Self: 0.0% (0us) | Total: 0.9% (15.4ms) | Samples: 0

**Called by:**
- `nativeCandidate` (11)

**Calls:**
- `extractErLayout` (6)
- `extractErLayout` (1)
- `extractErLayout` (1)
- `prepareErText` (1)
- `extractErLayout` (1)
- `extractErLayout` (1)

### `inspectPaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:98` | Self: 0.0% (0us) | Total: 2.3% (35.6ms) | Samples: 0

**Called by:**
- `drawNative` (22)

**Calls:**
- `visit` (13)
- `visit` (6)
- `visit` (3)

### `placeRelationshipLabels`
`/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts:206` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `finalizeErRelationshipLabels` (1)

**Calls:**
- `collides` (1)

### `withTextMeasurementExecution`
`/tmp/pr449-main-integration-20261029-762/src/text-measurement-profile.ts:135` | Self: 0.0% (0us) | Total: 55.9% (865.0ms) | Samples: 0

**Called by:**
- `consumeResolvedGraphicalRequest` (281)
- `retainedNativeDrawing` (175)
- `positionFamilyForNativeRender` (75)
- `runBackendConformance` (13)

**Calls:**
- `renderPositionedWithTextMeasurement` (209)
- `drawNative` (146)
- `(anonymous)` (73)
- `renderPositionedWithTextMeasurement` (31)
- `drawNative` (23)
- `renderPositionedWithTextMeasurement` (22)
- `renderPositionedWithTextMeasurement` (11)
- `renderPositionedWithTextMeasurement` (8)
- `createFixture` (5)
- `createFixture` (2)
- `createFixture` (2)
- `drawNative` (2)
- `drawNative` (2)
- `drawNative` (1)
- `(anonymous)` (1)
- `createFixture` (1)
- `createFixture` (1)
- `drawNative` (1)
- `createFixture` (1)
- `createFixture` (1)
- `(anonymous)` (1)

### `strokedBox`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:543` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `paintBounds` (3)

**Calls:**
- `lineStrokeBox` (1)
- `lineStrokeBox` (1)
- `lineStrokeBox` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/requirement/markers.ts:4` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (1)

### `get receipt`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:347` | Self: 0.0% (0us) | Total: 0.6% (9.9ms) | Samples: 0

**Called by:**
- `stringify` (4)

**Calls:**
- `(anonymous)` (2)
- `(anonymous)` (2)

### `shortenMeasuredRoutes`
`/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts:31` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `map` (1)

### `registerCanonicalStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:230` | Self: 0.0% (0us) | Total: 0.1% (2.9ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (1)

**Calls:**
- `frozenRoleStyles` (1)

### `prepareErText`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:151` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `map` (1)

### `consumeResolvedGraphicalRequest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:316` | Self: 0.0% (0us) | Total: 37.2% (575.4ms) | Samples: 0

**Called by:**
- `withSvgInspectionCache` (357)

**Calls:**
- `withTextMeasurementExecution` (281)
- `renderResolvedMermaidSVG` (76)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:420` | Self: 0.0% (0us) | Total: 0.2% (3.1ms) | Samples: 0

**Called by:**
- `measureErEntities` (2)

**Calls:**
- `advance` (1)
- `advance` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:166` | Self: 0.0% (0us) | Total: 0.7% (12.1ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (6)
- `renderCardinality` (2)

**Calls:**
- `group` (4)
- `group` (3)
- `group` (1)

### `renderRelationshipLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:543` | Self: 0.0% (0us) | Total: 0.2% (4.5ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (4)

**Calls:**
- `leaf` (4)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1389` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `(anonymous)` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:186` | Self: 0.0% (0us) | Total: 3.9% (61.3ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (31)

**Calls:**
- `measureRenderStage` (31)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:167` | Self: 0.0% (0us) | Total: 1.1% (18.0ms) | Samples: 0

**Called by:**
- `renderCardinality` (5)
- `lowerErDrawing` (3)
- `renderCardinality` (3)

**Calls:**
- `node` (9)
- `node` (2)

### `materializeText`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:102` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `transferRetainedPixelText` (1)

### `validateSceneDocument`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1637` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `assertAdmissibleSceneDoc` (2)

**Calls:**
- `applyOutputSecurityPolicy` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:202` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `map` (2)

**Calls:**
- `get` (1)
- `stringify` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:252` | Self: 0.0% (0us) | Total: 0.9% (14.0ms) | Samples: 0

**Called by:**
- `leaf` (9)

**Calls:**
- `paintBounds` (2)
- `connectorPaintBounds` (2)
- `paintBounds` (1)
- `paintBounds` (1)
- `paintBounds` (1)
- `connectorPaintBounds` (1)
- `paintBounds` (1)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:156` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `scanStartTags` (1)

**Calls:**
- `(anonymous)` (1)

### `captureFields`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1481` | Self: 0.0% (0us) | Total: 0.3% (6.1ms) | Samples: 0

**Called by:**
- `snapshotFamilyIdentity` (1)

**Calls:**
- `map` (1)

### `svgOpenTag`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:429` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `formatSvgNumericAttribute` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:259` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `leaf` (1)

### `negotiateCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts:127` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `executionCapabilityDecision` (1)

**Calls:**
- `isCapabilityId` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/nodes/Alias.js:6` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `writeConnectorSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:804` | Self: 0.0% (0us) | Total: 0.2% (4.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (2)

**Calls:**
- `geometryAttributes` (2)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:220` | Self: 0.0% (0us) | Total: 0.1% (3.0ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (2)

**Calls:**
- `layoutSharedFan` (2)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:420` | Self: 0.0% (0us) | Total: 0.6% (9.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `readXmlDataEnd` (2)
- `readXmlDataEnd` (1)
- `readXmlDataEnd` (1)
- `readXmlDataEnd` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:998` | Self: 0.0% (0us) | Total: 1.4% (23.1ms) | Samples: 0

**Called by:**
- `report` (13)

**Calls:**
- `withTextMeasurementExecution` (13)

### `boundedImmutableJsonSnapshot`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1242` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `admitRenderContractDigestInput` (1)

**Calls:**
- `omitUndefinedObjectFields` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:141` | Self: 0.0% (0us) | Total: 0.2% (3.6ms) | Samples: 0

**Calls:**
- `traits` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:780` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `validateNodeSerialization` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `(anonymous)` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:94` | Self: 0.0% (0us) | Total: 0.5% (7.7ms) | Samples: 0

**Called by:**
- `inspectPaint` (6)

**Calls:**
- `leaf` (6)

### `r`
`/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:1` | Self: 0.0% (0us) | Total: 0.2% (3.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `o` (2)

### `read`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:258` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `serialize` (1)

**Calls:**
- `factOf` (1)

### `gzipSync`
`node:zlib:360` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `Gzip` (1)

### `repairErFrameRoutes`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:313` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Called by:**
- `extractErLayout` (2)

**Calls:**
- `enoughLead` (2)

### `retainOrder`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:76` | Self: 0.0% (0us) | Total: 1.2% (18.6ms) | Samples: 0

**Called by:**
- `retainOrder` (8)
- `tree` (2)

**Calls:**
- `retainOrder` (8)
- `retainOrder` (1)
- `retainOrder` (1)

### `formatSvgNumericAttribute`
`/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts:41` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `svgOpenTag` (1)

**Calls:**
- `replace` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1245` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `erCardinalityInk` (1)

### `crowsFootMark`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:628` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `renderCardinality` (2)

**Calls:**
- `map` (1)
- `some` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:786` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `filter` (1)

**Calls:**
- `relationEnd` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:22` | Self: 0.0% (0us) | Total: 1.2% (19.6ms) | Samples: 0

**Calls:**
- `gc` (14)

### `attribute`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:483` | Self: 0.0% (0us) | Total: 0.3% (6.1ms) | Samples: 0

**Called by:**
- `paintAttribute` (2)

**Calls:**
- `formatSvgNumericAttribute` (1)
- `formatSvgNumericAttribute` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1256` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `flatIntoArrayWithCallback` (1)

**Calls:**
- `erRelationshipStyle` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/architecture/config-diagnostics.ts:6` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Calls:**
- `numericLike` (1)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:745` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `finish` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:220` | Self: 0.0% (0us) | Total: 0.5% (7.8ms) | Samples: 0

**Called by:**
- `copyInner` (4)

**Calls:**
- `copyInner` (4)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/composer.js:4` | Self: 0.0% (0us) | Total: 0.9% (13.9ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `svgRootStartTag`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:202` | Self: 0.0% (0us) | Total: 0.0% (947us) | Samples: 0

**Called by:**
- `scopeSvgStyles` (1)

**Calls:**
- `inspectOwnedSvgOnce` (1)

### `snapshotScenePrimitiveCell`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1548` | Self: 0.0% (0us) | Total: 0.3% (5.6ms) | Samples: 0

**Called by:**
- `snapshotDescriptorArray` (3)

**Calls:**
- `freeze` (2)
- `snapshotDescriptorArray` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:197` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `escapeDisplayAttr` (1)

### `freezeFamilyConformanceReport`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1903` | Self: 0.0% (0us) | Total: 0.2% (3.5ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `cloneObject` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:125` | Self: 0.0% (0us) | Total: 0.2% (3.8ms) | Samples: 0

**Called by:**
- `renderEntityBox` (2)
- `renderRelationshipLabel` (1)

**Calls:**
- `admitWritableSceneNode` (1)
- `shape` (1)
- `shape` (1)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:694` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `diagramColorVariables` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:3` | Self: 0.0% (0us) | Total: 3.5% (55.1ms) | Samples: 0

**Calls:**
- `bound require` (15)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/core/float.js:4` | Self: 0.0% (0us) | Total: 0.3% (5.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:14` | Self: 0.0% (0us) | Total: 5.9% (91.3ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:215` | Self: 0.0% (0us) | Total: 0.5% (9.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (5)

**Calls:**
- `leaf` (5)

### `parseErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:832` | Self: 0.0% (0us) | Total: 0.6% (9.9ms) | Samples: 0

**Called by:**
- `layout` (6)

**Calls:**
- `readErStatements` (2)
- `readErStatements` (2)
- `readErStatements` (1)
- `readErStatements` (1)

### `renderRelationshipLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:534` | Self: 0.0% (0us) | Total: 0.2% (3.6ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (3)

**Calls:**
- `leaf` (1)
- `shape` (1)
- `shape` (1)

### `writeSceneNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `map` (1)

### `enoughLead`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:300` | Self: 0.0% (0us) | Total: 0.2% (4.5ms) | Samples: 0

**Called by:**
- `repairErFrameRoutes` (2)
- `repairErFrameRoutes` (1)

**Calls:**
- `erCardinalityInk` (3)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:168` | Self: 0.0% (0us) | Total: 0.3% (5.8ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `attachSceneNodeSerialization` (1)

### `crowsFootMark`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:621` | Self: 0.0% (0us) | Total: 0.5% (8.6ms) | Samples: 0

**Called by:**
- `renderCardinality` (4)
- `renderCardinality` (3)

**Calls:**
- `leaf` (7)

### `findErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:698` | Self: 0.0% (0us) | Total: 0.2% (4.3ms) | Samples: 0

**Called by:**
- `readErStatements` (2)

**Calls:**
- `readErOuterStatements` (2)

### `snapshot`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1318` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `finishErGeometry` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:90` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `sceneAssertionsEnabled` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/generated/encode-html.js:10` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `parseEncodeTrie` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:328` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `get receipt` (2)

**Calls:**
- `canonicalTextDigest` (1)
- `renderedSvgDigest` (1)

### `walk`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1749` | Self: 0.0% (0us) | Total: 0.6% (9.7ms) | Samples: 0

**Called by:**
- `walk` (8)
- `visit` (2)

**Calls:**
- `walk` (8)
- `walk` (1)
- `walk` (1)

### `documentClose`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:140` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `attachSceneNodeSerialization` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:689` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `sameRectanglePaint` (1)

### `parseErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:902` | Self: 0.0% (0us) | Total: 0.0% (976us) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `includes` (1)

### `structurallyEqual`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1280` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `validateConnectorProjectionConsistency` (1)

**Calls:**
- `filter` (1)

### `readErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:785` | Self: 0.0% (0us) | Total: 0.2% (3.4ms) | Samples: 0

**Called by:**
- `parseErDiagram` (2)

**Calls:**
- `filter` (2)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:122` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `projectSvgCss` (1)
- `visitSvgStartTagsFresh` (1)

**Calls:**
- `sourceIndexOf` (2)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/default-backend.ts:5` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Calls:**
- `registerBuiltInBackend` (1)
- `registerBuiltInBackend` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:615` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `serializeSceneNode` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1841` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `find` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1763` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `has` (1)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:145` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (1)

**Calls:**
- `map` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:146` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `ownsParts` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:330` | Self: 0.0% (0us) | Total: 0.5% (7.8ms) | Samples: 0

**Called by:**
- `get receipt` (2)

**Calls:**
- `receiptOf` (1)
- `receiptOf` (1)

### `layout`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:26` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (1)

**Calls:**
- `checkAllClassLikeAuthoredStyles` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:778` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `validateChannels` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:96` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `shortenMeasuredRoutes` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:98` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (1)

**Calls:**
- `leaf` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:617` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `group` (3)

**Calls:**
- `ensureSvgIdentity` (3)

### `normalizedErText`
`/tmp/pr449-main-integration-20261029-762/src/er/text.ts:87` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `erDisplayText` (1)

**Calls:**
- `normalizeBrTags` (1)

### `layout`
`/tmp/pr449-main-integration-20261029-762/src/svg-family-hooks/er.ts:23` | Self: 0.0% (0us) | Total: 1.1% (17.1ms) | Samples: 0

**Called by:**
- `withGraphLayoutDecisionObserver` (11)

**Calls:**
- `parseErDiagram` (6)
- `parseErDiagram` (3)
- `parseErDiagram` (1)
- `parseErDiagram` (1)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1576` | Self: 0.0% (0us) | Total: 0.3% (6.1ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `snapshotFamilyIdentity` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:652` | Self: 0.0% (0us) | Total: 0.4% (6.9ms) | Samples: 0

**Called by:**
- `erCardinalityInk` (4)

**Calls:**
- `paintedStrokeExtent` (4)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:446` | Self: 0.0% (0us) | Total: 0.3% (5.8ms) | Samples: 0

**Called by:**
- `sort` (1)

**Calls:**
- `compareCodePointStrings` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:993` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `serializeLinearGradientResources` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1088` | Self: 0.0% (0us) | Total: 0.3% (5.3ms) | Samples: 0

**Called by:**
- `report` (3)

**Calls:**
- `map` (3)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts:253` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `leaf` (2)

**Calls:**
- `finite` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:10` | Self: 0.0% (0us) | Total: 0.6% (9.5ms) | Samples: 0

**Called by:**
- `map` (5)

**Calls:**
- `markerTerminalDepth` (5)

### `freezeDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1583` | Self: 0.0% (0us) | Total: 0.3% (5.6ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (3)

**Calls:**
- `snapshotDescriptorArray` (3)

### `toneOnFill`
`/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts:196` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `renderEntityBox` (1)

**Calls:**
- `resolvedColorValue` (1)

### `renderedSvgDigest`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:61` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `stringify` (1)

### `shape`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:101` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `relationAccessibility` (1)

### `validatePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:311` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `safeCssPaint` (1)

### `normalizeMermaidSourceWithOverrides`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:762` | Self: 0.0% (0us) | Total: 0.4% (6.8ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (5)

**Calls:**
- `normalizeSource` (1)
- `normalizeSource` (1)
- `normalizeSource` (1)
- `normalizeMermaidSource` (1)
- `normalizeMermaidSource` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:224` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `transformedBounds` (1)

### `node`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1456` | Self: 0.0% (0us) | Total: 0.2% (3.2ms) | Samples: 0

**Called by:**
- `group` (2)

**Calls:**
- `validateNodeSerialization` (1)
- `validateNodeSerialization` (1)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:465` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `validate` (1)

### `validateSerializableRenderOptions`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:454` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `sharedRenderOptionsJsonSchema` (1)

### `canonicalOpeningTag`
`/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts:443` | Self: 0.0% (0us) | Total: 0.3% (5.8ms) | Samples: 0

**Called by:**
- `canonicalizeSceneNodeSerialization` (1)

**Calls:**
- `sort` (1)

### `inlineResolvedColors`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:636` | Self: 0.0% (0us) | Total: 0.8% (12.4ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (8)

**Calls:**
- `colorResolution` (7)
- `colorResolution` (1)

### `inspectOwnedSvgOnce`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:46` | Self: 0.0% (0us) | Total: 2.9% (45.6ms) | Samples: 0

**Called by:**
- `applyOutputSecurityPolicy` (24)
- `svgRootStartTag` (1)
- `runBackendConformance` (1)
- `verifyNoExternalRefs` (1)

**Calls:**
- `(anonymous)` (22)
- `scanStartTags` (1)
- `inspectSecurityTail` (1)
- `verifyDocumentEnvelope` (1)
- `inspectSecurityTail` (1)
- `inspectSecurity` (1)

### `installBuiltinFamily`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1878` | Self: 0.0% (0us) | Total: 0.9% (14.1ms) | Samples: 0

**Called by:**
- `(module)` (5)

**Calls:**
- `freezeDescriptor` (3)
- `completeBuiltinDescriptor` (1)
- `freezeDescriptor` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1483` | Self: 0.0% (0us) | Total: 0.2% (3.2ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `hint`
`/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts:359` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `observe` (1)

**Calls:**
- `ownValue` (1)

### `validateAggregateReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1525` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `has` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:148` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `visitSvgStartTagsFresh` (1)

**Calls:**
- `tag` (1)

### `createFixture`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:193` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `shape` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1301` | Self: 0.0% (0us) | Total: 0.5% (8.4ms) | Samples: 0

**Called by:**
- `nativeCandidate` (5)

**Calls:**
- `finalizeErRelationshipLabels` (5)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:32` | Self: 0.0% (0us) | Total: 0.8% (12.3ms) | Samples: 0

**Calls:**
- `consume` (4)
- `consume` (1)
- `consume` (1)

### `internal:streams/operators`
`internal:streams/operators:2` | Self: 0.0% (0us) | Total: 0.2% (3.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `svgStyleRanges`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:294` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `scopeSvgStyles` (2)

**Calls:**
- `scanStartTags` (2)

### `scopedRule`
`/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts:131` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `scopeCss` (1)

**Calls:**
- `exec` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:172` | Self: 0.0% (0us) | Total: 0.2% (3.5ms) | Samples: 0

**Called by:**
- `visitSvgStartTagsFresh` (2)

**Calls:**
- `attribute` (1)
- `attribute` (1)

### `next`
`[native code]` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `Set` (1)

**Calls:**
- `arrayIteratorNextHelper` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:310` | Self: 0.0% (0us) | Total: 0.3% (4.6ms) | Samples: 0

**Called by:**
- `map` (2)

**Calls:**
- `slice` (1)
- `(anonymous)` (1)

### `assignPorts`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:688` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `map` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:143` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (1)

**Calls:**
- `assessRenderedLayoutHardViolations` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:624` | Self: 0.0% (0us) | Total: 0.2% (3.5ms) | Samples: 0

**Called by:**
- `visit` (1)
- `visit` (1)

**Calls:**
- `hint` (1)
- `hint` (1)

### `internal:streams/legacy`
`internal:streams/legacy:2` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `validateNodeSerialization`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:702` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `validateNode` (1)
- `node` (1)

**Calls:**
- `serializeSceneNode` (1)
- `serializeSceneNode` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:588` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Called by:**
- `createFixture` (1)

**Calls:**
- `semanticIdentityForSvg` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:14` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `validateRoleStyles`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:340` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Called by:**
- `validateStyleSpec` (1)

**Calls:**
- `validateRoleStyleRecord` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:22` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Calls:**
- `RegExp` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:840` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `isRetainedPixelText` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:906` | Self: 0.0% (0us) | Total: 0.8% (13.4ms) | Samples: 0

**Called by:**
- `node` (8)

**Calls:**
- `groupValidation` (8)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:3` | Self: 0.0% (0us) | Total: 16.6% (256.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (7)

**Calls:**
- `bound require` (7)

### `finish`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:726` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `drawNative` (1)

**Calls:**
- `some` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:175` | Self: 0.0% (0us) | Total: 0.7% (12.2ms) | Samples: 0

**Called by:**
- `checkInertGroup` (7)

**Calls:**
- `collectNativeGroup` (6)
- `nativeParseRecord` (1)

### `roleStyleJsonSchema`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:496` | Self: 0.0% (0us) | Total: 0.4% (6.6ms) | Samples: 0

**Called by:**
- `styleSpecJsonSchema` (1)

**Calls:**
- `map` (1)

### `admitSceneDocumentWith`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:270` | Self: 0.0% (0us) | Total: 0.7% (11.7ms) | Samples: 0

**Called by:**
- `render` (9)

**Calls:**
- `assertAdmissibleSceneDoc` (9)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:8` | Self: 0.0% (0us) | Total: 0.3% (5.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `zlibBufferSync`
`node:zlib:94` | Self: 0.0% (0us) | Total: 0.0% (979us) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `processChunkSync` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:665` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `opaque` (1)

**Calls:**
- `colorResolution` (1)

### `createRenderOutputDescriptors`
`/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts:171` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `map` (1)

### `issue`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:91` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `serializeSceneNode` (1)

**Calls:**
- `freeze` (1)

### `receiptOf`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:758` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `join`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:200` | Self: 0.0% (0us) | Total: 1.0% (16.5ms) | Samples: 0

**Called by:**
- `group` (9)

**Calls:**
- `(anonymous)` (9)

### `scanTagEnd`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:59` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `scanStartTags` (1)

**Calls:**
- `sourceIndexOf` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:710` | Self: 0.0% (0us) | Total: 2.4% (38.0ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (22)

**Calls:**
- `verifyDocumentEnvelope` (5)
- `verifyDocumentEnvelope` (5)
- `verifyDocumentEnvelope` (5)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)
- `verifyDocumentEnvelope` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1742` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `find` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:228` | Self: 0.0% (0us) | Total: 0.1% (3.0ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `scanAccessibilityDirectives`
`/tmp/pr449-main-integration-20261029-762/src/shared/accessibility-directives.ts:125` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `parseErDiagram` (1)

**Calls:**
- `slice` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts:55` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Calls:**
- `classMarkerResources` (1)

### `nativePlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1171` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `connectorInlineLabelSvg`
`/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts:761` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `writeConnectorSvg` (1)

**Calls:**
- `connectorInlineLabelText` (1)

### `withRenderStageObserver`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:20` | Self: 0.0% (0us) | Total: 38.5% (596.3ms) | Samples: 0

**Called by:**
- `withPerformanceObserver` (372)

**Calls:**
- `withSvgInspectionCache` (372)

### `chargeInkSort`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:7` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `build` (1)

**Calls:**
- `compare` (1)

### `rectOverlap`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:164` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `assessFamilyLayout` (1)

**Calls:**
- `min` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1088` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `validatePoint` (1)

### `captureNativeGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:101` | Self: 0.0% (0us) | Total: 0.8% (13.4ms) | Samples: 0

**Called by:**
- `groupValidation` (8)

**Calls:**
- `captureNativeGroupParse` (8)

### `graphicalBackendCapabilityClaims`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:271` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `createSketchBackend` (1)

**Calls:**
- `validatePrimitiveCapabilities` (1)

### `localPaintResourceReferences`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1395` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `validateNode` (2)

**Calls:**
- `collectPaintResourceReferences` (2)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/d3-sankey/dist/d3-sankey.js:5` | Self: 0.0% (0us) | Total: 16.6% (256.8ms) | Samples: 0

**Calls:**
- `(anonymous)` (7)

### `withPerformanceObserver`
`/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts:42` | Self: 0.0% (0us) | Total: 38.5% (596.3ms) | Samples: 0

**Called by:**
- `(module)` (372)

**Calls:**
- `withRenderStageObserver` (372)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:766` | Self: 0.0% (0us) | Total: 0.1% (2.9ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1592` | Self: 0.0% (0us) | Total: 0.9% (15.2ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (6)

**Calls:**
- `tree` (4)
- `tree` (2)

### `completeBuiltinDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1384` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `declareFamilyScenePrimitiveEvidence` (1)

### `canonicalErContacts`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:249` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `repairErFrameRoutes` (1)

**Calls:**
- `erCharge` (1)

### `serialize`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:631` | Self: 0.0% (0us) | Total: 4.3% (67.2ms) | Samples: 0

**Called by:**
- `leaf` (42)

**Calls:**
- `write` (23)
- `write` (17)
- `write` (1)
- `write` (1)

### `parseErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:810` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `layout` (1)

**Calls:**
- `scanAccessibilityDirectives` (1)

### `cloneValue`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:390` | Self: 0.0% (0us) | Total: 0.8% (13.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (7)
- `map` (2)
- `sharedRenderOptionsJsonSchema` (1)

**Calls:**
- `map` (10)

### `captureNativeGroupParse`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:173` | Self: 0.0% (0us) | Total: 0.8% (13.4ms) | Samples: 0

**Called by:**
- `captureNativeGroupEmission` (8)

**Calls:**
- `checkInertGroup` (8)

### `renderRelationshipLabel`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:527` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)

**Calls:**
- `resolveRoleStyle` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/block/markers.ts:10` | Self: 0.0% (0us) | Total: 0.2% (3.4ms) | Samples: 0

**Calls:**
- `prepareMarkerTerminals` (2)

### `escapeDisplayAttr`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:115` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `renderEntityBox` (1)

**Calls:**
- `sanitizeDisplayLines` (1)

### `node:fs`
`node:fs:8` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Calls:**
- `anonymous` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:323` | Self: 0.0% (0us) | Total: 0.1% (2.8ms) | Samples: 0

**Called by:**
- `measureErEntities` (2)

**Calls:**
- `prepareDisplayText` (1)
- `prepareDisplayText` (1)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:183` | Self: 0.0% (0us) | Total: 20.8% (322.0ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (209)

**Calls:**
- `measureRenderStage` (209)

### `internal:streams/duplex`
`internal:streams/duplex:2` | Self: 0.0% (0us) | Total: 1.4% (22.7ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `anonymous` (9)

### `executionCapabilityDecision`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1453` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveExecutionPlan` (1)

**Calls:**
- `negotiateCapabilities` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:634` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `visitSvgFirstTagAttributes`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:106` | Self: 0.0% (0us) | Total: 0.3% (5.1ms) | Samples: 0

**Called by:**
- `checkInertGroup` (4)

**Calls:**
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)
- `scanStartTags` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:90` | Self: 0.0% (0us) | Total: 0.7% (12.1ms) | Samples: 0

**Called by:**
- `visit` (8)

**Calls:**
- `leaf` (8)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:222` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `layoutMeasuredForest` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:653` | Self: 0.0% (0us) | Total: 0.3% (5.0ms) | Samples: 0

**Called by:**
- `erCardinalityInk` (4)

**Calls:**
- `strokedBox` (3)
- `transformedBounds` (1)

### `paintBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:676` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `leaf` (1)

**Calls:**
- `preparedInterTextBounds` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/compose/compose-node.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `measureRenderStage`
`/tmp/pr449-main-integration-20261029-762/src/render-stages.ts:30` | Self: 0.0% (0us) | Total: 38.6% (597.4ms) | Samples: 0

**Called by:**
- `renderPositionedWithTextMeasurement` (209)
- `renderResolvedMermaidSVG` (76)
- `renderPositionedWithTextMeasurement` (31)
- `renderPositionedWithTextMeasurement` (22)
- `nativePlacement` (15)
- `executeInspectedGraphicalRequest` (14)

**Calls:**
- `retainedNativeDrawing` (175)
- `positionFamilyForNativeRender` (76)
- `retainedNativeDrawing` (33)
- `positionedPaintCertification` (31)
- `applyOutputSecurityPolicy` (22)
- `layoutLayeredGraph` (13)
- `resolveRenderRequestForExecution` (5)
- `resolveRenderRequestForExecution` (3)
- `resolveRenderRequestForExecution` (3)
- `resolveRenderRequestForExecution` (2)
- `layoutLayeredGraph` (1)
- `resolveRenderRequestForExecution` (1)
- `layoutLayeredGraph` (1)
- `retainedNativeDrawing` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:430` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `connectorInlineLabelText` (1)

**Calls:**
- `every` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:411` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `add` (1)

### `localPaintResourceId`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:373` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `collectPaintResourceReferences` (1)

**Calls:**
- `exec` (1)

### `processChunkSync`
`node:zlib:203` | Self: 0.0% (0us) | Total: 0.0% (979us) | Samples: 0

**Called by:**
- `zlibBufferSync` (1)

**Calls:**
- `writeSync` (1)

### `connectorMarkerPaintRegions`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:352` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (1)

**Calls:**
- `forEach` (1)

### `group`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:169` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (1)
- `renderCardinality` (1)

**Calls:**
- `snapshot` (2)

### `measureErEntities`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:451` | Self: 0.0% (0us) | Total: 0.4% (7.2ms) | Samples: 0

**Called by:**
- `layoutErDiagram` (5)

**Calls:**
- `preparePixelText` (2)
- `preparePixelText` (2)
- `preparePixelText` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:258` | Self: 0.0% (0us) | Total: 0.1% (2.8ms) | Samples: 0

**Called by:**
- `writeTextSvg` (1)

**Calls:**
- `map` (1)

### `requiredBackendCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1363` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveExecutionPlan` (1)

**Calls:**
- `filter` (1)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:744` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `normalizeMermaidRuntimeConfig` (1)

### `expandLocalReferences`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:205` | Self: 0.0% (0us) | Total: 23.3% (361.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (26)
- `(module)` (6)

**Calls:**
- `map` (32)

### `get WriteStream`
`node:fs:667` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `anonymous` (2)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:702` | Self: 0.0% (0us) | Total: 0.0% (961us) | Samples: 0

**Called by:**
- `inlineResolvedColors` (1)

**Calls:**
- `cssPaintDefinitions` (1)

### `scanStartTags`
`/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts:173` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `projectSvgCss` (1)

**Calls:**
- `has` (1)

### `validateStyleSpec`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts:453` | Self: 0.0% (0us) | Total: 0.3% (4.7ms) | Samples: 0

**Called by:**
- `registerBuiltInStyle` (2)

**Calls:**
- `validateRoleStyles` (1)
- `validateRoleStyles` (1)

### `drawNative`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:205` | Self: 0.0% (0us) | Total: 14.2% (220.4ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (146)

**Calls:**
- `withDeferredTerminalProjections` (145)
- `withDeferredTerminalProjections` (1)

### `(module)`
`bun:main:14` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `isServerConfig` (1)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:137` | Self: 0.0% (0us) | Total: 2.7% (41.8ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (29)

**Calls:**
- `renderCardinality` (15)
- `renderCardinality` (13)
- `renderCardinality` (1)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:716` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `join` (1)

### `validatePrimitiveCapabilities`
`/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts:333` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `graphicalBackendCapabilityClaims` (1)

**Calls:**
- `primitiveCapabilityClaimKey` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:739` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `node` (1)

**Calls:**
- `includes` (1)

### `solidInteriors`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:202` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (2)

**Calls:**
- `map` (2)

### `nativePlacement`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1150` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `map` (1)

### `internal:validators`
`internal:validators:2` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `cssPaintDefinitions`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:613` | Self: 0.0% (0us) | Total: 0.0% (961us) | Samples: 0

**Called by:**
- `colorResolution` (1)

**Calls:**
- `safeCssToken` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:403` | Self: 0.0% (0us) | Total: 0.4% (7.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `readXmlNameEnd` (3)
- `readXmlNameEnd` (1)
- `readXmlNameEnd` (1)

### `inspectSecurityTail`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:697` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `freeze` (1)

### `geometryBounds`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:209` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `connectorPaintBounds` (1)

**Calls:**
- `pointsBounds` (1)

### `withGraphLayoutDecisionObserver`
`/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts:37` | Self: 0.0% (0us) | Total: 7.9% (122.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (73)

**Calls:**
- `layout` (61)
- `layout` (11)
- `layout` (1)

### `checkInertGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:39` | Self: 0.0% (0us) | Total: 1.2% (18.6ms) | Samples: 0

**Called by:**
- `captureNativeGroupParse` (8)
- `group` (4)

**Calls:**
- `(anonymous)` (7)
- `visitSvgFirstTagAttributes` (4)
- `(anonymous)` (1)

### `parseErRelationshipSyntax`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:1086` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `readErStatement` (1)

**Calls:**
- `erLabelUnread` (1)

### `internal:streams/destroy`
`internal:streams/destroy:2` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:streams/pipeline`
`internal:streams/pipeline:2` | Self: 0.0% (0us) | Total: 1.5% (23.9ms) | Samples: 0

**Called by:**
- `anonymous` (10)

**Calls:**
- `anonymous` (10)

### `snapshotDescriptorArray`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1501` | Self: 0.0% (0us) | Total: 0.3% (5.6ms) | Samples: 0

**Called by:**
- `freezeDescriptor` (3)

**Calls:**
- `snapshotScenePrimitiveCell` (3)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts:339` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `layoutLayeredGraph` (1)

**Calls:**
- `map` (1)

### `validateConnectorProjectionConsistency`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1364` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `structurallyEqual` (1)

### `registerBuiltInStyle`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:291` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `canonicalExtensionId` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:94` | Self: 0.0% (0us) | Total: 1.6% (25.3ms) | Samples: 0

**Called by:**
- `measureRenderStage` (13)

**Calls:**
- `layoutLayeredGraph` (5)
- `layoutLayeredGraph` (2)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)
- `layoutLayeredGraph` (1)

### `runBackendConformance`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:1045` | Self: 0.0% (0us) | Total: 0.1% (2.1ms) | Samples: 0

**Called by:**
- `report` (1)

**Calls:**
- `inspectOwnedSvgOnce` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1131` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `receiptOf` (1)

**Calls:**
- `canonicalJson` (1)

### `nativeOrEmulated`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:448` | Self: 0.0% (0us) | Total: 0.1% (2.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `drawn` (1)

### `applyOutputSecurityPolicy`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:727` | Self: 0.0% (0us) | Total: 2.6% (41.2ms) | Samples: 0

**Called by:**
- `measureRenderStage` (22)
- `validateSceneDocument` (2)

**Calls:**
- `inspectOwnedSvgOnce` (24)

### `lowerErDrawing`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:123` | Self: 0.0% (0us) | Total: 2.7% (42.5ms) | Samples: 0

**Called by:**
- `withDeferredTerminalProjections` (26)

**Calls:**
- `leaf` (21)
- `connector` (5)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:548` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Calls:**
- `registerBuiltInStyle` (1)

### `Zlib`
`node:zlib:298` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `Gzip` (1)

**Calls:**
- `ZlibBase` (1)

### `preparePixelText`
`/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts:405` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `measureErEntities` (1)

**Calls:**
- `styledRunLayout` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/positioning.ts:123` | Self: 0.0% (0us) | Total: 7.9% (122.4ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (73)

**Calls:**
- `withGraphLayoutDecisionObserver` (73)

### `measureErEntities`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:453` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `layoutErDiagram` (1)

**Calls:**
- `preparePixelText` (1)

### `prepareMarkerTerminals`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:9` | Self: 0.0% (0us) | Total: 0.7% (11.4ms) | Samples: 0

**Called by:**
- `(module)` (2)
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)
- `(module)` (1)

**Calls:**
- `map` (6)

### `hasOwned`
`/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts:11` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `copy` (1)

**Calls:**
- `has` (1)

### `normalizeMermaidSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:663` | Self: 0.0% (0us) | Total: 0.0% (1.5ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `mermaidFirstLine` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1491` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `segmentThroughShape` (1)

### `node`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1453` | Self: 0.0% (0us) | Total: 0.9% (14.8ms) | Samples: 0

**Called by:**
- `group` (9)

**Calls:**
- `validateNode` (8)
- `validateNode` (1)

### `admitRenderContractDigestInput`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1150` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `renderContractDigest` (1)

**Calls:**
- `boundedImmutableJsonSnapshot` (1)

### `finishErGeometry`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1328` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `nativeCandidate` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `verifyDocumentEnvelope`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:343` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `xmlTokenAt` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/c4/config.ts:91` | Self: 0.0% (0us) | Total: 0.1% (2.9ms) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:26` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Calls:**
- `(anonymous)` (3)

### `collectNativeGroup`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:146` | Self: 0.0% (0us) | Total: 0.5% (9.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (6)

**Calls:**
- `visitSvgStartTagsFresh` (6)

### `readXmlNameEnd`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:102` | Self: 0.0% (0us) | Total: 0.1% (1.6ms) | Samples: 0

**Called by:**
- `verifyDocumentEnvelope` (1)

**Calls:**
- `xmlAsciiLetter` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:168` | Self: 0.0% (0us) | Total: 0.2% (4.4ms) | Samples: 0

**Calls:**
- `WeakSet` (1)

### `connectorInlineLabelText`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:427` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `connectorInlineLabelSvg` (1)

**Calls:**
- `preparePixelText` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts:230` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `transferSceneNodeSerialization` (1)

### `inspectSecurityTail`
`/tmp/pr449-main-integration-20261029-762/src/output-security.ts:691` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `inspectOwnedSvgOnce` (1)

**Calls:**
- `test` (1)

### `certifyNativePaint`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:1502` | Self: 0.0% (0us) | Total: 1.9% (30.8ms) | Samples: 0

**Called by:**
- `positionedPaintCertification` (16)

**Calls:**
- `solidInteriors` (3)
- `solidInteriors` (3)
- `solidInteriors` (2)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)
- `solidInteriors` (1)

### `observe`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:626` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `visit` (1)

**Calls:**
- `invalidateFractionalCircle` (1)

### `setConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts:53` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Called by:**
- `connector` (2)

**Calls:**
- `deriveConnectorTerminalProjection` (1)
- `deriveConnectorTerminalProjection` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/marker-terminals.ts:11` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `markerTerminalDepth` (1)

### `frozenRoleStyles`
`/tmp/pr449-main-integration-20261029-762/src/scene/style-registry.ts:173` | Self: 0.0% (0us) | Total: 0.1% (2.9ms) | Samples: 0

**Called by:**
- `registerCanonicalStyle` (1)

**Calls:**
- `fromEntries` (1)

### `visit`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:92` | Self: 0.0% (0us) | Total: 0.3% (4.6ms) | Samples: 0

**Called by:**
- `inspectPaint` (3)

**Calls:**
- `observe` (1)
- `observe` (1)
- `observe` (1)

### `set`
`/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts:87` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `ensureSvgIdentity` (1)

**Calls:**
- `test` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/Schema.js:7` | Self: 0.0% (0us) | Total: 0.7% (11.7ms) | Samples: 0

**Called by:**
- `anonymous` (4)

**Calls:**
- `bound require` (4)

### `tree`
`/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts:79` | Self: 0.0% (0us) | Total: 0.8% (12.5ms) | Samples: 0

**Called by:**
- `certifyNativePaint` (4)

**Calls:**
- `retainOrder` (2)
- `retainOrder` (2)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:611` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `map` (1)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1572` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `renderContractDigest` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:15` | Self: 0.0% (0us) | Total: 0.1% (2.6ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:1106` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `write` (1)

**Calls:**
- `numericCss` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:208` | Self: 0.0% (0us) | Total: 5.0% (78.2ms) | Samples: 0

**Calls:**
- `expandLocalReferences` (6)
- `(anonymous)` (1)

### `renderResolvedMermaidSVG`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:270` | Self: 0.0% (0us) | Total: 8.1% (126.4ms) | Samples: 0

**Called by:**
- `consumeResolvedGraphicalRequest` (76)

**Calls:**
- `measureRenderStage` (76)

### `readErStatements`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:739` | Self: 0.0% (0us) | Total: 0.2% (4.3ms) | Samples: 0

**Called by:**
- `parseErDiagram` (2)

**Calls:**
- `findErStatements` (2)

### `registerBuiltInBackend`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts:470` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `freezeBuiltInBackend` (1)

### `copy`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:213` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `copyInner` (1)

**Calls:**
- `hasOwned` (1)

### `node:stream`
`node:stream:2` | Self: 0.0% (0us) | Total: 2.1% (32.7ms) | Samples: 0

**Called by:**
- `anonymous` (14)

**Calls:**
- `anonymous` (14)

### `internal:primordials`
`internal:primordials:76` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeSafe` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:37` | Self: 0.0% (0us) | Total: 0.7% (12.0ms) | Samples: 0

**Called by:**
- `build` (5)
- `(anonymous)` (2)
- `tree` (2)

**Calls:**
- `build` (5)
- `build` (2)
- `build` (1)
- `build` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/resource-manifest.ts:64` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `Set` (1)

### `connector/interaction/hit-test`
`/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts:870` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `hitsTransformed` (1)

### `assessRenderedLayoutHardViolations`
`/tmp/pr449-main-integration-20261029-762/src/family-rubric.ts:211` | Self: 0.0% (0us) | Total: 0.1% (1.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `assessFamilyLayout` (1)

### `markerBoundsAt`
`/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:245` | Self: 0.0% (0us) | Total: 0.1% (1.9ms) | Samples: 0

**Called by:**
- `markerTerminalDepth` (1)

**Calls:**
- `paintedStrokeExtent` (1)

### `validateNode`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:941` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `validateSceneDocument` (1)

**Calls:**
- `validateMarker` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/doc/Document.js:9` | Self: 0.0% (0us) | Total: 0.1% (1.8ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/tags.js:16` | Self: 0.0% (0us) | Total: 0.2% (4.1ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `bound require` (2)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:283` | Self: 0.0% (0us) | Total: 1.4% (22.2ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (16)

**Calls:**
- `leaf` (15)
- `text` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:36` | Self: 0.0% (0us) | Total: 0.4% (6.7ms) | Samples: 0

**Calls:**
- `writeFileSync` (1)
- `gzipSync` (1)
- `zlibBufferSync` (1)

### `internal:stream`
`internal:stream:46` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `extractErLayout`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:582` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `finish` (1)

**Calls:**
- `erFrameInkPadding` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:346` | Self: 0.0% (0us) | Total: 0.2% (3.8ms) | Samples: 0

**Called by:**
- `connector` (2)
- `createFixture` (1)

**Calls:**
- `connectorContourSemantics` (2)
- `connectorContourSemantics` (1)

### `positionedPaintCertification`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:154` | Self: 0.0% (0us) | Total: 3.9% (61.3ms) | Samples: 0

**Called by:**
- `measureRenderStage` (31)

**Calls:**
- `certifyNativePaint` (16)
- `certifyNativePaint` (6)
- `certifyNativePaint` (3)
- `certifyNativePaint` (3)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)
- `certifyNativePaint` (1)

### `(anonymous)`
`[native code]` | Self: 0.0% (0us) | Total: 0.2% (3.3ms) | Samples: 0

**Called by:**
- `(module)` (3)

**Calls:**
- `get WriteStream` (2)
- `WriteStream` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/schema/common/map.js:4` | Self: 0.0% (0us) | Total: 0.7% (11.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `bound require` (1)

### `(module)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:255` | Self: 0.0% (0us) | Total: 0.1% (1.5ms) | Samples: 0

**Calls:**
- `deepFreeze` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:45` | Self: 0.0% (0us) | Total: 6.0% (94.3ms) | Samples: 0

**Calls:**
- `gc` (56)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:191` | Self: 0.0% (0us) | Total: 0.4% (6.6ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `styleSpecJsonSchema` (1)

### `resolveRenderRequestForExecution`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1765` | Self: 0.0% (0us) | Total: 0.1% (2.3ms) | Samples: 0

**Called by:**
- `measureRenderStage` (2)

**Calls:**
- `resolveAppearance` (1)
- `resolveAppearance` (1)

### `node:zlib`
`node:zlib:159` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Calls:**
- `ArrayBuffer` (1)

### `forEach`
`[native code]` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `connectorMarkerPaintRegions` (1)

**Calls:**
- `include` (1)

### `connector`
`/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts:315` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `connector` (1)

**Calls:**
- `assertMarkAttributes` (1)

### `colorResolution`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:701` | Self: 0.0% (0us) | Total: 0.7% (11.4ms) | Samples: 0

**Called by:**
- `inlineResolvedColors` (7)

**Calls:**
- `projectSvgCss` (7)

### `deriveConnectorTerminalProjection`
`/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts:108` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `setConnectorTerminalProjection` (1)

**Calls:**
- `connectorEndpointMarkerAnchors` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:49` | Self: 0.0% (0us) | Total: 1.0% (16.5ms) | Samples: 0

**Called by:**
- `join` (9)

**Calls:**
- `indent` (7)
- `indent` (2)

### `resolveExecutionPlan`
`/tmp/pr449-main-integration-20261029-762/src/render-contract.ts:1485` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `resolveRenderRequestForExecution` (1)

**Calls:**
- `requiredBackendCapabilities` (1)

### `erFrameInkPadding`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:767` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `extractErLayout` (1)

**Calls:**
- `resolveRoleStyle` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:10` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Calls:**
- `importModule` (1)

### `groupValidation`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts:506` | Self: 0.0% (0us) | Total: 0.8% (13.4ms) | Samples: 0

**Called by:**
- `validateNode` (8)

**Calls:**
- `captureNativeGroupEmission` (8)

### `resolvedColorValue`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:599` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `toneOnFill` (1)

**Calls:**
- `match` (1)

### `renderEntityBox`
`/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts:228` | Self: 0.0% (0us) | Total: 0.7% (11.7ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (8)

**Calls:**
- `leaf` (6)
- `shape` (2)

### `renderPositionedWithTextMeasurement`
`/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts:237` | Self: 0.0% (0us) | Total: 0.5% (8.8ms) | Samples: 0

**Called by:**
- `withTextMeasurementExecution` (8)

**Calls:**
- `scopeSvgStyles` (3)
- `scopeSvgStyles` (2)
- `scopeSvgStyles` (2)
- `scopeSvgStyles` (1)

### `withSvgInspectionCache`
`/tmp/pr449-main-integration-20261029-762/src/svg-inspection-cache.ts:20` | Self: 0.0% (0us) | Total: 38.5% (596.3ms) | Samples: 0

**Called by:**
- `withRenderStageObserver` (372)

**Calls:**
- `consumeResolvedGraphicalRequest` (357)
- `executeInspectedGraphicalRequest` (14)
- `graphicalSvgArtifact` (1)

### `emissionRecord`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:75` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Called by:**
- `registerGroupEmission` (1)

**Calls:**
- `defineProperties` (1)

### `sceneRoleTraits`
`/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts:219` | Self: 0.0% (0us) | Total: 0.1% (2.2ms) | Samples: 0

**Called by:**
- `relationAccessibility` (1)

**Calls:**
- `resolveSceneRoleTraits` (1)

### `resolveCss`
`/tmp/pr449-main-integration-20261029-762/src/theme.ts:736` | Self: 0.0% (0us) | Total: 0.2% (3.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `replace` (1)

### `(module)`
`/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts:4` | Self: 0.0% (0us) | Total: 0.1% (2.4ms) | Samples: 0

**Calls:**
- `readFileSync` (1)

### `registerGroupEmission`
`/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts:87` | Self: 0.0% (0us) | Total: 0.2% (3.7ms) | Samples: 0

**Called by:**
- `group` (1)

**Calls:**
- `emissionRecord` (1)

### `retainedNativeDrawing`
`/tmp/pr449-main-integration-20261029-762/src/scene/positioned.ts:140` | Self: 0.0% (0us) | Total: 17.2% (267.5ms) | Samples: 0

**Called by:**
- `measureRenderStage` (175)

**Calls:**
- `withTextMeasurementExecution` (175)

### `mixHex`
`/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts:52` | Self: 0.0% (0us) | Total: 0.2% (3.6ms) | Samples: 0

**Called by:**
- `replace` (1)

**Calls:**
- `mixedChannels` (1)

### `build`
`/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts:36` | Self: 0.0% (0us) | Total: 0.0% (1.4ms) | Samples: 0

**Called by:**
- `build` (1)

**Calls:**
- `floor` (1)

### `renderMultilineText`
`/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts:275` | Self: 0.0% (0us) | Total: 0.0% (1.3ms) | Samples: 0

**Called by:**
- `writeTextSvg` (1)

**Calls:**
- `renderPreparedLine` (1)

### `validatePoint`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts:435` | Self: 0.0% (0us) | Total: 0.1% (2.7ms) | Samples: 0

**Called by:**
- `validateNode` (1)

**Calls:**
- `finite` (1)

### `parseErDiagram`
`/tmp/pr449-main-integration-20261029-762/src/er/parser.ts:898` | Self: 0.0% (0us) | Total: 0.2% (4.5ms) | Samples: 0

**Called by:**
- `layout` (3)

**Calls:**
- `relationshipFrom` (3)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1742` | Self: 0.0% (0us) | Total: 0.1% (2.0ms) | Samples: 0

**Called by:**
- `find` (1)

**Calls:**
- `validSceneRoleDeclaration` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js:16` | Self: 0.0% (0us) | Total: 0.3% (5.8ms) | Samples: 0

**Calls:**
- `bound require` (1)

### `validateDescriptor`
`/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts:1782` | Self: 0.0% (0us) | Total: 0.2% (4.3ms) | Samples: 0

**Called by:**
- `installBuiltinFamily` (1)

**Calls:**
- `trim` (1)

### `(anonymous)`
`/tmp/pr449-main-integration-20261029-762/src/er/layout.ts:1188` | Self: 0.0% (0us) | Total: 2.7% (43.2ms) | Samples: 0

**Called by:**
- `nativeCandidate` (23)

**Calls:**
- `nativePlacement` (15)
- `nativePlacement` (3)
- `nativePlacement` (2)
- `nativePlacement` (1)
- `nativePlacement` (1)
- `nativePlacement` (1)

### `layoutLayeredGraph`
`/tmp/pr449-main-integration-20261029-762/src/layout/agentic-producer-core.ts:95` | Self: 0.0% (0us) | Total: 0.2% (4.0ms) | Samples: 0

**Called by:**
- `measureRenderStage` (1)

**Calls:**
- `finalizeFlatMeasuredMarkers` (1)

### `leaf`
`/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts:118` | Self: 0.0% (0us) | Total: 7.3% (113.5ms) | Samples: 0

**Called by:**
- `lowerErDrawing` (21)
- `renderEntityBox` (15)
- `renderEntityBox` (13)
- `crowsFootMark` (7)
- `renderEntityBox` (6)
- `renderEntityBox` (5)
- `renderRelationshipLabel` (4)
- `lowerErDrawing` (1)
- `renderEntityBox` (1)
- `renderRelationshipLabel` (1)

**Calls:**
- `leaf` (43)
- `leaf` (26)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)
- `leaf` (1)

### `assertAdmissibleSceneDoc`
`/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation.ts:247` | Self: 0.0% (0us) | Total: 0.7% (11.7ms) | Samples: 0

**Called by:**
- `admitSceneDocumentWith` (9)

**Calls:**
- `validateSceneDocument` (7)
- `validateSceneDocument` (2)

### `normalizeSource`
`/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts:697` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `normalizeMermaidSourceWithOverrides` (1)

**Calls:**
- `installedFamilyStatementEnds` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 48.7% | 753.6ms | `[native code]` |
| 6.7% | 105.0ms | `/tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js` |
| 5.5% | 85.1ms | `/tmp/pr449-main-integration-20261029-762/src/render-contract.ts` |
| 3.0% | 47.9ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/decode-shared.js` |
| 2.7% | 42.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts` |
| 2.2% | 34.6ms | `/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts` |
| 2.0% | 32.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts` |
| 2.0% | 31.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts` |
| 1.8% | 28.2ms | `/tmp/pr449-main-integration-20261029-762/src/output-security.ts` |
| 1.6% | 25.9ms | `/tmp/pr449-main-integration-20261029-762/src/er/layout.ts` |
| 1.4% | 22.9ms | `/tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts` |
| 1.4% | 21.7ms | `/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts` |
| 1.1% | 17.6ms | `/tmp/pr449-main-integration-20261029-762/src/layout/agentic-layered-core.ts` |
| 1.0% | 16.8ms | `/tmp/pr449-main-integration-20261029-762/src/agent/family-registry.ts` |
| 1.0% | 16.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts` |
| 0.9% | 14.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts` |
| 0.7% | 12.1ms | `/tmp/pr449-main-integration-20261029-762/src/shared/xml-name.ts` |
| 0.7% | 11.5ms | `/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts` |
| 0.7% | 11.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts` |
| 0.7% | 11.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/style-spec.ts` |
| 0.7% | 11.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts` |
| 0.6% | 10.5ms | `/tmp/pr449-main-integration-20261029-762/src/shared/color-math.ts` |
| 0.6% | 9.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/emission-context.ts` |
| 0.5% | 8.0ms | `/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts` |
| 0.5% | 7.7ms | `/tmp/pr449-main-integration-20261029-762/src/er/renderer.ts` |
| 0.4% | 7.1ms | `/tmp/pr449-main-integration-20261029-762/src/scene/roles.ts` |
| 0.4% | 6.9ms | `/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts` |
| 0.3% | 6.1ms | `/tmp/pr449-main-integration-20261029-762/src/shared/svg-number.ts` |
| 0.3% | 5.8ms | `/tmp/pr449-main-integration-20261029-762/src/shared/deterministic-order.ts` |
| 0.3% | 5.7ms | `/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts` |
| 0.3% | 5.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-geometry.ts` |
| 0.2% | 4.6ms | `/tmp/pr449-main-integration-20261029-762/src/theme.ts` |
| 0.2% | 4.5ms | `/tmp/pr449-main-integration-20261029-762/src/scene/backend-conformance.ts` |
| 0.2% | 4.3ms | `/tmp/pr449-main-integration-20261029-762/src/svg-style-scope.ts` |
| 0.2% | 4.2ms | `/tmp/pr449-main-integration-20261029-762/src/multiline-utils.ts` |
| 0.2% | 4.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/gradient-resources.ts` |
| 0.2% | 4.0ms | `/tmp/pr449-main-integration-20261029-762/src/layout/compound-boundary-routes.ts` |
| 0.2% | 3.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/css-color.ts` |
| 0.2% | 3.2ms | `/tmp/pr449-main-integration-20261029-762/src/er/creation.ts` |
| 0.1% | 3.0ms | `/tmp/pr449-main-integration-20261029-762/src/graphical-render.ts` |
| 0.1% | 3.0ms | `/tmp/pr449-main-integration-20261029-762/src/layout/shared-fan-core.ts` |
| 0.1% | 2.9ms | `/tmp/pr449-main-integration-20261029-762/src/c4/config.ts` |
| 0.1% | 2.7ms | `/tmp/pr449-main-integration-20261029-762/src/class/relationship-paint.ts` |
| 0.1% | 2.6ms | `/tmp/pr449-main-integration-20261029-762/src/er/text.ts` |
| 0.1% | 2.4ms | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts` |
| 0.1% | 2.4ms | `/tmp/pr449-main-integration-20261029-762/src/shared/text-controls.ts` |
| 0.1% | 2.3ms | `/tmp/pr449-week-comparison-20261101/er-glyph-profile-3e43badc5/worker.ts` |
| 0.1% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/layout/backend.ts` |
| 0.1% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts` |
| 0.1% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/extension-identity.ts` |
| 0.1% | 2.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/deferred-terminal-projection.ts` |
| 0.1% | 2.2ms | `/tmp/pr449-main-integration-20261029-762/src/sequence/parser.ts` |
| 0.1% | 2.2ms | `/tmp/pr449-main-integration-20261029-762/src/ascii/terminal-document.ts` |
| 0.1% | 2.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/identity.ts` |
| 0.1% | 2.1ms | `/tmp/pr449-main-integration-20261029-762/src/er/parser.ts` |
| 0.1% | 2.0ms | `/tmp/pr449-main-integration-20261029-762/src/shared/css-named-colors.ts` |
| 0.1% | 2.0ms | `/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts` |
| 0.1% | 1.9ms | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-array/dist/d3-array.js` |
| 0.1% | 1.8ms | `/tmp/pr449-main-integration-20261029-762/src/graph-connectors.ts` |
| 0.1% | 1.7ms | `/tmp/pr449-main-integration-20261029-762/src/layout/shorten-measured-routes.ts` |
| 0.1% | 1.6ms | `/tmp/pr449-main-integration-20261029-762/src/shared/config-value-rules.ts` |
| 0.1% | 1.5ms | `/tmp/pr449-main-integration-20261029-762/src/shared/plain-data.ts` |
| 0.0% | 1.5ms | `/tmp/pr449-main-integration-20261029-762/src/render-output-metadata.ts` |
| 0.0% | 1.5ms | `/tmp/pr449-main-integration-20261029-762/src/mermaid-source-wrapper.ts` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/shared/immutable-parts.ts` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/layout/measured-forest.ts` |
| 0.0% | 1.4ms | `/tmp/pr449-main-integration-20261029-762/src/scene/assertions.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/display-text.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/shared/builtin-family-detection.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/src/scene/hit-test.ts` |
| 0.0% | 1.3ms | `/tmp/pr449-main-integration-20261029-762/node_modules/d3-shape/dist/d3-shape.js` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/connector-terminal.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/capability-negotiation.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/scene-data-snapshot.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/shared/style-props.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/shared/schema-validation.ts` |
| 0.0% | 1.2ms | `/tmp/pr449-main-integration-20261029-762/src/scene/capabilities.ts` |
| 0.0% | 1.2ms | `node:fs` |
| 0.0% | 1.2ms | `internal:primordials` |
| 0.0% | 1.1ms | `bun:main` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/node_modules/yaml/dist/index.js` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/experimental/weighted-lru.ts` |
| 0.0% | 1.1ms | `/tmp/pr449-main-integration-20261029-762/src/positioned-views/er.ts` |
| 0.0% | 1.1ms | `internal:streams/transform` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/node_modules/entities/dist/esm/internal/encode-shared.js` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/agent/family-router.ts` |
| 0.0% | 1.0ms | `internal:fs/streams` |
| 0.0% | 1.0ms | `/tmp/pr449-main-integration-20261029-762/src/shared/utf8.ts` |
| 0.0% | 994us | `/tmp/pr449-main-integration-20261029-762/src/color-resolver.ts` |
| 0.0% | 943us | `/tmp/pr449-main-integration-20261029-762/src/scene/written-geometry.ts` |
