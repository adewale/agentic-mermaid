import fs from 'node:fs'
Bun.plugin({name:'baseline08336-producer',setup(build){build.onLoad({filter:/\/src\/layout\/agentic-producer-core\.ts$/},()=>({contents:fs.readFileSync('/tmp/pr449-week-comparison-20261101/cyclic15-19-b063/producer-before.ts','utf8'),loader:'ts'}))}})
