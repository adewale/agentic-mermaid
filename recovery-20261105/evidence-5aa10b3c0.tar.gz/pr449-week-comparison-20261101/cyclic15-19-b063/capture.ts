import {writeFileSync,readFileSync} from 'node:fs'
import {gzipSync,gunzipSync} from 'node:zlib'
import assert from 'node:assert/strict'
const root='/tmp/pr449-main-integration-20261029-762',dir='/tmp/pr449-week-comparison-20261101/cyclic15-19-b063',arm=Bun.argv[2]
const {snapshotSample}=await import(root+'/eval/layout-compare/run.ts')
for(const file of ['cyclic-labelled-15-chains.mmd','cyclic-labelled-19.mmd'])for(const backend of ['agentic','elk'] as const){
 const source=readFileSync(root+'/eval/layout-compare/fixtures/'+file,'utf8')
 const retained=JSON.parse(gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/requirement-cycle-25e/before-'+file+'-'+backend+'.json.gz')).toString())
 assert.equal(source,retained.source)
 const options={graphLayout:{backend,fallback:'none' as const},embedFontImport:false}
 const value=snapshotSample({id:file,family:'flowchart',source},'cycle-check-',options,{includeAscii:false})
 const serialized=JSON.stringify(value),stem=`${dir}/${arm}-${file}-${backend}`
 writeFileSync(stem+'.json.gz',gzipSync(serialized))
 if(value.svg)writeFileSync(stem+'.svg.gz',gzipSync(value.svg))
 console.log(JSON.stringify({arm,file,backend,publicLayoutCalls:1,publicSvgCalls:1,fullyConsumedBytes:Buffer.byteLength(serialized),options,ok:value.ok,failures:value.failures,proof:value.svgReceipt?.layoutCertification,geometry:value.metrics?.routeGeometry,crossings:value.metrics?.edgeCrossings,labelConflicts:value.metrics?.labelConflicts,routeOverlaps:value.metrics?.routeOverlaps,svgDimensions:value.svg?.match(/<svg[^>]*>/)?.[0]}))
}
