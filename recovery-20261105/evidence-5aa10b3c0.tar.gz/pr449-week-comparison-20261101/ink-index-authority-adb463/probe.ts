import fs from 'node:fs'
const dir='/tmp/pr449-week-comparison-20261101/ink-index-authority-adb463'
const results:any[]=[]
for(const mode of ['original','skip-parent-axis']){
  const {buildInkTree}=await import(`${dir}/${mode}.ts`)
  for(const adverse of [false,true]){
    const items=Array.from({length:32},(_,id)=>({id,box:{x0:id,y0:0,x1:id+1,y1:1}}))
    let reads=0,chargeCalls=0,charged=0,branchReads=0,inChild=false,error:any,tree:any
    const bounds=(item:typeof items[number])=>{
      reads++
      if(inChild&&++branchReads>16&&adverse)throw new Error('repeated bounds observation in 16-row branch')
      return item.box
    }
    const charge=(count=1)=>{
      chargeCalls++;charged+=count
      if(count===17){inChild=true;branchReads=0}
      else if(count===9)inChild=false
    }
    try{tree=buildInkTree(items,bounds,charge)}catch(e:any){error={name:e.name,message:e.message}}
    const leaves=(n:any):number[]=>n?.leaves?n.leaves.map((r:any)=>r.id):n?[...leaves(n.left),...leaves(n.right)]:[]
    const row={mode,adverse,reads,chargeCalls,charged,error:error??null,leaves:leaves(tree)}
    results.push(row);console.log(JSON.stringify(row))
  }
  const items=Array.from({length:32},(_,id)=>({id,box:{x0:id,y0:0,x1:id+1,y1:1}}))
  const originalSlice=Object.getOwnPropertyDescriptor(Array.prototype,'slice')!
  let sliceMutations=0,tree:any
  try{
    Object.defineProperty(Array.prototype,'slice',{...originalSlice,value:function(this:typeof items,start?:number,end?:number){
      if(this.length===32&&start===0&&end===16&&this[0]?.id===0&&!sliceMutations){
        sliceMutations++;this[0]!.box.x0=14.5;this[0]!.box.x1=15.5
      }
      return Reflect.apply(originalSlice.value,this,[start,end])
    }})
    tree=buildInkTree(items,item=>item.box,()=>{})
  }finally{Object.defineProperty(Array.prototype,'slice',originalSlice)}
  const leaves=(n:any):number[]=>n?.leaves?n.leaves.map((r:any)=>r.id):n?[...leaves(n.left),...leaves(n.right)]:[]
  const row={mode,adverse:'ambient-slice-mutates-owned-box',sliceMutations,leaves:leaves(tree),expectedCoordinateOrder:[...Array.from({length:14},(_,i)=>i+1),0,...Array.from({length:17},(_,i)=>i+15)]}
  results.push(row);console.log(JSON.stringify(row))
}
fs.writeFileSync(`${dir}/RESULTS.json`,JSON.stringify({base:'adb4633a0',purpose:'Constant numeric coordinates do not make caller-owned generic bounds/charge callbacks inert; this prototype is evidence only and must not ship.',results},null,2))
