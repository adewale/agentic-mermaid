from pathlib import Path
import re,json
root=Path('/tmp/pr449-main-integration-20261029-762');out=Path('/tmp/pr449-week-comparison-20261101/sparse32-capture-ledger-f1e');out.mkdir(exist_ok=True)

def constscope(s,name,label,start,end):
 pattern=r'(^  const '+name+r'\b[^\n]*=> \{\n)([\s\S]*?)(^  \})(?=\n  (?:const|return))'
 matches=[m for m in re.finditer(pattern,s,re.M) if start < m.start() < end]
 assert len(matches)==1,(name,len(matches))
 m=matches[0];return s[:m.start()]+m.group(1)+'    return observedScope('+label+', () => {\n'+m.group(2)+'    })\n'+m.group(3)+s[m.end():]
def methodscope(s,name,label,extra=''):
 pattern=r'(^    '+name+r'(?:<[^\n]+>)?\([^\n]*\)[^\n]* \{\n)([\s\S]*?)(^    \},)'
 matches=list(re.finditer(pattern,s,re.M));assert len(matches)==1,(name,len(matches))
 m=matches[0]
 return s[:m.start()]+m.group(1)+'      return observedScope('+repr(label)+', () => {\n'+m.group(2)+'      }'+extra+')\n'+m.group(3)+s[m.end():]

s=(root/'src/scene/native-paint-emission.ts').read_text();(out/'native-paint-emission.original.ts').write_text(s)
s="const observedNativeLedgers: any[] = []\nexport function readObservedNativeLedgers() { return observedNativeLedgers }\nexport function markObservedNativePhase(phase: string) { observedNativeLedgers[observedNativeLedgers.length - 1]?.mark(phase) }\n"+s
needle='  const pay = (count = 1): boolean => {\n    if (exhausted) return false\n    if (!Number.isSafeInteger(count) || count < 0 || count > maxOperations - operations) { exhausted = true; return false }\n    operations += count\n    return true\n  }'
assert s.count(needle)==1
s=s.replace(needle,'''  let observedPhase = 'produce', observedLabel = 'other'
  const ledger: any = { categories: {}, scopes: {}, landmarks: [] }
  ledger.mark = (phase: string) => { observedPhase = phase; ledger.landmarks.push({ phase, operations, exhausted, uncertain }) }
  observedNativeLedgers.push(ledger)
  const observedScope = <T>(label: string, action: () => T): T => {
    const prior = observedLabel; observedLabel = label
    ledger.scopes[label] = (ledger.scopes[label] ?? 0) + 1
    try { return action() } finally { observedLabel = prior }
  }
  const pay = (count = 1): boolean => {
    const key = observedPhase + ':' + observedLabel
    const category = ledger.categories[key] ??= { calls: 0, accepted: 0, failedCalls: 0, failedRequested: 0 }; category.calls++
    if (exhausted) { category.failedCalls++; category.failedRequested += count; return false }
    if (!Number.isSafeInteger(count) || count < 0 || count > maxOperations - operations) {
      category.failedCalls++; category.failedRequested += count
      ledger.firstExhaustion ??= { phase: observedPhase, scope: observedLabel, count, operations, remaining: maxOperations - operations, stack: new Error('First rejected Native pay').stack }
      exhausted = true; return false
    }
    category.accepted += count
    operations += count
    return true
  }''')
s=s.replace("  const context = createEmissionContext(pay, { resources: false })","  const context = createEmissionContext(count => observedScope('emission-context', () => pay(count)), { resources: false })")
s=s.replace('  const xml = createSvgXmlCapture(pay)',"  const xml = createSvgXmlCapture(count => observedScope('xml-capture', () => pay(count)))")
for name in ['materializeText','copyInner']:
 label=repr(name)+( " + ':' + String(context)" if name in ['copy','copyInner'] else '')
 s=constscope(s,name,label,s.index('export function createNativePaintEmission('),s.index('\n  return {\n    xml,'))
for name in []:
 s=methodscope(s,name,'method:'+name)
# Finish substage boundaries use existing private locals and operation counter only.
for old,label in [('      const checkedContext = context.finish(header)','finish-context'),('      if (hasMarkedConnector) {\n        const verified','finish-xml-envelope'),('      const actualPaintRoster = ownedTextPaintRoster(inspection)','finish-occurrence-closure')]:
 assert s.count(old)==1
 s=s.replace(old,'      ledger.mark('+repr(label)+')\n'+old)
needle='      textPaintApply(textPaintPut, emissionWork, [inspection,'
assert s.count(needle)==1
s=s.replace(needle,"      ledger.mark('finish-complete')\n      ledger.finalState = { operations, exhausted, uncertain, closedMarkerContext, definitionsClosed, rootOpens, rootCloses, hasMarkedConnector, usedTextPaint }\n"+needle)
(out/'native-paint-emission.overlay.ts').write_text(s)

s=(root/'src/scene/emission-context.ts').read_text();(out/'emission-context.original.ts').write_text(s)
s="const observedContextLedgers: any[] = []\nexport function readObservedContextLedgers() { return observedContextLedgers }\n"+s
needle='  const reserve = (count: number): boolean => {\n    if (finished || !Number.isSafeInteger(count) || count < 0 || !pay(count)) { uncertain = true; return false }\n    return true\n  }'
assert s.count(needle)==1
s=s.replace(needle,'''  let observedLabel = 'other'
  const contextLedger: any = { categories: {}, scopes: {}, visits: {} }; observedContextLedgers.push(contextLedger)
  const observedScope = <T>(label: string, action: () => T): T => {
    const prior = observedLabel; observedLabel = label
    contextLedger.scopes[label] = (contextLedger.scopes[label] ?? 0) + 1
    try { return action() } finally { observedLabel = prior }
  }
  const reserve = (count: number): boolean => {
    const category = contextLedger.categories[observedLabel] ??= { calls: 0, accepted: 0, failedCalls: 0, failedRequested: 0 }; category.calls++
    if (finished || !Number.isSafeInteger(count) || count < 0 || !pay(count)) { category.failedCalls++; category.failedRequested += count; uncertain = true; return false }
    category.accepted += count
    return true
  }''')
for name in []:
 s=constscope(s,name,repr(name),s.index('export function createEmissionContext('),s.index('\n  return {\n    requireTextPaintContext'))
for name in []:
 s=methodscope(s,name,'method:'+name)
# No context method wrappers.
# Capture states just before original return freeze; this is the only normal non-early marker context completion.
old='      const freeze = options.pageUnderlay || hasTextPaintContext ? emissionContextFreeze : Object.freeze\n      return freeze({ uncertain,'
assert s.count(old)==1
s=s.replace(old,"      contextLedger.finalState = { uncertain, finished, fractionalCircleContext, hasMarkedConnector, hasTextPaintContext, hasRingConnector, roots, canonicalStyles, documentPosition, needsVariables, needsDerivedVariables }\n"+old)
for old,key in [('      for (const { node, svg } of documents) {','documents'),('      if (hasRingConnector && fractionalCircleContext) for (const { node, svg } of leaves) {','ringLeaves'),('      if (hasRingConnector && fractionalCircleContext) for (const text of texts) {','ringTexts'),('        for (const marker of references) {','resourceReferences')]:
 assert s.count(old)==1,(key,s.count(old))
 s=s.replace(old,old+"\n        contextLedger.visits['"+key+"'] = (contextLedger.visits['"+key+"'] ?? 0) + 1")
# Count only an existing taken text branch; no extra kind/field observation.
old="      if (node.kind === 'text') texts.push({ node, svg })"
assert s.count(old)==1
s=s.replace(old,"      if (node.kind === 'text') { contextLedger.visits.textsCollected = (contextLedger.visits.textsCollected ?? 0) + 1; texts.push({ node, svg }) }")
(out/'emission-context.overlay.ts').write_text(s)

s=(root/'src/scene/native-drawing.ts').read_text();(out/'native-drawing.original.ts').write_text(s)
s="import { markObservedNativePhase } from './native-paint-emission.ts'\n"+s
for old,label in [('  const document: DrawingDocument<Fragment> =','after-produce'),('  const capturedHeader = emittedHeader','after-composition'),('  const paint = inspectPaint','before-inspection'),('  emission.finish(paint,','before-finish'),('  return Object.freeze({ svg, header:','draw-complete')]:
 assert s.count(old)==1,(old,s.count(old))
 if label=='after-produce':
  line=next(t for t in s.splitlines() if t.startswith(old));s=s.replace(line,line+"\n  markObservedNativePhase('after-produce')")
 else:s=s.replace(old,"  markObservedNativePhase('"+label+"')\n"+old)
(out/'native-drawing.overlay.ts').write_text(s)
(out/'SETUP.json').write_text(json.dumps({'head':'f1e23e62fc30269827cef9765e70b67bd2d83296','authorizedDrawNativeCalls':1,'certifyNativeCalls':1,'publicSvgCalls':0,'sceneCalls':0,'productionEdits':0,'overlayModules':['native-drawing.ts','native-paint-emission.ts','emission-context.ts'],'fixture':'Exact sparse decorative markers existing owner32 producer; same literal header/colors/fonts/1500texts/32chrome carriers; no rootstyle added','method':'Private numeric pay/reserve accepted/failed counters + phase landmarks/scopes; original fees/limits/branches/getters retained'},indent=2)+'\n')
print('prepared 3 observational overlays; 0 calls so far')
