# Offline only. Reuses the retained er-next/authority-svg.ts attribute/point,
# emitted terminal-normal and body/foreign-stroke contact calculations for Class.
# Crossings use the repository's shared countPolylineCrossings separately.
import gzip,json,pathlib,xml.etree.ElementTree as E,math,hashlib
p=pathlib.Path(__file__).parent
results=json.loads(gzip.decompress((p/'RESULTS.json.gz').read_bytes()))
ns={'s':'http://www.w3.org/2000/svg'}
rows=[]
for backend in ['agentic','elk']:
 run=next(x for x in results['runs'] if x['count']=='class128LR' and x['arm']=='after' and x['backend']==backend)
 raw=gzip.decompress((p/f'class128LR-{backend}-after-cold.svg.gz').read_bytes());root=E.fromstring(raw)
 receipt=json.loads(gzip.decompress((p/f'class128LR-{backend}-after-cold.receipt.json.gz').read_bytes()))
 cards=root.findall('.//s:g[@class="class-node"]',ns)
 boxes={c.attrib['data-id']:c.find('s:rect',ns).attrib for c in cards}
 ids=[f'N{i}' for i in range(128)]
 groupsExact=list(boxes)==ids and all(c.attrib.get('data-label')==ids[i] for i,c in enumerate(cards))
 texts=[''.join(c.find('s:text',ns).itertext()) for c in cards]
 routes=root.findall('.//s:polyline[@class="class-relationship"]',ns)
 overlays=root.findall('.//s:polyline[@class="class-marker-overlay"]',ns)
 def points(e):return [tuple(map(float,pair.split(','))) for pair in e.attrib['points'].split()]
 wire=0.;bends=0;contacts=0;bodyIntrusions=0;foreignStrokeChecks=0;foreignStrokeIntrusions=0;edges=[];anchors=[];normalErrors=[]
 semanticExact=len(routes)==127
 for i,r in enumerate(routes):
  a=r.attrib;semanticExact &= all(a.get(k)==v for k,v in {'data-id':f'rel:N{i}->N{i+1}#0','data-from':f'N{i}','data-to':f'N{i+1}','data-type':'association','data-relation-type':'association','data-marker-at':'to','marker-end':'url(#cls-arrow)'}.items())
  pts=points(r);edges.append({'points':[{'x':x,'y':y} for x,y in pts]});prev=None
  for first,second in zip(pts,pts[1:]):
   dx=second[0]-first[0];dy=second[1]-first[1];span=math.hypot(dx,dy);wire+=span
   if span:
    ray=(dx/span,dy/span)
    if prev and (abs(prev[0]*ray[1]-prev[1]*ray[0])>1e-9 or prev[0]*ray[0]+prev[1]*ray[1]<0):bends+=1
    prev=ray
   for owner,b in boxes.items():
    x,y,w,h=[float(b[k]) for k in ['x','y','width','height']]
    interior=(first[1]>y+1e-6 and first[1]<y+h-1e-6 and max(first[0],second[0])>x+1e-6 and min(first[0],second[0])<x+w-1e-6) if dy==0 else (first[0]>x+1e-6 and first[0]<x+w-1e-6 and max(first[1],second[1])>y+1e-6 and min(first[1],second[1])<y+h-1e-6)
    bodyIntrusions+=int(interior)
    if owner not in [a['data-from'],a['data-to']]:
     half=float(a['stroke-width'])/2;bh=float(b['stroke-width'])/2;foreignStrokeChecks+=1
     hit=min(first[0],second[0])-(half if dx==0 else 0)<x+w+bh and max(first[0],second[0])+(half if dx==0 else 0)>x-bh and min(first[1],second[1])-(half if dy==0 else 0)<y+h+bh and max(first[1],second[1])+(half if dy==0 else 0)>y-bh
     foreignStrokeIntrusions+=int(hit)
  for point,toward,owner in [(pts[0],pts[1],a['data-from']),(pts[-1],pts[-2],a['data-to'])]:
   b=boxes[owner];x,y,w,h=[float(b[k]) for k in ['x','y','width','height']];dx=toward[0]-point[0];dy=toward[1]-point[1]
   ok=dy==0 and (abs(point[0]-x)<1e-6 and dx<0 or abs(point[0]-x-w)<1e-6 and dx>0) or dx==0 and (abs(point[1]-y)<1e-6 and dy<0 or abs(point[1]-y-h)<1e-6 and dy>0)
   contacts+=int(ok)
   if not ok:normalErrors.append({'relation':i,'owner':owner})
  anchors.append(pts[-1])
 marker=root.find('.//s:marker[@id="cls-arrow"]',ns);shape=marker.find('s:polyline',ns)
 matchingOverlays=len(overlays)==len(routes) and all(o.attrib['points']==r.attrib['points'] and o.attrib.get('marker-end')==r.attrib.get('marker-end') and o.attrib.get('stroke-opacity')=='0' for o,r in zip(overlays,routes))
 view=list(map(float,root.attrib['viewBox'].split()))
 row={'backend':backend,'source':run['source'],'options':run['options'],'svgReference':str(p/f'class128LR-{backend}-after-cold.svg.gz'),'receiptReference':str(p/f'class128LR-{backend}-after-cold.receipt.json.gz'),'svgBytes':len(raw),'svgSha256':hashlib.sha256(raw).hexdigest(),'viewBox':view,'area':view[2]*view[3],'relationshipCenterlineWire':wire,'bends':bends,'crossings':None,'writtenSemanticRoutes':edges,'cardCount':len(cards),'exactCardIdsLabelsAndNames':bool(groupsExact and texts==ids),'semanticRelationshipCount':len(routes),'exactSourceEndpointAndTypeCorrespondence':bool(semanticExact),'normalContacts':contacts,'normalContactErrors':normalErrors,'rawBodyIntrusions':bodyIntrusions,'foreignStrokeChecks':foreignStrokeChecks,'foreignStrokeIntrusions':foreignStrokeIntrusions,'authoredHeadAttachments':len(anchors),'distinctHeadAnchors':len(set(anchors)),'allHeadReferencesResolve':all(r.attrib.get('marker-end')=='url(#cls-arrow)' for r in routes) and marker is not None,'headResource':{'attributes':marker.attrib,'shape':shape.attrib},'decorativeMarkerOverlays':len(overlays),'overlaysExactlyMatchOwnedCarriersAndBindings':matchingOverlays,'transformAttributesPresent':sum('transform' in e.attrib for e in root.iter()),'finalProof':receipt['layoutCertification']}
 rows.append(row)
report={'head':results['candidateHead'],'callsMade':0,'comparison':'Class128 LR current after-cold actual final SVG; semantic carrier centerlines counted once, decorative opacity0 overlay shafts excluded','sameSource':rows[0]['source']==rows[1]['source'],'sameOptionsExceptBackend':{k:v for k,v in rows[0]['options'].items() if k!='graphLayout'}=={k:v for k,v in rows[1]['options'].items() if k!='graphLayout'} and all(x['options']['graphLayout']['fallback']=='none' for x in rows),'wholeSVGExactAcrossBackends':rows[0]['svgSha256']==rows[1]['svgSha256'],'rows':rows,'limits':['Vector route centerline metrics exclude marker-leg ink and duplicate overlay shafts.','Card/text/source endpoint correspondences and distinct resolved head attachments are checked separately from paint status.','Marker overlays are decorative and lack semantic owner attributes; association uses exact route points and matching marker binding.','No raster/font ink test or universal authored-ink claim.']}
(p/'final-svg-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({**{k:v for k,v in report.items() if k!='rows'},'rows':[{k:v for k,v in row.items() if k not in ['source','writtenSemanticRoutes','finalProof','headResource']} for row in rows]},indent=2))
