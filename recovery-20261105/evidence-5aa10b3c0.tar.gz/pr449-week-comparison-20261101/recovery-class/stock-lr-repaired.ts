import fs from 'node:fs'
import { gzipSync } from 'node:zlib'
const directory='/tmp/pr449-week-comparison-20261101/recovery-class',current='/tmp/pr449-main-integration-20261029-762',source=fs.readFileSync(`${current}/eval/layout-compare/fixtures/class-backends.mmd`,'utf8').replace(/direction\s+(?:TB|BT|LR|RL)/,'direction LR'),options={graphLayout:{backend:'agentic',fallback:'none'},embedFontImport:false}
for(const[tag,root]of[['stock-LR-repaired',current]]){
 const{renderMermaidSVGWithReceipt}=await import(`${root}/src/index.ts`),{withPerformanceObserver}=await import(`${root}/src/performance-observations.ts`);const events=[]
 const save=(name,value)=>fs.writeFileSync(`${directory}/${tag}.${name}.gz`,gzipSync(typeof value==='string'?value:JSON.stringify(value)))
 try{const result=withPerformanceObserver(e=>events.push(e),()=>renderMermaidSVGWithReceipt(source,options));save('svg',result.svg);save('receipt.json',JSON.stringify(result.receipt));save('result.json',{source,options,events,root});console.log(JSON.stringify({tag,returned:true,svgBytes:Buffer.byteLength(result.svg),proof:result.receipt.layoutCertification}))}catch(e){save('error.json',{source,options,events,root,name:e?.name,message:e?.message,stack:e?.stack});console.log(JSON.stringify({tag,returned:false,name:e?.name,message:e?.message}))}
}
