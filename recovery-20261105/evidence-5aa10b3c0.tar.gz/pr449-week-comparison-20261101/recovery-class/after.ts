import fs from 'node:fs'
import { gzipSync } from 'node:zlib'
import { renderMermaidSVGWithReceipt } from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import { withPerformanceObserver } from '/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts'
const directory = '/tmp/pr449-week-comparison-20261101/recovery-class'
const source = 'classDiagram\ndirection TB\nclass A\nclass B\nclass Sink\nA --> Sink : input\nB --> Sink\nSink --> Sink : retry'
const expected = { cards: ['A', 'B', 'Sink'], relations: [['A','Sink','association','input'],['B','Sink','association',undefined],['Sink','Sink','association','retry']], captions: ['input','retry'], heads: 3, contacts: 6 }
const save = (name: string, value: unknown) => fs.writeFileSync(`${directory}/${name}.gz`, gzipSync(typeof value === 'string' ? value : JSON.stringify(value)))
save('AFTER-ENROLLMENT.json', { source, expected, sourceHead: '3b56da55e6570908beb5d96c25f4c03c1a828a22', options: { graphLayout: { fallback: 'none' }, embedFontImport: false }, scope: 'Fresh recovered-source baseline; historical missing runtime is not used.' })
for (const backend of ['agentic','elk'] as const) {
 const events: unknown[] = [], options = { graphLayout: { backend, fallback: 'none' as const }, embedFontImport: false }
 try {
  const result = withPerformanceObserver(e => events.push(e), () => renderMermaidSVGWithReceipt(source, options))
  save(`after-${backend}.svg`, result.svg); save(`after-${backend}.receipt.json`, JSON.stringify(result.receipt)); save(`after-${backend}.json`, { source, options, events })
  console.log(JSON.stringify({ backend, returned: true, svgBytes: Buffer.byteLength(result.svg), proof: result.receipt.layoutCertification, provider: events.filter((e: any) => e.owner === 'paint-certification') }))
 } catch (e: any) { save(`after-${backend}.error.json`, { source, options, events, name: e?.name, message: e?.message, stack: e?.stack }); console.log(JSON.stringify({ backend, returned: false, name: e?.name, message: e?.message })) }
}
