import {compactMeasuredLoops} from '/tmp/pr449-main-integration-20261029-762/src/layout/compact-measured-loops.ts'
for(const changed of [-2,NaN]){
 let reads=0
 const label={get width(){return ++reads<=3?200:changed},height:20}
 const input={nodes:[{id:'loop',width:180,height:60},{id:'foreign',width:20,height:30}],edges:[{source:0,target:0,minSpan:1,label}],direction:'TB' as const,padding:40,nodeSpacing:40,layerSpacing:60}
 const points=[{x:260,y:100},{x:260,y:130},{x:260,y:200},{x:360,y:200},{x:360,y:130},{x:360,y:100}]
 const placed={width:600,height:300,nodes:[{x:220,y:40},{x:220,y:110}],edges:[{points,labelPosition:{x:156,y:160}}]}
 const result=compactMeasuredLoops(input,placed,{loopPairs:2_000_000})
 console.log(JSON.stringify({changed:String(changed),reads,points:result.edges[0].points,labelPosition:result.edges[0].labelPosition,sameOriginal:result.edges[0].points===points}))
}
