import fs from 'node:fs'
Bun.plugin({name:'before-private-freeze-custody',setup(build){build.onLoad({filter:/\/src\/scene\/group-emission\.ts$/},()=>({contents:fs.readFileSync('/tmp/pr449-week-comparison-20261101/native-group-actual-b063/group-emission.freeze-before.ts','utf8'),loader:'ts'}))}})
