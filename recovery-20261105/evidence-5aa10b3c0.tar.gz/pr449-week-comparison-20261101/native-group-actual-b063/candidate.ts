import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import assert from 'node:assert/strict'
import { renderMermaidSVGWithReceipt } from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/native-group-actual-b063'
const baseline=JSON.parse(gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/cyclic15-19-b063/current-cyclic-labelled-19.mmd-agentic.json.gz')).toString())
const source=readFileSync(root+'/eval/layout-compare/fixtures/cyclic-labelled-19.mmd','utf8')
assert.equal(source,baseline.source)
const options={graphLayout:{backend:'agentic' as const,fallback:'none' as const},embedFontImport:false,idPrefix:'cycle-check-'}
const result=renderMermaidSVGWithReceipt(source,options)
const serialized=JSON.stringify(result);let sum=0
for(let i=0;i<serialized.length;i++)sum+=serialized.charCodeAt(i)
writeFileSync(out+'/result.json.gz',gzipSync(JSON.stringify({source,options,actualPublicSVGCalls:1,actualPublicLayoutCalls:0,result,priorProof:baseline.svgReceipt.layoutCertification,wholeSVGByteEqual:result.svg===baseline.svg,consumed:{utf16Units:serialized.length,utf8Bytes:Buffer.byteLength(serialized),sum}})))
writeFileSync(out+'/raw-receipt.json.gz',gzipSync(JSON.stringify(result.receipt)))
writeFileSync(out+'/actual.svg.gz',gzipSync(result.svg))
const summary={actualPublicSVGCalls:1,actualPublicLayoutCalls:0,wholeSVGByteEqual:result.svg===baseline.svg,proof:result.receipt.layoutCertification,priorProof:baseline.svgReceipt.layoutCertification,consumed:{utf16Units:serialized.length,utf8Bytes:Buffer.byteLength(serialized),sum}}
writeFileSync(out+'/SUMMARY.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary))
assert.equal(result.svg,baseline.svg,'whole SVG equality, no normalization')
