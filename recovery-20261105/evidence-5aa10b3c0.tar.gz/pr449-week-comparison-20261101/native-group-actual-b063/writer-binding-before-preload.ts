import fs from 'node:fs'
Bun.plugin({name:'actual-source-shell-writer-before',setup(build){build.onLoad({filter:/\/src\/scene\/native-drawing\.ts$/},()=>({contents:fs.readFileSync('/tmp/pr449-week-comparison-20261101/native-group-actual-b063/native-drawing.writer-binding-before.ts','utf8'),loader:'ts'}))}})
