// Lexical-only design experiment. No render imports or public SVG calls.
import assert from 'node:assert/strict'
import { writeFileSync } from 'node:fs'
import { scanSvgStartTagsFresh, visitSvgFirstTagAttributes, decodedSvgAttributeValue, type SvgStartTagToken } from '/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts'
import { captureNativeGroupParse, type NativeGroupParse } from '/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts'
const out='/tmp/pr449-week-comparison-20261101/native-group-actual-b063'
const raw='<g class="mono">'
const intrinsicSlice=String.prototype.slice
let altered=0
const constructorValues: Array<[string,string]>=[]
let fact: readonly SvgStartTagToken[], actualPlan: NativeGroupParse|undefined
try {
 String.prototype.slice=function(start?:number,end?:number) {
  const actual=intrinsicSlice.call(this,start,end)
  if(String(this)===raw && actual==='mono' && altered===0) {altered++;return 'safe'}
  return actual
 }
 visitSvgFirstTagAttributes(raw,'g',(name,value)=>constructorValues.push([name,value]))
 actualPlan=captureNativeGroupParse({id:'g',open:raw,close:'</g>',join:'\n'},()=>true)
 assert.ok(actualPlan)
 fact=actualPlan.materialize(()=>true)!
 assert.ok(fact)
 assert.equal(constructorValues[0]?.[1],'safe')
 assert.equal(fact[0]?.attributes[0]?.value,'mono')
 assert.equal(scanSvgStartTagsFresh(raw)[0]?.attributes[0]?.value,'mono')
} finally {String.prototype.slice=intrinsicSlice}
// Exercise the actual production producer materializer twice.
function materialize(_source: readonly SvgStartTagToken[]): readonly SvgStartTagToken[] {
 const materialized=actualPlan!.materialize(()=>true)
 assert.ok(materialized)
 return materialized
}
const first=materialize(fact!),second=materialize(fact!)
assert.deepEqual(first,second)
assert.notEqual(first,second)
assert.notEqual(first[0],second[0])
assert.notEqual(first[0]!.attributes,second[0]!.attributes)
assert.notEqual(first[0]!.attributes[0],second[0]!.attributes[0])
const findDescriptor=Object.getOwnPropertyDescriptor(Array.prototype,'find')!
const ordinaryFind=Array.prototype.find
const visits=new WeakMap<object,number>()
let freshValues: Array<string|undefined>,sharedValues: Array<string|undefined>
try {
 Object.defineProperty(Array.prototype,'find',{configurable:true,get() {
  const receiver=this,n=(visits.get(receiver)??0)+1
  visits.set(receiver,n)
  return function(predicate:any) {
   const found=Reflect.apply(ordinaryFind,receiver,[predicate])
   return found && found.name==='class' ? {...found,value:n===1?'safe':'mono'}:found
  }
 }})
 freshValues=[decodedSvgAttributeValue(first[0]!,'class'),decodedSvgAttributeValue(second[0]!,'class')]
 const shared=materialize(fact!)
 sharedValues=[decodedSvgAttributeValue(shared[0]!,'class'),decodedSvgAttributeValue(shared[0]!,'class')]
 assert.deepEqual(freshValues,['safe','safe'])
 assert.deepEqual(sharedValues,['safe','mono'])
} finally {Object.defineProperty(Array.prototype,'find',findDescriptor)}
const result={publicSVGCalls:0,scope:'Lexical-only actual production producer/materializer receiver and primitive String.slice check; no render or capacity claim.',raw,retainedSliceCounterexample:{altered,constructorValues,primitiveProducerValue:fact![0]!.attributes[0]!.value,freshLaterValue:scanSvgStartTagsFresh(raw)[0]!.attributes[0]!.value},receiverCounterexample:{freshValues:freshValues!,sharedValues:sharedValues!,allTokenAndArrayReceiversDistinct:true},checks:'passed'}
writeFileSync(out+'/LEXICAL-CANDIDATE-CHECK.json',JSON.stringify(result,null,2))
console.log(JSON.stringify(result))
