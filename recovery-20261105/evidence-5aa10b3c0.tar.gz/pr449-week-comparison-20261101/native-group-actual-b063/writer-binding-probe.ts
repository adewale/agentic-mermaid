import { writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const getNamesDescriptor=Object.getOwnPropertyDescriptor(Object,'getOwnPropertyNames')!
const freezeDescriptor=Object.getOwnPropertyDescriptor(Object,'freeze')!
const names=getNamesDescriptor.value,freeze=freezeDescriptor.value
const events:any[]=[]
let sourceGroup:any,mutated=false
Object.defineProperty(Object,'getOwnPropertyNames',{...getNamesDescriptor,value:function(value:object){
 const result=Reflect.apply(names,Object,[value])
 if((value as any)?.kind==='group'&&(value as any)?.id==='font-group'&&(value as any)?.open==='<g class="safe">'){
  sourceGroup=value;events.push({event:'retained-private-source-shell',open:sourceGroup.open})
 }
 return result
}})
Object.defineProperty(Object,'freeze',{...freezeDescriptor,value:function(value:any){
 if(!mutated&&sourceGroup&&value?.name==='g'&&Array.isArray(value.attributes)&&new Error().stack?.includes('materialize')){
  sourceGroup.open='<g class="mono">';mutated=true;events.push({event:'mutated-after-capture-during-materialization',open:sourceGroup.open})
 }
 return Reflect.apply(freeze,Object,[value])
}})
let record:any
try {
 const root='/tmp/pr449-main-integration-20261029-762/src'
 const {drawNative}=await import(root+'/scene/native-drawing.ts')
 const {certifyNativePaint}=await import(root+'/scene/paint-certification.ts')
 const {preparePixelText}=await import(root+'/shared/prepared-text.ts')
 const {withTextMeasurementExecution}=await import(root+'/text-measurement-profile.ts')
 const {tipAnchoredArrow,serializeMarkerResource}=await import(root+'/scene/marker-resources.ts')
 const {svgOpenTag,buildStyleBlock}=await import(root+'/theme.ts')
 const width=200,height=120,colors={bg:'#fff',fg:'#111',font:'Inter'}
 const context={positioned:{width,height},colors,resolved:{renderOptions:{}}}
 const block=withTextMeasurementExecution(undefined,()=>preparePixelText('Wiii',{fontSize:20,fontWeight:400}),'Inter')
 const marker=tipAnchoredArrow('font-custody-arrow',{width:8,height:5},'end',{fill:'#000'},'userSpaceOnUse')
 const producer=(factory:any)=>({family:'flowchart',width,height,colors,transparent:false,parts:[
 factory.documentOpen({id:'root',width,height,colors,transparent:false,font:'Inter',hasMonoFont:true},svgOpenTag(width,height,colors)+'\n'+buildStyleBlock('Inter',true,false,false)),
 factory.definitions({id:'markers'},'<defs>'+serializeMarkerResource(marker)+'</defs>'),
 factory.connector({id:'edge',role:'edge',lineStyle:'solid',geometry:{kind:'line',x1:20,y1:40,x2:50,y2:40},paint:{stroke:'#000'},endpoints:{from:'outside',to:'cover'},markers:{end:marker}}),
 factory.shape({id:'cover',role:'node',geometry:{kind:'rect',x:90,y:10,width:35,height:45},paint:{fill:'#fff'}}),
 factory.group({id:'font-group',role:'chrome',open:'<g class="safe">',close:'</g>',children:[{node:factory.text({id:'font-text',role:'label',text:block.text,block,x:20,y:90,fontSize:20,anchor:'start',paint:{fill:'#111'}}),indent:2}]}),
 factory.documentClose(),
 ]})
 const drawing=drawNative(producer,context,'flowchart')
 const proof=certifyNativePaint(drawing.header,drawing.paint)
 record={directOwnerDrawCalls:1,publicSVGCalls:0,publicLayoutCalls:0,events,mutated,svg:drawing.svg,proof,actualGroup:drawing.svg.match(/<g class="(?:safe|mono)">/)?.[0]}
} finally {Object.defineProperty(Object,'getOwnPropertyNames',getNamesDescriptor);Object.defineProperty(Object,'freeze',freezeDescriptor)}
writeFileSync('/tmp/pr449-week-comparison-20261101/native-group-actual-b063/WRITER-BINDING-BEFORE.json.gz',gzipSync(JSON.stringify(record)))
console.log(JSON.stringify({...record,svg:undefined}))
