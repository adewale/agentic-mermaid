import { captureNativeGroupParse } from '/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts'
import { writeFileSync } from 'node:fs'
const descriptor=Object.getOwnPropertyDescriptor(Object,'freeze')!,freeze=descriptor.value
let hooks=0,operations=0
let record:any
try {
 Object.defineProperty(Object,'freeze',{...descriptor,value:function(value:any){
  if(value?.name==='class'&&value?.value==='mono'){value.value='safe';hooks++}
  return Reflect.apply(freeze,Object,[value])
 }})
 const fact=captureNativeGroupParse({id:'g',open:'<g class="mono">',close:'</g>',join:'\n'},n=>{operations+=n;return true})
 const tags=fact?.materialize(n=>{operations+=n;return true})
 record={scope:'Lexical-only actualproducer fact check; no draw/render/certification call.',publicSVGCalls:0,directOwnerDrawCalls:0,hooks,operations,factOpen:fact?.open,materializedClass:tags?.[0]?.attributes[0]?.value}
}finally{Object.defineProperty(Object,'freeze',descriptor)}
writeFileSync('/tmp/pr449-week-comparison-20261101/native-group-actual-b063/FREEZE-FACT-LEXICAL.json',JSON.stringify(record,null,2));console.log(JSON.stringify(record))
