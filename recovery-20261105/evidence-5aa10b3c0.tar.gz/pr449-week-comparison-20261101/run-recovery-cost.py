import json,os,subprocess
roots={'before':'/tmp/pr449-recovery-base3b','after':'/tmp/pr449-main-integration-20261029-762'}
env=os.environ.copy();env['AGENTIC_MERMAID_SCENE_ASSERTIONS']='0'
with open('/tmp/pr449-week-comparison-20261101/recovery-cost.jsonl','w') as out:
 for family in ['class','requirement']:
  for backend in ['agentic','elk']:
   for cache in ['0','1']:
    env['AGENTIC_MERMAID_ELK_CACHE']=cache
    arms=['before','after'] if (family=='class')==(cache=='0') else ['after','before']
    for arm in arms:
     tag=f'{family}-{backend}-geometry-cache{cache}-{arm}'
     try:
      r=subprocess.run(['/tmp/pr449-bin/bun','/tmp/pr449-week-comparison-20261101/recovery-cost.ts',roots[arm],family,backend,tag],env=env,text=True,capture_output=True,timeout=40)
      row=json.loads(r.stdout) if r.returncode==0 else {'tag':tag,'status':'process-failed','exit':r.returncode,'stderr':r.stderr}
     except Exception as e: row={'tag':tag,'status':'unavailable','error':str(e)}
     out.write(json.dumps(row)+'\n');out.flush()
     print(tag, row.get('status','recorded'),flush=True)
