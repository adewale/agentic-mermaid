import { spyOn } from 'bun:test'
import { writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const root='/tmp/pr449-main-integration-20261029-762'
const engine=await import(root+'/src/layout/agentic-layered.ts'),original=engine.layoutAgenticGraph
const source=await Bun.file(root+'/eval/layout-compare/fixtures/requirement-backends.mmd').text()
const spy=spyOn(engine,'layoutAgenticGraph').mockImplementation(input=>{
 const permutation=input.nodes.map((_,i)=>i).sort((a,b)=>Number(input.nodes[a]!.id==='fast')-Number(input.nodes[b]!.id==='fast'))
 const indices=new Uint32Array(input.nodes.length);permutation.forEach((id,i)=>indices[id]=i)
 const moved=original({...input,authoredCycleOrder:true,nodes:permutation.map(i=>input.nodes[i]!),edges:input.edges.map(e=>({...e,source:indices[e.source]!,target:indices[e.target]!}))})
 return {...moved,nodes:input.nodes.map((_,i)=>moved.nodes[indices[i]!]!)}
})
try{
 const {snapshotSample}=await import(root+'/eval/layout-compare/run.ts')
 const result=snapshotSample({id:'opposite-requirement',family:'requirement',source},'recovery-',{graphLayout:{backend:'agentic',fallback:'none'},embedFontImport:false},{includeAscii:false})
 writeFileSync('/tmp/pr449-week-comparison-20261101/requirement-cycle-25e/opposite-result.json.gz',gzipSync(JSON.stringify(result)))
 console.log(JSON.stringify({ok:result.ok,failures:result.failures,viewBox:result.svg?.match(/viewBox="[^"]+"/)?.[0],rounded:result.metrics?.routeGeometry}))
}finally{spy.mockRestore()}
