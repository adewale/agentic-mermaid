import { writeFileSync,readFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const [root,arm]=Bun.argv.slice(2),{snapshotSample}=await import(root+'/eval/layout-compare/run.ts')
for(const file of ['cyclic-labelled-9-chains.mmd','cyclic-labelled-15-chains.mmd','cyclic-labelled-19.mmd','state-basic.mmd'])for(const backend of ['agentic','elk'] as const){
 const source=readFileSync(root+'/eval/layout-compare/fixtures/'+file,'utf8')
 const value=snapshotSample({id:file,family:file.startsWith('state')?'state':'flowchart',source},'cycle-check-',{graphLayout:{backend,fallback:'none'},embedFontImport:false},{includeAscii:false})
 writeFileSync(`/tmp/pr449-week-comparison-20261101/requirement-cycle-25e/${arm}-${file}-${backend}.json.gz`,gzipSync(JSON.stringify(value)))
 console.log(JSON.stringify({file,backend,ok:value.ok,failures:value.failures,proof:value.svgReceipt?.layoutCertification?.status,geometry:value.metrics?.routeGeometry}))
}
