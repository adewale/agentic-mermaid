import fs from 'node:fs'
import { createHash } from 'node:crypto'
import { gzipSync, gunzipSync } from 'node:zlib'
import { Resvg } from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import { HOSTED_FONT_RESOURCES } from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import { inlineFontVarForRaster } from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import { prepareResvgMarkerOrientation } from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const dir=process.argv[3]!,root='/tmp/pr449-main-integration-20261029-762',scratch=fs.mkdtempSync('/tmp/pr449-req-font-')
try {
 const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter'), fontFiles=fonts.map(f=>{const b=fs.readFileSync(`${root}/${f.path}`);if(b.length!==f.bytes||createHash('sha256').update(b).digest('hex')!==f.sha256)throw Error('Font manifest mismatch');const p=`${scratch}/${f.file}`;fs.writeFileSync(p,b);return p})
 const bytes=fs.readFileSync(process.argv[2]!), packet=JSON.parse((process.argv[2]!.endsWith('.gz')?gunzipSync(bytes):bytes).toString()), source=(packet.svg??packet.rendered?.svg??packet.value?.svg) as string
 if(typeof source!=='string')throw Error('Missing served SVG')
 const [,,w,h]=source.match(/viewBox="(\S+) (\S+) (\S+) (\S+)"/)!.slice(1).map(Number)
 const expanded=source.replace(/width="[^"]+"/,`width="${w+40}"`).replace(/height="[^"]+"/,`height="${h+40}"`).replace(/viewBox="[^"]+"/,`viewBox="-20 -20 ${w+40} ${h+40}"`)
 const owned=expanded.match(/<g class="requirement-edge-label"[^>]*>[\s\S]*?&lt;&lt;refines&gt;&gt;[\s\S]*?<\/g>/g)!.at(-1)!
 const caption=owned.match(/<text\b[^>]*>&lt;&lt;refines&gt;&gt;<\/text>/)![0]
 const pill=owned.slice(owned.lastIndexOf('<g ')).match(/<rect[^>]+>/)![0], attr=(k:string)=>Number(new RegExp(k+'="([^"]+)"').exec(pill)![1]), captionROI={x:attr('x'),y:attr('y'),w:attr('width'),h:attr('height')}
 const routes=[...expanded.matchAll(/<polyline\b[^>]*data-role="relationship"[^>]*\/>/g)].map(m=>m[0])
 const rois=routes.map(route=>{const pts=/points="([^"]+)"/.exec(route)![1]!.trim().split(/\s+/).map(p=>p.split(',').map(Number));const [x,y]=pts.at(-1)!;return {x:x!-14,y:y!-14,w:28,h:28}})
 const mask=expanded.replace(caption,caption.replace('<text ','<text opacity="0" ')).replace(/ marker-end="[^"]+"/g,'')
 const [a,b]=[expanded,mask].map((svg,i)=>{const r=new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(svg)),{background:'#fff',fitTo:{mode:'zoom',value:2},font:{fontFiles,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();fs.writeFileSync(`${dir}/requirement-${i?'mask':'full'}.png.gz`,gzipSync(r.asPng()));return {width:r.width,height:r.height,pixels:Buffer.from(r.pixels)}})
 const heads=rois.map(()=>0);let captionDarker=0,outsideFull=0,outsideMask=0
 for(let y=0;y<a.height;y++)for(let x=0;x<a.width;x++){const i=(y*a.width+x)*4,wx=(x+.5)/2-20,wy=(y+.5)/2-20,out=wx<0||wy<0||wx>w||wy>h;if(out){if(a.pixels[i]!<245||a.pixels[i+1]!<245||a.pixels[i+2]!<245)outsideFull++;if(b.pixels[i]!<245||b.pixels[i+1]!<245||b.pixels[i+2]!<245)outsideMask++}if(a.pixels[i]!+a.pixels[i+1]!+a.pixels[i+2]!>=b.pixels[i]!+b.pixels[i+1]!+b.pixels[i+2]!-4)continue;for(let j=0;j<rois.length;j++){const r=rois[j]!;if(wx>=r.x&&wx<=r.x+r.w&&wy>=r.y&&wy<=r.y+r.h)heads[j]!++}if(wx>=captionROI.x&&wx<=captionROI.x+captionROI.w&&wy>=captionROI.y&&wy<=captionROI.y+captionROI.h)captionDarker++}
 const result={input:process.argv[2],captionROI,publicCalls:0,offlineRasterCalls:2,faces:fonts.map(f=>f.file),headDarker:heads,captionDarker,outsideFull,outsideMask,scope:'TB final served SVG, four pinned normal Inter faces, refines opacity and all marker-end controls; not a whole-ink/font-universal claim'}
 fs.writeFileSync(`${dir}/requirement-ink.json`,JSON.stringify(result,null,2));console.log(JSON.stringify(result))
}finally {fs.rmSync(scratch,{recursive:true,force:true})}
