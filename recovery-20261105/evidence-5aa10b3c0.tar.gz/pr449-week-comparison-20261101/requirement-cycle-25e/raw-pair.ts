import { spyOn } from 'bun:test'
import { writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const root='/tmp/pr449-main-integration-20261029-762', engine=await import(root+'/src/layout/cycle-layout-search.ts')
const original=engine.layoutCyclicGraph
const source=await Bun.file(root+'/eval/layout-compare/fixtures/requirement-backends.mmd').text()
const spy=spyOn(engine,'layoutCyclicGraph').mockImplementation((input,_in,_out,layout,fail,work,search)=>{
 const base=original(input,_in,_out,layout,fail,work,search)
 const reversed=input.edges.map(e=>input.nodes[e.source]!.id==='fast'&&input.nodes[e.target]!.id==='report')
 const placed=layout({...input,cycleOriented:true,edges:input.edges.map((e,i)=>reversed[i]?{...e,source:e.target,target:e.source}:e)},fail,search.routing)
 console.log(JSON.stringify({raw:[base,placed].map(p=>({w:p.width,h:p.height,bends:p.edges.reduce((s,e)=>s+Math.max(0,e.points.length-2),0)})),work:search}))
 return {...placed,edges:placed.edges.map((e,i)=>reversed[i]?{...e,points:[...e.points].reverse()}:e)}
})
try{
 const {snapshotSample}=await import(root+'/eval/layout-compare/run.ts')
 const result=snapshotSample({id:'opposite-requirement',family:'requirement',source},'recovery-',{graphLayout:{backend:'agentic',fallback:'none'},embedFontImport:false},{includeAscii:false})
 writeFileSync('/tmp/pr449-week-comparison-20261101/requirement-cycle-25e/raw-pair-result.json.gz',gzipSync(JSON.stringify(result)))
 console.log(JSON.stringify({ok:result.ok,failures:result.failures,viewBox:result.svg?.match(/viewBox="[^"]+"/)?.[0],rounded:result.metrics?.routeGeometry}))
}finally{spy.mockRestore()}
