import fs from 'node:fs'
import{gzipSync,gunzipSync}from'node:zlib'
import{renderMermaidSVGWithReceipt}from'/tmp/pr449-main-integration-20261029-762/src/index.ts'
const dir='/tmp/pr449-week-comparison-20261101/final-e087',root='/tmp/pr449-main-integration-20261029-762'
const template=JSON.parse(gunzipSync(fs.readFileSync('/tmp/pr449-week-comparison-20261101/class-caption-seat-0684/INPUT.json.gz')).toString()).template
const requirement=fs.readFileSync(root+'/eval/layout-compare/fixtures/requirement-backends.mmd','utf8'),rows=[]
for(const family of ['class','requirement'])for(const backend of ['agentic','elk'] as const){
 const source=family==='class'?template.replace('DIRECTION','LR'):requirement
 const options={graphLayout:{backend,fallback:'none' as const},embedFontImport:false,...(family==='requirement'?{idPrefix:'recovery-'}:{})},stem=`${dir}/${family}-${backend}`
 try{const value=renderMermaidSVGWithReceipt(source,options);fs.writeFileSync(stem+'.svg.gz',gzipSync(value.svg));fs.writeFileSync(stem+'.receipt.json.gz',gzipSync(JSON.stringify(value.receipt)));fs.writeFileSync(stem+'.result.json.gz',gzipSync(JSON.stringify({source,options,value})));rows.push({family,backend,source,options,svgReference:stem+'.svg.gz',receiptReference:stem+'.receipt.json.gz'});console.log(JSON.stringify({family,backend,status:'returned',viewBox:value.svg.match(/viewBox="([^"]+)"/)?.[1],proof:value.receipt.layoutCertification}))}catch(e:any){fs.writeFileSync(stem+'.error.json',JSON.stringify({source,options,name:e.name,message:e.message}));console.log(JSON.stringify({family,backend,status:'failed',name:e.name,message:e.message}))}
}
fs.writeFileSync(dir+'/bindings.json',JSON.stringify(rows,null,2))
