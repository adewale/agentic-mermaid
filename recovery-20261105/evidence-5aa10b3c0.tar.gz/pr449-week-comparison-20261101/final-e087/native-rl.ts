import fs from 'node:fs'
import{gzipSync,gunzipSync}from'node:zlib'
import{renderMermaidSVGWithReceipt}from'/tmp/pr449-main-integration-20261029-762/src/index.ts'
import{withRenderStageObserver}from'/tmp/pr449-main-integration-20261029-762/src/render-stages.ts'
const source=JSON.parse(gunzipSync(fs.readFileSync('/tmp/pr449-week-comparison-20261101/class-caption-seat-0684/INPUT.json.gz')).toString()).template.replace('DIRECTION','RL'),stages:string[]=[]
try{const result=withRenderStageObserver(s=>stages.push(s.stage),()=>renderMermaidSVGWithReceipt(source,{graphLayout:{backend:'elk',fallback:'none'},embedFontImport:false}));for(const[n,v]of[['svg',result.svg],['receipt.json',JSON.stringify(result.receipt)]]as const)fs.writeFileSync('/tmp/pr449-week-comparison-20261101/final-e087/class-RL-elk.'+n+'.gz',gzipSync(v));console.log(JSON.stringify({returned:true,stages,proof:result.receipt.layoutCertification?.status,viewport:result.svg.match(/viewBox="([^"]+)"/)?.[1]}))}catch(e:any){console.log(JSON.stringify({returned:false,stages,name:e.name,message:e.message}));process.exitCode=1}
