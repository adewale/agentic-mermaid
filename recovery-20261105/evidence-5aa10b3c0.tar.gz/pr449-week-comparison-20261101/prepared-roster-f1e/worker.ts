import { readFileSync, writeFileSync, writeSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/prepared-roster-f1e'
Bun.plugin({name:'prepared-run-roster-subtraction',setup(build){build.onLoad({filter:/\/src\/scene\/marks\.ts$/},args=>args.path===root+'/src/scene/marks.ts'?{contents:readFileSync('/tmp/pr449-week-comparison-20261101/prepared-roster-f1e/marks.candidate.ts','utf8'),loader:'ts'}:undefined)}})
const {drawNative}=await import(root+'/src/scene/native-drawing.ts')
const {certifyNativePaint}=await import(root+'/src/scene/paint-certification.ts')
const {preparePixelText}=await import(root+'/src/shared/prepared-text.ts')
const {tipAnchoredArrow,serializeMarkerResource}=await import(root+'/src/scene/marker-resources.ts')
const {nativeEmissionWorkOf}=await import(root+'/src/scene/native-paint-emission.ts')
const markerCount=32
  const width = 200, height = 31000, colors = { bg: '#fff', fg: '#111' }
  const block = preparePixelText('x', { fontSize: 12, fontWeight: 400 })
  const marker = tipAnchoredArrow('decorative-arrow', { width: 8, height: 5 }, 'end', { fill: '#111', stroke: '#111', strokeWidth: '0.75' }, 'userSpaceOnUse')
  const context = { positioned: { width, height }, colors, resolved: { renderOptions: {} } }
  const producer = factory => ({ family: 'flowchart', width, height, colors, transparent: false, parts: [
    factory.documentOpen({ id: 'root', width, height, colors, transparent: false, font: 'Inter', hasMonoFont: false }, `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">`),
    ...(markerCount ? [factory.definitions({ id: 'resources' }, `<defs>${serializeMarkerResource(marker)}</defs>`)] : []),
    ...Array.from({ length: markerCount }, (_, index) => factory.connector({ id: `chrome:${index}`, role: 'chrome', lineStyle: 'solid', geometry: { kind: 'line', x1: 20, y1: 40 + index * 20, x2: 60, y2: 40 + index * 20 }, paint: { stroke: '#111', strokeWidth: '1' }, markers: { end: marker } })),
    ...Array.from({ length: 1500 }, (_, index) => factory.text({ id: `text:${index}`, role: 'label', text: 'x', block, x: 20, y: 1000 + index * 20, fontSize: 12, anchor: 'start', paint: { fill: '#111' } })),
    factory.documentClose(),
  ] })

const start=performance.now(),cpu=process.cpuUsage(),beforeMemory=process.memoryUsage()
writeSync(1,JSON.stringify({event:'AUTHORIZED_NATIVE_DRAW_START',actualNativeDrawCalls:1,publicSvgCalls:0,sceneCalls:0})+'\n')
let packet:any
try {
 const drawing=drawNative(producer,context,'flowchart')
 const proof=certifyNativePaint(drawing.header,drawing.paint)
 const baseline=JSON.parse(readFileSync('/tmp/pr449-week-comparison-20261101/sparse32-foreground-f1e/baseline-packet.json','utf8'))
 const proofBytes=JSON.stringify(proof),productBytes=Buffer.from(JSON.stringify({svg:drawing.svg,header:drawing.header,proof}));let checksum=0;for(const byte of productBytes)checksum=(Math.imul(checksum,31)+byte)>>>0
 writeFileSync(out+'/actual.svg',drawing.svg);writeFileSync(out+'/actual.proof.json',proofBytes)
 const initial=nativeEmissionWorkOf(drawing.paint)
 packet={status:'returned',actualNativeDrawCalls:1,certifyNativeCalls:1,publicSvgCalls:0,sceneCalls:0,fullyConsumedProductBytes:productBytes.length,checksum,wholeSvgBytesExactToBaseline:drawing.svg===baseline.svg,entireNativeProofBytesExactToBaseline:proofBytes===JSON.stringify(baseline.proofs[1]),svg:drawing.svg,header:drawing.header,proof,nativeInitial:initial,beforeMemory,afterMemory:process.memoryUsage(),peakRssKiB:process.resourceUsage().maxRSS,elapsedMsObservedOnly:performance.now()-start,cpuObservedOnly:process.cpuUsage(cpu)}
} catch(error:any) { packet={status:'threw',actualNativeDrawCalls:1,publicSvgCalls:0,sceneCalls:0,error:{name:error?.name,message:error?.message,stack:error?.stack,code:error?.code,certification:error?.certification}} }
writeFileSync(out+'/RESULT.json.gz',gzipSync(JSON.stringify(packet)))
writeSync(1,JSON.stringify({...packet,svg:undefined})+'\n')
