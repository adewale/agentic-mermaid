import './old-preload.ts'
process.env.BUN_OPTIONS = '--preload /tmp/pr449-week-comparison-20261101/native-font-lexer-fix-9f519/old-preload.ts'
