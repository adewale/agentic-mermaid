import fs from 'node:fs'
import {gzipSync,gunzipSync} from 'node:zlib'
import assert from 'node:assert/strict'
import {snapshotSample} from '/tmp/pr449-main-integration-20261029-762/eval/layout-compare/run.ts'
const root='/tmp/pr449-main-integration-20261029-762',dir='/tmp/pr449-week-comparison-20261101/flow-fit-precleanup-7a8c58917',arm=process.argv[2]
const retained=JSON.parse(gunzipSync(fs.readFileSync('/tmp/pr449-week-comparison-20261101/requirement-cycle-25e/before-cyclic-labelled-9-chains.mmd-agentic.json.gz')).toString())
const source=fs.readFileSync(root+'/eval/layout-compare/fixtures/cyclic-labelled-9-chains.mmd','utf8');assert.equal(source,retained.source)
const options={graphLayout:{backend:'agentic' as const,fallback:'none' as const},embedFontImport:false}
const result=snapshotSample({id:'cyclic-labelled-9-chains.mmd',family:'flowchart',source},'cycle-check-',options,{includeAscii:false})
const serialized=JSON.stringify(result)
fs.writeFileSync(dir+`/${arm}.json.gz`,gzipSync(serialized))
if(result.svg){fs.writeFileSync(dir+`/${arm}.svg.gz`,gzipSync(result.svg));fs.writeFileSync(dir+`/${arm}.receipt.json.gz`,gzipSync(JSON.stringify(result.svgReceipt)))}
console.log(JSON.stringify({arm,fullyConsumedBytes:Buffer.byteLength(serialized),publicLayoutCalls:1,publicSvgCalls:1,ok:result.ok,failures:result.failures,geometry:result.metrics?.routeGeometry,crossings:result.metrics?.edgeCrossings,labelConflicts:result.metrics?.labelConflicts,routeOverlaps:result.metrics?.routeOverlaps,proof:result.svgReceipt?.layoutCertification}))
