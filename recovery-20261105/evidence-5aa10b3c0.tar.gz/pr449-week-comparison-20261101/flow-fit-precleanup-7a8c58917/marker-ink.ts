import fs from 'node:fs'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {gzipSync,gunzipSync} from 'node:zlib'
import {createRequire} from 'node:module'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const {JSDOM}=createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
const root='/tmp/pr449-main-integration-20261029-762',dir='/tmp/pr449-week-comparison-20261101/flow-fit-precleanup-7a8c58917',scratch=fs.mkdtempSync('/tmp/pr449-fit-fonts-')
const save=(name,value)=>fs.writeFileSync(`${dir}/${name}.gz`,gzipSync(typeof value==='string'||value instanceof Uint8Array?value:JSON.stringify(value,null,2)))
try {
 const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter'),fontFiles=fonts.map(f=>{const b=fs.readFileSync(`${root}/${f.path}`);assert.equal(b.length,f.bytes);assert.equal(createHash('sha256').update(b).digest('hex'),f.sha256);const p=`${scratch}/${f.file}`;fs.writeFileSync(p,b);return p})
 const raw=gunzipSync(fs.readFileSync(dir+'/after.svg.gz')).toString(),dom=new JSDOM(raw,{contentType:'image/svg+xml'}),d=dom.window.document
 const sv=d.documentElement,width=+sv.getAttribute('width'),height=+sv.getAttribute('height'),margin=10,zoom=2,ew=width+20,eh=height+20
 const edges=[...d.querySelectorAll('polyline.edge[data-id]')];assert.equal(edges.length,23)
 const rois=edges.map(edge=>{const id=/^url\(#([^)]*)\)$/.exec(edge.getAttribute('marker-end'))?.[1];assert(id);const marker=d.getElementById(id);assert(marker);assert.equal(marker.getAttribute('orient'),'auto');assert(!marker.hasAttribute('viewBox'));const unit=marker.getAttribute('markerUnits')??'strokeWidth';assert.equal(unit,'strokeWidth');assert.equal(+marker.getAttribute('refX'),8);assert.equal(+marker.getAttribute('refY'),2.5);const poly=marker.querySelector('polygon');assert(poly);assert.equal(poly.getAttribute('points'),'0 0, 8 2.5, 0 5');assert.equal(poly.getAttribute('stroke-linejoin'),'round')
  const pts=edge.getAttribute('points').trim().split(/\s+/).map(p=>p.split(',').map(Number)),p=pts.at(-1),a=pts.at(-2),dx=p[0]-a[0],dy=p[1]-a[1],len=Math.hypot(dx,dy);assert(len>0&&(dx===0||dy===0));const ux=dx/len,uy=dy/len,scale=+edge.getAttribute('stroke-width'),half=+poly.getAttribute('stroke-width')/2
  const corners=[[-8-half,-2.5-half],[half,-2.5-half],[-8-half,2.5+half],[half,2.5+half]].map(([x,y])=>[p[0]+scale*(x*ux-y*uy),p[1]+scale*(x*uy+y*ux)])
  return{id:edge.getAttribute('data-id'),from:edge.getAttribute('data-from'),to:edge.getAttribute('data-to'),endpoint:p,normal:[ux,uy],roi:{x0:Math.min(...corners.map(c=>c[0]))-1,y0:Math.min(...corners.map(c=>c[1]))-1,x1:Math.max(...corners.map(c=>c[0]))+1,y1:Math.max(...corners.map(c=>c[1]))+1},changed:0,darker:0,lighter:0}
 })
 dom.window.close()
 const expanded=raw.replace(/width="[^"]+"/,`width="${ew}"`).replace(/height="[^"]+"/,`height="${eh}"`).replace(/viewBox="[^"]+"/,`viewBox="-10 -10 ${ew} ${eh}"`),mask=expanded.replace(/ marker-end="url\(#[^)]+\)"/g,'');assert.notEqual(mask,expanded)
 const images=[expanded,mask].map((svg,i)=>{const rendered=new Resvg(inlineFontVarForRaster(svg),{background:'#ffffff',fitTo:{mode:'zoom',value:zoom},font:{fontFiles,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();save(`marker-${i?'mask':'full'}.svg`,svg);save(`marker-${i?'mask':'full'}.png`,rendered.asPng());return{width:rendered.width,height:rendered.height,pixels:rendered.pixels}})
 const [a,b]=images;assert.equal(a.width,b.width);assert.equal(a.height,b.height);let changed=0,unattributed=0,borrowed=0,outsideViewport=0
 for(let y=0;y<a.height;y++)for(let x=0;x<a.width;x++){const p=(y*a.width+x)*4;if(![0,1,2,3].some(k=>Math.abs(a.pixels[p+k]-b.pixels[p+k])>=4))continue;changed++;const wx=(x+.5)/zoom-margin,wy=(y+.5)/zoom-margin;if(wx<0||wx>width||wy<0||wy>height)outsideViewport++;const owners=rois.filter(r=>wx>=r.roi.x0&&wx<=r.roi.x1&&wy>=r.roi.y0&&wy<=r.roi.y1);if(!owners.length){unattributed++;continue}if(owners.length>1)borrowed++;for(const owner of owners){owner.changed++;if(a.pixels[p]+a.pixels[p+1]+a.pixels[p+2]<b.pixels[p]+b.pixels[p+1]+b.pixels[p+2])owner.darker++;else owner.lighter++}}
 const report={publicCalls:0,offlineRasterCalls:2,source:'after.svg.gz',svgSha256:createHash('sha256').update(raw).digest('hex'),controls:rois,changed,unattributed,borrowed,outsideViewport,withoutPositiveInk:rois.filter(r=>!r.darker).map(r=>r.id),fonts:fonts.map(f=>({file:f.file,bytes:f.bytes,sha256:f.sha256})),scope:'Exact saved cyclic9 Agentic final SVG; remove marker-end from all23 carriers and attribute changed pixels to independently transformed actual arrow resource bounds. Positive per-head differential ink only, with overlap/unattributed/negative observations retained. No individual glyph, universal font, browser, timing, complete Native proof or arbitrary input claim.'};save('marker-ink.json',report);console.log(JSON.stringify({...report,controls:rois.map(r=>({id:r.id,darker:r.darker,lighter:r.lighter})),fonts:undefined}))
}finally{fs.rmSync(scratch,{recursive:true,force:true})}
