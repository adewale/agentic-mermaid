import fs from 'node:fs'
Bun.plugin({name:'original-producer-without-prefit',setup(build){build.onLoad({filter:/\/src\/layout\/agentic-producer-core\.ts$/},args=>({contents:fs.readFileSync('/tmp/pr449-week-comparison-20261101/flow-fit-precleanup-7a8c58917/producer-before.ts','utf8'),loader:'ts'}))}})
