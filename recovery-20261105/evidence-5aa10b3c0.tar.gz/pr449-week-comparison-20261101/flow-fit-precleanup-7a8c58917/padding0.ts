import fs from 'node:fs'
import {gzipSync} from 'node:zlib'
import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const dir='/tmp/pr449-week-comparison-20261101/flow-fit-precleanup-7a8c58917',arm=process.argv[2],source='flowchart LR\nA -->|first| B\nA -->|second| B',options={padding:0,nodeSpacing:0,layerSpacing:0,graphLayout:{backend:'agentic' as const,fallback:'none' as const},embedFontImport:false}
let result
try{const r=renderMermaidSVGWithReceipt(source,options);fs.writeFileSync(`${dir}/padding0-${arm}.svg.gz`,gzipSync(r.svg));fs.writeFileSync(`${dir}/padding0-${arm}.receipt.json.gz`,gzipSync(JSON.stringify(r.receipt)));result={source,options,status:'returned',result:r}}
catch(error){result={source,options,status:'refused',error:{name:error.name,message:error.message,stack:error.stack,code:error.code,cause:error.cause?{name:error.cause.name,message:error.cause.message,stack:error.cause.stack,code:error.cause.code}:undefined}}}
const raw=JSON.stringify(result);fs.writeFileSync(`${dir}/padding0-${arm}.json.gz`,gzipSync(raw));console.log(JSON.stringify({arm,publicSVGCalls:1,fullyConsumedBytes:Buffer.byteLength(raw),status:result.status,error:result.error,proof:result.result?.receipt.layoutCertification}))
