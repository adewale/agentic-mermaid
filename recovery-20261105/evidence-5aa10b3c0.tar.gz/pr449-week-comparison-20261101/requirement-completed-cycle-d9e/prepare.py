from pathlib import Path
p=Path('/tmp/pr449-week-comparison-20261101/requirement-completed-cycle-d9e')
def read(n): return (p/'original'/n).read_text()
def put(n,s): (p/n).write_text(s)
def replace(s,a,b):
 assert a in s,a
 return s.replace(a,b,1)
n='agentic-producer-core.ts';s=read(n)
s=replace(s,"    const placed = layoutRawGraph(input, forest, unsupported, routingWork)\n    const final = input.placementOnly ? placed : finalizeFlatMeasuredMarkers(input, placed, routingWork, MAX_EXPANDED_VERTICES, unsupported)\n    return input.placementOnly ? final : shortenMeasuredRoutes(input, final)","""    const shortening = { attempts: 512, comparisons: 8_000_000 }
    let completed = false
    const finish = (candidate: AgenticLayout, fail: (reason: string) => never, work: ChannelWork): AgenticLayout => {
      const final = finalizeFlatMeasuredMarkers(input, candidate, work, MAX_EXPANDED_VERTICES, fail)
      const result = fitMeasuredLayout(input, shortenMeasuredRoutes(input, final, shortening))
      completed = true
      return result
    }
    const placed = layoutRawGraph(input, forest, unsupported, routingWork, undefined, input.placementOnly ? undefined : finish)
    if (completed || input.placementOnly) return placed
    const final = finalizeFlatMeasuredMarkers(input, placed, routingWork, MAX_EXPANDED_VERTICES, unsupported)
    return shortenMeasuredRoutes(input, final, shortening)""")
put(n,s)
n='agentic-layered-core.ts';s=read(n)
s=replace(s,'interface Vertex {',"export type CompleteMeasuredCandidate = (candidate: AgenticLayout, fail: (reason: string) => never, work: ChannelWork) => AgenticLayout\n\ninterface Vertex {")
s=replace(s,'  searchWork: LayoutSearchWork = { attempts: 128, scorePairs: 8_000_000, loopPairs: 2_000_000, rankPairs: 200_000, blockPairs: 2_000_000, routing: { pairs: 500_000, arcs: 32768, swaps: 500_000 } },\n): AgenticLayout {','  searchWork: LayoutSearchWork = { attempts: 128, scorePairs: 8_000_000, loopPairs: 2_000_000, rankPairs: 200_000, blockPairs: 2_000_000, routing: { pairs: 500_000, arcs: 32768, swaps: 500_000 } },\n  complete?: CompleteMeasuredCandidate,\n): AgenticLayout {')
s=replace(s,'  if (hasLoops) {',"""  // Root-only comparison sees authored loop routes, never private helpers.
  if (complete && hasLoops && !partitioned && nodes.length <= 48 && edges.length <= 128
    && searchWork.rankPairs >= nodes.length + 2 * edges.length) {
    searchWork.rankPairs -= nodes.length + 2 * edges.length
    let loopCount = 0, span = 0
    for (const edge of edges) { const loop = edge.source === edge.target; loopCount += Number(loop); span += edge.minSpan * (loop ? 2 : 1) }
    if (nodes.length + loopCount <= 48 && edges.length + loopCount <= 128 && span <= 128) {
      const degrees = new Uint32Array(indegree), queue = new Uint32Array(nodes.length)
      let tail = 0
      for (let node = 0; node < nodes.length; node++) if (degrees[node] === 0) queue[tail++] = node
      for (let cursor = 0; cursor < tail; cursor++) for (const index of outgoing[queue[cursor]!]!) {
        const target = edges[index]!.target
        if (--degrees[target]! === 0) queue[tail++] = target
      }
      if (tail !== nodes.length) return layoutCyclicGraph(input, incoming, outgoing,
        (flat, fail, work) => layoutLayeredGraph(flat, forestLayout, fail, work, searchWork),
        unsupported, routingWork, searchWork, complete)
    }
  }

  if (hasLoops) {""")
s=replace(s,'      unsupported, routingWork, searchWork)\n  }\n  const incomingWeight','      unsupported, routingWork, searchWork, complete)\n  }\n  const incomingWeight')
put(n,s)
n='shorten-measured-routes.ts';s=read(n)
s=replace(s,'export function shortenMeasuredRoutes(input: MeasuredGraph, placed: AgenticLayout): AgenticLayout {','export function shortenMeasuredRoutes(input: MeasuredGraph, placed: AgenticLayout, work?: { attempts: number; comparisons: number }): AgenticLayout {')
s=replace(s,'  let attempts = 512, comparisons = 8_000_000\n  const chargeContact', '  let attempts = Math.min(512, work?.attempts ?? 512), comparisons = Math.min(8_000_000, work?.comparisons ?? 8_000_000)\n  try {\n  if (attempts <= 0 || comparisons <= 0) return placed\n  const chargeContact')
s=replace(s,'  return placed\n}', '  return placed\n  } finally {\n    if (work) { work.attempts = Math.min(work.attempts, attempts); work.comparisons = Math.min(work.comparisons, comparisons) }\n  }\n}')
put(n,s)
n='cycle-layout-search.ts';s=read(n)
s=replace(s,"import type { AgenticLayout, MeasuredGraph }", "import type { AgenticLayout, MeasuredGraph, CompleteMeasuredCandidate }")
s=replace(s,'class OptionalOrderDecline extends Error {}',"""class OptionalOrderDecline extends Error {}

// NONSHIPPING: observations reuse the existing restoration/scoring traversals.
export const completedCycleObservations: { rawArea: number; rawBends: number; completedArea: number; completedBends?: number; crossings?: number }[] = []""")
s=replace(s,'  search: LayoutSearchWork,\n): AgenticLayout {','  search: LayoutSearchWork,\n  complete?: CompleteMeasuredCandidate,\n): AgenticLayout {')
s=replace(s,'  const place = (order:', '  let observed: AgenticLayout | undefined\n  const place = (order:')
s=replace(s,'    return { ...moved, nodes:', '    let rawBends = 0\n    const restored = { ...moved, nodes:')
s=replace(s,'        const route = moved.edges[edgeIndices[index]!]!\n        return reversed[index]', '        const route = moved.edges[edgeIndices[index]!]!\n        rawBends += edges[index]!.visible === false ? 0 : Math.max(0, route.points.length - 2)\n        return reversed[index]')
s=replace(s,'      }) }\n  }',"""      }) }
    if (!complete) return restored
    const rawArea = restored.width * restored.height
    const result = complete(restored, fail, work)
    completedCycleObservations.push({ rawArea, rawBends, completedArea: result.width * result.height })
    observed = result
    return result
  }""")
s=replace(s,'    return countPolylineCrossings(candidate.edges.map((route, index) => ({ ...route, visible: edges[index]!.visible })))','    const result = countPolylineCrossings(candidate.edges.map((route, index) => ({ ...route, visible: edges[index]!.visible })))\n    if (complete && observed === candidate) completedCycleObservations.at(-1)!.crossings = result\n    return result')
s=replace(s,'  if (bestScore === undefined || bestScore === 0) return best',"""  if (bestScore === undefined) return best
  let opposite: Int32Array | undefined
  if (bestScore === 0) {
    if (!complete) return best
    let cut: MeasuredGraph['edges'][number] | undefined
    for (const edge of edges) if (primary[edge.source]! > primary[edge.target]!) {
      if (cut) return best
      cut = edge
    }
    if (!cut) return best
    search.rankPairs -= nodes.length + edges.length
    if (search.rankPairs < 0) return best
    opposite = Int32Array.from(primary)
    const before = primary[cut.target]!, after = primary[cut.source]!
    for (let node = 0; node < nodes.length; node++) if (primary[node]! >= before && primary[node]! < after) opposite[node] = primary[node]! + 1
    opposite[cut.source] = before
    if (feedbackCount(opposite) !== 1) return best
  }""")
s=replace(s,"  const bendCount = (candidate: AgenticLayout): number => candidate.edges.reduce((sum, route, index) =>\n    sum + (edges[index]!.visible === false ? 0 : Math.max(0, route.points.length - 2)), 0)","""  const bendCount = (candidate: AgenticLayout): number => {
    const result = candidate.edges.reduce((sum, route, index) =>
      sum + (edges[index]!.visible === false ? 0 : Math.max(0, route.points.length - 2)), 0)
    if (complete && observed === candidate) completedCycleObservations.at(-1)!.completedBends = result
    return result
  }""")
s=replace(s,'  let localAttempts = input.compactPrivateRanks', '  let localAttempts = opposite ? 1 : input.compactPrivateRanks')
s=replace(s,'  const starts = nodes.length <= 12', '  const starts = opposite ? [] : nodes.length <= 12')
s=replace(s,'  const diversify = input.compactPrivateRanks','  const diversify = !opposite && input.compactPrivateRanks')
s=replace(s,'  const orders = [...cutOrders, greedy, model, ...shifted, Uint32Array.from(nodes, (_, index) => index)]', '  const orders = opposite ? [opposite] : [...cutOrders, greedy, model, ...shifted, Uint32Array.from(nodes, (_, index) => index)]')
s=replace(s,'  const permutations = cuts.length ?', '  const permutations = opposite ? [[false, false]] as const : cuts.length ?')
put(n,s)
