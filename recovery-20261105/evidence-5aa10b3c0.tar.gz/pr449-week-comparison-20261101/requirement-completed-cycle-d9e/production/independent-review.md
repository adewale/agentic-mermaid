Independent review of saved production Requirement SVGs

No public render or source/test change. Reused independent-meaning.py and existing local resvg/font tooling; four final SVGs checked offline. Detailed machine results are independent-vector-review.json and independent-ink-review.json; exact review scripts and expanded full/mask PNGs are alongside them.

The expected meaning comes from the fixed source: fast/suite/report, ten rendered card text elements (including authored fields), five ordered relationships and captions verifies/traces/derives/satisfies/refines, parallel suite→fast, reciprocal fast↔report, and fast self-loop. No cardinality or note is authored. All four SVGs retain those literals/owners, five dashed relationship carriers, five hollow triangular target-head resource references, and ten normal card contacts. Self-loop contacts are distinct. Serialized axis-aligned centerlines enter no card interior or foreign caption interior. This is a nominal geometry check, complemented by the ink controls below.

| Direction | Viewport | Area px² | Wire px | Turns | Physical card bands | Nonself backward relationship | Paint operations / 400000 |
|---|---|---:|---:|---:|---:|---|---:|
| TB | 461.893 × 499.45 | 230692.45885 | 671.19767 | 8 | 2 | derives | 102013 |
| BT | 461.893 × 499.45 | 230692.45885 | 671.19767 | 8 | 2 | derives | 101660 |
| LR | 970.194 × 251.95 | 244440.37830 | 947.6 | 6 | 3 | satisfies | 101806 |
| RL | 970.194 × 251.95 | 244440.37830 | 947.6 | 6 | 3 | satisfies | 101657 |

All four raw receipts are passed with five markers and unchanged 400000-operation cap. TB/BT preserve the 96.3 px inter-band gap. Their nominal frame/shaft margins remain 32–34 px. Against retained final-2fa actual SVGs, TB/BT area falls 18.2214%; wire rises 3.9879%, an explicit adverse tradeoff, with turns unchanged. LR/RL retain identical actual geometry and byte-identical whole SVGs, including prefix/style scope. Their only entire-receipt difference against that older revision is checks.operations; do not attribute legacy proof-count drift to this candidate. Production TB and LR are byte-identical to their respective prototype SVGs AND have identical entire receipts. BT/RL have no prototype product here.

Actual ink: rendered each saved final SVG at 2× using checked-in Inter Regular/Medium/SemiBold/Bold; all four files' byte lengths and SHA256 were checked against the hosted-font manifest, with system fonts disabled. Three offline rasters per direction (12 total): full expanded canvas, all text hidden, and target markers removed. Each of 15 physical text elements (ten card elements plus five captions) has positive darker contribution in its own row/pill ROI: minimum 633 pixels. Each of five target heads contributes 112–130 darker pixels in its own target ROI. Text and marker differential ink stays inside those respective ROIs. Expanded canvases show zero dark pixels beyond each original viewport. Full TB/BT/LR/RL rasters were visually inspected: authored fields/captions and open arrowheads remain readable; no observed clipping or foreign crossing. The existing offset refines caption policy is retained, not a new label-seating claim.

Limits: fixed normal Inter faces/resvg, actual saved default-style SVGs only; no browser/universal-font, per-glyph isolation, arbitrary-style, or broader family/capacity claim. The pixel scan uses dark threshold <245 and differential darkness >4; nominal line/box checks are not a general rounded-path collision oracle. These reports preserve the measured wire adverse and older-revision proof caveat.
