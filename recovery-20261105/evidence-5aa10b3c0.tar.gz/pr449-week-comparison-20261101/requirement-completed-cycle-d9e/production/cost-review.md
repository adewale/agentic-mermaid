# Completed-cycle cost review

Offline review of the two completed 12-call reports: Agentic Requirement TB target
and LR control, d9e before versus frozen candidate. Before loads four saved d9e
modules; current uses production without overlays. N=1 per cell. Imports are
separately timed; phase time fully consumes SVG and the ENTIRE public receipt,
and excludes forced post-phase GC and artifact compression. Three products remain
held per worker. These observations support no speed, allocation or memory claim.

All 24 calls returned P, with no errors. All eight same-arm repeats match their own
cold whole SVG and ENTIRE raw receipt. Cache-on has four actual positioned-layout
hits; all four edits miss. Cache-off bypasses that cache. LR before/current whole
SVG and ENTIRE receipts match in all six phase pairs. The final relation retains
identity relation-5, endpoints fast→fast, and changes its actual type, caption and
ARIA label from refines to traces on edit. No lost authored relation was found.

Cold/repeat/edit elapsed ms and worker peak RSS KiB, before → current:

| Mode / case | Elapsed ms | Peak RSS KiB |
|---|---|---|
| Off / TB | 147.46/26.79/33.21 → 224.79/58.90/44.45 | 120108 → 108848 |
| Off / LR | 202.88/56.26/37.35 → 227.99/52.67/44.41 | 108140 → 106584 |
| On / TB | 460.65/106.84/82.21 → 191.15/63.56/44.19 | 119300 → 105312 |
| On / LR | 213.86/72.89/43.43 → 212.58/60.79/51.46 | 107220 → 107288 |

Cache-off TB is adverse in every phase: Agentic search cold/repeat
14.77/2.36 → 20.71/7.78 ms, drawing 77.31/13.84 → 114.52/31.09 ms.
Cache-on reverses the overall timing direction amid substantial N1 variation.
LR off cold/edit and on edit are adverse too. No favorable reruns or timing ratios.

Post-GC RSS and heap MiB, cold/repeat/edit, before → current:

| Mode / case | RSS MiB | Heap MiB |
|---|---|---|
| Off / TB | 112.29/115.79/117.15 → 99.15/100.67/105.79 | 15.43/16.18/16.94 → 15.53/16.35/17.23 |
| Off / LR | 99.36/101.30/105.22 → 99.41/98.96/103.71 | 15.34/16.01/16.77 → 15.41/16.20/16.99 |
| On / TB | 109.88/110.55/113.25 → 100.50/100.47/102.34 | 15.54/16.07/17.00 → 15.66/16.21/17.13 |
| On / LR | 97.43/100.68/104.45 → 99.59/99.84/104.26 | 15.45/16.02/16.84 → 15.51/16.05/17.00 |

Every current post-GC heap observation increases. RSS is mixed, including adverse
LR cold observations and the cache-on peak. Lower TB RSS does not establish a
memory win.

Current paid TB proof is P102013 cold/repeat and P102332 edit, versus d9e
P102024/P102305; pairs 94→88, conditional 0 throughout. LR paid proofs remain
P101806/P102126. The historical f0fad prototype's P105308 is not the current ledger.
Only TB viewport, pair/operation counts and output/projection digests change in
the public receipts. This delivers geometry improvement, not proof capacity.

Actual TB area 282093.76798→230692.45885 px² (−18.22%), wire
645.4576→671.197666666 px (+3.99%), bends 8→8. The bounded completed-layout
alternative remains 10.43% smaller and 30.34% shorter than retained ELK.
Current LR remains area244440.3783/wire947.6/bends6 exactly, avoiding the old
f0fad prototype's horizontal regression on this control. Keep the area/wire
tradeoff and all adverse runtime/heap observations visible.

Raw products, entire receipts, stages, cache events and exact memory deltas remain
in `requirement-completed-cycle-cache{0,1}-cost-d9e31feb9/RESULTS.json.gz` and
`SUMMARY.json.gz`; combined evidence is cache0 `FINAL-EVIDENCE.json.gz`.
