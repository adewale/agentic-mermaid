import fs from 'node:fs'
import {createHash} from 'node:crypto'
import {gzipSync,gunzipSync} from 'node:zlib'
import {createRequire} from 'node:module'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const {JSDOM}=createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
const root='/tmp/pr449-main-integration-20261029-762',base='/tmp/pr449-week-comparison-20261101/requirement-completed-cycle-d9e/production',scratch=fs.mkdtempSync('/tmp/pr449-completed-fonts-')
try{
 const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter'),fontFiles=fonts.map(f=>{const b=fs.readFileSync(`${root}/${f.path}`);if(b.length!==f.bytes||createHash('sha256').update(b).digest('hex')!==f.sha256)throw Error('font mismatch');const p=`${scratch}/${f.file}`;fs.writeFileSync(p,b);return p})
 const rows=[]
 for(const direction of ['TB','BT','LR','RL']){
  const svg=gunzipSync(fs.readFileSync(`${base}/${direction}/actual.svg.gz`)).toString(),dom=new JSDOM(svg,{contentType:'image/svg+xml'}),d=dom.window.document,w=+d.documentElement.getAttribute('width'),h=+d.documentElement.getAttribute('height'),margin=20,zoom=2
  try{
   const textROIs=[...d.querySelectorAll('text')].map(t=>{const g=t.parentElement,r=g.querySelector('rect'),font=+(t.getAttribute('font-size')||13),spans=[...t.querySelectorAll('tspan')];let baselines:number[]=[];let y=+t.getAttribute('y');if(spans.length){for(const s of spans){y+=+(s.getAttribute('dy')||0);baselines.push(y)}}else baselines=[y+(+(t.getAttribute('dy')||0))];return {owner:g.getAttribute('data-id')||g.getAttribute('data-edge-id'),text:t.textContent,x:+r.getAttribute('x'),y:Math.min(...baselines)-font*1.2,w:+r.getAttribute('width'),h:Math.max(...baselines)-Math.min(...baselines)+font*1.6}})
   const heads=[...d.querySelectorAll('[data-role="relationship"]')].map(e=>{const ps=e.getAttribute('points').trim().split(/\s+/).map(p=>p.split(',').map(Number)),[x,y]=ps.at(-1);return {owner:e.getAttribute('data-id'),x:x-12,y:y-12,w:24,h:24}})
   const expanded=svg.replace(/width="[^"]+"/,`width="${w+40}"`).replace(/height="[^"]+"/,`height="${h+40}"`).replace(/viewBox="[^"]+"/,`viewBox="-20 -20 ${w+40} ${h+40}"`)
   const variants={full:expanded,noText:expanded.replace(/<text\b/g,'<text opacity="0"'),noHeads:expanded.replace(/ marker-end="[^"]+"/g,'')},images:any={}
   for(const [kind,s]of Object.entries(variants)){const r=new Resvg(inlineFontVarForRaster(s),{background:'#fff',fitTo:{mode:'zoom',value:zoom},font:{fontFiles,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();images[kind]={width:r.width,height:r.height,pixels:r.pixels};fs.writeFileSync(`${base}/${direction}/independent-${kind}.png.gz`,gzipSync(r.asPng()));if(kind==='full')fs.writeFileSync(`${base}/${direction}/independent-full.png`,r.asPng())}
   const textInk=textROIs.map(r=>({...r,darker:0})),headInk=heads.map(r=>({...r,darker:0}));let outsideViewport=0,headDiffOutsideROIs=0,textDiffOutsideROIs=0,inkBox={left:Infinity,top:Infinity,right:-Infinity,bottom:-Infinity}
   const a=images.full
   for(let py=0;py<a.height;py++)for(let px=0;px<a.width;px++){
    const i=(py*a.width+px)*4,x=(px+.5)/zoom-margin,y=(py+.5)/zoom-margin,sum=a.pixels[i]+a.pixels[i+1]+a.pixels[i+2],inside=(r:any)=>x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h
    if(a.pixels[i]<245||a.pixels[i+1]<245||a.pixels[i+2]<245){inkBox.left=Math.min(inkBox.left,x);inkBox.top=Math.min(inkBox.top,y);inkBox.right=Math.max(inkBox.right,x);inkBox.bottom=Math.max(inkBox.bottom,y);if(x<0||y<0||x>w||y>h)outsideViewport++}
    if(sum<images.noText.pixels[i]+images.noText.pixels[i+1]+images.noText.pixels[i+2]-4){let owned=false;for(const r of textInk)if(inside(r)){r.darker++;owned=true}if(!owned)textDiffOutsideROIs++}
    if(sum<images.noHeads.pixels[i]+images.noHeads.pixels[i+1]+images.noHeads.pixels[i+2]-4){let owned=false;for(const r of headInk)if(inside(r)){r.darker++;owned=true}if(!owned)headDiffOutsideROIs++}
   }
   if(textInk.length!==15||headInk.length!==5||textInk.some(r=>!r.darker)||headInk.some(r=>!r.darker)||outsideViewport||headDiffOutsideROIs||textDiffOutsideROIs)throw Error(JSON.stringify({direction,textInk,headInk,outsideViewport,headDiffOutsideROIs,textDiffOutsideROIs}))
   rows.push({direction,raster:[a.width,a.height],texts:textInk,heads:headInk,inkBox,outsideViewport,headDiffOutsideROIs,textDiffOutsideROIs})
  }finally{dom.window.close()}
 }
 const report={publicCalls:0,offlineRasterCalls:12,zoom:2,canvasExpansion:20,fontVerification:'Each normal Inter file byte length and SHA256 checked against current checked-in hosted manifest; no system fonts loaded.',fonts:fonts.map(({file,bytes,sha256})=>({file,bytes,sha256})),rows,scope:'Saved actual final SVG, fixed normal Inter faces, whole-text and marker-end differential controls. Each of 15 authored text elements and five target heads has positive darker pixel contribution in its physical owned ROI. Expanded-canvas check finds no dark pixel beyond original viewport. CSS font vars inlined only for resvg; no browser/font-universal, glyph-by-glyph, arbitrary-style or future input capacity claim.'}
 fs.writeFileSync(`${base}/independent-ink-review.json`,JSON.stringify(report,null,2));console.log(JSON.stringify({...report,rows:rows.map(r=>({...r,texts:r.texts.map(t=>({owner:t.owner,text:t.text,darker:t.darker})),heads:r.heads.map(h=>({owner:h.owner,darker:h.darker}))}))}))
}finally{fs.rmSync(scratch,{recursive:true,force:true})}
