import json,gzip,math,pathlib,xml.etree.ElementTree as E,subprocess
base=pathlib.Path('/tmp/pr449-week-comparison-20261101');out=base/'requirement-completed-cycle-d9e/production';N='{http://www.w3.org/2000/svg}'
load=lambda p:json.load(gzip.open(p,'rt') if str(p).endswith('.gz') else open(p))
meaning=json.loads(subprocess.check_output(['python',str(base/'requirement-kind-order-f1e/independent-meaning.py')]+[str(out/d/'RESULT.json.gz') for d in ['TB','BT','LR','RL']]))
def diff(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):return sum([diff(a.get(k),b.get(k),path+'.'+k) for k in sorted(a.keys()|b.keys())],[])
 if isinstance(a,list):return [path] if len(a)!=len(b) else sum([diff(x,y,path+f'[{i}]') for i,(x,y) in enumerate(zip(a,b))],[])
 return [] if a==b else [path]
def box(e):return tuple(float(e.get(k)) for k in ['x','y','width','height'])
def enters(a,b,r):
 x,y,w,h=r
 if a[0]==b[0]:return x+1e-7<a[0]<x+w-1e-7 and max(min(a[1],b[1]),y)<min(max(a[1],b[1]),y+h)-1e-7
 return y+1e-7<a[1]<y+h-1e-7 and max(min(a[0],b[0]),x)<min(max(a[0],b[0]),x+w)-1e-7
rows=[]
for d,m in zip(['TB','BT','LR','RL'],meaning):
 p=load(out/d/'RESULT.json.gz');s=p['product']['svg'];r=E.fromstring(s);cards={g.get('data-id'):box(g.find(N+'rect')) for g in r.iter(N+'g') if 'requirement-node' in g.get('class','').split()};pills={g.get('data-edge-id'):box(g.find(N+'rect')) for g in r.iter(N+'g') if g.get('class')=='requirement-edge-label'}
 routes=[e for e in r.iter() if e.get('data-role')=='relationship'];points=[[(float(x),float(y)) for x,y in [p.split(',') for p in e.get('points').split()]] for e in routes]
 cardHits=[];pillHits=[];feedback=[];axis=1 if d in ['TB','BT'] else 0;sign=1 if d in ['TB','LR'] else -1
 for e,pts in zip(routes,points):
  for a,b in zip(pts,pts[1:]):
   for k,v in cards.items():
    if enters(a,b,v):cardHits.append([e.get('data-id'),k,a,b])
   for k,v in pills.items():
    if k!=e.get('data-id') and enters(a,b,v):pillHits.append([e.get('data-id'),k,a,b])
  if e.get('data-from')!=e.get('data-to') and sign*(pts[-1][axis]-pts[0][axis])<0:feedback.append(e.get('data-relationship'))
 assert not cardHits and not pillHits,(d,cardHits,pillHits)
 intervals=sorted((b[axis],b[axis]+b[axis+2],k) for k,b in cards.items());bands=[]
 for a,b,k in intervals:
  if not bands or a>=bands[-1]['end']-1e-6:bands.append({'start':a,'end':b,'cards':[k]})
  else:bands[-1]['end']=max(bands[-1]['end'],b);bands[-1]['cards'].append(k)
 corners=[(v[0],v[1]) for v in list(cards.values())+list(pills.values())]+[(v[0]+v[2],v[1]+v[3]) for v in list(cards.values())+list(pills.values())]+sum(points,[])
 margins=[min(x for x,y in corners),min(y for x,y in corners),m['width']-max(x for x,y in corners),m['height']-max(y for x,y in corners)]
 old=load(base/f'final-2fa-requirement-{d}-agentic.json');oldsvg=old['svg'];oldroot=E.fromstring(oldsvg);ov=list(map(float,oldroot.get('viewBox').split()));oldpts=[[(float(x),float(y)) for x,y in [p.split(',') for p in e.get('points').split()]] for e in oldroot.iter() if e.get('data-role')=='relationship'];oldwire=sum(math.dist(a,b) for ps in oldpts for a,b in zip(ps,ps[1:]));oldturns=sum(len(ps)-2 for ps in oldpts)
 compare={'baselineSourceEqual':p['source']==old['source'],'oldArea':ov[2]*ov[3],'areaChangePercent':100*(m['area']/(ov[2]*ov[3])-1),'oldWire':oldwire,'wireChangePercent':100*(m['wire']/oldwire-1),'oldTurns':oldturns,'wholeSvgEqual':s==oldsvg,'receiptDifferences':diff(p['product']['receipt'],old['svgReceipt'])}
 if d in ['TB','LR']:
  proto=load(out.parent/d/'RESULT.json.gz');compare['prototypeSvgEqual']=s==proto['product']['svg'];compare['prototypeEntireReceiptEqual']=p['product']['receipt']==proto['product']['receipt'];compare['prototypeReceiptDifferences']=diff(p['product']['receipt'],proto['product']['receipt'])
 proof=p['product']['receipt']['layoutCertification'];rows.append({**m,'bands':bands,'bandGaps':[b['start']-a['end'] for a,b in zip(bands,bands[1:])],'feedbackNonself':feedback,'nominalMargins':margins,'foreignCardIntersections':cardHits,'foreignCaptionIntersections':pillHits,'certification':proof,'comparison':compare})
report={'publicCalls':0,'sourceContract':'Fixed authored suite/fast/report, ten text literals, five ordered typed relationships/captions, including parallel, reciprocal and self-loop; no cardinality or note authored.','rows':rows,'limitations':'Serialized axis-aligned centerline/open-frame intersection checks; painted ink assessed separately by pinned-Inter raster, not a universal font/browser or arbitrary-style guarantee. Legacy final-2fa receipts are a different source revision; proof-operation differences are recorded without attributing them to this candidate.'}
(out/'independent-vector-review.json').write_text(json.dumps(report,indent=2))
print(json.dumps([{k:v for k,v in x.items() if k in ['area','wire','bends','bands','bandGaps','feedbackNonself','nominalMargins','comparison']} for x in rows],indent=2))
