import { readFileSync, writeFileSync, writeSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import { createHash } from 'node:crypto'
const root='/tmp/pr449-main-integration-20261029-762',base='/tmp/pr449-week-comparison-20261101/requirement-completed-cycle-d9e'
const arm=process.argv[2],out=base+'/'+arm
if(!['TB','LR'].includes(arm))throw new Error('Expected baseline/candidate; no call started')
if(process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS!=='0'||process.env.AGENTIC_MERMAID_ELK_CACHE!=='0')throw new Error('Expected assertions0/cache0')
let overlayLoads=0
Bun.plugin({name:'completed-cycle-pipeline-only',setup(build){build.onLoad({filter:/\/src\/layout\/(agentic-producer-core|agentic-layered-core|cycle-layout-search|shorten-measured-routes)\.ts$/},args=>{
 if(!args.path.startsWith(root+'/src/layout/'))return
 overlayLoads++
 return {contents:readFileSync(base+'/'+args.path.slice(args.path.lastIndexOf('/')+1),'utf8'),loader:'ts'}
})}})
const wallStart=performance.now(),cpuStart=process.cpuUsage()
const log=(value:unknown)=>writeSync(1,JSON.stringify(value)+'\n')
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const {withRenderStageObserver}=await import(root+'/src/render-stages.ts')
const {withPerformanceObserver}=await import(root+'/src/performance-observations.ts')
const {completedCycleObservations}=await import(root+'/src/layout/cycle-layout-search.ts')
const {apiFailure}=await import(root+'/eval/layout-compare/outcomes.ts')
const source=readFileSync(root+'/eval/layout-compare/fixtures/requirement-backends.mmd','utf8').replace('direction TB','direction '+arm)
const options={graphLayout:{backend:'agentic' as const,fallback:'none' as const},embedFontImport:false,idPrefix:'recovery-'}
const importMs=performance.now()-wallStart,stages:any[]=[],events:any[]=[]
const loadedMemory=process.memoryUsage(),renderStart=performance.now(),renderCPU=process.cpuUsage()
let product:any,row:any
log({event:'ACTUAL_PUBLIC_CALL_START',arm,actualCalls:1})
try {
 const artifact=withPerformanceObserver(event=>events.push(event),()=>withRenderStageObserver(stage=>stages.push(stage),()=>renderMermaidSVGWithReceipt(source,options)))
 product={svg:artifact.svg,receipt:artifact.receipt}
 const bytes=Buffer.from(JSON.stringify(product));let checksum=0;for(const byte of bytes)checksum=(Math.imul(checksum,31)+byte)>>>0
 const old=gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/requirement-caption-843/metadata-only-TB-agentic-no-marker.svg.gz')).toString()
 writeFileSync(out+'/actual.svg.gz',gzipSync(product.svg));writeFileSync(out+'/actual.receipt.json.gz',gzipSync(JSON.stringify(product.receipt)))
 row={status:'returned',fullyConsumedBytes:bytes.length,checksum,svgSha256:createHash('sha256').update(product.svg).digest('hex'),wholeSvgExactToOldNoMarker:product.svg===old,proof:product.receipt.layoutCertification}
} catch(error:any) {
 product={normalized:apiFailure(error),name:error?.name,message:error?.message,code:error?.code,stack:error?.stack,certification:error?.certification,cause:error?.cause?{name:error.cause.name,message:error.cause.message,stack:error.cause.stack}:undefined}
 const bytes=Buffer.from(JSON.stringify(product));row={status:'refused',fullyConsumedErrorBytes:bytes.length,failure:product}
}
const packet={observedCuts:completedCycleObservations,arm,source,options,actualPublicCalls:1,overlayLoads,importMs,renderWallMs:performance.now()-renderStart,renderCPU:process.cpuUsage(renderCPU),totalWallMs:performance.now()-wallStart,totalCPU:process.cpuUsage(cpuStart),loadedMemory,afterMemory:process.memoryUsage(),peakRssKiB:process.resourceUsage().maxRSS,row,provider:events.filter(e=>e.owner==='paint-certification'),stages,events,product}
writeFileSync(out+'/RESULT.json.gz',gzipSync(JSON.stringify(packet)))
log({event:'ACTUAL_PUBLIC_CALL_COMPLETE',...packet,product:undefined,events:undefined})
