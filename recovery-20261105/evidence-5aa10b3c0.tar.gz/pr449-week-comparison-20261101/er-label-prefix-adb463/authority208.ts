import fs from 'node:fs'
import {gunzipSync} from 'node:zlib'
import {createRequire} from 'node:module'
import assert from 'node:assert/strict'
const dir='/tmp/pr449-week-comparison-20261101/er-label-prefix-adb463'
const {JSDOM}=createRequire('/tmp/pr449-main-integration-20261029-762/package.json')('jsdom')
const packet=JSON.parse(gunzipSync(fs.readFileSync(dir+'/CURRENT208.json.gz')).toString())
const svg=gunzipSync(fs.readFileSync(dir+'/CURRENT208.svg.gz')).toString()
assert.equal(svg,packet.outcome.result.svg)
const source='erDiagram\ndirection LR\n'+Array.from({length:207},(_,i)=>`N${i} ||--o{ N${i+1} : owns`).join('\n')
assert.equal(packet.source,source)
assert.deepEqual(packet.options,{graphLayout:{backend:'elk',fallback:'none'}})
const dom=new JSDOM(svg,{contentType:'image/svg+xml'})
const doc=dom.window.document
const attr=(e:Element,n:string)=>e.getAttribute(n)
const n=(e:Element,key:string)=>Number(attr(e,key))
const boxes=new Map<string,{x:number;y:number;width:number;height:number;half:number}>()
for(const e of [...doc.querySelectorAll('rect[data-id]')] as Element[]){
 const id=attr(e,'data-id')!;if(!id.startsWith('entity-rect:'))continue
 boxes.set(id.slice(12),{x:n(e,'x'),y:n(e,'y'),width:n(e,'width'),height:n(e,'height'),half:n(e,'stroke-width')/2})
}
assert.deepEqual([...boxes.keys()].toSorted(),Array.from({length:208},(_,i)=>`N${i}`).toSorted())
const ids=[...doc.querySelectorAll('[data-id]')].map((e:Element)=>attr(e,'data-id'))
assert.equal(new Set(ids).size,ids.length)
const rels=[...doc.querySelectorAll('polyline.er-relationship')] as Element[]
const marks=[...doc.querySelectorAll('g[data-role="cardinality"]')] as Element[]
const captions=[...doc.querySelectorAll('text')].filter((e:Element)=>e.textContent==='owns') as Element[]
assert.equal(rels.length,207);assert.equal(marks.length,414);assert.equal(captions.length,207)
const point=(s:string)=>{const [x,y]=s.split(',').map(Number);return{x:x!,y:y!}}
const routes=rels.map(e=>attr(e,'points')!.split(/\s+/).map(point))
const overlaps=(a:number[],b:number[])=>a[0]!<b[2]!&&a[2]!>b[0]!&&a[1]!<b[3]!&&a[3]!>b[1]!
const markBoxes=marks.flatMap(m=>[...m.children].map((p:Element)=>{
 const half=n(p,'stroke-width')/2
 return p.localName==='circle'?[n(p,'cx')-n(p,'r')-half,n(p,'cy')-n(p,'r')-half,n(p,'cx')+n(p,'r')+half,n(p,'cy')+n(p,'r')+half]:[Math.min(n(p,'x1'),n(p,'x2'))-half,Math.min(n(p,'y1'),n(p,'y2'))-half,Math.max(n(p,'x1'),n(p,'x2'))+half,Math.max(n(p,'y1'),n(p,'y2'))+half]
}))
const previousPills:number[][]=[]
let normalContacts=0,rawSegments=0,foreignStrokeChecks=0,ownedMarkPieces=0,captionBodyChecks=0,captionForeignShaftChecks=0,captionPairChecks=0,captionMarkChecks=0
for(const [i,rel] of rels.entries()){
 assert.deepEqual(['data-from','data-to','data-cardinality1','data-cardinality2','data-identifying','data-label'].map(k=>attr(rel,k)),[`N${i}`,`N${i+1}`,'one','zero-many','true','owns'])
 const points=routes[i]!,rId=attr(rel,'data-id')!
 assert.ok(points.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)))
 for(const [p,q,id] of [[points[0]!,points[1]!,`N${i}`],[points.at(-1)!,points.at(-2)!,`N${i+1}`]] as const){
  const b=boxes.get(id)!,dx=q.x-p.x,dy=q.y-p.y,eps=1e-6
  assert.ok(dy===0&&(Math.abs(p.x-b.x)<eps&&dx<0||Math.abs(p.x-b.x-b.width)<eps&&dx>0)||dx===0&&(Math.abs(p.y-b.y)<eps&&dy<0||Math.abs(p.y-b.y-b.height)<eps&&dy>0),`${id} actual normal terminal`)
  normalContacts++
 }
 for(let j=1;j<points.length;j++){
  const a=points[j-1]!,b=points[j]!,half=n(rel,'stroke-width')/2
  assert.ok(a.x===b.x||a.y===b.y);rawSegments++
  for(const [owner,box] of boxes){
   const interior=a.y===b.y?a.y>box.y+1e-6&&a.y<box.y+box.height-1e-6&&Math.max(a.x,b.x)>box.x+1e-6&&Math.min(a.x,b.x)<box.x+box.width-1e-6:a.x>box.x+1e-6&&a.x<box.x+box.width-1e-6&&Math.max(a.y,b.y)>box.y+1e-6&&Math.min(a.y,b.y)<box.y+box.height-1e-6
   assert.equal(interior,false,`${i}:${j} body interior ${owner}`)
   if(owner===`N${i}`||owner===`N${i+1}`)continue
   const stroke=Math.min(a.x,b.x)-(a.x===b.x?half:0)<box.x+box.width+box.half&&Math.max(a.x,b.x)+(a.x===b.x?half:0)>box.x-box.half&&Math.min(a.y,b.y)-(a.y===b.y?half:0)<box.y+box.height+box.half&&Math.max(a.y,b.y)+(a.y===b.y?half:0)>box.y-box.half
   assert.equal(stroke,false,`${i}:${j} foreign border ${owner}`);foreignStrokeChecks++
  }
 }
 const owned=marks.filter(m=>attr(m,'data-owner-id')===rId)
 assert.equal(owned.length,2)
 for(const [end,m] of owned.entries()){
  assert.deepEqual([attr(m,'data-owner-role'),attr(m,'data-end'),attr(m,'data-endpoint')],['relationship',end?'end':'start',`N${i+end}`])
  const pieces=[...m.children] as Element[]
  assert.deepEqual(pieces.map(p=>p.localName).toSorted(),end?['circle','line','line','line']:['line','line'])
  ownedMarkPieces+=pieces.length
 }
 const caption=captions[i]!,cx=n(caption,'x'),cy=n(caption,'y'),pill=caption.previousElementSibling!
 assert.equal(pill.localName,'rect')
 assert.ok(Math.abs(n(pill,'x')+n(pill,'width')/2-cx)<1e-6&&Math.abs(n(pill,'y')+n(pill,'height')/2-cy)<1e-6)
 const owningRoute=(path:typeof points)=>path.slice(1).some((b,j)=>{const a=path[j]!;return a.x===b.x&&Math.abs(cx-a.x)<1e-6&&cy>=Math.min(a.y,b.y)&&cy<=Math.max(a.y,b.y)||a.y===b.y&&Math.abs(cy-a.y)<1e-6&&cx>=Math.min(a.x,b.x)&&cx<=Math.max(a.x,b.x)})
 assert.equal(owningRoute(points),true,`${i} caption belongs on its emitted route`)
 assert.equal(routes.filter(owningRoute).length,1,`${i} caption has one actual carrier`)
 const pillHalf=n(pill,'stroke-width')/2,pillBox=[n(pill,'x')-pillHalf,n(pill,'y')-pillHalf,n(pill,'x')+n(pill,'width')+pillHalf,n(pill,'y')+n(pill,'height')+pillHalf]
 for(const [id,body] of boxes){assert.equal(overlaps(pillBox,[body.x-body.half,body.y-body.half,body.x+body.width+body.half,body.y+body.height+body.half]),false,`${i} caption versus body ${id}`);captionBodyChecks++}
 for(const [j,path] of routes.entries())if(j!==i){
  const half=n(rels[j]!,'stroke-width')/2,b=[pillBox[0]!-half,pillBox[1]!-half,pillBox[2]!+half,pillBox[3]!+half]
  for(let k=1;k<path.length;k++){
   const p=path[k-1]!,q=path[k]!
   const enters=p.y===q.y?p.y>b[1]!&&p.y<b[3]!&&Math.max(p.x,q.x)>b[0]!&&Math.min(p.x,q.x)<b[2]!:p.x>b[0]!&&p.x<b[2]!&&Math.max(p.y,q.y)>b[1]!&&Math.min(p.y,q.y)<b[3]!
   assert.equal(enters,false,`${i} caption versus foreign shaft ${j}`);captionForeignShaftChecks++
  }
 }
 for(const other of previousPills){assert.equal(overlaps(pillBox,other),false,`${i} caption versus previous caption`);captionPairChecks++}
 for(const mark of markBoxes){assert.equal(overlaps(pillBox,mark),false,`${i} caption versus cardinality`);captionMarkChecks++}
 previousPills.push(pillBox)
}
const report={publicCalls:0,source:'CURRENT208.svg.gz',entities:boxes.size,orderedRelationships:rels.length,captionOwners:captions.length,cardinalityOwners:marks.length,ownedMarkPieces,uniqueDataIds:ids.length,normalContacts,rawSegments,foreignStrokeChecks,captionBodyChecks,captionForeignShaftChecks,captionPairChecks,captionMarkChecks,proofStatus:packet.outcome.result.receipt.layoutCertification.status,scope:'Independent authored source identities/cardinalities/identifying labels and actual SVG ownership, normal contacts, body interiors, foreign shaft borders, caption-body/foreign-shaft/pair/cardinality separation. This source has no group headers. This does not claim complete Native paint certification.'}
fs.writeFileSync(dir+'/authority208.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));dom.window.close()
