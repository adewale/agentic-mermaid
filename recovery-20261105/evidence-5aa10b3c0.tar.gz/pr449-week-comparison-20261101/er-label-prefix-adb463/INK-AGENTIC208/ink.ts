import fs from 'node:fs'
import {createHash} from 'node:crypto'
import {gzipSync,gunzipSync} from 'node:zlib'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/er-label-prefix-adb463/INK-AGENTIC208',scratch=fs.mkdtempSync('/tmp/pr449-er208-fonts-')
const save=(name,value)=>fs.writeFileSync(`${out}/${name}.gz`,gzipSync(typeof value==='string'||value instanceof Uint8Array?value:JSON.stringify(value)))
const attrs=t=>Object.fromEntries([...t.matchAll(/([\w:-]+)="([^"]*)"/g)].map(m=>[m[1],m[2]]))
try {
 const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter'),fontFiles=fonts.map(f=>{const b=fs.readFileSync(`${root}/${f.path}`);if(b.length!==f.bytes||createHash('sha256').update(b).digest('hex')!==f.sha256)throw Error('Font manifest mismatch');const p=`${scratch}/${f.file}`;fs.writeFileSync(p,b);return p})
 const raw=gunzipSync(fs.readFileSync('/tmp/pr449-week-comparison-20261101/er-label-prefix-adb463/CURRENT208-AGENTIC.svg.gz')).toString(),r=attrs(raw.match(/<svg\b[^>]*>/)[0]),width=+r.width,height=+r.height,ew=width+20,eh=height+20
 const full=raw.replace(/width="[^"]+"/,`width="${ew}"`).replace(/height="[^"]+"/,`height="${eh}"`).replace(/viewBox="[^"]+"/,`viewBox="-10 -10 ${ew} ${eh}"`)
 const rois=[];let texts=0,groups=0
 const mask=full.replace(/<text\b[^>]*>owns<\/text>/g,tag=>{const a=attrs(tag),x=+a.x,y=+a.y,w=+a.textLength,h=+a['font-size'];rois.push({id:`caption:${texts++}`,box:[x-w/2-2,y-h-2,x+w/2+2,y+h+2],changed:0,darker:0,lighter:0});return tag.replace('<text','<text opacity="0"')})
 .replace(/<g\b[^>]*data-role="cardinality"[^>]*>[\s\S]*?<\/g>/g,tag=>{const a=attrs(tag.slice(0,tag.indexOf('>')+1)),pieces=[...tag.matchAll(/<(?:line|circle)\b[^>]*>/g)].map(m=>{const p=attrs(m[0]),half=+p['stroke-width']/2;return m[0].startsWith('<circle')?[+p.cx-p.r-half,+p.cy-p.r-half,+p.cx+(+p.r)+half,+p.cy+(+p.r)+half]:[Math.min(+p.x1,+p.x2)-half,Math.min(+p.y1,+p.y2)-half,Math.max(+p.x1,+p.x2)+half,Math.max(+p.y1,+p.y2)+half]});rois.push({id:a['data-id'],box:[Math.min(...pieces.map(p=>p[0]))-1,Math.min(...pieces.map(p=>p[1]))-1,Math.max(...pieces.map(p=>p[2]))+1,Math.max(...pieces.map(p=>p[3]))+1],changed:0,darker:0,lighter:0});groups++;return ''})
 if(texts!==207||groups!==414)throw Error(`Unexpected owned masks ${texts}/${groups}`)
 const images=[full,mask].map((s,i)=>{const prepared=inlineFontVarForRaster(s);save(`ink-${i?'mask':'full'}.svg`,prepared);const r=new Resvg(prepared,{background:'#ffffff',font:{fontFiles,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();save(`ink-${i?'mask':'full'}.png`,r.asPng());return{width:r.width,height:r.height,pixels:r.pixels}})
 const[a,b]=images;if(a.width!==b.width||a.height!==b.height)throw Error('Raster mismatch')
 const owners=new Uint8Array(a.width*a.height),ownerIndex=new Uint16Array(a.width*a.height)
 for(let k=0;k<rois.length;k++){const q=rois[k].box,x0=Math.max(0,Math.floor((q[0]+10)*a.width/ew)),x1=Math.min(a.width,Math.ceil((q[2]+10)*a.width/ew)),y0=Math.max(0,Math.floor((q[1]+10)*a.height/eh)),y1=Math.min(a.height,Math.ceil((q[3]+10)*a.height/eh));for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){const i=y*a.width+x;owners[i]++;ownerIndex[i]=k}}
 let outside=0,unattributed=0,borrowed=0,changed=0
 for(let y=0;y<a.height;y++)for(let x=0;x<a.width;x++){const p=y*a.width+x,i=p*4,wx=(x+.5)*ew/a.width-10,wy=(y+.5)*eh/a.height-10;if((wx<0||wx>width||wy<0||wy>height)&&Math.min(a.pixels[i],a.pixels[i+1],a.pixels[i+2])<245)outside++;if(![0,1,2,3].some(c=>Math.abs(a.pixels[i+c]-b.pixels[i+c])>=4))continue;changed++;if(!owners[p]){unattributed++;continue}if(owners[p]>1)borrowed++;const roi=rois[ownerIndex[p]];roi.changed++;if(a.pixels[i]+a.pixels[i+1]+a.pixels[i+2]<b.pixels[i]+b.pixels[i+1]+b.pixels[i+2])roi.darker++;else roi.lighter++}
 const report={publicCalls:0,offlineRasterCalls:2,source:'/tmp/pr449-week-comparison-20261101/er-label-prefix-adb463/CURRENT208-AGENTIC.svg.gz',width,height,raster:[a.width,a.height],textControls:texts,cardinalityGroupControls:groups,changed,outside,unattributed,borrowed,missingPositiveInk:rois.filter(r=>!r.darker).map(r=>r.id),controls:rois,verifiedFonts:fonts.map(f=>({file:f.file,bytes:f.bytes,sha256:f.sha256})),scope:'Saved Native AGENTIC LR208 output; each whole owned cardinality group and owns text must contribute positive dark ink in its disjoint emitted ROI. No separate every-component/glyph/browser/universal-font or passed certification claim.'};save('ink-result.json',report);console.log(JSON.stringify({...report,controls:undefined}))
} finally {fs.rmSync(scratch,{recursive:true,force:true})}
