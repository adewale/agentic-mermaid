import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
const [root, family, backend, tag] = Bun.argv.slice(2)
const importStart = performance.now()
const { renderMermaidSVGWithReceipt } = await import(root + '/src/index.ts')
const { withRenderStageObserver } = await import(root + '/src/render-stages.ts')
const importMs = performance.now() - importStart
const source = family === 'class' ? 'classDiagram\ndirection TB\nclass A\nclass B\nclass Sink\nA --> Sink : input\nB --> Sink\nSink --> Sink : retry' : readFileSync(root + '/eval/layout-compare/fixtures/requirement-backends.mmd', 'utf8')
const edited = family === 'class' ? source.replace(': retry', ': retry twice') : source.replace('Respond quickly', 'Respond promptly')
const options = { graphLayout: { backend, fallback: 'none' }, embedFontImport: false }
const outputs: unknown[] = [], rows = []
for (const [phase, input] of [['first', source], ['repeat', source], ['edit', edited]]) {
  const stages: unknown[] = [], start = performance.now()
  try {
    const result = withRenderStageObserver((s: unknown) => stages.push(s), () => renderMermaidSVGWithReceipt(input, options))
    // Same complete SVG+receipt consumer as eval/benchmark/peer-tracks.ts.
    const bytes = Buffer.from(JSON.stringify(result), 'utf8')
    let checksum = 0
    for (let i = 0; i < bytes.length; i++) checksum = (Math.imul(checksum, 31) + bytes[i]!) >>> 0
    const elapsedMs = performance.now() - start
    outputs.push(result)
    rows.push({ phase, status: 'returned', elapsedMs, bytes: bytes.length, checksum, stages, proof: result.receipt.layoutCertification?.status, viewBox: result.svg.match(/viewBox="([^"]+)"/)?.[1] })
  } catch (e: any) { rows.push({ phase, status: 'failed', elapsedMs: performance.now() - start, name: e.name, message: e.message, stages }) }
}
const usage = process.resourceUsage(), memory = process.memoryUsage()
writeFileSync(`/tmp/pr449-week-comparison-20261101/cost-${tag}.outputs.json.gz`, gzipSync(JSON.stringify(outputs)))
console.log(JSON.stringify({ tag, root, family, backend, cache: process.env.AGENTIC_MERMAID_ELK_CACHE, sceneAssertions: process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS, importMs, peakRssKiB: usage.maxRSS, rss: memory.rss, heapUsed: memory.heapUsed, rows }))
