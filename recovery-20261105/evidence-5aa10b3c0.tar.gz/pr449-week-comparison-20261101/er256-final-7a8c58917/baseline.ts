import { layoutErDiagram } from '/tmp/pr449-main-integration-20261029-762/src/er/layout.ts'
import { parseErDiagram } from '/tmp/pr449-main-integration-20261029-762/src/er/parser.ts'
import { toMermaidLines } from '/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts'
const source = `erDiagram\ndirection LR\n` + Array.from({length:255}, (_,i)=>`N${i} ||--o{ N${i+1} : owns`).join('\n')
try { const r=layoutErDiagram(parseErDiagram(toMermaidLines(source)),{graphLayout:{backend:'elk',fallback:'none'}}); console.log(JSON.stringify({status:'returned',entities:r.entities.length,relationships:r.relationships.length})) }
catch(error) { console.log(JSON.stringify({status:'refused',name:error.name,code:error.code,message:error.message,stack:error.stack})) }
