import fs from 'node:fs'
import { createHash } from 'node:crypto'
import { gzipSync } from 'node:zlib'
import { Resvg } from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import { HOSTED_FONT_RESOURCES } from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import { inlineFontVarForRaster } from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import { prepareResvgMarkerOrientation } from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const dir='/tmp/pr449-week-comparison-20261101',root='/tmp/pr449-main-integration-20261029-762',scratch=fs.mkdtempSync('/tmp/pr449-req-font-')
try {
 const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter'), fontFiles=fonts.map(f=>{const b=fs.readFileSync(`${root}/${f.path}`);if(b.length!==f.bytes||createHash('sha256').update(b).digest('hex')!==f.sha256)throw Error('Font manifest mismatch');const p=`${scratch}/${f.file}`;fs.writeFileSync(p,b);return p})
 const source=JSON.parse(fs.readFileSync(`${dir}/final-2fa-requirement-TB-agentic.json`,'utf8')).svg as string
 const [,,w,h]=source.match(/viewBox="(\S+) (\S+) (\S+) (\S+)"/)!.slice(1).map(Number)
 const expanded=source.replace(/width="[^"]+"/,`width="${w+40}"`).replace(/height="[^"]+"/,`height="${h+40}"`).replace(/viewBox="[^"]+"/,`viewBox="-20 -20 ${w+40} ${h+40}"`)
 const caption=expanded.match(/<text\b[^>]*>&lt;&lt;refines&gt;&gt;<\/text>/)![0]
 const routes=[...expanded.matchAll(/<polyline\b[^>]*data-role="relationship"[^>]*\/>/g)].map(m=>m[0])
 const rois=routes.map(route=>{const pts=/points="([^"]+)"/.exec(route)![1]!.trim().split(/\s+/).map(p=>p.split(',').map(Number));const [x,y]=pts.at(-1)!;return {x:x!-14,y:y!-14,w:28,h:28}})
 const mask=expanded.replace(caption,caption.replace('<text ','<text opacity="0" ')).replace(/ marker-end="[^"]+"/g,'')
 const [a,b]=[expanded,mask].map((svg,i)=>{const r=new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(svg)),{background:'#fff',fitTo:{mode:'zoom',value:2},font:{fontFiles,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();fs.writeFileSync(`${dir}/requirement-${i?'mask':'full'}.png.gz`,gzipSync(r.asPng()));return {width:r.width,height:r.height,pixels:Buffer.from(r.pixels)}})
 const heads=rois.map(()=>0);let captionDarker=0,outsideFull=0,outsideMask=0
 for(let y=0;y<a.height;y++)for(let x=0;x<a.width;x++){const i=(y*a.width+x)*4,wx=(x+.5)/2-20,wy=(y+.5)/2-20,out=wx<0||wy<0||wx>w||wy>h;if(out){if(a.pixels[i]!<245||a.pixels[i+1]!<245||a.pixels[i+2]!<245)outsideFull++;if(b.pixels[i]!<245||b.pixels[i+1]!<245||b.pixels[i+2]!<245)outsideMask++}if(a.pixels[i]!+a.pixels[i+1]!+a.pixels[i+2]!>=b.pixels[i]!+b.pixels[i+1]!+b.pixels[i+2]!-4)continue;for(let j=0;j<rois.length;j++){const r=rois[j]!;if(wx>=r.x&&wx<=r.x+r.w&&wy>=r.y&&wy<=r.y+r.h)heads[j]!++}if(wx>320&&wx<398&&wy>443&&wy<468)captionDarker++}
 const result={publicCalls:0,offlineRasterCalls:2,faces:fonts.map(f=>f.file),headDarker:heads,captionDarker,outsideFull,outsideMask,scope:'TB final served SVG, four pinned normal Inter faces, refines opacity and all marker-end controls; not a whole-ink/font-universal claim'}
 fs.writeFileSync(`${dir}/requirement-ink.json`,JSON.stringify(result,null,2));console.log(JSON.stringify(result))
}finally {fs.rmSync(scratch,{recursive:true,force:true})}
