import { readFileSync } from 'node:fs'
Bun.plugin({name:'retained-native-before',setup(build){build.onLoad({filter:/\/src\/scene\/native-paint-emission\.ts$/},()=>({contents:readFileSync('/tmp/pr449-week-comparison-20261101/text-plan-custody-684/native-before.ts','utf8'),loader:'ts'}))}})
