import { readFileSync } from 'node:fs'
Bun.plugin({name:'owning-before-child-only',setup(build){build.onLoad({filter:/\/src\/__tests__\/paint-certification\.test\.ts$/},args=>{
 const source=readFileSync(args.path,'utf8')
 const needle="['--eval', textReceiverProgram]"
 if(!source.includes(needle))throw new Error('Existing owner child seam missing')
 return {contents:source.replace(needle,"['--preload', '/tmp/pr449-week-comparison-20261101/text-plan-custody-684/child-before.ts', '--eval', textReceiverProgram]"),loader:'ts'}
})}})
