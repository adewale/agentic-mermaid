import { readFileSync } from 'node:fs'
Bun.plugin({name:'retained-before-marks',setup(build){build.onLoad({filter:/\/src\/scene\/marks\.ts$/},()=>({contents:readFileSync('/tmp/pr449-week-comparison-20261101/prepared-roster-f1e/marks.original.ts','utf8'),loader:'ts'}))}})
const { drawNative }=await import('/tmp/pr449-main-integration-20261029-762/src/scene/native-drawing.ts')
const { certifyNativePaint }=await import('/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts')
const { preparePixelText }=await import('/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts')
import { writeFileSync } from 'node:fs'
const block = preparePixelText('Read', { fontSize: 18, fontWeight: 400 })
const original = WeakMap.prototype.get
let contacts=0
function alter(plan:any):void { for(let i=0;i<plan.slots.length;i++){const slot=plan.slots[i]; if(slot.value==='Read')slot.value='Lost'; if(slot.child)alter(slot.child)} }
let drawing
try {
 WeakMap.prototype.get=function(key){const entry=Reflect.apply(original,this,[key]);if(key===block&&entry?.plan){contacts++;alter(entry.plan)}return entry}
 const width=300,height=160,colors={bg:'#fff',fg:'#111'}
 drawing=drawNative(factory=>({family:'flowchart',width,height,colors,transparent:false,parts:[
 factory.documentOpen({id:'root',width,height,colors,transparent:false,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="160">'),
 ...[40,90,140].map((y,i)=>factory.text({id:'label'+i,role:'label',text:'Read',block,x:20,y,fontSize:18,anchor:'start',paint:{fill:'#111'}})),factory.documentClose(),
 ]}),{positioned:{width,height},colors,resolved:{renderOptions:{}}},'flowchart')
} finally { WeakMap.prototype.get=original }
const packet={contacts,source:block.text,svg:drawing!.svg,proof:certifyNativePaint(drawing!.header,drawing!.paint)}
writeFileSync('/tmp/pr449-week-comparison-20261101/text-plan-custody-684/red-before.json',JSON.stringify(packet))
console.log(JSON.stringify({contacts,source:packet.source,texts:[...packet.svg.matchAll(/<text\b[^>]*>(.*?)<\/text>/g)].map(m=>m[1]),proof:packet.proof}))