// Prepared only. Run solely after separate ROOTGO and cost-agent CPU clearance.
import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
const repo='/tmp/pr449-main-integration-20261029-762'
const out='/tmp/pr449-week-comparison-20261101/class128-LR-requalification-52a'
const frozenHead='52a13881d0beafe2e7ebb4cfcfae349ab20ca1e2'
if(process.argv[2]!=='ROOTGO') throw new Error('HOLD: separate ROOTGO is required; no rendering started')
if(process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS!=='0'||process.env.AGENTIC_MERMAID_ELK_CACHE!=='0') throw new Error('Expected assertions0/cache0 before imports')
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim()
const dirtySource=execFileSync('git',['diff','HEAD','--','src'],{cwd:repo,encoding:'utf8'})
if(head!==frozenHead||dirtySource)throw new Error('Frozen52a source changed; no rendering started')
const {renderMermaidSVGWithReceipt}=await import(repo+'/src/index.ts')
const {resolveRenderRequestForExecution}=await import(repo+'/src/render-contract.ts')
const {assertScenesOf}=await import(repo+'/src/scene/assertions.ts')
const {positionResolvedFamily}=await import(repo+'/src/positioning.ts')
const {renderPositionedMermaidSVG,graphicalSvgArtifact}=await import(repo+'/src/graphical-render.ts')
const {emitResolvedConfigDiagnostics}=await import(repo+'/src/render-config-diagnostics.ts')
const {withSvgInspectionCache}=await import(repo+'/src/svg-inspection-cache.ts')
const {withRenderStageObserver,measureRenderStage}=await import(repo+'/src/render-stages.ts')
const {withPerformanceObserver}=await import(repo+'/src/performance-observations.ts')
const {apiFailure}=await import(repo+'/eval/layout-compare/outcomes.ts')
const source='classDiagram\ndirection LR\n'+Array.from({length:127},(_,i)=>`N${i} --> N${i+1}`).join('\n')
const options={graphLayout:{backend:'agentic' as const,fallback:'none' as const},embedFontImport:false}
const historical=JSON.parse(gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/class128-profile/outputs.json.gz')).toString())[4]
const digest=(value:string)=>createHash('sha256').update(value).digest('hex')
const rows:any[]=[],products:any[]=[]
let attempts=0,ordinary:any
for(const arm of ['ordinary','scene'] as const){
 if(arm==='scene'&&ordinary?.receipt.layoutCertification?.status==='passed')break
 const stages:any[]=[],events:any[]=[];const start=performance.now();attempts++
 console.log(JSON.stringify({event:'ACTUAL_CALL_START',arm,attempt:attempts}))
 try{
  const artifact=withPerformanceObserver(event=>events.push(event),()=>withRenderStageObserver(stage=>stages.push(stage),()=>{
   if(arm==='ordinary')return renderMermaidSVGWithReceipt(source,options)
   return withSvgInspectionCache(()=>{
    const request=measureRenderStage('request',()=>resolveRenderRequestForExecution(source,options,'svg'))
    assertScenesOf(request);emitResolvedConfigDiagnostics(request)
    const layout=measureRenderStage('layout',()=>positionResolvedFamily('class',request))
    const securityDiagnostics:any[]=[]
    return graphicalSvgArtifact(request,renderPositionedMermaidSVG(request,layout,securityDiagnostics),securityDiagnostics)
   })
  }))
  // Force the entire lazy final receipt and serialized artifact after backend finish.
  const product={svg:artifact.svg,receipt:artifact.receipt}
  const bytes=Buffer.from(JSON.stringify(product));let checksum=0
  for(const byte of bytes)checksum=(Math.imul(checksum,31)+byte)>>>0
  if(arm==='ordinary')ordinary=product
  products.push({arm,...product})
  writeFileSync(`${out}/${arm}.svg.gz`,gzipSync(product.svg))
  writeFileSync(`${out}/${arm}.receipt.json.gz`,gzipSync(JSON.stringify(product.receipt)))
  rows.push({arm,status:'returned',elapsedMs:performance.now()-start,fullyConsumedBytes:bytes.length,checksum,svgSha256:digest(product.svg),proof:product.receipt.layoutCertification,provider:events.filter(e=>e.owner==='paint-certification'),sameWholeSVGAsOrdinary:arm==='scene'?product.svg===ordinary?.svg:undefined,sameEntireReceiptAsOrdinary:arm==='scene'?JSON.stringify(product.receipt)===JSON.stringify(ordinary?.receipt):undefined,historicalLR:{sameWholeSVG:product.svg===historical.svg,sha256:digest(historical.svg),proof:historical.receipt.layoutCertification,note:'Historical vector predates25b; comparison is descriptive, not causal.'},stages,events})
 }catch(error:any){
  const failure={normalized:apiFailure(error),name:error?.name,message:error?.message,code:error?.code,stack:error?.stack,cause:error?.cause?{name:error.cause.name,message:error.cause.message,code:error.cause.code,stack:error.cause.stack}:undefined,certification:error?.certification}
  const bytes=Buffer.from(JSON.stringify(failure));products.push({arm,failure})
  rows.push({arm,status:'refused',elapsedMs:performance.now()-start,fullyConsumedErrorBytes:bytes.length,failure,stages,events,provider:events.filter(e=>e.owner==='paint-certification')})
 }
 const report={head,source,options,assertions:process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS,positionCache:process.env.AGENTIC_MERMAID_ELK_CACHE,attempts,rows,products}
 writeFileSync(`${out}/RESULTS.json.gz`,gzipSync(JSON.stringify(report)))
 console.log(JSON.stringify({event:'ACTUAL_CALL_COMPLETE',...rows.at(-1)}))
}
writeFileSync(`${out}/SUMMARY.json.gz`,gzipSync(JSON.stringify({head,source,options,attempts,stoppedAfterOrdinaryPass:attempts===1&&ordinary?.receipt.layoutCertification?.status==='passed',rows})))
console.log(JSON.stringify({event:'COMPLETE',attempts,stop:attempts===1?'ordinary passed; Scene call omitted':'two-call bound consumed'}))
