import gzip,json,xml.etree.ElementTree as E,math
from pathlib import Path
p=Path('/tmp/pr449-week-comparison-20261101/requirement-kind-order-f1e');n='{http://www.w3.org/2000/svg}'
rows={}
for arm in ['baseline','candidate']:
 x=json.load(gzip.open(p/arm/'RESULT.json.gz','rt'));r=E.fromstring(x['product']['svg'])
 cards={}
 for g in r.iter(n+'g'):
  if 'requirement-node' in g.get('class','').split():
   rect=g.find(n+'rect');cards[g.get('data-id')]=[float(rect.get(k)) for k in ['x','y','width','height']]
 intervals=sorted((v[1],v[1]+v[3]) for v in cards.values());bands=[]
 for lo,hi in intervals:
  if bands and lo<bands[-1][1]:bands[-1][1]=max(bands[-1][1],hi)
  else:bands.append([lo,hi])
 pairgaps=[];ids=list(cards)
 for i,a in enumerate(ids):
  ax,ay,aw,ah=cards[a]
  for b in ids[i+1:]:
   bx,by,bw,bh=cards[b];dx=max(ax-bx-bw,bx-ax-aw,0);dy=max(ay-by-bh,by-ay-ah,0)
   pairgaps.append({'cards':[a,b],'xGap':dx,'yGap':dy,'shortestAabbDistance':math.hypot(dx,dy)})
 edges=[]
 for e in r.iter():
  if e.get('data-role')!='relationship':continue
  pts=[tuple(map(float,t.split(','))) for t in e.get('points').split()];src=e.get('data-from');dst=e.get('data-to')
  edges.append({'id':e.get('data-id'),'src':src,'dst':dst,'kind':e.get('data-relationship'),'wire':sum(math.dist(a,b) for a,b in zip(pts,pts[1:])),'turns':len(pts)-2,'backwardOnTBMainAxis':src!=dst and pts[-1][1]<pts[0][1],'firstLead':math.dist(pts[0],pts[1]),'lastLead':math.dist(pts[-1],pts[-2]),'points':pts})
 vb=list(map(float,r.get('viewBox').split()));rawmeaning=json.load(open(p/'MEANING.json'))[0 if arm=='baseline' else 1]
 rows[arm]={'width':vb[2],'height':vb[3],'area':vb[2]*vb[3],'wire':sum(e['wire'] for e in edges),'turns':sum(e['turns'] for e in edges),'physicalCardRanksByOverlappingMainAxisBands':len(bands),'rankBands':bands,'rankGaps':[bands[i][0]-bands[i-1][1] for i in range(1,len(bands))],'cardPairSpacing':pairgaps,'minimumCardAabbDistance':min(g['shortestAabbDistance'] for g in pairgaps),'minimumTerminalLead':min(min(e['firstLead'],e['lastLead']) for e in edges),'backwardNonselfRelations':sum(e['backwardOnTBMainAxis'] for e in edges),'cards':cards,'edges':edges,'meaning':{k:rawmeaning[k] for k in ['pass','names','literalFields','orderedRelations','captionOwners','hollowHeads','normalDocks']},'proof':x['row']['proof'],'wholeSvgExactToOldNoMarker':x['row']['wholeSvgExactToOldNoMarker'],'actualPublicCalls':x['actualPublicCalls'],'overlayLoads':x['overlayLoads'],'fullyConsumedBytes':x['row']['fullyConsumedBytes'],'checksum':x['row']['checksum'],'svgSha256':x['row']['svgSha256'],'renderWallMsObservedOnly':x['renderWallMs'],'peakRssKiBObservedOnly':x['peakRssKiB']}
b,c=rows['baseline'],rows['candidate'];summary={'head':'f1e23e62fc30269827cef9765e70b67bd2d83296','actualPublicSvgCalls':2,'publicLayoutCalls':0,'productionEdits':0,'candidateMeaning':'Family kind-order [requirements, ...elements] using existing private authoredCycleOrder API; not literal source-order semantics.','rows':rows,'deltaCandidateVsBaseline':{k:{'difference':c[k]-b[k],'percent':(c[k]/b[k]-1)*100} for k in ['width','height','area','wire','turns','minimumCardAabbDistance']},'candidateAreaVsRetainedElkTBPercent':(c['area']/257555.09847999996-1)*100,'disposition':'HOLD for root tradeoff review: smaller area and all recorded meaning/dock/P checks pass, but wire/turns/backward relations worsen. No four-direction sweep or production change authorized/performed.','cpuClear':True,'scope':'Independent saved actual XML vectors and complete proof/receipt products. No new raster/full-font or timing gain claim.'}
(p/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'deltas':summary['deltaCandidateVsBaseline'],'areaVsElkPercent':summary['candidateAreaVsRetainedElkTBPercent'],'rows':{a:{k:v[k] for k in ['physicalCardRanksByOverlappingMainAxisBands','rankGaps','minimumCardAabbDistance','minimumTerminalLead','backwardNonselfRelations','turns','wire']} for a,v in rows.items()},'cpuClear':True},indent=2))
