import sys,json,gzip,xml.etree.ElementTree as E,math
N='{http://www.w3.org/2000/svg}'
expected=[('suite','fast','verifies'),('suite','fast','traces'),('fast','report','derives'),('report','fast','satisfies'),('fast','fast','refines')]
fields={'fast':['<<Requirement>>fast','ID: performance-1','Text: Respond quickly with retained measured fields','Risk: High','Verification: Test'],'suite':['<<Element>>suite','Type: test','Doc Ref: bench suite'],'report':['<<Element>>report','Type: artifact']}
def normal(p,q,b):
 x,y,w,h=b;dx=q[0]-p[0];dy=q[1]-p[1];eq=lambda a,b:abs(a-b)<1e-6
 return (eq(dy,0) and y<p[1]<y+h and ((eq(p[0],x) and dx<0) or(eq(p[0],x+w) and dx>0))) or (eq(dx,0) and x<p[0]<x+w and ((eq(p[1],y) and dy<0) or(eq(p[1],y+h) and dy>0)))
results=[]
for path in sys.argv[1:]:
 packet=json.load(gzip.open(path,'rt') if path.endswith('.gz') else open(path));s=packet.get('svg') or packet.get('rendered',{}).get('svg') or packet.get('value',{}).get('svg') or packet.get('product',{}).get('svg');assert isinstance(s,str),path
 root=E.fromstring(s);cards={};texts={}
 for g in root.iter(N+'g'):
  if 'requirement-node' in g.get('class','').split():
   rid=g.get('data-id');r=g.find(N+'rect');assert r is not None
   cards[rid]=tuple(float(r.get(k)) for k in ('x','y','width','height'))
   texts[rid]=[''.join(t.itertext()).strip() for t in g.iter(N+'text')]
 assert set(cards)==set(fields),(path,cards)
 for rid,want in fields.items():assert texts[rid]==want,(path,rid,texts[rid],want)
 routes=[r for r in root.iter() if r.get('data-role')=='relationship'];assert [(r.get('data-from'),r.get('data-to'),r.get('data-relationship')) for r in routes]==expected
 ids=[r.get('data-id') for r in routes];assert ids==['relation-'+str(i) for i in range(1,6)],ids
 groups=[g for g in root.iter(N+'g') if g.get('class')=='requirement-edge-label'];assert [g.get('data-edge-id') for g in groups]==ids
 assert [''.join(g.itertext()).strip() for g in groups]==['<<'+e[2]+'>>' for e in expected]
 wire=0;bends=0;docks=[]
 for r,(src,dst,kind) in zip(routes,expected):
  assert r.get('data-direction')=='forward' and r.get('stroke-dasharray')=='6 4' and r.get('marker-start') is None
  ref=r.get('marker-end');assert ref and ref.startswith('url(#') and ref.endswith('requirement-arrow)')
  marker=next(m for m in root.iter(N+'marker') if m.get('id')==ref[5:-1]);poly=marker.find(N+'polygon');assert poly is not None and poly.get('fill')=='none'
  mp=[float(x) for x in poly.get('points').replace(',',' ').split()];assert mp==[0,0,9,3.5,0,7]
  pts=[tuple(map(float,p.split(','))) for p in r.get('points').split()];assert all(a[0]==b[0] or a[1]==b[1] for a,b in zip(pts,pts[1:]));assert normal(pts[0],pts[1],cards[src]) and normal(pts[-1],pts[-2],cards[dst]),(path,kind,pts)
  if src==dst:assert pts[0]!=pts[-1]
  docks.extend([pts[0],pts[-1]]);wire+=sum(math.dist(a,b) for a,b in zip(pts,pts[1:]));bends+=len(pts)-2
 vb=list(map(float,root.get('viewBox').split()));direction=packet.get('source','').split('direction ')[-1][:2]
 results.append({'path':path,'pass':True,'names':3,'literalFields':sum(map(len,fields.values())),'orderedRelations':5,'captionOwners':5,'hollowHeads':5,'normalDocks':len(docks),'width':vb[2],'height':vb[3],'area':vb[2]*vb[3],'wire':wire,'bends':bends,'cards':cards,'scope':'Saved actual SVG literal meaning, hollow-head programs and serialized normal docks; no pixel/full-ink claim'})
print(json.dumps(results,indent=2))
