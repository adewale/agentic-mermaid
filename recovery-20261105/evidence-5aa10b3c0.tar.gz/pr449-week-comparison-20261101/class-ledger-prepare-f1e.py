from pathlib import Path
import re,json
root=Path('/tmp/pr449-main-integration-20261029-762')
out=Path('/tmp/pr449-week-comparison-20261101/class-ledger-f1e');out.mkdir(exist_ok=True)
p=(root/'src/scene/paint-certification.ts').read_text();(out/'paint-certification.original.ts').write_text(p)
p="const observedPaintLedgers: any[] = []\nexport function readObservedPaintLedgers() { return observedPaintLedgers }\n"+p
needle='  const work = (): boolean => {\n    if (operations >= MAX_OCCLUSION_OPERATIONS) { exhausted = true; return false }\n    operations++\n    return true\n  }'
assert p.count(needle)==1
p=p.replace(needle,'''  const ledger: any = { initialOperations: operations, phases: {}, landmarks: [], markerIterations: [], helpers: {} }
  observedPaintLedgers.push(ledger)
  let observedPhase = 'header-transparency', observedMarker: any
  const closeObservedMarker = () => { if (observedMarker) { observedMarker.exitOperations = operations; observedMarker.exitPairs = pairs; observedMarker.exhausted = exhausted; observedMarker = undefined } }
  const landmark = (phase: string) => { closeObservedMarker(); observedPhase = phase; ledger.landmarks.push({ phase, operations, pairs, exhausted }) }
  const observeHelper = <T>(name: string, action: () => T): T => {
    const before = operations, failures = ledger.failedWorkCalls ?? 0
    const h = ledger.helpers[name] ??= { calls: 0, paid: 0, failed: 0 }
    h.calls++
    try { return action() } finally { h.paid += operations - before; h.failed += (ledger.failedWorkCalls ?? 0) - failures }
  }
  const work = (): boolean => {
    const phase = ledger.phases[observedPhase] ??= { accepted: 0, failed: 0 }
    if (operations >= MAX_OCCLUSION_OPERATIONS) { phase.failed++; ledger.failedWorkCalls = (ledger.failedWorkCalls ?? 0) + 1; if (observedMarker) observedMarker.failed = (observedMarker.failed ?? 0) + 1; exhausted = true; return false }
    phase.accepted++
    operations++
    return true
  }''')
def once(old,new):
 global p
 assert p.count(old)==1,(old[:100],p.count(old))
 p=p.replace(old,new)
once('  const cylinderContext = !repaired', "  landmark('cylinder-context-scan')\n  const cylinderContext = !repaired")
once('  const retainedRoster = work()', "  landmark('surface-tree-and-rosters')\n  const retainedRoster = work()")
once('  if (!retainedRoster) for (const primitive of inspection.primitives)', "  landmark('text-occlusion')\n  if (!retainedRoster) for (const primitive of inspection.primitives)")
old='  for (const primitive of retainedRoster ? connectors : inspection.primitives) {'
assert p.count(old)==2
p=p.replace(old,"  landmark('connector-shaft')\n"+old,1)
# The second loop is uniquely preceded by reserveMarkerGeometry's return.
needle='    return true\n  }\n  for (const primitive of retainedRoster ? connectors : inspection.primitives) {'
assert p.count(needle)==1
p=p.replace(needle,"    return true\n  }\n  landmark('marker-target-preparation')\n  for (const primitive of retainedRoster ? connectors : inspection.primitives) {\n    closeObservedMarker()\n    observedMarker = { ordinal: ledger.markerIterations.length, entryOperations: operations, entryPairs: pairs, failed: 0, committed: 0 }\n    ledger.markerIterations.push(observedMarker)")
once('      lastMarkers.set(key,', '      if (observedMarker) observedMarker.committed++\n      lastMarkers.set(key,')
once('  const markerCheck = (branch:', "  landmark('marker-compound-contact-preparation')\n  const markerCheck = (branch:")
once('  for (let index = 0; index < markerTargets.length; index++) markerCheck', "  landmark('marker-vs-bodies')\n  for (let index = 0; index < markerTargets.length; index++) markerCheck")
once('  let semanticMarkers = 0, textQueries = 0', "  landmark('marker-text-index-setup')\n  let semanticMarkers = 0, textQueries = 0")
once('  for (let targetIndex = 0; targetIndex < markerTargets.length; targetIndex++)', "  landmark('marker-vs-text')\n  for (let targetIndex = 0; targetIndex < markerTargets.length; targetIndex++)")
once('  for (let earlierIndex = 0; earlierIndex < markerTargets.length; earlierIndex++)', "  landmark('marker-vs-marker')\n  for (let earlierIndex = 0; earlierIndex < markerTargets.length; earlierIndex++)")
once("  if (exhausted) issue({ code: 'CHECK_BUDGET'", "  landmark('final-containment')\n  ledger.finalOperations = operations; ledger.finalPairs = pairs; ledger.exhausted = exhausted\n  if (exhausted) issue({ code: 'CHECK_BUDGET'")
for name,expr in [
 ('markerPaintIdentity','markerPaintIdentity(descriptor, resolvePaintColor, work, primitive.ancestors.length === 0 || boundGroupPalette)'),
 ('emittedEndpointMarker','emittedEndpointMarker(node, descriptor, marker, work)'),
 ('markerMayHaveOpaqueFill','markerMayHaveOpaqueFill(resolvePaintColor, descriptor, work)'),
 ('prepareMarkerPolygonInk','prepareMarkerPolygonInk(scene, actualPose?.node ?? node, actualPose?.marker ?? descriptor, marker.position, work, resolvePaintColor)'),
 ('markerInkWitnesses','markerInkWitnesses(actualPose?.marker ?? descriptor, region.hull, resolvePaintColor, work, survivingFill)'),
 ('markerHasInk','markerHasInk(descriptor, fillWitnesses, resolvePaintColor, work, survivingFill)')]:
 once(expr,"observeHelper('"+name+"', () => "+expr+")")
(out/'paint-certification.instrumented.ts').write_text(p)
s=(root/'src/scene/serialization.ts').read_text();(out/'serialization.original.ts').write_text(s)
s="const observedSceneWriteLedgers: any[] = [], observedInspectionLedgers: any[] = []\nexport function readObservedSceneWriteLedgers() { return { captures: observedSceneWriteLedgers, inspections: observedInspectionLedgers } }\n"+s
needle='    let operations = this.#operations, exhausted = this.#exhausted\n    const consumed'
assert s.count(needle)==1
s=s.replace(needle,'    let operations = this.#operations, exhausted = this.#exhausted\n    const observed = { initialOperations: operations, nodeVisits: 0, acceptedNodeVisits: 0, finalOperations: operations, exhausted }; observedInspectionLedgers.push(observed)\n    const consumed')
s=s.replace('        if (exhausted || operations > this.#maxOperations - 16)', '        observed.nodeVisits++\n        if (exhausted || operations > this.#maxOperations - 16)',1)
s=s.replace('        operations += 16\n        const written', '        operations += 16\n        observed.acceptedNodeVisits++\n        const written',1)
needle='      work: (): SceneWriteWork => Object.freeze({ scene, operations, exhausted,'
assert s.count(needle)==1
s=s.replace(needle,'      work: (): SceneWriteWork => (observed.finalOperations = operations, observed.exhausted = exhausted, Object.freeze({ scene, operations, exhausted,')
needle='fractionalCircleContext: this.#fractionalCircleContext, resolveColor: this.#resolveColor }),'
assert s.count(needle)==1
s=s.replace(needle,'fractionalCircleContext: this.#fractionalCircleContext, resolveColor: this.#resolveColor })),')
needle='  const pay = (count: number): boolean => {\n    if (exhausted || !(actualBackendWrite ? groupSafeInteger(count) : Number.isSafeInteger(count)) || count < 0 || count > maxOperations - operations) { exhausted = true; return false }\n    operations += count\n    return true\n  }'
assert s.count(needle)==1
s=s.replace(needle,'''  const ledger: any = { actualBackendWrite, stages: {} }; observedSceneWriteLedgers.push(ledger)
  let observedStage = 'context-or-recorder'
  const observeCapture = <T>(name: string, action: () => T): T => {
    const prior = observedStage; observedStage = name
    try { return action() } finally { observedStage = prior }
  }
  const pay = (count: number): boolean => {
    const key = (emitting ? 'actual:' : 'admission:') + observedStage
    const stage = ledger.stages[key] ??= { calls: 0, accepted: 0, rejectedCalls: 0, rejectedRequested: 0 }; stage.calls++
    if (exhausted || !(actualBackendWrite ? groupSafeInteger(count) : Number.isSafeInteger(count)) || count < 0 || count > maxOperations - operations) { stage.rejectedCalls++; stage.rejectedRequested += count; exhausted = true; return false }
    stage.accepted += count
    operations += count
    return true
  }''')
# Scope only existing named private capture routines. No arguments, source fields or callbacks are reread.
names=['string','inert','hint','compound','compoundRecord','rectangle','rectangleRecord','replace','record']
for name in names:
 pattern=r'(  const '+name+r'(?:\s|:|=)[\s\S]*?=> \{)([\s\S]*?)(\n  \})(?=\n  (?:const|if))'
 scopeStart=s.index('export function createSceneWriteCapture(')
 scopeEnd=s.index('  const detach',scopeStart)
 matches=[m for m in re.finditer(pattern,s) if scopeStart < m.start() < scopeEnd]
 assert len(matches)==1,(name,len(matches))
 m=matches[0]
 s=s[:m.start()]+m.group(1)+" return observeCapture('"+name+"', () => {"+m.group(2)+'\n  })'+m.group(3)+s[m.end():]
(out/'serialization.instrumented.ts').write_text(s)
worker=Path('/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/worker.ts').read_text()
worker=worker.replace("out='/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a'","out='/tmp/pr449-week-comparison-20261101/class-ledger-f1e/'+process.argv[2]")
worker=worker.replace("const wallStart=performance.now(),cpuStart=process.cpuUsage()",'''const direction=process.argv[2]
if(!['TB','LR'].includes(direction))throw new Error('Expected TB or LR; no calls started')
let overlayLoads: string[]=[]
Bun.plugin({name:'class-ledger-observation-only',setup(build){
 build.onLoad({filter:/\\/src\\/scene\\/(paint-certification|serialization)\\.ts$/},args=>{
  if(!args.path.startsWith(root+'/src/scene/'))return
  const name=args.path.endsWith('/serialization.ts')?'serialization':'paint-certification'
  overlayLoads.push(name)
  return {contents:readFileSync(out+'/../'+name+'.instrumented.ts','utf8'),loader:'ts'}
 })
}})
const wallStart=performance.now(),cpuStart=process.cpuUsage()''')
worker=worker.replace("const source='classDiagram\\ndirection TB\\n'+", "const source='classDiagram\\ndirection '+direction+'\\n'+")
old="const historical=JSON.parse(gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/class128-ordinary-remaining-52a/RESULTS.json.gz')).toString()).products.find((p:any)=>p.direction==='TB')"
assert worker.count(old)==1
worker=worker.replace(old,"const baseline=direction==='TB'?'/tmp/pr449-week-comparison-20261101/class128-TB-candidate-profile-52a/TB':'/tmp/pr449-week-comparison-20261101/class-scene-cache0-cost-539407810/class128LR-agentic-after-cold'\n const historical={svg:gunzipSync(readFileSync(baseline+'.svg.gz')).toString(),receipt:gunzipSync(readFileSync(baseline+'.receipt.json.gz')).toString()}")
worker=worker.replace('wholeSVGExactToOrdinary52a:product.svg===historical.svg','wholeSVGExactToSaved:product.svg===historical.svg,entireRawReceiptBytesExactToSaved:JSON.stringify(product.receipt)===historical.receipt')
worker=worker.replace('const report={actualPublicCalls:1,',"const {readObservedPaintLedgers}=await import(root+'/src/scene/paint-certification.ts')\nconst {readObservedSceneWriteLedgers}=await import(root+'/src/scene/serialization.ts')\nconst report={direction,overlayLoads,paintLedgers:readObservedPaintLedgers(),sceneWriteLedgers:readObservedSceneWriteLedgers(),actualPublicCalls:1,")
for d in ['TB','LR']:(out/d).mkdir(exist_ok=True)
(out/'worker.ts').write_text(worker)
(out/'SETUP.json').write_text(json.dumps({'head':'f1e23e62fc30269827cef9765e70b67bd2d83296','authorizedPublicCalls':2,'directions':['TB','LR'],'cache':'0','assertions':'0','productionEdits':0,'instrumentation':'Private operation/call counters only; original work/pay/limits/control flow and source field read expressions retained.'},indent=2)+'\n')
print(json.dumps({'setup':'ready','callExpressionsPerProcess':worker.count('renderMermaidSVGWithReceipt(source,options)'),'paintLandmarks':p.count("landmark('"),'captureScopes':s.count("return observeCapture('")}))
