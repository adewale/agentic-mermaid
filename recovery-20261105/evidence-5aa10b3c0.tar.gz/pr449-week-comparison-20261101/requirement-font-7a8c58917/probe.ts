import {renderMermaidSVGWithReceipt} from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
import {layoutRequirementDiagram} from '/tmp/pr449-main-integration-20261029-762/src/requirement/layout.ts'
import {parseRequirementDiagram} from '/tmp/pr449-main-integration-20261029-762/src/requirement/parser.ts'
import {readFileSync,writeFileSync} from 'node:fs'
const source='requirementDiagram\nelement a {\ntype: "code"\n}\nelement b {\ntype: "code"\n}\na - satisfies -> b'
const out=[]
for(const font of ['Inter','monospace','JetBrains Mono']) {
 const options={font,graphLayout:{backend:'agentic' as const,fallback:'none' as const},embedFontImport:false}
 const p=layoutRequirementDiagram(parseRequirementDiagram(source),options)
 const r=renderMermaidSVGWithReceipt(source,options)
 writeFileSync(`/tmp/pr449-week-comparison-20261101/requirement-font-7a8c58917/${font.replaceAll(' ','-')}.svg`,r.svg)
 out.push({font,caption:p.edges[0].label,node:p.nodes[0].header,captionSvg:r.svg.match(/<g class="requirement-edge-label"[\s\S]*?<\/g>/)?.[0],proof:r.receipt.layoutCertification})
}
writeFileSync('/tmp/pr449-week-comparison-20261101/requirement-font-7a8c58917/probe.json',JSON.stringify(out,null,2))
console.log(out.map(r=>({font:r.font,captionFont:r.caption.fontFamily,captionWidth:r.caption.width,nodeFont:r.node.fontFamily,captionSvg:r.captionSvg,status:r.proof?.status})))
