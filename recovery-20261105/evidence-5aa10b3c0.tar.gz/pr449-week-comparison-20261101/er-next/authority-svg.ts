import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
import assert from 'node:assert/strict'
const repo = '/tmp/pr449-main-integration-20261029-762'
const dir = '/tmp/pr449-week-comparison-20261101/er-next'
const tag = process.argv[2] ?? 'unnamed'
const { renderMermaidSVGWithReceipt } = await import(repo + '/src/index.ts')
const { layoutMermaidWithReceipt } = await import(repo + '/src/agent/core.ts')
const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim()
const diff = execFileSync('git', ['diff', '--', 'src/er/layout.ts'], { cwd: repo, encoding: 'utf8' })
writeFileSync(`${dir}/${tag}.runtime.patch`, diff)
const attrs = (tag: string): Record<string, string> => Object.fromEntries([...tag.matchAll(/([\w:-]+)="([^"]*)"/g)].map(m => [m[1]!, m[2]!]))
const point = (raw: string) => { const [x,y] = raw.split(',').map(Number); return { x:x!, y:y! } }
type Box = {x:number;y:number;width:number;height:number;half:number}
const results: unknown[] = []
for (const count of [32, 256]) for (const backend of ['elk', 'agentic'] as const) for (const direction of ['TB','BT','LR','RL']) {
  const id = `${tag}-${count}-${backend}-${direction}`
  const source = `erDiagram\ndirection ${direction}\n` + Array.from({length:count-1},(_,i)=>`N${i} ||--o{ N${i+1} : owns`).join('\n')
  const options = {graphLayout:{backend,fallback:'none' as const}}
  const row: Record<string,unknown> = {id,head,count,backend,direction,source,options,layoutCalls:0,svgCalls:0}
  try {
    row.layoutCalls = 1
    const layout = layoutMermaidWithReceipt(source,options)
    writeFileSync(`${dir}/${id}.layout.json.gz`,gzipSync(JSON.stringify(layout)))
    assert.deepEqual(layout.layout.nodes.map(n=>n.id),Array.from({length:count},(_,i)=>`N${i}`))
    assert.deepEqual(layout.layout.edges.map(e=>[e.from,e.to]),Array.from({length:count-1},(_,i)=>[`N${i}`,`N${i+1}`]))
    row.svgCalls = 1
    const rendered = renderMermaidSVGWithReceipt(source,options)
    writeFileSync(`${dir}/${id}.svg.gz`,gzipSync(rendered.svg))
    writeFileSync(`${dir}/${id}.receipt.json.gz`,gzipSync(JSON.stringify(rendered.receipt)))
    const svg = rendered.svg
    const boxes = new Map<string,Box>([...svg.matchAll(/<rect\b[^>]*>/g)].flatMap(m=>{
      const a=attrs(m[0]); return a['data-id']?.startsWith('entity-rect:') ? [[a['data-id'].slice(12),{x:+a.x!,y:+a.y!,width:+a.width!,height:+a.height!,half:+a['stroke-width']!/2}] as [string,Box]]:[]
    }))
    assert.deepEqual([...boxes.keys()].toSorted(),Array.from({length:count},(_,i)=>`N${i}`).toSorted())
    const relationships=[...svg.matchAll(/<polyline\b[^>]*class="er-relationship"[^>]*>/g)].map(m=>attrs(m[0]))
    assert.equal(relationships.length,count-1)
    const eps=1e-6
    let normalContacts=0,rawSegments=0,foreignStrokeChecks=0
    for(const [i,r] of relationships.entries()) {
      assert.deepEqual([r['data-from'],r['data-to'],r['data-cardinality1'],r['data-cardinality2'],r['data-identifying'],r['data-label']], [`N${i}`,`N${i+1}`,'one','zero-many','true','owns'])
      const points=r.points!.split(/\s+/).map(point)
      assert.ok(points.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)))
      for(const [p,q,id] of [[points[0]!,points[1]!,`N${i}`],[points.at(-1)!,points.at(-2)!,`N${i+1}`]] as const) {
        const b=boxes.get(id)!,dx=q.x-p.x,dy=q.y-p.y
        assert.ok(dy===0&&(Math.abs(p.x-b.x)<eps&&dx<0||Math.abs(p.x-b.x-b.width)<eps&&dx>0)||dx===0&&(Math.abs(p.y-b.y)<eps&&dy<0||Math.abs(p.y-b.y-b.height)<eps&&dy>0),`${id} emitted terminal normal`)
        normalContacts++
      }
      for(let j=1;j<points.length;j++) {
        const a=points[j-1]!,b=points[j]!,half=+r['stroke-width']!/2
        assert.ok(a.x===b.x||a.y===b.y); rawSegments++
        for(const [owner,box] of boxes) {
          const interior = a.y===b.y ? a.y>box.y+eps&&a.y<box.y+box.height-eps&&Math.max(a.x,b.x)>box.x+eps&&Math.min(a.x,b.x)<box.x+box.width-eps
            : a.x>box.x+eps&&a.x<box.x+box.width-eps&&Math.max(a.y,b.y)>box.y+eps&&Math.min(a.y,b.y)<box.y+box.height-eps
          assert.equal(interior,false,`${i}:${j} emitted body interior ${owner}`)
          if(owner===r['data-from']||owner===r['data-to'])continue
          const stroke = Math.min(a.x,b.x)-(a.x===b.x?half:0)<box.x+box.width+box.half&&Math.max(a.x,b.x)+(a.x===b.x?half:0)>box.x-box.half&&Math.min(a.y,b.y)-(a.y===b.y?half:0)<box.y+box.height+box.half&&Math.max(a.y,b.y)+(a.y===b.y?half:0)>box.y-box.half
          assert.equal(stroke,false,`${i}:${j} emitted foreign border ${owner}`); foreignStrokeChecks++
        }
      }
    }
    assert.equal((svg.match(/data-role="cardinality"/g)??[]).length,(count-1)*2)
    assert.equal((svg.match(/data-label="owns"/g)??[]).length,count-1)
    row.outcome='passed-independent-meaning-and-emitted-body-contact';row.normalContacts=normalContacts;row.rawSegments=rawSegments;row.foreignStrokeChecks=foreignStrokeChecks;row.certification=rendered.receipt.layoutCertification?.status
  }catch(e){row.outcome='error';row.error={name:(e as Error).name,message:(e as Error).message,stack:(e as Error).stack}}
  results.push(row)
  writeFileSync(`${dir}/${tag}.authority.json`,JSON.stringify({head,runtimeDiff:diff,results},null,2))
  console.log(JSON.stringify({...row,source:undefined,options:undefined}))
}
