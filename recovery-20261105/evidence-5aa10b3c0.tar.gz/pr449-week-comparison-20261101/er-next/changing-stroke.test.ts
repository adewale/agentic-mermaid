import {test,expect,spyOn} from 'bun:test'
import {writeFileSync} from 'node:fs'
import {layoutErDiagram} from '/tmp/pr449-main-integration-20261029-762/src/er/layout.ts'
import {parseErDiagram} from '/tmp/pr449-main-integration-20261029-762/src/er/parser.ts'
import {toMermaidLines} from '/tmp/pr449-main-integration-20261029-762/src/mermaid-source.ts'
import * as labels from '/tmp/pr449-main-integration-20261029-762/src/er/label-layout.ts'
const finalizer=labels.finalizeErRelationshipLabels
for(const authority of ['accessor','proxy'] as const)test(`changing foreign entity stroke remains read per painted shaft with ${authority}`,()=>{
  let reads=0,finalizations=0,error:any
  const spy=spyOn(labels,'finalizeErRelationshipLabels').mockImplementation((diagram,style,face,work)=>{
    const result=finalizer(diagram,style,face,work)
    finalizations++
    const z=diagram.entities.find(e=>e.id==='Z')!
    if(authority==='accessor'){
      z.inlineStyle={}
      Object.defineProperty(z.inlineStyle,'stroke-width',{enumerable:true,configurable:true,get:()=> ++reads===1?'1':'10000'})
    }else z.inlineStyle=new Proxy({'stroke-width':'1'},{get(target,key){return key==='stroke-width'?(++reads===1?'1':'10000'):Reflect.get(target,key)}})
    return result
  })
  try { layoutErDiagram(parseErDiagram(toMermaidLines('erDiagram\ndirection LR\nA ||--o{ B : owns\nB ||--o{ C : owns\nZ')),{graphLayout:{backend:'elk',fallback:'none'}}) }
  catch(e){error=e}
  finally{spy.mockRestore()}
  const result={authority,finalizations,reads,error:error?{name:error.name,message:error.message}:null}
  console.log(JSON.stringify(result))
  writeFileSync(`/tmp/pr449-week-comparison-20261101/er-next/changing-stroke-${authority}-${process.env.EVIDENCE_TAG??'unnamed'}.json`,JSON.stringify(result,null,2))
  expect(error?.name).toBe('ErRouteGeometryError')
  expect(reads).toBeGreaterThan(1)
})
