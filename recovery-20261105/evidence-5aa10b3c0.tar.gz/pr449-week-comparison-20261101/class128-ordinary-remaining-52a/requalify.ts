import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
const repo='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/class128-ordinary-remaining-52a'
const expected='52a13881d0beafe2e7ebb4cfcfae349ab20ca1e2'
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim()
if(head!==expected||execFileSync('git',['diff','HEAD','--','src'],{cwd:repo,encoding:'utf8'}))throw Error('Frozen52a changed; no calls')
if(process.env.AGENTIC_MERMAID_SCENE_ASSERTIONS!=='0'||process.env.AGENTIC_MERMAID_ELK_CACHE!=='0')throw Error('Expected assertions0/cache0 before imports')
const {renderMermaidSVGWithReceipt}=await import(repo+'/src/index.ts')
const {withRenderStageObserver}=await import(repo+'/src/render-stages.ts')
const {withPerformanceObserver}=await import(repo+'/src/performance-observations.ts')
const {apiFailure}=await import(repo+'/eval/layout-compare/outcomes.ts')
const historical=JSON.parse(gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/class128-profile/outputs.json.gz')).toString())
const options={graphLayout:{backend:'agentic' as const,fallback:'none' as const},embedFontImport:false}
const rows:any[]=[],products:any[]=[];let attempts=0
for(const [direction,oldIndex] of [['TB',0],['BT',2],['RL',6]] as const){
 const source=`classDiagram\ndirection ${direction}\n`+Array.from({length:127},(_,i)=>`N${i} --> N${i+1}`).join('\n')
 const stages:any[]=[],events:any[]=[];attempts++;const start=performance.now()
 console.log(JSON.stringify({event:'ACTUAL_CALL_START',direction,attempt:attempts}))
 try{
  const artifact=withPerformanceObserver(event=>events.push(event),()=>withRenderStageObserver(stage=>stages.push(stage),()=>renderMermaidSVGWithReceipt(source,options)))
  const product={svg:artifact.svg,receipt:artifact.receipt};const serialized=JSON.stringify(product),bytes=Buffer.from(serialized);let checksum=0
  for(const byte of bytes)checksum=(Math.imul(checksum,31)+byte)>>>0
  products.push({direction,source,options,...product})
  writeFileSync(`${out}/${direction}.svg.gz`,gzipSync(product.svg));writeFileSync(`${out}/${direction}.receipt.json.gz`,gzipSync(JSON.stringify(product.receipt)))
  rows.push({direction,source,options,status:'returned',fullyConsumedBytes:bytes.length,checksum,elapsedMs:performance.now()-start,svgSha256:createHash('sha256').update(product.svg).digest('hex'),proof:product.receipt.layoutCertification,provider:events.filter(e=>e.owner==='paint-certification'),stages,events,historical:{sameWholeSVG:product.svg===historical[oldIndex].svg,sameEntireProduct:serialized===JSON.stringify(historical[oldIndex]),note:'Retained vector predates25b; comparison descriptive not causal.'}})
 }catch(error:any){
  const failure={normalized:apiFailure(error),name:error?.name,message:error?.message,code:error?.code,stack:error?.stack,cause:error?.cause?{name:error.cause.name,message:error.cause.message,stack:error.cause.stack}:undefined,certification:error?.certification}
  const bytes=Buffer.from(JSON.stringify(failure));products.push({direction,source,options,failure});rows.push({direction,source,options,status:'refused',fullyConsumedErrorBytes:bytes.length,elapsedMs:performance.now()-start,failure,stages,events,provider:events.filter(e=>e.owner==='paint-certification')})
 }
 writeFileSync(`${out}/RESULTS.json.gz`,gzipSync(JSON.stringify({head,attempts,rows,products})))
 console.log(JSON.stringify({event:'ACTUAL_CALL_COMPLETE',...rows.at(-1)}))
}
writeFileSync(`${out}/SUMMARY.json.gz`,gzipSync(JSON.stringify({head,attempts,rows})))
console.log(JSON.stringify({event:'COMPLETE',attempts}))
