# Cyclic19 diagnostic profile review

Exactly six authorized calls completed, all P. Every profiled phase's whole SVG
and ENTIRE raw receipt matches the corresponding prior unprofiled cost product.
Before cold/repeat/edit P392818/P392818/P392614; current P392774/P392774/P392570.
No further calls, profiles, builds or production changes in this review.

The tables reuse the existing ER profile summarizer's self/inclusive ancestry
method, restricted to the three render-marker windows. Locations are profile
call-frame entry positions. **Weighted sample ms are elapsed sampling weights,
not measured self CPU time.** Inclusive rows overlap.

| Before source SELF hotspot | File:line | Samples | Weighted ms |
|---|---|---:|---:|
| runPipeline | layout/pass.ts:102 | 2 | 373.274* |
| collectLaneBlockers | layout/route-lanes.ts:215 | 63 | 105.814 |
| routeChannelMayBlock | shared/route-channel-geometry.ts:31 | 22 | 86.539 |
| pointsBounds | scene/bounds.ts:10 | 34 | 50.436 |
| countPolylineCrossings | shared/edge-crossings.ts:131 | 25 | 41.120 |

| Current source SELF hotspot | File:line | Samples | Weighted ms |
|---|---|---:|---:|
| collectLaneBlockers | layout/route-lanes.ts:215 | 37 | 53.739 |
| countPolylineCrossings | shared/edge-crossings.ts:131 | 36 | 48.478 |
| layoutLayeredGraph | layout/agentic-layered-core.ts:98 | 34 | 46.008 |
| scoreMeasuredRouteCrossingsWithAdmission | layout/measured-route-safety.ts:686 | 23 | 33.921 |
| include | scene/bounds.ts:321 | 22 | 32.697 |

* One372.111ms sample gap lands on runPipeline. The largest deltas are493.804ms
before and191.443ms current; nominal1ms sampling did not observe continuously.
Do not conclude runPipeline spent373ms doing self CPU work, or infer speedup from
the before/current ranking. Other long gaps land on import/native/package frames.

The matched new design case is the bounded first-only lane proof under
`retainedContactClear` (route-contracts.ts:136), preserving a bent endpoint seat:
21 samples/27.965 weighted inclusive ms across three renders, including
11 samples/14.150ms in collectLaneBlockers. Its self weight is2.923ms/2 samples.
Current collectLaneBlockers totals83.338ms inclusive; existing tryZRoute ancestry
accounts for52.179ms, proveLane17.009ms, and scanRouteHitches9.423ms. These ancestry
groups overlap and must not be summed. The1.457ms hasDirectLaneBlocker wrapper
sample belongs to tryZRoute, not the new retention guard.

This is existing route search/validation, not a demonstrated duplicated producer
fact. The collector already uses the node-lane index and an existence-only early
exit; certificate-producing callers still require complete ordered evidence.
No safe subtraction or performance rewrite is established, and expected speedup
is unknown. Do not remove the guard, replace certificate collection globally, add
a cache, or assign all lane samples to the new guard from these observations.

Marker wall spans in ms, cold/repeat/edit:

| Arm | Render | Entire result + receipt consumption | Forced post-GC | SVG artifact |
|---|---|---|---|---|
| Before | 1042.01/584.28/1093.19 | 4.78/4.89/3.12 | 30.39/43.10/179.76 | 3.14/0.82/1.39 |
| Current | 1057.61/597.26/374.80 | 6.92/3.42/2.65 | 25.87/58.03/88.62 | 3.45/1.33/0.56 |

Forced GC and artifact spans are outside consumed phase elapsed. Current phase
elapsed minus top-level stages is39.74/20.12/8.53ms, versus28.54/29.53/17.16ms
before. This run does **not** reproduce the old782.40ms cold remainder, so it
cannot retrospectively explain that event as serialization, routing, GC or
scheduling. No rerun was added. Imports, source overlays and profiler warmup
also prevent a startup-speed claim.

Clock alignment is supported: profile timestamps are epoch microseconds and map
to1000×(performance.timeOrigin+performance.now); Date.now corroborates within
0.95ms before/0.99ms current. Cumulative sample deltas end within0.66/0.59ms of
profile end. Interval weights are clipped to these marker windows. This supports
phase separation, not causal attribution of long gaps.

Process CPU markers include multiple threads: e.g. current cold render1057.61ms
wall versus2223.60ms aggregate process CPU. They cannot be assigned wholly to a
sampled JS frame. Native/JIT/automatic GC, sampler stalls and scheduling remain
partially opaque. Profiling, markers and observers perturb execution; N=1 per
arm, no causal timing ratios, memory claim, Amdahl bound or expected-savings claim.

`SUMMARY.json.gz` retains exact controls, clocks, CPU/wall spans, sample counts,
top self/inclusive rows and lane ancestry; original profiles, all products,
entire receipts/errors and memory data remain unchanged beside it.
