import {readFileSync} from 'node:fs'
const arm=process.env.PR449_CORE_CONTROL;if(!['unsafe','original'].includes(arm!))throw new Error('Expected control arm');
Bun.plugin({name:'joint-order-isolation-control',setup(build){build.onLoad({filter:/\/src\/layout\/agentic-layered-core\.ts$/},()=>({contents:readFileSync('/tmp/pr449-week-comparison-20261101/joint-rank-arrays-38d/checks/'+arm+'-core.ts','utf8'),loader:'ts'}))}})
