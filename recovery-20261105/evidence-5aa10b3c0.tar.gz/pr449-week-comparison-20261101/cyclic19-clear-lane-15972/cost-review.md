# Cyclic19 clear-lane cost review

Offline review only: all18 consumed calls returned (12 Agentic P,6 ELK U), no
errors/refusals. Before is exactcefbe4 with old route-contracts/layout-engine
overlaid together; current uses production without overlays. Same cyclic19
fixture/options/prefix and visible edge40 edit throughout. N=1 per cell, no timing
ratios, speed, memory or Amdahl claim. Imports are separately timed; phase time
includes the entire result serialization/checksum, excludes forced post-phase GC
and artifact compression. Three full products remain held per worker.

Current Agentic cold whole SVG and ENTIRE raw receipt exactly match the corrected
prototype in both modes. All six same-arm cold/repeat pairs match whole SVG and
ENTIRE receipt. Both Agentic cache-on repeats actually hit positioned-layout;
edits miss. ELK before/current whole SVG and ENTIRE receipts match in all three
phases, retaining U400000/CHECK_BUDGET only (pairs1170, edit1180). No P-only gate.

Every saved SVG retains all19 authored node literals,44 ordered endpoint/caption
occurrences and11 caption literals. The unique `edge 40 xxxxxxxxx` becomes
`edge 40 revised` on edit, with identities/endpoints retained. In the five reviewed
head occurrences, actual Agentic anchors change from two distinct seats to five
in cold/repeat/edit, both modes. Current cold is the exact independently reviewed
prototype, so its saved meaning/ink evidence applies; this review adds no raster
calls. Agentic proof remains P:392818→392774 cold/repeat,392614→392570 edit;
pairs1043→1048 (edit1033→1038). This closes a visible head-distinction gap, not
proof capacity. Canvas and bend count remain unchanged in the independent review.

Cold/repeat/edit elapsed ms and worker peak RSS KiB, before → current:

| Case | Elapsed ms | Peak RSS KiB |
|---|---|---|
| Agentic cache-off | 880.66/466.61/463.81 → 1609.75/787.09/511.18 | 239104 → 246896 |
| Agentic cache-on | 736.10/89.90/375.22 → 812.41/112.31/343.60 | 243468 → 225896 |
| ELK cache-off | 1559.50/656.21/695.16 → 1969.93/1208.92/557.90 | 330884 → 326632 |

All three Agentic cache-off phases, Agentic cache-on cold/repeat, and ELK cold/
repeat are adverse. Agentic cache-off cold recorded layout falls623.34→530.62ms,
while elapsed rises. Elapsed minus summed top-level stages is26.21→782.40ms;
that remainder includes full consumption and other unobserved work. Its cause is
unattributed: no GC, scheduling, routing-cost or Amdahl attribution. Agentic off
repeat layout is separately adverse373.46→618.82ms. Cache-on repeat layout is
0.51→0.33ms, while drawing56.57→71.47ms and certification16.42→19.32ms.
ELK recorded layout cold/repeat is1267.07/530.36→1704.05/970.02ms despite exact
products. These N1 observations are retained without favorable reruns.

Post-GC RSS/heap MiB, cold/repeat/edit, before → current:

| Case | RSS MiB | Heap MiB |
|---|---|---|
| Agentic off | 154.75/194.10/231.82 → 142.65/189.16/238.04 | 24.42/25.65/27.29 → 24.43/26.58/27.24 |
| Agentic on | 156.55/158.25/234.22 → 143.32/145.41/219.44 | 23.91/25.51/27.74 → 23.83/25.37/27.86 |
| ELK off | 244.26/290.39/306.38 → 237.26/286.95/301.20 | 47.68/50.66/52.66 → 47.65/50.75/52.73 |

Memory is mixed: adverse Agentic off peak/edit RSS and repeat heap, Agentic on edit
heap, and ELK repeat/edit heap remain enrolled. Lower RSS elsewhere is no memory
win claim. Before/current import ms are1159.62→418.77 (AM off),957.15→468.12
(AM on),1129.76→582.19 (ELK off); import and overlay differences are excluded
from phase timings and cannot support startup-speed claims.

Full18-product evidence and stage/memory data: `COST-FINAL-EVIDENCE.json.gz` here;
each `cyclic-contact-{cache0,cache1,elk-cache0}-cost-cefbe4a73` report retains
RESULTS/SUMMARY, complete raw receipts/SVGs, literal modules and candidate patch.
Keep for bounded authored head distinction despite measured adverse costs.
