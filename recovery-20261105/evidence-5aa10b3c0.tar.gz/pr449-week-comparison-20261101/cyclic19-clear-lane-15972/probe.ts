// Adapted retained one-call cyclic19 worker; sole route-contracts onLoad overlay.
// HOLD: one public SVG call only after explicit ROOT GO.
import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import assert from 'node:assert/strict'
const root = '/tmp/pr449-main-integration-20261029-762'
const out = '/tmp/pr449-week-comparison-20261101/cyclic19-clear-lane-15972'
if (process.env.AM_CYCLIC19_CLEAR_LANE_ROOT_GO !== '1') throw new Error('HOLD: explicit ROOT GO required')
const original = readFileSync(out + '/route-contracts.original.ts')
assert.deepEqual(readFileSync(root + '/src/route-contracts.ts'), original)
let calls = 0, loaded = 0
Bun.plugin({ name: 'nonshipping-cyclic19-existing-lane-proof', setup(build) {
  build.onLoad({ filter: /\/src\/route-contracts\.ts$/ }, args => {
    assert.deepEqual(readFileSync(args.path), original)
    loaded++
    return { contents: readFileSync(out + '/route-contracts.candidate.ts', 'utf8'), loader: 'ts' }
  })
}})
try {
  const baseline = JSON.parse(gunzipSync(readFileSync('/tmp/pr449-week-comparison-20261101/cyclic15-19-b063/current-cyclic-labelled-19.mmd-agentic.json.gz')).toString())
  const source = readFileSync(root + '/eval/layout-compare/fixtures/cyclic-labelled-19.mmd', 'utf8')
  assert.equal(source, baseline.source)
  const options = { graphLayout: { backend: 'agentic' as const, fallback: 'none' as const }, embedFontImport: false, idPrefix: 'cycle-check-' }
  const { renderMermaidSVGWithReceipt } = await import(root + '/src/index.ts')
  assert.equal(loaded, 1)
  calls++
  const result = renderMermaidSVGWithReceipt(source, options)
  const { retainedLaneProofWork } = await import(root + '/src/route-contracts.ts') as any
  const serialized = JSON.stringify(result)
  let sum = 0
  for (let i = 0; i < serialized.length; i++) sum += serialized.charCodeAt(i)
  const record = { scope: 'NONSHIPPING existing-lane-proof candidate; one route-contracts overlay; real extra scans recorded; no timing claim', source, options,
    publicSVGCalls: calls, publicLayoutCalls: 0, loaded, retainedLaneProofWork, result, byteExactOldSVG: result.svg === baseline.svg,
    consumed: { utf16Units: serialized.length, utf8Bytes: Buffer.byteLength(serialized), sum },
    retainedBaseline: '/tmp/pr449-week-comparison-20261101/cyclic15-19-b063/current-cyclic-labelled-19.mmd-agentic.json.gz' }
  writeFileSync(out + '/result.json.gz', gzipSync(JSON.stringify(record)))
  writeFileSync(out + '/raw-receipt.json.gz', gzipSync(JSON.stringify(result.receipt)))
  writeFileSync(out + '/actual.svg.gz', gzipSync(result.svg))
  const summary = { scope: record.scope, publicSVGCalls: calls, publicLayoutCalls: 0, loaded, retainedLaneProofWork,
    proof: result.receipt.layoutCertification, byteExactOldSVG: record.byteExactOldSVG, consumed: record.consumed }
  writeFileSync(out + '/SUMMARY.json', JSON.stringify(summary, null, 2))
  console.log(JSON.stringify(summary))
} catch (error) {
  const failure = { publicSVGCalls: calls, publicLayoutCalls: 0, error: { name: (error as Error).name, message: (error as Error).message, stack: (error as Error).stack } }
  writeFileSync(out + '/FAILURE.json', JSON.stringify(failure, null, 2))
  console.log(JSON.stringify(failure)); process.exitCode = 1
}
