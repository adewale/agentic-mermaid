import {readFileSync} from 'node:fs'
Bun.plugin({name:'old-route-only',setup(build){build.onLoad({filter:/\/src\/route-contracts\.ts$/},()=>({contents:readFileSync('/tmp/pr449-week-comparison-20261101/cyclic19-clear-lane-15972/route-contracts.original.ts','utf8'),loader:'ts'}))}})
