Saved-product independent review; zero public SVG/layout calls and no source edits.

All 44 authored ordered relations, all 19 node identities/names, and all 11 caption literals survive exactly. Entire node markup is byte-equal. Seven route point lists changed; six target tips moved and one interior jog changed. Actual target coordinates improve from 41 distinct to 44 distinct (no shared target coordinates).

Viewport/area remain 857.439 × 1438.504 = 1233429.431256 px². Manhattan wire decreases 16134.741821019 → 15849.613081799 px (−285.128739220, -1.767173%). Actual noncollinear bends remain 102.

Individual marker-end removal from the exact saved candidate XML establishes positive surviving ink for all five original collision-group heads:
- Edge 2 (edge:n9->n13#0), tip [577.166, 1349.55663355]: 120 darker pixels; 0 changed pixels outside its actual marker ROI.
- Edge 13 (edge:n2->n18#0), tip [717.235, 859.574]: 120 darker pixels; 0 changed pixels outside its actual marker ROI.
- Edge 15 (edge:n18->n13#0), tip [657.36, 1350.87661451]: 125 darker pixels; 0 changed pixels outside its actual marker ROI.
- Edge 20 (edge:n5->n13#0), tip [613.263, 1347.604]: 121 darker pixels; 0 changed pixels outside its actual marker ROI.
- Edge 38 (edge:n16->n18#0), tip [761.332, 859.574]: 120 darker pixels; 0 changed pixels outside its actual marker ROI.

Three additional moved heads also have positive individual removal controls (all eight controls retained in independent-review.json). Every differential lies within its independently transformed actual marker-resource ROI. Fixed normal Inter font files were checked against the repository manifest byte lengths/SHA256, with system fonts disabled. Eleven offline raster calls total: ten successful raster products plus one full-image setup attempt before correcting raw XML tag selection. No font-universal/browser/arbitrary-input claim.
