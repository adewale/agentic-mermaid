import fs from 'node:fs'
import {createHash} from 'node:crypto'
import {gzipSync,gunzipSync} from 'node:zlib'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import {prepareResvgMarkerOrientation} from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/class-caption-seat-0684',scratch=fs.mkdtempSync('/dev/shm/pr449-class-residual-ink-')
const save=(name:string,value:unknown)=>fs.writeFileSync(`${out}/${name}.gz`,gzipSync(typeof value==='string'||value instanceof Uint8Array?value:JSON.stringify(value)))
try{
 const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter'),fontFiles=fonts.map(f=>{const b=fs.readFileSync(`${root}/${f.path}`);if(b.length!==f.bytes||createHash('sha256').update(b).digest('hex')!==f.sha256)throw Error('Font manifest mismatch');const path=`${scratch}/${f.file}`;fs.writeFileSync(path,b);return path})
 const raw=gunzipSync(fs.readFileSync(`${out}/owner-after-elk-LR.svg.gz`)).toString(),full=raw.replace(/width="[^"]+"/,'width="881"').replace(/height="[^"]+"/,'height="355"').replace(/viewBox="[^"]+"/,'viewBox="-20 -20 881 355"')
 let texts=0,heads=0
 const mask=full.replace(/<text\b([^>]*)>retries<\/text>/,(_,a)=>{texts++;return`<text opacity="0"${a}>retries</text>`}).replace(/<polyline\b[^>]*class="(?:class-relationship|class-marker-overlay)"[^>]*\/>/g,t=>t.replace(/ marker-end="url\(#cls-inherit\)"/,()=>{heads++;return''}))
 if(texts!==1||heads!==2)throw Error(`Unexpected mask ownership ${texts}/${heads}`)
 const images=[full,mask].map((s,i)=>{const prepared=prepareResvgMarkerOrientation(inlineFontVarForRaster(s));save(`INK-${i?'mask':'full'}.svg`,prepared);const r=new Resvg(prepared,{background:'#ffffff',fitTo:{mode:'zoom',value:2},font:{fontFiles,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();save(`INK-${i?'mask':'full'}.png`,r.asPng());return{width:r.width,height:r.height,pixels:r.pixels}})
 const[a,b]=images,rois={retries:[689,106,729,126],realizationHead:[719,125,738,146]},controls=Object.fromEntries(Object.keys(rois).map(k=>[k,{changed:0,darker:0,lighter:0}]));let outsideFull=0,outsideMask=0,unattributed=0,changedOutside=0,borrowedPixels=0
 for(let y=0;y<a.height;y++)for(let x=0;x<a.width;x++){const i=(y*a.width+x)*4,wx=(x+.5)/2-20,wy=(y+.5)/2-20,outside=wx<0||wx>840.768||wy<0||wy>314.2;if(outside){if(Math.min(a.pixels[i],a.pixels[i+1],a.pixels[i+2])<245)outsideFull++;if(Math.min(b.pixels[i],b.pixels[i+1],b.pixels[i+2])<245)outsideMask++}if(![0,1,2,3].some(c=>Math.abs(a.pixels[i+c]-b.pixels[i+c])>=4))continue;if(outside)changedOutside++;let owners=0;for(const[k,r]of Object.entries(rois)){if(wx<r[0]||wx>r[2]||wy<r[1]||wy>r[3])continue;owners++;controls[k].changed++;if(a.pixels[i]+a.pixels[i+1]+a.pixels[i+2]<b.pixels[i]+b.pixels[i+1]+b.pixels[i+2])controls[k].darker++;else controls[k].lighter++}if(!owners)unattributed++;if(owners>1)borrowedPixels++}
 const report={offlineRasterCalls:2,publicCalls:0,sourceSvg:`${out}/owner-after-elk-LR.svg.gz`,beforeEvidence:'before-LR.error.json.gz (no SVG returned)',controls,outsideFull,outsideMask,changedOutside,unattributed,borrowedPixels,verifiedFonts:fonts.map(f=>({file:f.file,weight:f.weight,style:f.style,bytes:f.bytes,sha256:f.sha256})),fontOptions:{fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'},scope:'NewlydeliveredsavedLRretriescaption andhollowrealizationhead;RLvectorqualifiedonly; textopacitypreservespositions andbothsemanticandoverlayrefsremoved. No publicPNG/browser/universalfont/fullinkclaim.'};save('INDEPENDENT-INK.json',report);console.log(JSON.stringify(report))
}finally{fs.rmSync(scratch,{recursive:true,force:true})}
