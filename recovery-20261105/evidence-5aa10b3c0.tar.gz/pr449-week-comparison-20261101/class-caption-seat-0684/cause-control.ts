import fs from 'node:fs'
import{gzipSync,gunzipSync}from'node:zlib'
const root='/tmp/pr449-main-integration-20261029-762',dir='/tmp/pr449-week-comparison-20261101/class-caption-seat-0684'
Bun.plugin({name:'old-caption-association-control',setup(build){build.onLoad({filter:/\/src\/class\/annotation-seats\.ts$/},args=>{
 let source=fs.readFileSync(args.path,'utf8');source=source.replace("if (seat.role === 'caption') {\n      const near", "if (seat.role === 'caption' && changed?.has(seat.edge)) {\n      const near").replace('side * (seat.block.height / 2 + RELATION_LABEL_OFFSET_Y)','side * RELATION_LABEL_OFFSET_Y');return{contents:source,loader:'ts'}
})}})
const{renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts'),template=JSON.parse(gunzipSync(fs.readFileSync(dir+'/INPUT.json.gz')).toString()).template
for(const direction of ['LR','RL'])try{const result=renderMermaidSVGWithReceipt(template.replace('DIRECTION',direction),{graphLayout:{backend:'elk',fallback:'none'},embedFontImport:false});fs.writeFileSync(dir+`/old-association-control-${direction}.svg.gz`,gzipSync(result.svg));console.log(JSON.stringify({direction,returned:true,proof:result.receipt.layoutCertification?.status}))}catch(e:any){console.log(JSON.stringify({direction,returned:false,name:e.name,message:e.message}))}
