import fs from 'node:fs'
import {gzipSync} from 'node:zlib'
import {spyOn} from 'bun:test'
import * as api from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const actual=api.renderMermaidSVGWithReceipt,out='/tmp/pr449-week-comparison-20261101/class-caption-seat-0684',arm=process.env.PR449_CAPTURE_ARM
spyOn(api,'renderMermaidSVGWithReceipt').mockImplementation((source,options)=>{
 if(!source.includes('Keep authored Gateway note'))return actual(source,options)
 const tag=`${arm}-${options?.graphLayout?.backend}-${/direction (\w+)/.exec(source)?.[1]}`,save=(name,value)=>fs.writeFileSync(`${out}/${tag}.${name}.gz`,gzipSync(typeof value==='string'?value:JSON.stringify(value)))
 try{const r=actual(source,options);save('svg',r.svg);save('receipt.json',JSON.stringify(r.receipt));return r}catch(e){save('error.json',{name:e?.name,message:e?.message,code:e?.code,stack:e?.stack});throw e}
})
