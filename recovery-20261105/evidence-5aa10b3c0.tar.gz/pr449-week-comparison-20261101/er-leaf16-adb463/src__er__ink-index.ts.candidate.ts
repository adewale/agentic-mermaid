import { createInkIndex, type InkBounds } from '../shared/ink-index.ts'
export type { InkBounds as ErInkBounds } from '../shared/ink-index.ts'

/** ER batches trade fewer tree partitions for more exact leaf checks. */
export function erInkIndex<T>(items: readonly T[], bounds: (item: T) => InkBounds, charge: (count?: number) => void, expectedQueries: number): (box: InkBounds) => T[] {
  return createInkIndex(items, bounds, charge, expectedQueries, 16)
}
