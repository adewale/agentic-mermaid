# Read-only reduction of already measured products. No public/layout/build calls.
import pathlib,json,gzip,subprocess
W=pathlib.Path('/tmp/pr449-week-comparison-20261101');R=pathlib.Path('/tmp/pr449-main-integration-20261029-762');H='52a13881d0beafe2e7ebb4cfcfae349ab20ca1e2'
def raw(p):return gzip.decompress(pathlib.Path(p).read_bytes())
def read(p):return json.loads(raw(p))
def gz(p,v):p.write_bytes(gzip.compress(json.dumps(v,separators=(',',':')).encode(),mtime=0))
def diffs(a,b,p=''):
 if type(a)!=type(b):return[p]
 if isinstance(a,dict):return sum((diffs(a[k],b[k],p+'.'+k)if k in a and k in b else[p+'.'+k]for k in a.keys()|b.keys()),[])
 if isinstance(a,list):return[p]if len(a)!=len(b)else sum((diffs(x,y,p+f'[{i}]')for i,(x,y)in enumerate(zip(a,b))),[])
 return[]if a==b else[p]
combined={'head':H,'costCalls':0,'batches':[],'statusCounts':{},'limits':['N=1 per cell; no causal speed, memory/allocation or preservation claim','U-to-P is unequal completed proof work; no timing ratio','All adverse elapsed/RSS/heap/stage rows retained, including17.742s paint and5.700s backend tails; cause unresolved','Post-GC memory includes imports/overlays/harness/observers/three held products; forced Bun.gc(true) runs after elapsed/stage clocks; automatic GC/host scheduling/internal CPU cannot be isolated','No favorable reruns, timing replays, profile, or ER256-chain calls in these cost batches']}
allRows=[]
for cache in [0,1]:
 O=W/f'er-scene-cache{cache}-cost-{H[:9]}';d=read(O/'RESULTS.json.gz');assert d['completed']and d['candidateHead']==H
 rows=[];pairs=[];hits=[];by={(r['count'],r['backend'],r['arm']):r for r in d['runs']}
 for r in d['runs']:
  phases=[]
  for x in r['rows']:
   proof=x.get('proof',{});key=x['status']+'/'+proof.get('status','none');combined['statusCounts'][key]=combined['statusCounts'].get(key,0)+1
   top={}
   for st in x['stages']:
    if st['depth']==0:top[st['stage']]=top.get(st['stage'],0)+st['ms']
   phases.append({'phase':x['phase'],'status':x['status'],'proof':proof,'elapsedMs':x['elapsedMs'],'fullyConsumedBytes':x.get('bytes'),'checksum':x.get('checksum'),'afterGC':x['afterGC'],'topLevelStageMs':top,'unscopedElapsedMs':x['elapsedMs']-sum(top.values()),'allStages':x['stages'],'paintProviderEvents':x['paintProviderEvents'],'allEvents':x['events'],'svgReference':x.get('svgReference'),'receiptReference':x.get('receiptReference')})
  row={'case':r['count'],'backend':r['backend'],'arm':r['arm'],'source':r['source'],'edited':r['edited'],'options':r['options'],'importMs':r['importMs'],'peakRssKiB':r['peakRssKiB'],'loaded':r['loaded'],'overlayLoads':r['overlayLoads'],'phases':phases};rows.append(row);allRows.append({'cache':cache,**row})
  if r['arm']=='after':
   old=by[(r['count'],r['backend'],'before')]
   for a,b in zip(old['rows'],r['rows']):
    assert a['phase']==b['phase']and a['status']==b['status']=='returned'
    pairs.append({'case':r['count'],'backend':r['backend'],'phase':a['phase'],'wholeSVGExact':raw(a['svgReference'])==raw(b['svgReference']),'entireRawReceiptExact':a['receiptJSON']==b['receiptJSON'],'receiptDifferencePaths':diffs(json.loads(a['receiptJSON']),json.loads(b['receiptJSON']))})
  if cache:
   cold,repeat,edit=r['rows'];outcome=lambda p:[e['outcome']for e in p['events']if e.get('owner')=='positioned-layout']
   hits.append({'backend':r['backend'],'arm':r['arm'],'positionedLayout':{'cold':outcome(cold),'repeat':outcome(repeat),'edit':outcome(edit)},'repeatActuallyHit':outcome(repeat)==['hit'],'editActuallyMissed':outcome(edit)==['miss'],'ownColdRepeatWholeSVGExact':raw(cold['svgReference'])==raw(repeat['svgReference']),'ownColdRepeatEntireRawReceiptExact':cold['receiptJSON']==repeat['receiptJSON'],'editSVGDiffersFromCold':raw(cold['svgReference'])!=raw(edit['svgReference'])})
 summary={'head':H,'cache':cache,'beforeRuntimeRevision':d['beforeRuntimeRevision'],'actualPublicCalls':d['actualPublicCalls'],'fullyConsumedBytes':sum(x['fullyConsumedBytes']for r in rows for x in r['phases']),'completed':d['completed'],'errors':d['errors'],'sourceUnchanged':d['scenePolicySourceUnchanged'],'ramRemoved':d['ramRemoved'],'scope':d['scope'],'rows':rows,'beforeCurrentPairs':pairs,'cacheTransitions':hits};gz(O/'SUMMARY.json.gz',summary)
 combined['costCalls']+=d['actualPublicCalls'];combined['batches'].append({'cache':cache,'calls':d['actualPublicCalls'],'fullyConsumedBytes':summary['fullyConsumedBytes'],'summaryReference':str(O/'SUMMARY.json.gz'),'allBeforeCurrentSVGExact':all(p['wholeSVGExact']for p in pairs),'beforeCurrentPairCount':len(pairs),'cacheTransitions':hits})
 print('\nCACHE',cache,'calls',d['actualPublicCalls'],'bytes',summary['fullyConsumedBytes'],'SVG pairs',len(pairs),'allExact',all(p['wholeSVGExact']for p in pairs))
 for case in list(dict.fromkeys(r['case']for r in rows)):
  for backend in ['agentic','elk']:
   a=next(r for r in rows if r['case']==case and r['backend']==backend and r['arm']=='before');b=next(r for r in rows if r['case']==case and r['backend']==backend and r['arm']=='after')
   fmt=lambda vals:'/'.join(f'{x:.2f}'for x in vals)
   val=lambda r,key:[p[key]for p in r['phases']]
   print(case,backend,'ms',fmt(val(a,'elapsedMs')),'->',fmt(val(b,'elapsedMs')),'RSSKiB',a['peakRssKiB'],'->',b['peakRssKiB'],'heapMiB',fmt([p['afterGC']['heapUsed']/1048576 for p in a['phases']]),'->',fmt([p['afterGC']['heapUsed']/1048576 for p in b['phases']]),'ops',[p['proof']['checks']['operations']for p in a['phases']],'->',[p['proof']['checks']['operations']for p in b['phases']])
 print('CACHE',hits)
 assert all(p['wholeSVGExact']for p in pairs)
# Preserve requested adverse-stage evidence with all top-level buckets and full post-GC data.
adverse=[]
for row in allRows:
 if row['case']=='256cards'and row['backend']=='elk' or row['case']==32 and row['backend']=='elk' or row['case']==208:
  adverse.append(row)
gz(W/f'er-scene-cache0-cost-{H[:9]}'/'ADVERSE-STAGES.json.gz',{'rows':adverse,'limits':combined['limits']})
# Existing canonical payload context; no new before build.
P=W/f'recovery-payload/er-scene-{H[:9]}';B=W/'recovery-payload/native-group-cyclic19-25b6c43b0';current=read(P/'OUTCOME.json.gz');before=read(B/'OUTCOME.json.gz');comparison={'baselineHead':before['head'],'productionEquivalentBefore':'3e43badc5ebd110df717273cf952cd4e3dd36142','candidateHead':H,'beforeReportReference':str(B/'report.json.gz'),'currentReportReference':str(P/'report.json.gz'),'newBeforeBuilds':0,'closures':{}}
for name,a,b in [('agentic',before['er']['nativeSolver'],current['er']['nativeSolver']),('elk',before['er'],current['er']),('static',before['er']['static'],current['er']['static']),('initial',before['initial'],current['initial'])]:
 keys=['requests','raw','gzip','brotli'];comparison['closures'][name]={'before':{k:a[k]for k in keys},'current':{k:b[k]for k in keys},'delta':{k:b[k]-a[k]for k in keys}}
gz(P/'BASELINE-COMPARISON.json.gz',comparison)
combined['nodeSourceCalls']=2;combined['buildCalls']=current['buildCalls'];combined['compiledCalls']=current['actualRenderCalls'];combined['payloadCompleted']=current['completed'];combined['payloadErrors']=current['errors'];combined['payloadReference']=str(P/'OUTCOME.json.gz');combined['payloadComparisonReference']=str(P/'BASELINE-COMPARISON.json.gz');combined['compiledBindings']={tag:{'wholeSVGExact':v['wholeSvgExactUnbundledWitness'],'entireRawReceiptExact':v['entireRawReceiptExactUnbundledWitness'],'runtime':v['runtime'],'status':v['outcome'],'proof':v['proof']['status'],'operations':v['proof']['checks']['operations'],'layoutDecisions':v.get('layoutDecisions'),'executionDecision':v.get('executionDecision')}for tag,v in current['renders'].items()}
combined['sourceWitnessReference']=str(W/f'er-scene-node24-{H[:9]}'/'OUTCOME.json.gz');combined['headAfterMeasurements']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();combined['dirtyProductionBuildPaths']=[p for p in subprocess.check_output(['git','diff','--name-only','HEAD','--','src','tsup.browser-lazy.config.ts','scripts/build'],cwd=R,text=True).splitlines()if not p.startswith('src/__tests__/')and '/__tests__/'not in p];combined['sourceCleanAtRecordedHead']=combined['headAfterMeasurements']==H and not combined['dirtyProductionBuildPaths'];combined['ramRemoved']=all(read(W/f'er-scene-cache{c}-cost-{H[:9]}'/'RESULTS.json.gz')['ramRemoved']for c in [0,1])and current['ramRemoved']
combined['harnessPreparationNote']='An added cache0 early-SVG-stop patch failed AST validation before changing the prepared controller; original cache0 controller ran, with worker refusal-stop applied. No refusal or SVG-difference trigger occurred; retained comparisons were checked live at33calls and all18pairs at36 before cache1. Cache1 used corrected early-stop guards. No extra public calls or production changes resulted.'
gz(W/f'er-scene-cache0-cost-{H[:9]}'/'FINAL-EVIDENCE.json.gz',combined);print('\nPAYLOAD',json.dumps(comparison['closures'],indent=2));print('FINAL COUNTS',combined['costCalls'],combined['statusCounts'],'BINDINGS',combined['compiledBindings'],'SOURCE CLEAN',combined['sourceCleanAtRecordedHead'])
