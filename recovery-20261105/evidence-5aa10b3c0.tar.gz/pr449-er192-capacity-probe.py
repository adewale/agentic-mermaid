from pathlib import Path
import os,json,subprocess,gzip
R=Path('/tmp/pr449-main-integration-20261029-762'); O=Path('/tmp/pr449-week-comparison-20261101/er-terminal-parts-bb749/agentic192');O.mkdir(exist_ok=True)
worker=Path('/tmp/pr449-er-terminal-cost-worker.ts').read_text().replace("[['cold', source], ['repeat', source], ['edit', edited]]", "[['cold', source]]")
assert "[['cold', source]]" in worker
(O/'worker.ts').write_text(worker)
source='erDiagram\ndirection LR\n'+'\n'.join(f'N{i} ||--o{{ N{i+1} : owns' for i in range(191))
(O/'source.mmd').write_text(source);(O/'options.json').write_text(json.dumps({'graphLayout':{'backend':'agentic','fallback':'none'}}))
(O/'before.ts').write_bytes(subprocess.check_output(['git','show','bb7492b44:src/er/layout.ts'],cwd=R));(O/'after.ts').write_bytes((R/'src/er/layout.ts').read_bytes())
E=dict(os.environ,PATH='/tmp/pr449-bin:'+os.environ['PATH'],AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0',NODE_DISABLE_COMPILE_CACHE='1')
for arm in ['before','after']:
 job={'root':str(R),'count':192,'backend':'agentic','arm':arm,'overlay':str(O/(arm+'.ts')),'sourceFile':str(O/'source.mmd'),'editFile':str(O/'source.mmd'),'optionsFile':str(O/'options.json'),'out':str(O/arm)};(O/'job.json').write_text(json.dumps(job))
 p=subprocess.run(['/tmp/pr449-bin/bun',str(O/'worker.ts'),str(O/'job.json')],cwd=R,env=E,capture_output=True,timeout=180)
 (O/(arm+'.log')).write_bytes(p.stdout+p.stderr);print(arm,'exit',p.returncode,flush=True);assert p.returncode==0
 j=json.loads(gzip.decompress((O/(arm+'.json.gz')).read_bytes()));row=j['rows'][0]
 print(json.dumps({'arm':arm,'publicCalls':j['actualPublicCalls'],'overlayLoads':j['overlayLoads'],'status':row['status'],'proof':row.get('proof'),'failure':row.get('failure'),'paintProviderEvents':row['paintProviderEvents']}),flush=True)
 if arm=='before' and row['status']=='returned':print('STOP: ordinary192 Agentic already delivered before change; no new owning test/capacity claim',flush=True);break
assert (R/'src/er/layout.ts').read_bytes()==(O/'after.ts').read_bytes()
