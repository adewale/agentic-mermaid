import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { registerHooks, stripTypeScriptTypes } from 'node:module';
import { gzipSync } from 'node:zlib';
const root='/tmp/pr449-main-integration-20261029-762';
const out='/tmp/pr449-week-comparison-20261101/flowchart-node24-calibration-fff8c38ef';
fs.mkdirSync(out,{recursive:true});
const row={runtime:process.version,actualPublicCalls:0,setupErrors:[],root,loader:'Node built-in registerHooks; stripTypeScriptTypes mode=transform; existing extensionless relative .ts resolution',status:'setup'};
const gz=(name,value)=>fs.writeFileSync(out+'/'+name,gzipSync(typeof value==='string'?value:JSON.stringify(value)));
try {
 registerHooks({
  resolve(specifier,context,nextResolve){
   if(specifier.startsWith('.')&&context.parentURL?.startsWith(pathToFileURL(root+'/').href)){
    const candidate=new URL(specifier,context.parentURL);
    if(!path.extname(candidate.pathname)&&fs.existsSync(fileURLToPath(candidate)+'.ts'))return nextResolve(candidate.href+'.ts',context);
    if(!path.extname(candidate.pathname)&&fs.existsSync(fileURLToPath(candidate)+'.js'))return nextResolve(candidate.href+'.js',context);
   }
   if(specifier.startsWith('roughjs/bin/')&&!path.extname(specifier))return nextResolve(specifier+'.js',context);
   return nextResolve(specifier,context);
  },
  load(url,context,nextLoad){
   if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.json'))return {format:'json',shortCircuit:true,source:fs.readFileSync(fileURLToPath(url),'utf8')};
   if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.ts'))return {format:'module',shortCircuit:true,source:stripTypeScriptTypes(fs.readFileSync(fileURLToPath(url),'utf8'),{mode:'transform',sourceUrl:url})};
   return nextLoad(url,context);
  }
 });
 const bindings=JSON.parse(fs.readFileSync('/tmp/pr449-week-comparison-20261101/flowchart-fit-cost-fff8c38ef/bindings-cyclic9.json','utf8'));
 const binding=bindings.find(x=>x.backend==='agentic');
 if(!binding||binding.family!=='flowchart')throw new Error('Missing exact Agentic binding');
 row.binding=binding;
 const api=await import(pathToFileURL(root+'/src/index.ts').href);
 row.status='calling';process.stdout.write('ACTUAL_PUBLIC_CALL_START\n');row.actualPublicCalls++;
 try {
  const result=api.renderMermaidSVGWithReceipt(binding.source,binding.options);
  const bytes=Buffer.from(JSON.stringify(result),'utf8');let checksum=0;for(const n of bytes)checksum=(Math.imul(checksum,31)+n)>>>0;
  gz('agentic.svg.gz',result.svg);gz('agentic.receipt.json.gz',JSON.stringify(result.receipt));
  row.status='returned';row.bytes=bytes.length;row.checksum=checksum;row.proof=result.receipt.layoutCertification;
 }catch(error){row.status='refused';row.failure={name:error.name,message:error.message,stack:error.stack,cause:{name:error.cause?.name,message:error.cause?.message,stack:error.cause?.stack}};const bytes=Buffer.from(JSON.stringify(row.failure));let checksum=0;for(const n of bytes)checksum=(Math.imul(checksum,31)+n)>>>0;row.consumedFailure={bytes:bytes.length,checksum};}
}catch(error){row.status='setup-error';row.setupErrors.push({name:error.name,message:error.message,stack:error.stack});}
finally{gz('OUTCOME.json.gz',row);process.stdout.write(JSON.stringify({status:row.status,actualPublicCalls:row.actualPublicCalls,setupErrors:row.setupErrors,operations:row.proof?.checks?.operations})+'\n');}
