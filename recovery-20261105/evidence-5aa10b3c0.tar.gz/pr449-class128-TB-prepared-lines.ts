import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
const directory = '/tmp/pr449-week-comparison-20261101/class128-TB-prepared-lines-f1e'
mkdirSync(directory, { recursive: true })
const baselinePath = '/tmp/pr449-week-comparison-20261101/class-ledger-f1e/TB/RESULT.json.gz'
const baseline = JSON.parse(gunzipSync(readFileSync(baselinePath)).toString())
const { renderMermaidSVGWithReceipt } = await import('/tmp/pr449-main-integration-20261029-762/src/index.ts')
const { withPerformanceObserver } = await import('/tmp/pr449-main-integration-20261029-762/src/performance-observations.ts')
const { withRenderStageObserver } = await import('/tmp/pr449-main-integration-20261029-762/src/render-stages.ts')
const events: unknown[] = [], stages: unknown[] = []
let product, failure
try {
  product = withPerformanceObserver(event => events.push(event), () => withRenderStageObserver(stage => stages.push(stage), () => renderMermaidSVGWithReceipt(baseline.source, baseline.options)))
} catch (error: any) {
  failure = { name: error.name, message: error.message, code: error.code, stack: error.stack, certification: error.certification }
}
const differences = (a: any, b: any, prefix = ''): string[] => {
  if (a && b && typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) return [...new Set([...Object.keys(a), ...Object.keys(b)])].flatMap(key => differences(a[key], b[key], prefix ? prefix + '.' + key : key))
  return JSON.stringify(a) === JSON.stringify(b) ? [] : [prefix]
}
const packet = { baselinePath, actualPublicCalls: 1, source: baseline.source, options: baseline.options, entry: '/src/index.ts:renderMermaidSVGWithReceipt', product, failure, stages, events,
  comparison: product ? { wholeSvgEqual: product.svg === baseline.product.svg, entireReceiptEqual: JSON.stringify(product.receipt) === JSON.stringify(baseline.product.receipt), receiptDifferencePaths: differences(baseline.product.receipt, product.receipt) } : undefined }
writeFileSync(directory + '/RESULT.json.gz', gzipSync(JSON.stringify(packet)))
if (product) {
  writeFileSync(directory + '/TB.svg.gz', gzipSync(product.svg))
  writeFileSync(directory + '/TB.receipt.json.gz', gzipSync(JSON.stringify(product.receipt)))
}
console.log(JSON.stringify({ actualPublicCalls: 1, returned: !!product, failure, comparison: packet.comparison, proof: product?.receipt.layoutCertification, providers: events.filter((event: any) => event.owner === 'paint-certification') }, null, 2))
