import { readFileSync } from 'node:fs'
const arm=process.env.AM_REMAINING_OWNER_ARM
if(arm!=='before'&&arm!=='current')throw new Error('explicit remaining-owner replay arm required')
if(arm==='before')await import('/tmp/pr449-native-group-font-truth-before-preload.ts')
Bun.plugin({name:'remaining-native-owner-proof-capture',setup(build){
 build.onLoad({filter:/\/src\/__tests__\/paint-certification\.test\.ts$/},args=>{
  let source=readFileSync(args.path,'utf8')
  const er="const rows = JSON.parse(new TextDecoder().decode(result.stdout))"
  const sparse="for (const proof of [certifyScenePaint(producer(marks, context)), certifyNativePaint(drawing.header, drawing.paint)]) expect(proof).toMatchObject({ status: 'passed', issues: [] })"
  if(source.split(er).length!==2||source.split(sparse).length!==3)throw new Error('remaining-owner capture boundaries changed')
  source="import { writeFileSync as saveRemainingOwnerProof } from 'node:fs'\n"+source
  source=source.replace("rows.push({count,phase,sameSvg:", "rows.push({count,phase,svg:rendered.svg,sameSvg:")
  source=source.replace("rows.push({count,phase:'scene',sameSvg:", "rows.push({count,phase:'scene',svg:scene.svg,sameSvg:")
  source=source.replace(er,er+"\n  saveRemainingOwnerProof('/tmp/pr449-week-comparison-20261101/native-group-actual-b063/remaining-owners-a50/"+arm+"-er.json', JSON.stringify(rows, null, 2))")
  const sparseStart=source.indexOf(sparse, source.indexOf("test.each([0, 32])('sparse decorative markers"))
  source=source.substring(0,sparseStart)+"const remainingSparseProofs = [certifyScenePaint(producer(marks, context)), certifyNativePaint(drawing.header, drawing.paint)]\n  saveRemainingOwnerProof('/tmp/pr449-week-comparison-20261101/native-group-actual-b063/remaining-owners-a50/"+arm+"-sparse' + markerCount + '.json', JSON.stringify({svg:drawing.svg, proofs:remainingSparseProofs}, null, 2))\n  for (const proof of remainingSparseProofs) expect(proof).toMatchObject({ status: 'passed', issues: [] })"+source.substring(sparseStart+sparse.length)
  if(arm==='before')source=source.replaceAll('Bun.spawnSync([process.execPath, probe]',"Bun.spawnSync([process.execPath, '--preload', '/tmp/pr449-native-group-font-truth-before-preload.ts', probe]")
  return {contents:source,loader:'ts'}
 })
}})
