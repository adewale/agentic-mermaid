import { readFileSync } from 'node:fs'
const arm = process.env.AM_ER_SCENE_OWNER_ARM
if (arm !== 'before' && arm !== 'current') throw new Error('explicit ER Scene owner arm required')
const directory = '/tmp/pr449-week-comparison-20261101/er-scene-preference-3e43'
const modules = new Map([
  ['/src/scene/drawing.ts', 'drawing.before.ts'],
  ['/src/scene/positioned.ts', 'positioned.before.ts'],
  ['/src/positioning.ts', 'positioning.before.ts'],
])
Bun.plugin({ name: 'er-scene-preference-owning-replay', setup(build) {
  if (arm === 'before') build.onLoad({ filter: /\/src\/(?:scene\/(?:drawing|positioned)|positioning)\.ts$/ }, args => {
    const suffix = [...modules.keys()].find(key => args.path.endsWith(key))
    if (!suffix) throw new Error('unknown ER preference overlay module')
    return { contents: readFileSync(directory + '/' + modules.get(suffix), 'utf8'), loader: 'ts' }
  })
  build.onLoad({ filter: /\/src\/__tests__\/paint-certification\.test\.ts$/ }, args => {
    let source = readFileSync(args.path, 'utf8')
    const boundary = 'const { rows, controls } = JSON.parse(new TextDecoder().decode(result.stdout))'
    if (source.split(boundary).length !== 2) throw new Error('ER owning packet capture boundary changed')
    source = "import { writeFileSync as saveErOwnerPacket } from 'node:fs'\n" + source
    source = source.replace(boundary, boundary + `\n  saveErOwnerPacket('${directory}/owner-${arm}-packet.json', JSON.stringify({ rows, controls }, null, 2))`)
    if (arm === 'before') source = source.replaceAll('Bun.spawnSync([process.execPath, probe]', "Bun.spawnSync([process.execPath, '--preload', '/tmp/pr449-er-scene-preference-owner-preload.ts', probe]")
    return { contents: source, loader: 'ts' }
  })
} })
