import { readFileSync } from 'node:fs'
Bun.plugin({name:'before-writer-binding-owner-child',setup(build){
  build.onLoad({filter:/\/src\/__tests__\/paint-certification\.test\.ts$/},args=>{
    const source=readFileSync(args.path,'utf8')
    const target="['--eval', String.raw`"
    if(!source.includes(target))throw new Error('owner child arguments unavailable')
    return {contents:source.replaceAll(target,"['--preload', '/tmp/pr449-week-comparison-20261101/native-group-actual-b063/writer-binding-before-preload.ts', '--eval', String.raw`"),loader:'ts'}
  })
}})
