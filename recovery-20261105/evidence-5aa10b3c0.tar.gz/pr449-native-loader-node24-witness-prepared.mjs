import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { registerHooks, stripTypeScriptTypes } from 'node:module';
import { gzipSync } from 'node:zlib';
const root='/tmp/pr449-main-integration-20261029-762';
const frozen=process.env.PR449_FINAL_SHA;
if(process.argv[2]==='--prepare'){console.log('STATIC_ONLY_READY HOLD: one fresh Node24 source witness per selected family/engine; zero render/build calls');process.exit(0);}
if(process.argv[2]!=='--run'||process.env.PR449_ROOT_GO!=='native-loader-node-source'||!frozen?.match(/^[a-f0-9]{40}$/))throw new Error('Separate root GO and exact frozen SHA required');
if(process.env.PR449_CONTROLLER_VERIFIED_HEAD!==frozen)throw new Error('Python controller frozen-head/source-clean preflight required');
if(!process.version.startsWith('v24.'))throw new Error('Resolved Node24 runtime required');
const selectedTag=process.argv[3];if(!['class-agentic','class-elk','flowchart-agentic','flowchart-elk','flowchart-omitted'].includes(selectedTag))throw new Error('One exact family/engine per fresh source process required');
const out='/tmp/pr449-week-comparison-20261101/native-loader-node24-'+frozen.slice(0,9)+'/'+selectedTag;
fs.mkdirSync(out,{recursive:true});
const row={runtime:process.version,actualPublicCalls:0,setupErrors:[],root,loader:'Node built-in registerHooks; stripTypeScriptTypes mode=transform; existing extensionless relative .ts resolution',status:'setup'};
const gz=(name,value)=>fs.writeFileSync(out+'/'+name,gzipSync(typeof value==='string'?value:JSON.stringify(value)));
try {
 registerHooks({
  resolve(specifier,context,nextResolve){
   if(specifier.startsWith('.')&&context.parentURL?.startsWith(pathToFileURL(root+'/').href)){
    const candidate=new URL(specifier,context.parentURL);
    if(!path.extname(candidate.pathname)&&fs.existsSync(fileURLToPath(candidate)+'.ts'))return nextResolve(candidate.href+'.ts',context);
    if(!path.extname(candidate.pathname)&&fs.existsSync(fileURLToPath(candidate)+'.js'))return nextResolve(candidate.href+'.js',context);
   }
   if(specifier.startsWith('roughjs/bin/')&&!path.extname(specifier))return nextResolve(specifier+'.js',context);
   return nextResolve(specifier,context);
  },
  load(url,context,nextLoad){
   if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.json'))return {format:'json',shortCircuit:true,source:fs.readFileSync(fileURLToPath(url),'utf8')};
   if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.ts'))return {format:'module',shortCircuit:true,source:stripTypeScriptTypes(fs.readFileSync(fileURLToPath(url),'utf8'),{mode:'transform',sourceUrl:url})};
   return nextLoad(url,context);
  }
 });
 const bindings=JSON.parse(fs.readFileSync(process.env.PR449_BINDINGS_JSON,'utf8'));
 if(bindings.length!==5||new Set(bindings.map(x=>x.family+'-'+x.backend)).size!==5)throw new Error('Exactly five fixed Class/Flowchart both-engine plus omitted-forest inputs required');
 const classReference=JSON.parse(fs.readFileSync('/tmp/pr449-week-comparison-20261101/final-2d77-native-font/bindings.json','utf8')).filter(x=>x.family==='class');
 const flowReference=JSON.parse(fs.readFileSync('/tmp/pr449-week-comparison-20261101/native-group-cache0-cost-25b6c43b0/bindings-cyclic19-bun.json','utf8'));
 const references=[...classReference,...flowReference,{"family": "flowchart", "backend": "omitted", "source": "flowchart TD\nA[Wide root] --> B\nA --> C\nD[Disconnected]", "options": {"embedFontImport": false}}];
 const api=await import(pathToFileURL(root+'/src/index.ts').href);
 row.bindings=[];row.renders=[];
 for(const binding of bindings.filter(x=>x.family+'-'+x.backend===selectedTag)){
  const reference=references.find(x=>x.family===binding.family&&x.backend===binding.backend);
  if(!reference||binding.source!==reference.source||JSON.stringify(binding.options)!==JSON.stringify(reference.options))throw new Error('Exact retained family/engine source/options required');
  row.status='calling';process.stdout.write('ACTUAL_PUBLIC_CALL_START\n');row.actualPublicCalls++;
  const resultRow={family:binding.family,backend:binding.backend};
  try {
   const result=api.renderMermaidSVGWithReceipt(binding.source,binding.options);
   const bytes=Buffer.from(JSON.stringify(result),'utf8');let checksum=0;for(const n of bytes)checksum=(Math.imul(checksum,31)+n)>>>0;
   const svgName=selectedTag+'.svg.gz',receiptName=selectedTag+'.receipt.json.gz';
   gz(svgName,result.svg);gz(receiptName,JSON.stringify(result.receipt));
   Object.assign(resultRow,{status:'returned',bytes:bytes.length,checksum,proof:result.receipt.layoutCertification,layoutDecisions:result.receipt.layoutDecisions,executionDecision:result.receipt.executionDecision});
   row.bindings.push({...binding,svgReference:out+'/'+svgName,receiptReference:out+'/'+receiptName,sourceRuntime:process.version,sourceHead:frozen});
  }catch(error){resultRow.status='refused';resultRow.failure={name:error.name,message:error.message,stack:error.stack,cause:{name:error.cause?.name,message:error.cause?.message,stack:error.cause?.stack}};const bytes=Buffer.from(JSON.stringify(resultRow.failure));let checksum=0;for(const n of bytes)checksum=(Math.imul(checksum,31)+n)>>>0;resultRow.consumedFailure={bytes:bytes.length,checksum};}
  row.renders.push(resultRow);
 }
 // Python controller rechecks frozen HEAD and source cleanliness after this child.
 row.status=row.renders.every(x=>x.status==='returned')?'returned':'contains-refusal';
 row.completed=row.actualPublicCalls===1&&row.bindings.length===1;
 fs.writeFileSync(out+'/bindings-native-loader-node24.json',JSON.stringify(row.bindings));
}catch(error){row.status='setup-error';row.setupErrors.push({name:error.name,message:error.message,stack:error.stack});}
finally{gz('OUTCOME.json.gz',row);process.stdout.write(JSON.stringify({status:row.status,actualPublicCalls:row.actualPublicCalls,setupErrors:row.setupErrors,completed:row.completed,proofs:row.renders?.map(x=>({backend:x.backend,proof:x.proof?.status,operations:x.proof?.checks?.operations}))})+'\n');}
