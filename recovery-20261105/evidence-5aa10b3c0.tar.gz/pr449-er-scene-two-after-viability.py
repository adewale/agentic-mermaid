# Existing ER full-product worker, AFTER-only single cold phase; no before replay/profile/build.
import pathlib,json,gzip,os,subprocess,shutil,tempfile,xml.etree.ElementTree as ET
R=pathlib.Path('/tmp/pr449-main-integration-20261029-762');W=pathlib.Path('/tmp/pr449-week-comparison-20261101');O=W/'er-scene-viability-3e43-final';H='3e43badc5ebd110df717273cf952cd4e3dd36142';paths=['src/positioning.ts','src/scene/drawing.ts','src/scene/positioned.ts'];assert not (O/'RESULTS.json.gz').exists(),'Existing results; do not duplicate calls';O.mkdir(exist_ok=True)
E=dict(os.environ,PATH='/tmp/pr449-bin:'+os.environ['PATH'],GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0',NODE_DISABLE_COMPILE_CACHE='1')
def git(*a):return subprocess.check_output(['git',*a],cwd=R,env=E,text=True).strip()
assert git('rev-parse','HEAD')==H
prod=[p for p in git('diff','--name-only','HEAD','--','src').splitlines()if not p.startswith('src/__tests__/')and '/__tests__/'not in p];assert set(prod)==set(paths),prod
frozen={p:(R/p).read_bytes()for p in paths}
for path,data in frozen.items():(O/path.replace('/','__')).write_bytes(data)
def check():
 assert git('rev-parse','HEAD')==H
 assert all((R/p).read_bytes()==b for p,b in frozen.items()),'Frozen candidate changed'
before=json.loads(gzip.decompress((W/'er-glyph-profile-3e43badc5/RESULTS.json.gz').read_bytes()));assert before['head']==H
worker=(W/'er-glyph-profile-3e43badc5/worker.ts').read_text();assert "[['cold', source], ['repeat', source]]"in worker;worker=worker.replace("[['cold', source], ['repeat', source]]","[['cold', source]]");(O/'worker.ts').write_text(worker)
j={'baseHead':H,'frozenProductionPaths':paths,'actualPublicCalls':0,'beforePublicCalls':0,'runs':[],'errors':[],'scope':'Exactly2 after-only ER208LR publicSVGcalls max, one per engine; exact old3e43 profile sources/options, cacheoff. Fully consumed FINAL SVG/ENTIRE public receipt after actual default-backend finish, or full error. No public before replay/profile/build. Candidate3files frozen by exact bytes; stage/provider and all P/U/errors/differences retained. Stop on new refusal or geometry mismatch.'}
def gz(p,v):p.write_bytes(gzip.compress(v if isinstance(v,bytes)else json.dumps(v,separators=(',',':')).encode(),mtime=0))
def save():gz(O/'RESULTS.json.gz',j)
def different(a,b,p=''):
 if type(a)!=type(b):return[p]
 if isinstance(a,dict):return sum((different(a[k],b[k],p+'.'+k)if k in a and k in b else[p+'.'+k]for k in a.keys()|b.keys()),[])
 if isinstance(a,list):return[p]if len(a)!=len(b)else sum((different(x,y,p+f'[{i}]')for i,(x,y)in enumerate(zip(a,b))),[])
 return[]if a==b else[p]
def geometry(svg):
 keys={'viewBox','width','height','x','y','x1','y1','x2','y2','cx','cy','r','rx','ry','d','points','transform','dx','dy','textLength','lengthAdjust','font-size','text-anchor','marker-start','marker-mid','marker-end','stroke-width'}
 return[{'tag':e.tag.rsplit('}',1)[-1],'attributes':{k:v for k,v in e.attrib.items()if k in keys},'text':e.text if e.tag.rsplit('}',1)[-1]in ['text','tspan']else None}for e in ET.fromstring(svg).iter()if any(k in keys for k in e.attrib)]
S=None
try:
 S=pathlib.Path(tempfile.mkdtemp(prefix='pr449-er-scene-viability-',dir='/dev/shm'));E.update(TMPDIR=str(S),XDG_CACHE_HOME=str(S/'cache'),BUN_RUNTIME_TRANSPILER_CACHE_PATH=str(S/'bun-cache'))
 for backend in ['agentic','elk']:
  check();old=next(r for r in before['runs']if r['count']==208 and r['backend']==backend);oldcold=old['rows'][0];assert oldcold['status']=='returned';src=old['source'];options=old['options'];assert options=={'graphLayout':{'backend':backend,'fallback':'none'}}
  (S/'source.mmd').write_text(src);(S/'options.json').write_text(json.dumps(options));out=S/backend;job={'root':str(R),'count':208,'backend':backend,'arm':'after-frozen-scene','sourceFile':str(S/'source.mmd'),'editFile':str(S/'source.mmd'),'optionsFile':str(S/'options.json'),'out':str(out)};(S/'job.json').write_text(json.dumps(job))
  p=subprocess.run(['/tmp/pr449-bin/bun',str(O/'worker.ts'),str(S/'job.json')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);actual=p.stdout.decode().count('ACTUAL_PUBLIC_CALL_START');j['actualPublicCalls']+=actual;gz(O/(backend+'-stdout-stderr.log.gz'),p.stdout+p.stderr);check()
  if p.returncode:j['errors'].append({'backend':backend,'exitCode':p.returncode,'actualCallsObserved':actual,'stderr':p.stderr.decode()});save();break
  row=json.loads(gzip.decompress(pathlib.Path(str(out)+'.json.gz').read_bytes()));assert row['actualPublicCalls']==actual==1;current=row['rows'][0];row['beforeReference']=str(W/'er-glyph-profile-3e43badc5/RESULTS.json.gz');row['beforeCold']=oldcold
  if current['status']=='returned':
   svg=gzip.decompress(pathlib.Path(str(out)+'-cold.svg.gz').read_bytes());svgName=backend+'.svg.gz';receiptName=backend+'.receipt.json.gz';gz(O/svgName,svg);gz(O/receiptName,current['receiptJSON'].encode());current['svgReference']=str(O/svgName);current['receiptReference']=str(O/receiptName)
   oldsvg=gzip.decompress(pathlib.Path(oldcold['svgReference']).read_bytes());oldreceipt=json.loads(oldcold['receiptJSON']);newreceipt=json.loads(current['receiptJSON']);g0=geometry(oldsvg);g1=geometry(svg)
   row['comparison']={'wholeSVGExact':oldsvg==svg,'geometryAttributesExact':g0==g1,'geometryDifferencePaths':different(g0,g1),'entireRawReceiptExact':oldcold['receiptJSON']==current['receiptJSON'],'receiptDifferencePaths':different(oldreceipt,newreceipt),'beforeProof':oldreceipt.get('layoutCertification'),'afterProof':newreceipt.get('layoutCertification'),'beforeExecutionDecision':oldreceipt.get('executionDecision'),'afterExecutionDecision':newreceipt.get('executionDecision'),'beforeLayoutDecisions':oldreceipt.get('layoutDecisions'),'afterLayoutDecisions':newreceipt.get('layoutDecisions'),'beforeProviderEvents':oldcold['paintProviderEvents'],'afterProviderEvents':current['paintProviderEvents']}
  j['runs'].append(row);save();print('AFTER',backend,current['status'],'proof',current.get('proof',{}).get('status'),'geometryExact',row.get('comparison',{}).get('geometryAttributesExact'),'wholeSVGExact',row.get('comparison',{}).get('wholeSVGExact'),'elapsedMs',round(current['elapsedMs'],2),'provider',current['paintProviderEvents'],flush=True)
  if current['status']!='returned' or not row['comparison']['geometryAttributesExact']:j['stopReason']='new-refusal-or-geometry-difference';save();break
 j['completed']=j['actualPublicCalls']==2 and len(j['runs'])==2 and not j['errors']and not j.get('stopReason');j['frozenSourceUnchanged']=all((R/p).read_bytes()==b for p,b in frozen.items())
except Exception as e:j['error']=repr(e);j['completed']=False
finally:
 if S:shutil.rmtree(S)
 j['ramRemoved']=S is None or not S.exists();save();print('FINAL',json.dumps({k:j.get(k)for k in ['completed','actualPublicCalls','beforePublicCalls','errors','error','stopReason','frozenSourceUnchanged','ramRemoved']}),flush=True)
