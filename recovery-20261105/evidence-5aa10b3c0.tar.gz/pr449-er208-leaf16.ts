import {writeFileSync,mkdirSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/er-leaf16-adb463'
mkdirSync(out,{recursive:true})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const source='erDiagram\ndirection LR\n'+Array.from({length:207},(_,i)=>`N${i} ||--o{ N${i+1} : owns`).join('\n')
const options={graphLayout:{backend:'elk',fallback:'none'}}
let outcome:any
try{const result=renderMermaidSVGWithReceipt(source,options);outcome={status:'returned',result}}catch(e:any){outcome={status:'refused',error:{name:e.name,message:e.message,stack:e.stack,cause:e.cause&&{name:e.cause.name,message:e.cause.message,stack:e.cause.stack}}}}
const serialized=JSON.stringify({source,options,actualPublicCalls:1,outcome});let consumed=0;for(let i=0;i<serialized.length;i++)consumed+=serialized.charCodeAt(i)
writeFileSync(out+'/CURRENT208.json.gz',gzipSync(serialized))
console.log(JSON.stringify({status:outcome.status,proof:outcome.result?.receipt.layoutCertification,error:outcome.error,consumed}))
