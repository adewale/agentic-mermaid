import pathlib,os,subprocess,tempfile,shutil,json,gzip
R=pathlib.Path('/tmp/pr449-main-integration-20261029-762');O=pathlib.Path('/tmp/pr449-week-comparison-20261101/recovery-payload/baseline');O.mkdir(exist_ok=True)
E=dict(os.environ,PATH='/tmp/pr449-bin:'+os.environ['PATH'],GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',NODE_DISABLE_COMPILE_CACHE='1',AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0')
S=None;j={'buildCalls':0,'actualRenderCalls':0,'errors':[]}
def gz(name,x):
 b=x if isinstance(x,bytes)else json.dumps(x,separators=(',',':')).encode();(O/name).write_bytes(gzip.compress(b,compresslevel=9,mtime=0))
def git(*a):return subprocess.check_output(['git',*a],cwd=R,env=E,text=True).strip()
try:
 j['head']=git('rev-parse','HEAD');assert j['head']=='3b56da55e6570908beb5d96c25f4c03c1a828a22';assert not [p for p in git('diff','--name-only','HEAD','--','src','tsup.browser-lazy.config.ts','scripts/build').splitlines()if not p.startswith('src/__tests__/')]
 S=pathlib.Path(tempfile.mkdtemp(prefix='pr449-recovery-payload-',dir='/dev/shm'));E.update(TMPDIR=str(S),XDG_CACHE_HOME=str(S/'cache'),BUN_RUNTIME_TRANSPILER_CACHE_PATH=str(S/'bun-cache'));art=S/'artifact';art.mkdir()
 builder="import{build}from'ROOT/node_modules/tsup/dist/index.js';import canonical from'ROOT/tsup.browser-lazy.config.ts';await build({...canonical,config:false,dts:false,outDir:process.argv[2]});".replace('ROOT',str(R));(S/'build.mjs').write_text(builder);j['recipe']={'canonicalConfig':'tsup.browser-lazy.config.ts','overrides':{'config':False,'dts':False,'outDir':'private RAM artifact/dist'},'driver':builder}
 j['buildCalls']+=1;p=subprocess.run(['bun',str(S/'build.mjs'),str(art/'dist')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300);gz('build.log.gz',p.stdout+p.stderr);j['buildExit']=p.returncode;assert p.returncode==0,p.stderr.decode()[-1500:]
 j['sourceCleanAtBuildComplete']=not [p for p in git('diff','--name-only','HEAD','--','src','tsup.browser-lazy.config.ts','scripts/build').splitlines()if not p.startswith('src/__tests__/')];assert j['sourceCleanAtBuildComplete'];print('BASELINE_SNAPSHOT_CAPTURED_BUILD_OK',flush=True)
 mp=art/'dist/metafile-esm.json';raw=mp.read_bytes();gz('metafile-original.json.gz',raw);m=json.loads(raw)
 def fix(s):return os.path.relpath(os.path.normpath(os.path.join(str(R),s)),str(art))
 m['outputs']={fix(k):dict(v,imports=[dict(i,path=fix(i['path']))for i in v.get('imports',[])])for k,v in m['outputs'].items()};mp.write_text(json.dumps(m));gz('metafile-normalized.json.gz',m)
 p=subprocess.run(['bun',str(R/'scripts/build/browser-lazy-report.ts'),'--root',str(art),'--measure-only','--json'],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120);gz('report.stderr.gz',p.stderr);assert p.returncode==0,p.stderr.decode()[-1000:];report=json.loads(p.stdout);gz('report.json.gz',report);j['initial']=report['initial'];j['class']=report['families']['class'];j['flowchart']=report['families']['flowchart'];print('CLASS',j['class'],'INITIAL',j['initial'],flush=True)
 src=(R/'eval/layout-compare/fixtures/class-backends.mmd').read_text();j['source']=src;j['optionsBase']={'embedFontImport':False,'idPrefix':'recovery-'}
 consumer="""import fs from'node:fs';import{pathToFileURL}from'node:url';const j=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));const api=await import(pathToFileURL(j.api));let row={actualRenderCalls:0};try{process.stdout.write('ACTUAL_RENDER_CALL_START\\n');row.actualRenderCalls++;const v=await api.renderMermaidSVGWithReceiptAsync(j.source,j.options),raw=Buffer.from(JSON.stringify(v),'utf8');let checksum=0;for(const n of raw)checksum=(Math.imul(checksum,31)+n)>>>0;row={...row,outcome:'returned',svg:v.svg,receiptJSON:JSON.stringify(v.receipt),bytes:raw.length,checksum,proof:v.receipt.layoutCertification};}catch(e){row={...row,outcome:'error',error:{name:e.name,message:e.message,stack:e.stack,cause:{name:e.cause?.name,message:e.cause?.message,stack:e.cause?.stack}}}}fs.writeFileSync(j.out,JSON.stringify(row));""";(S/'consume.mjs').write_text(consumer);j['renders']={}
 for backend in ['agentic','elk']:
  options=dict(j['optionsBase'],graphLayout={'backend':backend,'fallback':'none'});job={'source':src,'options':options,'api':str(art/'dist/browser-lazy/index.js'),'out':str(S/'render.json')};(S/'job.json').write_text(json.dumps(job));p=subprocess.run(['node',str(S/'consume.mjs'),str(S/'job.json')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90);gz(backend+'-stdout-stderr.log.gz',p.stdout+p.stderr);j['actualRenderCalls']+=p.stdout.decode().count('ACTUAL_RENDER_CALL_START');assert p.returncode==0,p.stderr.decode()[-1000:];v=json.loads((S/'render.json').read_text());assert v['actualRenderCalls']==1
  if v['outcome']=='returned':gz(backend+'.svg.gz',v.pop('svg').encode());gz(backend+'.receipt.json.gz',v.pop('receiptJSON').encode())
  j['renders'][backend]=v;print('RENDER',backend,v['outcome'],v.get('proof',{}).get('status'),flush=True)
 j['completed']=j['actualRenderCalls']==2 and all(v['outcome']=='returned'for v in j['renders'].values())
except Exception as e:j['completed']=False;j['error']=repr(e)
finally:
 if S:shutil.rmtree(S)
 j['ramRemoved']=S is None or not S.exists();gz('OUTCOME.json.gz',j);print('FINAL',json.dumps({k:j.get(k)for k in ['completed','buildCalls','actualRenderCalls','buildExit','error','ramRemoved']}),flush=True)
