import collections,gzip,json,pathlib
W=pathlib.Path('/tmp/pr449-week-comparison-20261101')
H='539407810'
def read(p):return gzip.decompress(pathlib.Path(p).read_bytes())
out={'head':'5394078101a415a3657214c9185e2e662dd3f07c','baseline':'52a13881d0beafe2e7ebb4cfcfae349ab20ca1e2','calls':0,'proofStatuses':{},'beforeCurrentSVG':[],'ownCacheComparisons':[],'runs':[],'scope':'Read-only retained evidence summarization; zero layout/render/build calls. N1 per cell, no causal ratios or speed/memory claims.'}
proof=collections.Counter()
for cache in [0,1]:
 O=W/f'class-scene-cache{cache}-cost-{H}';j=json.loads(read(O/'RESULTS.json.gz'))
 assert j['completed'] and not j['errors']
 out['calls']+=j['actualPublicCalls']
 summary={'cache':cache,'calls':j['actualPublicCalls'],'consumedBytes':sum(q['bytes'] for r in j['runs'] for q in r['rows']),'runs':[],'beforeCurrentSVG':[],'ownCacheComparisons':[]}
 for r in j['runs']:
  item={k:r[k] for k in ['count','backend','arm','peakRssKiB','importMs','overlayLoads']}
  item['loaded']=r['loaded'];item['phases']=[]
  for q in r['rows']:
   assert q['status']=='returned';proof[q['proof']['status']]+=1
   assert read(q['receiptReference']).decode()==q['receiptJSON']
   item['phases'].append({'phase':q['phase'],'elapsedMs':q['elapsedMs'],'bytes':q['bytes'],'proof':q['proof'],'postGC':q['afterGC'],'stages':q['stages'],'providerEvents':[e for e in q['events'] if e.get('owner') in ['positioned-layout','positioned-scene','native-drawing','paint-certification']]})
  summary['runs'].append(item);out['runs'].append(dict(cache=cache,**item))
  if r['arm']=='after':
   before=next(x for x in j['runs'] if x['count']==r['count'] and x['backend']==r['backend'] and x['arm']=='before')
   for a,b in zip(before['rows'],r['rows']):
    x={'cache':cache,'case':r['count'],'backend':r['backend'],'phase':a['phase'],'wholeSVGExact':read(a['svgReference'])==read(b['svgReference'])}
    assert x['wholeSVGExact'];summary['beforeCurrentSVG'].append(x);out['beforeCurrentSVG'].append(x)
  if cache:
   a,b,c=r['rows'];x={'case':r['count'],'backend':r['backend'],'arm':r['arm'],'repeatWholeSVGExact':read(a['svgReference'])==read(b['svgReference']),'repeatEntireRawReceiptExact':a['receiptJSON']==b['receiptJSON'],'repeatPositionedLayoutHit':any(e.get('owner')=='positioned-layout' and e.get('outcome')=='hit' for e in b['events']),'editPositionedLayoutMiss':any(e.get('owner')=='positioned-layout' and e.get('outcome')=='miss' for e in c['events']),'editSVGDiffers':read(a['svgReference'])!=read(c['svgReference'])}
   assert all(v for k,v in x.items() if k not in ['case','backend','arm']);summary['ownCacheComparisons'].append(x);out['ownCacheComparisons'].append(x)
 (O/'SUMMARY.json.gz').write_bytes(gzip.compress(json.dumps(summary,separators=(',',':')).encode(),mtime=0))
 print('CACHE',cache,'calls',summary['calls'],'consumedBytes',summary['consumedBytes'])
 for case in dict.fromkeys(r['count'] for r in j['runs']):
  for backend in ['agentic','elk']:
   rs=[next(r for r in j['runs'] if r['count']==case and r['backend']==backend and r['arm']==arm) for arm in ['before','after']]
   fmt=lambda f:' -> '.join('/'.join(f(q) for q in r['rows']) for r in rs)
   print(case,backend,'elapsed',fmt(lambda q:f"{q['elapsedMs']:.2f}"),'rss',' -> '.join(str(r['peakRssKiB'])for r in rs),'heapMiB',fmt(lambda q:f"{q['afterGC']['heapUsed']/2**20:.2f}"),'import',' -> '.join(f"{r['importMs']:.2f}"for r in rs))
out['proofStatuses']=dict(proof);out['consumedBytes']=sum(q['bytes'] for r in out['runs'] for q in r['phases'])
(W/f'class-scene-cache0-cost-{H}'/'FINAL-EVIDENCE.json.gz').write_bytes(gzip.compress(json.dumps(out,separators=(',',':')).encode(),mtime=0))
print('TOTAL',out['calls'],out['consumedBytes'],out['proofStatuses'],'pairedSVG',len(out['beforeCurrentSVG']),'cacheChecks',len(out['ownCacheComparisons']))
