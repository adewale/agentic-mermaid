import { readFileSync } from 'node:fs'
const arm=process.env.AM_REQUIREMENT_CAPTION_OWNER_ARM
const base='/tmp/pr449-week-comparison-20261101/requirement-caption-843/'
if(arm!=='before'&&arm!=='current')throw new Error('explicit Requirement caption owner arm required')
Bun.plugin({name:'requirement-caption-owning-artifacts',setup(build){
 if(arm==='before')build.onLoad({filter:/\/src\/layout\/shorten-measured-routes\.ts$/},()=>({contents:readFileSync(base+'shorten-before.ts','utf8'),loader:'ts'}))
 build.onLoad({filter:/\/src\/__tests__\/requirement-layout-backends\.test\.ts$/},args=>{
  const source=readFileSync(args.path,'utf8')
  const target='    const rendered = renderMermaidSVGWithReceipt(source(direction), options)'
  if(source.split(target).length!==2)throw new Error('ordinary Requirement owner capture boundary changed')
  const capture="\n    saveRequirementCaptionOwnerPacket('"+base+arm+"-' + direction + '-' + backend + '.json', JSON.stringify({ source: source(direction), options, direction, backend, placed, rendered }, null, 2))"
  return {contents:"import { writeFileSync as saveRequirementCaptionOwnerPacket } from 'node:fs'\n"+source.replace(target,target+capture),loader:'ts'}
 })
}})
