# Parameter reuse of the existing paired recovery-cost controller; no geometry cache.
import ast,gzip,json,os,pathlib,shutil,subprocess,sys,tempfile
R=pathlib.Path('/tmp/pr449-main-integration-20261029-762')
W=pathlib.Path('/tmp/pr449-week-comparison-20261101')
B='f1e23e62fc30269827cef9765e70b67bd2d83296'
PATHS=['src/scene/marks.ts','src/scene/fidelity.ts']
DIRTY=PATHS+['src/__tests__/scene-text-fidelity.test.ts']
FROZEN_FILES=None
ORIGINAL=W/'prepared-roster-f1e/marks.original.ts'
WORKER=pathlib.Path('/tmp/pr449-prepared-roster-cost-worker.ts')
if sys.argv[1:]==['--prepare']:
 assert ORIGINAL.is_file() and WORKER.is_file()
 print('STATIC_READY HOLD: four workers, exactly12 drawNative+certifyNativePaint pairs max; count0/32 beforef1e/current cold/repeat/edit freshdraws, fullSVG+ENTIREcertification; no geometrycache, Scene/backend/publicMMD/build calls.');sys.exit()
assert len(sys.argv)==3 and sys.argv[1]=='--run' and sys.argv[2]==B,'Frozen f1e base plus uncommitted candidate and root GO required'
assert os.environ.get('PR449_ROOT_GO')=='prepared-roster-cost','Separate root CPU GO required'
H=sys.argv[2]
E=dict(os.environ,PATH='/tmp/pr449-bin:'+os.environ['PATH'],GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',NODE_DISABLE_COMPILE_CACHE='1',AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env=E,text=True).strip()
def production(paths):return [p for p in paths.splitlines()if p and not p.startswith('src/__tests__/')and '/__tests__/'not in p]
def frozen():
 assert git('rev-parse','HEAD')==H,'Frozen HEAD changed'
 assert set(git('diff','--name-only','HEAD','--','src','tsup.browser-lazy.config.ts','scripts/build').splitlines())==set(DIRTY),'Exact three-file dirty candidate required'
 if FROZEN_FILES is not None:assert all((R/p).read_bytes()==data for p,data in FROZEN_FILES.items()),'Frozen candidate literal bytes changed'
frozen()
O=W/('prepared-roster-cost-'+H[:9]+'-dirty');O.mkdir(exist_ok=True)
assert not (O/'RESULTS.json.gz').exists(),'Existing attempt retained: do not replay'
S=None;j={'head':H,'candidateKind':'frozen uncommitted three-file patch on f1e; no committed-candidate gate','beforeRuntimeRevision':B,'overlayPaths':PATHS,'dirtyCandidatePaths':DIRTY,'actualDrawCalls':0,'actualCertificationCalls':0,'runs':[],'errors':[],'comparisons':[],'scope':'Exact owning sparse decorative marker producer count0/32, 1500 labels, before/current cold/repeat/edit fresh draws. Each phase exactlyone drawNative plusone certifyNativePaint, fullyconsume SVG+ENTIREcertification. No geometrycache or publicMermaid/Scene calls. Moduleimport and fixture setup separatelytimed, phase elapsed includes draw/cert/fullJSON checksum but excludes forcedpostGC and artifactcompression; three products held, imports/overlays/observers in RSS/heap. AllP/U/failed/refusals/adverse retained, noPgate/causalratios/speed or memoryclaims. Finaltext only x-to-y with matchingpreparedblock; positions/IDs/counts fixed.'}
def gz(name,value):
 data=value if isinstance(value,bytes)else json.dumps(value,separators=(',',':')).encode();(O/name).write_bytes(gzip.compress(data,mtime=0))
def save():gz('RESULTS.json.gz',j)
try:
 before={p:subprocess.check_output(['git','show',B+':'+p],cwd=R,env=E)for p in PATHS};assert before[PATHS[0]]==ORIGINAL.read_bytes(),'Exact owner baseline required'
 after={p:(R/p).read_bytes()for p in PATHS};assert all(before[p]!=after[p]for p in PATHS)
 FROZEN_FILES={p:(R/p).read_bytes()for p in DIRTY};frozen()
 for arm,files in [('before',before),('after',after)]:
  for path,data in files.items():gz(arm+'-'+path.replace('/','__')+'.gz',data)
 gz('candidate.patch.gz',subprocess.check_output(['git','diff','--binary',B,'--',*DIRTY],cwd=R,env=E));j['candidatePatchReference']=str(O/'candidate.patch.gz')
 S=pathlib.Path(tempfile.mkdtemp(prefix='pr449-prepared-roster-cost-',dir='/dev/shm'));E.update(TMPDIR=str(S),XDG_CACHE_HOME=str(S/'cache'),BUN_RUNTIME_TRANSPILER_CACHE_PATH=str(S/'bun-cache'))
 overlays={}
 for arm,files in [('before',before),('after',after)]:
  overlays[arm]={}
  for path,data in files.items():
   file=S/(arm+'-'+path.replace('/','__'));file.write_bytes(data);overlays[arm][str(R/path)]=str(file)
 (S/'worker.ts').write_bytes(WORKER.read_bytes())
 syntax=subprocess.run(['/tmp/pr449-bin/bun','-e',"new Bun.Transpiler({loader:'ts'}).transformSync(require('node:fs').readFileSync(process.argv[1],'utf8'));console.log('SYNTAX_OK')",str(S/'worker.ts')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 assert syntax.returncode==0,syntax.stderr.decode();print(syntax.stdout.decode().strip(),flush=True)
 for i,(count,arm)in enumerate([(0,'before'),(0,'after'),(32,'after'),(32,'before')]):
  frozen();out=S/('w'+str(i));job={'root':str(R),'count':count,'arm':arm,'overlays':overlays[arm],'out':str(out)};(S/'job.json').write_text(json.dumps(job))
  p=subprocess.run(['/tmp/pr449-bin/bun',str(S/'worker.ts'),str(S/'job.json')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
  draws=p.stdout.count(b'ACTUAL_DRAW_CALL_START');certs=p.stdout.count(b'ACTUAL_CERTIFICATION_CALL_START');j['actualDrawCalls']+=draws;j['actualCertificationCalls']+=certs;gz('w'+str(i)+'-stdout-stderr.log.gz',p.stdout+p.stderr)
  if p.returncode:
   j['errors'].append({'worker':i,'count':count,'arm':arm,'exitCode':p.returncode,'drawCallsObserved':draws,'certificationCallsObserved':certs,'stderr':p.stderr.decode()});save();raise RuntimeError('Worker failed; stop without further calls')
  row=json.loads(gzip.decompress(pathlib.Path(str(out)+'.json.gz').read_bytes()));row['worker']=i;assert row['actualDrawCalls']==draws and row['actualCertificationCalls']==certs
  for q in row['rows']:
   if q['status']=='returned':
    name=f'sparse{count}-{arm}-{q["phase"]}';gz(name+'.svg.gz',gzip.decompress(pathlib.Path(str(out)+'-'+q['phase']+'.svg.gz').read_bytes()));gz(name+'.proof.json.gz',q['proofJSON'].encode());q['svgReference']=str(O/(name+'.svg.gz'));q['proofReference']=str(O/(name+'.proof.json.gz'))
  j['runs'].append(row);save();print('WORKER',i,count,arm,'draws',draws,'certifications',certs,'RSSKiB',row['peakRssKiB'],[(q['phase'],q['status'],round(q['elapsedMs'],3),q.get('proof',{}).get('status'))for q in row['rows']],flush=True)
  assert all(q['status']=='returned'for q in row['rows']),'Native draw/certification refusal; stop for root review'
  other=next((r for r in j['runs']if r['count']==count and r['arm']!=arm),None)
  if other:
   for a,b in zip(other['rows'],row['rows']):
    assert a['phase']==b['phase'];exact=gzip.decompress(pathlib.Path(a['svgReference']).read_bytes())==gzip.decompress(pathlib.Path(b['svgReference']).read_bytes());j['comparisons'].append({'count':count,'phase':a['phase'],'wholeSVGExact':exact,'entireCertificationExact':a['proofJSON']==b['proofJSON']});save();assert exact,'Before/current SVG changed; stop for root review'
  frozen()
 j['sourceUnchanged']=all((R/p).read_bytes()==data for p,data in FROZEN_FILES.items());j['completed']=j['actualDrawCalls']==12 and j['actualCertificationCalls']==12 and len(j['runs'])==4 and not j['errors']and j['sourceUnchanged']and all(str(R/PATHS[0])in r['overlayPathsSeen']and len(set(r['overlayPathsSeen']))==r['overlayLoads']for r in j['runs'])
except Exception as error:j['completed']=False;j['error']=repr(error)
finally:
 if S:shutil.rmtree(S)
 j['ramRemoved']=S is None or not S.exists();save();print('FINAL',json.dumps({k:j.get(k)for k in ['completed','actualDrawCalls','actualCertificationCalls','errors','error','sourceUnchanged','ramRemoved']}),flush=True)
