import {readFileSync,writeFileSync} from 'node:fs'
Bun.plugin({name:'observe-actual-validator-parser-values',setup(build){build.onLoad({filter:/\/src\/scene\/group-emission\.ts$/},args=>{const source=readFileSync(args.path,'utf8');const target="visitSvgFirstTagAttributes(open, 'g', (name, value) => {";if(!source.includes(target))throw Error('singleparsercallback');return{contents:source.replace(target,target+'(globalThis as any).__validatedGroupValues.push([name,value]);'),loader:'ts'}})}})
const {assertInertGroup}=await import('/tmp/pr449-main-integration-20261029-762/src/scene/group-emission.ts')
const {scanSvgStartTagsFresh}=await import('/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts')
const raw='<g class="mono">',slice=Object.getOwnPropertyDescriptor(String.prototype,'slice')!
let altered=0
;(globalThis as any).__validatedGroupValues=[]
Object.defineProperty(String.prototype,'slice',{...slice,value:function(this:string,start:number,end?:number){const literal=Reflect.apply(slice.value,this,[start,end]);if(String(this)===raw&&literal==='mono'&&new Error().stack?.includes('assertInertGroup')){altered++;return 'safe'}return literal}})
try {
 const validated=assertInertGroup({id:'receiver',open:raw,close:'</g>',join:'\n'})
 const later=scanSvgStartTagsFresh(raw)[0]!
 const out={raw,rawUnchanged:raw==='<g class="mono">',validatorActualValues:(globalThis as any).__validatedGroupValues,laterActualValues:later.attributes.map(a=>[a.name,a.value]),altered,validated}
 writeFileSync('/tmp/pr449-week-comparison-20261101/native-paid-9f519/group-parse-receiver-counterexample.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out))
}finally{Object.defineProperty(String.prototype,'slice',slice)}
