import pathlib,gzip,json,subprocess
W=pathlib.Path('/tmp/pr449-week-comparison-20261101');root=pathlib.Path('/tmp/pr449-main-integration-20261029-762');head='25b6c43b02926e286d016d21fc701ee1d3663479'
def gz(p,v):p.write_bytes(gzip.compress(json.dumps(v,separators=(',',':')).encode(),mtime=0))
def raw(p):return gzip.decompress(pathlib.Path(p).read_bytes())
def differences(a,b,p=''):
 if type(a)!=type(b):return[p]
 if isinstance(a,dict):return sum((differences(a[k],b[k],p+'.'+k)if k in a and k in b else[p+'.'+k]for k in a.keys()|b.keys()),[])
 if isinstance(a,list):return[p]if len(a)!=len(b)else sum((differences(x,y,p+f'[{i}]')for i,(x,y)in enumerate(zip(a,b))),[])
 return[]if a==b else[p]
combined={'head':head,'actualPublicCalls':0,'buildCalls':0,'nodeWitnessCalls':0,'batches':[],'limits':['N=1 per cell; no causal timing/allocation/speedup or ratio claim','U-to-P does unequal proof work','Peak RSS and post-GC include imports/overlays/harness/observers/three held products; post-GC is not retained allocation attribution']}
for cache in [0,1]:
 O=W/f'native-group-cache{cache}-cost-'+pathlib.Path(head[:9]) if False else W/('native-group-cache'+str(cache)+'-cost-'+head[:9])
 d=json.loads(raw(O/'RESULTS.json.gz'));assert d['completed']and d['candidateHead']==head
 rows=[]
 by={(r['count'],r['backend'],r['arm']):r for r in d['runs']}
 pairs=[];hits=[]
 for r in d['runs']:
  rows.append({'case':r['count'],'backend':r['backend'],'arm':r['arm'],'importMs':r['importMs'],'peakRssKiB':r['peakRssKiB'],'loaded':r['loaded'],'overlayLoads':r['overlayLoads'],'phases':[{'phase':x['phase'],'status':x['status'],'proof':x.get('proof'),'elapsedMs':x['elapsedMs'],'consumedBytes':x.get('bytes'),'consumedChecksum':x.get('checksum'),'afterGC':x['afterGC'],'paintProviderEvents':x['paintProviderEvents'],'cacheEvents':[e for e in x['events']if e.get('kind')=='cache'],'stages':x['stages']}for x in r['rows']]})
  if r['arm']=='after':
   old=by[(r['count'],r['backend'],'before')]
   for x,y in zip(old['rows'],r['rows']):
    assert x['phase']==y['phase']
    pair={'case':r['count'],'backend':r['backend'],'phase':y['phase'],'bothReturned':x['status']==y['status']=='returned'}
    if pair['bothReturned']:
     pair['wholeSVGExactBeforeCurrent']=raw(x['svgReference'])==raw(y['svgReference'])
     pair['receiptDifferencePaths']=differences(json.loads(x['receiptJSON']),json.loads(y['receiptJSON']))
    pairs.append(pair)
  if cache:
   cold,repeat,edit=r['rows'];pe=lambda p:[e['outcome']for e in p['events']if e.get('owner')=='positioned-layout']
   hits.append({'backend':r['backend'],'arm':r['arm'],'positionedLayout':{'cold':pe(cold),'repeat':pe(repeat),'edit':pe(edit)},'repeatActuallyHit':pe(repeat)==['hit'],'editActuallyMissed':pe(edit)==['miss'],'ownColdRepeatWholeSVGExact':raw(cold['svgReference'])==raw(repeat['svgReference']),'ownColdRepeatEntireRawReceiptExact':cold['receiptJSON']==repeat['receiptJSON'],'editSVGDiffersFromCold':raw(cold['svgReference'])!=raw(edit['svgReference'])})
 summary={'head':head,'beforeRuntimeRevision':d['beforeRuntimeRevision'],'cache':cache,'completed':d['completed'],'actualPublicCalls':d['actualPublicCalls'],'errors':d['errors'],'nativeGroupSourceUnchanged':d['nativeGroupSourceUnchanged'],'ramRemoved':d['ramRemoved'],'scope':d['scope'],'fullyConsumedBytes':sum(x.get('bytes',0)for r in d['runs']for x in r['rows']),'rows':rows,'beforeCurrentPairs':pairs,'cacheTransitions':hits}
 gz(O/'SUMMARY.json.gz',summary)
 combined['actualPublicCalls']+=d['actualPublicCalls'];combined['batches'].append({'cache':cache,'calls':d['actualPublicCalls'],'summaryReference':str(O/'SUMMARY.json.gz'),'allBeforeCurrentSVGExact':all(x.get('wholeSVGExactBeforeCurrent',False)for x in pairs),'beforeCurrentPairs':len(pairs),'cacheTransitions':hits})
 print('\nCACHE',cache,'calls',d['actualPublicCalls'],'bytes',summary['fullyConsumedBytes'],'before/currentSVG',sum(x.get('wholeSVGExactBeforeCurrent',False)for x in pairs),'/',len(pairs))
 print('case engine arm | import ms | cold/repeat/edit ms | peak KiB | post-GC heap MiB | post-GC RSS MiB | operations | proof')
 for r in d['runs']:
  xs=r['rows'];fmt=lambda ys:'/'.join(f'{y:.2f}'for y in ys)
  print(r['count'],r['backend'],r['arm'],'|',round(r['importMs'],2),'|',fmt([x['elapsedMs']for x in xs]),'|',r['peakRssKiB'],'|',fmt([x['afterGC']['heapUsed']/1048576 for x in xs]),'|',fmt([x['afterGC']['rss']/1048576 for x in xs]),'|','/'.join(str(x['proof']['checks']['operations'])for x in xs),'|','/'.join(x['proof']['status']for x in xs))
 print('CACHE TRANSITIONS',json.dumps(hits))
 print('RECEIPT DIFF PATHS',sorted(set(p for x in pairs for p in x.get('receiptDifferencePaths',[]))))
combined['finalHead']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
combined['productionDirtyPaths']=[x for x in subprocess.check_output(['git','diff','--name-only','HEAD','--','src'],cwd=root,text=True).splitlines()if not x.startswith('src/__tests__/')and '/__tests__/'not in x]
combined['sourceStillClean']=combined['finalHead']==head and not combined['productionDirtyPaths'];assert combined['sourceStillClean']
gz(W/('native-group-cache0-cost-'+head[:9])/'FINAL-EVIDENCE.json.gz',combined)
print('FINAL',json.dumps(combined))
