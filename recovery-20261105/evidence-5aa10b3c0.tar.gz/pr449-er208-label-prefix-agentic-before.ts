import{writeFileSync,mkdirSync}from'node:fs';import{gzipSync}from'node:zlib';
const out='/tmp/pr449-week-comparison-20261101/er-label-prefix-adb463';mkdirSync(out,{recursive:true});
const{renderMermaidSVGWithReceipt}=await import('/tmp/pr449-main-integration-20261029-762/src/index.ts');
const source='erDiagram\ndirection LR\n'+Array.from({length:207},(_,i)=>`N${i} ||--o{ N${i+1} : owns`).join('\n');const options={graphLayout:{backend:'agentic',fallback:'none'}};
let outcome:any;try{outcome={status:'returned',result:renderMermaidSVGWithReceipt(source,options)}}catch(e:any){outcome={status:'refused',error:{name:e.name,message:e.message,stack:e.stack}}}
const all=JSON.stringify({source,options,actualPublicCalls:1,outcome});let consumed=0;for(let i=0;i<all.length;i++)consumed+=all.charCodeAt(i);writeFileSync(out+'/BEFORE208-AGENTIC.json.gz',gzipSync(all));console.log(JSON.stringify({status:outcome.status,proof:outcome.result?.receipt.layoutCertification,error:outcome.error,consumed}));
