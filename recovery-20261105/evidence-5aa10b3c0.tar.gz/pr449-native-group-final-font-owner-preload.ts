import { readFileSync } from 'node:fs'
const arm=process.env.AM_FINAL_FONT_OWNER_ARM
const base='/tmp/pr449-week-comparison-20261101/native-group-actual-b063/'
const overlays={ 'freeze-before':base+'freeze-before-preload.ts', 'writer-before':base+'writer-binding-before-preload.ts' }
if(arm!=='current'&&!(arm in overlays))throw new Error('explicit final font-owner arm required')
Bun.plugin({name:'final-native-font-owner-evidence',setup(build){
 build.onLoad({filter:/\/src\/__tests__\/paint-certification\.test\.ts$/},args=>{
  let source=readFileSync(args.path,'utf8')
  source="import { writeFileSync as saveFinalFontOwnerPacket } from 'node:fs'\n"+source
  const fontStart=source.indexOf("test('native group font scope")
  const fontPacket=source.indexOf('  expect(packet.restored).toBe(true)',fontStart)
  if(fontStart<0||fontPacket<0)throw new Error('font owner packet boundary changed')
  source=source.substring(0,fontPacket)+"  saveFinalFontOwnerPacket('"+base+'owner-final-'+arm+"-font-packet.json', child.stdout)\n"+source.substring(fontPacket)
  const nativePacket=source.indexOf('  const { rendered, stages, provider } = JSON.parse(child.stdout)')
  if(nativePacket<0)throw new Error('Native cyclic19 packet boundary changed')
  source=source.substring(0,nativePacket)+"  saveFinalFontOwnerPacket('"+base+'owner-final-'+arm+"-native19-packet.json', child.stdout)\n"+source.substring(nativePacket)
  if(arm!=='current')source=source.replaceAll("['--eval', String.raw`","['--preload', '"+overlays[arm]+"', '--eval', String.raw`")
  return {contents:source,loader:'ts'}
 })
}})
