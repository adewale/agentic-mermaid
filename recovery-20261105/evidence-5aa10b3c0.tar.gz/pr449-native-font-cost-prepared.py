import pathlib,os,sys,json,gzip,tempfile,subprocess,shutil
R=pathlib.Path('/tmp/pr449-main-integration-20261029-762');W=pathlib.Path('/tmp/pr449-week-comparison-20261101');B='9f519bf00eced828e193fcbb80947dc20fd6c5c2';BUN='/tmp/pr449-bin/bun';PATHS=['src/svg-structure.ts','src/shared/xml-name.ts','src/output-security.ts'];worker=pathlib.Path('/tmp/pr449-native-font-cost-worker.ts')
if sys.argv[1:]==['--prepare']:
 assert worker.is_file();print('STATIC_READY HOLD:4freshworkers/12publicSVGcalls max;smallordinaryClass AM/ELK before9f519/current3lexer-module overlays, geometrycacheOFF cold/repeat/retry-to-retrytwice;fullSVG/rawENTIREreceipt/errorconsume,stages/provider/cache/RSS/postGC;noP-onlygate/no speedpreservationclaim;0calls.');sys.exit()
assert len(sys.argv)in [2,3]and sys.argv[1]=='--run','RootGO+authorityCPUclear required'
E=dict(os.environ,PATH='/tmp/pr449-bin:'+os.environ['PATH'],GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',NODE_DISABLE_COMPILE_CACHE='1',AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env=E,text=True).strip()
head=git('rev-parse','HEAD')
if len(sys.argv)==3:assert head==sys.argv[2],'Wrong frozen HEAD'
O=W/('native-font-cost-'+head[:9]);O.mkdir(exist_ok=True);S=None
j={'beforeModuleRevision':B,'candidateHead':head,'runtimeOverlayPaths':PATHS,'actualPublicCalls':0,'runs':[],'errors':[],'scope':'Exactly4freshworkers/12publicSVGcalls maximum;smallordinaryClass3cards/3relations bothbackends. BeforeAgentic/afterAgentic/afterELK/beforeELK;geometrycacheoff,onecold/repeat/realretry-to-retrytwiceedit each. EntireSVG/rawENTIREreceipt or fullfailure serialization consumed. Sourcelexeronlydelta,allstatuses/errors/adverse retained;N1/cell/order+import/harness/observerinclusive,no ratio/causal/preservation/allocationclaim. PostGC holds3products perworker. No giantcapacity/profiles/payload.'}
def gz(name,v):
 data=v if isinstance(v,bytes)else json.dumps(v,separators=(',',':')).encode();(O/name).write_bytes(gzip.compress(data,compresslevel=9,mtime=0))
def save():gz('RESULTS.json.gz',j)
try:
 before={p:subprocess.check_output(['git','show',B+':'+p],cwd=R,env=E)for p in PATHS};after={p:(R/p).read_bytes()for p in PATHS};assert all(before[p]!=after[p]for p in PATHS)
 S=pathlib.Path(tempfile.mkdtemp(prefix='pr449-native-font-cost-',dir='/dev/shm'));E.update(TMPDIR=str(S),XDG_CACHE_HOME=str(S/'cache'),BUN_RUNTIME_TRANSPILER_CACHE_PATH=str(S/'bun-cache'));overlays={}
 for arm,files in [('before',before),('after',after)]:
  overlays[arm]={};(S/arm).mkdir()
  for path,data in files.items():
   p=S/arm/path.replace('/','__');p.write_bytes(data);overlays[arm][str(R/path)]=str(p)
 (S/'worker.ts').write_bytes(worker.read_bytes());source='classDiagram\ndirection TB\nclass A\nclass B\nclass Sink\nA --> Sink : input\nB --> Sink\nSink --> Sink : retry';edited=source.replace(': retry',': retry twice');(S/'source.mmd').write_text(source);(S/'edit.mmd').write_text(edited);j['source']=source;j['edited']=edited
 syntax=subprocess.run([BUN,'-e',"new Bun.Transpiler({loader:'ts'}).transformSync(require('node:fs').readFileSync(process.argv[1],'utf8'));console.log('SYNTAX_OK')",str(S/'worker.ts')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert syntax.returncode==0,syntax.stderr.decode();print(syntax.stdout.decode().strip(),flush=True)
 for i,(backend,arm)in enumerate([('agentic','before'),('agentic','after'),('elk','after'),('elk','before')]):
  options={'graphLayout':{'backend':backend,'fallback':'none'},'embedFontImport':False};(S/'options.json').write_text(json.dumps(options));out=S/('w'+str(i));job={'root':str(R),'count':3,'backend':backend,'arm':arm,'overlays':overlays[arm],'sourceFile':str(S/'source.mmd'),'editFile':str(S/'edit.mmd'),'optionsFile':str(S/'options.json'),'out':str(out)};(S/'job.json').write_text(json.dumps(job));p=subprocess.run([BUN,str(S/'worker.ts'),str(S/'job.json')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120);actual=p.stdout.decode().count('ACTUAL_PUBLIC_CALL_START');j['actualPublicCalls']+=actual;gz('w'+str(i)+'-stdout-stderr.log.gz',p.stdout+p.stderr)
  if p.returncode:
   j['errors'].append({'worker':i,'backend':backend,'arm':arm,'actualCallsObserved':actual,'exitCode':p.returncode,'stderr':p.stderr.decode()});save();continue
  row=json.loads(gzip.decompress(pathlib.Path(str(out)+'.json.gz').read_bytes()));assert row['actualPublicCalls']==actual;row['worker']=i
  for phase in row['rows']:
   if phase['status']=='returned':
    name=f'{backend}-{arm}-{phase["phase"]}.svg.gz';data=gzip.decompress(pathlib.Path(str(out)+'-'+phase['phase']+'.svg.gz').read_bytes());gz(name,data);phase['svgReference']=str(O/name)
  j['runs'].append(row);save();print('WORKER',i,backend,arm,'calls',actual,'RSSKiB',row['peakRssKiB'],[(x['phase'],x['status'],round(x['elapsedMs'],3),x.get('proof',{}).get('status'),[e.get('detail')for e in x['paintProviderEvents']])for x in row['rows']],flush=True)
 j['sourcesUnchanged']=all((R/p).read_bytes()==after[p]for p in PATHS);j['completed']=j['actualPublicCalls']==12 and len(j['runs'])==4 and not j['errors']and j['sourcesUnchanged']and all(r['overlayLoads']==3 for r in j['runs'])
except Exception as e:j['error']=repr(e);j['completed']=False
finally:
 if S:shutil.rmtree(S)
 j['ramRemoved']=S is None or not S.exists();save();print('FINAL',json.dumps({k:j.get(k)for k in ['completed','actualPublicCalls','errors','error','sourcesUnchanged','ramRemoved']}),flush=True)
