import pathlib,os,sys,json,gzip,tempfile,subprocess,shutil,ast
R=pathlib.Path('/tmp/pr449-main-integration-20261029-762');W=pathlib.Path('/tmp/pr449-week-comparison-20261101');B=subprocess.check_output(['git','rev-parse','adb4633a0^{commit}'],cwd=R,env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0'),text=True).strip();BUN='/tmp/pr449-bin/bun';PATHS=['src/er/layout.ts','src/er/label-layout.ts'];worker=pathlib.Path('/tmp/pr449-er-prefix-cost-worker.ts')
if sys.argv[1:]==['--prepare']:
 assert worker.is_file();print('STATIC_READY HOLD:4freshworkers/12publicSVGcalls max;ER32ONLYLR×Agentic/ELK×beforeadbTWOERmodules/current;geometrycacheOFF;3cold/repeat/lastowns-to-revises calls each;allSVG/ENTIREreceipt or refusalJSON fullyconsumed;provider/cache/stages/RSS/postGC;noP-onlygate/ratios;0calls.');sys.exit()
assert len(sys.argv)in [2,3]and sys.argv[1]=='--run','RootGO+ERownerCPUclear required'
E=dict(os.environ,PATH='/tmp/pr449-bin:'+os.environ['PATH'],GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',NODE_DISABLE_COMPILE_CACHE='1',AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env=E,text=True).strip()
head=git('rev-parse','HEAD');assert len(sys.argv)==2 or head==sys.argv[2],'Wrong frozenHEAD';O=W/('er-prefix-cost-followup32-'+head[:9]);O.mkdir(exist_ok=True);S=None
j={'beforeRuntimeRevision':B,'runtimeOverlayPaths':PATHS,'candidateHead':head,'actualPublicCalls':0,'runs':[],'errors':[],'scope':'Exactly4freshworkers/12publicSVGcalls maximum. Geometrycacheoff only;ONEreverseorder32equivalentcontrolFOLLOWUP;NO208or256calls LR bothbackend beforeadbTWOERmodules/currentfrozenmodule. Onecold/repeat/visiblelastcaptionedit each. EntireSVG+rawENTIREreceipt or fullrefusal serialization consumed. All statuses/providers/errors/adverse preserved;noP-onlygate. N1/cell,reverseorders acrosscases notindependentreplication;no ratio/causal/preservation/allocationclaim. RSS/postGC includesimports/overlay/harness/stages/observations/threeheldproducts.'}
def gz(name,v):
 data=v if isinstance(v,bytes)else json.dumps(v,separators=(',',':')).encode();(O/name).write_bytes(gzip.compress(data,compresslevel=9,mtime=0))
def save():gz('RESULTS.json.gz',j)
try:
 before={p:subprocess.check_output(['git','show',B+':'+p],cwd=R,env=E)for p in PATHS};after={p:(R/p).read_bytes()for p in PATHS};assert all(before[p]!=after[p]for p in PATHS)
 S=pathlib.Path(tempfile.mkdtemp(prefix='pr449-er-followup32-',dir='/dev/shm'));E.update(TMPDIR=str(S),XDG_CACHE_HOME=str(S/'cache'),BUN_RUNTIME_TRANSPILER_CACHE_PATH=str(S/'bun-cache'))
 overlays={}
 for arm,files in [('before',before),('after',after)]:
  overlays[arm]={};(S/arm).mkdir()
  for path,data in files.items():
   out=S/arm/path.replace('/','__');out.write_bytes(data);overlays[arm][str(R/path)]=str(out)
 (S/'worker.ts').write_bytes(worker.read_bytes());j['cases']={}
 for n in [32]:
  source='erDiagram\ndirection LR\n'+'\n'.join(f'N{i} ||--o{{ N{i+1} : owns'for i in range(n-1));last=f'N{n-2} ||--o{{ N{n-1} : owns';assert source.count(last)==1;edited=source.replace(last,last.removesuffix('owns')+'revises')
  (S/(str(n)+'.mmd')).write_text(source);(S/(str(n)+'-edit.mmd')).write_text(edited);j['cases'][str(n)]={'source':source,'edited':edited,'edit':'last relationship owns→revises','counts':{'entities':n,'relationships':n-1}}
 syntax=subprocess.run([BUN,'-e',"new Bun.Transpiler({loader:'ts'}).transformSync(require('node:fs').readFileSync(process.argv[1],'utf8'));console.log('SYNTAX_OK')",str(S/'worker.ts')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert syntax.returncode==0,syntax.stderr.decode();print(syntax.stdout.decode().strip(),flush=True)
 jobs=[(32,'agentic','after'),(32,'agentic','before'),(32,'elk','before'),(32,'elk','after')]
 for i,(count,backend,arm)in enumerate(jobs):
  options={'graphLayout':{'backend':backend,'fallback':'none'}};(S/'options.json').write_text(json.dumps(options));out=S/('w'+str(i));job={'root':str(R),'count':count,'backend':backend,'arm':arm,'overlays':overlays[arm],'sourceFile':str(S/(str(count)+'.mmd')),'editFile':str(S/(str(count)+'-edit.mmd')),'optionsFile':str(S/'options.json'),'out':str(out)};(S/'job.json').write_text(json.dumps(job))
  p=subprocess.run([BUN,str(S/'worker.ts'),str(S/'job.json')],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);actual=p.stdout.decode().count('ACTUAL_PUBLIC_CALL_START');j['actualPublicCalls']+=actual;gz('w'+str(i)+'-stdout-stderr.log.gz',p.stdout+p.stderr)
  if p.returncode:
   j['errors'].append({'worker':i,'count':count,'backend':backend,'arm':arm,'actualCallsObserved':actual,'exitCode':p.returncode,'stderr':p.stderr.decode()});save();continue
  row=json.loads(gzip.decompress(pathlib.Path(str(out)+'.json.gz').read_bytes()));assert row['actualPublicCalls']==actual;row['worker']=i
  for phase in row['rows']:
   if phase['status']=='returned':
    name=f'{count}-{backend}-{arm}-{phase["phase"]}.svg.gz';data=gzip.decompress(pathlib.Path(str(out)+'-'+phase['phase']+'.svg.gz').read_bytes());gz(name,data);phase['svgReference']=str(O/name)
  j['runs'].append(row);save();print('WORKER',i,count,backend,arm,'calls',actual,'RSSKiB',row['peakRssKiB'],[(x['phase'],x['status'],round(x['elapsedMs'],3),x.get('proof',{}).get('status'),[e.get('detail')for e in x['paintProviderEvents']])for x in row['rows']],flush=True)
 j['ERSourceUnchanged']=all((R/p).read_bytes()==data for p,data in after.items());j['completed']=j['actualPublicCalls']==12 and len(j['runs'])==4 and not j['errors']and j['ERSourceUnchanged']and all(r['overlayLoads']==2 for r in j['runs'])
except Exception as e:j['error']=repr(e);j['completed']=False
finally:
 if S:shutil.rmtree(S)
 j['ramRemoved']=S is None or not S.exists();save();print('FINAL',json.dumps({k:j.get(k)for k in ['completed','actualPublicCalls','errors','error','ERSourceUnchanged','ramRemoved']}),flush=True)
