# Retained Node24 calibration, exactly one fresh process per case/engine; no build.
import ast,sys,os,pathlib,subprocess,json,gzip
if sys.argv[1:]==['--prepare']:
 print('STATIC_ONLY_READY HOLD: exactly two fresh Node24 source witness calls, full SVG/ENTIRE raw receipt or full failure consumed; no normalization; zero calls/builds now.');sys.exit()
assert sys.argv[1:]==['--run']and os.environ.get('PR449_ROOT_GO')=='requirement-compound-node-source','Separate root CPU GO required'
head=os.environ['PR449_FINAL_SHA'];assert len(head)==40
root='/tmp/pr449-main-integration-20261029-762'
def frozen():
 env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,env=env,text=True).strip()==head,'Frozen HEAD mismatch'
 assert not [x for x in subprocess.check_output(['git','diff','--name-only','HEAD','--','src','tsup.browser-lazy.config.ts','scripts/build'],cwd=root,env=env,text=True).splitlines()if not x.startswith('src/__tests__/')and '/__tests__/'not in x],'Dirty production source'
 expected={'src/scene/bounds.ts'}
 changed=subprocess.check_output(['git','diff','--name-only','8393d577f9245f62aa3a0f970cc7aaca2b4f5b9c','HEAD','--','src','tsup.browser-lazy.config.ts','scripts/build'],cwd=root,env=env,text=True).splitlines()
 assert {p for p in changed if not p.startswith('src/__tests__/')and '/__tests__/'not in p}==expected,'Exact shared bounds.ts runtime scope required'
frozen()
E=dict(os.environ,PR449_CONTROLLER_VERIFIED_HEAD=head,AGENTIC_MERMAID_ELK_CACHE='0',AGENTIC_MERMAID_SCENE_ASSERTIONS='0')
base=pathlib.Path('/tmp/pr449-week-comparison-20261101/requirement-compound-node24-'+head[:9]);base.mkdir(exist_ok=True)
results=[];bindings=[]
for caseId,backend in [('fan','agentic'),('fan','elk')]:
 tag=caseId+'-'+backend
 frozen()
 p=subprocess.run(['node','/tmp/pr449-requirement-compound-node24-witness-prepared.mjs','--run',caseId,backend],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=E,timeout=180)
 frozen()
 (base/(tag+'-stdout-stderr.log.gz')).write_bytes(gzip.compress(p.stdout+p.stderr,mtime=0))
 path=base/tag/'OUTCOME.json.gz'
 result=json.loads(gzip.decompress(path.read_bytes()))if path.is_file()else {'status':'setup-error','actualPublicCalls':0}
 results.append({'caseId':caseId,'backend':backend,'exitCode':p.returncode,'result':result});bindings.extend(result.get('bindings',[]))
 print(tag,'exit',p.returncode,'status',result['status'],'calls',result['actualPublicCalls'],flush=True)
(base/'bindings-requirement-compound-node24.json').write_text(json.dumps(bindings))
summary={'sourceHead':head,'actualPublicCalls':sum(x['result']['actualPublicCalls']for x in results),'results':results,'completed':len(bindings)==2 and all(x['exitCode']==0 and x['result'].get('completed')for x in results)}
(base/'OUTCOME.json.gz').write_bytes(gzip.compress(json.dumps(summary).encode(),mtime=0))
print(json.dumps({'completed':summary['completed'],'actualPublicCalls':summary['actualPublicCalls'],'bindings':str(base/'bindings-requirement-compound-node24.json')}))
