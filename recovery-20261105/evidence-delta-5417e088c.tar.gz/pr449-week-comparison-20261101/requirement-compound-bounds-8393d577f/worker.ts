import { readFileSync, writeFileSync, writeSync, mkdirSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
const root='/tmp/pr449-main-integration-20261029-762',fixture='/tmp/pr449-week-comparison-20261101/requirement-compound-bounds-8393d577f',arm=process.argv[2],out=process.argv[3],backend=process.argv[4]??'agentic'
Error.stackTraceLimit=40
const sourcePath=fixture+'/source.mmd'
if(!arm||!out||!['agentic','elk'].includes(backend)||process.env.PR449_ROOT_GO!=='requirement-compound-bounds')throw new Error('Held: root GO, arm/output and backend required; zero calls started')
mkdirSync(out,{recursive:true})
const reference=JSON.parse(readFileSync(fixture+'/references.json','utf8'))[backend]
const previousSVG=gunzipSync(readFileSync(reference.svg)),previousReceiptRaw=gunzipSync(readFileSync(reference.receipt)),previousReceipt=JSON.parse(previousReceiptRaw.toString('utf8'))
const previousProofJSON=JSON.stringify(previousReceipt.layoutCertification)
const sourceBytes=readFileSync(sourcePath),source=sourceBytes.toString('utf8')
const revision=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8',env:{...process.env,GIT_NO_LAZY_FETCH:'1',GIT_OPTIONAL_LOCKS:'0'}}).trim()
const wallStart=performance.now(),cpuStart=process.cpuUsage()
const log=(value:unknown)=>writeSync(1,JSON.stringify(value)+'\n')
log({event:'IMPORT_START',memory:process.memoryUsage(),cpu:process.cpuUsage()})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const {withRenderStageObserver}=await import(root+'/src/render-stages.ts')
const {withPerformanceObserver}=await import(root+'/src/performance-observations.ts')
const {apiFailure}=await import(root+'/eval/layout-compare/outcomes.ts')
const importMs=performance.now()-wallStart,importCPU=process.cpuUsage(cpuStart)
const options=JSON.parse(readFileSync(fixture+'/'+backend+'.options.json','utf8'))
const sourceExactReference=sourceBytes.equals(readFileSync(reference.source)),optionsExactReference=JSON.stringify(options)===JSON.stringify(JSON.parse(readFileSync(reference.options,'utf8')))
const stages:any[]=[],events:any[]=[]
const before=process.memoryUsage(),renderCPU=process.cpuUsage(),renderStart=performance.now()
let product:any,row:any
log({event:'ACTUAL_PUBLIC_CALL_START',actualCalls:1,importMs,importCPU,before})
try{
 const artifact=withPerformanceObserver(event=>events.push(event),()=>withRenderStageObserver(stage=>{stages.push(stage);log({event:'STAGE_COMPLETE',...stage})},()=>renderMermaidSVGWithReceipt(source,options)))
 product={svg:artifact.svg,receipt:artifact.receipt}
 const bytes=Buffer.from(JSON.stringify(product))
 writeFileSync(out+'/product.json.gz',gzipSync(bytes))
 writeFileSync(out+'/actual.svg.gz',gzipSync(product.svg));writeFileSync(out+'/actual.receipt.json.gz',gzipSync(JSON.stringify(product.receipt)))
 const proof=product.receipt.layoutCertification,proofJSON=JSON.stringify(proof)
 if(proofJSON!==undefined)writeFileSync(out+'/actual.proof.json.gz',gzipSync(proofJSON))
 row={status:'returned',fullyConsumedBytes:bytes.length,proof,referenceComparisons:{wholeSVGExact:Buffer.from(product.svg,'utf8').equals(previousSVG),entireRawReceiptExact:Buffer.from(JSON.stringify(product.receipt),'utf8').equals(previousReceiptRaw),entireProofExact:proofJSON===previousProofJSON}}
}catch(error:any){
 product={normalized:apiFailure(error),name:error?.name,message:error?.message,code:error?.code,stack:error?.stack,cause:error?.cause?{name:error.cause.name,message:error.cause.message,stack:error.cause.stack}:undefined,certification:error?.certification}
 const bytes=Buffer.from(JSON.stringify(product));writeFileSync(out+'/product.json.gz',gzipSync(bytes))
 const proofJSON=JSON.stringify(error?.certification)
 if(proofJSON!==undefined)writeFileSync(out+'/actual.proof.json.gz',gzipSync(proofJSON))
 row={status:'refused',fullyConsumedErrorBytes:bytes.length,failure:product,referenceComparisons:{wholeSVGExact:null,entireRawReceiptExact:null,entireProofExact:proofJSON===undefined?null:proofJSON===previousProofJSON}}
}
const memoryBeforeGC=process.memoryUsage();Bun.gc(true);const postGCMemory=process.memoryUsage()
const report={revision,arm,sourceBytesUnchanged:sourceBytes.equals(readFileSync(sourcePath)),sourceExactReference,optionsExactReference,backend,sourcePath,reference,previousProof:previousReceipt.layoutCertification,memoryBeforeGC,postGCMemory,actualPublicCalls:1,source,options,importMs,importCPU,renderWallMs:performance.now()-renderStart,renderCPU:process.cpuUsage(renderCPU),totalWallMs:performance.now()-wallStart,totalCPU:process.cpuUsage(cpuStart),loadedMemory:before,afterMemory:process.memoryUsage(),peakRssKiB:process.resourceUsage().maxRSS,row,provider:events.filter(e=>e.owner==='paint-certification'),stages,events,product}
writeFileSync(out+'/RESULT.json.gz',gzipSync(JSON.stringify(report)))
log({event:'ACTUAL_PUBLIC_CALL_COMPLETE',...report,product:undefined,events:undefined})
