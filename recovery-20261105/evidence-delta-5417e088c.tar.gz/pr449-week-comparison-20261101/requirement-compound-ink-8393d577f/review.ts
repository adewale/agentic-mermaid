// Candidate-only offline adaptation of requirement-contains-fan-proposal-c0bba6102/review.ts; baseline controls remain retained there.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { gzipSync, gunzipSync } from 'node:zlib'
import { createRequire } from 'node:module'
import { Resvg } from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import { HOSTED_FONT_RESOURCES } from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import { inlineFontVarForRaster } from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const { JSDOM } = createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
const root = '/tmp/pr449-main-integration-20261029-762', out = '/tmp/pr449-week-comparison-20261101/requirement-compound-ink-8393d577f'
if(process.env.PR449_ROOT_GO!=='requirement-compound-ink')throw new Error('Root raster GO required')
const tag = process.argv[2] ?? 'candidate'
const paths = process.argv.slice(3)
assert.equal(paths.length, 1, 'Supply exactly one clean candidate ELK SVG path; baseline is not rerasterized')
const entries = paths.map(path => ({ name: 'candidate-elk', path: path.startsWith('/') ? path : `${out}/${path}` }))
const target = `${out}/${tag}-independent-review.json.gz`
assert(!fs.existsSync(target), `Refusing to overwrite ${target}`)
const attrs = (element: Element) => Object.fromEntries([...element.attributes].map(attribute => [attribute.name, attribute.value]))
const near = (a: number, b: number) => Math.abs(a - b) < 1e-6
const normal = (p: number[], q: number[], box: Record<string, string>) => {
  const x = +box.x, y = +box.y, w = +box.width, h = +box.height, dx = q[0] - p[0], dy = q[1] - p[1]
  return dy === 0 && p[1] > y && p[1] < y + h && (near(p[0], x) && dx < 0 || near(p[0], x + w) && dx > 0)
    || dx === 0 && p[0] > x && p[0] < x + w && (near(p[1], y) && dy < 0 || near(p[1], y + h) && dy > 0)
}
const expected = [['root', 'leaf'], ['root', 'leaf'], ['root', 'leaf'], ['root', 'leaf'], ['root', 'side']]
const sourcePath = '/tmp/pr449-week-comparison-20261101/requirement-contains-fan-proposal-c0bba6102/source.mmd'
const authored = fs.readFileSync(sourcePath, 'utf8').split('\n').filter(line => line.includes(' - contains -> ')).map(line => {
  const match = /^(root) - contains -> (leaf|side)$/.exec(line)
  assert(match, line)
  return [match[1], match[2]]
})
assert.deepEqual(authored, expected)
const scratch = fs.mkdtempSync('/tmp/pr449-contains-fan-fonts-')
let rasterCalls = 0
try {
  const fonts = HOSTED_FONT_RESOURCES.filter(font => font.family === 'Inter')
  const fontFiles = fonts.map(font => {
    const bytes = fs.readFileSync(`${root}/${font.path}`)
    assert.equal(bytes.length, font.bytes)
    assert.equal(createHash('sha256').update(bytes).digest('hex'), font.sha256)
    const path = `${scratch}/${font.file}`
    fs.writeFileSync(path, bytes)
    return path
  })
  const zoom = 3, results = []
  const render = (svg: string, fullName?: string) => {
    rasterCalls++
    const image = new Resvg(inlineFontVarForRaster(svg), { background: '#ffffff', fitTo: { mode: 'zoom', value: zoom }, font: { fontFiles, fontDirs: [], loadSystemFonts: false, defaultFontFamily: 'Inter' } }).render()
    if (fullName) fs.writeFileSync(`${out}/${tag}-${fullName}-full.png.gz`, gzipSync(image.asPng()))
    return { width: image.width, height: image.height, pixels: image.pixels }
  }
  for (const entry of entries) {
    const raw = entry.path.endsWith('.gz') ? gunzipSync(fs.readFileSync(entry.path)).toString() : fs.readFileSync(entry.path, 'utf8')
    const dom = new JSDOM(raw, { contentType: 'image/svg+xml' }), document = dom.window.document as Document
    try {
      const cards = [...document.querySelectorAll('g.requirement-node')]
      assert.deepEqual(cards.map(card => card.getAttribute('data-id')).sort(), ['leaf', 'root', 'side'])
      for (const [id, header, fields] of [['root', '<<Element>>root', ['Type: software']], ['leaf', '<<Requirement>>leaf', ['ID: R1', 'Text: Dispatch']], ['side', '<<Element>>side', ['Type: service']]] as const) {
        const card = cards.find(card => card.getAttribute('data-id') === id)!
        assert.deepEqual([...card.querySelectorAll('text')].map(text => text.textContent), [header, ...fields])
      }
      const carriers = [...document.querySelectorAll('[data-role="relationship"][data-from]')]
      assert.equal(carriers.length, 5)
      assert.deepEqual(carriers.map(carrier => [carrier.getAttribute('data-from'), carrier.getAttribute('data-to')]), expected)
      const ids = carriers.map(carrier => carrier.getAttribute('data-id')!)
      assert.equal(new Set(ids).size, 5)
      const labels = [...document.querySelectorAll('g.requirement-edge-label')]
      assert.equal(labels.length, 5)
      for (const id of ids) {
        const owned = labels.filter(label => label.getAttribute('data-edge-id') === id)
        assert.equal(owned.length, 1)
        assert.deepEqual([...owned[0].querySelectorAll('text')].map(text => text.textContent), ['<<contains>>'])
      }
      const resources = [...document.querySelectorAll('marker#requirement-contains')]
      assert.equal(resources.length, 1)
      const marker = resources[0], ma = attrs(marker)
      assert.equal(ma.orient, 'auto'); assert.equal(ma.markerUnits, 'userSpaceOnUse')
      assert.deepEqual([+ma.markerWidth, +ma.markerHeight, +ma.refX, +ma.refY], [12, 12, 0, 6])
      assert.deepEqual([...marker.children].map(child => child.localName), ['circle', 'path'])
      const circle = attrs(marker.children[0]), cross = attrs(marker.children[1])
      assert.deepEqual([+circle.cx, +circle.cy, +circle.r, +circle['stroke-width']], [6, 6, 5, 1])
      assert.equal(cross.d.replaceAll(' ', ''), 'M26H10M62V10')
      assert.equal(+cross['stroke-width'], 1)
      for (const component of [circle, cross]) { assert.equal(component.stroke, '#47474a'); assert.equal(component.fill, '#FFFFFF') }
      assert(!raw.includes('fan-review-local-marker'))
      const markerMatches = [...raw.matchAll(/<marker\b[^>]*\bid="requirement-contains"[^>]*>[\s\S]*?<\/marker>/g)]
      assert.equal(markerMatches.length, 1)
      const markerXml = markerMatches[0][0]
      const circleMatches = [...markerXml.matchAll(/<circle\b[^>]*\/>/g)], crossMatches = [...markerXml.matchAll(/<path\b[^>]*\/>/g)]
      assert.equal(circleMatches.length, 1); assert.equal(crossMatches.length, 1)
      const carrierTags = [...raw.matchAll(/<polyline\b[^>]*\bdata-role="relationship"[^>]*\/>/g)]
      assert.equal(carrierTags.length, 5)
      assert.equal((raw.match(/<\/defs>/g) ?? []).length, 1)
      const full = render(raw, entry.name), controls = [], vectors = []
      for (const [index, carrier] of carriers.entries()) {
        const ca = attrs(carrier), id = ids[index]
        assert.equal(ca['data-relationship'], 'contains'); assert.equal(ca['data-direction'], 'forward')
        assert.equal(ca['marker-start'], 'url(#requirement-contains)'); assert(!carrier.hasAttribute('marker-end')); assert(!carrier.hasAttribute('stroke-dasharray'))
        const tags = carrierTags.filter(match => match[0].includes(`data-id="${id}"`))
        assert.equal(tags.length, 1)
        const selected = tags[0], at = selected.index!, originalTag = selected[0]
        assert.equal((originalTag.match(/\smarker-start="[^"]*"/g) ?? []).length, 1)
        const points = ca.points.trim().split(/\s+/).map(point => point.split(',').map(Number))
        assert(points.length >= 2 && points.every(point => point.length === 2 && point.every(Number.isFinite)))
        const start = points[0], next = points[1], end = points.at(-1)!, previous = points.at(-2)!
        const sourceFrame = attrs(cards.find(card => card.getAttribute('data-id') === ca['data-from'])!.querySelector('rect')!)
        const targetFrame = attrs(cards.find(card => card.getAttribute('data-id') === ca['data-to'])!.querySelector('rect')!)
        const length = Math.hypot(next[0] - start[0], next[1] - start[1])
        const center = length > 0 ? [start[0] + 6 * (next[0] - start[0]) / length, start[1] + 6 * (next[1] - start[1]) / length] : null
        // Keep the proof consumer's immediate-segment fact separate from SVG's
        // first nonzero direction when initial vertices coincide.
        const firstNonzero = points.slice(1).find(point => point[0] !== start[0] || point[1] !== start[1]) ?? null
        const firstNonzeroLength = firstNonzero ? Math.hypot(firstNonzero[0] - start[0], firstNonzero[1] - start[1]) : 0
        const firstNonzeroCenter = firstNonzero ? [start[0] + 6 * (firstNonzero[0] - start[0]) / firstNonzeroLength, start[1] + 6 * (firstNonzero[1] - start[1]) / firstNonzeroLength] : null
        vectors.push({ id, from: ca['data-from'], to: ca['data-to'], start, next, end, previous, sourceFrame, targetFrame, immediateSourceDirectionKnown: length > 0, sourceNormal: length > 0 ? normal(start, next, sourceFrame) : null, targetNormal: normal(end, previous, targetFrame), markerCenter: center, firstNonzeroPoint: firstNonzero, firstNonzeroDirection: firstNonzero ? [firstNonzero[0] - start[0], firstNonzero[1] - start[1]] : null, firstNonzeroSourceNormal: firstNonzero ? normal(start, firstNonzero, sourceFrame) : null, firstNonzeroMarkerCenter: firstNonzeroCenter })
        const roi = { x0: start[0] - 14, y0: start[1] - 14, x1: start[0] + 14, y1: start[1] + 14 }
        for (const kind of ['whole', 'circle', 'cross'] as const) {
          let replacement: string, addedResource = ''
          if (kind === 'whole') replacement = originalTag.replace(/\smarker-start="[^"]*"/, '')
          else {
            // Only this occurrence references the copied explicit resource;
            // all other heads keep their exact original resource and paint order.
            const localId = `fan-review-local-marker-${index}-${kind}`
            const resource = markerXml.replace('id="requirement-contains"', `id="${localId}"`).replace(kind === 'circle' ? circleMatches[0][0] : crossMatches[0][0], '')
            addedResource = resource
            replacement = originalTag.replace('url(#requirement-contains)', `url(#${localId})`)
          }
          let absentSvg = raw.slice(0, at) + replacement + raw.slice(at + originalTag.length)
          if (addedResource) absentSvg = absentSvg.replace('</defs>', `${addedResource}</defs>`)
          const absent = render(absentSvg)
          assert.equal(full.width, absent.width); assert.equal(full.height, absent.height)
          let changed = 0, darker = 0, lighter = 0, outsideRoi = 0
          for (let y = 0; y < full.height; y++) for (let x = 0; x < full.width; x++) {
            const offset = (y * full.width + x) * 4
            if (Math.abs(full.pixels[offset] - absent.pixels[offset]) < 4 && Math.abs(full.pixels[offset + 1] - absent.pixels[offset + 1]) < 4 && Math.abs(full.pixels[offset + 2] - absent.pixels[offset + 2]) < 4 && Math.abs(full.pixels[offset + 3] - absent.pixels[offset + 3]) < 4) continue
            changed++
            const wx = (x + .5) / zoom, wy = (y + .5) / zoom
            if (wx < roi.x0 || wx > roi.x1 || wy < roi.y0 || wy > roi.y1) outsideRoi++
            if (full.pixels[offset] + full.pixels[offset + 1] + full.pixels[offset + 2] < absent.pixels[offset] + absent.pixels[offset + 1] + absent.pixels[offset + 2]) darker++
            else lighter++
          }
          controls.push({ id, kind, changed, darker, lighter, outsideRoi, roi, contribution: darker > 0 && outsideRoi === 0 ? 'positive owned component ink' : 'zero or ambiguous component ink; retained adverse' })
        }
      }
      const circlePairs = vectors.flatMap((first, index) => vectors.slice(index + 1).filter(second => first.markerCenter && second.markerCenter).map(second => {
        const distance = Math.hypot(first.markerCenter![0] - second.markerCenter![0], first.markerCenter![1] - second.markerCenter![1])
        return { first: first.id, second: second.id, centerDistance: distance, circleInteriorsOverlap: distance < 10, strokedCircleBoundsOverlap: distance < 11 }
      }))
      const receiptPath = entry.path.replace(/actual\.svg(?:\.gz)?$/, 'actual.receipt.json.gz')
      const proof = fs.existsSync(receiptPath) ? JSON.parse(gunzipSync(fs.readFileSync(receiptPath)).toString()).layoutCertification : null
      results.push({ ...entry, svgBytes: Buffer.byteLength(raw, 'utf8'), viewport: attrs(document.documentElement), proof, rasterSize: [full.width, full.height], vectors, circlePairs, controls })
    } finally { dom.window.close() }
  }
  assert.equal(rasterCalls, 16)
  const report = { publicCalls: 0, offlineRasterCalls: rasterCalls, sourcePath, retainedBaselineControls: '/tmp/pr449-week-comparison-20261101/requirement-contains-fan-proposal-c0bba6102/before-independent-review.json.gz', authoredRelations: expected, results, fonts: fonts.map(font => ({ file: font.file, bytes: font.bytes, sha256: font.sha256 })), scope: 'Exact saved full-canvas SVGs under pinned Inter. Individual whole-marker and local circle/cross differential contributions do not establish complete or recognizable glyphs or separated relationships. Duplicate immediate source points retain the immediate-direction unknown; separate first-nonzero direction and circle pose are geometric SVG observations, not a proof-status replacement. No universal-font, Native proof, backend-parity or capacity claim.' }
  fs.writeFileSync(target, gzipSync(JSON.stringify(report, null, 2)))
  console.log(JSON.stringify(report))
} finally { fs.rmSync(scratch, { recursive: true, force: true }) }
