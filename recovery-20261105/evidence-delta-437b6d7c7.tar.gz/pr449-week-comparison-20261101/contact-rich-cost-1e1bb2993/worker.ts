// Existing sparse256-isolate three-phase cost consumer, current source only.
import { readFileSync, writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
Error.stackTraceLimit=40
if(process.env.PR449_ROOT_GO!=='contact-rich-cost')throw new Error('Root GO required; no calls started')
const job = JSON.parse(readFileSync(Bun.argv[2]!, 'utf8'))
const overlayLoads = 0
const importStart = performance.now()
const { renderMermaidSVGWithReceipt } = await import(job.root + '/src/index.ts')
const { withRenderStageObserver } = await import(job.root + '/src/render-stages.ts')
const { withPerformanceObserver } = await import(job.root + '/src/performance-observations.ts')
const { apiFailure } = await import(job.root + '/eval/layout-compare/outcomes.ts')
const importMs = performance.now() - importStart
const source = readFileSync(job.sourceFile, 'utf8'), edited = readFileSync(job.editFile, 'utf8')
const options = JSON.parse(readFileSync(job.optionsFile, 'utf8'))
const consume = (value: unknown) => {
  const bytes = Buffer.from(JSON.stringify(value), 'utf8')
  return { bytes: bytes.length } // Entire SVG/receipt JSON materialized; raw products saved below, no own-output hash.
}
const outputs: unknown[] = [], rows: unknown[] = []
let actualPublicCalls = 0
Bun.gc(true)
const loaded = process.memoryUsage()
for (const [phase, input] of [['cold', source], ['repeat', source], ['edit', edited]]) {
  const stages: unknown[] = [], events: any[] = []
  process.stdout.write('ACTUAL_PUBLIC_CALL_START\n')
  actualPublicCalls++
  const start = performance.now()
  let row: any
  try {
    const result = withPerformanceObserver((event: unknown) => events.push(event), () => withRenderStageObserver((stage: unknown) => stages.push(stage), () => renderMermaidSVGWithReceipt(input, options)))
    const consumed = consume(result), receiptJSON = JSON.stringify(result.receipt)
    row = { phase, status: 'returned', elapsedMs: performance.now() - start, ...consumed, receiptJSON,
      proof: result.receipt.layoutCertification, viewBox: result.svg.match(/viewBox="([^"]+)"/)?.[1] }
    const cold:any=outputs[0];row.ownColdWholeSVGExact=phase==='cold'?true:result.svg===cold?.svg;row.ownColdEntireRawReceiptExact=phase==='cold'?true:receiptJSON===JSON.stringify(cold?.receipt);row.editSVGChanged=phase==='edit'?result.svg!==cold?.svg:undefined
    outputs.push(result)
    writeFileSync(job.out + '-' + phase + '.svg.gz', gzipSync(result.svg))
    writeFileSync(job.out + '-' + phase + '.receipt.json.gz', gzipSync(receiptJSON))
  } catch (error: any) {
    const failure = { error: apiFailure(error), name: error?.name, message: error?.message, stack: error?.stack, cause: { name: error?.cause?.name, message: error?.cause?.message, stack: error?.cause?.stack } }
    const consumed = consume(failure)
    row = { phase, status: 'refused', elapsedMs: performance.now() - start, consumedError: consumed, failure }
    outputs.push(failure)
  }
  row.stages = stages; row.events = events
  row.paintProviderEvents = events.filter(event => event.owner === 'paint-certification')
  row.memoryBeforeGC=process.memoryUsage()
  Bun.gc(true)
  row.afterGC = process.memoryUsage()
  rows.push(row)

}
writeFileSync(job.out + '.json.gz', gzipSync(JSON.stringify({ arm: job.arm, count: job.count, backend: job.backend, source, edited, options, actualPublicCalls, overlayLoads, cache: process.env.AGENTIC_MERMAID_ELK_CACHE, importMs, loaded, peakRssKiB: process.resourceUsage().maxRSS, rows })))
