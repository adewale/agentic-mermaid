// Disposable saved-SVG check; no render/layout API imports or calls.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
import { gunzipSync, gzipSync } from 'node:zlib'
import { Resvg } from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import { HOSTED_FONT_RESOURCES } from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import { inlineFontVarForRaster } from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const { JSDOM } = createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
if (process.env.PR449_ROOT_GO !== 'richtrial-actual-ink') throw Error('Held: explicit root raster GO required; zero rasters started')
const root = '/tmp/pr449-main-integration-20261029-762', week = '/tmp/pr449-week-comparison-20261101', out = week + '/richtrial'
const words = ['Top', 'Bottom 🚀', 'first', 'second']
const inputs = [
  { arm: 'before', svg: week + '/rich-line-format-1e1bb2993/before-agentic/actual.svg.gz', receipt: week + '/rich-line-format-1e1bb2993/before-agentic/actual.receipt.json.gz' },
  { arm: 'after', svg: week + '/contact-rich-cost-1e1bb2993/rich-agentic-cache0-cold.svg.gz', receipt: week + '/contact-rich-cost-1e1bb2993/rich-agentic-cache0-cold.receipt.json.gz' },
]
const report: any = { publicCalls: 0, layoutCalls: 0, offlineRasterCalls: 0, rasterLimit: 11, zoom: 2, errors: [], arms: [], scope: 'Exact saved SVGs, DOM-serialized fulls and one visibility-hidden actual leaf per control. Fixed four normal Inter faces, no system fonts. Positive word contribution does not establish emoji availability or physical italic shape. Actual bold effect is a separate forced-400 control. Raw paint receipts are separate evidence.' }
const save = (name: string, data: any) => fs.writeFileSync(out + '/' + name + '.gz', gzipSync(typeof data === 'string' || data instanceof Uint8Array ? data : JSON.stringify(data)))
const checkpoint = () => save('REPORT.json', report)
const errorRecord = (e: any) => ({ name: e?.name, message: e?.message, stack: e?.stack })
const read = (p: string) => gunzipSync(fs.readFileSync(p)).toString()
const attr = (e: any) => Object.fromEntries([...e.attributes].map((a: any) => [a.name, a.value]))
const eq = (a: any, b: any) => JSON.stringify(a) === JSON.stringify(b)
const leaves = (d: any) => [...d.querySelectorAll('text,tspan')].filter((e: any) => !e.querySelector('text,tspan') && e.textContent.length)
const inherited = (e: any, property: string, fallback: string) => {
  for (let n = e; n?.nodeType === 1; n = n.parentElement) {
    const value = n.style?.getPropertyValue(property) || n.getAttribute(property)
    if (value) return value
  }
  return fallback
}
const box = (e: any) => { assert(e?.localName === 'rect', 'Actual ROI carrier is not a rect'); const [x, y, w, h] = ['x', 'y', 'width', 'height'].map(k => Number(e.getAttribute(k))); assert([x,y,w,h].every(Number.isFinite) && w > 0 && h > 0); return { x0: x - 1, y0: y - 1, x1: x + w + 1, y1: y + h + 1, actualAttributes: attr(e) } }
const viewport = (d: any) => Object.fromEntries(['width', 'height', 'viewBox'].map(k => [k, d.documentElement.getAttribute(k)]))
const semantic = (d: any) => {
  const entities = [...d.querySelectorAll('g.entity[data-role="entity"]')], edges = [...d.querySelectorAll('polyline.er-relationship')], cards = [...d.querySelectorAll('g[data-role="cardinality"]')]
  const observed = { entities: entities.map((e: any) => ({ id: e.getAttribute('data-id'), label: e.getAttribute('data-label') })), attributes: [...d.querySelectorAll('text[data-role="attribute"]')].map((e: any) => ({ id: e.getAttribute('data-id'), text: e.textContent })), edges: edges.map((e: any) => ({ id: e.getAttribute('data-id'), from: e.getAttribute('data-from'), to: e.getAttribute('data-to'), label: e.getAttribute('data-label'), cardinality1: e.getAttribute('data-cardinality1'), cardinality2: e.getAttribute('data-cardinality2') })), cardinalities: cards.map((e: any) => ({ id: e.getAttribute('data-id'), owner: e.getAttribute('data-owner-id'), endpoint: e.getAttribute('data-endpoint'), end: e.getAttribute('data-end'), lineCount: e.querySelectorAll('line').length })) }
  const expected = { entities: [{ id: 'A', label: '<i>Top\nBottom 🚀</i>' }, { id: 'B', label: 'Sink' }], attributes: [{ id: 'attr:A:code:type', text: 'string' }, { id: 'attr:A:code', text: 'code' }, { id: 'entity-empty:B', text: '(no attributes)' }], edges: [{ id: 'rel:A-B#0', from: 'A', to: 'B', label: '<b>first\nsecond</b>', cardinality1: 'one', cardinality2: 'one' }], cardinalities: [{ id: 'card:A-B#0:1', owner: 'rel:A-B#0', endpoint: 'A', end: 'start', lineCount: 2 }, { id: 'card:A-B#0:2', owner: 'rel:A-B#0', endpoint: 'B', end: 'end', lineCount: 2 }] }
  const actualOwnedTexts = entities.map((e: any) => ({ id: e.getAttribute('data-id'), texts: [...e.querySelectorAll('text')].map((t: any) => t.textContent) }))
  const expectedOwnedTexts = [{ id: 'A', texts: ['TopBottom 🚀', 'string', 'code'] }, { id: 'B', texts: ['Sink', '(no attributes)'] }]
  return { observed, actualOwnedTexts, exactOwnedDisplayTexts: eq(actualOwnedTexts, expectedOwnedTexts), exactAuthoredBindings: eq(observed, expected) }
}
const diff = (full: any, mask: any, roi: any) => {
  assert.equal(mask.width, full.width); assert.equal(mask.height, full.height)
  const a = full.pixels, b = mask.pixels; let changed = 0, darker = 0, lighter = 0, outside = 0
  for (let i = 0; i < a.length; i += 4) {
    if (![0,1,2,3].some(c => Math.abs(a[i+c] - b[i+c]) >= 4)) continue
    changed++; const p = i / 4, x = (p % full.width + .5) / 2, y = (Math.floor(p / full.width) + .5) / 2
    if (x < roi.x0 || x > roi.x1 || y < roi.y0 || y > roi.y1) outside++
    if (a[i] + a[i+1] + a[i+2] < b[i] + b[i+1] + b[i+2]) darker++; else lighter++
  }
  return { changed, darker, lighter, outside, outcome: darker <= 0 ? 'unknown-no-positive-darker-contribution' : outside ? 'failed-unconfined-difference' : 'positive-darker-confined-contribution' }
}
const scratch = fs.mkdtempSync('/tmp/pr449-richtrial-fonts-'), opened: any[] = []
try {
  const fonts = HOSTED_FONT_RESOURCES.filter(f => f.family === 'Inter' && f.style === 'normal')
  assert.equal(fonts.length, 4); assert.deepEqual(fonts.map(f => f.weight).sort(), ['400','500','600','700'])
  const fontFiles = fonts.map(f => { const bytes = fs.readFileSync(root + '/' + f.path); assert.equal(bytes.length, f.bytes); assert.equal(createHash('sha256').update(bytes).digest('hex'), f.sha256); const path = scratch + '/' + f.file; fs.writeFileSync(path, bytes); return path })
  report.fonts = fonts.map(({file,bytes,sha256,weight,style}) => ({file,bytes,sha256,weight,style})); report.fontOptions = { fontDirs: [], loadSystemFonts: false, defaultFontFamily: 'Inter' }
  // Preflight both real documents before spending a raster, including existence of the after product.
  for (const input of inputs) {
    const svg = read(input.svg), dom = new JSDOM(svg, { contentType: 'image/svg+xml' }); opened.push(dom)
    const d = dom.window.document, chosen = words.map(word => { const found = leaves(d).filter((e: any) => e.textContent === word); assert.equal(found.length, 1, 'Expected unique actual leaf: ' + word); return found[0] })
    const aliasText = chosen[0].closest('text'), captionText = chosen[2].closest('text')
    assert.equal(chosen[1].closest('text'), aliasText); assert.equal(chosen[3].closest('text'), captionText)
    const aliasEntity = aliasText.closest('g.entity'); assert.equal(aliasEntity?.getAttribute('data-id'), 'A')
    const aliasROI = box(aliasEntity.querySelector('rect[data-role="entity"]')), captionROI = box(captionText.previousElementSibling)
    const rows = (e: any) => [...e.children].filter((c: any) => c.localName === 'tspan').map((c: any) => ({ text: c.textContent, attributes: attr(c) }))
    const semanticResult = semantic(d), arm: any = { arm: input.arm, savedSVG: input.svg, savedReceipt: input.receipt, entireRawReceipt: read(input.receipt), viewport: viewport(d), semantics: semanticResult, aliasRows: rows(aliasText), captionRows: rows(captionText), leaves: chosen.map((e: any, i: number) => ({ text: words[i], actualTag: e.localName, actualAttributes: attr(e), parentAttributes: attr(e.parentElement), effectiveStyle: { italic: inherited(e, 'font-style', 'normal'), weight: inherited(e, 'font-weight', '400') }, actualMarkup: e.outerHTML })), rois: { alias: aliasROI, caption: captionROI }, wordControls: [], errors: [] }
    report.arms.push(arm)
    arm.authoredRowsExact = eq(arm.aliasRows.map((r: any) => r.text), ['Top','Bottom 🚀']) && eq(arm.captionRows.map((r: any) => r.text), ['first','second'])
    arm.formatting = { aliasItalic: arm.leaves.slice(0,2).map((l: any) => l.effectiveStyle.italic === 'italic'), captionBold: arm.leaves.slice(2).map((l: any) => ['bold','700'].includes(l.effectiveStyle.weight)) }
    assert(semanticResult.exactAuthoredBindings, 'Authored bindings changed'); assert(semanticResult.exactOwnedDisplayTexts, 'Actual owned node/attribute strings changed'); assert(arm.authoredRowsExact, 'Authored two-row content changed')
    const expectedFlags = input.arm === 'before' ? { aliasItalic: [true,false], captionBold: [true,false] } : { aliasItalic: [true,true], captionBold: [true,true] }
    arm.expectedFormattingExact = eq(arm.formatting, expectedFlags); assert(arm.expectedFormattingExact, 'Unexpected actual formatting flags')
    opened[opened.length-1] = { dom, d, chosen, arm, aliasROI, captionROI, fullXML: dom.serialize() }
  }
  const raster = (xml: string, name: string) => { if (report.offlineRasterCalls >= 11) throw Error('Raster budget exhausted'); report.offlineRasterCalls++; checkpoint(); save(name + '.svg', xml); const rendered = new Resvg(inlineFontVarForRaster(xml), { background: '#fff', fitTo: { mode: 'zoom', value: 2 }, font: { fontFiles, fontDirs: [], loadSystemFonts: false, defaultFontFamily: 'Inter' } }).render(); save(name + '.png', rendered.asPng()); return rendered }
  for (const state of opened) {
    const { dom, d, chosen, arm, aliasROI, captionROI, fullXML } = state
    try {
      const full = raster(fullXML, arm.arm + '-full'); arm.rasterDimensions = { width: full.width, height: full.height }
      for (const [i, leaf] of chosen.entries()) {
        const original = leaf.getAttribute('visibility'), roi = i < 2 ? aliasROI : captionROI
        try { leaf.setAttribute('visibility', 'hidden'); assert.deepEqual(viewport(d), arm.viewport); const mask = raster(dom.serialize(), arm.arm + '-word-' + i); arm.wordControls.push({ text: words[i], roi, ...diff(full, mask, roi) }) }
        catch (e) { arm.wordControls.push({ text: words[i], outcome: 'unknown-error', error: errorRecord(e) }) }
        finally { if (original === null) leaf.removeAttribute('visibility'); else leaf.setAttribute('visibility', original); assert.equal(dom.serialize(), fullXML, 'Visibility restore changed document'); checkpoint() }
      }
      if (arm.arm === 'after') {
        const leaf = chosen[3], original = leaf.getAttribute('font-weight')
        try { leaf.setAttribute('font-weight', '400'); assert.deepEqual(viewport(d), arm.viewport); const control = raster(dom.serialize(), 'after-second-caption-weight400'); arm.boldWeightControl = { word: words[3], forcedWeight: '400', roi: captionROI, ...diff(full, control, captionROI), scope: 'Different confined physical ink at fixed layout when the actual second caption leaf is forced to weight400; not an italic/emoji claim.' } }
        catch (e) { arm.boldWeightControl = { outcome: 'unknown-error', error: errorRecord(e) } }
        finally { if (original === null) leaf.removeAttribute('font-weight'); else leaf.setAttribute('font-weight', original); assert.equal(dom.serialize(), fullXML, 'Weight restore changed document'); checkpoint() }
      }
      arm.viewportPreserved = eq(viewport(d), arm.viewport); arm.restoredDocumentExact = dom.serialize() === fullXML
    } catch (e) { arm.errors.push(errorRecord(e)) }
    finally { checkpoint() }
  }
  report.authoredMeaningsEqualBeforeAfter = eq(report.arms[0].semantics.observed, report.arms[1].semantics.observed)
  report.allWordContributionControlsPass = report.arms.every((a: any) => a.wordControls.length === 4 && a.wordControls.every((c: any) => c.darker > 0 && c.outside === 0))
  report.secondCaptionBoldPhysicalEffect = report.arms[1].boldWeightControl?.darker > 0 && report.arms[1].boldWeightControl?.outside === 0
  report.completed = report.offlineRasterCalls === 11 && report.arms.every((a: any) => a.wordControls.length === 4 && a.errors.length === 0)
} catch (e) { report.errors.push(errorRecord(e)); report.completed = false }
finally { checkpoint(); for (const state of opened) (state.dom ?? state).window.close(); fs.rmSync(scratch, { recursive: true, force: true }) }
console.log(JSON.stringify(report))
