Retained revision d82c926cc0f6f1119a86e5079ba79fca1a2df0f9, exact cyclic19 source/options and saved final ELK SVG/entire raw receipt.

ELK:45 offline rasters (one reference +44 marker-end removals), pinned manifest Inter, system fonts disabled, zoom2 and identical per-comparison viewport. All44 have positive darker differences (20–129 pixels); outside-ROI differences zero. Every head outcome and entire raw receipt/proof remain unchanged in the corrected report.

Authored44 ordered from/to/caption occurrences and complete text multiset match. Corrected19-node ID multiset and per-node owned text n{i}→Node76-{i} match exactly. ELK DOM order differs from source order; those false source-order flags remain explicitly incidental, with observed DOM order recorded. Original bytes preserved in elk-original-order-report.json.gz.

Distinct tips:37; coincident endpoint groups:4. Membership and individual head results remain enrolled. Positive removal contribution does not establish each head's recognizability, semantic separation of coincident heads, or complete contact/clearance correctness.

ELK public paint proof remains U400000 with44 marker checks, separate from ink results. Root reports Native all44 contribution/ordered-tuple/caption owner evidence; no duplicate Native rasters here. The offline semantic correction and held-script update performed no API/layout/raster/build/test calls. Runtime and peak RSS are not measured by this report; preparation dimensions remain planning quantities only.
