// Parameter reuse of cyclic19-clear-lane-15972/independent-review.ts; saved products only.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {gunzipSync,gzipSync} from 'node:zlib'
import {createRequire} from 'node:module'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const {JSDOM}=createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
const root='/tmp/pr449-main-integration-20261029-762',week='/tmp/pr449-week-comparison-20261101',out=week+'/cyclic19-all-heads-retained-d82'
const selected=process.argv[2]
if(process.env.PR449_ROOT_GO!=='cyclic19-all-heads-offline'||!['agentic','elk','both'].includes(selected))throw new Error('Held: explicit root offline raster GO and one engine/both required; no raster started')
const inputs=JSON.parse(fs.readFileSync(week+'/cyclic-contact-node24-d82c926cc/bindings-cyclic19-node24.json','utf8'))
const source=fs.readFileSync(root+'/eval/layout-compare/fixtures/cyclic-labelled-19.mmd','utf8')
const authored=source.split('\n').filter(l=>l.includes(' -->')).map(l=>{const m=/^(n\d+) -->(?:\|([^|]*)\|)? (n\d+)$/.exec(l);if(!m)throw new Error('Unrecognized authored relation');return{from:m[1],to:m[3],label:m[2]??''}})
const names=Array.from({length:19},(_,i)=>'Node 76-'+i),labels=authored.filter(e=>e.label).map(e=>e.label)
const points=(e:any)=>e.getAttribute('points').trim().split(/\s+/).map((s:string)=>s.split(',').map(Number))
const edges=(d:any)=>[...d.querySelectorAll('polyline[data-role="edge"][data-from]')]
const geometry=(d:any)=>{const es=edges(d);let wire=0,bends=0;for(const e of es){const ps=points(e);for(let i=1;i<ps.length;i++){const [x,y]=ps[i],a=ps[i-1];assert(x===a[0]||y===a[1]);wire+=Math.abs(x-a[0])+Math.abs(y-a[1]);if(i>1){const b=ps[i-2];if((a[0]-b[0])*(y-a[1])!==(a[1]-b[1])*(x-a[0]))bends++}}}const w=+d.documentElement.getAttribute('width'),h=+d.documentElement.getAttribute('height');return{width:w,height:h,area:w*h,wire,bends}}

const scratch=fs.mkdtempSync('/tmp/pr449-cyclic19-all-head-fonts-')
try {
 const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter'),fontFiles=fonts.map(f=>{const bytes=fs.readFileSync(root+'/'+f.path);assert.equal(bytes.length,f.bytes);assert.equal(createHash('sha256').update(bytes).digest('hex'),f.sha256);const p=scratch+'/'+f.file;fs.writeFileSync(p,bytes);return p})
 for(const backend of selected==='both'?['agentic','elk']:[selected]) {
  const binding=inputs.find((b:any)=>b.backend===backend),report:any={backend,publicCalls:0,layoutCalls:0,offlineRasterCalls:0,heads:[],errors:[],sourceFixture:'eval/layout-compare/fixtures/cyclic-labelled-19.mmd',sourceOptions:binding?.options,retainedRevision:binding?.sourceHead,fonts:fonts.map(({file,bytes,sha256})=>({file,bytes,sha256})),scope:'Exact saved final SVG; single-marker-removal raster differences, zoom2, manifest Inter, no system fonts. Individual zero/darker/outside/error and duplicate seats retained. Proof status separate; no arbitrary-font/CSS or all-input claim.'}
  let dom:any
  const save=()=>fs.writeFileSync(out+'/'+backend+'.json.gz',gzipSync(JSON.stringify(report)))
  try {
   const stem=week+'/recovery-payload/cyclic-contact-d82c926cc/flowchart-'+backend
   const svg=gunzipSync(fs.readFileSync(stem+'.svg.gz')).toString(),receipt=gunzipSync(fs.readFileSync(stem+'.receipt.json.gz')).toString()
   report.sourceExactToFixture=binding.source===source;report.receipt=JSON.parse(receipt);report.entireRawReceipt=receipt
   dom=new JSDOM(svg,{contentType:'image/svg+xml'});const d=dom.window.document,es=edges(d),ns=[...d.querySelectorAll('g.node[data-role="node"]')]
   report.geometry=geometry(d);report.meaning={authoredRelations:authored.length,actualRelations:es.length,nodes:ns.length,nodeIDsExact:JSON.stringify(ns.map((n:any)=>n.getAttribute('data-id')))===JSON.stringify(Array.from({length:19},(_,i)=>'n'+i)),nodeLiteralsExact:JSON.stringify(ns.map((n:any)=>n.textContent.trim().replace(/\s+/g,' ')))===JSON.stringify(names),orderedRelationsExact:JSON.stringify(es.map((e:any)=>({from:e.getAttribute('data-from'),to:e.getAttribute('data-to'),label:e.getAttribute('data-label')??''})))===JSON.stringify(authored),svgTextLiteralsExact:JSON.stringify([...d.querySelectorAll('text')].map((e:any)=>e.textContent.trim()).sort())===JSON.stringify([...names,...labels].sort())}
   report.meaning.incidentalNodeIDsInSourceOrderExact=report.meaning.nodeIDsExact;report.meaning.incidentalNodeLiteralsInSourceOrderExact=report.meaning.nodeLiteralsExact;delete report.meaning.nodeIDsExact;delete report.meaning.nodeLiteralsExact;report.meaning.incidentalOrderScope='Observed DOM order, not author-order contract';report.meaning.nodeDomOrderObserved=ns.map((n:any)=>n.getAttribute('data-id'));report.meaning.nodeIDMultisetExact=JSON.stringify([...report.meaning.nodeDomOrderObserved].sort())===JSON.stringify(Array.from({length:19},(_,i)=>'n'+i).sort());report.meaning.nodeOwnedTextBindingsObserved=ns.map((n:any)=>({id:n.getAttribute('data-id'),text:n.textContent.trim().replace(/\s+/g,' ')}));report.meaning.perNodeOwnedTextBindingExact=ns.length===19&&new Set(report.meaning.nodeDomOrderObserved).size===19&&report.meaning.nodeOwnedTextBindingsObserved.every((n:any)=>/^n(?:[0-9]|1[0-8])$/.test(n.id)&&n.text==='Node 76-'+Number(n.id.slice(1)));
   const seats=new Map<string,number[]>();es.forEach((e:any,i:number)=>{const p=points(e).at(-1);const k=p?.join(',')??'missing';seats.set(k,[...(seats.get(k)??[]),i])});report.duplicateEndpointSeats=[...seats].filter(([k,v])=>v.length>1).map(([seat,indices])=>({seat,indices}));report.distinctEndpointSeats=seats.size
   const marker=d.getElementById('cycle-check-arrowhead'),poly=marker?.querySelector('polygon')
   if(!marker||marker.getAttribute('orient')!=='auto'||marker.getAttribute('markerUnits')!==null||poly?.getAttribute('points')!=='0 0, 8 2.5, 0 5'||+marker.getAttribute('refX')!==8||+marker.getAttribute('refY')!==2.5||+poly?.getAttribute('stroke-width')!==.75)throw new Error('Actual marker resource outside existing audit transform domain')
   const zoom=2,raster=(input:string)=>{report.offlineRasterCalls++;return new Resvg(inlineFontVarForRaster(input),{background:'#fff',fitTo:{mode:'zoom',value:zoom},font:{fontFiles,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render()}
   const full=raster(svg),fp=full.pixels;report.rasterDimensions={width:full.width,height:full.height,zoom};if(process.env.PR449_SAVE_AUDIT_FULL==='1')fs.writeFileSync(out+'/'+backend+'-full.png.gz',gzipSync(full.asPng()))
   const tags=svg.match(/<polyline\b[^>]*\/>/g)!.filter((tag:string)=>tag.includes('data-role="edge"'))
   for(const [i,e]of es.entries()) {
    try {
     const ps=points(e),p=ps.at(-1),a=ps.at(-2),length=Math.hypot(p[0]-a[0],p[1]-a[1]);if(!(length>0))throw new Error('Degenerate terminal tangent')
     const ux=(p[0]-a[0])/length,uy=(p[1]-a[1])/length,scale=+e.getAttribute('stroke-width'),half=.375
     const cs=[[-8-half,-2.5-half],[half,-2.5-half],[-8-half,2.5+half],[half,2.5+half]].map(([x,y])=>[p[0]+scale*(x*ux-y*uy),p[1]+scale*(x*uy+y*ux)])
     const box={x0:Math.min(...cs.map(c=>c[0]))-1,y0:Math.min(...cs.map(c=>c[1]))-1,x1:Math.max(...cs.map(c=>c[0]))+1,y1:Math.max(...cs.map(c=>c[1]))+1}
     const tag=tags[i];if(!tag)throw new Error('Missing exact carrier markup');const masked=svg.replace(tag,tag.replace(/ marker-end="[^"]+"/,''));if(masked===svg)throw new Error('Marker removal did not change actual markup')
     const mask=raster(masked),mp=mask.pixels;if(mask.width!==full.width||mask.height!==full.height)throw new Error('Raster dimension mismatch')
     let changedPixels=0,darker=0,lighter=0,outside=0
     for(let k=0;k<fp.length;k+=4){if(![0,1,2,3].some(c=>Math.abs(fp[k+c]-mp[k+c])>=4))continue;changedPixels++;const n=k/4,x=(n%full.width+.5)/zoom,y=(Math.floor(n/full.width)+.5)/zoom;if(x<box.x0||x>box.x1||y<box.y0||y>box.y1)outside++;if(fp[k]+fp[k+1]+fp[k+2]<mp[k]+mp[k+1]+mp[k+2])darker++;else lighter++}
     report.heads.push({edgeIndex:i,id:e.getAttribute('data-id'),from:e.getAttribute('data-from'),to:e.getAttribute('data-to'),caption:e.getAttribute('data-label')??'',points:ps,endpoint:p,normal:[ux,uy],box,changedPixels,darker,lighter,outside,outcome:darker===0?'no-positive-darker-difference':outside?'difference-outside-ROI':'positive-darker-inside-ROI'})
    }catch(error:any){report.heads.push({edgeIndex:i,id:e.getAttribute('data-id'),outcome:'audit-error',error:{name:error.name,message:error.message,stack:error.stack}})}
    save()
   }
   report.completed=report.heads.length===es.length;report.all44Recorded=es.length===44&&report.heads.length===44
  }catch(error:any){report.errors.push({name:error.name,message:error.message,stack:error.stack});report.completed=false}
  finally{save();dom?.window.close()}
 }
}finally{fs.rmSync(scratch,{recursive:true,force:true})}
