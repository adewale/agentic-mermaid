import { writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import * as marks from '/tmp/pr449-main-integration-20261029-762/src/scene/marks.ts'
import { preparePixelText } from '/tmp/pr449-main-integration-20261029-762/src/shared/prepared-text.ts'
import { admitSceneDocument } from '/tmp/pr449-main-integration-20261029-762/src/scene/external-data-snapshot.ts'
import { createSceneWriteCapture } from '/tmp/pr449-main-integration-20261029-762/src/scene/serialization.ts'
import { inspectScenePaintGeometry } from '/tmp/pr449-main-integration-20261029-762/src/scene/inspection.ts'
import { certifyScenePaint } from '/tmp/pr449-main-integration-20261029-762/src/scene/paint-certification.ts'
import { MAX_OCCLUSION_OPERATIONS } from '/tmp/pr449-main-integration-20261029-762/src/scene/native-paint-emission.ts'
import { DefaultBackend } from '/tmp/pr449-main-integration-20261029-762/src/scene/backend.ts'

if (process.argv[2] !== 'GO') throw Error('HOLD: root GO required for the one Scene bounds-custody probe')
const dir = '/tmp/pr449-week-comparison-20261101/scene-inspection-bounds-custody-30844276e'
const save = (name, value) => writeFileSync(`${dir}/${name}.gz`, gzipSync(typeof value === 'string' ? value : JSON.stringify(value, null, 2)))
const header = { family: 'flowchart' as const, width: 100, height: 80, colors: { bg: '#fff', fg: '#111' }, transparent: false }
const context = { positioned: { width: 100, height: 80 }, colors: header.colors, resolved: { renderOptions: {} } }
const producer = (factory, _context) => ({ ...header, parts: [
  factory.documentOpen({ id: 'root', width: 100, height: 80, colors: header.colors, transparent: false, font: 'Inter', hasMonoFont: false }, '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="80">'),
  factory.text({ id: 'text', role: 'label', text: 'Lost', block: preparePixelText('Lost', { fontSize: 12, fontWeight: 400 }), x: 30, y: 40, fontSize: 12, anchor: 'start', paint: { fill: '#111' } }),
  factory.shape({ id: 'cover', role: 'node', geometry: { kind: 'rect', x: 10, y: 10, width: 70, height: 60 }, paint: { fill: '#fff' } }),
  factory.documentClose(),
] })

// Same Scene arm as the existing drawPaintControl: one admission and write
// receipt, actual DefaultBackend output, inspection, then final certification.
const raw = producer(marks, context)
const capture = createSceneWriteCapture(MAX_OCCLUSION_OPERATIONS)
const admitted = admitSceneDocument(raw, 'internal', true, capture.observe)
const receipt = capture.finish(admitted)
const svg = DefaultBackend.render(admitted, { seed: 0 })
const inspection = inspectScenePaintGeometry(admitted, receipt)
const baseline = { svg, proof: certifyScenePaint(admitted, undefined, { sceneWriteReceipt: receipt }),
  textBounds: inspection.primitives.filter(p => p.kind === 'text').map(p => ({ id: p.id, bounds: p.bounds })) }
save('baseline.svg', svg)
save('baseline.proof.json', baseline.proof)
const target = baseline.textBounds.find(item => item.id === 'text')?.bounds
if (!target || ![target.x0, target.x1, target.y0, target.y1].every(Number.isFinite)) throw Error('Expected the fixed baseline text bounds')

const freezeDescriptor = Object.getOwnPropertyDescriptor(Object, 'freeze')!
const freeze = freezeDescriptor.value, own = Object.getOwnPropertyDescriptor, isFrozen = Object.isFrozen, define = Object.defineProperty
let hookCount = 0, hookedProof, hookError
const observations = []
try {
  define(Object, 'freeze', { ...freezeDescriptor, value(value) {
    if (value && typeof value === 'object' && !isFrozen(value)) {
      const x0 = own(value, 'x0')?.value, x1 = own(value, 'x1')?.value, y0 = own(value, 'y0')?.value, y1 = own(value, 'y1')?.value
      if (x0 === target.x0 && x1 === target.x1 && y0 === target.y0 && y1 === target.y1) {
        hookCount++
        observations.push({ before: { x0, x1, y0, y1 }, after: { x0: 85, x1: 90, y0: 1, y1: 8 }, stack: new Error('Fresh text bounds observed by freeze').stack })
        value.x0 = 85; value.x1 = 90; value.y0 = 1; value.y1 = 8
      }
    }
    return freeze(value)
  } })
  hookedProof = certifyScenePaint(admitted, undefined, { sceneWriteReceipt: receipt })
} catch (error) {
  hookError = { name: error.name, message: error.message, stack: error.stack }
} finally { define(Object, 'freeze', freezeDescriptor) }
const hookedSvg = DefaultBackend.render(admitted, { seed: 0 })
const report = {
  sceneAdmissions: 1, sceneCertifications: 2, nativeDraws: 0, publicMermaidCalls: 0, offlineRasters: 0,
  sameAdmittedSceneAndReceipt: true, hookCount, observations, wholeSVGExact: svg === hookedSvg,
  restoredFreeze: Object.freeze === freeze, baseline, hooked: { svg: hookedSvg, proof: hookedProof, error: hookError },
  confirmedFalsePass: baseline.proof.status === 'failed' && hookedProof?.status === 'passed' && svg === hookedSvg && hookCount > 0,
  scope: 'One fixed Lost text covered by the later opaque white rectangle. Ambient freeze hook is installed only for the second certification of the SAME admitted Scene and receipt. The two actual SVG serializations occur outside the hook. No raster or universal ink claim; retain non-P/error/no-hook outcomes unchanged.',
}
save('hooked.svg', hookedSvg)
save('hooked.proof.json', { proof: hookedProof, error: hookError })
save('RESULT.json', report)
console.log(JSON.stringify({ ...report, baseline: { proof: baseline.proof, textBounds: baseline.textBounds }, hooked: { proof: hookedProof, error: hookError } }))
