Current unprofiled follow-up to Scene inspector sealing, commit3c567e1e5d0b4d50f61a00f1735edd226926820e. Exactly3 current-only ELK cache0 calls, no overlays or baseline calls; all returned passed. Import1121.338ms; peak RSS265632KiB. This is a soundness qualification, not a performance win.

| Phase | Consumed elapsed ms | Request | Layout (nested ELK) | Scene | Paint | Backend | Security | post-GC RSS / heapUsed MiB |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| cold | 2281.313 | 74.840 | 1786.539 (1344.390) | 227.114 | 79.667 | 45.936 | 28.866 | 220.016 / 41.013 |
| repeat | 855.490 | 4.401 | 505.830 (464.425) | 190.333 | 72.115 | 7.461 | 43.250 | 242.371 / 42.069 |
| edit | 316.672 | 4.609 | 146.500 (120.690) | 84.417 | 39.301 | 4.101 | 23.470 | 249.418 / 42.794 |

Drawing stages0.357/0.044/0.047ms are retained separately in JSON. Nested ELK is contained in layout; no double summing. No attribution of the old spike is made. Cold2281.313ms and repeat855.490ms remain adverse observations, with substantially different conditions from the profiled before run. No timing ratio or fast claim.

Exact binding: source1199B/edit1202B/options match the profiled308 run and retained52a current fixture. All3 whole SVGs and ENTIRE raw receipt strings match the profiled products exactly. Own cold/repeat SVG+receipt are exact. CPU profiling, named phase wrappers and additional phase markers are absent here; standard stage/performance observers remain in both runs. Output identity does not make timings comparable.

Historical52a raw-product binding per phase:
cold: whole SVG=True, ENTIRE receipt=True.
repeat: whole SVG=True, ENTIRE receipt=True.
edit: whole SVG=True, ENTIRE receipt=True.

Proof operations cold/repeat/edit90857/90857/91361. Actual positioned-layout and ELK-layout cache events bypass every phase because cache is disabled. Native drawing bypass/fallback reason owned-scene-geometry; paint-certification miss/detail scene every phase. No cache-hit or skipped-proof claim.

Pre-GC RSS bytes242339840/264613888/271929344; pre-GC heapUsed43028241/48556795/50105007. Post-GC RSS230703104/254144512/261533696; heapUsed43004875/44112964/44873181. Three products plus receipt strings/stage/event arrays stay rooted; these values do not establish lower allocation or peak-memory improvement. The original profiled tail absence is not a performance-fix claim. No new API/render/profile/test/build calls in this postread.
