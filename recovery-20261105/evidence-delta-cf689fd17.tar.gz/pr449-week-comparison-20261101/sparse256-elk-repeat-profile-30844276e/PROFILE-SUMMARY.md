One current-only profile, 3 returned P calls. Consumed cold/repeat/edit1532.839/552.282/501.507ms; repeat paint83.636ms. The old18,627ms repeat /17,742.523ms paint tail was NOT reproduced. No causal speed ratio or rewrite recommendation.

Profile span3381.982ms; 1927 samples, total delta-weight3381.270ms. Global largest delta171.218ms is charged to anonymous at :0, phase=None. These are weighted observation intervals, not measured exclusive CPU durations. Named ancestry, not wallclock slicing, selects phases.

sparseCold: 940 samples /1530.057 weighted ms; repo source SELF263 samples /381.296 weighted ms.

| Exclusive SELF source function | File:line | Samples | Delta-weight ms | Largest single sample ms |
|---|---|---:|---:|---:|
| visit | scene/scene-data-snapshot.ts:98 | 22 | 31.608 | 3.867 |
| validateNode | scene/scene-validation-core.ts:724 | 15 | 22.423 | 3.322 |
| certifyNativePaint | scene/paint-certification.ts:1432 | 10 | 16.274 | 4.614 |
| verifyDocumentEnvelope | output-security.ts:324 | 7 | 12.134 | 2.903 |
| preparePixelText | shared/prepared-text.ts:314 | 5 | 9.109 | 3.893 |

Largest phase/combined interval82.878ms at <anonymous> (file:///tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:199).

sparseRepeat: 354 samples /550.799 weighted ms; repo source SELF133 samples /224.217 weighted ms.

| Exclusive SELF source function | File:line | Samples | Delta-weight ms | Largest single sample ms |
|---|---|---:|---:|---:|
| visit | scene/scene-data-snapshot.ts:98 | 12 | 25.519 | 4.640 |
| pathBounds | scene/bounds.ts:48 | 13 | 23.401 | 7.159 |
| solidInteriors | scene/paint-certification.ts:139 | 5 | 9.460 | 3.711 |
| scanStartTags | svg-structure.ts:120 | 6 | 7.806 | 1.759 |
| read | scene/bounds.ts:63 | 3 | 7.361 | 3.402 |

Largest phase/combined interval7.159ms at pathBounds (file:///tmp/pr449-main-integration-20261029-762/src/scene/bounds.ts:48).

sparseEdit: 352 samples /501.323 weighted ms; repo source SELF119 samples /177.177 weighted ms.

| Exclusive SELF source function | File:line | Samples | Delta-weight ms | Largest single sample ms |
|---|---|---:|---:|---:|
| visit | scene/scene-data-snapshot.ts:98 | 12 | 15.584 | 1.872 |
| validateNode | scene/scene-validation-core.ts:724 | 10 | 14.139 | 2.140 |
| solidInteriors | scene/paint-certification.ts:139 | 5 | 10.015 | 4.910 |
| preparePixelText | shared/prepared-text.ts:314 | 4 | 6.762 | 2.794 |
| boundedUtf8ByteLength | shared/utf8.ts:4 | 3 | 5.897 | 3.539 |

Largest phase/combined interval5.639ms at readXmlDataEnd (file:///tmp/pr449-main-integration-20261029-762/src/output-security.ts:216).

combined: 1646 samples /2582.179 weighted ms; repo source SELF515 samples /782.690 weighted ms.

| Exclusive SELF source function | File:line | Samples | Delta-weight ms | Largest single sample ms |
|---|---|---:|---:|---:|
| visit | scene/scene-data-snapshot.ts:98 | 46 | 72.711 | 4.640 |
| validateNode | scene/scene-validation-core.ts:724 | 26 | 37.698 | 3.322 |
| pathBounds | scene/bounds.ts:48 | 18 | 33.641 | 7.159 |
| solidInteriors | scene/paint-certification.ts:139 | 12 | 22.137 | 4.910 |
| verifyDocumentEnvelope | output-security.ts:324 | 14 | 21.062 | 2.903 |

Largest phase/combined interval82.878ms at <anonymous> (file:///tmp/pr449-main-integration-20261029-762/node_modules/elkjs/lib/elk.bundled.js:199).

Clock check: profile microsecond timestamps align to epoch wall markers; performance.timeOrigin+performance.now minus Date.now ranges[0.01025390625, 0.953125]. Named-frame sample endpoints outside phase-start/consume-end markers (2ms tolerance): sparseCold=0, sparseRepeat=0, sparseEdit=0.

Recorded stages use ms (not durationMs); nested ELK stage is included in layout and must not be added twice. Cold layout1052.064ms includes ELK954.830ms; repeat layout286.996 includes ELK248.022; edit layout254.729 includes ELK222.275. Scene230.758/117.658/134.491ms; paint95.286/83.636/46.933ms. Consumption and sample-window data are retained in JSON.

Original outputs array keeps all3 products plus row receipts/events/stages; GC before first and after each phase does not release these retained roots. Phase wrappers stop before artifact writes and forced GC; whole-process profile includes them. Sampling/native/anonymous delays and GC cannot be separated into causal CPU cost from these data. Large deltas can dominate self rankings; no reliable optimization or expected speedup established. Whole cold/repeat SVG and entire raw receipt are exact. No new runtime calls/profiles/production changes in this analysis.

Largest global171.218ms gap lies entirely during imports, outside named phases; it cannot be assigned to paint. Largest intervals contribute5.42% of cold weighted window,1.30% of repeat,1.12% of edit. All top source SELF functions have at most7.159ms individual sample weights; exact weights without each function's largest sample are retained in JSON.

Largest visit samples in each phase follow admitSceneDocumentWith→admitFamilyScene→retainedPositionedScene→renderPositionedWithTextMeasurement. This establishes Scene-admission ancestry, not repeated-work counts or a safe skipped-check opportunity.
