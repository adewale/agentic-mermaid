// After-only paired-control adaptation of the stock fractional-circle owner and
// requirement-contains-fan-proposal-c0bba6102/review.ts. No rendering API calls.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { gzipSync, gunzipSync } from 'node:zlib'
import { createRequire } from 'node:module'
import { Resvg } from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import { HOSTED_FONT_RESOURCES } from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import { inlineFontVarForRaster } from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import { decodePng } from '/tmp/pr449-main-integration-20261029-762/src/__tests__/helpers/png-pixels.ts'
const { JSDOM } = createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
const root = '/tmp/pr449-main-integration-20261029-762', out = '/tmp/pr449-week-comparison-20261101/wide-circle-absorption-5417e088c'
const tag = process.argv[2] ?? 'after'
const supplied = process.argv.slice(3)
const paths = supplied.length ? supplied : ['after-agentic/actual.svg.gz', 'after-elk/actual.svg.gz']
assert.equal(paths.length, 2, 'Exactly the two saved backend products; 4 offline rasters maximum')
const target = `${out}/${tag}-independent-review.json.gz`
assert(!fs.existsSync(target), `Refusing to overwrite ${target}`)
const attrs = (element: Element) => Object.fromEntries([...element.attributes].map(attribute => [attribute.name, attribute.value]))
const read = (path: string) => path.endsWith('.gz') ? gunzipSync(fs.readFileSync(path)).toString() : fs.readFileSync(path, 'utf8')
const save = (name: string, data: string | Uint8Array) => fs.writeFileSync(`${out}/${tag}-${name}.gz`, gzipSync(data))
const scratch = fs.mkdtempSync('/tmp/pr449-wide-circle-fonts-')
let rasterCalls = 0
try {
  const fonts = HOSTED_FONT_RESOURCES.filter(font => font.family === 'Inter')
  const fontFiles = fonts.map(font => {
    const bytes = fs.readFileSync(`${root}/${font.path}`)
    assert.equal(bytes.length, font.bytes)
    assert.equal(createHash('sha256').update(bytes).digest('hex'), font.sha256)
    const path = `${scratch}/${font.file}`
    fs.writeFileSync(path, bytes)
    return path
  })
  const zoom = 3, results = []
  const render = (svg: string, name: string) => {
    rasterCalls++
    const image = new Resvg(inlineFontVarForRaster(svg), { background: '#ffffff', fitTo: { mode: 'zoom', value: zoom }, font: { fontFiles, fontDirs: [], loadSystemFonts: false, defaultFontFamily: 'Inter' } }).render()
    save(`${name}.svg`, svg)
    save(`${name}.png`, image.asPng())
    return { width: image.width, height: image.height, pixels: image.pixels }
  }
  for (const [index, relative] of paths.entries()) {
    const path = relative.startsWith('/') ? relative : `${out}/${relative}`
    const name = ['agentic', 'elk'][index], raw = read(path)
    const dom = new JSDOM(raw, { contentType: 'image/svg+xml' }), document = dom.window.document as Document
    try {
      const nodes = [...document.querySelectorAll('g.node')]
      assert.deepEqual(nodes.map(node => node.getAttribute('data-id')), ['A', 'B'])
      assert.deepEqual(nodes.map(node => [...node.querySelectorAll('text')].map(text => text.textContent)), [['A'], ['B']])
      const edges = [...document.querySelectorAll('[data-role="edge"][data-from]')]
      assert.equal(edges.length, 1)
      const edge = edges[0], carrier = attrs(edge)
      assert.equal(edge.localName, 'polyline')
      assert.equal(carrier['data-id'], 'edge:A->B#0'); assert.equal(carrier['data-from'], 'A'); assert.equal(carrier['data-to'], 'B')
      assert.equal(carrier['data-direction'], 'forward'); assert.equal(carrier['data-marker-end'], 'circle')
      assert(/^\s*(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/.test(carrier['stroke-width']))
      assert.equal(Number.parseFloat(carrier['stroke-width']), 10); assert(!edge.hasAttribute('marker-start')); assert(!edge.hasAttribute('style'))
      const reference = carrier['marker-end'], resourceId = /^url\(#([A-Za-z_][\w:.-]*)\)$/.exec(reference)?.[1]
      assert(resourceId)
      const resourceMatches = [...document.querySelectorAll('marker')].filter(marker => marker.id === resourceId)
      assert.equal(resourceMatches.length, 1)
      const resource = resourceMatches[0], marker = attrs(resource)
      assert.deepEqual([+marker.markerWidth, +marker.markerHeight, +marker.refX, +marker.refY], [8, 8, 7.5, 4])
      assert.equal(marker.orient, 'auto'); assert.equal(marker.markerUnits, 'userSpaceOnUse'); assert(!resource.hasAttribute('viewBox'))
      assert.equal(resource.children.length, 1); assert.equal(resource.children[0].localName, 'circle')
      const circle = attrs(resource.children[0])
      assert(/^\s*(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/.test(circle['stroke-width']))
      assert.deepEqual([+circle.cx, +circle.cy, +circle.r, Number.parseFloat(circle['stroke-width'])], [4, 4, 3.25, 1]); assert.equal(circle.fill, 'none')
      assert(!document.querySelector('[transform]'))
      const points = carrier.points.trim().split(/\s+/).map(point => point.split(',').map(Number))
      assert.equal(points.length, 2); assert(points.every(point => point.length === 2 && point.every(Number.isFinite)))
      assert.equal(points[0][1], points[1][1]); assert(points[1][0] > points[0][0])
      const bodies = [...document.querySelectorAll('[data-id="node-shape:B"]')]
      assert.equal(bodies.length, 1); assert.equal(bodies[0].localName, 'rect'); assert(!bodies[0].hasAttribute('style'))
      const body = attrs(bodies[0])
      const markerToken = ` marker-end="${reference}"`
      assert.equal(raw.split(markerToken).length, 2)
      const carrierMatches = [...raw.matchAll(/<polyline\b[^>]*\/>/g)].filter(match => match[0].includes(markerToken))
      const bodyMatches = [...raw.matchAll(/<rect\b[^>]*\/>/g)].filter(match => match[0].includes(' data-id="node-shape:B"'))
      assert.equal(carrierMatches.length, 1); assert.equal(bodyMatches.length, 1)
      const carrierTag = carrierMatches[0][0], bodyTag = bodyMatches[0][0]
      assert.equal(raw.split(carrierTag).length, 2); assert.equal(raw.split(bodyTag).length, 2)
      const center = [points[1][0] + +circle.cx - +marker.refX, points[1][1] + +circle.cy - +marker.refY]
      const radius = +circle.r + Number.parseFloat(circle['stroke-width']) / 2
      const roi = { x0: center[0] - radius - 2, y0: center[1] - radius - 2, x1: center[0] + radius + 2, y1: center[1] + radius + 2 }
      const beforePath = `${out}/before-${name}/actual.svg.gz`, beforeSvg = read(beforePath)
      const beforePixelsPath = `${out}/before-${name}-normal-with-marker.png.gz`
      const beforePixels = decodePng(gunzipSync(fs.readFileSync(beforePixelsPath)))
      const dash = carrier['stroke-dasharray']
      const dashToken = dash === undefined ? '' : ` stroke-dasharray="${dash}"`
      const onlyDashAttributeInserted = dashToken !== '' && raw.split(dashToken).length === 2 && raw.replace(dashToken, '') === beforeSvg
      const controls = []
      for (const control of ['normal'] as const) {
        const svg = raw
        // No paint suppression: compare the actual served product with only
        // its selected marker reference removed. Invalid stroke:none controls
        // remain retained before; none are replayed here.
        assert.equal(svg.split(markerToken).length, 2)
        const absentSvg = svg.replace(markerToken, '')
        const actual = render(svg, `${name}-${control}-with-marker`), absent = render(absentSvg, `${name}-${control}-without-marker`)
        assert.equal(actual.width, absent.width); assert.equal(actual.height, absent.height)
        assert.equal(actual.width, beforePixels.width); assert.equal(actual.height, beforePixels.height)
        let changedPaint = 0, darkenedPaint = 0, lightenedPaint = 0, paintOutsideTerminalRoi = 0
        for (let y = 0; y < actual.height; y++) for (let x = 0; x < actual.width; x++) {
          const offset = (y * actual.width + x) * 4, before = beforePixels.rgba
          if (Math.abs(actual.pixels[offset] - before[offset]) < 4 && Math.abs(actual.pixels[offset + 1] - before[offset + 1]) < 4 && Math.abs(actual.pixels[offset + 2] - before[offset + 2]) < 4 && Math.abs(actual.pixels[offset + 3] - before[offset + 3]) < 4) continue
          changedPaint++
          const wx = (x + .5) / zoom, wy = (y + .5) / zoom
          if (wx < roi.x0 || wx > roi.x1 || wy < roi.y0 || wy > roi.y1) paintOutsideTerminalRoi++
          if (actual.pixels[offset] + actual.pixels[offset + 1] + actual.pixels[offset + 2] < before[offset] + before[offset + 1] + before[offset + 2]) darkenedPaint++
          else lightenedPaint++
        }
        let changed = 0, darker = 0, lighter = 0, outsideRoi = 0
        for (let y = 0; y < actual.height; y++) for (let x = 0; x < actual.width; x++) {
          const offset = (y * actual.width + x) * 4
          if (Math.abs(actual.pixels[offset] - absent.pixels[offset]) < 4 && Math.abs(actual.pixels[offset + 1] - absent.pixels[offset + 1]) < 4 && Math.abs(actual.pixels[offset + 2] - absent.pixels[offset + 2]) < 4 && Math.abs(actual.pixels[offset + 3] - absent.pixels[offset + 3]) < 4) continue
          changed++
          const wx = (x + .5) / zoom, wy = (y + .5) / zoom
          if (wx < roi.x0 || wx > roi.x1 || wy < roi.y0 || wy > roi.y1) outsideRoi++
          if (actual.pixels[offset] + actual.pixels[offset + 1] + actual.pixels[offset + 2] < absent.pixels[offset] + absent.pixels[offset + 1] + absent.pixels[offset + 2]) darker++
          else lighter++
        }
        controls.push({ control, changed, darker, lighter, outsideRoi, rgbaBytesEqual: actual.pixels.equals(absent.pixels), rasterSize: [actual.width, actual.height], roi, actualPaintDeltaVsBefore: { changedPaint, darkenedPaint, lightenedPaint, paintOutsideTerminalRoi, beforePixelsPath } })
      }
      const receiptPath = path.replace(/actual\.svg(?:\.gz)?$/, 'actual.receipt.json.gz')
      const resultPath = path.replace(/actual\.svg(?:\.gz)?$/, 'RESULT.json.gz')
      const packet = fs.existsSync(resultPath) ? JSON.parse(read(resultPath)) : undefined
      const receipt = fs.existsSync(receiptPath) ? JSON.parse(read(receiptPath)) : undefined
      results.push({ name, path, beforePath, onlyDashAttributeInserted, svgBytes: Buffer.byteLength(raw), source: packet?.source, options: packet?.options, viewport: attrs(document.documentElement), carrier, marker, circle, body, anchor: points[1], center, radius, proof: receipt?.layoutCertification, controls })
    } finally { dom.window.close() }
  }
  assert.equal(rasterCalls, 4)
  const report = { publicCalls: 0, offlineRasterCalls: rasterCalls, retainedBeforeControls: `${out}/before-independent-review.json.gz`, retainedDiagnosticControls: `${out}/stroke-contrast-independent-review.json.gz`, results, fonts: fonts.map(font => ({ file: font.file, bytes: font.bytes, sha256: font.sha256 })), scope: 'Actual final SVG paired only with its single marker-end reference removed: 4 offline rasters total. Retained before PNGs are decoded with the existing pixel helper, never rerasterized, to locate actual paint changes separately from marker-removal contribution. Whole before/after SVG comparison permits only insertion of the served carrier dash attribute; false is retained adverse, not normalized. Original invalid stroke:none and completed diagnostic controls are not replayed. Geometry/resource/ref/anchors/identities/text/width10px remain required. No area/wire, certification, universal-font or recognizability claim from pixels alone.' }
  fs.writeFileSync(target, gzipSync(JSON.stringify(report, null, 2)))
  console.log(JSON.stringify(report))
} finally { fs.rmSync(scratch, { recursive: true, force: true }) }
