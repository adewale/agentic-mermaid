## Hollow circles on wide straight shafts — 5 November

c7490d9b45dbf78ee77b165f3677581f971f9c6d fixes a shared actual-ink loss: black10px
`A --o B` formerly delivered with zero circle contribution in BOTHbackends. A gap
under the existing hollow ring restores230owned pixels each, preserving10pxwidth,
resource/ref/anchor, cards/text, route and248×116.9canvas. Only536pixels lighten,
all in the terminal region; markup differs only by actual dash paint and3scoped
class renamings. Proof remainsU149226→U148921 with the same B-occlusion issue/caps;
strict refusal stays honest. This is visible delivery, not proof/readiness or an
ELK-relative quality win. Long straight solid known-width carriers only; authored
dash/offset, dotted/animated/thick, curved, short and unknown-width cases unchanged.

Eight actual-ink owners RED→GREEN cover Native/Scene, both backends and start/end/
both-circle contacts. First endpoint run had3inkRED+1unsupported `o--` parse failure,
not4inkRED: source and failure retained. Supported `o-->` with explicit end-arrow
ownership separately reproduces the start-circle RED against old producer, then
passes; original candidate restored byte-exactly. No parser change. `stroke:none`
controls dropped markers too and are inconclusive; opacity0 and same-carrier dash
controls each exposed230pixels with B intact. First producer candidate confused
conservative10.5px proof support with actual7.5px diameter and failed all8; retained,
then replaced with canonical geometry plus smooth stroke support (7.25px setback).
No bound/cap relaxation, extra carrier, opaque fill, cache or new qualification gate.

Eight-file milestone893P/knownSparse32F,188.36s/1142588KiB. Test table typing fixes
retained; final types56.46s/2121896KiB, lintP and affected start ownerP. Twelve current
fully consumed calls allU; repeat wholeSVG/ENTIREreceipt exact, real B-text edits.
Cold/repeat/edit ms cache0 AM175/24/18 vsELK514/42/33; cache1 AM171/11/25 vsELK551/25/56.
N1/no ratios or performance-win claim; slower cache-on edit observations retained.
PeakRSS AM101604/100348KiB vsELK136980/134612; phase heaps retain3products/caches and
separately timed compression. Earlier onecall reproduction timers included artifact
I/O/GC and are excluded from performance comparisons. SVG raw4855 (+28),gzip1173/
Br1010B, equal backends. TwoNode24 and two compiled products match wholeSVG/ENTIRE
receipts exactly; one RAM build+compiled run19.36s/303980KiB, scratch removed.
Flowchart closure AM26requests/raw1123221/gzip368344/Br312317B vsELK24/2397795/738474/
583747; adds431gzip/297Br to BOTH, requests unchanged. Initial3/raw15408/gzip5853/
Br5235 (+1/+1). Evidence: week wide-circle-absorption-5417e088c,
wide-circle-absorption-cost-5417e088c, wide-circle-node24-c7490d9b4 and
recovery-payload/wide-circle-c7490d9b4. Failed scripts/candidates and original owners
remain retained; no unchanged comparison is counted as new progress.

## Remaining losses and next cause

Retained comparisons still show sparse256area+115.35%, forestwire+16.89% (area−6.43%),
and Requirement-cycle TB/BTarea+9.53% vsELK (LR/RL−1.44%). ER256-chain refusal affects
both backends; Sparse32 proof still exhausts400k. Those are separate from quality.
Moving profile tails/historical ELK timeout remain unexplained; stopped probes stay
stopped. Original2dad/Trident/peers unavailable; replacement24 sealed.
Next demonstrated first-stage deficit: standalone start-circle `o--` is read as an
unfinished text-arrow label and absorbs the following linkStyle line with `<br>`.
Its exact failed source is retained. Reproduce at the lexer/parser owner and repair
that meaning boundary before extending wide-circle claims to unsupported syntax.
