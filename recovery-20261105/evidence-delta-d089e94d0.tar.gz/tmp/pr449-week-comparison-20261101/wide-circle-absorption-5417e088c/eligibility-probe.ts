import{readFileSync,writeFileSync}from'node:fs'
const root='/tmp/pr449-main-integration-20261029-762'
const{parseMermaid}=await import(root+'/src/parser.ts'),{layoutGraphSync}=await import(root+'/src/layout-engine.ts'),{graphEdgeDashArray,flowchartMarkerResources}=await import(root+'/src/graph-connectors.ts'),{paintedStrokeExtent,markerTerminalDepth}=await import(root+'/src/scene/bounds.ts')
const source=readFileSync(new URL('source.mmd',import.meta.url),'utf8'), parsed=parseMermaid(source), placed=layoutGraphSync(parsed,{graphLayout:{backend:'agentic',fallback:'none'}})
const m=flowchartMarkerResources(new Set(),new Set([undefined]),true,true).find(m=>m.id==='circlehead-fixed')!
const row={parsedEdges:parsed.edges,placedEdges:placed.edges,dashes:placed.edges.map(e=>graphEdgeDashArray(e)),half:paintedStrokeExtent({stroke:'black',strokeWidth:'10px'},false),support:[markerTerminalDepth(m,'start'),markerTerminalDepth(m,'end')]}
writeFileSync(new URL('eligibility-probe.json',import.meta.url),JSON.stringify(row,null,2));console.log(JSON.stringify(row))
