from pathlib import Path
import json
W=Path('/tmp/pr449-week-comparison-20261101');R=W/'wide-circle-absorption-5417e088c';O=W/'wide-circle-absorption-cost-5417e088c';O.mkdir(exist_ok=True)
# Preserve the executed BEFORE worker; a separately named copy writes AFTER arms.
after=(R/'worker.ts').read_text().replace("process.env.PR449_ROOT_GO!=='wide-circle-absorption'", "process.env.PR449_ROOT_GO!=='wide-circle-absorption-after'")
after=after.replace('const report={revision,arm,',"const report={measurementScope:'Single-call reproduction only. renderWallMs/renderCPU include artifacts and forcedGC; do not use for performance claims or compare with cost elapsedMs.',revision,arm,")
(R/'after-worker.ts').write_text(after)
for name in ['source.mmd','agentic.options.json','elk.options.json']:(O/name).write_bytes((R/name).read_bytes())
(O/'edit.mmd').write_text('flowchart LR\n    A --o B[B revised]\nlinkStyle 0 stroke:#000,stroke-width:10px\n')
s=(W/'requirement-compound-cost-8393d577f/worker.ts').read_text().replace('requirement-compound-cost','wide-circle-absorption-cost')
s=s.replace('// Existing contact-rich three-phase cost consumer, current Requirement fan only.','// Reused requirement-compound three-phase full-product consumer; exact wide circle input.')
s=s.replace('gzipSync, gunzipSync, brotliCompressSync','gzipSync, brotliCompressSync')
s='\n'.join(line for line in s.splitlines()if 'job.previousNativeSvgReference'not in line)+'\n'
s=s.replace("    const consumed = consume(result), receiptJSON = JSON.stringify(result.receipt)\n    row = { phase, status: 'returned', elapsedMs: performance.now() - start,", "    const consumed = consume(result), receiptJSON = JSON.stringify(result.receipt)\n    const consumedEnd=performance.now()\n    row = { phase, status: 'returned', elapsedMs: consumedEnd - start, measurementWindow:{name:phase,kind:'publicAPI-through-entireSVG-and-receipt-consumption',startPerformanceMs:start,endPerformanceMs:consumedEnd},")
s=s.replace("    const consumed = consume(failure)\n    row = { phase, status: 'refused', elapsedMs: performance.now() - start,", "    const consumed = consume(failure)\n    const consumedEnd=performance.now()\n    row = { phase, status: 'refused', elapsedMs: consumedEnd - start, measurementWindow:{name:phase,kind:'publicAPI-through-entire-error-consumption',startPerformanceMs:start,endPerformanceMs:consumedEnd},")
s=s.replace("  } catch (error: any) {\n", "  } catch (error: any) {\n    if(row?.status==='returned')throw error // Artifact failures cannot become inflated public API timing rows.\n")
(O/'worker.ts').write_text(s)
jobs=[]
for backend in ['agentic','elk']:
 for cache in [0,1]:
  tag=f'{backend}-cache{cache}';job={'root':'/tmp/pr449-main-integration-20261029-762','arm':'current-candidate','count':'wide-circle-AB-stroke10','backend':backend,'expectedCache':cache,'sourceFile':str(O/'source.mmd'),'editFile':str(O/'edit.mmd'),'optionsFile':str(O/(backend+'.options.json')),'out':str(O/tag)}
  name=tag+'.job.json';jobs.append(name);(O/name).write_text(json.dumps(job,indent=2)+'\n')
(O/'PREPARED.json').write_text(json.dumps({'status':'HOLD static preparation only; zero projectimports/calls/profiles/builds','workerReuse':'requirement-compound-cost-8393d577f/worker.ts','rootGoNamespace':'wide-circle-absorption-cost','jobs':jobs,'workers':4,'callsPerWorker':3,'maxPublicCalls':12,'phases':['cold','repeat','edit'],'edit':'Keep endpoints A/B and hollow-circle relation; change only B visible text B→B revised using B[B revised]; retain exact linkStyle0 stroke:#000/stroke-width:10px.','options':'Perbackend AM/ELK fallbacknone/embedFontImport:false; defaultnonstrict, Sceneassertions0.','timing':'Named measurementWindow start through publicAPI+entireSVG/receipt consumer end. Row metadata/comparisons/artifactI/O/gzip9/Br11/forcedGC excluded; svgTransferMs separately records compression. Existing observers wrap calls, so instrumented N1 not benchmark.','retention':'FullSVG.gz+ENTIREreceipt.json.gz per returnedphase, fullproof/errors/stages/events/loaded and beforeGC/afterGC RSSheap/maxRSS, actualSVG raw/gzip9/Br11 bytes; held3outputs retained. Repeat fullproduct equality and realedit change recorded, alloutcomes retained.','beforeTimingLimitation':'Earlier onecall renderWallMs included artifactwrites/compression+forcedGC. Never compare it with cost elapsedMs or infer speed/performance ratios.','constraints':'Root sole CPU after RED/candidate authorization. No execution, extra caches, checksums/hashes/overlays/profiles/bundlebuild/framework, no priorartifact/worker/repository edits; separate after-worker.ts prepared.'},indent=2)+'\n')
print('STATIC_FILE_PREPARATION_COMPLETE: zero runtime imports, calls, profiles or builds')
