// Held after-only adaptation of the existing wide-circle/contains ink tools.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { gzipSync, gunzipSync } from 'node:zlib'
import { createRequire } from 'node:module'
import { Resvg } from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import { HOSTED_FONT_RESOURCES } from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import { inlineFontVarForRaster } from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const { JSDOM } = createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
const root = '/tmp/pr449-main-integration-20261029-762', out = '/tmp/pr449-week-comparison-20261101/start-circle-standalone-c7490d9b4'
const tag = process.argv[2] ?? 'after'
const target = `${out}/${tag}-independent-review.json.gz`
assert(!fs.existsSync(target), `Refusing to overwrite ${target}`)
const read = (path: string) => path.endsWith('.gz') ? gunzipSync(fs.readFileSync(path)).toString() : fs.readFileSync(path, 'utf8')
const attrs = (element: Element) => Object.fromEntries([...element.attributes].map(attribute => [attribute.name, attribute.value]))
const save = (name: string, data: string | Uint8Array) => fs.writeFileSync(`${out}/${tag}-${name}.gz`, gzipSync(data))
const scratch = fs.mkdtempSync('/tmp/pr449-start-circle-fonts-')
let rasterCalls = 0
try {
  const fonts = HOSTED_FONT_RESOURCES.filter(font => font.family === 'Inter')
  const fontFiles = fonts.map(font => {
    const bytes = fs.readFileSync(`${root}/${font.path}`)
    assert.equal(bytes.length, font.bytes)
    assert.equal(createHash('sha256').update(bytes).digest('hex'), font.sha256)
    const path = `${scratch}/${font.file}`
    fs.writeFileSync(path, bytes)
    return path
  })
  const zoom = 3, results = []
  const render = (svg: string, name: string) => {
    rasterCalls++
    const image = new Resvg(inlineFontVarForRaster(svg), { background: '#ffffff', fitTo: { mode: 'zoom', value: zoom }, font: { fontFiles, fontDirs: [], loadSystemFonts: false, defaultFontFamily: 'Inter' } }).render()
    save(`${name}.svg`, svg); save(`${name}.png`, image.asPng())
    return { width: image.width, height: image.height, pixels: image.pixels }
  }
  for (const backend of ['agentic', 'elk']) {
    const path = `${out}/after-${backend}/actual.svg.gz`, raw = read(path)
    const packet = JSON.parse(read(`${out}/after-${backend}/RESULT.json.gz`))
    assert.equal(packet.source, read(`${out}/source.mmd`))
    assert.deepEqual(packet.options, JSON.parse(read(`${out}/${backend}.options.json`)))
    const dom = new JSDOM(raw, { contentType: 'image/svg+xml' }), document = dom.window.document as Document
    try {
      assert(!document.querySelector('[transform]'))
      const nodes = [...document.querySelectorAll('g.node')]
      assert.deepEqual(nodes.map(node => [node.getAttribute('data-id'), node.getAttribute('data-label')]).sort(), [['edge__0', '依頼者 🧭'], ['store', '記録庫 📦']])
      assert.deepEqual([...document.querySelectorAll('text')].map(text => text.textContent).sort(), ['依頼者 🧭', '記録庫 📦', '保存'].sort())
      const carriers = [...document.querySelectorAll('[data-role="edge"][data-from]')]
      assert.equal(carriers.length, 1)
      const carrier = carriers[0], edge = attrs(carrier)
      assert.equal(carrier.localName, 'polyline')
      assert.equal(edge['data-from'], 'edge__0'); assert.equal(edge['data-to'], 'store'); assert.equal(edge['data-label'], '保存')
      assert.equal(edge['data-arrow-start'], 'true'); assert.equal(edge['data-marker-start'], 'circle')
      assert.equal(edge['data-arrow-end'], 'false'); assert(!carrier.hasAttribute('marker-end'))
      assert(/^\s*(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/.test(edge['stroke-width']))
      assert.equal(Number.parseFloat(edge['stroke-width']), 10); assert.equal(edge.stroke, '#ff0000')
      const labels = [...document.querySelectorAll('g.edge-label')]
      assert.equal(labels.length, 1)
      assert.equal(labels[0].getAttribute('data-from'), 'edge__0'); assert.equal(labels[0].getAttribute('data-to'), 'store')
      assert.equal(labels[0].getAttribute('data-label'), '保存'); assert.equal(labels[0].querySelector('text')?.textContent, '保存')
      const cylinder = nodes.find(node => node.getAttribute('data-id') === 'store')!
      const pieces = [...cylinder.children].filter(child => child.localName !== 'text')
      assert.deepEqual(pieces.map(piece => piece.localName), ['rect', 'line', 'line', 'ellipse', 'ellipse'])
      const sourceFrames = [...document.querySelectorAll('[data-id="node-shape:edge__0"]')]
      assert.equal(sourceFrames.length, 1); assert.equal(sourceFrames[0].localName, 'rect')
      const sourceFrame = attrs(sourceFrames[0]), targetSide = attrs(pieces[1])
      const points = edge.points.trim().split(/\s+/).map(point => point.split(',').map(Number))
      assert(points.length >= 2 && points.every(point => point.length === 2 && point.every(Number.isFinite)))
      const start = points[0], next = points.find(point => point[0] !== start[0] || point[1] !== start[1])
      assert(next); assert(points.every(point => point[1] === start[1])); assert(next[0] > start[0])
      const end = points.at(-1)!, previous = [...points].reverse().find(point => point[0] !== end[0] || point[1] !== end[1])!
      const sourceNormal = Math.abs(start[0] - (+sourceFrame.x + +sourceFrame.width)) < 1e-6 && start[1] > +sourceFrame.y && start[1] < +sourceFrame.y + +sourceFrame.height
      const targetNormal = Math.abs(end[0] - +targetSide.x1) < 1e-6 && end[1] > +targetSide.y1 && end[1] < +targetSide.y2 && previous[0] < end[0]
      assert(sourceNormal); assert(targetNormal)
      const reference = edge['marker-start'], id = /^url\(#([A-Za-z_][\w:.-]*)\)$/.exec(reference)?.[1]
      assert(id)
      const resources = [...document.querySelectorAll('marker')].filter(marker => marker.id === id)
      assert.equal(resources.length, 1)
      const resource = resources[0], marker = attrs(resource)
      assert.deepEqual([+marker.markerWidth, +marker.markerHeight, +marker.refX, +marker.refY], [8, 8, .5, 4])
      assert.equal(marker.orient, 'auto'); assert.equal(marker.markerUnits, 'userSpaceOnUse'); assert(!resource.hasAttribute('viewBox'))
      assert.equal(resource.children.length, 1); assert.equal(resource.children[0].localName, 'circle')
      const circle = attrs(resource.children[0])
      assert.deepEqual([+circle.cx, +circle.cy, +circle.r, Number.parseFloat(circle['stroke-width'])], [4, 4, 3.25, 1])
      assert.equal(circle.fill, 'none'); assert.equal(circle.stroke, '#ff0000')
      const token = ` marker-start="${reference}"`
      assert.equal(raw.split(token).length, 2)
      const boundTags = [...raw.matchAll(/<polyline\b[^>]*\/>/g)].filter(match => match[0].includes(token))
      assert.equal(boundTags.length, 1)
      const center = [start[0] + +circle.cx - +marker.refX, start[1] + +circle.cy - +marker.refY]
      const radius = +circle.r + Number.parseFloat(circle['stroke-width']) / 2
      const roi = { x0: center[0] - radius - 2, y0: center[1] - radius - 2, x1: center[0] + radius + 2, y1: center[1] + radius + 2 }
      const full = render(raw, `${backend}-full`), absent = render(raw.replace(token, ''), `${backend}-marker-removed`)
      assert.equal(full.width, absent.width); assert.equal(full.height, absent.height)
      let changed = 0, darker = 0, lighter = 0, outsideRoi = 0
      for (let y = 0; y < full.height; y++) for (let x = 0; x < full.width; x++) {
        const offset = (y * full.width + x) * 4
        if (Math.abs(full.pixels[offset] - absent.pixels[offset]) < 4 && Math.abs(full.pixels[offset + 1] - absent.pixels[offset + 1]) < 4 && Math.abs(full.pixels[offset + 2] - absent.pixels[offset + 2]) < 4 && Math.abs(full.pixels[offset + 3] - absent.pixels[offset + 3]) < 4) continue
        changed++
        const wx = (x + .5) / zoom, wy = (y + .5) / zoom
        if (wx < roi.x0 || wx > roi.x1 || wy < roi.y0 || wy > roi.y1) outsideRoi++
        if (full.pixels[offset] + full.pixels[offset + 1] + full.pixels[offset + 2] < absent.pixels[offset] + absent.pixels[offset + 1] + absent.pixels[offset + 2]) darker++
        else lighter++
      }
      const beforeResult = `${out}/before-${backend}/RESULT.json.gz`, beforeSvg = `${out}/before-${backend}/actual.svg.gz`
      const before = fs.existsSync(beforeResult) ? JSON.parse(read(beforeResult)) : undefined
      const receipt = JSON.parse(read(`${out}/after-${backend}/actual.receipt.json.gz`))
      results.push({ backend, path, source: packet.source, options: packet.options, beforeStatus: before?.row?.status ?? 'not captured', beforeFailure: before?.row?.failure, beforeActualSvgAvailable: fs.existsSync(beforeSvg), beforeActualInkAvailable: false, viewport: attrs(document.documentElement), carrier: edge, marker, circle, sourceFrame, targetSide, sourceNormal, targetNormal, center, radius, proof: receipt.layoutCertification, markerContribution: { changed, darker, lighter, outsideRoi, roi, rasterSize: [full.width, full.height] } })
    } finally { dom.window.close() }
  }
  assert.equal(rasterCalls, 4)
  const report = { publicCalls: 0, offlineRasterCalls: rasterCalls, results, fonts: fonts.map(font => ({ file: font.file, bytes: font.bytes, sha256: font.sha256 })), scope: 'Independent source IDs, UTF-16 label/caption spelling, one start-circle occurrence and no actual end arrow; source rectangle and target cylinder-side normal contacts from actual SVG. Actual same-color10px start-circle marker-removal contribution under pinned Inter. Before refusal supplies no SVG/ink comparison. Positive head contribution alone is not universal recognizability; supplementary-label fallback glyph ink is not qualified. No P, area/wire or performance claim.' }
  fs.writeFileSync(target, gzipSync(JSON.stringify(report, null, 2)))
  console.log(JSON.stringify(report))
} finally { fs.rmSync(scratch, { recursive: true, force: true }) }
