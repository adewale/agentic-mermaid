import { readFileSync, writeFileSync, writeSync, mkdirSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
const root='/tmp/pr449-main-integration-20261029-762',fixture='/tmp/pr449-week-comparison-20261101/requirement-contains-fan-proposal-c0bba6102',arm=process.argv[2],out=process.argv[3],backend=process.argv[4]??'elk',overridePath=process.argv[5]
Error.stackTraceLimit=40
const sourcePath=fixture+'/source.mmd'
if(!arm||!out||backend!=='elk'||process.env.PR449_ROOT_GO!=='requirement-elk-dock')throw new Error('Held: root GO, arm/output and exact ELK backend required; zero calls started')
mkdirSync(out,{recursive:true})
// Reuse the prior Bun source overlay pattern at exactly the existing ELK call.
// No override file means observation only. Root alone selects any later probe.
const optionOverrides: Record<string,string> = overridePath ? JSON.parse(readFileSync(overridePath,'utf8')) : {}
for(const [name,value] of Object.entries(optionOverrides))if(typeof value!=='string')throw new Error('ELK layout option values must remain strings: '+name)
let overlayLoads=0,actualElkCalls=0
const saveGraph=(name:string,value:unknown)=>writeFileSync(out+'/'+name+'.json.gz',gzipSync(JSON.stringify(value)))
;(globalThis as any).__PR449_CAPTURE_REQUIREMENT_ELK__=(graph:any,run:()=>any)=>{
 actualElkCalls++
 const tag='elk-call-'+actualElkCalls
 saveGraph(tag+'-before-options',graph)
 if(overridePath)Object.assign(graph.layoutOptions,optionOverrides)
 saveGraph(tag+'-input',graph)
 try{
  const placed=run()
  saveGraph(tag+'-after',placed)
  saveGraph(tag+'-input-after-call',graph)
  return placed
 }catch(error:any){
  saveGraph(tag+'-error',{name:error?.name,message:error?.message,stack:error?.stack,cause:error?.cause?{name:error.cause.name,message:error.cause.message,stack:error.cause.stack}:undefined})
  saveGraph(tag+'-input-after-error',graph)
  throw error
 }
}
Bun.plugin({name:'requirement-existing-elk-call-capture',setup(build){build.onLoad({filter:/\/src\/requirement\/layout\.ts$/},args=>{
 if(args.path!==root+'/src/requirement/layout.ts')return
 const original=readFileSync(args.path,'utf8'),needle='elkLayoutSync(graph)'
 if(original.split(needle).length!==2)throw new Error('Expected exactly the existing Requirement ELK graph call')
 overlayLoads++
 const contents=original.replace(needle,'(globalThis as any).__PR449_CAPTURE_REQUIREMENT_ELK__(graph, () => elkLayoutSync(graph))')
 writeFileSync(out+'/observational-layout-overlay.ts.gz',gzipSync(contents))
 return {contents,loader:'ts'}
})}})
const sourceBytes=readFileSync(sourcePath),source=sourceBytes.toString('utf8')
const revision=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8',env:{...process.env,GIT_NO_LAZY_FETCH:'1',GIT_OPTIONAL_LOCKS:'0'}}).trim()
const wallStart=performance.now(),cpuStart=process.cpuUsage()
const log=(value:unknown)=>writeSync(1,JSON.stringify(value)+'\n')
log({event:'IMPORT_START',memory:process.memoryUsage(),cpu:process.cpuUsage()})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const {withRenderStageObserver}=await import(root+'/src/render-stages.ts')
const {withPerformanceObserver}=await import(root+'/src/performance-observations.ts')
const {apiFailure}=await import(root+'/eval/layout-compare/outcomes.ts')
const importMs=performance.now()-wallStart,importCPU=process.cpuUsage(cpuStart)
const options=JSON.parse(readFileSync(fixture+'/'+backend+'.options.json','utf8'))
const stages:any[]=[],events:any[]=[]
const before=process.memoryUsage(),renderCPU=process.cpuUsage(),renderStart=performance.now()
let product:any,row:any
log({event:'ACTUAL_PUBLIC_CALL_START',actualCalls:1,importMs,importCPU,before})
try{
 const artifact=withPerformanceObserver(event=>events.push(event),()=>withRenderStageObserver(stage=>{stages.push(stage);log({event:'STAGE_COMPLETE',...stage})},()=>renderMermaidSVGWithReceipt(source,options)))
 product={svg:artifact.svg,receipt:artifact.receipt}
 const bytes=Buffer.from(JSON.stringify(product))
 writeFileSync(out+'/product.json.gz',gzipSync(bytes))
 writeFileSync(out+'/actual.svg.gz',gzipSync(product.svg));writeFileSync(out+'/actual.receipt.json.gz',gzipSync(JSON.stringify(product.receipt)))
 row={status:'returned',fullyConsumedBytes:bytes.length,proof:product.receipt.layoutCertification}
}catch(error:any){
 product={normalized:apiFailure(error),name:error?.name,message:error?.message,code:error?.code,stack:error?.stack,cause:error?.cause?{name:error.cause.name,message:error.cause.message,stack:error.cause.stack}:undefined,certification:error?.certification}
 const bytes=Buffer.from(JSON.stringify(product));writeFileSync(out+'/product.json.gz',gzipSync(bytes));row={status:'refused',fullyConsumedErrorBytes:bytes.length,failure:product}
}
const memoryBeforeGC=process.memoryUsage();Bun.gc(true);const postGCMemory=process.memoryUsage()
const report={revision,arm,sourceBytesUnchanged:sourceBytes.equals(readFileSync(sourcePath)),backend,sourcePath,memoryBeforeGC,postGCMemory,actualPublicCalls:1,overlayLoads,actualElkCalls,overridePath,optionOverrides,scope:'One existing public ELK render with raw graph before/effective input/immediate output captured; instrumented causal probe, not a timing benchmark or new backend.',source,options,importMs,importCPU,renderWallMs:performance.now()-renderStart,renderCPU:process.cpuUsage(renderCPU),totalWallMs:performance.now()-wallStart,totalCPU:process.cpuUsage(cpuStart),loadedMemory:before,afterMemory:process.memoryUsage(),peakRssKiB:process.resourceUsage().maxRSS,row,provider:events.filter(e=>e.owner==='paint-certification'),stages,events,product}
writeFileSync(out+'/RESULT.json.gz',gzipSync(JSON.stringify(report)))
log({event:'ACTUAL_PUBLIC_CALL_COMPLETE',...report,product:undefined,events:undefined})
