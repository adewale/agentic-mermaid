import fs from 'node:fs'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { gzipSync, gunzipSync } from 'node:zlib'
import { createRequire } from 'node:module'
import { Resvg } from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import { HOSTED_FONT_RESOURCES } from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import { inlineFontVarForRaster } from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import { prepareResvgMarkerOrientation } from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'

const { JSDOM } = createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
if (process.argv[2] !== 'GO' || process.argv.length !== 5) throw Error('HOLD: root GO plus exact TB.svg.gz and BT.svg.gz paths required; four offline rasters total')
const root = '/tmp/pr449-main-integration-20261029-762'
const base = '/tmp/pr449-week-comparison-20261101/class-meaning-before-proof-24b21fc43'
const scratch = fs.mkdtempSync('/tmp/pr449-class128-ink-fonts-')
const rows = []
const sha = (value) => createHash('sha256').update(value).digest('hex')
const save = (dir, name, value) => fs.writeFileSync(`${dir}/${name}.gz`, gzipSync(typeof value === 'string' || value instanceof Uint8Array ? value : JSON.stringify(value, null, 2)))
try {
  const fonts = HOSTED_FONT_RESOURCES.filter(font => font.family === 'Inter')
  assert.equal(fonts.length, 4)
  const fontFiles = fonts.map(font => {
    const bytes = fs.readFileSync(`${root}/${font.path}`)
    assert.equal(bytes.length, font.bytes)
    assert.equal(sha(bytes), font.sha256)
    const path = `${scratch}/${font.file}`
    fs.writeFileSync(path, bytes)
    return path
  })
  for (const [index, direction] of ['TB', 'BT'].entries()) {
    const source = process.argv[index + 3], raw = gunzipSync(fs.readFileSync(source)).toString()
    const dir = `${base}/ink-${direction}`
    fs.mkdirSync(dir) // Preserve any earlier run instead of overwriting it.
    const dom = new JSDOM(raw, { contentType: 'image/svg+xml' }), document = dom.window.document
    const svg = document.documentElement, width = Number(svg.getAttribute('width')), height = Number(svg.getAttribute('height'))
    assert(width > 0 && height > 0 && Number.isFinite(width * height))
    assert.deepEqual(svg.getAttribute('viewBox').trim().split(/[\s,]+/).map(Number), [0, 0, width, height])
    assert.equal(document.querySelectorAll('[transform]').length, 0, 'Unaccounted coordinate transform')
    const marker = document.getElementById('cls-arrow'), piece = marker?.querySelector('polyline')
    assert(marker && piece)
    assert(['auto', 'auto-start-reverse'].includes(marker.getAttribute('orient')))
    assert.equal(marker.getAttribute('markerUnits') ?? 'strokeWidth', 'strokeWidth')
    assert(!marker.hasAttribute('viewBox'))
    assert.equal(Number(marker.getAttribute('refX')), 8)
    assert.equal(Number(marker.getAttribute('refY')), 3)
    assert.equal(marker.children.length, 1)
    assert.deepEqual(piece.getAttribute('points').trim().split(/[\s,]+/).map(Number), [0, 0, 8, 3, 0, 6])
    assert.equal(piece.getAttribute('fill'), 'none')
    assert.match(piece.getAttribute('stroke'), /^#[0-9a-f]{6}$/i)
    assert.equal(Number(piece.getAttribute('stroke-width')), 1.5)
    assert.equal(Number(piece.getAttribute('stroke-miterlimit') ?? 4), 4)
    for (const node of [marker, piece]) for (const attr of ['opacity', 'stroke-opacity']) assert(Number(node.getAttribute(attr) ?? 1) > 0)
    const carriers = [...document.querySelectorAll('polyline.class-relationship')]
    const overlays = [...document.querySelectorAll('polyline.class-marker-overlay')]
    assert.equal(carriers.length, 127)
    assert.equal(overlays.length, 127)
    const rois = carriers.map((carrier, i) => {
      assert.equal(carrier.getAttribute('data-from'), `N${i}`)
      assert.equal(carrier.getAttribute('data-to'), `N${i + 1}`)
      for (const node of [carrier, overlays[i]]) {
        assert.equal(node.getAttribute('marker-end'), 'url(#cls-arrow)')
        assert(!node.hasAttribute('marker-start'))
        assert.equal(Number(node.getAttribute('stroke-width')), 1)
      }
      assert.equal(overlays[i].getAttribute('points'), carrier.getAttribute('points'))
      const points = carrier.getAttribute('points').trim().split(/\s+/).map(pair => pair.split(',').map(Number))
      const end = points.at(-1), previous = points.at(-2), dx = end[0] - previous[0], dy = end[1] - previous[1], length = Math.hypot(dx, dy)
      assert(length > 0 && (dx === 0 || dy === 0))
      const ux = dx / length, uy = dy / length
      // Literal open arrow relative to ref(8,3), with conservative 3px
      // stroke/miter extent and a further 1px antialias/ROI margin.
      const corners = [[-11, -6], [3, -6], [-11, 6], [3, 6]].map(([x, y]) => [end[0] + x * ux - y * uy, end[1] + x * uy + y * ux])
      return { id: carrier.getAttribute('data-id'), from: `N${i}`, to: `N${i + 1}`, endpoint: end, tangent: [ux, uy],
        roi: [Math.min(...corners.map(p => p[0])) - 1, Math.min(...corners.map(p => p[1])) - 1, Math.max(...corners.map(p => p[0])) + 1, Math.max(...corners.map(p => p[1])) + 1], changed: 0, darker: 0, lighter: 0, borrowed: 0 }
    })
    const overlaps = []
    for (let i = 0; i < rois.length; i++) for (let j = 0; j < i; j++) {
      const a = rois[i].roi, b = rois[j].roi
      if (a[0] < b[2] && a[2] > b[0] && a[1] < b[3] && a[3] > b[1]) overlaps.push([rois[j].id, rois[i].id])
    }
    let removed = 0
    const maskRaw = raw.replace(/<polyline\b[^>]*class="(?:class-relationship|class-marker-overlay)"[^>]*\/>/g, tag => tag.replace(/ marker-end="url\(#cls-arrow\)"/g, () => { removed++; return '' }))
    assert.equal(removed, 254)
    const margin = 10, zoom = 2, expandedWidth = width + margin * 2, expandedHeight = height + margin * 2
    const expand = value => value.replace(/<svg\b[^>]*>/, opening => opening.replace(/\bwidth="[^"]+"/, `width="${expandedWidth}"`).replace(/\bheight="[^"]+"/, `height="${expandedHeight}"`).replace(/\bviewBox="[^"]+"/, `viewBox="-10 -10 ${expandedWidth} ${expandedHeight}"`))
    dom.window.close()
    const images = [raw, maskRaw].map((value, i) => {
      const adapted = prepareResvgMarkerOrientation(inlineFontVarForRaster(expand(value)))
      save(dir, `marker-${i ? 'mask' : 'full'}.svg`, adapted)
      const rendered = new Resvg(adapted, { background: '#ffffff', fitTo: { mode: 'zoom', value: zoom }, font: { fontFiles, fontDirs: [], loadSystemFonts: false, defaultFontFamily: 'Inter' } }).render()
      save(dir, `marker-${i ? 'mask' : 'full'}.png`, rendered.asPng())
      return { width: rendered.width, height: rendered.height, pixels: rendered.pixels }
    })
    const [full, absent] = images, fullPixels = full.pixels, absentPixels = absent.pixels
    assert.equal(full.width, absent.width); assert.equal(full.height, absent.height)
    let changed = 0, unattributed = 0, borrowed = 0, changedOutside = 0, fullDarkOutside = 0, maskDarkOutside = 0
    for (let y = 0; y < full.height; y++) for (let x = 0; x < full.width; x++) {
      const at = (y * full.width + x) * 4, wx = (x + 0.5) / zoom - margin, wy = (y + 0.5) / zoom - margin
      const outside = wx < 0 || wx > width || wy < 0 || wy > height
      if (outside) { if (Math.min(fullPixels[at], fullPixels[at + 1], fullPixels[at + 2]) < 245) fullDarkOutside++; if (Math.min(absentPixels[at], absentPixels[at + 1], absentPixels[at + 2]) < 245) maskDarkOutside++ }
      if (Math.abs(fullPixels[at] - absentPixels[at]) < 4 && Math.abs(fullPixels[at + 1] - absentPixels[at + 1]) < 4 && Math.abs(fullPixels[at + 2] - absentPixels[at + 2]) < 4 && Math.abs(fullPixels[at + 3] - absentPixels[at + 3]) < 4) continue
      changed++; if (outside) changedOutside++
      const owners = rois.filter(owner => wx >= owner.roi[0] && wx <= owner.roi[2] && wy >= owner.roi[1] && wy <= owner.roi[3])
      if (!owners.length) { unattributed++; continue }
      if (owners.length > 1) { borrowed++; for (const owner of owners) owner.borrowed++; continue }
      const owner = owners[0]; owner.changed++
      if (fullPixels[at] + fullPixels[at + 1] + fullPixels[at + 2] < absentPixels[at] + absentPixels[at + 1] + absentPixels[at + 2]) owner.darker++; else owner.lighter++
    }
    const report = { direction, source, sourceSha256: sha(raw), publicCalls: 0, publicLayoutCalls: 0, offlineRasterCalls: 2, width, height, zoom, exteriorMargin: margin, removedMarkerRefs: removed, overlaps, controls: rois,
      changed, unattributed, borrowed, changedOutside, fullDarkOutside, maskDarkOutside, withoutPositiveIndependentInk: rois.filter(owner => owner.darker === 0).map(owner => owner.id),
      fonts: fonts.map(font => ({ file: font.file, weight: font.weight, style: font.style, bytes: font.bytes, sha256: font.sha256 })),
      scope: 'Saved Class128 actual SVG only; all127 semantic-carrier and127 overlay end-marker references removed together. Per-head darkening is attributed only to unique actual-resource endpoint ROIs; overlapping/borrowed/unattributed/outside observations retained. Ten-pixel exterior margin exposes ink beyond original viewport. Pinned Inter/resvg observation, not individual label-ink, browser/universal-font, proof-status, or arbitrary-input certification.' }
    save(dir, 'marker-ink.json', report); rows.push(report)
    console.log(JSON.stringify({ direction, source, changed, unattributed, borrowed, changedOutside, fullDarkOutside, maskDarkOutside, overlaps, withoutPositiveIndependentInk: report.withoutPositiveIndependentInk }))
  }
  fs.writeFileSync(`${base}/independent-marker-ink-summary.json`, JSON.stringify({ publicCalls: 0, publicLayoutCalls: 0, offlineRasterCalls: 4, rows }, null, 2))
} finally { fs.rmSync(scratch, { recursive: true, force: true }) }
