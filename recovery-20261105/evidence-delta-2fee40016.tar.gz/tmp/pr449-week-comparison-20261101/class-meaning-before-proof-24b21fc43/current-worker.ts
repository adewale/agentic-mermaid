import { readFileSync, writeFileSync, writeSync, mkdirSync, existsSync } from 'node:fs'
import { gzipSync, gunzipSync } from 'node:zlib'
import { createHash } from 'node:crypto'
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/class-meaning-before-proof-24b21fc43/'+process.argv[3]
Error.stackTraceLimit=40
const engine=process.argv[2], direction=process.argv[3]
if(!['TB','BT'].includes(direction))throw Error('Exact enrolled direction required')
if(!['agentic','elk'].includes(engine)||process.env.PR449_ROOT_GO!=='class-final-ink-'+direction)throw new Error('Held: exact per-engine root GO required; no calls started')
if(existsSync(out+'/RESULT.json.gz'))throw new Error('Existing result retained; no repeat call')
mkdirSync(out,{recursive:true})
const wallStart=performance.now(),cpuStart=process.cpuUsage()
const log=(value:unknown)=>writeSync(1,JSON.stringify(value)+'\n')
log({event:'IMPORT_START',memory:process.memoryUsage(),cpu:process.cpuUsage()})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const {withRenderStageObserver}=await import(root+'/src/render-stages.ts')
const {withPerformanceObserver}=await import(root+'/src/performance-observations.ts')
const {apiFailure}=await import(root+'/eval/layout-compare/outcomes.ts')
const importMs=performance.now()-wallStart,importCPU=process.cpuUsage(cpuStart)
const source='classDiagram\ndirection '+direction+'\n'+Array.from({length:127},(_,i)=>`N${i} --> N${i+1}`).join('\n')
const options={graphLayout:{backend:engine as 'agentic'|'elk',fallback:'none' as const},embedFontImport:false}
const stages:any[]=[],events:any[]=[]
const before=process.memoryUsage(),renderCPU=process.cpuUsage(),renderStart=performance.now()
let product:any,row:any
log({event:'ACTUAL_PUBLIC_CALL_START',actualCalls:1,importMs,importCPU,before})
try{
 const artifact=withPerformanceObserver(event=>events.push(event),()=>withRenderStageObserver(stage=>{stages.push(stage);log({event:'STAGE_COMPLETE',...stage})},()=>renderMermaidSVGWithReceipt(source,options)))
 product={svg:artifact.svg,receipt:artifact.receipt}
 const bytes=Buffer.from(JSON.stringify(product));let checksum=0
 for(const byte of bytes)checksum=(Math.imul(checksum,31)+byte)>>>0
 writeFileSync(out+'/'+direction+'.svg.gz',gzipSync(product.svg));writeFileSync(out+'/'+direction+'.receipt.json.gz',gzipSync(JSON.stringify(product.receipt)))
 row={status:'returned',fullyConsumedBytes:bytes.length,checksum,svgSha256:createHash('sha256').update(product.svg).digest('hex'),proof:product.receipt.layoutCertification}
}catch(error:any){
 product={normalized:apiFailure(error),name:error?.name,message:error?.message,code:error?.code,stack:error?.stack,cause:error?.cause?{name:error.cause.name,message:error.cause.message,stack:error.cause.stack}:undefined,certification:error?.certification}
 const bytes=Buffer.from(JSON.stringify(product));let checksum=0;for(const byte of bytes)checksum=(Math.imul(checksum,31)+byte)>>>0;row={checksum,status:'refused',fullyConsumedErrorBytes:bytes.length,failure:product}
}
const memoryBeforeGC=process.memoryUsage();Bun.gc(true);const postGCMemory=process.memoryUsage()

const report={head:'24b21fc43a4a9a337167583426c52410ea2aada7',runtimeUnchanged:true,purpose:'current final SVG products for independent marker ink; no capacity or runtime-gain claim',engine,direction,memoryBeforeGC,postGCMemory,actualPublicCalls:1,source,options,importMs,importCPU,renderWallMs:performance.now()-renderStart,renderCPU:process.cpuUsage(renderCPU),totalWallMs:performance.now()-wallStart,totalCPU:process.cpuUsage(cpuStart),loadedMemory:before,afterMemory:process.memoryUsage(),peakRssKiB:process.resourceUsage().maxRSS,row,provider:events.filter(e=>e.owner==='paint-certification'),stages,events,product}
writeFileSync(out+'/RESULT.json.gz',gzipSync(JSON.stringify(report)))
log({event:'ACTUAL_PUBLIC_CALL_COMPLETE',...report,product:undefined,events:undefined})
