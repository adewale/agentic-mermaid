// Two-backend actual STEP e1 circle review adapted from the existing stock owner and
// requirement-contains-fan-proposal-c0bba6102/review.ts. No rendering API calls.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { gzipSync, gunzipSync } from 'node:zlib'
import { createRequire } from 'node:module'
import { Resvg } from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import { HOSTED_FONT_RESOURCES } from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import { inlineFontVarForRaster } from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const { JSDOM } = createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
const root = '/tmp/pr449-main-integration-20261029-762', out = '/tmp/pr449-week-comparison-20261101/step-wide-circle-bebf1d52f'
const tag = process.argv[2] ?? 'before'
const supplied = process.argv.slice(3)
const paths = supplied.length ? supplied : [`${tag}-agentic/actual.svg.gz`, `${tag}-elk/actual.svg.gz`]
assert.equal(paths.length, 2, 'Exactly the two saved backend products; 4 offline rasters maximum')
const target = `${out}/${tag}-independent-review.json.gz`
assert(!fs.existsSync(target), `Refusing to overwrite ${target}`)
const attrs = (element: Element) => Object.fromEntries([...element.attributes].map(attribute => [attribute.name, attribute.value]))
const read = (path: string) => path.endsWith('.gz') ? gunzipSync(fs.readFileSync(path)).toString() : fs.readFileSync(path, 'utf8')
const save = (name: string, data: string | Uint8Array) => fs.writeFileSync(`${out}/${tag}-${name}.gz`, gzipSync(data))
const scratch = fs.mkdtempSync('/tmp/pr449-wide-circle-fonts-')
let rasterCalls = 0
try {
  const fonts = HOSTED_FONT_RESOURCES.filter(font => font.family === 'Inter')
  const fontFiles = fonts.map(font => {
    const bytes = fs.readFileSync(`${root}/${font.path}`)
    assert.equal(bytes.length, font.bytes)
    assert.equal(createHash('sha256').update(bytes).digest('hex'), font.sha256)
    const path = `${scratch}/${font.file}`
    fs.writeFileSync(path, bytes)
    return path
  })
  const zoom = 3, results = []
  const render = (svg: string, name: string) => {
    rasterCalls++
    const image = new Resvg(inlineFontVarForRaster(svg), { background: '#ffffff', fitTo: { mode: 'zoom', value: zoom }, font: { fontFiles, fontDirs: [], loadSystemFonts: false, defaultFontFamily: 'Inter' } }).render()
    save(`${name}.svg`, svg)
    save(`${name}.png`, image.asPng())
    return { width: image.width, height: image.height, pixels: image.pixels }
  }
  for (const [index, relative] of paths.entries()) {
    const path = relative.startsWith('/') ? relative : `${out}/${relative}`
    const name = ['agentic', 'elk'][index], raw = read(path)
    const dom = new JSDOM(raw, { contentType: 'image/svg+xml' }), document = dom.window.document as Document
    try {
      const nodes = [...document.querySelectorAll('g.node')]
      assert.deepEqual(nodes.map(node => node.getAttribute('data-id')), ['A', 'B', 'C'])
      assert.deepEqual(nodes.map(node => [...node.querySelectorAll('text')].map(text => text.textContent)), [['A'], ['B'], ['C']])
      assert.deepEqual([...document.querySelectorAll('text')].map(text => text.textContent), ['A', 'B', 'C'])
      const edges = [...document.querySelectorAll('[data-role="edge"][data-from]')]
      assert.equal(edges.length, 2)
      assert.deepEqual(edges.map(edge => [edge.getAttribute('data-from'), edge.getAttribute('data-to')]), [['A', 'B'], ['A', 'C']])
      assert.equal(new Set(edges.map(edge => edge.getAttribute('data-id'))).size, 2)
      const edge = edges.find(edge => edge.getAttribute('data-id') === 'e1')!, carrier = attrs(edge)
      assert(['polyline', 'path'].includes(edge.localName))
      assert.equal(carrier['data-id'], 'e1'); assert.equal(carrier['data-curve'], 'step'); assert.equal(carrier['data-from'], 'A'); assert.equal(carrier['data-to'], 'B')
      assert.equal(carrier['data-direction'], 'forward'); assert.equal(carrier['data-marker-end'], 'circle')
      assert.equal(carrier['data-arrow-start'], 'false'); assert.equal(carrier['data-arrow-end'], 'true')
      assert(/^\s*(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/.test(carrier['stroke-width']))
      assert.equal(Number.parseFloat(carrier['stroke-width']), 10); assert(!edge.hasAttribute('marker-start')); assert(!edge.hasAttribute('style'))
      const reference = carrier['marker-end'], resourceId = /^url\(#([A-Za-z_][\w:.-]*)\)$/.exec(reference)?.[1]
      assert(resourceId)
      const resourceMatches = [...document.querySelectorAll('marker')].filter(marker => marker.id === resourceId)
      assert.equal(resourceMatches.length, 1)
      const resource = resourceMatches[0], marker = attrs(resource)
      assert.deepEqual([+marker.markerWidth, +marker.markerHeight, +marker.refX, +marker.refY], [8, 8, 7.5, 4])
      assert.equal(marker.orient, 'auto'); assert.equal(marker.markerUnits, 'userSpaceOnUse'); assert(!resource.hasAttribute('viewBox'))
      assert.equal(resource.children.length, 1); assert.equal(resource.children[0].localName, 'circle')
      const circle = attrs(resource.children[0])
      assert(/^\s*(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?(?:px)?\s*$/.test(circle['stroke-width']))
      assert.deepEqual([+circle.cx, +circle.cy, +circle.r, Number.parseFloat(circle['stroke-width'])], [4, 4, 3.25, 1]); assert.equal(circle.fill, 'none')
      assert(!document.querySelector('[transform]'))
      // Preserve every written vertex, including duplicates. Only absolute
      // M/L paths and polylines are interpreted; no curve flattening is used.
      const routePoints = (element: Element): number[][] => {
        const value = attrs(element)
        let points: number[][]
        if (element.localName === 'polyline') points = value.points.trim().split(/\s+/).map(point => point.split(',').map(Number))
        else {
          assert.equal(element.localName, 'path')
          const tokens = value.d.match(/[ML]|[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/g) ?? []
          assert(tokens.length >= 6 && tokens.length % 3 === 0)
          assert.equal(value.d.replace(/[ML]|[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/g, '').replace(/[\s,]/g, ''), '')
          points = []
          for (let i = 0; i < tokens.length; i += 3) {
            assert.equal(tokens[i], i === 0 ? 'M' : 'L')
            points.push([Number(tokens[i + 1]), Number(tokens[i + 2])])
          }
        }
        assert(points.length >= 2 && points.every(point => point.length === 2 && point.every(Number.isFinite)))
        return points
      }
      const normal = (at: number[], toward: number[] | undefined, box: Record<string, string>) => {
        if (!toward) return null
        const x = +box.x, y = +box.y, w = +box.width, h = +box.height, dx = toward[0] - at[0], dy = toward[1] - at[1]
        const near = (a: number, b: number) => Math.abs(a - b) < 1e-6
        return dy === 0 && at[1] > y && at[1] < y + h && (near(at[0], x) && dx < 0 || near(at[0], x + w) && dx > 0)
          || dx === 0 && at[0] > x && at[0] < x + w && (near(at[1], y) && dy < 0 || near(at[1], y + h) && dy > 0)
      }
      const contacts = edges.map(item => {
        const a = attrs(item), points = routePoints(item), start = points[0], end = points.at(-1)!
        const next = points.find(point => point[0] !== start[0] || point[1] !== start[1])
        const previous = [...points].reverse().find(point => point[0] !== end[0] || point[1] !== end[1])
        const from = nodes.find(node => node.getAttribute('data-id') === a['data-from'])!.querySelector('rect')!
        const to = nodes.find(node => node.getAttribute('data-id') === a['data-to'])!.querySelector('rect')!
        return { id: a['data-id'], from: a['data-from'], to: a['data-to'], points, immediateStartDirectionKnown: points[1][0] !== start[0] || points[1][1] !== start[1], immediateEndDirectionKnown: points.at(-2)![0] !== end[0] || points.at(-2)![1] !== end[1], sourceNormal: normal(start, next, attrs(from)), targetNormal: normal(end, previous, attrs(to)) }
      })
      const activeResources = edges.map(item => {
        const a = attrs(item)
        assert.equal(a['data-arrow-start'], 'false'); assert(!item.hasAttribute('marker-start'))
        assert.equal(a['data-arrow-end'], 'true')
        const id = /^url\(#([^)]*)\)$/.exec(a['marker-end'])?.[1]
        assert(id)
        const matching = [...document.querySelectorAll('marker')].filter(marker => marker.id === id)
        assert.equal(matching.length, 1)
        if (a['data-id'] !== 'e1') {
          assert.equal(a['data-from'], 'A'); assert.equal(a['data-to'], 'C')
          assert.equal(a['data-marker-end'], 'arrow'); assert(!item.hasAttribute('data-curve'))
          assert.equal(matching[0].children.length, 1); assert.equal(matching[0].children[0].localName, 'polygon')
        }
        return { edge: a['data-id'], marker: attrs(matching[0]), children: [...matching[0].children].map(child => ({ name: child.localName, attributes: attrs(child) })) }
      })
      const points = routePoints(edge)
      const bodies = [...document.querySelectorAll('[data-id="node-shape:B"]')]
      assert.equal(bodies.length, 1); assert.equal(bodies[0].localName, 'rect'); assert(!bodies[0].hasAttribute('style'))
      const body = attrs(bodies[0])
      const markerToken = ` marker-end="${reference}"`
      assert.equal(raw.split(markerToken).length, 2)
      const carrierMatches = [...raw.matchAll(/<(?:polyline|path)\b[^>]*\/>/g)].filter(match => match[0].includes(markerToken))
      const bodyMatches = [...raw.matchAll(/<rect\b[^>]*\/>/g)].filter(match => match[0].includes(' data-id="node-shape:B"'))
      assert.equal(carrierMatches.length, 1); assert.equal(bodyMatches.length, 1)
      const carrierTag = carrierMatches[0][0], bodyTag = bodyMatches[0][0]
      assert.equal(raw.split(carrierTag).length, 2); assert.equal(raw.split(bodyTag).length, 2)
      const anchor = points.at(-1)!, previous = [...points].reverse().find(point => point[0] !== anchor[0] || point[1] !== anchor[1])
      const length = previous ? Math.hypot(anchor[0] - previous[0], anchor[1] - previous[1]) : 0
      const terminalDirection = previous ? [(anchor[0] - previous[0]) / length, (anchor[1] - previous[1]) / length] : null
      const center = terminalDirection ? [anchor[0] + (+circle.cx - +marker.refX) * terminalDirection[0] - (+circle.cy - +marker.refY) * terminalDirection[1], anchor[1] + (+circle.cx - +marker.refX) * terminalDirection[1] + (+circle.cy - +marker.refY) * terminalDirection[0]] : null
      const radius = +circle.r + Number.parseFloat(circle['stroke-width']) / 2
      const roi = center ? { x0: center[0] - radius - 2, y0: center[1] - radius - 2, x1: center[0] + radius + 2, y1: center[1] + radius + 2 } : { x0: anchor[0] - 10, y0: anchor[1] - 10, x1: anchor[0] + 10, y1: anchor[1] + 10 }
      const controls = []
      for (const control of ['normal'] as const) {
        const svg = raw
        // Actual product vs exactly one selected marker reference removed.
        // The invalid stroke:none consumer control is not repeated.
        assert.equal(svg.split(markerToken).length, 2)
        const absentSvg = svg.replace(markerToken, '')
        const actual = render(svg, `${name}-${control}-with-marker`), absent = render(absentSvg, `${name}-${control}-without-marker`)
        assert.equal(actual.width, absent.width); assert.equal(actual.height, absent.height)
        let changed = 0, darker = 0, lighter = 0, outsideRoi = 0
        for (let y = 0; y < actual.height; y++) for (let x = 0; x < actual.width; x++) {
          const offset = (y * actual.width + x) * 4
          if (Math.abs(actual.pixels[offset] - absent.pixels[offset]) < 4 && Math.abs(actual.pixels[offset + 1] - absent.pixels[offset + 1]) < 4 && Math.abs(actual.pixels[offset + 2] - absent.pixels[offset + 2]) < 4 && Math.abs(actual.pixels[offset + 3] - absent.pixels[offset + 3]) < 4) continue
          changed++
          const wx = (x + .5) / zoom, wy = (y + .5) / zoom
          if (wx < roi.x0 || wx > roi.x1 || wy < roi.y0 || wy > roi.y1) outsideRoi++
          if (actual.pixels[offset] + actual.pixels[offset + 1] + actual.pixels[offset + 2] < absent.pixels[offset] + absent.pixels[offset + 1] + absent.pixels[offset + 2]) darker++
          else lighter++
        }
        controls.push({ control, changed, darker, lighter, outsideRoi, rgbaBytesEqual: actual.pixels.equals(absent.pixels), rasterSize: [actual.width, actual.height], roi })
      }
      const receiptPath = path.replace(/actual\.svg(?:\.gz)?$/, 'actual.receipt.json.gz')
      const resultPath = path.replace(/actual\.svg(?:\.gz)?$/, 'RESULT.json.gz')
      const packet = fs.existsSync(resultPath) ? JSON.parse(read(resultPath)) : undefined
      assert.equal(packet.source, read(`${out}/source.mmd`))
      assert.deepEqual(packet.options, JSON.parse(read(`${out}/${name}.options.json`)))
      const receipt = fs.existsSync(receiptPath) ? JSON.parse(read(receiptPath)) : undefined
      results.push({ name, path, authoredEdgeId: 'e1', authoredCurve: 'step', carrierKind: edge.localName, points, contacts, authoredCarriers: edges.map(attrs), activeResources, e1ResolvedStrokeEqualsMarkerStroke: carrier.stroke === circle.stroke, svgBytes: Buffer.byteLength(raw), source: packet?.source, options: packet?.options, viewport: attrs(document.documentElement), carrier, marker, circle, body, anchor, terminalDirection, center, radius, proof: receipt?.layoutCertification, controls })
    } finally { dom.window.close() }
  }
  assert.equal(rasterCalls, 4)
  const report = { publicCalls: 0, offlineRasterCalls: rasterCalls, results, fonts: fonts.map(font => ({ file: font.file, bytes: font.bytes, sha256: font.sha256 })), scope: 'Exact authored e1/curve:step A-to-B endcircle plus A-to-C arrow, actual XML A/B/C text, 10px black e1 stroke and full active resources. Polyline/absolute multi-M/L vertices retain duplicates; first/last nonzero contact normals are observations separate from immediate duplicate uncertainty. Four e1 marker-end-removal rasters only; no assumed zero, P or readability gate. Geometry/resource/ref/anchor/body/root are unchanged by the mask. Other arrow ink, area/wire, runtime certification and universal fonts are not qualified.' }
  fs.writeFileSync(target, gzipSync(JSON.stringify(report, null, 2)))
  console.log(JSON.stringify(report))
} finally { fs.rmSync(scratch, { recursive: true, force: true }) }
