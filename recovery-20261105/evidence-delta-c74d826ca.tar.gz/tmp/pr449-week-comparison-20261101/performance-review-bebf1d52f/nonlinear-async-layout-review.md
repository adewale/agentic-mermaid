# Async and layout boundary review at bebf1d52f

Read-only source review while root collects Node/V8 profiles. No runtime calls,
tests, builds, source changes, or hotness/savings claims. This note is a report,
not an implementation proposal approved for execution.

## One possible independent load overlap, browser only

`src/browser-preview-worker.ts:25–65` currently loads the selected verified
family, then an optional nondefault backend, then the module for the known
operation. For a fixed worker request, fetching the operation module
(`agent/verify.ts` for preview, `browser-png.ts` for PNG, or `ascii/index.ts` for
terminal output) need not await the family chunk's download. This is a concrete
place to investigate browser cold-load latency, if a request waterfall shows it.
It cannot explain a synchronous Node render CPU profile.

The ordering is not entirely free: verified-family loading installs hooks;
operation imports can evaluate shared registry modules; backend selection calls
`captureRenderOptions`; moving that call across an await changes when live
options/getters are observed. A valid overlap would keep one admitted request,
family installation before execution, failure handling, and selected-only
downloads. Concurrent import failure can also change the reported first cause
and leave another import running. No overlap is asserted safe before those
effects are checked.

Several nearby awaits already express dependencies or existing parallelism:
`browser-lazy.ts:66` overlaps selected-family/render-core imports;
`layout/agentic-layered.lazy.ts:14` overlaps native producer/forest loading.
`browser-lazy/render-core.ts:30–50` discovers one demanded dependency by failed
execution and replays the same admitted request. Its bounded loop is not a list
of known independent loads. The browser PNG host callback requires the completed
secured SVG. `shared/batched.ts:26–37` invokes arbitrary handlers in order;
`Promise.all` would change side-effect/error/read ordering, not just speed.

## One conditional candidate-allocation location

`src/layout/cycle-layout-search.ts:34–54` constructs node permutations, edge
orders, endpoint remaps, copied edge records, and restored route lists for each
candidate order. If a measured profile puts material time/allocation here,
private ordinal buffers or a narrowly reused permutation could be compared
against the present per-candidate arrays. This is a location to inspect, not a
demonstrated removable pass: the reordering and restoration preserve authored
edge occurrences, captions, feedback directions, loop-port references, and the
complete-candidate callback's result.

Existing layout code already uses dense numeric data where appropriate:
`measured-forest.ts` uses typed span/band/depth arrays; `chain-insertion-order.ts`
uses typed score/displacement/parent arrays; `compound-obstacle-index.ts` uses
indexed broad phases followed by original strict predicates. A blanket Map/Set
or array-of-structs replacement is not justified by their presence elsewhere.
The optional cycle search is bounded to small graphs and charged candidate
work; an allocation hypothesis must show a material consumed cost first.

Any private-buffer experiment must keep earlier winning candidates independent
of later mutable work, exact authored tie/order semantics, existing budget
charges/refusal paths, and complete final contact validation. It must not turn
ordinary caller objects into an assumed immutable snapshot or silently change
getter reads. String identities remain opaque, including authored names that
look generated, non-BMP text, and JavaScript UTF-16 spelling; replacing identity
maps with property dictionaries or changing string iteration is outside this
candidate. No text/definition/CSS/UTF-16 scan subtraction was established here.

## Current decision

Wait for root's measured top frames. There is no demonstrated redundant await
in the synchronous render path and no demonstrated hot layout pass to rewrite.
The browser load overlap needs separate cold-download evidence; the candidate
allocation site needs profile attribution and a causal bounded comparison.
