# Five measured source frames: contract review

Root reports Native Class128 over six calls: snapshot.visit about131ms,
validateNode18ms, certifyNativePaint13ms, bounds.include9ms, and XML envelope6ms.
These are filtered sampled elapsed estimates, not exact exclusive CPU times or
predicted savings. Source review only; no experiment, replay or implementation.

1. **snapshot.visit — local storage substitution candidate.**
   `src/scene/scene-data-snapshot.ts:98–178` captures arrays with a local descriptor
   Map at150 and numeric-string lookup at167. Private descriptor slots could
   remove that allocation/lookup layer; the measured visit frame does not show
   how much of its131ms belongs to the Map. Preserve length-descriptor and
   ownKeys preflight, descriptor traps in reported key order BEFORE key-domain
   validation, then recursive value visits in ascending numeric order. Direct
   array assignment/read must not invoke inherited setters/getters or fabricate
   sparse entries. Keep captured own-slot publishers, active-cycle WeakSet,
   alias-preserving WeakMap and their order: the object counter increments
   BEFORE alias lookup. Object handling at184–237 has a different trap/recursion
   sequence and registered terminal-projection materialization; do not fold it
   into the array rewrite. Text/key limits still use bounded UTF-8 accounting,
   including JavaScript surrogate spelling, rather than code-point iteration or
   string.length as a byte count.

2. **validateNode — necessary semantic admission; no subtraction demonstrated.**
   `src/scene/scene-validation-core.ts:724–793` checks depth/count limits,
   typed kind, resources, IDs/DOM collisions, roles, owners, channels,
   serialization and transforms. These are distinct observable obligations.
   The per-kind field-array construction at746–757 is inside state.external;
   do not attribute Native savings to hoisting it without proving that branch
   executes in this profile. Moving checks or reading caller fields once could
   change diagnostic precedence and live getter observations. A broad frame
   sample establishes neither duplicate validation nor a removable second pass.

3. **certifyNativePaint — already indexed, with no demonstrated SoA hot loop.**
   `src/scene/paint-certification.ts:68–96` already builds an ink tree or lazy
   index with stable tie order and charged queries. Immutable sibling batches
   at1592–1605 reuse broad-phase results; textSurfaces at1649–1655 filters on
   bounds and paint order, then1667–1690 consumes full ownership/interior facts.
   That leaf filter is structurally bounds+order, but the parent13ms frame does
   not identify it as hot. The initial occurrence pass at1452–1463 also checks
   write authority, conditional/unmeasured coverage and prepared text, not just
   numeric bounds. Surface/marker records carry semantic paint facts, so a
   blanket AoS→SoA proposal would add construction and ordinal-recovery work
   around existing indexes. Preserve comparison charges, cap exhaustion, issue
   ordering and raw mutable-caller paths; there is no supported packing or
   upper-bit proposal.

4. **bounds.include — producer reuse candidate, not a new cache.**
   `src/scene/bounds.ts:350–363` computes an occurrence pose, then JSON-stringifies
   a spread marker (including resource geometry/paint), effective angle/unit
   scale and the matrix's linear part. Repeated immutable resource encoding is
   the concrete candidate. Only an existing owning producer could safely reuse
   its admitted resource portion; pose/scale/matrix remain occurrence-specific.
   Live descriptors, nested geometry, getters/toJSON, property order, default
   orient and unknown-angle geometry must keep their current behavior. Repaint
   equality controls owned restoration in paint-certification.ts:1948,2229,2307;
   an identity token or resource ID alone is not an equivalent replacement.
   Reusing resource encoding must not reuse resolved CSS/palette paint facts.

5. **verifyDocumentEnvelope — required authority-specific scan.**
   `src/output-security.ts:275–292` already request-caches the ordinary exact-byte
   envelope predicate. Work-charged proof callers deliberately take the fresh
   path. Final security at710–724 scans with an attribute observer and preserves
   malformed-XML precedence over attribute/CSS errors; observeData at315 has
   another obligation. `src/svg-inspection-cache.ts:1–10,38–58` keys by private
   inspector owner plus exact immutable SVG bytes, with retention caps and
   nested-request restoration. Changed bytes, a different observer or proof
   authority legitimately require another scan. The6ms frame alone proves no
   redundant same-authority scan, and does not justify cached boolean reuse.

Report decision: the snapshot's local descriptor storage and the marker
resource's repeated encoding are the only concrete narrow candidates from this
review. Neither has a causal savings measurement or authorization to implement.
The other three frames require finer attribution before proposing a subtraction.
