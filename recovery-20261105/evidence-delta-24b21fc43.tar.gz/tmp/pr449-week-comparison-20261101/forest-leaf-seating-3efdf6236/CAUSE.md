Stopped leaf-only seating trial, parent runtime3efdf6236, 2026-11-04.
One actual public Agentic call on the existing188-byte source/options, fallback none;
receipt selectsAgentic, P98335. Entire final SVG equals the retained ELK SVG exactly.
Predicted fixed-body totalshaft404.2875/area165355.6575 was falsified. Actual shaft
396.469666666/area176727.21: shorterwire14.45%, but area+6.8776% versus3ef.
No visible meaning/ink correctness conclusion follows from P or geometry equality.
First responsible admission: equalizePeerNodeDimensions in the existing shared
finishGraphGeometry pipeline, enabled for native forest mergeEdges. sameFlowLayer
compares main starts (shared.ts17–20); oldE/F124.9/184.05 differ59.15, proposedboth
124.9 qualify. peers.ts127–132/178–180 equalizes them to97.525×155.2, then cross-packs;
fanout normalization/barycenter updates follow. This is not an ELK backend fallback.
Changing this established symmetry/sizing policy needs separate independently
justified contract work; no fixture-specific bypass, additional variant or extra
cost/Node/build/raster/test call attempted. Production/test draft and full patch
preserved in stopped-trial; both restored byte-exact to committed3ef. Prepared
qualification scripts/jobs remain evidence only, NOT executed. No failure closed.
One fully consumed call371.80ms, peakRSS106172KiB; GC/artifacts are included by this
consumer. N1 dated predecessor comparison; no speed or memory ratio.
