import {plugin} from 'bun'
import {readFileSync} from 'node:fs'
plugin({name:'prior forest source owning regression',setup(build){build.onLoad({filter:/\/src\/layout\/measured-forest\.ts$/},()=>({contents:readFileSync('/tmp/pr449-week-comparison-20261101/forest-independent-bands-7299495bc/before-measured-forest.ts','utf8'),loader:'ts'}))}})
