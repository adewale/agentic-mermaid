All 18 fully consumed calls returned passed proofs; no refused/error rows. Six fresh workers, one observation per cell. Before alone uses an onLoad literal measured-forest overlay; current has no overlay, so imports/loader work are asymmetric. Elapsed excludes import and phase GC/artifact writes; worker time includes them. Outputs and receiptJSON are retained in each job; no speed or memory claim.

| Job | Import ms | cold/repeat/edit elapsed ms | peak RSS KiB | post-GC RSS MiB (c/r/e) | post-GC heapUsed MiB (c/r/e) |
|---|---:|---|---:|---|---|
| agentic-cache0-before | 450.8 | 192.18/35.87/40.32 | 110316 | 98.64/102.86/107.10 | 16.10/17.52/18.61 |
| agentic-cache0-current | 550.7 | 298.38/61.11/77.07 | 107668 | 97.52/98.89/104.51 | 16.11/17.49/18.61 |
| agentic-cache1-before | 531.5 | 328.92/47.67/70.09 | 107880 | 96.68/102.05/104.72 | 16.15/17.27/18.23 |
| agentic-cache1-current | 786.9 | 287.72/44.24/79.77 | 107972 | 96.48/100.07/104.81 | 16.20/17.26/18.26 |
| elk-cache0-current | 542.7 | 1116.80/240.35/116.36 | 148604 | 133.54/138.78/144.07 | 34.96/37.15/38.56 |
| elk-cache1-current | 2953.9 | 4417.00/46.20/132.05 | 147228 | 133.21/136.46/139.92 | 35.01/35.68/38.02 |

All six own-cold/repeat whole SVGs and ENTIRE raw receipt strings match exactly. All same-arm phases also match exactly across cache0/cache1. Cache0 positioned-layout bypasses throughout; ELK additionally bypasses elk-layout. Cache1 positioned-layout is miss/hit/miss for cold/repeat/edit in every job; ELK layout is miss/absent-on-positioned-hit/miss. Native drawing and paint certification remain misses on every phase: the positioned hit still draws and certifies.

The edit adds one literal A8 logical line; its visible text occurs once (zero before), every edit SVG changes, and viewport height rises 16.9 px: old AM438.4→455.3, current AM320.1→337, ELK320.1→337. No caption loss/alias is inferred from proof alone. Proof operations c/r/e: old AM97825/97825/98574; current AM97331/97331/98489; ELK98335/98335/99493.

Post-GC current-minus-before RSS/heapUsed byte deltas (cold/repeat/edit):
cache0: cold RSS -1175552, heap +8266, repeat RSS -4153344, heap -24213, edit RSS -2715648, heap +3811.
cache1: cold RSS -208896, heap +52220, repeat RSS -2076672, heap -5576, edit RSS +90112, heap +30237.

Costs remain mixed/adverse. AM cache0 every phase is slower; cache1 timing is not a repeatable speed finding. Peak RSS is mixed, post-GC heaps retain small adverse cold/edit deltas, and outputs are retained in memory across phases. These observations establish neither a memory improvement nor a causal slowdown.

ELK cache1 worker wall8.238463s includes import2953.896ms, cold4416.996ms, repeat46.203ms, edit132.051ms. Cold stage layout4053.552ms includes nested ELK3820.769ms (do not sum both); other top-level drawing123.384ms, paint151.145ms, request68.843ms, security1.401ms. This locates recorded stage wall time but does not identify the cause of the adverse run. Remaining worker wall includes process/GC/artifact work and is not separately attributed. ELK has no paired before/current cost arm.

Unedited geometry value (same fixed source): current AM area165355.6575 / wire463.4375 /8bends versus old AM226466.48 /700.0375 /8 and ELK176727.21 /396.469666666 /8. Current AM gains area versus ELK while retaining longer wire. This is layout quality evidence, not a runtime ratio.

Agentic cache0 adverse stage attribution (recorded wall milliseconds; before→current; nested agentic is included in layout, not additive):

| Phase | Consumed elapsed | Request | Layout | nested Agentic | Drawing | Paint | SVG security | Other elapsed |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| cold | 192.18→298.38 | 13.98→38.29 | 66.93→90.50 | 3.95→5.50 | 79.86→138.87 | 22.80→18.85 | 1.48→2.20 | 7.13→9.67 |
| repeat | 35.87→61.11 | 2.29→3.63 | 10.75→20.69 | 0.14→0.20 | 15.65→25.88 | 3.41→4.63 | 0.94→1.69 | 2.83→4.59 |
| edit | 40.32→77.07 | 2.72→3.47 | 18.66→26.25 | 0.15→0.67 | 12.20→34.99 | 3.21→7.71 | 1.25→1.88 | 2.29→2.76 |

Cold elapsed grows106.20ms, mainly drawing+59.00ms, request+24.30ms and layout+23.57ms (nested Agentic+1.55ms), while paint decreases3.95ms. Repeat grows25.24ms: layout+9.94ms and drawing+10.23ms dominate, with nested Agentic only+0.061ms; paint+1.22ms and request+1.33ms. Edit grows36.75ms, mainly drawing+22.79ms, layout+7.60ms and paint+4.50ms; nested Agentic+0.517ms.

These are observed stage wall locations, not CPU attribution or a causal explanation. Drawing is the recorded public drawing stage; it is not an isolated Scene-lowering measurement. Residual elapsed includes work outside recorded stages (including full-product consumption). Instrumentation does not attribute GC/scheduling, and this N1 run cannot explain the extra time as private band-array work. No speed or memory claim.
