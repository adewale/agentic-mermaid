import fs from 'node:fs'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {gzipSync,gunzipSync} from 'node:zlib'
import {createRequire} from 'node:module'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
const {JSDOM}=createRequire(import.meta.url)('/tmp/pr449-main-integration-20261029-762/node_modules/jsdom')
if(process.argv[2]!=='GO')throw Error('HOLD: root GO required for six offline rasters')
const root='/tmp/pr449-main-integration-20261029-762',base='/tmp/pr449-week-comparison-20261101/forest-independent-bands-7299495bc',scratch=fs.mkdtempSync('/tmp/pr449-fit-fonts-');let dir=base
const rows=[]
const save=(name,value)=>fs.writeFileSync(`${dir}/${name}.gz`,gzipSync(typeof value==='string'||value instanceof Uint8Array?value:JSON.stringify(value,null,2)))
try {
 const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter'),fontFiles=fonts.map(f=>{const b=fs.readFileSync(`${root}/${f.path}`);assert.equal(b.length,f.bytes);assert.equal(createHash('sha256').update(b).digest('hex'),f.sha256);const p=`${scratch}/${f.file}`;fs.writeFileSync(p,b);return p})
 for(const arm of ['agentic','after-agentic','elk']){
 dir=base+'/ink-'+arm;fs.mkdirSync(dir,{recursive:true})
 const raw=gunzipSync(fs.readFileSync(base+'/'+arm+'/TB.svg.gz')).toString(),dom=new JSDOM(raw,{contentType:'image/svg+xml'}),d=dom.window.document
 const expectedLines={A:['A0','A1','A2','A3','A4','A5','A6','A7'],B:['Branch B'],C:['Branch C'],D:['Root D'],E:['E0','E1','E2','E3','E4','E5','E6','E7'],F:['Branch F']}
 const cards=[...d.querySelectorAll('g.node')],expectedPairs=[['A','B'],['A','C'],['D','E'],['D','F']]
 assert.deepEqual(cards.map(c=>c.getAttribute('data-id')),Object.keys(expectedLines))
 const boxes=new Map()
 for(const card of cards){const id=card.getAttribute('data-id'),rect=card.querySelector('rect');assert(rect);boxes.set(id,['x','y','width','height'].map(k=>+rect.getAttribute(k)));assert.deepEqual([...card.querySelectorAll('text')].flatMap(t=>{const spans=[...t.querySelectorAll('tspan')];return(spans.length?spans:[t]).map(s=>s.textContent.trim())}),expectedLines[id])}
 const physicalEdges=[...d.querySelectorAll('[data-role="edge"][data-from]')];assert.deepEqual(physicalEdges.map(e=>[e.getAttribute('data-from'),e.getAttribute('data-to')]),expectedPairs)
 let normalContacts=0,wire=0,bends=0
 for(const edge of physicalEdges){const points=edge.getAttribute('points').trim().split(/\s+/).map(p=>p.split(',').map(Number));for(const [id,p,q]of[[edge.getAttribute('data-from'),points[0],points[1]],[edge.getAttribute('data-to'),points.at(-1),points.at(-2)]]){const[x,y,w,h]=boxes.get(id),dx=q[0]-p[0],dy=q[1]-p[1],eq=(a,b)=>Math.abs(a-b)<1e-6;assert(dy===0&&p[1]>y&&p[1]<y+h&&(eq(p[0],x)&&dx<0||eq(p[0],x+w)&&dx>0)||dx===0&&p[0]>x&&p[0]<x+w&&(eq(p[1],y)&&dy<0||eq(p[1],y+h)&&dy>0));normalContacts++}for(let i=1;i<points.length;i++){assert(points[i][0]===points[i-1][0]||points[i][1]===points[i-1][1]);wire+=Math.hypot(points[i][0]-points[i-1][0],points[i][1]-points[i-1][1]);if(i+1<points.length&&(points[i][0]-points[i-1][0])*(points[i+1][1]-points[i][1])!==(points[i][1]-points[i-1][1])*(points[i+1][0]-points[i][0]))bends++}}
 const sv=d.documentElement,width=+sv.getAttribute('width'),height=+sv.getAttribute('height'),margin=10,zoom=2,ew=width+20,eh=height+20
 const edges=[...d.querySelectorAll('polyline.edge[data-id]')];assert.equal(edges.length,4)
 const rois=edges.map(edge=>{const id=/^url\(#([^)]*)\)$/.exec(edge.getAttribute('marker-end'))?.[1];assert(id);const marker=d.getElementById(id);assert(marker);assert.equal(marker.getAttribute('orient'),'auto');assert(!marker.hasAttribute('viewBox'));const unit=marker.getAttribute('markerUnits')??'strokeWidth';assert.equal(unit,'strokeWidth');assert.equal(+marker.getAttribute('refX'),8);assert.equal(+marker.getAttribute('refY'),2.5);const poly=marker.querySelector('polygon');assert(poly);assert.equal(poly.getAttribute('points'),'0 0, 8 2.5, 0 5');assert.equal(poly.getAttribute('stroke-linejoin'),'round')
  const pts=edge.getAttribute('points').trim().split(/\s+/).map(p=>p.split(',').map(Number)),p=pts.at(-1),a=pts.at(-2),dx=p[0]-a[0],dy=p[1]-a[1],len=Math.hypot(dx,dy);assert(len>0&&(dx===0||dy===0));const ux=dx/len,uy=dy/len,scale=+edge.getAttribute('stroke-width'),half=+poly.getAttribute('stroke-width')/2
  const corners=[[-8-half,-2.5-half],[half,-2.5-half],[-8-half,2.5+half],[half,2.5+half]].map(([x,y])=>[p[0]+scale*(x*ux-y*uy),p[1]+scale*(x*uy+y*ux)])
  return{id:edge.getAttribute('data-id'),from:edge.getAttribute('data-from'),to:edge.getAttribute('data-to'),endpoint:p,normal:[ux,uy],roi:{x0:Math.min(...corners.map(c=>c[0]))-1,y0:Math.min(...corners.map(c=>c[1]))-1,x1:Math.max(...corners.map(c=>c[0]))+1,y1:Math.max(...corners.map(c=>c[1]))+1},changed:0,darker:0,lighter:0}
 })
 dom.window.close()
 const expanded=raw.replace(/width="[^"]+"/,`width="${ew}"`).replace(/height="[^"]+"/,`height="${eh}"`).replace(/viewBox="[^"]+"/,`viewBox="-10 -10 ${ew} ${eh}"`),mask=expanded.replace(/ marker-end="url\(#[^)]+\)"/g,'');assert.notEqual(mask,expanded)
 const images=[expanded,mask].map((svg,i)=>{const rendered=new Resvg(inlineFontVarForRaster(svg),{background:'#ffffff',fitTo:{mode:'zoom',value:zoom},font:{fontFiles,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render();save(`marker-${i?'mask':'full'}.svg`,svg);save(`marker-${i?'mask':'full'}.png`,rendered.asPng());return{width:rendered.width,height:rendered.height,pixels:rendered.pixels}})
 const [a,b]=images;assert.equal(a.width,b.width);assert.equal(a.height,b.height);let changed=0,unattributed=0,borrowed=0,outsideViewport=0,fullDarkOutsideViewport=0
 for(let y=0;y<a.height;y++)for(let x=0;x<a.width;x++){const p=(y*a.width+x)*4,wx=(x+.5)/zoom-margin,wy=(y+.5)/zoom-margin,outside=wx<0||wx>width||wy<0||wy>height;if(outside&&Math.min(a.pixels[p],a.pixels[p+1],a.pixels[p+2])<245)fullDarkOutsideViewport++;if(![0,1,2,3].some(k=>Math.abs(a.pixels[p+k]-b.pixels[p+k])>=4))continue;changed++;if(outside)outsideViewport++;const owners=rois.filter(r=>wx>=r.roi.x0&&wx<=r.roi.x1&&wy>=r.roi.y0&&wy<=r.roi.y1);if(!owners.length){unattributed++;continue}if(owners.length>1)borrowed++;for(const owner of owners){owner.changed++;if(a.pixels[p]+a.pixels[p+1]+a.pixels[p+2]<b.pixels[p]+b.pixels[p+1]+b.pixels[p+2])owner.darker++;else owner.lighter++}}
 const headRoiOverlaps=[];for(let i=0;i<rois.length;i++)for(let j=0;j<i;j++){const a=rois[i].roi,b=rois[j].roi;if(a.x0<b.x1&&a.x1>b.x0&&a.y0<b.y1&&a.y1>b.y0)headRoiOverlaps.push([rois[j].id,rois[i].id])}
 const report={arm,authoredIDs:6,logicalTextLines:20,orderedRelations:4,normalContacts,area:width*height,wire,bends,headRoiOverlaps,fullDarkOutsideViewport,publicCalls:0,offlineRasterCalls:2,source:arm+'/TB.svg.gz',svgSha256:createHash('sha256').update(raw).digest('hex'),controls:rois,changed,unattributed,borrowed,outsideViewport,withoutPositiveInk:rois.filter(r=>!r.darker).map(r=>r.id),fonts:fonts.map(f=>({file:f.file,bytes:f.bytes,sha256:f.sha256})),scope:'Exact saved six-node independent-band forest final SVG; remove marker-end from all4 carriers and attribute changed pixels to independently transformed actual arrow resource bounds. Positive per-head differential ink only, with overlap/unattributed/negative observations retained. No individual glyph, universal font, browser, timing, complete Native proof or arbitrary input claim.'};rows.push(report);save('marker-ink.json',report);console.log(JSON.stringify({...report,controls:rois.map(r=>({id:r.id,darker:r.darker,lighter:r.lighter})),fonts:undefined}))
 }
 fs.writeFileSync(base+'/independent-ink-summary.json',JSON.stringify({publicCalls:0,publicLayoutCalls:0,offlineRasterCalls:6,rows,scope:'Three saved public SVGs only; actual source/card/caption correspondence and independent rectangular outward contacts plus pinned-Inter head-removal ink. This is not a font/browser-universal or runtime/capacity claim.'},null,2))
}finally{fs.rmSync(scratch,{recursive:true,force:true})}
