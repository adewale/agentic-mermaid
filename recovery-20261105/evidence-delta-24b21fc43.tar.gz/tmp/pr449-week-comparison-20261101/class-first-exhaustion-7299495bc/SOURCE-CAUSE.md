# Class128 TB first-exhaustion attribution

Runtime revision:7299495bca8fa0a78dcc9770a23d9a0ecd313f5e; production unchanged.
Exactly one Agentic and one ELK public SVG/entire-receipt call, same1585-byte source
and options except backend (fallback:none, embedFontImport:false; spacing/prefix omitted).
Both return byte-identical189921-byte SVG and U400000/53marker entries/1520pairs.
The entire raw Agentic receipt AND SVG match retained f1e TB bytes exactly;
this validates nominal instrumentation behavior, not a new improvement.

Both: admission capture357300 +1024 receipt visits×16 =373684 before paint checks
(93.421% of400000). Marker preparation begins381712. The first refused work()
occurs in markerPaintIdentity's paid own-paint field-copy loop, marker ordinal52,
with exhaustedBefore:false. Later actual backend root pay(4) sees exhaustedBefore:true;
OUTPUT_SCOPE is downstream, not the first cause. This is shared emission/proof work,
not a demonstrated backend geometry or visible author-meaning loss. The capped result
cannot determine the full remaining work or justify a smaller fee/cap. Existing
written contour reuse is active; no sufficient safe small subtraction established.

Scene ledger categorization caveat: admission:context-or-recorder also counts the
42700 proof-continuation synchronization before emitting=true. True capture is357300;
do not add every ledger stage and call that admission cost.

Observer source disclosure: preparation changed after the initial READY: worker gained
existsSync/result-exists guard; serialization observer removed only proofBudgetIssue
(.some over proof issues) from its continuation record. Paint instrumentation unchanged.
Agentic stack uses worker line36; ELK line37. The first versions were not snapshotted
before that edit; the explicitly named *agentic*-reconstruction files reproduce the
reported edits from root's pre-execution worker read and the author's disclosure, not
an original byte-custody claim. Final ELK observer/worker copies are retained separately.
All production work/pay conditions, fees, caps and returns remained unchanged.

Diagnostic costs (observers/artifacts/GC included; N=1, no performance ratio):
Agentic render window613.909ms, peakRSS154600KiB, postGC heap22401340B;
ELK1559.386ms,223796KiB,44567176B. Actual public calls2; no layout/raster/build/Node
or broad-test calls. Complete products, stacks, observers and failed charges retained.
No capacity failure closed, no new qualification gate/framework or runtime change.
