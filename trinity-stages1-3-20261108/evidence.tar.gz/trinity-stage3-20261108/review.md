# Trinity stages1–3: independent scope/value review

Read-only review of c76dde5b3, bf48cee97 and the current stage3 extraction.
No production edits, tests, builds, frameworks, agents or external actions.
**No demonstrated existing-path semantic regression found.** The extraction
provides a useful dependency boundary; it is not a measured quality/speed gain
or a completed Trinity implementation.

## Preservation findings

- The neutral module has type-only dependencies. Native loop/search controls
  and result topology/work fields remain on its private extensions rather than
  entering the shared contract. Existing runtime JSON/cache inputs are not
  rewritten merely by moving these types.
- Requirement still measures its cards/labels once. Its ELK mapping preserves
  root/edge/node IDs, all layered options, terminal spacing, label text/dimensions,
  empty-graph extents and ordered section/anchor extraction. Native capacity
  growth is published only after a successful solve, preserving untouched ELK
  fallback dimensions. The new common solve owns role/count/extent checks, while
  existing family completion and paint certification remain in place.
- Selection/fallback still runs through the existing backend owner. Deferred
  dependency, invalid producer geometry and typed capability declines retain
  distinct behavior; no broad catch was added. The ELK adapter conservatively
  declines groups, nondefault ordering/port/paint constraints, invisible/long
  edges and other unsupported neutral fields instead of silently translating
  them away. Its placement return still incurs ELK internal routing; no avoided
  work claim is justified by that result tag.
- Static comparison confirms stage3's complete pipeline/context/guards/state-note
  block is unchanged after the helper-export and retainGraphText relocation.
  finishGraphGeometry is byte-exact after its export modifier. groupTitleWidth,
  groupHeaderHeight and retainGraphText are likewise unchanged. Thus pass order,
  enabled predicates, centering rollback, freeze/mutation guards, shared-route
  ownership, note translation, text authority and final bounds stay together.
- Root reexports preserve the existing LAYOUT_PIPELINE object identity and
  LayoutPassContext spelling. Producer binding helpers refer to the same moved
  functions. Direct completion/pass/measurement imports have no runtime back-edge
  to layout-engine in the inspected paths. Text measurement still runs under
  the existing captured font/profile context; this move adds no getter, cache
  or fallback owner.

## Stage4 boundary limits

Stage4 can proceed as an explicitly bounded opt-in implementation against these
seams. It cannot honestly claim the full proposed contract is already enforced:

1. `solveMeasuredLayout` checks role, subject counts and finite nonnegative canvas
   extent. It does not yet validate finite node/group coordinates, route points,
   label anchors or endpoint/index correspondence. A finite extent with NaN node
   coordinates currently passes that common check. Current family completion
   still owns later certification, so this is a future-adapter boundary limit,
   not a demonstrated new Requirement output defect. Before allowing a new
   result to bypass legacy repairs, make the actual completed-geometry owner
   reject invalid output as a producer defect, without relabelling it unsupported
   or executing a silent fallback.
2. The extracted neutral shape is a starting subset. Explicit fixed-size/growth
   permission, shape contact domains/unknowns, returned port assignments and
   shared work-context handoff from the specification are not all encoded yet.
   Implement only the next slice's required distinctions and decline the rest;
   do not describe opaque rectangle boxes or a routed result tag as final paint
   completion. Preserve family-owned label/marker and physical contact checks.
3. The legacy completion leaf is available separately, but existing producers
   still use it. Extraction alone does not establish a safe Trinity bypass.
   The first actual kernel product must close a retained ink deficit while
   preserving the stopped adverse controls and all meaning/cap/cost limits.

The coordinator reports847owning tests passing and corrected types. The retained
bounded editor build reports exit0, but this reviewer did not rerun it or infer
payload/speed improvement from the file move. The1748-product equality pass is
still coordinator-owned qualification; pending evidence is not a completed
outcome. No extra public backend/default, quota, cache, runtime plugin registry
or generic state framework is justified by stages1–3.
