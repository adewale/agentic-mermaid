import { readFileSync, writeFileSync } from 'node:fs'
import { renderMermaidSVGWithReceipt } from '/tmp/pr449-main-integration-20261029-762/src/index.ts'
const fixture=readFileSync('/tmp/pr449-main-integration-20261029-762/eval/layout-compare/fixtures/requirement-backends.mmd','utf8')
const results=[]
for(const direction of ['TB','BT','LR','RL']) for(const backend of ['agentic','elk'] as const) for(const variant of ['fixture','parallel','empty']) {
 const source=variant==='fixture'?fixture.replace('direction TB',`direction ${direction}`):variant==='empty'?`requirementDiagram\ndirection ${direction}`:`requirementDiagram\ndirection ${direction}\nelement root {\n type: software\n}\nrequirement leaf {\n id: R1\n text: Dispatch 漢🙂\n}\nelement side {\n type: service\n}\n${Array(4).fill('root - contains -> leaf').join('\n')}\nroot - contains -> side`
 try {const product=renderMermaidSVGWithReceipt(source,{graphLayout:{backend,fallback:'none'}}); results.push({direction,backend,variant,product})} catch(error){results.push({direction,backend,variant,error:String(error)})}
}
writeFileSync(process.argv[2]!, JSON.stringify(results))
