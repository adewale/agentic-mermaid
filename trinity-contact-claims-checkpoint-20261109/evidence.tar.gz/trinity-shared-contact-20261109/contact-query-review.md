# Shared contact query: bounded causal review

Source `3f2c26bd860eadcfb48746eabb45801ab8e07c7a`; retained evidence under `joint-caption-dd365` and `forest-placement-deafff`. Read-only source/JSON inspection, no source edits, rendering, builds, tests, profiling, network or new agents.

**One concrete preparation mismatch merits a narrowly counted causal probe: each node query recreates the same two-point shaft array, defeating the already-existing shaft memo inside one immutable proposal.** Reuse one call-local segment representation in that proposal; do not introduce a cross-proposal cache, broaden the circle-only domain, change ordering, or retry frame expansion. Dynamic savings and actual public-output improvement remain unmeasured.

## Exact owner and subtraction

`src/layout/passes/obstacle-routing.ts:89–97` defines `blockedBy(a,b,node)` and invokes `paintedContact(currentEdge, [a,b], node)` after the existing shape check. `throughNode` visits nodes first, then segments. Thus the same unchanged segment is packaged into a new array for each node query.

`src/layout/graph-paint-support.ts:88–89,110–139` already retains shafts by edge and **points-array identity**. The fresh wrapper misses that existing memo on every eligible circle. Its repeated work includes paint eligibility, written numeric point formatting, finite/orthogonal checks and construction of the same butt-cap strip. For a supported two-point segment the explicit preparation charges are 8 + (2×8+8) = **32 units**. The later two-unit query entry and four-unit strip/circle predicate are distinct obligations and must remain for every query.

Smallest prospective shape: for a single `throughNode` candidate, retain a bounded roster of stable two-point segment views for the existing context's memo, materialized only where the original path needs painted contact. Preserve node-major/segment-minor query order, short-circuit behavior and all charges for actual work/roster creation. Retire the roster when that candidate query ends. This is finite call-local geometry preparation, not a new keyed cache, verdict memo, or quota. Existing full-route memo behavior stays intact.

Do **not** replace the segment query with the full-route paint query: the latter also constructs miter-join squares, while the current two-point query deliberately checks a butt-capped segment. Preserve that distinction, endpoint exclusions, CSS/unknown eligibility and undefined-on-exhaustion behavior. The reuse boundary must contain no node/style/point writes or host callbacks capable of mutating them. If that cannot be established for a caller, retain its fresh preparation path rather than assuming object identity is immutability. Publication still goes through `graphInkClear`, marker/caption/header checks, `commitReroutedEdge` and final actual-write proof.

## Retained evidence and honest ceiling

The exact final failure is real paint: `forest-placement-deafff/shaft-card-152/INK.json` and its independent review bind the original SVG SHA256 `960d89b522ab5441cd28e55c624441e2223c9443ccf1d7f50b238c2582790515` to 183 exposed shaft pixels, 61 contributing with the card, and 122 fully hidden. `joint-caption-dd365/INK.json` binds the stopped repair SVG `374e964bbaea4b6ae3c610c60cb450b0e4693a2a0d3110bd4e44700bb0fdfe5c` to zero hidden pixels. `STOP-REGRESSION.json` records why that actual repair was reverted: five P→U regressions and new circle/shaft overlaps. Reordering the same ledger restores two controls but leaves152 unchanged.

The retained `phase152/actual.receipt.json.gz` is unverified with `edge:n16->n12#0` versus `node-shape:n4`, 353,905 operations of400,000. **That is the final paint-proof counter, not the optional contact-exploration ledger and not proof-cap exhaustion.** The contact ledger is separately `graphInkWork()` =8,192 units (`label-conflicts.ts:202–203`). These counters must not be added or interpreted as interchangeable headroom.

`joint-caption-dd365/context.json` contains three circles (n1,n7,n13); candidate edge16 is n16→n12, so its endpoint exclusions remove none of them. The retained LANES candidate has six points/five segments. A complete clear painted scan of those five segments against all three circles would perform ten redundant segment preparations: **320 gross charged units**, before roster overhead, if every query reaches that branch. This is a conditional source-derived ceiling for that scan, not a measured execution count or saving. Early geometric rejection can reduce it sharply, and current SHA152's offending rectangle remains outside the circle-only detector.

`LANES.json` reports accepted gap4/8 isolated proposals leaving7,220 of8,192 units (972 spent); the smaller-gap and caption alternatives have different refusals. `372-ledger-trace.log` records late budgets278/926/358 and a detection at288, demonstrating tight remaining work, but it does not count this wrapper-induced duplication. Neither record proves sufficient headroom for the stopped frame repair. Count exactly these repeated preparations in the current public path before an implementation decision.

## Smaller duplicate rejected as the next task

`graphInkClear` prepares an `edgeInk` support map (`label-conflicts.ts:214–218`) and then `preservesLabelInkSeparation` makes another map (`:137–150`). The proposed edge is prepared twice inside one publication attempt. Reusing its existing accessor is possible, but the retained six-point/one-marker proposal duplicates only roughly six charged support units versus972 total. That is a genuine small duplication, not a plausible explanation of the broader resource failures; it is not the selected intervention.

## Stop condition

First establish a nontrivial repeated-preparation count on current supported circle work, with unchanged query decisions and fewer real charged operations. Stop if memo-hit opportunities are rare, roster overhead erases savings, or immutable lifetime cannot be proved. Even success does not close152: retain its current unsupported repair domain and adverse outcomes until separate actual SVG/ink evidence establishes a safe repair under unchanged caps. No helper-pass result should be reported as restored visible contact.

## Follow-up: stop the preparation proposal; SHA152 already has a later repair

The current `PREPARATION-COUNTS.json` falsifies the proposed workload connection. Across warmup, two repeats and the same-input “edit”, SHA152 has 468 preparation events and SHA372 has 396, but **zero preparations inside the scoped painted-repair two-point path and zero duplicate preparations there**. Trace and fresh baseline SVGs and entire receipts match for all recorded comparisons. The gross saving ceiling for this proposal on these executions is therefore zero. Do not implement it or resume the old frame-expansion/strategy-order trials. The earlier 320-unit calculation was conditional, not an observed opportunity; it has no current causal support. The work log also records an earlier stopped two-point staging probe (111→68 constructions, exact output), so this should not be presented as a new optimization discovery.

The apparent SHA152 discrepancy is explained by a **later committed geometry repair**, not evidence of a Node-versus-Bun floating-point problem. `weighted-face-780/INK152.json` already contains the exact two geometries now being compared:

| Retained arm | SVG SHA256 | Shaft x | Card n4 x | Selected exposed / visible / hidden pixels |
| --- | --- | ---: | ---: | --- |
| Before | `960d89b522ab5441cd28e55c624441e2223c9443ccf1d7f50b238c2582790515` | 293.172 | 293.224 | 183 / 61 / 122 |
| After | `211c322ee2d3710fc97286e6143909b156bf79cb1e1c102e0d4bcc4e05da6e0f` | 287.224 | 293.224 | 183 / 183 / 0 |

The after arm also has zero attenuated pixels. These are retained manifest-font, 2×, four-mask measurements of the selected border interval, not whole-graph visibility findings. `weighted-face-780/SHA-INK-BINDING.json` records exact ink-SVG binding for case152. The current coordinator-reported warmup SHA prefix and literal geometry match that repaired arm; transfer its ink result only after binding the **entire current SVG hash**, not merely its proof status or prefix. The fresh current masks remain the coordinator's responsibility.

The source owner is commit `3b737e930c2673638db20a3ccea32bc415309a31` (“Seat crowded endpoint paint and retain shortening clearance”), whose original evidence-era identity is `62d521fbce155cdd3de928ec62fc5222fa3a8482`. The current history for `src/layout/shorten-measured-routes.ts` retains that change. The diff introduces `input.nodeClearance`, expands only foreign-node shaft obstacles, leaves endpoint bodies and caption seating constraints intact, and rejects shortcuts crossing those expanded obstacles. Current ownership is:

- `src/layout/measured-graph-producer.ts:284–305`: derive margin from measured node half-stroke plus maximum edge half-stroke; supply `nodeClearance: margin` for the eligible Native path when numeric clearance is known.
- `src/layout/shorten-measured-routes.ts:28–29,46–66,94`: read and validate that clearance, charge bounded foreign-box preparation, preserve own endpoints, and test shortcut segments against the prepared foreign obstacles.
- `src/layout/agentic-producer-core.ts:99,106`: apply this shortener before the subsequent projection/completion path.
- `docs/design/system/layout-0.6-work-log.md:661–686`: explicitly records the joint candidate's SHA152 selected-shaft **122 hidden→0** result and its owning corpus qualification.

This is different from the earlier stopped shortcut-clearance trial and the stopped later shared painted-frame expansion. The retained committed joint candidate is the relevant historical transition. No new bisect was run here, so this review attributes the demonstrated repair to that retained joint change rather than claiming isolated experimental attribution to one line. An unchanged `agentic-layered@28` receipt identifier does not imply identical producer/shortener/completion code.

Current `bun-controls.log` independently records both cases returned with proof passed on both Bun1.4.4 calls, agreeing with Node24 on proof outcome. Exact cross-runtime SVG/receipt equivalence is not established by that log alone. There is no positive evidence here for a runtime-conditional or floating-point-order explanation. SHA372's historical transition is not attributed by this SHA152 finding. The old contact evidence remains valid for its old artifact, but it must not be carried forward as a current SHA152 failure.

This addendum uses only existing source/history/evidence reads. No new renderer, profile, test, build, or experiment was run; production source was untouched.
