# Independent reconciliation of stale contact-loss claims

Read-only review of current work-log lines 661–686, retained weighted-face-780 evidence/reviews, current shared-contact manifests and present campaign wording. No implementation, tests, renders, profiles, builds, network or new agents. No new optimization or visible-fix credit belongs to this reconciliation.

**Finding: the blanket present-tense claim “Native contacts 152/372/201/241 remain” is stale and must be qualified.** It appears in docs/design/system/trinity-layout.md:250 and the frozen-cost README decision paragraph. Retain dated original failures as historical evidence; correct current campaign/PR claims by source/input/artifact rather than deleting the old observations.

## Correct classification

| Exact case / evidence | What is established | Current wording |
| --- | --- | --- |
| SHA152 selected shaft/card interval | Committed joint repair removes the historical selected loss. Current recorded full SVG SHA matches the retained repaired arm; fresh current four-mask evidence has 183 exposed / 183 visible / 0 hidden / 0 attenuated pixels. | Selected historical contact is repaired and currently reconfirmed. Not an open current 152 loss and not a new fix from this run. |
| Base SHA201 and SHA241 selected heads | weighted-face-780 and committed work log record each selected head's hidden/attenuated contribution 4/12 → 0/0. | Previously repaired by the committed joint change. Bind entire current SVGs to these retained after artifacts before transferring their selected ink qualification to a fresh current capture. |
| Oversubscribed SHA201 plus three invisible constraints | Explicitly retained as open in the same final work log and stopped PR body. It changes endpoint incidence/capacity and is not the base SHA201 input. | Keep as the separate named remaining variant; never use its open status to relabel every SHA201 base drawing as still broken. Current variant outcome needs its own source/options/artifact binding. |
| SHA372 | Fresh Node/Bun calls return/proof passed according to current captures; actual selected ink qualification is pending. No historical transition is attributed by the SHA152 finding. | Current proof passed; visible-contact status unqualified pending current ink evidence. Neither a demonstrated present contact failure nor a proven visible repair from proof alone. |
| Other U→U/current unknown cases | The committed 874-input replay and retained stop note leave these distinct. | Keep unknown/open cases explicit. Do not extrapolate selected fixes or passed receipts to the whole contact domain. |

The source owner is `3b737e930c2673638db20a3ccea32bc415309a31` (“Seat crowded endpoint paint and retain shortening clearance”), originally evidenced as `62d521fbce155cdd3de928ec62fc5222fa3a8482`. Work-log lines 661–686 document both responsibilities: endpoint packing clears selected crowded heads; the shortener retains known numeric foreign-node clearance and clears the selected shaft interval. The current run did not introduce these changes. The full 874 replay recorded 76 U→P, zero P→U and zero delivery changes; that is proof coverage, not 76 independently observed visible repairs.

## SHA152 artifact binding and exact scope

Current `152-INK.json` records full SVG SHA256 `211c322ee2d3710fc97286e6143909b156bf79cb1e1c102e0d4bcc4e05da6e0f`, identical to the after row in weighted-face-780/INK152.json. The historical before artifact is `960d89b522ab5441cd28e55c624441e2223c9443ccf1d7f50b238c2582790515`, with 183 exposed / 61 visible / 122 hidden pixels. Both after manifests show zero hidden/attenuated selected shaft pixels, and the actual shaft moves from x293.172 to x287.224 beside the same card x293.224. The fresh current ROI is narrower than the historical ROI, so do not call the mask image bytes identical; the recorded full SVG binding and independently repeated selected contribution are the relevant facts.

These are manifest-font, system-font-disabled, 2× selected-interval observations. They do not establish whole-graph readability, all marker visibility, whole-scene parity or generic proof completeness. Node/Bun proof agreement alone is not cross-runtime SVG equality; the coordinator separately reports actual SVG equality. The current retained JSONs inspected here support the selected hash/mask claim, not an independently rerun rasterization by this reviewer.

## Pending base SHA201/241 current binding

At this review, the coordinator's new base201/241 current captures were not yet present in the shared-contact directory. Do not infer fresh current hashes from a receipt producer identifier, proof P, a short hash prefix, similar geometry, or the separate oversubscribed variant. The retained weighted-face after artifacts already establish the historical committed repair. Once current base captures arrive, compare the entire SVG bytes/full artifact hashes with those exact retained after arms and preserve source/options/selected occurrence identity. Equality can carry the retained same-artifact selected ink evidence; inequality requires its own current observation before a current closure claim. This is normal evidence attribution, not a new acceptance framework or permission gate.

## Suggested current campaign wording

“Committed endpoint packing/shortening already repaired the selected base SHA201/SHA241 head contacts and SHA152 shaft/card contact. Current3f2 SHA152 matches the repaired full SVG and its fresh selected masks retain all 183 exposed pixels, with none hidden or attenuated. Current SHA372 returns with proof passed; actual ink qualification is pending. Current base201/241 artifact binding is pending. The oversubscribed SHA201 + three invisible constraints and other unqualified drawings remain separate open/unknown cases.”

Replace the pending sentence with exact source-bound results when those captures are available. Credit the original committed repair, not this documentation correction. Append a dated correction to immutable historical report context rather than pretending the original captured failure never happened.

## Stopped optimization and unchanged decision

PREPARATION-COUNTS.json records zero scoped two-point preparations and zero duplicate preparations for both current152 and372 across the four traced phases, with baseline/trace SVG and entire receipt equality. The proposed current-workload subtraction therefore has a zero observed gross saving ceiling and stays stopped. Aggregate preparation counts elsewhere are not evidence for the proposed path. No new code/probe should be justified by carrying the stale loss roster forward.

Correcting these claims does not resolve the oversubscribed variant, pending/current unknowns, crossing/resource losses, Sparse32, failed CI, bundle cap or replacement readiness. Retain the draft/default/version/cap decisions. The value is an accurate current counterexample inventory that directs further work only after known counters and their exact artifacts have been reconciled.
