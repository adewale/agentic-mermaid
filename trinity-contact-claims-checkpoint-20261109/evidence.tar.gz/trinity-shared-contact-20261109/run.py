from pathlib import Path
import json,os,subprocess
out=Path(__file__).parent;rows=[]
for case in ['152','372']:
 for mode in ['baseline','trace']:
  name=case+'-'+mode
  with (out/(name+'.log')).open('w') as log:r=subprocess.run(['node','--expose-gc',str(out/('worker.mjs' if mode=='baseline' else 'trace-worker.mjs')),str(out/name),str(out/(name+'-job.json'))],env={**os.environ,'AGENTIC_MERMAID_ELK_CACHE':'0'},stdout=log,stderr=subprocess.STDOUT)
  row={'case':case,'mode':mode,'exit':r.returncode};rows.append(row);print(row,flush=True)
  if r.returncode:break
(out/'RUNS.json').write_text(json.dumps({'source':'3f2c26bd860eadcfb48746eabb45801ab8e07c7a','runs':rows,'scope':'Two namedNativepaint failures; actualcompleteSVG+receipt, oneunprofiledwarmup and3profiledidentical originals perprocess. Inheritedphaseedit is sameinput, notanedit. Baselinesamplingbeforeanyoptimization. Traceoverrides onlycount prepidentity/coordinates; traceelapsednotusedforperformance.'},indent=2)+'\n')
