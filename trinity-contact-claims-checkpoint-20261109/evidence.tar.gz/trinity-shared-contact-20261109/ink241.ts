import {readFileSync,writeFileSync} from 'node:fs'
import {gunzipSync} from 'node:zlib'
import {createHash} from 'node:crypto'
import {Resvg} from '/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js'
import {HOSTED_FONT_RESOURCES} from '/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts'
import {inlineFontVarForRaster} from '/tmp/pr449-main-integration-20261029-762/src/theme.ts'
import {prepareResvgMarkerOrientation} from '/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts'
const repo='/tmp/pr449-main-integration-20261029-762',root='/tmp/pr449-week-comparison-20261101/trinity-shared-contact-20261109'
const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const p=repo+'/'+f.path;if(createHash('sha256').update(readFileSync(p)).digest('hex')!==f.sha256)throw Error('font mismatch');return p})
const rows=[]
for(const [num,target,selected,peer] of [[241,'n3','edge:n13-&gt;n3#0','edge:n2-&gt;n3#0']] as const) for(const arm of ['current']){
 const path=root+'/241-bun/0.svg.gz'
 const svg=gunzipSync(readFileSync(path)).toString(),carriers=[...svg.matchAll(/<polyline\b[^>]*\/>/g)].map(m=>m[0])
 const a=carriers.find(t=>t.includes('data-id="'+selected+'"'))!,b=carriers.find(t=>t.includes('data-id="'+peer+'"'))!
 if(!a||!b)throw Error('selected occurrence missing')
 const point=(t:string)=>/points="([^"]+)"/.exec(t)![1]!.trim().split(/\s+/).at(-1)!.split(',').map(Number),pa=point(a),pb=point(b),zoom=3
 const strip=(t:string)=>t.replace(/ marker-end="[^"]*"/,'')
 const variants=[svg,svg.replace(a,strip(a)),svg.replace(b,strip(b)),svg.replace(a,strip(a)).replace(b,strip(b))]
 const images=variants.map(s=>new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(s)),{background:'#fff',fitTo:{mode:'zoom',value:zoom},font:{fontFiles:fonts,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render())
 writeFileSync(root+'/'+arm+num+'.png',images[0]!.asPng());const pixels=images.map(i=>i.pixels)
 const roi={x0:Math.floor((Math.min(pa[0]!,pb[0]!)-2)*zoom),x1:Math.ceil((Math.max(pa[0]!,pb[0]!)+11)*zoom),y0:Math.floor((Math.min(pa[1]!,pb[1]!)-5)*zoom),y1:Math.ceil((Math.max(pa[1]!,pb[1]!)+5)*zoom)}
 let exposed=0,visible=0,attenuated=0,hidden=0;const delta=(a:Uint8Array,b:Uint8Array,k:number)=>Math.abs(a[k]!-b[k]!)+Math.abs(a[k+1]!-b[k+1]!)+Math.abs(a[k+2]!-b[k+2]!)
 for(let y=roi.y0;y<roi.y1;y++)for(let x=roi.x0;x<roi.x1;x++){const k=(y*images[0]!.width+x)*4,e=delta(pixels[2]!,pixels[3]!,k),v=delta(pixels[0]!,pixels[1]!,k);if(e>=6){exposed++;if(v>=6)visible++;if(v+6<e)attenuated++;if(v<6)hidden++}}
 rows.push({case:num,arm,selected,peer,sha256:createHash('sha256').update(svg).digest('hex'),roi,exposed,visible,attenuated,hidden,actualSelected:a,actualPeer:b})
}
writeFileSync(root+'/241-INK.json',JSON.stringify({font:'manifest-verified Inter; system fonts off',zoom:3,offlineRasters:4,scope:'Selected head contribution with/without one neighboring head; actual SVG geometry, not whole-diagram readability. Coordinates/raster phase differ between layouts.',rows},null,2)+'\n')
console.log(JSON.stringify(rows.map(({actualSelected,actualPeer,...r})=>r)))
