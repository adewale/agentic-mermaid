import fs from 'node:fs';
import path from 'node:path';
import inspector from 'node:inspector';
import {promisify} from 'node:util';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {registerHooks,stripTypeScriptTypes} from 'node:module';
import {gzipSync} from 'node:zlib';
const root='/tmp/pr449-main-integration-20261029-762',out=process.argv[2],job=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
fs.mkdirSync(out,{recursive:true});
const maps={};
registerHooks({
 resolve(specifier,context,next){
  if(specifier.startsWith('.')&&(context.parentURL?.startsWith(pathToFileURL(root+'/').href)||context.parentURL?.includes('/node_modules/roughjs/bin/'))){
   const p=new URL(specifier,context.parentURL);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.ts'))return next(p.href+'.ts',context);
   if(!path.extname(p.pathname)&&fs.existsSync(fileURLToPath(p)+'.js'))return next(p.href+'.js',context);
  }
  if(specifier.startsWith('roughjs/bin/')&&!path.extname(specifier))return next(specifier+'.js',context);
  return next(specifier,context);
 },
 load(url,context,next){
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.json'))return{format:'json',shortCircuit:true,source:fs.readFileSync(fileURLToPath(url),'utf8')};
  if(url.startsWith(pathToFileURL(root+'/').href)&&url.endsWith('.ts')){
   const original=fs.readFileSync(job.moduleOverrides?.[fileURLToPath(url)] ?? fileURLToPath(url),'utf8');
   const source=stripTypeScriptTypes(original,{mode:'transform',sourceMap:true,sourceUrl:url});
   const m=source.match(/sourceMappingURL=data:application\/json;base64,([^\s]+)/);
   if(m)maps[url]=JSON.parse(Buffer.from(m[1],'base64').toString());
   return{format:'module',shortCircuit:true,source};
  }
  return next(url,context);
 }
});
const gz=(name,value)=>fs.writeFileSync(out+'/'+name+'.gz',gzipSync(typeof value==='string'?value:JSON.stringify(value)));
const api=await import(pathToFileURL(root+'/src/index.ts'));
const {withRenderStageObserver}=await import(pathToFileURL(root+'/src/render-stages.ts'));
const {withPerformanceObserver}=await import(pathToFileURL(root+'/src/performance-observations.ts'));
const session=new inspector.Session();session.connect();const post=promisify(session.post).bind(session);
await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:200});
const products=[];const rows=[];
function consume(source){const product=api.renderMermaidSVGWithReceipt(source,job.options);const receiptJSON=JSON.stringify(product.receipt);const svg=product.svg;const bytes=Buffer.byteLength(JSON.stringify({svg,receipt:product.receipt}));return{svg,receiptJSON,bytes};}
// One complete unprofiled call loads source modules/JIT before source-runtime attribution.
let warmup;try{warmup=consume(job.source);gz('warmup?.svg',warmup?.svg);gz('warmup.receipt.json',warmup?.receiptJSON);}catch(e){gz('warmup-error.json',{name:e.name,message:e.message,stack:e.stack,certification:e.certification});}
for(const phase of ['repeat1','repeat2','edit']){
 globalThis.__contactPhase=phase;
 global.gc?.();const stages=[],events=[];const before=process.memoryUsage();await post('Profiler.start');const start=performance.now(),cpu=process.cpuUsage();let product,failure;
 try{product=withPerformanceObserver(e=>events.push(e),()=>withRenderStageObserver(s=>stages.push(s),()=>consume(phase==='edit'?job.edit:job.source)));}catch(e){failure={name:e.name,message:e.message,stack:e.stack,certification:e.certification};}
 const wallMs=performance.now()-start,cpuTime=process.cpuUsage(cpu);const {profile}=await post('Profiler.stop');const after=process.memoryUsage();
 gz(phase+'.cpuprofile',profile);
 if(product){gz(phase+'.svg',product.svg);gz(phase+'.receipt.json',product.receiptJSON);products.push(product);}
 const row={phase,status:product?'returned':'error',wallMs,cpuMs:(cpuTime.user+cpuTime.system)/1000,before,after,peakRssKiB:process.resourceUsage().maxRSS,bytes:product?.bytes,wholeSvgExactWarmup:phase==='edit'?undefined:product?.svg===warmup?.svg,entireReceiptExactWarmup:phase==='edit'?undefined:product?.receiptJSON===warmup?.receiptJSON,editChanged:phase==='edit'?product?.svg!==warmup?.svg:undefined,proof:product?JSON.parse(product.receiptJSON).layoutCertification:undefined,failure,stages,events,profileStart:profile.startTime,profileEnd:profile.endTime,samples:profile.samples?.length};
 rows.push(row);gz(phase+'.row.json',row);console.log(JSON.stringify({case:job.case,backend:job.backend,phase,status:row.status,wallMs,cpuMs:row.cpuMs,samples:row.samples}));
}
gz('contact-trace.json',globalThis.__contactTrace);gz('source-maps.json',maps);gz('RESULT.json',{runtime:process.version,job,cache:process.env.AGENTIC_MERMAID_ELK_CACHE,samplingIntervalUs:200,scope:'Node source runtime after complete unprofiled module-loading warmup; full SVG and entire receipt consumed; imports/artifacts/compression/explicit GC outside measured windows',rows});session.disconnect();
