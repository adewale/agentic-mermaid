import ts from '/tmp/pr449-main-integration-20261029-762/node_modules/typescript/lib/typescript.js'
import {readFileSync,writeFileSync}from'node:fs'
const p='/tmp/pr449-main-integration-20261029-762/src/scene/scene-validation-core.ts',f=ts.createSourceFile(p,readFileSync(p,'utf8'),ts.ScriptTarget.Latest,true)
const helpers:any[]=[];let state=0
function visit(n:ts.Node){
 if(ts.isPropertyAccessExpression(n)&&ts.isIdentifier(n.expression)&&n.expression.text==='state'&&n.name.text==='external')state++
 if(ts.isFunctionDeclaration(n)&&n.parameters.some(p=>ts.isIdentifier(p.name)&&p.name.text==='external')){
  let refs=0;function count(x:ts.Node){if(ts.isIdentifier(x)&&x.text==='external'&&!ts.isParameter(x.parent)&&!(ts.isPropertyAccessExpression(x.parent)&&x.parent.name===x)&&!(ts.isPropertyAssignment(x.parent)&&x.parent.name===x))refs++;ts.forEachChild(x,count)}
  if(n.body)count(n.body);helpers.push({function:n.name?.text,references:refs})
 }
 ts.forEachChild(n,visit)
}visit(f)
const d={statePropertyReads:state,externalBooleanHelpers:helpers,combinedFlagSites:state+helpers.reduce((s,x)=>s+x.references,0)};writeFileSync(import.meta.dir+'/SCOPE.json',JSON.stringify(d,null,2)+'\n');console.log(JSON.stringify(d))
