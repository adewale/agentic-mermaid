import {readFileSync,writeFileSync} from 'node:fs'
const root='/dev/shm/pr449-four-final-20261111/marker-operand-candidate'
let calls:any[]=[]
;(globalThis as any).__validationMode=(kind:string,external:boolean)=>{calls.push({kind,external});return external}
Bun.plugin({name:'actual-validation-mode-observation',setup(build){build.onLoad({filter:/\/src\/scene\/scene-validation-core\.ts$/},args=>{
 if(args.path!==root+'/src/scene/scene-validation-core.ts')return
 let s=readFileSync(args.path,'utf8')
 s=s.replace("const external = sceneValidationMode(value, options) === 'external'", "const external = (globalThis as any).__validationMode('document', sceneValidationMode(value, options) === 'external')")
 s=s.replace('function createValidationState(diagnostics: MutableDiagnostic[], external: boolean, crossChecks: boolean, aggregateBudgets = external): ValidationState {', "function createValidationState(diagnostics: MutableDiagnostic[], external: boolean, crossChecks: boolean, aggregateBudgets = external): ValidationState { (globalThis as any).__validationMode('state', external);")
 return{contents:s,loader:'ts'}
})}})
const {renderMermaidSVGWithReceipt}=await import(root+'/src/index.ts')
const source=JSON.parse(readFileSync('/dev/shm/pr449-four-final-20261111/runtime-e0cac-focused/profile-current.job.json','utf8')).source
const rows=[]
for(const style of [undefined,'paper','hand-drawn'])for(const backend of ['agentic','elk']){
 calls=[]
 const product=renderMermaidSVGWithReceipt(source,{...(style?{style}:{}),graphLayout:{backend,fallback:'none'}})
 const json=JSON.stringify(product)
 rows.push({style:style??'plain',backend,wholeProductBytes:json.length,proof:product.receipt.layoutCertification?.status,modeCalls:calls,externalCalls:calls.filter(x=>x.external).length})
}
writeFileSync(import.meta.dir+'/MODES.json',JSON.stringify({scope:'UNTIMED actualfullyconsumedNodepublicWithReceipt using same canonicalvalidationcore on committedmarkeroperand source; baselinebroaderNodeadmission, notbrowserdeliveryclaim. Actualmodeexpressionsloggedwithoutre-evaluatingcallerfields. No validatororconformanceomitted.',rows},null,2)+'\n');console.log(JSON.stringify(rows))
