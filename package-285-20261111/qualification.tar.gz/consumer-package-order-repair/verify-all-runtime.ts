import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs'
import {join} from 'node:path'
import {publishPackageProblems,expectedFilesWithLazyBuild,normalizePackagePath} from './candidate/scripts/ci/verify-publish-package.ts'
const task=import.meta.dir,root=task+'/candidate',required=['package.json','README.md','LICENSE','THIRD_PARTY_NOTICES.md','LICENSES/Apache-2.0.txt','server.json']
const walk=(dir:string):string[]=>readdirSync(join(root,dir),{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(dir+'/'+e.name):/\.(?:c?js)$/.test(e.name)?[dir+'/'+e.name]:[])
const runtime=(p:string)=>p.startsWith('dist/')&&/\.(?:c?js)$/.test(p)&&p!=='dist/browser.global.js'
const files=[...required.filter(p=>existsSync(join(root,p))),...walk('dist')],manifest=JSON.parse(readFileSync(root+'/scripts/ci/publish-package-files.json','utf8')),meta=JSON.parse(readFileSync(root+'/dist/metafile-esm.json','utf8'))
const expected=[...required,...expectedFilesWithLazyBuild(manifest.files,Object.keys(meta.outputs)).filter(runtime)],pkg=JSON.parse(readFileSync(root+'/package.json','utf8'))
pkg.exports=Object.fromEntries(Object.entries(pkg.exports).map(([k,v]:any)=>[k,typeof v==='string'?v:Object.fromEntries(Object.entries(v).filter(([p,v]:any)=>p!=='types'&&String(v).endsWith('.js')&&!String(v).includes('browser.global.js')))]).filter(([k,v]:any)=>typeof v==='string'?v.endsWith('.js')&&!v.includes('browser.global.js'):Object.keys(v).length))
const problems=publishPackageProblems(pkg,files,expected,Object.keys(meta.outputs).filter(p=>p.endsWith('.js')))
writeFileSync(task+'/PACK-ALL-RUNTIME.json',JSON.stringify({scope:'Actual full owning14Node, CJS kernels, isolatedZen ESM/frame, lazy-browser emitted runtime inventory and publicJS export/bin targets using unchanged existing package validator. No fabricated IIFE/declaration files; complete tarball/IIFE/declarations remain CI scope. Existing private/source-map exclusions and runtime manifest exact counts retained.',files,expected,normalized:files.map(normalizePackagePath),problems},null,2)+'\n');console.log(JSON.stringify({actualFiles:files.length,expectedFiles:expected.length,problems}));if(problems.length)process.exitCode=1
