import type { Geometry, MarkPaint, ScenePoint, ShapeMark, TextMark } from './ir.ts'
// Internal implementations of the existing paint/geometry interfaces. Values
// live in private slots, never in mutable receiver fields exposed to a helper.
const issuer = { __proto__: null }
const seal = Object.preventExtensions, proto = Object.getPrototypeOf, extensible = Object.isExtensible, keys = Reflect.ownKeys
const define = Object.defineProperties, freeze = Object.freeze, descriptor = Object.getOwnPropertyDescriptor
function closePrototype(value: object, fields: Record<string, () => unknown>): boolean {
  const expected = { __proto__: null, ...fields } as unknown as Record<string, () => unknown>
  const slots = { __proto__: null } as unknown as PropertyDescriptorMap
  for (const key in expected) slots[key] = { __proto__: null, get: expected[key], enumerable: true, configurable: false } as PropertyDescriptor
  define(value, slots)
  freeze(value)
  if (extensible(value)) return false
  for (const key in expected) { const slot = descriptor(value, key); if (!slot || slot.get !== expected[key] || slot.set !== undefined || slot.configurable) return false }
  return true
}
function closeInstance(value: object, expectedPrototype: object, ready: boolean): void {
  if (!ready || seal(value) !== value || extensible(value) || proto(value) !== expectedPrototype || keys(value).length !== 0) throw new TypeError('Actual writer receiver could not be closed')
}

class WrittenPoint implements ScenePoint {
  declare readonly x: number
  declare readonly y: number
  readonly #x: number
  readonly #y: number
  constructor(token: object, x: number, y: number) {
    if (token !== issuer) throw new TypeError('Actual values require their writer')
    this.#x = x
    this.#y = y
    closeInstance(this, WrittenPoint.prototype, WrittenPointReady)
  }
  static x(value: WrittenPoint): number { return value.#x }
  static y(value: WrittenPoint): number { return value.#y }
  static owns(value: unknown): value is WrittenPoint { return !!value && typeof value === 'object' && #x in value }
}
const readWrittenPointx = WrittenPoint.x
const readWrittenPointy = WrittenPoint.y
const ownsWrittenPoint = WrittenPoint.owns
const WrittenPointReady = closePrototype(WrittenPoint.prototype, {
  x: function(this: WrittenPoint) { return readWrittenPointx(this) },
  y: function(this: WrittenPoint) { return readWrittenPointy(this) },
})
export function isWrittenPoint(value: unknown): value is ScenePoint { return ownsWrittenPoint(value) }
export function createWrittenPoint(x: number, y: number): ScenePoint | undefined {
  try { return new WrittenPoint(issuer, x, y) } catch { return undefined }
}

class WrittenLine implements Extract<Geometry, { kind: 'line' }> {
  declare readonly kind: 'line'
  declare readonly x1: number
  declare readonly y1: number
  declare readonly x2: number
  declare readonly y2: number
  readonly #x1: number
  readonly #y1: number
  readonly #x2: number
  readonly #y2: number
  constructor(token: object, x1: number, y1: number, x2: number, y2: number) {
    if (token !== issuer) throw new TypeError('Actual values require their writer')
    this.#x1 = x1
    this.#y1 = y1
    this.#x2 = x2
    this.#y2 = y2
    closeInstance(this, WrittenLine.prototype, WrittenLineReady)
  }
  static kind(value: WrittenLine): 'line' { return 'line' }
  static x1(value: WrittenLine): number { return value.#x1 }
  static y1(value: WrittenLine): number { return value.#y1 }
  static x2(value: WrittenLine): number { return value.#x2 }
  static y2(value: WrittenLine): number { return value.#y2 }
  static owns(value: unknown): value is WrittenLine { return !!value && typeof value === 'object' && #x1 in value }
}
const readWrittenLinekind = WrittenLine.kind
const readWrittenLinex1 = WrittenLine.x1
const readWrittenLiney1 = WrittenLine.y1
const readWrittenLinex2 = WrittenLine.x2
const readWrittenLiney2 = WrittenLine.y2
const ownsWrittenLine = WrittenLine.owns
const WrittenLineReady = closePrototype(WrittenLine.prototype, {
  kind: function(this: WrittenLine) { return readWrittenLinekind(this) },
  x1: function(this: WrittenLine) { return readWrittenLinex1(this) },
  y1: function(this: WrittenLine) { return readWrittenLiney1(this) },
  x2: function(this: WrittenLine) { return readWrittenLinex2(this) },
  y2: function(this: WrittenLine) { return readWrittenLiney2(this) },
})
export function isWrittenLine(value: unknown): value is Extract<Geometry, { kind: 'line' }> { return ownsWrittenLine(value) }
export function createWrittenLine(x1: number, y1: number, x2: number, y2: number): Extract<Geometry, { kind: 'line' }> | undefined {
  try { return new WrittenLine(issuer, x1, y1, x2, y2) } catch { return undefined }
}

class WrittenRect implements Extract<Geometry, { kind: 'rect' }> {
  declare readonly kind: 'rect'
  declare readonly x: number
  declare readonly y: number
  declare readonly width: number
  declare readonly height: number
  declare readonly rx: number | undefined
  declare readonly ry: number | undefined
  readonly #x: number
  readonly #y: number
  readonly #width: number
  readonly #height: number
  readonly #rx: number | undefined
  readonly #ry: number | undefined
  constructor(token: object, x: number, y: number, width: number, height: number, rx: number | undefined, ry: number | undefined) {
    if (token !== issuer) throw new TypeError('Actual values require their writer')
    this.#x = x
    this.#y = y
    this.#width = width
    this.#height = height
    this.#rx = rx
    this.#ry = ry
    closeInstance(this, WrittenRect.prototype, WrittenRectReady)
  }
  static kind(value: WrittenRect): 'rect' { return 'rect' }
  static x(value: WrittenRect): number { return value.#x }
  static y(value: WrittenRect): number { return value.#y }
  static width(value: WrittenRect): number { return value.#width }
  static height(value: WrittenRect): number { return value.#height }
  static rx(value: WrittenRect): number | undefined { return value.#rx }
  static ry(value: WrittenRect): number | undefined { return value.#ry }
  static owns(value: unknown): value is WrittenRect { return !!value && typeof value === 'object' && #x in value }
}
const readWrittenRectkind = WrittenRect.kind
const readWrittenRectx = WrittenRect.x
const readWrittenRecty = WrittenRect.y
const readWrittenRectwidth = WrittenRect.width
const readWrittenRectheight = WrittenRect.height
const readWrittenRectrx = WrittenRect.rx
const readWrittenRectry = WrittenRect.ry
const ownsWrittenRect = WrittenRect.owns
const WrittenRectReady = closePrototype(WrittenRect.prototype, {
  kind: function(this: WrittenRect) { return readWrittenRectkind(this) },
  x: function(this: WrittenRect) { return readWrittenRectx(this) },
  y: function(this: WrittenRect) { return readWrittenRecty(this) },
  width: function(this: WrittenRect) { return readWrittenRectwidth(this) },
  height: function(this: WrittenRect) { return readWrittenRectheight(this) },
  rx: function(this: WrittenRect) { return readWrittenRectrx(this) },
  ry: function(this: WrittenRect) { return readWrittenRectry(this) },
})
export function isWrittenRect(value: unknown): value is Extract<Geometry, { kind: 'rect' }> { return ownsWrittenRect(value) }
export function createWrittenRect(x: number, y: number, width: number, height: number, rx: number | undefined, ry: number | undefined): Extract<Geometry, { kind: 'rect' }> | undefined {
  try { return new WrittenRect(issuer, x, y, width, height, rx, ry) } catch { return undefined }
}

class WrittenPaint implements MarkPaint {
  declare readonly fill: string | undefined
  declare readonly fillOpacity: string | undefined
  declare readonly stroke: string | undefined
  declare readonly strokeOpacity: string | undefined
  declare readonly strokeWidth: string | undefined
  declare readonly strokeDasharray: string | undefined
  declare readonly strokeDashoffset: string | undefined
  declare readonly strokeLinecap: MarkPaint['strokeLinecap']
  declare readonly strokeLinejoin: MarkPaint['strokeLinejoin']
  declare readonly strokeMiterlimit: string | undefined
  declare readonly vectorEffect: MarkPaint['vectorEffect']
  declare readonly paintOrder: string | undefined
  declare readonly opacity: string | undefined
  readonly #fill: string | undefined
  readonly #fillOpacity: string | undefined
  readonly #stroke: string | undefined
  readonly #strokeOpacity: string | undefined
  readonly #strokeWidth: string | undefined
  readonly #strokeDasharray: string | undefined
  readonly #strokeDashoffset: string | undefined
  readonly #strokeLinecap: MarkPaint['strokeLinecap']
  readonly #strokeLinejoin: MarkPaint['strokeLinejoin']
  readonly #strokeMiterlimit: string | undefined
  readonly #vectorEffect: MarkPaint['vectorEffect']
  readonly #paintOrder: string | undefined
  readonly #opacity: string | undefined
  constructor(token: object, fill: string | undefined, fillOpacity: string | undefined, stroke: string | undefined, strokeOpacity: string | undefined, strokeWidth: string | undefined, strokeDasharray: string | undefined, strokeDashoffset: string | undefined, strokeLinecap: MarkPaint['strokeLinecap'], strokeLinejoin: MarkPaint['strokeLinejoin'], strokeMiterlimit: string | undefined, vectorEffect: MarkPaint['vectorEffect'], paintOrder: string | undefined, opacity: string | undefined) {
    if (token !== issuer) throw new TypeError('Actual values require their writer')
    this.#fill = fill
    this.#fillOpacity = fillOpacity
    this.#stroke = stroke
    this.#strokeOpacity = strokeOpacity
    this.#strokeWidth = strokeWidth
    this.#strokeDasharray = strokeDasharray
    this.#strokeDashoffset = strokeDashoffset
    this.#strokeLinecap = strokeLinecap
    this.#strokeLinejoin = strokeLinejoin
    this.#strokeMiterlimit = strokeMiterlimit
    this.#vectorEffect = vectorEffect
    this.#paintOrder = paintOrder
    this.#opacity = opacity
    closeInstance(this, WrittenPaint.prototype, WrittenPaintReady)
  }
  static fill(value: WrittenPaint): string | undefined { return value.#fill }
  static fillOpacity(value: WrittenPaint): string | undefined { return value.#fillOpacity }
  static stroke(value: WrittenPaint): string | undefined { return value.#stroke }
  static strokeOpacity(value: WrittenPaint): string | undefined { return value.#strokeOpacity }
  static strokeWidth(value: WrittenPaint): string | undefined { return value.#strokeWidth }
  static strokeDasharray(value: WrittenPaint): string | undefined { return value.#strokeDasharray }
  static strokeDashoffset(value: WrittenPaint): string | undefined { return value.#strokeDashoffset }
  static strokeLinecap(value: WrittenPaint): MarkPaint['strokeLinecap'] { return value.#strokeLinecap }
  static strokeLinejoin(value: WrittenPaint): MarkPaint['strokeLinejoin'] { return value.#strokeLinejoin }
  static strokeMiterlimit(value: WrittenPaint): string | undefined { return value.#strokeMiterlimit }
  static vectorEffect(value: WrittenPaint): MarkPaint['vectorEffect'] { return value.#vectorEffect }
  static paintOrder(value: WrittenPaint): string | undefined { return value.#paintOrder }
  static opacity(value: WrittenPaint): string | undefined { return value.#opacity }
  static owns(value: unknown): value is WrittenPaint { return !!value && typeof value === 'object' && #fill in value }
}
const readWrittenPaintfill = WrittenPaint.fill
const readWrittenPaintfillOpacity = WrittenPaint.fillOpacity
const readWrittenPaintstroke = WrittenPaint.stroke
const readWrittenPaintstrokeOpacity = WrittenPaint.strokeOpacity
const readWrittenPaintstrokeWidth = WrittenPaint.strokeWidth
const readWrittenPaintstrokeDasharray = WrittenPaint.strokeDasharray
const readWrittenPaintstrokeDashoffset = WrittenPaint.strokeDashoffset
const readWrittenPaintstrokeLinecap = WrittenPaint.strokeLinecap
const readWrittenPaintstrokeLinejoin = WrittenPaint.strokeLinejoin
const readWrittenPaintstrokeMiterlimit = WrittenPaint.strokeMiterlimit
const readWrittenPaintvectorEffect = WrittenPaint.vectorEffect
const readWrittenPaintpaintOrder = WrittenPaint.paintOrder
const readWrittenPaintopacity = WrittenPaint.opacity
const ownsWrittenPaint = WrittenPaint.owns
const WrittenPaintReady = closePrototype(WrittenPaint.prototype, {
  fill: function(this: WrittenPaint) { return readWrittenPaintfill(this) },
  fillOpacity: function(this: WrittenPaint) { return readWrittenPaintfillOpacity(this) },
  stroke: function(this: WrittenPaint) { return readWrittenPaintstroke(this) },
  strokeOpacity: function(this: WrittenPaint) { return readWrittenPaintstrokeOpacity(this) },
  strokeWidth: function(this: WrittenPaint) { return readWrittenPaintstrokeWidth(this) },
  strokeDasharray: function(this: WrittenPaint) { return readWrittenPaintstrokeDasharray(this) },
  strokeDashoffset: function(this: WrittenPaint) { return readWrittenPaintstrokeDashoffset(this) },
  strokeLinecap: function(this: WrittenPaint) { return readWrittenPaintstrokeLinecap(this) },
  strokeLinejoin: function(this: WrittenPaint) { return readWrittenPaintstrokeLinejoin(this) },
  strokeMiterlimit: function(this: WrittenPaint) { return readWrittenPaintstrokeMiterlimit(this) },
  vectorEffect: function(this: WrittenPaint) { return readWrittenPaintvectorEffect(this) },
  paintOrder: function(this: WrittenPaint) { return readWrittenPaintpaintOrder(this) },
  opacity: function(this: WrittenPaint) { return readWrittenPaintopacity(this) },
})
export function isWrittenPaint(value: unknown): value is MarkPaint { return ownsWrittenPaint(value) }
export function createWrittenPaint(fill: string | undefined, fillOpacity: string | undefined, stroke: string | undefined, strokeOpacity: string | undefined, strokeWidth: string | undefined, strokeDasharray: string | undefined, strokeDashoffset: string | undefined, strokeLinecap: MarkPaint['strokeLinecap'], strokeLinejoin: MarkPaint['strokeLinejoin'], strokeMiterlimit: string | undefined, vectorEffect: MarkPaint['vectorEffect'], paintOrder: string | undefined, opacity: string | undefined): MarkPaint | undefined {
  try { return new WrittenPaint(issuer, fill, fillOpacity, stroke, strokeOpacity, strokeWidth, strokeDasharray, strokeDashoffset, strokeLinecap, strokeLinejoin, strokeMiterlimit, vectorEffect, paintOrder, opacity) } catch { return undefined }
}

export type WrittenShapeMetadata = Omit<ShapeMark, 'geometry' | 'paint'>
class WrittenShape implements ShapeMark {
  declare readonly kind: ShapeMark['kind']
  declare readonly id: ShapeMark['id']
  declare readonly role: ShapeMark['role']
  declare readonly identity: ShapeMark['identity']
  declare readonly owner: ShapeMark['owner']
  declare readonly visibility: ShapeMark['visibility']
  declare readonly accessibility: ShapeMark['accessibility']
  declare readonly channels: ShapeMark['channels']
  declare readonly transform: ShapeMark['transform']
  declare readonly attributes: ShapeMark['attributes']
  declare readonly childPaints: ShapeMark['childPaints']
  declare readonly conditionalPaint: ShapeMark['conditionalPaint']
  declare readonly surfaceFragment: ShapeMark['surfaceFragment']
  declare readonly geometry: ShapeMark['geometry']
  declare readonly paint: ShapeMark['paint']
  readonly #metadata: WrittenShapeMetadata
  readonly #geometry: Geometry
  readonly #paint: MarkPaint
  constructor(token: object, metadata: WrittenShapeMetadata, geometry: Geometry, paint: MarkPaint) {
    if (token !== issuer) throw new TypeError('Actual values require their writer')
    this.#metadata = metadata; this.#geometry = geometry; this.#paint = paint
    closeInstance(this, WrittenShape.prototype, WrittenShapeReady)
  }
  static kind(value: WrittenShape): ShapeMark['kind'] { return value.#metadata.kind }
  static id(value: WrittenShape): ShapeMark['id'] { return value.#metadata.id }
  static role(value: WrittenShape): ShapeMark['role'] { return value.#metadata.role }
  static identity(value: WrittenShape): ShapeMark['identity'] { return value.#metadata.identity }
  static owner(value: WrittenShape): ShapeMark['owner'] { return value.#metadata.owner }
  static visibility(value: WrittenShape): ShapeMark['visibility'] { return value.#metadata.visibility }
  static accessibility(value: WrittenShape): ShapeMark['accessibility'] { return value.#metadata.accessibility }
  static channels(value: WrittenShape): ShapeMark['channels'] { return value.#metadata.channels }
  static transform(value: WrittenShape): ShapeMark['transform'] { return value.#metadata.transform }
  static attributes(value: WrittenShape): ShapeMark['attributes'] { return value.#metadata.attributes }
  static childPaints(value: WrittenShape): ShapeMark['childPaints'] { return value.#metadata.childPaints }
  static conditionalPaint(value: WrittenShape): ShapeMark['conditionalPaint'] { return value.#metadata.conditionalPaint }
  static surfaceFragment(value: WrittenShape): ShapeMark['surfaceFragment'] { return value.#metadata.surfaceFragment }
  static geometry(value: WrittenShape): Geometry { return value.#geometry }
  static paint(value: WrittenShape): MarkPaint { return value.#paint }
  static owns(value: unknown): value is WrittenShape { return !!value && typeof value === 'object' && #metadata in value }
}
const readWrittenShapekind = WrittenShape.kind
const readWrittenShapeid = WrittenShape.id
const readWrittenShaperole = WrittenShape.role
const readWrittenShapeidentity = WrittenShape.identity
const readWrittenShapeowner = WrittenShape.owner
const readWrittenShapevisibility = WrittenShape.visibility
const readWrittenShapeaccessibility = WrittenShape.accessibility
const readWrittenShapechannels = WrittenShape.channels
const readWrittenShapetransform = WrittenShape.transform
const readWrittenShapeattributes = WrittenShape.attributes
const readWrittenShapechildPaints = WrittenShape.childPaints
const readWrittenShapeconditionalPaint = WrittenShape.conditionalPaint
const readWrittenShapesurfaceFragment = WrittenShape.surfaceFragment
const readWrittenShapegeometry = WrittenShape.geometry
const readWrittenShapepaint = WrittenShape.paint
const ownsWrittenShape = WrittenShape.owns
const WrittenShapeReady = closePrototype(WrittenShape.prototype, {
  kind: function(this: WrittenShape) { return readWrittenShapekind(this) },
  id: function(this: WrittenShape) { return readWrittenShapeid(this) },
  role: function(this: WrittenShape) { return readWrittenShaperole(this) },
  identity: function(this: WrittenShape) { return readWrittenShapeidentity(this) },
  owner: function(this: WrittenShape) { return readWrittenShapeowner(this) },
  visibility: function(this: WrittenShape) { return readWrittenShapevisibility(this) },
  accessibility: function(this: WrittenShape) { return readWrittenShapeaccessibility(this) },
  channels: function(this: WrittenShape) { return readWrittenShapechannels(this) },
  transform: function(this: WrittenShape) { return readWrittenShapetransform(this) },
  attributes: function(this: WrittenShape) { return readWrittenShapeattributes(this) },
  childPaints: function(this: WrittenShape) { return readWrittenShapechildPaints(this) },
  conditionalPaint: function(this: WrittenShape) { return readWrittenShapeconditionalPaint(this) },
  surfaceFragment: function(this: WrittenShape) { return readWrittenShapesurfaceFragment(this) },
  geometry: function(this: WrittenShape) { return readWrittenShapegeometry(this) },
  paint: function(this: WrittenShape) { return readWrittenShapepaint(this) },
})
export function isWrittenShape(value: unknown): value is ShapeMark { return ownsWrittenShape(value) }
export function createWrittenShape(metadata: WrittenShapeMetadata, geometry: Geometry, paint: MarkPaint): ShapeMark | undefined {
  try { return new WrittenShape(issuer, metadata, geometry, paint) } catch { return undefined }
}

export type WrittenTextMetadata = Omit<TextMark, 'paint' | 'block' | 'preparedLines'>
class WrittenText implements TextMark {
  declare readonly kind: TextMark['kind']
  declare readonly id: TextMark['id']
  declare readonly role: TextMark['role']
  declare readonly identity: TextMark['identity']
  declare readonly owner: TextMark['owner']
  declare readonly visibility: TextMark['visibility']
  declare readonly accessibility: TextMark['accessibility']
  declare readonly channels: TextMark['channels']
  declare readonly transform: TextMark['transform']
  declare readonly attributes: TextMark['attributes']
  declare readonly text: TextMark['text']
  declare readonly fontSize: TextMark['fontSize']
  declare readonly fontWeight: TextMark['fontWeight']
  declare readonly letterSpacing: TextMark['letterSpacing']
  declare readonly display: TextMark['display']
  declare readonly prepared: TextMark['prepared']
  declare readonly measurement: TextMark['measurement']
  declare readonly textLayout: TextMark['textLayout']
  declare readonly anchor: TextMark['anchor']
  declare readonly dominantBaseline: TextMark['dominantBaseline']
  declare readonly fontStyle: TextMark['fontStyle']
  declare readonly textDecoration: TextMark['textDecoration']
  declare readonly spans: TextMark['spans']
  declare readonly pageFill: TextMark['pageFill']
  declare readonly x: TextMark['x']
  declare readonly y: TextMark['y']
  declare readonly baselineShift: TextMark['baselineShift']
  declare readonly paint: TextMark['paint']
  declare readonly block: TextMark['block']
  declare readonly preparedLines: TextMark['preparedLines']
  readonly #metadata: WrittenTextMetadata
  readonly #paint: MarkPaint
  readonly #block: NonNullable<TextMark['block']>
  readonly #x: number
  readonly #y: number
  readonly #baselineShift: number
  constructor(token: object, metadata: WrittenTextMetadata, paint: MarkPaint, block: NonNullable<TextMark['block']>, x: number, y: number, baselineShift: number) {
    if (token !== issuer) throw new TypeError('Actual values require their writer')
    this.#metadata=metadata; this.#paint=paint; this.#block=block; this.#x=x; this.#y=y; this.#baselineShift=baselineShift
    closeInstance(this, WrittenText.prototype, WrittenTextReady)
  }
  static kind(value: WrittenText): TextMark['kind'] { return value.#metadata.kind }
  static id(value: WrittenText): TextMark['id'] { return value.#metadata.id }
  static role(value: WrittenText): TextMark['role'] { return value.#metadata.role }
  static identity(value: WrittenText): TextMark['identity'] { return value.#metadata.identity }
  static owner(value: WrittenText): TextMark['owner'] { return value.#metadata.owner }
  static visibility(value: WrittenText): TextMark['visibility'] { return value.#metadata.visibility }
  static accessibility(value: WrittenText): TextMark['accessibility'] { return value.#metadata.accessibility }
  static channels(value: WrittenText): TextMark['channels'] { return value.#metadata.channels }
  static transform(value: WrittenText): TextMark['transform'] { return value.#metadata.transform }
  static attributes(value: WrittenText): TextMark['attributes'] { return value.#metadata.attributes }
  static text(value: WrittenText): TextMark['text'] { return value.#metadata.text }
  static fontSize(value: WrittenText): TextMark['fontSize'] { return value.#metadata.fontSize }
  static fontWeight(value: WrittenText): TextMark['fontWeight'] { return value.#metadata.fontWeight }
  static letterSpacing(value: WrittenText): TextMark['letterSpacing'] { return value.#metadata.letterSpacing }
  static display(value: WrittenText): TextMark['display'] { return value.#metadata.display }
  static prepared(value: WrittenText): TextMark['prepared'] { return value.#metadata.prepared }
  static measurement(value: WrittenText): TextMark['measurement'] { return value.#metadata.measurement }
  static textLayout(value: WrittenText): TextMark['textLayout'] { return value.#metadata.textLayout }
  static anchor(value: WrittenText): TextMark['anchor'] { return value.#metadata.anchor }
  static dominantBaseline(value: WrittenText): TextMark['dominantBaseline'] { return value.#metadata.dominantBaseline }
  static fontStyle(value: WrittenText): TextMark['fontStyle'] { return value.#metadata.fontStyle }
  static textDecoration(value: WrittenText): TextMark['textDecoration'] { return value.#metadata.textDecoration }
  static spans(value: WrittenText): TextMark['spans'] { return value.#metadata.spans }
  static pageFill(value: WrittenText): TextMark['pageFill'] { return value.#metadata.pageFill }
  static x(value: WrittenText): TextMark['x'] { return value.#x }
  static y(value: WrittenText): TextMark['y'] { return value.#y }
  static baselineShift(value: WrittenText): TextMark['baselineShift'] { return value.#baselineShift }
  static paint(value: WrittenText): TextMark['paint'] { return value.#paint }
  static block(value: WrittenText): TextMark['block'] { return value.#block }
  static preparedLines(value: WrittenText): undefined { return undefined }
  static owns(value: unknown): value is WrittenText { return !!value && typeof value === 'object' && #metadata in value }
}
const readWrittenTextkind = WrittenText.kind
const readWrittenTextid = WrittenText.id
const readWrittenTextrole = WrittenText.role
const readWrittenTextidentity = WrittenText.identity
const readWrittenTextowner = WrittenText.owner
const readWrittenTextvisibility = WrittenText.visibility
const readWrittenTextaccessibility = WrittenText.accessibility
const readWrittenTextchannels = WrittenText.channels
const readWrittenTexttransform = WrittenText.transform
const readWrittenTextattributes = WrittenText.attributes
const readWrittenTexttext = WrittenText.text
const readWrittenTextfontSize = WrittenText.fontSize
const readWrittenTextfontWeight = WrittenText.fontWeight
const readWrittenTextletterSpacing = WrittenText.letterSpacing
const readWrittenTextdisplay = WrittenText.display
const readWrittenTextprepared = WrittenText.prepared
const readWrittenTextmeasurement = WrittenText.measurement
const readWrittenTexttextLayout = WrittenText.textLayout
const readWrittenTextanchor = WrittenText.anchor
const readWrittenTextdominantBaseline = WrittenText.dominantBaseline
const readWrittenTextfontStyle = WrittenText.fontStyle
const readWrittenTexttextDecoration = WrittenText.textDecoration
const readWrittenTextspans = WrittenText.spans
const readWrittenTextpageFill = WrittenText.pageFill
const readWrittenTextx = WrittenText.x
const readWrittenTexty = WrittenText.y
const readWrittenTextbaselineShift = WrittenText.baselineShift
const readWrittenTextpaint = WrittenText.paint
const readWrittenTextblock = WrittenText.block
const readWrittenTextpreparedLines = WrittenText.preparedLines
const ownsWrittenText = WrittenText.owns
const WrittenTextReady = closePrototype(WrittenText.prototype, {
  kind: function(this: WrittenText) { return readWrittenTextkind(this) },
  id: function(this: WrittenText) { return readWrittenTextid(this) },
  role: function(this: WrittenText) { return readWrittenTextrole(this) },
  identity: function(this: WrittenText) { return readWrittenTextidentity(this) },
  owner: function(this: WrittenText) { return readWrittenTextowner(this) },
  visibility: function(this: WrittenText) { return readWrittenTextvisibility(this) },
  accessibility: function(this: WrittenText) { return readWrittenTextaccessibility(this) },
  channels: function(this: WrittenText) { return readWrittenTextchannels(this) },
  transform: function(this: WrittenText) { return readWrittenTexttransform(this) },
  attributes: function(this: WrittenText) { return readWrittenTextattributes(this) },
  text: function(this: WrittenText) { return readWrittenTexttext(this) },
  fontSize: function(this: WrittenText) { return readWrittenTextfontSize(this) },
  fontWeight: function(this: WrittenText) { return readWrittenTextfontWeight(this) },
  letterSpacing: function(this: WrittenText) { return readWrittenTextletterSpacing(this) },
  display: function(this: WrittenText) { return readWrittenTextdisplay(this) },
  prepared: function(this: WrittenText) { return readWrittenTextprepared(this) },
  measurement: function(this: WrittenText) { return readWrittenTextmeasurement(this) },
  textLayout: function(this: WrittenText) { return readWrittenTexttextLayout(this) },
  anchor: function(this: WrittenText) { return readWrittenTextanchor(this) },
  dominantBaseline: function(this: WrittenText) { return readWrittenTextdominantBaseline(this) },
  fontStyle: function(this: WrittenText) { return readWrittenTextfontStyle(this) },
  textDecoration: function(this: WrittenText) { return readWrittenTexttextDecoration(this) },
  spans: function(this: WrittenText) { return readWrittenTextspans(this) },
  pageFill: function(this: WrittenText) { return readWrittenTextpageFill(this) },
  x: function(this: WrittenText) { return readWrittenTextx(this) },
  y: function(this: WrittenText) { return readWrittenTexty(this) },
  baselineShift: function(this: WrittenText) { return readWrittenTextbaselineShift(this) },
  paint: function(this: WrittenText) { return readWrittenTextpaint(this) },
  block: function(this: WrittenText) { return readWrittenTextblock(this) },
  preparedLines: function(this: WrittenText) { return readWrittenTextpreparedLines(this) },
})
export function isWrittenText(value: unknown): value is TextMark { return ownsWrittenText(value) }
export function createWrittenText(metadata: WrittenTextMetadata, paint: MarkPaint, block: NonNullable<TextMark['block']>, x: number, y: number, baselineShift: number): TextMark | undefined {
  try { return new WrittenText(issuer, metadata, paint, block, x, y, baselineShift) } catch { return undefined }
}
