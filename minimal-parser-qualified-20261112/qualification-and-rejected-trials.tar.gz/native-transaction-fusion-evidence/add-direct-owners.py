from pathlib import Path
p=Path('/dev/shm/pr449-four-final-20261111/native-transaction-fusion-candidate/src/__tests__/scene-svg-writer.test.ts');s=p.read_text();s=s.replace('writeConnectorSvg, type SvgXmlWrite', 'writeConnectorSvg, writeNativeConnectorSourceSvg, type SvgXmlWrite')
pos=s.index("  test.each(['actual', 'foreign-capture'")
block='''  test.each(['hit', 'labels', 'geometry-kind', 'endpoint-x', 'array-slot', 'unknown-before-hit'] as const)('reduced Native selection retains effectful SDK order: %s', mode => {
    const run = (attemptDirect: boolean) => {
      const events: string[] = []
      const fields: marks.ConnectorFields = { id: 'source-order', role: 'edge', lineStyle: 'solid',
        geometry: { kind: 'polyline', points: [{ x: 10, y: 10 }, { x: 40, y: 10 }] }, paint: { stroke: '#111' } }
      if (mode === 'hit' || mode === 'unknown-before-hit') Object.defineProperty(fields, 'hit', { get() { events.push('hit'); return undefined } })
      if (mode === 'labels') Object.defineProperty(fields, 'labels', { get() { events.push('labels'); return [] } })
      if (mode === 'geometry-kind') Object.defineProperty(fields.geometry, 'kind', { get() { events.push('kind'); return 'polyline' } })
      if (fields.geometry.kind !== 'polyline') throw new Error('Expected polyline')
      if (mode === 'endpoint-x') Object.defineProperty(fields.geometry.points[0]!, 'x', { get() { events.push('x'); return 10 }, enumerable: true })
      if (mode === 'array-slot') {
        const point = fields.geometry.points[0]!
        Object.defineProperty(fields.geometry.points, '0', { get() { events.push('point'); return point }, enumerable: true })
      }
      if (mode === 'unknown-before-hit') Object.defineProperty(fields, 'unknown', { value: true })
      events.length = 0
      try {
        if (attemptDirect) {
          expect(createOriginalNativePaintEmission(400000).directConnector(fields)).toBeUndefined()
          expect(events).toEqual([])
        }
        const node = marks.connector(fields)
        return { events, svg: sceneNodeSerialization(node) }
      } catch (error) { return { events, error: String(error) } }
    }
    expect(run(true)).toEqual(run(false))
  })

  test('a failed reduced-source capture writes once conditionally without SDK normalization retry', () => {
    const emission = createOriginalNativePaintEmission(400000)
    const fields: marks.ConnectorFields = { id: 'source-closure-once', role: 'edge', lineStyle: 'solid',
      geometry: { kind: 'line', x1: 10, y1: 10, x2: 40, y2: 10 }, paint: { stroke: '#111' } }
    const prevent = Object.preventExtensions
    let closures = 0, writes = 0
    Object.preventExtensions = function <T>(value: T): T {
      if (value && typeof value === 'object' && 'kind' in value && value.kind === 'connector' && 'id' in value && value.id === fields.id) {
        closures++
        throw new Error('declined source closure')
      }
      return prevent(value)
    }
    try {
      const source = emission.directConnector(fields)
      expect(source).toBeDefined()
      if (!source) throw new Error('Expected once-normalized source')
      const leaf = emission.leaf(source, (node, sink) => { writes++; return writeNativeConnectorSourceSvg(node, sink, emission.xml) }, emission.xml)
      expect(leaf.conditional).toBe(true)
      expect(leaf.svg).toContain('<line x1="10" y1="10" x2="40" y2="10"')
      expect(closures).toBe(1)
      expect(writes).toBe(1)
    } finally { Object.preventExtensions = prevent }
  })

  test('reduced-source writing never consults inherited SDK hit or terminal payloads', () => {
    const emission = createOriginalNativePaintEmission(400000)
    const source = emission.directConnector({ id: 'source-own-fields', role: 'edge', lineStyle: 'solid',
      geometry: { kind: 'line', x1: 10, y1: 10, x2: 40, y2: 10 }, paint: { stroke: '#111' } })
    expect(source).toBeDefined()
    if (!source) throw new Error('Expected original source')
    const validator = createNativeSceneValidator({ family: 'flowchart', width: 100, height: 100, colors: { bg: '#fff', fg: '#111' }, transparent: false })
    let reads = 0
    for (const field of ['hit', 'terminalProjection']) Object.defineProperty(Object.prototype, field, { configurable: true, get() { reads++; throw new Error('Inherited SDK payload must not be read') } })
    try {
      const leaf = emission.leaf(source, (node, sink) => validator.write(node, emission.xml, 0, sink, true), emission.xml)
      expect(leaf.conditional).toBe(false)
      expect(leaf.svg).toContain('<line x1="10" y1="10" x2="40" y2="10"')
      expect(reads).toBe(0)
    } finally {
      Reflect.deleteProperty(Object.prototype, 'hit')
      Reflect.deleteProperty(Object.prototype, 'terminalProjection')
    }
  })

'''
s=s[:pos]+block+s[pos:];p.write_text(s)
