from pathlib import Path
r=Path('/dev/shm/pr449-four-final-20261111/native-transaction-fusion-candidate')
p=r/'src/scene/native-paint-emission.ts';n=p.read_text(); a=n.index('export function assertMarkAttributes');b=n.index('/** Every occurrence retains',a)
block=n[a:b];n=n[:a]+n[b:]
imports=n[:n.index("import { nativeTextPaintWriteOf")]
n=n[n.index("import { nativeTextPaintWriteOf"):]
n="import { normalizeConnector, type NativeConnectorSource } from './connector-construction.ts'\nimport type { ConnectorFields } from './marks.ts'\n"+n
block=block.replace('function normalizeConnector(', 'export function normalizeConnector(')
helper=imports.replace("import type { NativeConnectorPaintSource } from './inspection.ts'\n",'')+"import type { ConnectorMark, MarkerDescriptor, MarkPaint } from './ir.ts'\nimport { connectorContourSemantics } from './connector-geometry.ts'\n"+block
(r/'src/scene/connector-construction.ts').write_text(helper);p.write_text(n)
p=r/'src/scene/marks.ts';s=p.read_text().replace("from './native-paint-emission.ts'", "from './connector-construction.ts'");p.write_text(s)
# Private source type is a Pick/Omit of the existing interfaces; SDK type unchanged.
for name in ['native-drawing.ts','inspection.ts','bounds.ts','emission-context.ts','svg-writer.ts','scene-validation-core.ts']:
 p=r/'src/scene'/name;s=p.read_text();s="import type { NativeConnectorSource } from './connector-construction.ts'\n"+s
 if name=='native-drawing.ts':
  s=s.replace("type LeafNode = Exclude<SceneNode, { kind: 'group' }>","type LeafNode = Exclude<SceneNode, { kind: 'group' }> | NativeConnectorSource")
  s=s.replace('validator.write(captured, xml, 0, sink)',"validator.write(captured, xml, 0, sink, captured.kind === 'connector' && !('hit' in captured))")
  s=s.replace('connector: fields => leaf(marks.connector(fields)),', 'connector: fields => leaf(emission.directConnector(fields) ?? marks.connector(fields)),')
 elif name=='inspection.ts':
  s=s.replace("readonly node: Exclude<SceneNode, { kind: 'group' }>","readonly node: Exclude<SceneNode, { kind: 'group' }> | NativeConnectorSource")
  s=s.replace("function nonPainting(node: SceneNode,", "function nonPainting(node: SceneNode | NativeConnectorSource,")
  s=s.replace("function nativePaintSource(node: Exclude<SceneNode, { kind: 'group' }>,", "function nativePaintSource(node: Exclude<SceneNode, { kind: 'group' }> | NativeConnectorSource,")
  s=s.replace("semanticNode: Exclude<SceneNode, { kind: 'group' }>","semanticNode: Exclude<SceneNode, { kind: 'group' }> | NativeConnectorSource")
  # TypeScript needs parentheses for unions in optional parameters.
  s=s.replace("servedNode?: Exclude<SceneNode, { kind: 'group' }>","servedNode?: Exclude<SceneNode, { kind: 'group' }> | NativeConnectorSource")
 elif name=='bounds.ts':
  s=s.replace('function connectorPaintBounds(node: ConnectorMark,', 'function connectorPaintBounds(node: ConnectorMark | NativeConnectorSource,')
  s=s.replace('node: SceneNode, parentTransform?', 'node: SceneNode | NativeConnectorSource, parentTransform?')
 elif name=='emission-context.ts':
  s=s.replace('hint(node: SceneNode)', 'hint(node: SceneNode | NativeConnectorSource)').replace('leaf(node: SceneNode,', 'leaf(node: SceneNode | NativeConnectorSource,')
 elif name=='svg-writer.ts':
  # Direct source retains the same writer, with no fake hit object.
  s=s.replace('writeConnectorSvg(node: ConnectorMark,', 'writeConnectorSvg(node: ConnectorMark | NativeConnectorSource,')
  s=s.replace("if (node.hit.pointerEvents === 'none')", "if (('hit' in node ? node.hit.pointerEvents : node.lineStyle === 'invisible' ? 'none' : 'stroke') === 'none')")
  s=s.replace('connectorInlineLabelSvg(node: ConnectorMark,', 'connectorInlineLabelSvg(node: ConnectorMark | NativeConnectorSource,')
 elif name=='scene-validation-core.ts':
  s=s.replace('enclosing?: SceneOwner): void {','enclosing?: SceneOwner, directConnector = false): void {',1)
  s=s.replace("  } else add(state.diagnostics, 'SCENE_DOCUMENT', `${path}.hit`, 'must be typed hit geometry')", "  } else if (!directConnector) add(state.diagnostics, 'SCENE_DOCUMENT', `${path}.hit`, 'must be typed hit geometry')")
  s=s.replace('  if (!state.external && !state.crossChecks\n    && state.native && deferredTerminalProjectionInput(value) !== undefined) return', '  if (!state.external && !state.crossChecks\n    && state.native && (directConnector || deferredTerminalProjectionInput(value) !== undefined)) return')
  s=s.replace('write(node: SceneNode, capture: SvgXmlCapture, depth?: number, sink?: SvgGeometryWriteSink): SvgXmlWrite','write(node: SceneNode | NativeConnectorSource, capture: SvgXmlCapture, depth?: number, sink?: SvgGeometryWriteSink, directConnector?: boolean): SvgXmlWrite')
  s=s.replace('write(node, capture, nesting = 0, sink) {','write(node, capture, nesting = 0, sink, directConnector = false) {')
  # Only this already-private writer entry selects reduced semantics.
  a=s.index('    write(node, capture, nesting');b=s.index('\n    depth,',a)
  segment=s[a:b].replace('validateNode(node, path, state, nesting)', 'validateNode(node, path, state, nesting, undefined, directConnector)')
  segment=segment.replace('sceneNodeWrite(node, capture, sink, state.serializationObserver)', "directConnector && node.kind === 'connector' ? writeConnectorSvg(node, sink, capture) : sceneNodeWrite(node as SceneNode, capture, sink, state.serializationObserver)")
  s=s[:a]+segment+s[b:]
  s="import { writeConnectorSvg } from './svg-writer.ts'\n"+s
 p.write_text(s)
