from pathlib import Path
r=Path('/dev/shm/pr449-four-final-20261111/native-transaction-fusion-candidate')
p=r/'src/scene/native-paint-emission.ts';s=p.read_text();s=s.replace('const capturedLeaves = new WeakMap<object, Leaf>()','const capturedLeaves = new WeakMap<object, Leaf | undefined>()')
a=s.index('  const directConnector =');b=s.index('  const snapshot = <T>',a)
s=s[:a]+'''  const directConnector = (fields: ConnectorFields): NativeConnectorSource | undefined => {
    if (!closeLeaves) return undefined
    // Only observations omitted with the SDK finish need this eligibility
    // check. It never invokes an optional getter. This is not a proxy brand.
    const plain = (value: unknown, array = false): value is object => {
      if (!value || typeof value !== 'object' || !pay(2)) return false
      const prototype = textPaintProto(value)
      return array ? Array.isArray(value) && prototype === Array.prototype : prototype === textPaintPrototype || prototype === null
    }
    const data = (value: object, key: string): unknown => {
      if (!pay(2)) throw failed
      const slot = textPaintDescriptor(value, key)
      if (slot) { if (!textPaintOwn(slot, 'value')) throw failed; return slot.value }
      const prototype = textPaintProto(value)
      if (prototype && textPaintDescriptor(prototype, key)) throw failed
      return undefined
    }
    try {
      if (!plain(fields)) return undefined
      const geometry = data(fields, 'geometry')
      if (!plain(geometry)) return undefined
      const kind = data(geometry, 'kind')
      if (kind !== 'line' && kind !== 'polyline') return undefined
      data(fields, 'lineStyle')
      if (data(fields, 'hit') !== undefined || data(fields, 'terminalProjection') !== undefined || data(fields, 'transform') !== undefined) return undefined
      const labels = data(fields, 'labels')
      if (labels !== undefined && (!plain(labels, true) || data(labels, 'length') !== 0)) return undefined
      const route = data(fields, 'route')
      if (route !== undefined && (!plain(route) || data(route, 'closed') || data(route, 'contours') || data(route, 'startTangent') || data(route, 'endTangent'))) return undefined
      const endpoints = data(fields, 'endpoints')
      if (endpoints !== undefined && (!plain(endpoints) || data(endpoints, 'start') || data(endpoints, 'end'))) return undefined
      const markers = data(fields, 'markers')
      if (markers !== undefined) {
        if (!plain(markers)) return undefined
        const mid = data(markers, 'mid')
        if (mid !== undefined && (!plain(mid, true) || data(mid, 'length') !== 0)) return undefined
      }
      if (kind === 'line') {
        for (const field of ['x1', 'y1', 'x2', 'y2']) if (typeof data(geometry, field) !== 'number') return undefined
      } else {
        const points = data(geometry, 'points')
        if (!plain(points, true)) return undefined
        const length = data(points, 'length')
        if (typeof length !== 'number' || !Number.isInteger(length) || length < 2) return undefined
        for (const index of [0, length - 1]) {
          const point = data(points, String(index))
          if (!plain(point) || !pay(2)) return undefined
          const keys = textPaintKeys(point)
          if (keys.length !== 2 || typeof data(point, 'x') !== 'number' || typeof data(point, 'y') !== 'number') return undefined
        }
      }
    } catch { return undefined }
    const source = normalizeConnector(fields, true) as NativeConnectorSource
    let retained: NativeConnectorSource | undefined
    try { retained = copy(source, 0, new Set(), 'leaf', true) as NativeConnectorSource } catch { /* One failed capture remains conditional. */ }
    if (pay()) textPaintApply(textPaintPut, capturedLeaves, [source, retained])
    return source
  }
'''+s[b:]
old="      try { captured = closeLeaves && textPaintApply(textPaintGet, capturedLeaves, [node]) === node ? node : copy(node, 0, new Set(), 'leaf', closeLeaves) as Leaf } catch { /* Strict mutable fallback. */ }"
new="""      try {
        captured = closeLeaves && textPaintApply(textPaintHasMap, capturedLeaves, [node])
          ? textPaintApply(textPaintGet, capturedLeaves, [node]) as Leaf | undefined
          : copy(node, 0, new Set(), 'leaf', closeLeaves) as Leaf
      } catch { /* Strict mutable fallback. */ }"""
assert old in s;s=s.replace(old,new)
s=s.replace('const textPaintGet = WeakMap.prototype.get, textPaintPut = WeakMap.prototype.set','const textPaintGet = WeakMap.prototype.get, textPaintPut = WeakMap.prototype.set, textPaintHasMap = WeakMap.prototype.has')
p.write_text(s)
p=r/'src/scene/native-drawing.ts';s=p.read_text();s=s.replace('const leaf = (node: LeafNode): Fragment => {','const leaf = (node: LeafNode, directSource = false): Fragment => {').replace("validator.write(captured, xml, 0, sink, captured.kind === 'connector' && !('hit' in captured))",'validator.write(captured, xml, 0, sink, directSource)')
s=s.replace('connector: fields => leaf(emission.directConnector(fields) ?? marks.connector(fields)),', '''connector: fields => {
      const source = emission.directConnector(fields)
      return source ? leaf(source, true) : leaf(marks.connector(fields))
    },''');p.write_text(s)
p=r/'src/scene/svg-writer.ts';s=p.read_text();a=s.index('export function writeConnectorSvg(');body=s.index('  const out = new SvgWriter(capture)',a)
head='''export function writeConnectorSvg(node: ConnectorMark, sink?: SvgGeometryWriteSink): string
export function writeConnectorSvg(node: ConnectorMark, sink: SvgGeometryWriteSink | undefined, capture: SvgXmlCapture): SvgXmlWrite
export function writeConnectorSvg(node: ConnectorMark, sink?: SvgGeometryWriteSink, capture?: SvgXmlCapture): string | SvgXmlWrite {
  return writeConnector(node, sink, capture, false)
}
/** Internal reduced-source transaction. The source owns no SDK hit payload. */
export function writeNativeConnectorSourceSvg(node: NativeConnectorSource, sink: SvgGeometryWriteSink | undefined, capture: SvgXmlCapture): SvgXmlWrite {
  return writeConnector(node, sink, capture, true) as SvgXmlWrite
}
function writeConnector(node: ConnectorMark | NativeConnectorSource, sink: SvgGeometryWriteSink | undefined, capture: SvgXmlCapture | undefined, directSource: boolean): string | SvgXmlWrite {
'''
s=s[:a]+head+s[body:];s=s.replace("if (('hit' in node ? node.hit.pointerEvents : 'stroke') === 'none')", "if (!directSource && (node as ConnectorMark).hit.pointerEvents === 'none')");p.write_text(s)
p=r/'src/scene/scene-validation-core.ts';s=p.read_text().replace("import { writeConnectorSvg }", "import { writeNativeConnectorSourceSvg }").replace('written = writeConnectorSvg(node, sink, capture)', 'written = writeNativeConnectorSourceSvg(node, sink, capture)')
# The direct call flag comes only from the factory branch. The ordinary SDK
# overload still admits complete Scene nodes and keeps its exact old reads.
a=s.index('function completeSceneNode(');b=s.index('export interface NativeSceneValidator',a);s=s[:a]+s[b:]
s=s.replace('else if (completeSceneNode(node)) written = sceneNodeWrite(node, capture, sink, state.serializationObserver)\n        else throw new TypeError(\'Reduced Native source requires the direct constructor transaction\')', 'else written = sceneNodeWrite(node as SceneNode, capture, sink, state.serializationObserver)');p.write_text(s)
