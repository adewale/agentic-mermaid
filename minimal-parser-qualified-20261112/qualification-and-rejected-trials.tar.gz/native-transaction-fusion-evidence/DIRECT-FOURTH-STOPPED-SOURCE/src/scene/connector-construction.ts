import type { ConnectorFields } from './marks.ts'
import type { ConnectorContourSemantics, ConnectorEndpointAnchor, ConnectorEndpoints, ConnectorGeometry, ConnectorHitGeometry, ConnectorLabelDescriptor, ConnectorRelationship, ConnectorRoute, ConnectorStroke, ConnectorTerminalProjection, MarkAttributes } from './ir.ts'
import type { SvgSemanticIdentity } from './identity.ts'
import { relationAccessibility } from './accessibility.ts'
import { resolveLabelContent } from '../shared/display-text.ts'
import { sanitizeDisplayLines } from '../shared/text-controls.ts'
import { displayText } from '../multiline-utils.ts'
import { FLOWCHART_DOTTED_DASH } from '../styles.ts'
import { connectorInlineLabelText } from './bounds.ts'
import { connectorGeometryHasCurves, connectorMidpoints, connectorSubpaths, pathMoveCount, sameConnectorPoint } from './connector-geometry.ts'
import { setConnectorTerminalProjection } from './deferred-terminal-projection.ts'
import { admitWritableSceneNode } from './serialization.ts'
import { MARK_CLASS_TOKENS, MARK_DATA_KEY, WRITER_OWNED_DATA_KEYS } from './svg-writer.ts'
import type { ConnectorMark, MarkerDescriptor, MarkPaint } from './ir.ts'
import { connectorContourSemantics } from './connector-geometry.ts'
export function assertMarkAttributes(id: string, attributes: MarkAttributes | undefined): void {
  if (!attributes) return
  for (const key of Object.keys(attributes)) {
    if (key !== 'className' && key !== 'data' && key !== 'ariaHidden' && key !== 'tabIndex' && key !== 'ariaLabel') throw new TypeError(`Mark "${id}" has unknown attribute hook "${key}"`)
  }
  if (attributes.className !== undefined && !MARK_CLASS_TOKENS.test(attributes.className)) throw new TypeError(`Mark "${id}" class must be space-separated CSS tokens`)
  for (const [key, value] of Object.entries(attributes.data ?? {})) {
    if (!MARK_DATA_KEY.test(key)) throw new TypeError(`Mark "${id}" has an invalid data attribute key "${key}"`)
    if (WRITER_OWNED_DATA_KEYS.has(key)) throw new TypeError(`Mark "${id}" data-${key} belongs to its typed fields`)
    if (typeof value !== 'string') throw new TypeError(`Mark "${id}" data-${key} must be a string`)
  }
  if (attributes.ariaHidden !== undefined && attributes.ariaHidden !== true) throw new TypeError(`Mark "${id}" ariaHidden must be true when present`)
  if (attributes.tabIndex !== undefined && attributes.tabIndex !== 0) throw new TypeError(`Mark "${id}" tabIndex must be 0 when present`)
  if (attributes.ariaLabel !== undefined && typeof attributes.ariaLabel !== 'string') throw new TypeError(`Mark "${id}" ariaLabel must be a string`)
}

// Runtime admission is closed too: TypeScript permits extra spread properties.
const CONNECTOR_FIELDS: Record<keyof ConnectorFields, true> = {
  id: true, role: true, geometry: true, lineStyle: true, paint: true,
  identity: true, owner: true, visibility: true, endpoints: true, relationship: true, route: true, stroke: true,
  markers: true, labels: true, hit: true, terminalProjection: true, channels: true, transform: true, attributes: true,
}
const CONNECTOR_MARKER_FIELDS: Record<keyof NonNullable<ConnectorFields['markers']>, true> = { start: true, mid: true, end: true }

function assertKnownConnectorFields(value: object, allowed: object, kind: string): void {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError(`${kind} fields must be an object`)
  for (const key of Reflect.ownKeys(value)) {
    if (!Object.hasOwn(allowed, key)) throw new TypeError(`unknown ${kind} field "${String(key)}"`)
  }
}

function connectorGeometryEndpoints(geometry: ConnectorGeometry, closed: boolean): {
  start?: ConnectorEndpointAnchor
  end?: ConnectorEndpointAnchor
} {
  if (geometry.kind === 'line') {
    return {
      start: { point: { x: geometry.x1, y: geometry.y1 } },
      end: { point: { x: geometry.x2, y: geometry.y2 } },
    }
  }
  const subpaths = connectorSubpaths(geometry, closed)
  const start = subpaths[0]?.points[0]
  const finalContour = subpaths.at(-1)
  const end = finalContour?.closed ? finalContour.points[0] : finalContour?.points.at(-1)
  return {
    ...(start ? { start: { point: { ...start } } } : {}),
    ...(end ? { end: { point: { ...end } } } : {}),
  }
}

/** Geometry endpoints are fresh constructor data. Adopt them when there is no
 * caller override; otherwise merge while copying the caller's owner/point. */
function ownConnectorEndpoint(geometry: ConnectorEndpointAnchor | undefined, endpoint: ConnectorEndpointAnchor | undefined): ConnectorEndpointAnchor {
  return endpoint ? {
    ...geometry,
    ...endpoint,
    ...(endpoint.owner ? { owner: { ...endpoint.owner } } : {}),
    ...(endpoint.point ? { point: { ...endpoint.point } } : {}),
  } : geometry ?? {}
}

function numericStrokeWidth(width: string | number): number {
  const parsed = typeof width === 'number' ? width : parseFloat(width)
  return Number.isFinite(parsed) ? Math.max(0, parsed) : 1
}

function connectorDirection(
  endpoints: ConnectorEndpoints,
  startMarker: MarkerDescriptor | undefined,
  endMarker: MarkerDescriptor | undefined,
): ConnectorRelationship['direction'] {
  if (endpoints.from !== undefined && endpoints.from === endpoints.to) return 'self'
  if (startMarker && endMarker) return 'bidirectional'
  if (startMarker) return 'reverse'
  if (endMarker) return 'forward'
  return 'undirected'
}

function projectedMidMarkerId(id: string, geometry: ConnectorGeometry, closed: boolean, markers: readonly MarkerDescriptor[]): string | undefined {
  if (markers.length === 0) return undefined
  const interiorCount = connectorMidpoints(geometry, closed).length
  if (interiorCount === 0) {
    throw new RangeError(`Connector "${id}" has mid markers but no typed interior route points`)
  }
  if (markers.length !== 1 && markers.length !== interiorCount) {
    throw new RangeError(`Connector "${id}" mid markers must contain one repeated descriptor or one descriptor per interior route point`)
  }
  const markerIds = new Set(markers.map(marker => marker.id))
  if (markerIds.size !== 1) {
    throw new RangeError(`Connector "${id}" uses distinct mid markers that one SVG marker-mid carrier cannot represent`)
  }
  return markers[0]!.id
}

export function normalizeConnector(fields: ConnectorFields, direct = false): ConnectorMark | NativeConnectorSource {
  assertKnownConnectorFields(fields, CONNECTOR_FIELDS, 'connector')
  if (fields.markers !== undefined) assertKnownConnectorFields(fields.markers, CONNECTOR_MARKER_FIELDS, 'marker')
  if (fields.geometry.kind !== 'path' && fields.route?.closed === true) {
    throw new TypeError(`Connector "${fields.id}" closed route topology requires path geometry`)
  }
  if (fields.geometry.kind === 'path') {
    const pathGeometry = fields.geometry
    const subpaths = pathGeometry.subpaths
    const moves = pathMoveCount(pathGeometry.d)
    if (moves > 1 && !subpaths) {
      throw new TypeError(`Connector "${fields.id}" path has multiple SVG subpaths but no typed subpaths`)
    }
    if (subpaths) {
      if (subpaths.length === 0 || subpaths.some(subpath => subpath.points.length < 2)) {
        throw new TypeError(`Connector "${fields.id}" typed subpaths must each contain at least two points`)
      }
      if (moves !== subpaths.length) {
        throw new TypeError(`Connector "${fields.id}" typed subpath count disagrees with SVG path moves`)
      }
      const flattened = subpaths.flatMap(subpath => subpath.points)
      if (flattened.length !== pathGeometry.points.length || flattened.some((point, index) => {
        const expected = pathGeometry.points[index]
        return !expected || expected.x !== point.x || expected.y !== point.y
      })) {
      throw new TypeError(`Connector "${fields.id}" typed subpaths disagree with the canonical point projection`)
      }
    }
  }
  const subpaths = connectorSubpaths(fields.geometry, fields.route?.closed ?? false)
  const derivedClosed = subpaths.length === 1 && subpaths[0]!.closed
  if (fields.geometry.kind === 'path' && fields.geometry.subpaths && fields.route?.closed !== undefined && fields.route.closed !== derivedClosed) {
    throw new TypeError(`Connector "${fields.id}" route.closed disagrees with typed subpath topology`)
  }
  const routeClosed = fields.geometry.kind === 'path' && fields.geometry.subpaths ? derivedClosed : fields.route?.closed ?? false
  if (fields.geometry.kind === 'path') {
    const closeCommands = fields.geometry.d.match(/[Zz]/g)?.length ?? 0
    const closedContours = fields.geometry.subpaths
      ? fields.geometry.subpaths.filter(subpath => subpath.closed).length
      : routeClosed ? 1 : 0
    if (closeCommands !== closedContours) {
      throw new TypeError(`Connector "${fields.id}" SVG close commands disagree with typed closed-contour semantics`)
    }
  }
  const markerStart = fields.markers?.start
  const markerEnd = fields.markers?.end
  const midMarkers = fields.markers?.mid ?? []
  for (const marker of [markerStart, ...midMarkers, markerEnd]) {
    if (marker?.geometry?.kind === 'path' && !marker.bounds && !marker.viewBox && !marker.size) {
      throw new TypeError(`Connector "${fields.id}" path marker "${marker.id}" requires bounds, viewBox, or size`)
    }
  }
  const midMarkerId = projectedMidMarkerId(fields.id, fields.geometry, routeClosed, midMarkers)
  const geometryEndpoints = direct ? {} : connectorGeometryEndpoints(fields.geometry, routeClosed)
  for (const position of ['start', 'end'] as const) {
    const supplied = fields.endpoints?.[position]?.point
    const derived = geometryEndpoints[position]?.point
    if (supplied && derived && !sameConnectorPoint(supplied, derived)) {
      throw new TypeError(`Connector "${fields.id}" endpoints.${position}.point disagrees with typed route geometry`)
    }
  }
  const endpoints: ConnectorEndpoints = {
    ...(fields.endpoints ?? {}),
    ...(!direct ? { start: ownConnectorEndpoint(geometryEndpoints.start, fields.endpoints?.start), end: ownConnectorEndpoint(geometryEndpoints.end, fields.endpoints?.end) } : {}),
  }
  const relationship: ConnectorRelationship = {
    kind: fields.relationship?.kind ?? fields.role,
    direction: fields.relationship?.direction ?? connectorDirection(endpoints, markerStart, markerEnd),
  }
  const labels = (fields.labels ?? []).map(label => {
    const input = resolveLabelContent(label.text, label.textContent)
    const text = sanitizeDisplayLines(label.text)
    return { ...label, text, ...(typeof input !== 'string' ? { textContent: { ...label.textContent!, value: text } } : {}) }
  })
  const identity: SvgSemanticIdentity = {
    id: fields.identity?.id ?? fields.id,
    role: fields.role,
    ...(fields.identity?.classNames ? { classNames: fields.identity.classNames } : {}),
    ...(fields.identity?.from ?? endpoints.from ? { from: fields.identity?.from ?? endpoints.from } : {}),
    ...(fields.identity?.to ?? endpoints.to ? { to: fields.identity?.to ?? endpoints.to } : {}),
  }
  const firstLabel = labels[0]
  const accessibleLabel = firstLabel?.visual?.kind === 'inline'
    ? connectorInlineLabelText(firstLabel).lineBlocks.map(line => line.runs.map(run => run.text).join('')).join('\n')
    : firstLabel ? displayText(resolveLabelContent(firstLabel.text, firstLabel.textContent), firstLabel.display ?? 'literal') : undefined
  const accessibility = relationAccessibility(identity, accessibleLabel, fields.relationship?.direction)
  assertMarkAttributes(fields.id, fields.attributes)
  if (accessibility && fields.attributes?.ariaLabel !== undefined) throw new TypeError(`Connector "${fields.id}" takes its aria-label from typed relation accessibility`)
  for (const [index, label] of labels.entries()) {
    if (label.visual?.kind === 'inline' && (!label.anchor || !label.paint || label.fontSize === undefined || label.textAnchor === undefined)) {
      throw new TypeError(`Connector "${fields.id}" inline label ${index + 1} requires anchor, paint, fontSize, and textAnchor`)
    }
  }

  const width = fields.stroke?.width ?? fields.paint.strokeWidth ?? '1'
  const dash = fields.stroke?.dash
    ?? (fields.paint.strokeDasharray ? {
      array: fields.paint.strokeDasharray,
      ...(fields.paint.strokeDashoffset !== undefined ? { offset: fields.paint.strokeDashoffset } : {}),
    } : fields.lineStyle === 'dashed' ? { array: '6 4' }
      : fields.lineStyle === 'dotted' ? { array: `${FLOWCHART_DOTTED_DASH.dash} ${FLOWCHART_DOTTED_DASH.gap}` }
        : undefined)
  const opacity = fields.stroke?.opacity ?? fields.paint.opacity
  const paintOrder = fields.stroke?.paintOrder ?? fields.paint.paintOrder
  const mixBlendMode = fields.stroke?.mixBlendMode
  const stroke: ConnectorStroke = {
    color: fields.stroke?.color ?? fields.paint.stroke ?? 'var(--_line)',
    width,
    ...(opacity !== undefined ? { opacity } : {}),
    ...(dash ? { dash } : {}),
    lineCap: fields.stroke?.lineCap ?? fields.paint.strokeLinecap ?? 'butt',
    lineJoin: fields.stroke?.lineJoin ?? fields.paint.strokeLinejoin ?? 'miter',
    miterLimit: fields.stroke?.miterLimit ?? Number(fields.paint.strokeMiterlimit ?? 4),
    ...(fields.stroke?.pathLength !== undefined ? { pathLength: fields.stroke.pathLength } : {}),
    ...(paintOrder !== undefined ? { paintOrder } : {}),
    ...(mixBlendMode !== undefined ? { mixBlendMode } : {}),
    nonScaling: fields.stroke?.nonScaling ?? fields.paint.vectorEffect === 'non-scaling-stroke',
    ...(fields.stroke?.encodesValue ? { encodesValue: true } : {}),
  }
  const derivedContours = connectorContourSemantics(fields.geometry, routeClosed)
  const suppliedContours = fields.route?.contours
  if (suppliedContours && (suppliedContours.length !== derivedContours.length || suppliedContours.some((contour, index) => {
    const derived = derivedContours[index]
    return !derived
      || contour.start.x !== derived.start.x || contour.start.y !== derived.start.y
      || contour.end.x !== derived.end.x || contour.end.y !== derived.end.y
      || contour.closed !== derived.closed
  }))) {
    throw new TypeError(`Connector "${fields.id}" route contours disagree with typed subpath endpoint topology`)
  }
  const linearGeometry = !connectorGeometryHasCurves(fields.geometry)
  if (linearGeometry && suppliedContours) {
    for (const [index, supplied] of suppliedContours.entries()) {
      const derived = derivedContours[index]!
      for (const field of ['startTangent', 'endTangent'] as const) {
        const actual = supplied[field]
        const expected = derived[field]
        if (actual && (!expected || !sameConnectorPoint(actual, expected, 1e-9))) {
          throw new TypeError(`Connector "${fields.id}" route.contours[${index}].${field} disagrees with linear route geometry`)
        }
      }
    }
  }
  // Fill omitted tangent fields from geometry. Curved projections retain any
  // exact derivative supplied by their lowering over the flattened chord.
  // Geometry derivation owns these fresh contour records and endpoint copies.
  // Keep them directly unless caller-supplied tangents need merging.
  const contours: ConnectorContourSemantics[] = suppliedContours ? derivedContours.map((derived, index) => {
    const supplied = suppliedContours?.[index]
    const startTangent = supplied?.startTangent ?? derived.startTangent
    const endTangent = supplied?.endTangent ?? derived.endTangent
    return {
      start: { ...derived.start },
      end: { ...derived.end },
      closed: derived.closed,
      ...(startTangent ? { startTangent } : {}),
      ...(endTangent ? { endTangent } : {}),
    }
  }) : derivedContours
  for (const contour of contours) {
    for (const tangent of [contour.startTangent, contour.endTangent]) {
      if (!tangent) continue
      const length = Math.hypot(tangent.x, tangent.y)
      if (!Number.isFinite(length) || Math.abs(length - 1) > 1e-9) {
        throw new TypeError(`Connector "${fields.id}" contour tangents must be finite unit vectors`)
      }
    }
  }
  for (const tangent of [fields.route?.startTangent, fields.route?.endTangent]) {
    if (!tangent) continue
    const length = Math.hypot(tangent.x, tangent.y)
    if (!Number.isFinite(length) || Math.abs(length - 1) > 1e-9) {
      throw new TypeError(`Connector "${fields.id}" route tangents must be finite unit vectors`)
    }
  }
  for (const [field, supplied, derived] of [
    ['startTangent', fields.route?.startTangent, contours[0]?.startTangent],
    ['endTangent', fields.route?.endTangent, contours.at(-1)?.endTangent],
  ] as const) {
    if (supplied && derived && !sameConnectorPoint(supplied, derived, 1e-9)) {
      throw new TypeError(`Connector "${fields.id}" route.${field} disagrees with its contour tangent authority`)
    }
  }
  const route: ConnectorRoute = {
    geometry: fields.geometry,
    ownership: fields.route?.ownership ?? 'family',
    closed: routeClosed,
    bendRadius: fields.route?.bendRadius ?? 0,
    contours,
    ...(fields.route?.startTangent ?? contours[0]?.startTangent ? { startTangent: fields.route?.startTangent ?? contours[0]?.startTangent } : {}),
    ...(fields.route?.endTangent ?? contours.at(-1)?.endTangent ? { endTangent: fields.route?.endTangent ?? contours.at(-1)?.endTangent } : {}),
    labelAnchors: fields.route?.labelAnchors ?? labels.flatMap(label => label.anchor ? [label.anchor] : []),
  }

  if (direct) {
  const source: NativeConnectorSource = {
    kind: 'connector',
    id: fields.id,
    role: fields.role,
    lineStyle: fields.lineStyle,
    endpoints,
    relationship,
    route,
    stroke,
    markers: { ...(markerStart ? { start: markerStart } : {}), mid: midMarkers, ...(markerEnd ? { end: markerEnd } : {}) },
    labels,
    identity,
    ...(fields.owner ? { owner: fields.owner } : {}),
    ...(fields.visibility ? { visibility: fields.visibility } : {}),
    ...(accessibility ? { accessibility } : {}),
    ...(fields.channels ? { channels: fields.channels } : {}),
    ...(fields.transform ? { transform: fields.transform } : {}),
    ...(fields.attributes ? { attributes: fields.attributes } : {}),
  }
    return source
  }

  if (fields.hit?.closed !== undefined && fields.hit.closed !== routeClosed) {
    throw new TypeError(`Connector "${fields.id}" hit.closed must match route.closed topology`)
  }
  const hit: ConnectorHitGeometry = {
    geometry: fields.hit?.geometry ?? fields.geometry,
    closed: fields.hit?.closed ?? routeClosed,
    strokeWidth: fields.hit?.strokeWidth ?? Math.max(6, numericStrokeWidth(width)),
    pointerEvents: fields.hit?.pointerEvents ?? (fields.lineStyle === 'invisible' ? 'none' : 'stroke'),
  }
  const terminalInput = {
    geometry: fields.geometry,
    lineStyle: fields.lineStyle,
    endpoints,
    relationship,
    route,
    stroke,
    markers: { ...(markerStart ? { start: markerStart } : {}), mid: midMarkers, ...(markerEnd ? { end: markerEnd } : {}) },
    labels,
    hit,
    ...(fields.transform ? { transform: fields.transform } : {}),
    additionalDiagnostics: fields.terminalProjection?.diagnostics,
  }

  const result: ConnectorMark = {
    kind: 'connector',
    id: fields.id,
    role: fields.role,
    lineStyle: fields.lineStyle,
    endpoints,
    relationship,
    route,
    stroke,
    markers: { ...(markerStart ? { start: markerStart } : {}), mid: midMarkers, ...(markerEnd ? { end: markerEnd } : {}) },
    labels,
    hit,
    terminalProjection: undefined as unknown as ConnectorTerminalProjection,
    identity,
    ...(fields.owner ? { owner: fields.owner } : {}),
    ...(fields.visibility ? { visibility: fields.visibility } : {}),
    ...(accessibility ? { accessibility } : {}),
    ...(fields.channels ? { channels: fields.channels } : {}),
    ...(fields.transform ? { transform: fields.transform } : {}),
    ...(fields.attributes ? { attributes: fields.attributes } : {}),
  }
  setConnectorTerminalProjection(result, terminalInput)
  return admitWritableSceneNode(result)
}

export type NativeConnectorSource = Omit<ConnectorMark, 'hit' | 'terminalProjection'>
export function constructSceneConnector(fields: ConnectorFields): ConnectorMark {
  return normalizeConnector(fields) as ConnectorMark
}

