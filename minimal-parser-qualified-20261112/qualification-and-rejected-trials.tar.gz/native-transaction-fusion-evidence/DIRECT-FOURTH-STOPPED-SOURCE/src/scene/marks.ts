import { assertMarkAttributes, constructSceneConnector } from './connector-construction.ts'
import { isInlinePng } from '../shared/inline-png.ts'
import { SCENE_VALIDATION_LIMITS } from './scene-validation-limits.ts'
import { sanitizeDisplayLines } from '../shared/text-controls.ts'
// ============================================================================
// Mark constructors — the only way family lowerings build scene nodes.
//
// Shape, text and connector marks are semantic fields only: the backend's
// writer (svg-writer.ts) draws each one from those fields, so what paint
// certification reads is what the SVG shows. Groups keep an inert open tag
// (hooks and their typed transform) and compose their children; document
// marks carry opaque SVG the fields cannot describe (preludes, definitions,
// family document content).
// ============================================================================

import type {
  ConnectorContourSemantics, ConnectorDash, ConnectorEndpointAnchor, ConnectorEndpoints, ConnectorGeometry,
  ConnectorHitGeometry, ConnectorLabelDescriptor, ConnectorMark, ConnectorRelationship,
  ConnectorRoute, ConnectorStroke, ConnectorTerminalProjection, DocumentMark, GroupMark,
  Geometry, ImageMark, LinearGradientDescriptor, MarkAttributes, MarkPaint, MarkerDescriptor,
  SceneNode, SceneOwner, SceneRole, SceneTransform, SemanticChannels, ShapeMark, TextMark,
} from './ir.ts'
import type { DiagramColors } from '../theme.ts'
import type { SvgSemanticIdentity } from './identity.ts'
import { ensureSvgIdentity, semanticChildId, semanticIdentityForSvg } from './identity.ts'
import { relationAccessibility } from './accessibility.ts'
import { displayText, escapeAttr, escapeXml } from '../multiline-utils.ts'
import { resolveLabelContent } from '../shared/display-text.ts'
import type { LabelDisplay } from '../multiline-utils.ts'
import { preparePixelText, isOwnedPixelTextPart, type PixelTextBlock } from '../shared/prepared-text.ts'
import {
  connectorContourSemantics,
  connectorGeometryHasCurves,
  connectorMidpoints,
  connectorSubpaths,
  pathMoveCount,
  sameConnectorPoint,
} from './connector-geometry.ts'
import { connectorInlineLabelText } from './bounds.ts'
import { setConnectorTerminalProjection, copyDeferredTerminalProjection, deferredTerminalProjectionInput } from './deferred-terminal-projection.ts'
import type { parseSvgTransform } from './transforms.ts'
import { assertInertGroup, registerGroupEmission } from './group-emission.ts'
import {
  admitWritableSceneNode,
  attachSceneNodeSerialization,
  canonicalizeSceneNodeSerialization,
  hasSceneNodeSerialization,
  transferSceneNodeSerialization,
} from './serialization.ts'
import { MARK_CLASS_TOKENS, MARK_DATA_KEY, WRITER_OWNED_DATA_KEYS } from './svg-writer.ts'
import { LINE_HEIGHT_RATIO } from '../text-metrics.ts'
import { FLOWCHART_DOTTED_DASH } from '../styles.ts'

/** Hooks are inert by construction: class tokens and data-* values only, with
 * the keys the writer derives from typed fields reserved. */

export { retainedGroupEmission } from './group-emission.ts'

/** Typed identity: the explicit public identity, or the mark id with its
 * class tokens, which is what the writer emits as data-id and class. */
function typedIdentity(fields: { id: string; role: SceneRole; identity?: Omit<SvgSemanticIdentity, 'role'> | false; attributes?: MarkAttributes }): SvgSemanticIdentity {
  if (fields.identity) return { ...fields.identity, role: fields.role }
  const classNames = fields.attributes?.className?.split(' ')
  return { id: fields.id, role: fields.role, ...(classNames ? { classNames } : {}) }
}

export function shape(fields: {
  id: string
  role: SceneRole
  /** False only for artwork owned by an enclosing semantic group; the group
   * retains the public identity while this shape retains its paint role. */
  identity?: Omit<SvgSemanticIdentity, 'role'> | false
  owner?: SceneOwner
  visibility?: 'conditional'
  geometry: Geometry
  paint: MarkPaint
  conditionalPaint?: MarkPaint
  surfaceFragment?: boolean
  channels?: SemanticChannels
  transform?: SceneTransform
  attributes?: MarkAttributes
  childPaints?: readonly MarkPaint[]
}): ShapeMark {
  assertMarkAttributes(fields.id, fields.attributes)
  if (fields.childPaints && (fields.geometry.kind !== 'compound' || fields.childPaints.length !== fields.geometry.children.length)) {
    throw new TypeError(`Shape "${fields.id}" child paints must match its compound geometry`)
  }
  if (fields.identity === false && fields.owner?.role !== fields.role) throw new TypeError(`Shape "${fields.id}" without DOM identity requires an explicit owner with the same role`)
  const identity = fields.identity === false ? undefined : typedIdentity(fields)
  const accessibility = identity ? relationAccessibility(identity, fields.attributes?.data?.label) : undefined
  if (accessibility && fields.attributes?.ariaLabel !== undefined) throw new TypeError(`Shape "${fields.id}" takes its aria-label from typed relation accessibility`)
  return admitWritableSceneNode({
    kind: 'shape',
    id: fields.id,
    role: fields.role,
    ...(identity ? { identity } : {}),
    ...(fields.owner ? { owner: fields.owner } : {}),
    ...(fields.visibility ? { visibility: fields.visibility } : {}),
    ...(accessibility ? { accessibility } : {}),
    geometry: fields.geometry,
    paint: fields.paint,
    ...(fields.childPaints ? { childPaints: fields.childPaints } : {}),
    ...(fields.conditionalPaint ? { conditionalPaint: fields.conditionalPaint } : {}),
    ...(fields.surfaceFragment !== undefined ? { surfaceFragment: fields.surfaceFragment } : {}),
    ...(fields.channels ? { channels: fields.channels } : {}),
    ...(fields.transform ? { transform: fields.transform } : {}),
    ...(fields.attributes ? { attributes: fields.attributes } : {}),
  })
}

export function image(fields: Omit<ImageMark, 'kind' | 'identity' | 'accessibility'> & {
  identity?: Omit<SvgSemanticIdentity, 'role'>
}): ImageMark {
  assertMarkAttributes(fields.id, fields.attributes)
  if (typeof fields.href !== 'string' || fields.href.length > SCENE_VALIDATION_LIMITS.maxSerializationBytesPerNode || !isInlinePng(fields.href)) throw new TypeError('Image requires a self-contained PNG data URI')
  if (![fields.x, fields.y, fields.width, fields.height].every(value => Number.isFinite(value) && Math.abs(value) <= SCENE_VALIDATION_LIMITS.maxExtent)
    || fields.width <= 0 || fields.height <= 0 || !['contain', 'stretch'].includes(fields.fit)) throw new TypeError('Image requires a bounded positive viewport and fit')
  const identity = typedIdentity(fields)
  const accessibility = relationAccessibility(identity, fields.attributes?.data?.label)
  if (accessibility && fields.attributes?.ariaLabel !== undefined) throw new TypeError(`Image "${fields.id}" takes its aria-label from typed relation accessibility`)
  return admitWritableSceneNode({
    kind: 'image', id: fields.id, role: fields.role, identity,
    href: fields.href, x: fields.x, y: fields.y, width: fields.width, height: fields.height, fit: fields.fit,
    ...(fields.owner ? { owner: fields.owner } : {}),
    ...(fields.visibility ? { visibility: fields.visibility } : {}),
    ...(accessibility ? { accessibility } : {}),
    ...(fields.channels ? { channels: fields.channels } : {}),
    ...(fields.transform ? { transform: fields.transform } : {}),
    ...(fields.attributes ? { attributes: fields.attributes } : {}),
  })
}

export interface ConnectorFields {
  id: string
  role: SceneRole
  geometry: ConnectorGeometry
  lineStyle: ConnectorMark['lineStyle']
  paint: MarkPaint
  /** Public DOM identity when it differs from the Scene key. */
  identity?: Omit<SvgSemanticIdentity, 'role'>
  owner?: SceneOwner
  visibility?: 'conditional'
  endpoints?: ConnectorEndpoints
  relationship?: Partial<ConnectorRelationship>
  route?: Partial<Omit<ConnectorRoute, 'geometry' | 'labelAnchors'>> & {
    labelAnchors?: readonly { x: number; y: number }[]
  }
  stroke?: Partial<Omit<ConnectorStroke, 'dash'>> & { dash?: ConnectorDash }
  markers?: { start?: MarkerDescriptor; mid?: readonly MarkerDescriptor[]; end?: MarkerDescriptor }
  labels?: readonly ConnectorLabelDescriptor[]
  hit?: Partial<ConnectorHitGeometry>
  /** Optional family-specific terminal limitation additions. Semantic fields
   * are always derived from the connector itself and cannot drift. */
  terminalProjection?: Partial<Pick<ConnectorTerminalProjection, 'diagnostics'>>
  channels?: SemanticChannels
  transform?: SceneTransform
  attributes?: MarkAttributes
}

export function connector(fields: ConnectorFields): ConnectorMark {
  return constructSceneConnector(fields)
}

const preparedRunMap = Array.prototype.map
const preparedRunApply = Reflect.apply
const preparedRunArray = Array, preparedRunPrototype = Array.prototype
const preparedRunDescriptor = Object.getOwnPropertyDescriptor, preparedRunOwn = Object.hasOwn
const preparedRunProto = Object.getPrototypeOf
const preparedRunSpecies = preparedRunDescriptor(Array, Symbol.species)?.get
function legacyPreparedRuns(block: PixelTextBlock): TextMark['preparedLines'] {
  if (!isOwnedPixelTextPart(block)) return block.lineBlocks.map(line => line.runs)
  const lines = block.lineBlocks, map = lines.map
  // Owned blocks already retain these runs. Preserve caller array hooks while
  // avoiding a second roster for the ordinary intrinsic mapping operation.
  const constructor = preparedRunDescriptor(preparedRunPrototype, 'constructor')
  const species = preparedRunDescriptor(preparedRunArray, Symbol.species)
  const intrinsic = map === preparedRunMap && preparedRunProto(lines) === preparedRunPrototype && !preparedRunDescriptor(lines, 'constructor')
    && constructor && preparedRunOwn(constructor, 'value') && constructor.value === preparedRunArray
    && species && !preparedRunOwn(species, 'value') && preparedRunSpecies !== undefined && species.get === preparedRunSpecies
  return intrinsic ? undefined : preparedRunApply(map, lines, [(line: PixelTextBlock['lineBlocks'][number]) => line.runs])
}

export function text(fields: {
  id: string
  role: SceneRole
  /** Optional public DOM identity when the bounded Scene key is internal. */
  identity?: Omit<SvgSemanticIdentity, 'role'>
  owner?: SceneOwner
  visibility?: 'conditional'
  text: string
  x: number
  y: number
  fontSize: number
  fontWeight?: number
  letterSpacing?: number
  display?: LabelDisplay
  block?: PixelTextBlock
  anchor: TextMark['anchor']
  paint: MarkPaint
  pageFill?: string
  channels?: SemanticChannels
  transform?: SceneTransform
  attributes?: MarkAttributes
  baselineShift?: number
  dominantBaseline?: TextMark['dominantBaseline']
  fontStyle?: TextMark['fontStyle']
  textDecoration?: TextMark['textDecoration']
  spans?: TextMark['spans']
}): TextMark {
  const { block, ...semantic } = fields
  if (block) {
    for (const field of ['fontSize', 'fontWeight', 'letterSpacing'] as const) {
      if (fields[field] !== undefined && fields[field] !== block[field]) throw new TypeError(`Text "${fields.id}" ${field} differs from its retained prepared block`)
    }
  }
  assertMarkAttributes(fields.id, fields.attributes)
  const weight = fields.fontWeight ?? block?.fontWeight ?? 400
  const spacing = fields.letterSpacing ?? block?.letterSpacing ?? 0
  const display = fields.display ?? block?.prepared.display ?? 'formatted'
  const measured = block ?? preparePixelText(fields.text, { display, fontSize: fields.fontSize, fontWeight: weight, letterSpacing: spacing })
  if (fields.spans && (measured.lines.length !== 1 || fields.spans.map(span => span.text).join('') !== measured.text)) {
    throw new TypeError(`Text "${fields.id}" spans must spell its one displayed line`)
  }
  // The writer's first baseline: shift ems below y, less half the extra
  // lines, as renderMultilineText places it. Unprepared text keeps that
  // writer's nominal line height. An alphabetic line is centred 0.35em above
  // that baseline; a middle or central baseline is the line's centre, and a
  // hanging baseline its top.
  const shift = fields.baselineShift ?? 0.35
  const lines = measured.lines.length
  const writtenLineHeight = block ? block.lineHeight : fields.fontSize * LINE_HEIGHT_RATIO
  const firstDy = (lines === 1 ? 0 : -((lines - 1) / 2) * writtenLineHeight) + fields.fontSize * shift
  const firstLineCentre = fields.dominantBaseline === 'hanging' ? measured.lineHeight / 2
    : fields.dominantBaseline === 'middle' || fields.dominantBaseline === 'central' ? 0
      : -fields.fontSize * 0.35
  const offsetY = firstDy + (lines - 1) * measured.lineHeight / 2 + firstLineCentre
  const identity = typedIdentity(fields)
  const accessibility = relationAccessibility(identity, fields.attributes?.data?.label)
  if (accessibility && fields.attributes?.ariaLabel !== undefined) throw new TypeError(`Text "${fields.id}" takes its aria-label from typed relation accessibility`)
  return admitWritableSceneNode({
    kind: 'text', ...semantic, identity, accessibility, block: measured, measurement: block ? 'prepared' : 'fallback',
    ...(block ? { prepared: true, preparedLines: legacyPreparedRuns(block) } : {}),
    fontWeight: weight, letterSpacing: spacing, display,
    textLayout: { width: measured.width, height: measured.height, lineHeight: measured.lineHeight, offsetY },
  })
}

export function documentContent(fields: {
  id: string
  role: SceneRole
  nonPaint?: DocumentMark['nonPaint']
  channels?: SemanticChannels
}, svg: string): DocumentMark {
  return attachSceneNodeSerialization({ kind: 'document', element: 'content', ...fields }, svg)
}

export function documentText(fields: {
  id: string
  element: 'title' | 'description'
  text: string
  domId?: string
}): DocumentMark {
  const tag = fields.element === 'title' ? 'title' : 'desc'
  const idAttr = fields.domId ? ` id="${escapeAttr(fields.domId)}"` : ''
  return attachSceneNodeSerialization(
    { kind: 'document', role: 'chrome', ...fields },
    `<${tag}${idAttr}>${escapeXml(fields.text)}</${tag}>`,
  )
}

export function definitions(
  fields: {
    id: string
    markerResources?: readonly MarkerDescriptor[]
    gradientResources?: readonly LinearGradientDescriptor[]
  },
  crisp: string,
): DocumentMark {
  return attachSceneNodeSerialization({ kind: 'document', role: 'defs', element: 'definitions', ...fields }, crisp)
}

export function documentClose(): DocumentMark {
  return attachSceneNodeSerialization({ kind: 'document', id: 'svg-close', role: 'chrome', element: 'close' }, '</svg>')
}

export { indentLines } from './serialization.ts'

export function group(fields: {
  id: string
  role: SceneRole
  owner?: SceneOwner
  visibility?: 'conditional'
  transform?: SceneTransform
  open: string
  close: string
  children: Array<{ node: SceneNode; indent: number }>
  join?: string
  channels?: SemanticChannels
  paint?: GroupMark['paint']
}, nativePay?: (operations: number) => boolean): GroupMark {
  const sourceOpen = fields.open, close = fields.close, join = fields.join ?? '\n'
  const emitted = assertInertGroup({ id: fields.id, open: sourceOpen, close, join, transform: fields.transform })
  const identity = semanticIdentityForSvg(sourceOpen, fields)
  const paint = fields.paint, opacity = paint?.opacity, fill = paint?.fill
  const cascade = paint && [
    ...(opacity !== undefined ? [`opacity="${escapeAttr(opacity)}"`] : []),
    ...(fill !== undefined ? [`fill="${escapeAttr(fill)}"`] : []),
  ].join(' ')
  const painted = cascade ? sourceOpen.replace(/^(\s*<g)\b/, `$1 ${cascade}`) : sourceOpen
  const owner = fields.owner ?? { id: identity.id, role: identity.role }
  // A mark can participate in more than one document. Ownership belongs to
  // this composition, so never mutate a caller's reusable child in place.
  const children = fields.children.map(child => {
    if (child.node.owner || child.node.kind === 'document' || child.node.kind === 'group') return child
    let node: SceneNode
    if (deferredTerminalProjectionInput(child.node)) {
      // A spread would materialize the terminal-only payload. Preserve the
      // enumerable property's position and install a getter for this copy.
      const copied: Record<string, unknown> = {}
      for (const key of Object.keys(child.node)) copied[key] = key === 'terminalProjection' ? undefined : (child.node as unknown as Record<string, unknown>)[key]
      copied.owner = owner
      node = copied as unknown as ConnectorMark
      copyDeferredTerminalProjection(child.node, node)
    } else node = { ...child.node, owner }
    if (hasSceneNodeSerialization(child.node)) transferSceneNodeSerialization(child.node, node)
    return { ...child, node }
  })
  // Relation accessibility belongs to the typed ConnectorMark. Composite
  // wrappers may carry grouping metadata, but must not create a second ARIA
  // relation beside the connector authority. The writer serializes a group
  // from its open tag, children and close tag.
  const open = canonicalizeSceneNodeSerialization(ensureSvgIdentity(painted, identity))
  const result = admitWritableSceneNode({
    kind: 'group',
    id: fields.id,
    role: fields.role,
    open,
    close,
    children,
    join,
    channels: fields.channels,
    identity,
    owner,
    ...(fields.visibility ? { visibility: fields.visibility } : {}),
    ...(fields.transform ? { transform: fields.transform } : {}),
    ...(paint ? { paint } : {}),
  })
  registerGroupEmission(result, { open, opacity, ...emitted, style: emitted.style || fill !== undefined }, nativePay)
  return result
}

export function documentOpen(fields: {
  id: string
  width: number
  height: number
  colors: DiagramColors
  transparent: boolean
  font: string
  hasMonoFont: boolean
  extraCss?: string
}, svg: string): DocumentMark {
  return attachSceneNodeSerialization({
    kind: 'document',
    element: 'open',
    id: fields.id,
    role: 'prelude',
  }, svg)
}

/** Lower bounded, source-owned icon paths without recovering geometry from SVG.
 * Each path carries the paint; the group's open tag carries hooks and the
 * transform only. */
export type PathArtworkFields = {
  id: string
  paths: readonly string[]
  open: string
  paint: MarkPaint
  transform?: SceneTransform
  owner?: SceneOwner
  channels?: SemanticChannels
  join?: string
  indent?: number
}

export function pathArtwork(fields: PathArtworkFields): GroupMark {
  return drawPathArtwork({ shape, group }, fields)
}

/** Share icon lowering with the immediate native writer. */
export function drawPathArtwork<T, G>(factory: {
  shape(fields: Parameters<typeof shape>[0]): T
  group(fields: Omit<Parameters<typeof group>[0], 'children'> & { children: Array<{ node: T; indent: number }> }): G
}, fields: PathArtworkFields): G {
  return factory.group({
    id: fields.id, role: 'icon', open: fields.open, close: '</g>',
    ...(fields.transform ? { transform: fields.transform } : {}),
    ...(fields.owner ? { owner: fields.owner } : {}),
    ...(fields.channels ? { channels: fields.channels } : {}),
    join: fields.join ?? '',
    children: fields.paths.map((path, index) => ({
      indent: fields.indent ?? 0,
      node: factory.shape({ id: semanticChildId(fields.id, 'path', index), role: 'icon',
        geometry: { kind: 'path', d: path }, paint: fields.paint,
        ...(fields.owner ? { owner: fields.owner } : {}),
      }),
    })),
  })
}
