import{readFileSync,writeFileSync}from'node:fs'
const [root,caseName,out]=process.argv.slice(2),base='/dev/shm/pr449-four-final-20261111'
const cases=JSON.parse(readFileSync(base+'/runtime-marker-operand/MEASUREMENT-CASES.json','utf8')),c=cases.find((x:any)=>x.id==='diagnostic:'+caseName),api=await import(root+'/src/index.ts')
const product=api.renderMermaidSVGWithReceipt(c.source,{graphLayout:{backend:'agentic',fallback:'none'}})
writeFileSync(out,JSON.stringify(product));console.log(JSON.stringify({case:caseName,svgBytes:product.svg.length,proof:product.receipt.layoutCertification}))
