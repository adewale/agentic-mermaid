from pathlib import Path
root=Path('/dev/shm/pr449-four-final-20261111/native-transaction-fusion-candidate')
marks=root/'src/scene/marks.ts'; native=root/'src/scene/native-paint-emission.ts'
m=marks.read_text(); n=native.read_text()
a=m.index('// Runtime admission is closed too:'); b=m.index('\nconst preparedRunMap',a)
block=m[a:b]
block=block.replace('export function connector(fields: ConnectorFields): ConnectorMark {','function normalizeConnector(fields: ConnectorFields, direct = false): ConnectorMark | NativeConnectorSource {')
block=block.replace('  const geometryEndpoints = connectorGeometryEndpoints(fields.geometry, routeClosed)','  const geometryEndpoints = direct ? {} : connectorGeometryEndpoints(fields.geometry, routeClosed)')
block=block.replace('    start: ownConnectorEndpoint(geometryEndpoints.start, fields.endpoints?.start),\n    end: ownConnectorEndpoint(geometryEndpoints.end, fields.endpoints?.end),','    ...(!direct ? { start: ownConnectorEndpoint(geometryEndpoints.start, fields.endpoints?.start), end: ownConnectorEndpoint(geometryEndpoints.end, fields.endpoints?.end) } : {}),')
# SDK-only allocations remain after the common source has been formed.
a=block.index('  if (fields.hit?.closed !== undefined'); b=block.index('\n  const result: ConnectorMark',a)
sdk=block[a:b]
block=block[:a]+block[b:]
block=block.replace('  const result: ConnectorMark = {','  const source: NativeConnectorSource = {')
block=block.replace('    hit,\n    terminalProjection: undefined as unknown as ConnectorTerminalProjection,\n','')
block=block.replace('  setConnectorTerminalProjection(result, terminalInput)\n  return admitWritableSceneNode(result)','''  if (direct) return source
'''+sdk+'''
  const result: ConnectorMark = { ...source, hit, terminalProjection: undefined as unknown as ConnectorTerminalProjection }
  setConnectorTerminalProjection(result, terminalInput)
  return admitWritableSceneNode(result)''')
# One canonical normalizer is private to the capture transaction. Public SDK finish retains its complete mutable result.
block += '''\nexport type NativeConnectorSource = Omit<ConnectorMark, 'hit' | 'terminalProjection'>
export function constructSceneConnector(fields: ConnectorFields): ConnectorMark {
  return normalizeConnector(fields) as ConnectorMark
}
'''
m=m[:a]+'''export function connector(fields: ConnectorFields): ConnectorMark {
  return constructSceneConnector(fields)
}
'''+m[b:]
m="import { constructSceneConnector } from './native-paint-emission.ts'\n"+m
# Attribute grammar must stay canonical for both constructors.
a=m.index('function assertMarkAttributes('); b=m.index('\nexport { retainedGroupEmission',a)
attr=m[a:b]
m=m[:a]+m[b:]
m=m.replace("import { constructSceneConnector }", "import { assertMarkAttributes, constructSceneConnector }")
attr=attr.replace('function assertMarkAttributes(', 'export function assertMarkAttributes(')
imports='''import type { ConnectorFields } from './marks.ts'
import type { NativeConnectorPaintSource } from './inspection.ts'
import type { ConnectorContourSemantics, ConnectorEndpointAnchor, ConnectorEndpoints, ConnectorGeometry, ConnectorHitGeometry, ConnectorLabelDescriptor, ConnectorRelationship, ConnectorRoute, ConnectorStroke, ConnectorTerminalProjection, MarkAttributes } from './ir.ts'
import type { SvgSemanticIdentity } from './identity.ts'
import { relationAccessibility } from './accessibility.ts'
import { resolveLabelContent } from '../shared/display-text.ts'
import { sanitizeDisplayLines } from '../shared/text-controls.ts'
import { displayText } from '../multiline-utils.ts'
import { FLOWCHART_DOTTED_DASH } from '../styles.ts'
import { connectorInlineLabelText } from './bounds.ts'
import { connectorGeometryHasCurves, connectorMidpoints, connectorSubpaths, pathMoveCount, sameConnectorPoint } from './connector-geometry.ts'
import { setConnectorTerminalProjection } from './deferred-terminal-projection.ts'
import { admitWritableSceneNode } from './serialization.ts'
import { MARK_CLASS_TOKENS, MARK_DATA_KEY, WRITER_OWNED_DATA_KEYS } from './svg-writer.ts'
'''
n=imports+n
n=n.replace("type Leaf = Exclude<SceneNode, { kind: 'group' }>","type Leaf = Exclude<SceneNode, { kind: 'group' }> | NativeConnectorSource")
# Insert common constructor before the emission creates any callbacks.
pos=n.index('/** Every occurrence retains immutable operands')
n=n[:pos]+attr+'\n'+block+'\n'+n[pos:]
# The closure helper inspects newly allocated normalization records once; raw child operands were already captured.
pos=n.index('  const snapshot = <T>')
n=n[:pos]+'''  const closeConstructed = <T extends object>(record: T): T => {
    // Keep exact operands across ambient sealing hooks. This is only the
    // local constructor roster, never a second walk of the source subtree.
    const keys = textPaintKeys(record)
    if (!pay(2 + keys.length * 3)) throw failed
    const values = keys.map(key => textPaintDescriptor(record, key))
    if (Object.preventExtensions(record) !== record || textPaintExtensible(record) || textPaintFreeze(record) !== record) throw failed
    const actualKeys = textPaintKeys(record)
    if (actualKeys.length !== keys.length) throw failed
    for (let index = 0; index < keys.length; index++) {
      const expected = values[index], actual = textPaintDescriptor(record, keys[index]!)
      if (actualKeys[index] !== keys[index] || !expected || !actual || !textPaintOwn(expected, 'value') || !textPaintOwn(actual, 'value')
        || expected.value !== actual.value || actual.writable || actual.configurable) throw failed
    }
    return record
  }
  const directConnector = (fields: ConnectorFields): NativeConnectorSource | undefined => {
    if (!closeLeaves) return undefined
    let input: ConnectorFields
    try { input = copy(fields) as ConnectorFields } catch { return undefined }
    // This first transaction supports only routes whose SDK metadata is
    // generated, so authored metadata and effects retain their old contract.
    if (input.geometry.kind !== 'polyline' && input.geometry.kind !== 'line' || input.hit !== undefined || input.terminalProjection !== undefined
      || input.labels?.length || input.transform || input.route?.closed || input.route?.contours || input.route?.startTangent || input.route?.endTangent
      || input.endpoints?.start || input.endpoints?.end || input.markers?.mid?.length) return undefined
    const result = normalizeConnector(input, true) as NativeConnectorSource
    try {
      closeConstructed(result.endpoints); closeConstructed(result.relationship); closeConstructed(result.identity!)
      if (result.accessibility) { closeConstructed(result.accessibility.relation); closeConstructed(result.accessibility) }
      closeConstructed(result.stroke)
      for (const contour of result.route.contours) {
        closeConstructed(contour.start); closeConstructed(contour.end)
        if (contour.startTangent) closeConstructed(contour.startTangent)
        if (contour.endTangent) closeConstructed(contour.endTangent)
        closeConstructed(contour)
      }
      closeConstructed(result.route.contours); closeConstructed(result.route.labelAnchors); closeConstructed(result.route)
      closeConstructed(result.markers.mid); closeConstructed(result.markers); closeConstructed(result.labels); closeConstructed(result)
      if (!pay()) throw failed
      capturedLeaves.set(result, result)
      return result
    } catch { return undefined }
  }
'''+n[pos:]
# leaf only avoids walk for exact same request-local constructed value.
n=n.replace('    leaf(node: Leaf, write:', '    directConnector,\n    leaf(node: Leaf, write:')
n=n.replace("      try { captured = copy(node, 0, new Set(), 'leaf', closeLeaves) as Leaf }", "      try { captured = closeLeaves && capturedLeaves.get(node) === node ? node : copy(node, 0, new Set(), 'leaf', closeLeaves) as Leaf }")
marks.write_text(m); native.write_text(n)
