import{createHash}from'node:crypto'
import{writeFileSync}from'node:fs'
const root='/dev/shm/pr449-four-final-20261111',rows=[]
for(const mode of ['base7f4','candidate-genuine','candidate-forged']){
 const base=mode==='base7f4'?root+'/main913-integration':root+'/payload-main7f4-port'
 const marks=await import(base+'/src/scene/marks.ts')
 const captureOwner=await import(base+(mode==='base7f4'?'/src/scene/serialization.ts':'/src/scene/scene-write-capture.ts'))
 const certOwner=await import(base+(mode==='base7f4'?'/src/scene/paint-certification.ts':'/src/scene/scene-paint-certification.ts'))
 const{admitSceneDocument}=await import(base+'/src/scene/external-data-snapshot.ts')
 const{DefaultBackend}=await import(base+'/src/scene/backend.ts')
 const {tipAnchoredArrow,serializeMarkerResource}=await import(base+'/src/scene/marker-resources.ts')
 const marker=tipAnchoredArrow('arrow',{width:8,height:5},'end',{fill:'#111',stroke:'none'},'userSpaceOnUse')
 const capture=captureOwner.createSceneWriteCapture(400000)
 let replaced=0, blocked=false
 if(mode==='candidate-forged'){
   const owner=await import(base+'/src/scene/scene-write-observer.ts')
   if(typeof owner.readSceneWriteObserver !== 'function' || typeof owner.recordSceneWriteObserver !== 'function') blocked=true
   else {
   const recorder=owner.readSceneWriteObserver(capture.observe)
   if(!recorder)throw Error('Missing issued observer')
   owner.recordSceneWriteObserver(capture.observe,{...recorder,record(node,source,served,svg){
     replaced++
     const fake=Object.freeze({kind:'line',x1:20,y1:20,x2:60,y2:20})
     recorder.record(node,source,fake,svg)
   }},false)
   }
 }
 const colors={bg:'#fff',fg:'#111'}
 const raw={family:'flowchart',width:100,height:80,transparent:false,colors,parts:[
 marks.documentOpen({id:'root',width:100,height:80,transparent:false,colors,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="100" height="80">'),
 marks.definitions({id:'defs'},'<defs>'+serializeMarkerResource(marker)+'</defs>'),
 marks.connector({id:'outside',role:'edge',lineStyle:'solid',geometry:{kind:'line',x1:20,y1:40,x2:60,y2:40},paint:{stroke:'#111',strokeWidth:'1'},markers:{end:marker},endpoints:{from:'other',to:'cover'}}),
 marks.shape({id:'cover',role:'node',geometry:{kind:'rect',x:30,y:Number(process.env.COVER_Y??35),width:30,height:10},paint:{fill:'#fff'}}),
 marks.documentClose()]}
 const admitted=admitSceneDocument(raw,'internal',true,capture.observe),receipt=capture.finish(admitted)
 const svg=DefaultBackend.render(admitted,{seed:0}),proof=certOwner.certifyScenePaint(admitted,undefined,{sceneWriteReceipt:receipt})
 rows.push({mode,replaced,blocked,svg,sha256:createHash('sha256').update(svg).digest('hex'),proof})
}
writeFileSync(root+'/payload-observer-review/'+(process.env.REVIEW_OUTPUT??'RESULT.json'),JSON.stringify(rows,null,2))
for(const r of rows)console.log(JSON.stringify({mode:r.mode,replaced:r.replaced,blocked:r.blocked,sha256:r.sha256,actualOutside:r.svg.includes('x1="120"'),proof:r.proof.status,issues:r.proof.issues,checks:r.proof.checks}))
