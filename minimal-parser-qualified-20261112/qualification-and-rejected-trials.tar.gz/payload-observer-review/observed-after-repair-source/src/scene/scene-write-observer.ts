import type { SceneNode, SceneDoc, Geometry, ShapeMark } from './ir.ts'
import type { WrittenCompoundInput } from './written-geometry.ts'
export const sceneObserverCreate = Object.create, sceneObserverWeakMap = WeakMap
export const sceneObserverGet = WeakMap.prototype.get, sceneObserverSet = WeakMap.prototype.set, sceneObserverDelete = WeakMap.prototype.delete, sceneObserverApply = Reflect.apply
export const groupObserverHas = WeakSet.prototype.has, groupObserverAdd = WeakSet.prototype.add, groupObserverApply = Reflect.apply
export const groupFreeze = Object.freeze
export interface GroupComposition {
  readonly valid: boolean
  invalidate(): void
  beforeMap(children: unknown): void
  beforeSpread(mapped: unknown): void
  beforeJoin(parts: unknown): void
  indent(svg: string, spaces: number): string
}
/** First-write data belongs to one admission transaction, not a global node
 * proof cache. A later request cannot borrow an earlier cached serialization. */
declare const sceneWriteObserver: unique symbol
export interface SceneSerializationObserver { readonly [sceneWriteObserver]: true }
export type SceneWriteCallback = (node: SceneNode, source: Geometry, served: Geometry | undefined, svg: string) => void
export interface SceneWriteRecorder {
  string(node: Exclude<SceneNode, { kind: 'group' }>, svg: string): void
  root(scene: SceneDoc): { readonly composition: GroupComposition; underlay(svg: string): void; complete(sealed: boolean): void } | undefined
  reserve(): boolean
  reserveProjection(operations: number): boolean
  document(node: Extract<SceneNode, { kind: 'document' }>, svg: string): void
  connector(node: ConnectorNode): void
  group(node: Extract<SceneNode, { kind: 'group' }>): { readonly composition: GroupComposition | undefined; complete(sealed: boolean): void } | undefined
  hint(node: SceneNode): boolean
  compound(node: ShapeMark): WrittenCompoundInput | undefined
  compoundRecord(node: ShapeMark, input: WrittenCompoundInput, svg: string): void
  rectangle(node: ShapeMark): boolean
  rectangleRecord(node: ShapeMark, source: Geometry, served: Geometry | undefined, attributes: Readonly<Record<string, string>> | undefined, svg: string): void
  contextLeaf(node: Exclude<SceneNode, { kind: 'group' }>, svg: string): void
  leaf(node: Exclude<SceneNode, { kind: 'group' }>, svg: string): void
  record: SceneWriteCallback
}
// Explicit transaction tokens identify recorders; there is no active global
// observer, and callers cannot invoke or substitute a recorder callback.
