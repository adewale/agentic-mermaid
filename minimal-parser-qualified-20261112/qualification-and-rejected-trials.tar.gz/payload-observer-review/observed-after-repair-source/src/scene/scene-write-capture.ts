import { MAX_OCCLUSION_OPERATIONS } from './paint-work.ts'
import { connectorContourSemantics } from './connector-geometry.ts'
import { isAdmittedSceneDocument } from './scene-admission-state.ts'
import { isOwnDataSceneSnapshot, isOwnDataSceneSnapshotInert, isOwnDataSceneArrayInert } from './scene-data-snapshot.ts'
import type { SceneDoc, SceneNode, Geometry, MarkPaint, ShapeMark } from './ir.ts'
import { rectanglePaintFields, writtenPolylineProjectionOf, prepareWrittenCompoundShape, observeWrittenCompoundShape, completeWrittenCompoundShape, type WrittenCompoundInput } from './written-geometry.ts'
import { createEmissionContext, type EmissionColorResolver } from './emission-context.ts'
import { writtenSceneNodeSerialization, isTransferredWritableSceneNode, transferredWritableSceneNodeInert, indentLines, newSceneWriteObserver } from './serialization.ts'
import { sceneObserverWeakMap, sceneObserverGet, sceneObserverSet, sceneObserverDelete, sceneObserverApply, groupFreeze, groupObserverHas, groupObserverApply, type SceneSerializationObserver, type SceneWriteCallback, type SceneWriteRecorder, type ConnectorNode, type GroupComposition } from './scene-write-observer.ts'

// Only this actual Scene capture owner can attach/detach its observation token
// to the backend context. No public setter can replace a live binding.
const backendWriteObservers = new WeakMap<object, SceneSerializationObserver>()
export function sceneBackendWriteObserver(context: object): SceneSerializationObserver | undefined {
  return sceneObserverApply(sceneObserverGet, backendWriteObservers, [context])
}

interface WrittenPath { readonly source: Geometry | undefined; readonly svg: string; readonly served: Exclude<SceneNode, { kind: 'group' }>; readonly conditional: boolean; readonly path: boolean }
export interface SceneWriteWork { readonly scene: SceneDoc; readonly operations: number; readonly exhausted: boolean; readonly uncertain: boolean; readonly fractionalCircleContext: boolean; readonly resolveColor?: EmissionColorResolver }

const ownValue = (value: object, key: string): unknown => {
  const descriptor = Object.getOwnPropertyDescriptor(value, key)
  return descriptor && Object.hasOwn(descriptor, 'value') ? descriptor.value : undefined
}

class CapturedSceneWrites {
  readonly #scene: SceneDoc
  readonly #paths: ReadonlyMap<SceneNode, WrittenPath>
  readonly #operations: number
  readonly #exhausted: boolean
  readonly #maxOperations: number
  readonly #uncertain: boolean
  readonly #resolveColor: EmissionColorResolver | undefined
  readonly #fractionalCircleContext: boolean
  constructor(scene: SceneDoc, paths: ReadonlyMap<SceneNode, WrittenPath>, operations: number, exhausted: boolean, maxOperations: number, uncertain: boolean, fractionalCircleContext: boolean, resolveColor?: EmissionColorResolver) {
    this.#scene = scene; this.#paths = paths; this.#operations = operations; this.#exhausted = exhausted; this.#maxOperations = maxOperations; this.#uncertain = uncertain; this.#fractionalCircleContext = fractionalCircleContext; this.#resolveColor = resolveColor
  }

  begin(scene: SceneDoc) {
    if (scene !== this.#scene) return undefined
    let operations = this.#operations, exhausted = this.#exhausted
    const consumed = new Set<SceneNode>()
    return {
      node: (node: Exclude<SceneNode, { kind: 'group' }>): WrittenPath | undefined => {
        if (exhausted || operations > this.#maxOperations - 16) { exhausted = true; return undefined }
        operations += 16
        const written = this.#paths.get(node)
        if (!written || written.served.kind !== node.kind || writtenSceneNodeSerialization(node) !== written.svg) return undefined
        if (node.kind === 'connector') {
          const route = ownValue(node, 'route')
          if (!route || typeof route !== 'object' || ownValue(route, 'geometry') !== written.source) return undefined
        } else {
          if (consumed.has(node)) return undefined
          consumed.add(node)
          if (node.kind === 'shape' ? ownValue(node, 'geometry') !== written.source : node.kind !== 'text' || written.source !== undefined) return undefined
        }
        return written
      },
      work: (): SceneWriteWork => Object.freeze({ scene, operations, exhausted, uncertain: this.#uncertain, fractionalCircleContext: this.#fractionalCircleContext, resolveColor: this.#resolveColor }),
    }
  }
}
const issuedSceneWrites = new WeakSet<CapturedSceneWrites>()
Object.freeze(CapturedSceneWrites.prototype)
export type SceneWriteReceipt = CapturedSceneWrites

export function beginSceneWriteInspection(receipt: SceneWriteReceipt | undefined, scene: SceneDoc) {
  try { return receipt !== undefined && issuedSceneWrites.has(receipt) && receipt instanceof CapturedSceneWrites && isAdmittedSceneDocument(scene) ? receipt.begin(scene) : undefined } catch { return undefined }
}

export function createSceneWriteCapture(maxOperations: number, options: { fractionalCircleOutput?: boolean; pageUnderlay?: boolean } = {}, actualBackendWrite = false) {
  if (!Number.isSafeInteger(maxOperations) || maxOperations < 0 || maxOperations > MAX_OCCLUSION_OPERATIONS) throw new RangeError('Invalid Scene write work allowance')
  const option = Object.getOwnPropertyDescriptor(options, 'fractionalCircleOutput')
  const fractionalCircleOutput = !!option && Object.hasOwn(option, 'value') && option.value === true
  let operations = 0, exhausted = false
  let phase: 'collecting' | 'prepared' | 'emitting' | 'finished' = 'collecting'
  const paths = new Map<SceneNode, WrittenPath>()
  const pay = (count: number): boolean => {
    if (exhausted || !(actualBackendWrite ? groupSafeInteger(count) : Number.isSafeInteger(count)) || count < 0 || count > maxOperations - operations) { exhausted = true; return false }
    operations += count
    return true
  }
  const context = createEmissionContext(pay, { pageUnderlay: actualBackendWrite && Object.getOwnPropertyDescriptor(options, 'pageUnderlay')?.value === true })
  const admissionStrings = new sceneObserverWeakMap<object, { readonly svg: string; readonly kind: string }>()
  let preparedScene: SceneDoc | undefined, preparedContext: ReturnType<typeof context.finish> | undefined
  let backendContext: object | undefined
  let activeProof: import('./paint-certification.ts').PaintLayoutCertification | undefined
  let actualRoots = 0, actualRootCompleted = false, actualClosed = true
  const string = (node: Exclude<SceneNode, { kind: 'group' }>, svg: string): void => {
    if (!actualBackendWrite || phase === 'finished') return
    if (phase !== 'emitting') {
      if (!pay(1)) return
      const prior = sceneObserverApply(sceneObserverGet, admissionStrings, [node]) as { svg: string; kind: string } | undefined
      if (prior) { if (prior.svg !== svg || prior.kind !== node.kind) actualClosed = false; return }
      sceneObserverApply(sceneObserverSet, admissionStrings, [node, { svg, kind: node.kind }])
      return
    }
    // Same primitive equality used by the existing flat leaf-custody check.
    // The first value is this actual return, never a second ambient cache get.
    if (!pay(4)) return
    const pinned = sceneObserverApply(sceneObserverGet, admissionStrings, [node]) as { svg: string; kind: string } | undefined
    if (!pinned || pinned.kind !== node.kind || typeof svg !== 'string' || pinned.svg !== svg) actualClosed = false
  }
  const rectangles = new WeakSet<ShapeMark>()
  const fractional = new WeakSet<SceneNode>()
  const inert = <T extends object>(source: T, field?: string, value?: unknown): T | undefined => {
    if (!pay(2)) return undefined
    const keys = Object.getOwnPropertyNames(source)
    if (!pay(keys.length * 3)) return undefined
    const result = Object.create(null) as T
    let replaced = false
    for (const key of keys) {
      const descriptor = Object.getOwnPropertyDescriptor(source, key)
      if (!descriptor || !Object.hasOwn(descriptor, 'value')) return undefined
      if (key === field) replaced = true
      Object.defineProperty(result, key, { value: key === field ? value : descriptor.value, enumerable: descriptor.enumerable })
    }
    if (field !== undefined && !replaced) return undefined
    return Object.preventExtensions(result)
  }
  const hint = (node: SceneNode): boolean => {
    if (phase === 'finished' || !fractionalCircleOutput || actualBackendWrite && phase === 'emitting') return false
    // No extra property access or reflection reaches an ordinary raw mark.
    if (!isTransferredWritableSceneNode(node)) { context.invalidateFractionalCircle(); return false }
    if (!pay(2)) return false
    if (!isOwnDataSceneSnapshot(node)) {
      if (!pay(4) || Object.getPrototypeOf(node) !== null || !Object.isFrozen(node)) { context.invalidateFractionalCircle(); return false }
      const keys = Object.getOwnPropertyNames(node)
      if (!pay(keys.length * 2)) return false
      for (const key of keys) if (!Object.hasOwn(Object.getOwnPropertyDescriptor(node, key)!, 'value')) { context.invalidateFractionalCircle(); return false }
    }
    if (!context.hint(node)) return false
    fractional.add(node)
    return true
  }
  const compound = (node: ShapeMark): WrittenCompoundInput | undefined => {
    // This independent first-write receipt also serves polygon markers. The
    // circle/cross hint is not a prerequisite, and raw marks are never reflected.
    if (phase === 'finished' || !fractionalCircleOutput || !isTransferredWritableSceneNode(node)) return undefined
    if (!pay(4) || Object.getPrototypeOf(node) !== null || !Object.isFrozen(node)) return undefined
    const geometry = ownValue(node, 'geometry')
    if (!geometry || typeof geometry !== 'object' || ownValue(geometry, 'kind') !== 'compound') return undefined
    return prepareWrittenCompoundShape(node, pay)
  }
  const compoundRecord = (node: ShapeMark, input: WrittenCompoundInput, svg: string): void => {
    if (phase === 'finished') return
    const source = ownValue(node, 'geometry')
    if (!source || typeof source !== 'object') return
    const projection = completeWrittenCompoundShape(input, source as Geometry, svg, pay)
    if (!projection) return
    const proof = inert(node), overlay = proof && replace(proof, 'geometry', projection.geometry)
    const served = overlay && replace(overlay, 'childPaints', projection.childPaints)
    if (!served) return
    if (paths.has(node)) { paths.delete(node); exhausted = true; return }
    paths.set(node, Object.freeze({ source: source as Geometry, svg, served, conditional: false, path: false }))
  }
  const rectangle = (node: ShapeMark): boolean => {
    if (!fractional.has(node) || !pay(32)) return false
    const geometry = ownValue(node, 'geometry'), paint = ownValue(node, 'paint')
    if (!geometry || typeof geometry !== 'object' || !paint || typeof paint !== 'object'
      || Object.getPrototypeOf(geometry) !== null || !Object.isFrozen(geometry)
      || Object.getPrototypeOf(paint) !== null || !Object.isFrozen(paint) || 'transform' in node
      || ownValue(geometry, 'kind') !== 'rect') return false
    for (const field of ['x', 'y', 'width', 'height']) if (typeof ownValue(geometry, field) !== 'number') return false
    if (!((ownValue(geometry, 'width') as number) > 0 && (ownValue(geometry, 'height') as number) > 0)) return false
    for (const field of ['rx', 'ry']) if (ownValue(geometry, field) !== undefined && ownValue(geometry, field) !== 0) return false
    for (const field of Object.keys(rectanglePaintFields) as (keyof MarkPaint)[]) {
      if (!pay(4)) return false
      const descriptor = Object.getOwnPropertyDescriptor(paint, field)
      if (!descriptor) { if (field in paint) return false; continue }
      if (!Object.hasOwn(descriptor, 'value') || descriptor.value !== undefined && (typeof descriptor.value !== 'string' || rectanglePaintFields[field].numeric && descriptor.value.length >= 13)) return false
    }
    rectangles.add(node)
    return true
  }
  const rectangleRecord = (node: ShapeMark, source: Geometry, served: Geometry | undefined, attributes: Readonly<Record<string, string>> | undefined, svg: string): void => {
    if (phase === 'finished' || !rectangles.has(node) || !pay(64) || ownValue(node, 'geometry') !== source) return
    let conditional = !served || served.kind !== 'rect' || source.kind !== 'rect' || !attributes
    if (served?.kind === 'rect' && (!(served.width > 0 && served.height > 0) || (served.rx ?? 0) !== 0 || (served.ry ?? 0) !== 0)) conditional = true
    let matched = 0
    const paint = node.paint
    if (attributes) for (const field of Object.keys(rectanglePaintFields) as (keyof MarkPaint)[]) {
      if (!pay(4)) return
      const attribute = rectanglePaintFields[field].attribute, expected = paint[field]
      const descriptor = Object.getOwnPropertyDescriptor(attributes, attribute)
      const ownData = !!descriptor && Object.hasOwn(descriptor, 'value')
      if (descriptor && (!ownData || typeof descriptor.value !== 'string')) conditional = true
      const actual = ownData ? descriptor.value as string | undefined : undefined
      if (!pay((expected?.length ?? 0) + (actual?.length ?? 0))) return
      if (actual !== expected) conditional = true
      if (descriptor) matched++
    }
    if (attributes && (!pay(16) || Object.getOwnPropertyNames(attributes).length !== matched)) conditional = true
    const geometry = served && inert(served)
    const overlay = geometry && inert(node, 'geometry', geometry)
    if (paths.has(node)) { paths.delete(node); exhausted = true; return }
    paths.set(node, Object.freeze({ source, svg, served: overlay ?? node, conditional: conditional || !overlay, path: false }))
  }
  const replace = <T extends object>(source: T, key: string, value: unknown): T | undefined => {
    if (!pay(2)) return undefined
    const keys = Object.getOwnPropertyNames(source)
    if (!pay(keys.length * 3) || !Object.hasOwn(source, key)) return undefined
    const result = Object.create(Object.getPrototypeOf(source)) as T
    for (const name of keys) {
      const descriptor = Object.getOwnPropertyDescriptor(source, name)!
      Object.defineProperty(result, name, name === key ? { ...descriptor, value } : descriptor)
    }
    return Object.preventExtensions(result)
  }
  const record: SceneWriteCallback = (node, source, served, svg) => {
    if (phase === 'finished' || !pay(64) || node.kind !== 'connector') return
    const route = ownValue(node, 'route')
    if (!route || typeof route !== 'object' || ownValue(route, 'geometry') !== source) return
    let paintNode = node, conditional = !served || served.kind !== source.kind
    if (served && !conditional && served !== source) {
      if (ownValue(node, 'transform') || ownValue(route, 'closed') || served.kind === 'polyline' && node.markers.mid.length !== 0) conditional = true
      else if (served.kind === 'path') {
        if (typeof ownValue(source, 'd') !== 'string') return
        const geometry = replace(source, 'd', served.d)
        const paintRoute = geometry && replace(route, 'geometry', geometry)
        const overlay = paintRoute && replace(node, 'route', paintRoute)
        if (!overlay) return
        paintNode = overlay
      } else if (served.kind === 'line' || served.kind === 'polyline') {
        if (!pay(192)) return
        const projection = served.kind === 'polyline' ? writtenPolylineProjectionOf(served) : undefined
        if (served.kind === 'polyline' && !projection) return
        Object.freeze(served)
        const contours = projection?.contours ?? connectorContourSemantics(served, false)
        if (!projection) {
          for (const contour of contours) {
            Object.freeze(contour.start); Object.freeze(contour.end)
            if (contour.startTangent) Object.freeze(contour.startTangent)
            if (contour.endTangent) Object.freeze(contour.endTangent)
            Object.freeze(contour)
          }
          Object.freeze(contours)
        }
        const first = contours[0], last = contours.at(-1)
        conditional = !first || !last || (served.kind === 'polyline'
          ? projection!.collapsed
          : first.start.x === last.end.x && first.start.y === last.end.y)
        if (!pay(2)) return
        const routeKeys = Object.getOwnPropertyNames(node.route)
        if (!pay(routeKeys.length * 3 + 12)) return
        const paintRoute = Object.create(Object.getPrototypeOf(node.route)) as ConnectorNode['route']
        for (const key of routeKeys) {
          const descriptor = Object.getOwnPropertyDescriptor(node.route, key)
          if (!descriptor || !Object.hasOwn(descriptor, 'value')) return
          const value = key === 'geometry' ? served : key === 'contours' ? contours : key === 'startTangent' ? first?.startTangent : key === 'endTangent' ? last?.endTangent : descriptor.value
          Object.defineProperty(paintRoute, key, { ...descriptor, value })
        }
        Object.preventExtensions(paintRoute)
        const overlay = replace(node, 'route', paintRoute)
        if (!overlay) return
        paintNode = overlay
      } else conditional = true
    }
    if (paths.has(node)) { paths.delete(node); exhausted = true; return }
    paths.set(node, Object.freeze({ source, svg, served: paintNode, conditional, path: source.kind === 'path' }))
  }
  const recorder: SceneWriteRecorder = {
    string,
    root: scene => actualBackendWrite && phase === 'emitting' && scene === preparedScene && pay(4) ? (actualRoots++, {
      composition: groupComposition(scene as never, pay, true),
      underlay: svg => {
        if (svg === '') return
        if (!pay(svg.length * 2 + 16) || svg !== preparedContext?.pageUnderlay
          || groupOwnDescriptor(scene.parts, '0')?.value !== preparedContext?.pagePrelude) actualClosed = false
      },
      complete: sealed => { actualRootCompleted = true; if (!pay(2) || !sealed) actualClosed = false },
    }) : undefined,
    reserve: () => phase !== 'finished' && phase !== 'emitting' && pay(192), reserveProjection: count => phase !== 'finished' && phase !== 'emitting' && pay(count),
    document: (node, svg) => { if (phase !== 'finished' && phase !== 'emitting') context.document(node, svg) },
    connector: node => { if (phase !== 'finished' && phase !== 'emitting') context.connector(node) },
    group: node => {
      if (phase === 'finished') return undefined
      if (phase !== 'emitting') { context.group(node); return undefined }
      const composition = transferredWritableSceneNodeInert(node) && isOwnDataSceneSnapshotInert(node) ? groupComposition(node, pay) : undefined
      return { composition, complete: sealed => { if (!pay(2) || !sealed) actualClosed = false } }
    }, hint, compound, compoundRecord, rectangle, rectangleRecord,
    contextLeaf: (node, svg) => {
      if (phase === 'finished' || phase === 'emitting' || !fractionalCircleOutput) return
      if (!isTransferredWritableSceneNode(node)) { context.invalidateFractionalCircle(); return }
      context.leaf(node, svg)
    },
    leaf: (node, svg) => {
      if (phase === 'finished' || phase === 'emitting' || !fractional.has(node) || node.kind !== 'text' || !pay(32)) return
      if (paths.has(node)) { paths.delete(node); exhausted = true; return }
      paths.set(node, Object.freeze({ source: undefined, svg, served: node, conditional: false, path: false }))
    }, record }
  const observe = newSceneWriteObserver(recorder, actualBackendWrite)
  const detach = (): void => { if (backendContext) { sceneObserverApply(sceneObserverDelete, backendWriteObservers, [backendContext]); backendContext = undefined }
    activeProof = undefined
  }
  const receipt = (scene: SceneDoc, result: ReturnType<typeof context.finish>): SceneWriteReceipt => {
    const value = new CapturedSceneWrites(scene, paths, operations, exhausted, maxOperations, result.uncertain,
      fractionalCircleOutput && result.fractionalCircleContext && !exhausted, result.uncertain ? undefined : result.resolveColor)
    Object.freeze(value); issuedSceneWrites.add(value); return value
  }
  return {
    observe,
    prepare(scene: SceneDoc): SceneWriteReceipt | undefined {
      if (!actualBackendWrite || phase !== 'collecting') throw new Error('Invalid Scene preparation phase')
      if (!isAdmittedSceneDocument(scene)) return undefined
      phase = 'prepared'
      preparedScene = scene
      preparedContext = context.finish(scene)
      return receipt(scene, preparedContext)
    },
    beginBackendEmission(scene: SceneDoc, contextObject: object, proof: import('./paint-certification.ts').PaintLayoutCertification): void {
      if (!actualBackendWrite || phase !== 'prepared' || scene !== preparedScene || !preparedContext) throw new Error('Invalid Scene actual-write phase')
      const completed = proof.checks.operations
      if (!groupSafeInteger(completed) || completed < 0 || completed > maxOperations) throw new Error('Invalid Scene proof continuation')
      if (completed < operations) actualClosed = false
      else pay(completed - operations)
      for (let index = 0; index < proof.issues.length; index++) if (proof.issues[index]!.code === 'CHECK_BUDGET') exhausted = true
      phase = 'emitting'; backendContext = contextObject; activeProof = proof
      sceneObserverApply(sceneObserverSet, backendWriteObservers, [contextObject, observe])
    },
    abortBackendEmission(): void { phase = 'finished'; actualClosed = false; detach() },
    finishActual(proof: import('./paint-certification.ts').PaintLayoutCertification): import('./paint-certification.ts').PaintLayoutCertification {
      if (!actualBackendWrite || phase !== 'emitting' || !preparedContext || proof !== activeProof) throw new Error('Invalid Scene actual-write completion')
      phase = 'finished'; detach()
      if (actualRoots !== 1 || !actualRootCompleted) actualClosed = false
      pay(16 + proof.issues.length * 2)
      const budget = exhausted, scope = !actualClosed
      let hasBudget = false, hasScope = false
      for (let index = 0; index < proof.issues.length; index++) { const code = proof.issues[index]!.code; hasBudget ||= code === 'CHECK_BUDGET'; hasScope ||= code === 'OUTPUT_SCOPE' }
      const extra = (scope && !hasScope ? 1 : 0) + (budget && !hasBudget ? 1 : 0)
      const issues: import('./paint-certification.ts').PaintCertificationIssue[] = []
      const count = proof.issues.length < 64 - extra ? proof.issues.length : 64 - extra
      for (let index = 0; index < count; index++) groupDefine(issues, index, { value: proof.issues[index], enumerable: true, configurable: false, writable: false })
      if (scope && !hasScope) groupDefine(issues, issues.length, { value: { code: 'OUTPUT_SCOPE', message: budget
        ? 'Actual backend composition could not be established within the paint-work allowance'
        : 'Actual backend composition differs from its admission write evidence' }, enumerable: true })
      if (budget && !hasBudget) groupDefine(issues, issues.length, { value: { code: 'CHECK_BUDGET', message: 'Actual backend composition exhausted the existing paint-work allowance' }, enumerable: true })
      return groupFreeze({ ...proof, status: proof.status === 'failed' ? 'failed' : budget || scope ? 'unverified' : proof.status,
        checks: groupFreeze({ ...proof.checks, operations: budget ? maxOperations : operations }), issues: groupFreeze(issues) })
    },
    finish(scene: SceneDoc): SceneWriteReceipt | undefined {
      if (actualBackendWrite) throw new Error('Actual writes require preparation and same-ledger completion')
      if (phase === 'finished') throw new Error('Scene write capture already finished')
      phase = 'finished'
      if (!isAdmittedSceneDocument(scene)) return undefined
      return receipt(scene, context.finish(scene))
    },
  }
}

const groupDefine = Object.defineProperty
const groupSafeInteger = Number.isSafeInteger
const groupHasOwn = Object.hasOwn
const groupOwnDescriptor = Object.getOwnPropertyDescriptor
const groupPrototype = Object.getPrototypeOf
const groupFrozen = Object.isFrozen
const groupIsArray = Array.isArray
const groupArray = Array, groupArrayPrototype = Array.prototype
const groupStringPrototype = String.prototype, groupRegExpPrototype = RegExp.prototype
const groupMap = Array.prototype.map, groupJoin = Array.prototype.join
const groupIterator = Array.prototype[Symbol.iterator]
const groupIteratorPrototype = Object.getPrototypeOf([][Symbol.iterator]())
const groupNext = groupOwnDescriptor(groupIteratorPrototype, 'next')!.value
const groupSpecies = groupOwnDescriptor(Array, Symbol.species)!.get
const groupRepeat = String.prototype.repeat, groupReplace = String.prototype.replace
const groupRegExpReplace = RegExp.prototype[Symbol.replace], groupRegExpExec = RegExp.prototype.exec
const groupRegExpFlags = ['global', 'unicode', 'unicodeSets'] as const
const groupRegExpGetters = groupRegExpFlags.map(name => groupOwnDescriptor(RegExp.prototype, name)?.get)
function groupComposition(node: Extract<SceneNode, { kind: 'group' }>, pay: (count: number) => boolean, root = false): GroupComposition {
  let valid = true
  const charge = (count = 1): boolean => { if (valid && !pay(count)) valid = false; return valid }
  const descriptor = (source: object, key: PropertyKey): PropertyDescriptor | undefined => charge() ? groupOwnDescriptor(source, key) : undefined
  const data = (source: object, key: PropertyKey, expected: unknown): boolean => {
    const slot = descriptor(source, key)
    return !!slot && groupHasOwn(slot, 'value') && slot.value === expected
  }
  const getter = (source: object, key: PropertyKey, expected: unknown): boolean => {
    const slot = descriptor(source, key)
    return !!slot && !groupHasOwn(slot, 'value') && slot.get === expected && expected !== undefined
  }
  const array = (value: unknown): value is unknown[] => charge(2) && !!value && typeof value === 'object' && groupIsArray(value) && groupPrototype(value) === groupArrayPrototype
  const dense = (value: unknown, strings: boolean): value is unknown[] => {
    if (!array(value)) return false
    const length = descriptor(value, 'length')
    if (!length || !groupHasOwn(length, 'value')) return false
    for (let index = 0; index < length.value; index++) {
      const slot = descriptor(value, String(index))
      if (!slot || !groupHasOwn(slot, 'value') || strings && typeof slot.value !== 'string') return false
    }
    return true
  }
  if (!charge(2) || !groupFrozen(node) || groupPrototype(node) !== null) valid = false
  const fields = root ? [] : ['open', 'close', 'join']
  for (let index = 0; index < fields.length; index++) {
    const slot = descriptor(node, fields[index]!)
    if (!slot || !groupHasOwn(slot, 'value') || typeof slot.value !== 'string') valid = false
  }
  const field = descriptor(node, root ? 'parts' : 'children')
  if (!field || !groupHasOwn(field, 'value')) valid = false
  return {
    get valid() { return valid },
    invalidate(): void { if (!charge()) return; valid = false },
    beforeMap(children): void {
      if (!valid) return
      if (children !== field!.value) { valid = false; return }
      // Admission checked the roles/order of these producer-owned immutable
      // slots. Reuse their closed construction rather than reflect them again.
      const owned = !!children && typeof children === 'object' && charge(2) && isOwnDataSceneArrayInert(children)
      if (!owned) {
        if (!dense(children, false) || !charge() || !groupFrozen(children)) { valid = false; return }
        for (let index = 0; index < children.length; index++) {
          const child = groupOwnDescriptor(children, String(index))!.value
          if (!charge(2) || !child || typeof child !== 'object' || !isOwnDataSceneSnapshotInert(child) || !groupFrozen(child)) { valid = false; return }
          const node = root ? undefined : descriptor(child, 'node'), indent = root ? undefined : descriptor(child, 'indent')
          if (!root && (!node || !groupHasOwn(node, 'value') || !indent || !groupHasOwn(indent, 'value') || typeof indent.value !== 'number' || indent.value !== indent.value)) { valid = false; return }
        }
      }
      if (descriptor(children, 'map') || descriptor(children, 'constructor')
        || !data(groupArrayPrototype, 'map', groupMap) || !data(groupArrayPrototype, 'constructor', groupArray)
        || !getter(groupArray, Symbol.species, groupSpecies)) valid = false
    },
    beforeSpread(mapped): void {
      if (!valid) return
      if (!dense(mapped, true) || descriptor(mapped as object, Symbol.iterator)
        || !data(groupArrayPrototype, Symbol.iterator, groupIterator)
        || !data(groupIteratorPrototype, 'next', groupNext)) valid = false
    },
    beforeJoin(parts): void {
      if (!valid) return
      if (!(root ? dense(parts, true) : array(parts)) || descriptor(parts as object, 'join') || !data(groupArrayPrototype, 'join', groupJoin)) valid = false
    },
    indent(svg, spaces): string {
      if (!valid || spaces <= 0 || svg === '') return indentLines(svg, spaces)
      if (typeof svg !== 'string' || typeof spaces !== 'number' || !data(groupStringPrototype, 'repeat', groupRepeat)) valid = false
      const pad = ' '.repeat(spaces)
      if (valid) {
        if (!data(groupStringPrototype, 'replace', groupReplace) || !data(groupRegExpPrototype, Symbol.replace, groupRegExpReplace)
          || !data(groupRegExpPrototype, 'exec', groupRegExpExec)) valid = false
        for (let index = 0; valid && index < groupRegExpFlags.length; index++) if (!getter(groupRegExpPrototype, groupRegExpFlags[index]!, groupRegExpGetters[index])) valid = false
      }
      return pad + svg.replace(/\n/g, `\n${pad}`)
    },
  }
}

