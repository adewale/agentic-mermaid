import { groupObserverHas as sceneStateWeakHas, groupObserverApply as sceneStateWeakApply, groupObserverAdd, groupFreeze, sceneObserverCreate, sceneObserverGet, sceneObserverSet, sceneObserverApply, type SceneSerializationObserver, type GroupComposition, type ConnectorNode, type SceneWriteRecorder } from './scene-write-observer.ts'
export type { SceneSerializationObserver } from './scene-write-observer.ts'
export type { SceneWriteReceipt, SceneWriteWork } from './scene-write-capture.ts'
import { connectorContourSemantics } from './connector-geometry.ts'
import type { SceneDoc, SceneNode, Geometry, MarkPaint, ShapeMark } from './ir.ts'
import { compareCodePointStrings } from '../shared/deterministic-order.ts'
import { writeImageSvg, writeConnectorSvg, writeShapeSvg, writeTextSvg, type SvgGeometryWriteSink, type SvgXmlCapture, type SvgXmlWrite } from './svg-writer.ts'
import { rectanglePaintFields, writtenPolylineProjectionOf, prepareWrittenCompoundShape, observeWrittenCompoundShape, completeWrittenCompoundShape, type WrittenCompoundInput } from './written-geometry.ts'

// SVG serialization is backend-private state, not part of the public Scene IR.
// Shape, text and connector marks are written from their typed fields when
// first serialized (svg-writer.ts); a group is its opening tag, its children
// and its closing tag. Only document marks (the shell, definitions,
// stylesheets, titles, opaque family content) carry construction-time markup,
// normalized before admission: callers cannot use attribute order, quote
// style, or tag spacing as a second byte-level Scene authority.
const SERIALIZED_SCENE_NODES = new WeakMap<object, string>()
/** Marks the mark constructors built, and admitted copies of them: the only
 * shape, text, connector and group nodes the writer draws. A plain object
 * shaped like a mark has no serialization, as it had none before the writer. */
const WRITABLE_SCENE_NODES = new WeakSet<object>()
/** Writer output for frozen (admitted) leaf marks, which cannot change after. */
const WRITTEN_SCENE_NODES = new WeakMap<object, string>()
// The snapshot handoff is private writer provenance, not a caller flag. Check
// membership before reflecting on a node so raw/mutable serialization retains
// its existing observations and strict writer behavior.
const TRANSFERRED_WRITABLE_NODES = new WeakSet<object>()
export function isTransferredWritableSceneNode(node: object): boolean { return TRANSFERRED_WRITABLE_NODES.has(node) }
export function transferredWritableSceneNodeInert(node: object): boolean { return sceneStateWeakApply(sceneStateWeakHas, TRANSFERRED_WRITABLE_NODES, [node]) }
export function writtenSceneNodeSerialization(node: object): string | undefined { return WRITTEN_SCENE_NODES.get(node) }
const POSSIBLE_FITTED_TEXT = /<\s*text/i

// Recorders are private to their consuming serializer, as before the Scene
// capture split. A new registration can mint only a fresh opaque token; it
// cannot read or replace any genuine transaction's callbacks.
const actualSceneObservers = new WeakSet<object>()
const sceneWriteObservers = new WeakMap<SceneSerializationObserver, SceneWriteRecorder>()
function readSceneWriteObserver(observer: SceneSerializationObserver): SceneWriteRecorder | undefined {
  return sceneStateWeakApply(sceneStateWeakHas, actualSceneObservers, [observer])
    ? sceneObserverApply(sceneObserverGet, sceneWriteObservers, [observer]) : sceneWriteObservers.get(observer)
}
export function newSceneWriteObserver(recorder: SceneWriteRecorder, actualBackendWrite: boolean): SceneSerializationObserver {
  const observe = (actualBackendWrite ? groupFreeze(sceneObserverCreate(null)) : Object.freeze(Object.create(null))) as SceneSerializationObserver
  if (actualBackendWrite) {
    sceneStateWeakApply(groupObserverAdd, actualSceneObservers, [observe])
    sceneObserverApply(sceneObserverSet, sceneWriteObservers, [observe, groupFreeze(recorder)])
  } else sceneWriteObservers.set(observe, recorder)
  return observe
}
export function sceneDocumentComposition(observer: SceneSerializationObserver, scene: import('./ir.ts').SceneDoc) {
  return (sceneObserverApply(sceneObserverGet, sceneWriteObservers, [observer]) as SceneWriteRecorder | undefined)?.root(scene)
}


interface SerializedAttribute {
  readonly name: string
  readonly value: string
  readonly index: number
}

function canonicalOpeningTag(tag: string): string {
  const head = tag.match(/^<([A-Za-z_][A-Za-z0-9_.:-]*)/)
  if (!head || tag.startsWith('</') || tag.startsWith('<!') || tag.startsWith('<?')) return tag
  const name = head[1]!
  // The v2 Scene contract owns the document shell. Family mark serialization
  // remains an internal projection of its typed geometry/presentation fields;
  // reordering those attributes would add no contract value and would make
  // family-level semantic probes needlessly depend on the shell migration.
  if (name !== 'svg') return tag
  const selfClosing = /\/\s*>$/.test(tag)
  const boundary = selfClosing ? tag.lastIndexOf('/') : tag.length - 1
  const attributes: SerializedAttribute[] = []
  let cursor = head[0].length
  while (cursor < boundary) {
    while (/\s/.test(tag[cursor] ?? '')) cursor++
    if (cursor >= boundary) break
    const attribute = tag.slice(cursor).match(/^([^\s=<>/]+)/)
    if (!attribute) return tag
    const attributeName = attribute[1]!
    cursor += attribute[0].length
    while (/\s/.test(tag[cursor] ?? '')) cursor++
    if (tag[cursor] !== '=') return tag
    cursor++
    while (/\s/.test(tag[cursor] ?? '')) cursor++
    const quote = tag[cursor]
    if (quote !== '"' && quote !== "'") return tag
    cursor++
    const valueStart = cursor
    while (cursor < boundary && tag[cursor] !== quote) cursor++
    if (tag[cursor] !== quote) return tag
    const rawValue = tag.slice(valueStart, cursor)
    cursor++
    attributes.push({
      name: attributeName,
      value: quote === '"' ? rawValue : rawValue.replaceAll('"', '&quot;'),
      index: attributes.length,
    })
  }
  const shellOrder = new Map([
    ['xmlns', 0], ['width', 1], ['height', 2], ['viewBox', 3], ['style', 4],
  ])
  attributes.sort((a, b) => {
    const aOrder = shellOrder.get(a.name) ?? 100
    const bOrder = shellOrder.get(b.name) ?? 100
    return aOrder - bOrder || compareCodePointStrings(a.name, b.name) || a.index - b.index
  })
  const serialized = attributes.map(attribute => `${attribute.name}="${attribute.value}"`).join(' ')
  return `<${name}${serialized ? ` ${serialized}` : ''}${selfClosing ? ' /' : ''}>`
}

/** Canonicalize the owned SVG document shell without reparsing or rewriting
 * family elements, text, CSS, comments, or closing tags. This is deliberately
 * one-way: historical root ordering cannot survive as backend output. */
export function canonicalizeSceneNodeSerialization(svg: string): string {
  // Only opening <svg> tags are canonicalized. Most document fragments are
  // styles, definitions or metadata and cannot contain one at all.
  if (!svg.includes('<svg')) return svg
  let output = ''
  let cursor = 0
  while (cursor < svg.length) {
    const start = svg.indexOf('<', cursor)
    if (start < 0) return output + svg.slice(cursor)
    output += svg.slice(cursor, start)
    if (svg.startsWith('<!--', start)) {
      const end = svg.indexOf('-->', start + 4)
      if (end < 0) return output + svg.slice(start)
      output += svg.slice(start, end + 3)
      cursor = end + 3
      continue
    }
    let quote: '"' | "'" | undefined
    let end = start + 1
    for (; end < svg.length; end++) {
      const char = svg[end]
      if (quote) {
        if (char === quote) quote = undefined
      } else if (char === '"' || char === "'") {
        quote = char
      } else if (char === '>') {
        break
      }
    }
    if (end >= svg.length) return output + svg.slice(start)
    output += canonicalOpeningTag(svg.slice(start, end + 1))
    cursor = end + 1
  }
  return output
}

/** Attach a document mark's markup. Every other mark's SVG is written from
 * its fields, so what paint certification reads is what the output shows. */
export function attachSceneNodeSerialization<T extends SceneNode>(node: T, svg: string): T {
  if (node.kind !== 'document') throw new TypeError(`Scene ${node.kind} "${node.id}" is written from its fields, not stored markup`)
  SERIALIZED_SCENE_NODES.set(node, canonicalizeSceneNodeSerialization(svg))
  return node
}

/** Record that a mark constructor built `node`, so the writer may draw it. */
export function admitWritableSceneNode<T extends SceneNode>(node: T): T {
  WRITABLE_SCENE_NODES.add(node)
  return node
}

export function sceneNodeSerialization(node: SceneNode): string {
  return serializeSceneNode(node)
}

/** Observe only this actual write. Cached markup supplies no new receipt. */
export function sceneNodeSerializationObserved(node: SceneNode, sink?: SvgGeometryWriteSink, observer?: SceneSerializationObserver): string {
  return serializeSceneNode(node, sink, observer)
}

/** One actual typed write supplies both the bytes and its XML construction fact.
 * Stored/mutable/cached markup keeps its complete XML in the projection. */
export function sceneNodeWrite(node: SceneNode, capture: SvgXmlCapture, sink?: SvgGeometryWriteSink, observer?: SceneSerializationObserver): SvgXmlWrite {
  return serializeSceneNode(node, sink, observer, capture)
}

function serializeSceneNode(node: SceneNode, sink?: SvgGeometryWriteSink, observer?: SceneSerializationObserver): string
function serializeSceneNode(node: SceneNode, sink: SvgGeometryWriteSink | undefined, observer: SceneSerializationObserver | undefined, capture: SvgXmlCapture): SvgXmlWrite
function serializeSceneNode(node: SceneNode, sink?: SvgGeometryWriteSink, observer?: SceneSerializationObserver, capture?: SvgXmlCapture): string | SvgXmlWrite {
  const recorder = observer && readSceneWriteObserver(observer)
  const stored = SERIALIZED_SCENE_NODES.get(node)
  if (stored !== undefined) {
    if (node.kind === 'group') recorder?.group(node)?.complete(false)
    if (node.kind !== 'group') recorder?.string(node, stored)
    if (node.kind === 'document') recorder?.document(node, stored)
    else if (node.kind !== 'group') recorder?.contextLeaf(node, stored)
    return capture ? capture.raw(stored, node) : stored
  }
  if (!WRITABLE_SCENE_NODES.has(node)) throw new TypeError(`Scene node "${node.id}" has no admitted SVG serialization`)
  const written = WRITTEN_SCENE_NODES.get(node)
  if (written !== undefined) {
    if (node.kind === 'group') recorder?.group(node)?.complete(false)
    if (node.kind !== 'group') recorder?.string(node, written)
    if (node.kind !== 'group' && node.kind !== 'document') recorder?.contextLeaf(node, written)
    return capture ? capture.raw(written, node) : written
  }
  let source: Geometry | undefined, served: Geometry | undefined, received = false, invalid = false, projectionReserved = false
  const groupWrite = node.kind === 'group' ? recorder?.group(node) : undefined
  if (node.kind === 'connector') recorder?.connector(node)
  const fractional = recorder?.hint(node) ?? false
  const rectangle = fractional && node.kind === 'shape' && recorder!.rectangle(node)
  const compound = node.kind === 'shape' ? recorder?.compound(node) : undefined
  const watchedConnector = recorder && node.kind === 'connector'
  const watched = recorder && (watchedConnector || rectangle || compound) && recorder.reserve()
  let attributesReceived = false, invalidAttributes = false, attributes: Readonly<Record<string, string>> | undefined
  const geometrySink: SvgGeometryWriteSink | undefined = watched ? Object.assign((geometry: Geometry, written: Geometry | undefined) => {
    if (compound) { observeWrittenCompoundShape(compound, geometry, written, count => recorder!.reserveProjection(count)); sink?.(geometry, written); return }
    if (received) { invalid = true; return }
    received = true
    source = geometry
    if (rectangle && written) {
      if (!recorder!.reserveProjection(48)) { invalid = true; return }
      const fresh = Object.create(null) as Geometry
      for (const key of Object.getOwnPropertyNames(written)) {
        const descriptor = Object.getOwnPropertyDescriptor(written, key)
        if (!descriptor || !Object.hasOwn(descriptor, 'value')) { invalid = true; return }
        Object.defineProperty(fresh, key, { value: descriptor.value, enumerable: descriptor.enumerable })
      }
      served = Object.preventExtensions(fresh)
    } else served = written
    sink?.(geometry, written)
  }, { reserveProjection: (geometry: Geometry, operations: number) => {
    if (node.kind !== 'connector' || geometry !== node.route.geometry || projectionReserved) { invalid = true; return false }
    projectionReserved = true
    return recorder!.reserveProjection(operations)
  }, rectangleAttributes: rectangle ? (shape: ShapeMark, actual: Readonly<Record<string, string>> | undefined): void => {
    if (shape !== node || attributesReceived) { invalidAttributes = true; return }
    attributesReceived = true
    attributes = actual
    sink?.rectangleAttributes?.(shape, actual)
  } : undefined }) : sink
  const output = capture ? writeStructuredSceneNode(node, capture, geometrySink, observer) : writeSceneNode(node, geometrySink, observer, groupWrite?.composition)
  const svg = typeof output === 'string' ? output : output.svg
  groupWrite?.complete(!capture && groupWrite.composition?.valid === true)
  if (node.kind !== 'group') recorder?.string(node, svg)
  // A group is written from its children each time: its children array is
  // not part of what freezing it protects.
  if (node.kind !== 'group' && Object.isFrozen(node)) WRITTEN_SCENE_NODES.set(node, svg)
  if (compound && node.kind === 'shape') recorder!.compoundRecord(node, compound, svg)
  if (watched && source) {
    if (watchedConnector && !invalid && source === (node as ConnectorNode).route.geometry) recorder!.record(node, source, served, svg)
    else if (rectangle && node.kind === 'shape') recorder!.rectangleRecord(node, source, invalid ? undefined : served,
      attributesReceived && !invalidAttributes ? attributes : undefined, svg)
  }
  if (node.kind !== 'group' && node.kind !== 'document') recorder?.contextLeaf(node, svg)
  if (fractional && node.kind !== 'group' && node.kind !== 'document') recorder!.leaf(node, svg)
  return capture ? output as SvgXmlWrite : svg
}

function writeStructuredSceneNode(node: SceneNode, capture: SvgXmlCapture, sink?: SvgGeometryWriteSink, observer?: SceneSerializationObserver): SvgXmlWrite {
  switch (node.kind) {
    case 'image': return writeImageSvg(node, capture)
    case 'shape': return writeShapeSvg(node, sink, capture)
    case 'text': return writeTextSvg(node, capture, sink)
    case 'connector': return writeConnectorSvg(node, sink, capture)
    case 'group': return capture.join([
      capture.raw(node.open),
      ...node.children.map(child => capture.indent(serializeSceneNode(child.node, undefined, observer, capture), child.indent)),
      capture.raw(node.close),
    ], node.join)
    case 'document': throw new TypeError(`Scene node "${node.id}" has no admitted SVG serialization`)
  }
}

function writeSceneNode(node: SceneNode, sink?: SvgGeometryWriteSink, observer?: SceneSerializationObserver, composition?: GroupComposition): string {
  switch (node.kind) {
    case 'image': return writeImageSvg(node)
    case 'shape': return writeShapeSvg(node, sink)
    case 'text': return writeTextSvg(node)
    case 'connector': return writeConnectorSvg(node, sink)
    case 'group': {
      if (!composition) return [
        node.open,
        ...node.children.map(child => indentLines(serializeSceneNode(child.node, undefined, observer), child.indent)),
        node.close,
      ].join(node.join)
      {
        const indentLines = composition.indent
        const open = node.open
        composition.beforeMap(node.children)
        const mapped = node.children.map(child => indentLines(serializeSceneNode(child.node, undefined, observer), child.indent))
        composition.beforeSpread(mapped)
        const parts = [open, ...mapped, node.close]
        composition.beforeJoin(parts)
        return parts.join(node.join)
      }
    }
    case 'document': throw new TypeError(`Scene node "${node.id}" has no admitted SVG serialization`)
  }
}

// This private receipt assumes standard intrinsics when this module loads.
// It does not fingerprint a hostile pre-import realm. Captured reflection only
// inspects admitted own-data objects; every actual unknown operator still runs.
/** Indent every line of a serialized chunk by `n` spaces. */
export function indentLines(s: string, n: number): string {
  if (n <= 0 || s === '') return s
  const pad = ' '.repeat(n)
  return pad + s.replace(/\n/g, `\n${pad}`)
}

export function transferSceneNodeSerialization(source: object, target: object): void {
  const svg = SERIALIZED_SCENE_NODES.get(source)
  if (svg !== undefined) SERIALIZED_SCENE_NODES.set(target, svg)
  if (WRITABLE_SCENE_NODES.has(source)) {
    WRITABLE_SCENE_NODES.add(target)
    // Only the Scene snapshot handoff starts with an inert target. A public
    // group clone starts plain; changing its prototype later cannot upgrade it.
    if (Object.getPrototypeOf(target) === null) TRANSFERRED_WRITABLE_NODES.add(target)
  }
}

export function hasSceneNodeSerialization(value: object): boolean {
  return SERIALIZED_SCENE_NODES.has(value) || WRITABLE_SCENE_NODES.has(value)
}

/** A conservative proof for the canonical default writer only. The font-fit
 * postpass ignores prepared text trees. Opaque fragments can still contain
 * unprepared text, so an unknown fragment or even a possible text token keeps
 * that postpass. Styled/custom backends cannot use this proof. */
export function sceneHasOnlyPreparedText(scene: SceneDoc): boolean {
  // The fitting pass accepts whitespace after '<' and compares names without
  // case. Opaque fragments must conservatively cover that same lexical model.
  const prepared = (node: SceneNode): boolean => {
    if (node.kind === 'document') {
      const svg = SERIALIZED_SCENE_NODES.get(node)
      return svg !== undefined && !POSSIBLE_FITTED_TEXT.test(svg)
    }
    if (!WRITABLE_SCENE_NODES.has(node)) return false
    switch (node.kind) {
      case 'text': return node.measurement === 'prepared' && node.block !== undefined
      case 'image': return true
      case 'shape': return true
      // The connector writer sends every inline label through the prepared
      // shared text writer; companion labels are separate Text marks.
      case 'connector': return true
      case 'group': return !POSSIBLE_FITTED_TEXT.test(node.open) && !POSSIBLE_FITTED_TEXT.test(node.close) && node.children.every(child => prepared(child.node))
    }
  }
  return scene.parts.every(prepared)
}
