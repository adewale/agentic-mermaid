import{spyOn}from'bun:test'
import{createHash}from'node:crypto'
import{writeFileSync}from'node:fs'
const root='/dev/shm/pr449-four-final-20261111',rows=[]
for(const mode of ['d4','candidate-genuine','candidate-forged']){
 const base=mode==='d4'?root+'/chain-proof-candidate':root+'/payload-scene-boundary-candidate'
 const marks=await import(base+'/src/scene/marks.ts')
 const captureOwner=await import(base+(mode==='d4'?'/src/scene/serialization.ts':'/src/scene/scene-write-capture.ts'))
 const common=await import(base+'/src/scene/inspection.ts')
 const sceneInspection=mode==='d4'?common:await import(base+'/src/scene/scene-inspection.ts')
 const{certifyNativePaint}=await import(base+'/src/scene/paint-certification.ts')
 const{admitSceneDocument}=await import(base+'/src/scene/external-data-snapshot.ts')
 const{DefaultBackend}=await import(base+'/src/scene/backend.ts')
 const{tipAnchoredArrow,serializeMarkerResource}=await import(base+'/src/scene/marker-resources.ts')
 const marker=tipAnchoredArrow('arrow',{width:8,height:5},'end',{fill:'#111',stroke:'none'},'userSpaceOnUse')
 const colors={bg:'#fff',fg:'#111'},capture=captureOwner.createSceneWriteCapture(400000)
 const raw={family:'flowchart',width:100,height:80,transparent:false,colors,parts:[
 marks.documentOpen({id:'root',width:100,height:80,transparent:false,colors,font:'Inter',hasMonoFont:false},'<svg xmlns="http://www.w3.org/2000/svg" width="100" height="80">'),
 marks.definitions({id:'defs'},'<defs>'+serializeMarkerResource(marker)+'</defs>'),
 marks.connector({id:'outside',role:'edge',lineStyle:'solid',geometry:{kind:'line',x1:20,y1:40,x2:60,y2:40},paint:{stroke:'#111',strokeWidth:'1'},markers:{end:marker},endpoints:{from:'other',to:'cover'}}),
 marks.shape({id:'cover',role:'node',geometry:{kind:'rect',x:30,y:Number(process.env.COVER_Y??35),width:30,height:10},paint:{fill:'#fff'}}),
 marks.documentClose()]}
 const admitted=admitSceneDocument(raw,'internal',true,capture.observe),receipt=capture.finish(admitted)
 let observed,spy
 if(mode==='candidate-forged'&&typeof common.createSceneGeometryRecorder==='function'){
  const original=common.createSceneGeometryRecorder
  spy=spyOn(common,'createSceneGeometryRecorder').mockImplementation((...args)=>{observed=args[3];return Reflect.apply(original,undefined,args)})
 }
 const genuine=sceneInspection.inspectScenePaintGeometry(admitted,receipt)
 spy?.mockRestore()
 let inspection=genuine,forged=false,blocked=false
 if(mode==='candidate-forged'){
  if(typeof observed!=='function')blocked=true
  else{
   const node=admitted.parts.find(part=>part.kind==='connector'),primitive=genuine.primitives.find(part=>part.kind==='connector')
   const start=Object.freeze({x:20,y:20}),end=Object.freeze({x:60,y:20}),tangent=Object.freeze({x:1,y:0})
   const geometry=Object.freeze({kind:'line',x1:20,y1:20,x2:60,y2:20})
   const route=Object.freeze({...node.route,geometry,contours:Object.freeze([Object.freeze({start,end,closed:false,startTangent:tangent,endTangent:tangent})]),startTangent:tangent,endTangent:tangent})
   const source=Object.freeze({kind:'connector',lineStyle:node.lineStyle,endpoints:node.endpoints,route,stroke:node.stroke,markers:node.markers})
   observed(primitive,source);forged=true
  }
 }
 const svg=DefaultBackend.render(admitted,{seed:0}),proof=certifyNativePaint(admitted,inspection)
 rows.push({mode,forged,blocked,svg,sha256:createHash('sha256').update(svg).digest('hex'),proof})
}
writeFileSync(root+'/payload-observer-review/'+(process.env.REVIEW_OUTPUT??'INSPECTION-CALLBACK-RESULT.json'),JSON.stringify(rows,null,2))
for(const r of rows)console.log(JSON.stringify({mode:r.mode,forged:r.forged,blocked:r.blocked,sha256:r.sha256,proof:r.proof.status,issues:r.proof.issues,checks:r.proof.checks}))
