import { isAdmittedSceneDocument } from './scene-admission-state.ts'
import { beginSceneWriteInspection, type SceneWriteReceipt } from './scene-write-capture.ts'
import { assertInertGroup } from './group-emission.ts'
import type { SceneDoc, SceneNode, SceneOwner } from './ir.ts'
import { composeMatrices, IDENTITY_MATRIX, transformMatrix, type AffineMatrix } from './transforms.ts'
import { createPaintRecorder, ownerSnapshot, retainScenePathEmissionWork, multiplySceneOpacity, sceneGroupOpacity, type ScenePaintInspection, type ScenePaintGeometryInspection, type TextDetails } from './inspection.ts'
const textPaintFreeze = Object.freeze

/** Inspect the actual lowered primitives, retaining paint order and ownership.
 * Bounds are conservative occupied regions, not a claim of pixel-exact ink.
 * Opaque content and missing geometry remain explicit missing evidence.
 */
export function inspectScenePrimitives(scene: SceneDoc): ScenePaintInspection {
  return inspectScene(scene, (text, block, includeFont) => ({
    source: block?.prepared.source ?? text,
    displayed: block ? block.lineBlocks.map(line => line.runs.map(run => run.text).join('')).join('\n') : text,
    ...(includeFont && block?.fontFamily ? { fontFamily: block.fontFamily } : {}),
  })) as ScenePaintInspection
}

export function inspectScenePaintGeometry(scene: SceneDoc, receipt?: SceneWriteReceipt): ScenePaintGeometryInspection {
  const writes = beginSceneWriteInspection(receipt, scene)
  const inspection = inspectScene(scene, undefined, writes, receipt !== undefined ? 'all' : isAdmittedSceneDocument(scene) ? 'marked' : false)
  if (writes) retainScenePathEmissionWork(inspection, writes.work())
  return inspection
}

function inspectScene(scene: SceneDoc, retainText?: TextDetails, writes?: ReturnType<typeof beginSceneWriteInspection>, requireWritten: false | 'marked' | 'all' = false): ScenePaintGeometryInspection {
  const recorder = createPaintRecorder(scene, retainText, false, isAdmittedSceneDocument(scene) ? scene.colors.font : undefined)
  const walk = (nodes: readonly SceneNode[], prefix: string, parent: AffineMatrix, ancestors: readonly SceneOwner[], conditional = false, groupOpacity = 1, untransformed = true): void => {
    nodes.forEach((node, index) => {
      const key = `${prefix}.${index}`
      if (node.kind === 'group') {
        const emitted = assertInertGroup(node)
        const own = node.identity ?? { id: node.id, role: node.role }
        walk(node.children.map(child => child.node), key, composeMatrices(parent, transformMatrix(node.transform)), textPaintFreeze([...ancestors, ownerSnapshot(own)]), conditional || node.visibility === 'conditional' || emitted.style || node.paint?.fill !== undefined, multiplySceneOpacity(groupOpacity, sceneGroupOpacity(node.paint?.opacity)), untransformed && !node.transform)
      } else {
        const written = writes?.node(node)
        // Without a receipt, unmarked legacy inspection still owns its inline
        // label diagnostics. Explicit receipts and marked carriers remain strict.
        const missingWrite = requireWritten && node.kind === 'connector' && node.lineStyle !== 'invisible' && !written
          && (requireWritten === 'all' || !!node.markers.start || !!node.markers.end || node.markers.mid.length > 0)
        recorder.leaf(node, key, parent, ancestors, conditional || !!written?.conditional || !!missingWrite, groupOpacity, undefined, written?.served, written?.path, untransformed)
      }
    })
  }
  walk(scene.parts, 'scene', IDENTITY_MATRIX, textPaintFreeze([]))
  return recorder.finish()
}
