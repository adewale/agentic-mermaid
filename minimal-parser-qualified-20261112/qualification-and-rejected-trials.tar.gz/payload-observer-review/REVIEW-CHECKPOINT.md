# Independent Scene authority review

All three demonstrated authority surfaces are repaired in the final reviewed callback-free source. This is bounded source and exact-witness qualification; owning/broad emitted qualification is separate.

- Direct observer recorder read/replace: original hidden-marker SVG failed with MARKER_OCCLUDED; unsafe draft forged a pass. Repaired direct attack is blocked, hidden controls fail at 11683 operations and visible controls pass at 11675.
- Raw inspection factory and work setter: unsafe draft manufactured actual-write authority using genuine work. Repaired direct APIs are absent; the same hidden and visible controls match d4.
- Escaped private stamping callback: unsafe exported numeric factory received a fourth-argument private callback; Bun module spy retained it and changed published provenance after genuine math was restored, producing a false pass. This finding requires test module interposition, unlike the direct API findings. The final factory receives no callback; exact saved witness is blocked, hidden controls fail at 11683 and visible controls pass at 11675.

Final independent runtime review: /dev/shm/pr449-four-final-20261111/payload-authority-repair-real

- src/scene/inspection.ts: 6a6448dee5b1fdbca783ebc6cf9a4e3ac1707b50e5a9931c8f1389fe305c2d4c
- src/scene/scene-inspection.ts: 5b64c90bb16f90240274bc264e11d71b47cac21d3fb8835e875f6b131a20d773

The numeric helper has no Scene issuer/map writers. The canonical receipt walk privately owns semantic/served sources, actual-write/path occurrence, work, and final Scene roster issuance. No remaining concrete blocker found in this bounded review.

Exact final witness logs: INSPECTION-CALLBACK-GREEN-PROBE.log and INSPECTION-CALLBACK-GREEN-POSITIVE.log, with full products in corresponding JSON files. All unsafe sources, RED results, invalid harness attempts and earlier controls remain retained. No runtime source was edited by the independent reviewer.
