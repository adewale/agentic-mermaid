import { registerHooks } from 'node:module'
// Existing observer helpers import this repository's TS with Bun-style omitted
// extensions. Resolve only those helper imports; emitted renderer paths remain
// untouched. Node's own transform handles the existing TS parameter properties.
registerHooks({ resolve(specifier, context, nextResolve) {
  if (context.parentURL?.startsWith('file:///tmp/pr449-main-integration-20261029-762/src/') && specifier.endsWith('.json')) {
    const importAttributes = { ...context.importAttributes, type: 'json' }; return { ...nextResolve(specifier, { ...context, importAttributes }), importAttributes }
  }
  try { return nextResolve(specifier, context) } catch (error) {
    if (error.code !== 'ERR_MODULE_NOT_FOUND' || !context.parentURL?.startsWith('file:///tmp/pr449-main-integration-20261029-762/src/') || !specifier.startsWith('.')) throw error
    for (const candidate of [specifier + '.ts', specifier + '/index.ts', specifier.replace(/\.js$/, '.ts')]) {
      try { return nextResolve(candidate, context) } catch {}
    }
    throw error
  }
} })
