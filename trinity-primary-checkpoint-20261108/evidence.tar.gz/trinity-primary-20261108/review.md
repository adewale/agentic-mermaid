# Trinity primary-graph producer: independent review

Read-only review of the current uncommitted extraction and primary registration
over4433c6f1c. No production edits, tests, builds, profiles, agents or external
actions. Two physical-admission findings were sent to the coordinator; they
remain findings against the code inspected below, not claims of observed bad SVG.

## Actionable physical-demand gaps

1. `owned-routed` admission does not currently reject `edge.curve`. The neutral
   kernel reserves orthogonal shafts and rejects nonzero global bend radius,
   while projection preserves the authored curve and later graphEdgePathProjection
   emits its different curve/tangent geometry. Raw point/rubric certification
   does not establish that arbitrary curved paint fits those reservations. For
   this bounded slice, decline authored curve projection until it is modeled.
   This is separate from correctly declining rounded global route paint.
2. Ordinary owned-route labels still omit opaque halo from their measured body:
   measured-graph-producer.ts216 adds halo only to ancestor-boundary labels.
   Actual graph label paint is pill + labelHaloExtension, and the neutral label
   contract promises the occupied painted body. For6px global line width the
   omitted halo is12px per side, greater than the kernel's3px shaft-half padding.
   Use the existing halo owner for physical mode while keeping legacy demand
   unchanged. A generous fixture or later proof result cannot make this missing
   constraint faithful for all admitted spacing/style requests.

## Preservation and ownership checks

The Native wrapper retains its order flags, placement flag, cache implementation,
preparedGraphWork identity/ledger handoff and final legacy completion. The shared
helper's hint/order/ancestor preprocessing is byte-exact; all new paint metadata,
growth policy, stronger preparation hard errors and disabled shared-fan behavior
are conditional on owned-routed purpose. Legacy marker/glyph/CSS interpretation,
slot charges and minimum-port preparation are retained. Public Native/ELK output
preservation remains an execution qualification, not inferred solely from a move.

The physical slice explicitly declines compounds, state notes/visual geometry and
semantic/nonrectangular shapes. It requires known absolute numeric node/shaft
stroke measurements. It uses the same marker factory and fixed-vs-scaled resource
rules as rendering, with per-endpoint support unioned with actual shaft width;
loops receive those supports too. Rounded body radius follows the same renderer
fallback and stays a conservative configured bound after permitted growth.
Explicit nodeSizes remain fixed; otherwise returned minimum-size dimensions are
consumed during authored projection.

Trinity receives the same preparation ledger and hard depletion throws
LayoutWorkLimitError. It does not enter Native caches/search/shortening or legacy
repair. Projection checks ordered correspondence/nonfinite geometry, then existing
retainGraphText establishes label authority before the strict common certifier.
Only its typed candidate rejection can use the existing explicitly requested ELK
fallback; hard errors and dependency failures are not converted to unsupported.
Default/no-selector behavior still directly selects legacy ELK.

The neutral preparation module has type-only layout-engine dependencies. Browser
aliases preserve real dynamic imports, and the producer facade demands kernel and
producer in parallel under one Trinity graph dependency. Both facades share the
kernel loader; rejected loads reset pending ownership. The retry owner replays a
captured request once per dependency/load identity. This avoids an extra kernel
retry without introducing a synthetic solver or copying source/options across
an unowned async boundary.

Source/Node imports may still change startup/shipped bytes, and extracting a shared
producer is not a cost or quality gain. The reported four-direction mixed-width
fixture demonstrates one delivered domain, not general contact/paint coverage.
Original failed label-authority/fixture-binding probes should remain retained.
No adoption, default switch, historical-gap closure or complete family coverage
follows from this registration.

## Targeted re-read: both physical-demand findings resolved

Current source now rejects any authored edge.curve in owned-routed admission,
so a curve cannot enter orthogonal reservations and later acquire unmodeled
writer geometry. The decline is confined to the new physical slice; legacy
Native behavior is unchanged. The retained before probe returning a passed
product establishes the previous admission gap, not an observed collision.

Ordinary owned captions now use the existing labelHaloExtension drawing owner
and add that halo to both measured dimensions. The nonphysical branch retains
its previous ordinary/ancestor sizing. The new passthrough observation owner
compares actual measured demand against written SVG halo dimensions rather than
copying the measurement formula; the reported1px/6px RED differences establish
demand faithfulness, including the24px dimension mismatch at6px. The actual
before collision probe had no hits and remains retained, so this is not claimed
as a demonstrated visible-collision repair.

No remaining actionable finding from this targeted re-read. The original findings
above remain as historical evidence. No tests/builds or production edits were
performed by this reviewer; cost, broader product preservation and adoption
remain separate qualification.

## Narrow StateVisual admission follow-up

Read only the StateVisual relaxation and its present consumers. No concrete gap
found. The resolved visual record contains forkWidth/forkHeight, noteMargin,
dividerMargin and styleDefaults. Fork/pseudostate/nonrectangular or semantic nodes
still fail shape admission; groups/concurrency dividers and both attached/floating
notes still decline. The remaining rectangular/rounded State nodes are sized
using the existing state-aware estimator, and measurement/drawing both resolve
the same State styleDefaults and captured style face.

The port-face condition now admits physical mode despite StateVisual; when
physical is false it is algebraically the previous legacy condition. Shared fans
remain disabled for owned routes. This is a bounded flat-State extension, not
support for forks, pseudostates, notes or compounds. The coordinator's reported
four-direction owners are separate execution evidence; none was rerun here.
