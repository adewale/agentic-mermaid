from pathlib import Path
import json
p=Path('/tmp/pr449-week-comparison-20261101/sparse-plan-00938-20261107');s=(p/'svg-writer-before.ts').read_text()
a=s.index('type XmlWriteEvent =');b=s.index('\nconst projectXmlTextPaint',a)
cls='''// Private writer tokens choose the same fixed bytes for emission and XML facts.
const enum XmlAttribute { TextAnchor, FontSize, FontWeight, Fill }
function xmlAttributeName(token: XmlAttribute): string {
  switch (token) {
    case XmlAttribute.TextAnchor: return 'text-anchor'
    case XmlAttribute.FontSize: return 'font-size'
    case XmlAttribute.FontWeight: return 'font-weight'
    case XmlAttribute.Fill: return 'fill'
  }
  throw new TypeError('Unknown private XML attribute token')
}
const PREPARED_XML_MASK = 127
function preparedXmlFlag(name: string): number {
  switch (name) {
    case 'x': return 1
    case 'y': return 2
    case 'dy': return 4
    case 'textLength': return 8
    case 'data-prepared-text': return 16
    case 'lengthAdjust': return 32
    case 'data-font-metrics': return 64
    default: return 0
  }
}
class XmlLeafWrite {
  readonly #state: XmlCaptureState
  readonly #attributes = new Set<string>()
  readonly #paintEvents: XmlList<readonly [keyof MarkPaint, string]>
  #preparedAttributes = 0
  #lastAttribute: string | undefined
  #preparedContent: string | undefined
  #preparedCount = 0
  valid = true
  #paintPrepared = false
  #complete = false
  static markComplete(xml: XmlLeafWrite): void { xml.#complete = true }
  static completed(xml: XmlLeafWrite | undefined): boolean { return xml !== undefined && xml.#complete }
  constructor(state: XmlCaptureState) { this.#state = state; this.valid = state.pay(1); this.#paintEvents = xmlList() }
  list<T>(): XmlList<T> | undefined { return this.#state.pay(1) ? xmlList<T>() : undefined }
  element(name: string): void {
    if (!this.valid) return
    this.valid = this.#state.pay(1) && (name === 'rect' || name === 'circle' || name === 'ellipse' || name === 'line' || name === 'polygon' || name === 'polyline' || name === 'path' || name === 'text')
    this.#attributes.clear(); this.#preparedAttributes = 0; this.#lastAttribute = undefined
  }
  attribute(name: string, escaped: unknown, knownName = false): void {
    if (!this.valid) return
    this.#lastAttribute = undefined
    if (typeof escaped !== 'string' || !this.#state.pay(2)) { this.valid = false; return }
    const flag = knownName ? 0 : preparedXmlFlag(name)
    if ((flag ? (this.#preparedAttributes & flag) !== 0 : this.#attributes.has(name))
      || !knownName && !this.#state.name(name) || !this.#state.literal(escaped, true)) { this.valid = false; return }
    if (flag) this.#preparedAttributes |= flag
    else this.#attributes.add(name)
    this.#lastAttribute = escaped
  }
  recordPaintField(field: keyof MarkPaint): void {
    if (!this.valid) return
    this.valid = this.#state.pay(1) && this.#lastAttribute !== undefined
    if (this.valid) this.#paintEvents[this.#paintEvents.length++] = [field, this.#lastAttribute!]
    this.#lastAttribute = undefined
  }
  text(content: string): void {
    if (this.valid) this.valid = typeof content === 'string' && this.#state.literal(content, false)
    this.#lastAttribute = undefined
  }
  prepared(written: PreparedSingleLineWrite): void {
    if (!this.valid) return
    const { x, y, dy, textLength, content } = written
    this.valid = typeof x === 'string' && typeof y === 'string' && typeof dy === 'string' && typeof textLength === 'string' && typeof content === 'string' && this.#state.pay(5)
    if (!this.valid) return
    this.valid = this.#state.pay(2) && (this.#preparedAttributes & PREPARED_XML_MASK) === 0 && this.#state.prepared()
      && this.#state.literal(x, true) && this.#state.literal(y, true) && this.#state.literal(dy, true) && this.#state.literal(textLength, true) && this.#state.literal(content, false)
    this.#preparedAttributes |= PREPARED_XML_MASK
    this.#preparedContent = content; this.#preparedCount++; this.#lastAttribute = undefined
    for (let i = 0; i < written.additionalAttributes.length; i++) { const attribute = written.additionalAttributes[i]!; this.attribute(attribute.name, attribute.value) }
  }
  markPaintPrepared(written: PreparedSingleLineWrite): void {
    if (this.valid) this.#paintPrepared = this.#state.pay(1) && written.additionalAttributes.length === 0
  }
  static paint(xml: XmlLeafWrite): MarkPaint | undefined {
    if (!xml.valid || !xml.#paintPrepared || !xml.#state.pay(1) || xml.#preparedCount !== 1 || xml.#preparedContent === undefined) return undefined
    const paint = { __proto__: null } as MarkPaint
    for (let i = 0; i < xml.#paintEvents.length; i++) {
      if (!xml.#state.pay(2)) return undefined
      const [field, escaped] = xml.#paintEvents[i]!
      if (!xml.#state.pay(2 + escaped.length)) return undefined
      for (let j = 0; j < escaped.length; j++) if (escaped[j] === '&') return undefined
      textPaintDefine(paint, field, { value: escaped, enumerable: true, writable: false, configurable: false })
    }
    const content = xml.#preparedContent
    if (!xml.#state.pay(content.length + 1)) return undefined
    for (let j = 0; j < content.length; j++) if (content[j] === '<') return undefined
    return textPaintFreeze(paint)
  }
  check(): boolean { return this.valid && this.#state.pay(1) }
}
'''
s=s[:a]+cls+s[b:]
s=s.replace('attribute(name: string, value: string | number, changedToken?', 'attribute(name: string | XmlAttribute, value: string | number, changedToken?')
s=s.replace("    const literal = typeof value === 'number' ? formatSvgNumber(value) : formatSvgNumericAttribute(name, value, changedToken, numericToken)","    const knownName = typeof name === 'number'\n    const actualName = knownName ? xmlAttributeName(name) : name\n    const literal = typeof value === 'number' ? formatSvgNumber(value) : formatSvgNumericAttribute(actualName, value, changedToken, numericToken)")
s=s.replace('this.value += ` ${name}="${escaped}"`','this.value += ` ${actualName}="${escaped}"`').replace('this.xml?.attribute(name, escaped)','this.xml?.attribute(actualName, escaped, knownName)').replace("if (name === 'transform') this.transformed = true","if (actualName === 'transform') this.transformed = true").replace('this.observeAttributes?.(name, literal)','this.observeAttributes?.(actualName, literal)')
s=s.replace("this.attribute(name, value, undefined, undefined, field)","this.attribute(name === 'fill' ? XmlAttribute.Fill : name, value, undefined, undefined, field)")
s=s.replace("out.attribute('text-anchor', node.anchor)","out.attribute(XmlAttribute.TextAnchor, node.anchor)").replace("out.attribute('font-size', node.fontSize)","out.attribute(XmlAttribute.FontSize, node.fontSize)").replace("out.attribute('font-weight', node.fontWeight ?? node.block?.fontWeight ?? 400)","out.attribute(XmlAttribute.FontWeight, node.fontWeight ?? node.block?.fontWeight ?? 400)")
(p/'svg-writer-stream.ts').write_text(s);j=json.loads((p/'profile-before.json').read_text());j['moduleOverrides']={'/tmp/pr449-main-integration-20261029-762/src/scene/svg-writer.ts':str(p/'svg-writer-stream.ts')};(p/'profile-stream.json').write_text(json.dumps(j))
