from pathlib import Path
import json,subprocess,os,time
p=Path(__file__).resolve().parent;r=Path('/tmp/pr449-main-integration-20261029-762');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();s=json.loads((p/'PLAN.json').read_text());s['sourceRevision']=head;s['startedAt']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(p/'PLAN.json').write_text(json.dumps(s,indent=2)+'\n');results=[]
for n,run in enumerate(s['runs']):
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==head
 job=Path(run['job']);j=json.loads(job.read_text());j['sourceRevision']=head;job.write_text(json.dumps(j,indent=2)+'\n');out=Path(run['out']);out.mkdir(parents=True,exist_ok=True);env=dict(os.environ,AGENTIC_MERMAID_ELK_CACHE=str(run['cache']));start=time.time()
 with (p/(run['name']+'.log')).open('wb') as log:
  q=subprocess.run(['node','--expose-gc','/tmp/pr449-week-comparison-20261101/native-elk-d8c8-comparison/measure.mjs',str(out),str(job)],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':run['name'],'exitCode':q.returncode,'processWallSeconds':time.time()-start});(p/'PROCESS-OUTCOMES.json').write_text(json.dumps(results,indent=2)+'\n');print(n+1,run['name'],'exit',q.returncode,flush=True)
s['finishedAt']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(p/'PLAN.json').write_text(json.dumps(s,indent=2)+'\n')
