# Payload next-cost review —00938cc04

Read-only review; no build, test, profile replay, source mutation or network
operation. No build/counterfactual CPU work is pending. Source remains
`00938cc04693fe5da7a02a5d226406c3c2848251`.

**One concrete subtraction target: the graphical backend admission/writer
closure retained in the main-thread standalone facade.** Stop at this scoped
hypothesis; no compressed saving or passing-cap claim is established.

The current `editor.html` is2287540bytes and its inline `editor-runtime` is
471764bytes. Its main-thread code still contains the Scene-validation error
implementation (`SceneValidationError` at character342839 of that script).
This is separate from the inert packed worker payload. The coordinator binds
this HTML to SHA256`bbfeabc29496dd8f29bb13bcc08d5d8eb28561c938714184fc203030a9d7b0fd`,
gzip9=1386827/Brotli11=1318081. The gzip cap gap is52327bytes.

Concrete dependency path:

1. `browser-standalone.ts` imports `browser-editor-adapter.ts`.
2. Adapter line3 imports option fields/schema/serializable validation from the
   full `render-contract.ts`; its runtime API is worker RPC, local option/style
   inspection and output-security checks. It never executes a Scene backend.
3. `render-contract.ts:54` statically imports `getBackendDescriptor` from
   `scene/backend.ts` for actual execution-plan resolution. Its serializable
   validation at454–479 needs schema, safe CSS and style admission, not a
   graphical backend's `drawNode`/`render` methods.
4. `scene/backend.ts` owns a `DefaultBackend` object at138 with references to
   Scene admission, serialization and write observation. Those retained
   registrations/method references keep the implementation closure alive.

The retained standalone module graph
`current-execution-c9/after-metafile.json` independently attributes66944 raw
Bun-output bytes to `scene-validation-core.ts`,22090 to `svg-writer.ts` and20769
to `backend-conformance.ts` in the facade. This is historical attribution, not
an exact00938 byte measurement. The retained main9fb lazy graph also places
validation/writer/backend together in the shared runtime chunk. Neither raw
contribution sum predicts gzip savings, and neither graph is a fresh00938
standalone metafile. Current HTML establishes continued validation-code presence
but not the whole exact compressed attribution.

The possible owning change is to make this **one closed facade** consume the
canonical declarative option-validation/schema surface without importing the
execution-plan backend implementation. Retain one schema/validator authority,
style registry identity, exact errors, JSON admission limits and editor field
behavior. Keep full backend admission/writing in the actual worker, public
Node/Scene/IIFE entries and all rendering paths. Do not replace backend lookup
with a permissive stub in the renderer or duplicate the descriptor inventory.

Existing flags do not perform this subtraction:
`sourceOnlySceneAdmission:true` substitutes a narrower external-data admission
module but still retains internal Scene validation; schemaDocumentation and
familyEditorMetadata already remove their intended annotations. The coalescing
flag merges/redirects module identities and default registration, rather than
separating validation-only from graphical execution. A flag-only counterfactual
would therefore not demonstrate the proposed removal. No giant rebuild was
performed simply to remeasure these unchanged flags.

First-use/cost limits: this would remove unnecessary main-thread code, not defer
an offered feature to a network request. Standalone remains offline and the
worker must retain all preview/mutate/terminal/PNG behavior, option-dependent
backend selection and cancellation/recovery. The packed worker may dominate
the final gzip; this facade subtraction might not close52327bytes and could
alter cross-section compression unfavorably. Qualification would require an
exact facade-only emitted graph and complete final HTML gzip/Brotli comparison,
plus existing option/schema/style and built standalone first-use owners. None
of those outcomes is claimed here.
