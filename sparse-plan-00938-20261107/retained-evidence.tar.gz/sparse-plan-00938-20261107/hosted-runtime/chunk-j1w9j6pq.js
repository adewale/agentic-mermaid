function em(d,i,r){let t=d,s=d,n=1;if(d.width>i+0.01)for(let h of[1,2]){let e=r(h,s);if(!e)break;if(n++,s=e,e.width<t.width)t=e;if(e.width<=i+0.01){t=e;break}}return Object.assign(t,{widthFit:{maxWidth:i,width:t.width,attempts:n,status:t.width<=i+0.01?"fitted":"exceeded"}})}
export{em};
