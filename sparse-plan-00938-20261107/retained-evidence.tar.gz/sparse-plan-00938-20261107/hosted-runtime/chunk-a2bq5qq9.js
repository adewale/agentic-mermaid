import{GS}from"./chunk-53vq5zpe.js";import"./chunk-9dxn21dj.js";export{GS as BUILTIN_BACKENDS};
