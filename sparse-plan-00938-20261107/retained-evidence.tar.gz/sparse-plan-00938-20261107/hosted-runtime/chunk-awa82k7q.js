import{be,J,Q}from"./browser-preview-worker-tcq53gnx.js";function Ye(o,h,t,e,n,m){let i=e.font??"Inter",r=be(e);return{family:h,width:t.width,height:t.height,colors:e,transparent:n,parts:[o.documentOpen({id:"prelude",width:t.width,height:t.height,colors:e,transparent:n,font:i,hasMonoFont:!1},`${Q(t.width,t.height,e,n)}
${J(i,!1,e.shadow,e.embedFontImport)}${r?`
<defs>${r}</defs>`:""}`),...m,o.documentClose()]}}
export{Ye};
