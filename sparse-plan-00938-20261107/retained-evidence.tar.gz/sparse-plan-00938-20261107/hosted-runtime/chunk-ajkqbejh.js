function ht(i){let t=[];for(let o of i){if(t.at(-1)?.x===o.x&&t.at(-1)?.y===o.y)continue;t.push({...o});while(t.length>2){let n=t.at(-3),e=t.at(-2),r=t.at(-1);if(!(n.x===e.x&&e.x===r.x&&e.y>=Math.min(n.y,r.y)&&e.y<=Math.max(n.y,r.y)||n.y===e.y&&e.y===r.y&&e.x>=Math.min(n.x,r.x)&&e.x<=Math.max(n.x,r.x)))break;t.splice(t.length-2,1)}}return t}
export{ht};
