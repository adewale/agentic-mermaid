function P(e,t={}){return Object.freeze({document:e,serialization:Object.freeze({...t})})}function r(e){return e.document.serialize(e.serialization)}var n=Symbol("native terminal renderer");function De(e){let t=(i)=>r(e(i));return Object.defineProperty(t,n,{value:e}),Object.freeze(t)}function bp(e,t,i){return e[n]?.(t,i)}
export{P,De,bp};
