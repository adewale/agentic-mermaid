var o=new WeakMap;function Qy(t,a){return o.set(t,a),t}function d1(t,a){return o.get(t)?.(a)}
export{Qy,d1};
