function e(t){let r=2166136261;for(let n=0;n<t.length;n++)r^=t.charCodeAt(n),r=Math.imul(r,16777619);return r>>>0}function wt(...t){return e(t.join("|")).toString(36)}function Yb(t){let r=t>>>0;return()=>{r|=0,r=r+1831565813|0;let n=Math.imul(r^r>>>15,1|r);return n=n+Math.imul(n^n>>>7,61|n)^n,((n^n>>>14)>>>0)/4294967296}}function Xb(t,r,n){return e(`${t>>>0}|${r}|${n}`)}
export{wt,Yb,Xb};
