import{H}from"./browser-preview-worker-tcq53gnx.js";function id(r,t,n){let e=H(r,[t,n]);return typeof e==="number"&&Number.isFinite(e)&&e>=0?e:void 0}
export{id};
