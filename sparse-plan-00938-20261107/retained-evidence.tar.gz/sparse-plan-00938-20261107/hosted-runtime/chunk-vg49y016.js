function xt(r,n,s,t,e){let i={};if(e)i.role="img",i["aria-roledescription"]=e;else if(r||n)i.role="img";if(r)i["aria-labelledby"]=s;if(n)i["aria-describedby"]=t;return i}
export{xt};
