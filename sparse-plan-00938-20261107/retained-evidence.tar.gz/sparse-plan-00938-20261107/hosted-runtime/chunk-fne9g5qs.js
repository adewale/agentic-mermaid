class Zl extends RangeError{code="C4_ROUTE_WORK_LIMIT";constructor(){super("C4_ROUTE_WORK_LIMIT: physical corridor checks exceed 400000; split the diagram or reduce its relationships");this.name="C4RouteWorkLimitError"}}
export{Zl};
