import{gi,tm,bt}from"./chunk-na8geb44.js";function ar(r,e={}){let n=r<=6?{accent:e.accent&&tm(e.accent)?e.accent:gi,bg:e.bg&&tm(e.bg)?e.bg:void 0}:e,a=bt(r,n),t=e.overrides;if(!t||t.length===0)return a;return a.map((o,c)=>t[c%12]??o)}
export{ar};
