function Ui(r){if(Number.isInteger(r))return String(r);let n=Math.round(r*100)/100;return String(Number.isFinite(n)&&(n!==0||r===0)?n:r)}
export{Ui};
