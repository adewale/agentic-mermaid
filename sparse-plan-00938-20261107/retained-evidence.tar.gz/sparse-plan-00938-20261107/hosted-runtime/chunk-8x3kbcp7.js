import{Vn}from"./chunk-yhvcnss9.js";function m(t){return(Math.round(t*100)/100).toString()}function ca(t,o,i,e,n){if(!i)throw TypeError(`Missing retained tooltip layout for ${e}`);let{block:a,bgW:p,bgX:s,bgY:l,textX:g,textY:c,ptrPath:u}=i,r=(h)=>Number(m(h));return t.group({id:e,role:"chrome",owner:n,visibility:"conditional",open:`<g class="${o}-tip">`,close:"</g>",join:"",children:[{indent:0,node:t.shape({id:`${e}:background`,role:"chrome",owner:n,geometry:{kind:"rect",x:r(s),y:r(l),width:r(p),height:Vn.height,rx:Vn.rx},paint:{fill:"var(--_text)"},attributes:{className:`${o}-tip ${o}-tip-bg`}})},{indent:0,node:t.shape({id:`${e}:pointer`,role:"chrome",owner:n,geometry:{kind:"path",d:u},paint:{fill:"var(--_text)"},attributes:{className:`${o}-tip ${o}-tip-ptr`}})},{indent:0,node:t.text({id:`${e}:text`,role:"label",owner:n,text:a.text,block:a,x:r(g),y:r(c),fontSize:Vn.fontSize,fontWeight:Vn.fontWeight,anchor:"middle",paint:{fill:"var(--bg)"},attributes:{className:`${o}-tip ${o}-tip-text`}})}]})}function vc(t,o){let i=o.map((e)=>`.${e}:hover .${t}-tip`).join(`,
  `);return`
  .${t}-tip { opacity: 0; pointer-events: none; }
  .${t}-tip-bg { fill: var(--_text); }
  .${t}-tip-text { fill: var(--bg); font-size: ${Vn.fontSize}px; font-weight: ${Vn.fontWeight}; }
  .${t}-tip-ptr { fill: var(--_text); }
  ${i} { opacity: 1; }`}
export{ca,vc};
