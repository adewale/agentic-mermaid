function Ml(n,o){for(let e of n)if(o(e),e.kind==="group")Ml(e.children.map((d)=>d.node),o)}
export{Ml};
