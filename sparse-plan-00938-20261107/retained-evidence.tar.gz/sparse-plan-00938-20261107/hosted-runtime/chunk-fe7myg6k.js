import{yp}from"./chunk-53x830wm.js";function Mo({positioned:o,options:i}){return yp(o,i)}
export{Mo};
