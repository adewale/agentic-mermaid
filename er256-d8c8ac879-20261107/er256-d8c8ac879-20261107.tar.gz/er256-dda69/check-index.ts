import {readFileSync,writeFileSync} from 'node:fs'
import {buildInkTree as before,createInkIndex as beforeQuery} from './ink-original.ts'
import {buildInkTree as after,createInkIndex as afterQuery} from '/tmp/pr449-main-integration-20261029-762/src/shared/ink-index.ts'
let seed=1530426
const next=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed}
const rows=[]
for(let n=0;n<180;n++){
 const count=9+next()%504,axis=n%3
 const items=Array.from({length:count},(_,id)=>{const x=axis===0?id*4:next()%32,y=axis===1?id*4:next()%32;return{id,x0:x,y0:y,x1:x+next()%8,y1:y+next()%8}})
 if(n%2)items.reverse()
 let oldWork=0,newWork=0
 const bounds=(v:typeof items[number])=>v,tie=n%4===0?(a:typeof items[number],b:typeof items[number])=>b.id-a.id:undefined
 const b=before([...items],bounds,c=>{oldWork+=c??1},tie),a=after([...items],bounds,c=>{newWork+=c??1},tie)
 if(JSON.stringify(a)!==JSON.stringify(b))throw Error('Tree order or bounds changed case'+n)
 const bq=beforeQuery(items,bounds,()=>{},1024),aq=afterQuery(items,bounds,()=>{},1024)
 for(let q=0;q<16;q++){const x=next()%(count*4),y=next()%(count*4),box={x0:x,y0:y,x1:x+next()%20,y1:y+next()%20};if(JSON.stringify(aq(box))!==JSON.stringify(bq(box)))throw Error('Query changed '+n+'/'+q)}
 rows.push({n,count,axis,treeExact:true,queryExact:16,oldWork,newWork})
}
writeFileSync('/tmp/pr449-week-comparison-20261101/er256-dda69/INDEX-EQUIVALENCE.json',JSON.stringify(rows,null,2))
console.log('180 mixed-axis/tie/reversed trees and2880 strict queries identical; work',rows.reduce((n,r)=>n+r.oldWork,0),'to',rows.reduce((n,r)=>n+r.newWork,0))
