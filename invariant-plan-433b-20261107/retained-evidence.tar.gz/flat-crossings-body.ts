export function countPolylineCrossings(routes: readonly CrossingPolyline[], involved?: ReadonlySet<number>): number {
  const starts: CrossingPoint[] = [], ends: CrossingPoint[] = []
  const edges: number[] = [], points: number[] = [], minX: number[] = [], maxX: number[] = [], minY: number[] = [], maxY: number[] = []
  const order: number[] = []
  routes.forEach((route, edgeIndex) => {
    if (route.visible === false) return
    for (let pointIndex = 0; pointIndex + 1 < route.points.length; pointIndex++) {
      const a = route.points[pointIndex]!, b = route.points[pointIndex + 1]!
      if (a.x === b.x && a.y === b.y) continue
      const index = order.length
      starts[index] = a; ends[index] = b; edges[index] = edgeIndex; points[index] = pointIndex
      minX[index] = Math.min(a.x, b.x); maxX[index] = Math.max(a.x, b.x)
      minY[index] = Math.min(a.y, b.y); maxY[index] = Math.max(a.y, b.y)
      order[index] = index
    }
  })
  order.sort((a, b) => minX[a]! - minX[b]! || minY[a]! - minY[b]! || edges[a]! - edges[b]! || points[a]! - points[b]!)
  const active: number[] = [], locations = new Map<string, CrossingLocation[]>()
  const left: RouteSegment = { a: { x: 0, y: 0 }, b: { x: 0, y: 0 }, edgeIndex: 0, pointIndex: 0 }
  const right: RouteSegment = { ...left }
  for (const segment of order) {
    const edge = edges[segment]!
    let retained = 0
    for (let index = 0; index < active.length; index++) {
      const other = active[index]!, peer = edges[other]!
      if (!(maxX[other]! >= minX[segment]!)) continue
      active[retained++] = other
      if (peer === edge || (involved && !involved.has(peer) && !involved.has(edge)) || maxY[other]! < minY[segment]! || minY[other]! > maxY[segment]!) continue
      left.a = starts[segment]!; left.b = ends[segment]!; left.edgeIndex = edge; left.pointIndex = points[segment]!
      right.a = starts[other]!; right.b = ends[other]!; right.edgeIndex = peer; right.pointIndex = points[other]!
      const point = crossingPoint(left, right, routes)
      if (!point) continue
      const key = `${Math.min(edge, peer)}:${Math.max(edge, peer)}`, previous = locations.get(key)
      if (previous) {
        const duplicate = previous.find(p => p.x === point.x && p.y === point.y)
        if (duplicate) duplicate.error = Math.max(duplicate.error, point.error)
        else previous.push(point)
      } else locations.set(key, [point])
    }
    active.length = retained
    active.push(segment)
  }
  let crossings = 0
  for (const points of locations.values()) {
    points.sort(pointOrder)
    const distinct: CrossingLocation[] = []
    for (const point of points) {
      if (!distinct.some(previous => sameLocation(previous, point, Math.max(previous.error, point.error)))) distinct.push(point)
    }
    crossings += distinct.length
  }
  return crossings
}
