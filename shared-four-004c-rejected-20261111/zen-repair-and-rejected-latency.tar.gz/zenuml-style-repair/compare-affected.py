import json,gzip,hashlib
from pathlib import Path
r=Path('/dev/shm/pr449-four-final-20261111'); z=r/'zenuml-style-repair'; rows=[]; products=[]
for fresh,old,styled in [('zen-async-scope-plain','browser-e0cac',False),('zen-async-scope-styled','browser-e0cac-styled',True)]:
 newdir=r/fresh/'browser'; olddir=r/old/'browser'
 oldrows=json.loads((olddir/'RESULTS.json').read_text())
 for n in json.loads((newdir/'RESULTS.json').read_text()):
  o=next(v for v in oldrows if v['backend']==n['backend'] and v['family']==n['family'] and v.get('style')==n.get('style'))
  arm='candidate-'+n['backend']+('-'+n['style'] if styled else ''); rel=Path(arm)/n['family']
  for call in [1,2]:
   nb=gzip.decompress((newdir/rel/f'call{call}.product.json.gz').read_bytes());ob=gzip.decompress((olddir/rel/f'call{call}.product.json.gz').read_bytes()); nv=json.loads(nb);ov=json.loads(ob)
   ns=json.dumps(nv['receipt'].get('layoutCertification'),sort_keys=True);os=json.dumps(ov['receipt'].get('layoutCertification'),sort_keys=True)
   nr=dict(nv['receipt']);orr=dict(ov['receipt']);nr.pop('layoutCertification',None);orr.pop('layoutCertification',None)
   products.append({'family':n['family'],'backend':n['backend'],'style':n.get('style'),'call':call,'wholeBytesExact':nb==ob,'wholeObjectExact':nv==ov,'svgExact':nv['svg']==ov['svg'],'noncertReceiptExact':nr==orr,'proofExact':ns==os,'proofStatus':nv['receipt'].get('layoutCertification',{}).get('status'),'newFile':str(newdir/rel/f'call{call}.product.json.gz'),'oldFile':str(olddir/rel/f'call{call}.product.json.gz')})
  rows.append({'family':n['family'],'backend':n['backend'],'style':n.get('style'),'qualification':n['status'],'observerErrors':n['observerErrors'],'requestsOld':o['requests'],'requestsNew':n['requests'],'productOld':o['product'],'productNew':n['product'],'productDelta':{k:n['product'][k]-o['product'][k] for k in ['raw','gzip9','brotli11']},'heapOld':o['heap']['metrics']['jsHeapUsedBytes'],'heapNew':n['heap']['metrics']['jsHeapUsedBytes'],'heapDelta':n['heap']['metrics']['jsHeapUsedBytes']-o['heap']['metrics']['jsHeapUsedBytes']})
report={'scope':'Fixed Zen build-only scope repair async artifact vs retained e0cac, 8 plain observations + 2 Native styled observations; mandatory support+enrolled each. Same pinned Trident qualifiers. No control rerenders. No API timing claim.','observations':len(rows),'products':len(products),'browserClosed':10,'browserOpen':0,'allWholeBytesExact':all(p['wholeBytesExact'] for p in products),'allWholeObjectsExact':all(p['wholeObjectExact'] for p in products),'allSvgExact':all(p['svgExact'] for p in products),'allNoncertReceiptsExact':all(p['noncertReceiptExact'] for p in products),'allProofsExact':all(p['proofExact'] for p in products),'rows':rows,'productRows':products}
(z/'ASYNC-AFFECTED-COMPARISON.json').write_text(json.dumps(report,indent=2)+'\n')
summary=['Fixed async scope qualification: 10/10 observations; 20/20 public full products. Browser closed10/open0.',f"Whole JSON bytes exact: {report['allWholeBytesExact']}; SVG/noncertification receipt/proof exact: {report['allSvgExact']}/{report['allNoncertReceiptsExact']}/{report['allProofsExact']}",'Actual product-module closure deltas vs retained e0cac (raw/gzip9/Brotli11 bytes, requests, heap bytes):']
for v in rows:summary.append(f"{v['family']} {v['backend']} {v['style'] or 'plain'}: {v['productDelta']}, requests {v['requestsOld']}→{v['requestsNew']}, heap {v['heapDelta']:+}; qualifier {v['qualification']}")
(z/'ASYNC-SUMMARY.txt').write_text('\n'.join(summary)+'\n');print('\n'.join(summary))
res=json.loads((z/'RESULT.json').read_text());res['asyncAffectedQualification']={'report':str(z/'ASYNC-AFFECTED-COMPARISON.json'),'observations':10,'products':20,'wholeBytesExact':report['allWholeBytesExact'],'allSvgNoncertProofExact':report['allSvgExact'] and report['allNoncertReceiptsExact'] and report['allProofsExact'],'browserClosed':10,'browserOpen':0};res['jobsOpen']=0;(z/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
(z/'CLOSED.json').write_text(json.dumps({'buildsOpen':0,'testsOpen':0,'browsersOpened':10,'browsersClosed':10,'browsersOpen':0,'profilersOpen':0,'clocksRun':0},indent=2)+'\n')
