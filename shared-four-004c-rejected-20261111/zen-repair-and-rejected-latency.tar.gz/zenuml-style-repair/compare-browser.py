import json,hashlib,re,difflib
from pathlib import Path
r=Path('/dev/shm/pr449-four-final-20261111'); a=r/'final-e0cac'; b=r/'zenuml-style-repair/fixed'; out=r/'zenuml-style-repair'
x=json.loads((a/'dist/metafile-esm.json').read_text()); y=json.loads((b/'dist/metafile-esm.json').read_text())
def canon(s):
 if 'node_modules/' in s:return 'node_modules/'+s.split('node_modules/',1)[1]
 return re.sub(r'^(?:\.\./)+','/',s)

def sig(v):return (canon(v.get('entryPoint','')),tuple(sorted(canon(k) for k in v['inputs'])))
ai={sig(v):(k,v) for k,v in x['outputs'].items()}; bi={sig(v):(k,v) for k,v in y['outputs'].items()}
assert len(ai)==len(x['outputs']) and len(bi)==len(y['outputs'])
assert ai.keys()==bi.keys(), 'output source sets changed'
pairs=[(ai[s][0],bi[s][0]) for s in sorted(ai,key=str)]
# Only replace known emitted import-target basenames, retaining all executable code otherwise.
rename={Path(bk).name:Path(ak).name for ak,bk in pairs}
pattern=re.compile('|'.join(re.escape(k) for k in sorted(rename,key=len,reverse=True)))
changes=[]; identical=0; semantic=[]
for ak,bk in pairs:
 av=(a/ak).read_text();bv=(b/bk).read_text(); bn=pattern.sub(lambda m:rename[m.group()],bv)
 if av==bv:identical+=1
 if av!=bn:
  start=0
  while start<min(len(av),len(bn)) and av[start]==bn[start]:start+=1
  stop=0
  while stop<min(len(av),len(bn))-start and av[-stop-1]==bn[-stop-1]:stop+=1
  oldspan=av[start:len(av)-stop if stop else len(av)];newspan=bn[start:len(bn)-stop if stop else len(bn)]
  spans=[{'offset':start,'oldLength':len(oldspan),'newLength':len(newspan),'old':oldspan[:300],'new':newspan[:300]}]
  semantic.append({'old':ak,'new':bk,'oldBytes':len(av.encode()),'newBytes':len(bv.encode()),'differences':spans})
report={'baseline':str(a),'candidate':str(b),'outputs':len(pairs),'inputsOld':len(x['inputs']),'inputsNew':len(y['inputs']),'sameInputSets':True,'rawIdenticalPairedFiles':identical,'specifierNormalizedEqualFiles':len(pairs)-len(semantic),'specifierNormalization':'Replace only known emitted filenames using unique entryPoint+inputset pairing; no source code normalization.','remainingChangedFiles':semantic,'pairs':[{'old':ak,'new':bk} for ak,bk in pairs]}
(out/'BROWSER-CODE-COMPARISON.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='pairs'},indent=2))
