import {readFileSync,readdirSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
import {normalizePackagePath} from '/tmp/pr449-main-integration-20261029-762/scripts/ci/verify-publish-package.ts'
const base=import.meta.dir,result:any={normalizer:'existing scripts/ci/verify-publish-package.ts normalizePackagePath; no manifest mutation',arms:{}}
for(const arm of ['bad','fixed']){
 const files=readdirSync(join(base,arm,'dist/zenuml/chunks')).filter(x=>x.endsWith('.js')).map(x=>'dist/zenuml/chunks/'+x).sort()
 const normalized=files.map(normalizePackagePath).sort(),counts:any={};for(const row of normalized)counts[row]=(counts[row]??0)+1
 result.arms[arm]={files,normalized,counts}
}
writeFileSync(join(base,'NORMALIZED-ZEN-ROWS.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({bad:result.arms.bad.counts,fixed:result.arms.fixed.counts,fixedRows:result.arms.fixed.normalized},null,2))
