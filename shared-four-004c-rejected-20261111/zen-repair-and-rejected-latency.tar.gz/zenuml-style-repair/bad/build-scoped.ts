import { build } from 'tsup'; import options from './tsup.zenuml.config.ts'; for(const config of options) await build({...config,config:false,dts:false,clean:false,sourcemap:false});
