import { countOpposingRouteOverlaps } from './shared/edge-overlaps.ts'
export { countOpposingRouteOverlaps } from './shared/edge-overlaps.ts'
/**
 * Deterministic layout-quality rubric (docs/design/system/layout-rubric.md).
 *
 * Computes the empirically validated graph-drawing aesthetics (Purchase 1997,
 * 2002: crossings and bends are the strongest comprehension factors), the
 * orthogonal-drawing tradition's bend/orthogonality criteria (Tamassia), the
 * Kakoulis–Tollis edge-label criteria (a label must associate unambiguously
 * with its own edge), and this project's route/port contracts — all from
 * final geometry, with no human judgment. Hard metrics must be zero; soft
 * metrics are reported for thresholds set per fixture class.
 *
 * The outline oracle is independent of the layout/clipping code paths: it
 * reimplements each shape's rendered outline equation from the renderer's
 * geometry, so a port or clipping regression cannot hide itself.
 */

import type { MermaidGraph, Point, PositionedEdge, PositionedGraph, PositionedGroup, PositionedNode } from './types.ts'
import { diamondFacetPorts, findRouteHitches, hasBundleRouteExemption, invalidEndpointApproaches, PORT_EXACT, shapePorts } from './route-contracts.ts'
import { renderedEndpointContact } from './rendered-endpoint-diagnostics.ts'
import { graphTextBlock } from './graph-text.ts'
import { resolveRenderStyle } from './styles.ts'
import type { ResolvedRenderStyle } from './styles.ts'
import type { PassMetrics, RubricMetric } from './layout/pass.ts'
import { measureLabelConflicts } from './layout/label-conflicts.ts'
import { countPolylineCrossings } from './shared/edge-crossings.ts'
import { graphReachability } from './layout/geometry.ts'
import { hasConstructedBundleRoute } from './layout/bundle-routes.ts'

/**
 * Evidence-based impact rank for a violation, mirroring the QualityBounds
 * provenance (src/agent/quality.ts BOUND_PROVENANCE, grounded in Purchase
 * 1997/2002): readability-destroying defects (edges through nodes, overlaps,
 * crossings) rank above routing-shape defects (bends, diagonals, hitches),
 * which rank above endpoint/label-placement cosmetics. Reports sort by this so
 * the most-impactful violation is read first, not buried in declaration order.
 *
 * JUSTIFIED / SYMMETRIC BEND (not a defect): a bend that is part of a SYMMETRIC
 * convergence — a fan-out/fan-in bundle, or a co-ranked mixed-label fan-in's
 * converging dogleg — is "as good as" a straight line and is NOT penalized. The
 * bend is structurally necessary to converge, and the symmetry it buys offsets
 * the small bend cost; every reference layered drawer routes a fan that way, and
 * our own fan-out emitter (applySymmetricFanoutEmissions) does too. So
 * bundle-certified bends are excluded from totalBends/maxBendsPerEdge below — the
 * SAME edges findRouteHitches treats as non-hitches, keeping the bend penalty and
 * the HARD hitch-invariant in agreement. Only UNJUSTIFIED / lone bends still cost
 * (an off-lane jog with a clear straight lane is a `hitches` HARD violation; a
 * bend on a 'straight'-certified edge is an `unexplainedBends` HARD violation).
 */
export type RubricSeverity = 'primary' | 'secondary' | 'cosmetic'

const RUBRIC_SEVERITY: Record<string, RubricSeverity> = {
  edgeThroughNode: 'primary',
  nodeOverlaps: 'primary',
  diagonalSegments: 'secondary',
  unexplainedBends: 'secondary',
  hitches: 'secondary',
  offOutlineEndpoints: 'cosmetic',
  endpointApproaches: 'primary',
  labelOffRoute: 'cosmetic',
}

const RUBRIC_SEVERITY_ORDER: Record<RubricSeverity, number> = { primary: 0, secondary: 1, cosmetic: 2 }

export function rubricSeverity(metric: string): RubricSeverity {
  return RUBRIC_SEVERITY[metric] ?? 'secondary'
}

export interface RubricViolation {
  metric: string
  detail: string
  /** Evidence-based impact rank; reports are sorted by it. */
  severity: RubricSeverity
}

export interface RubricMetrics {
  edges: number
  /** HARD (0): edge endpoints must lie on the rendered shape outline. */
  offOutlineEndpoints: number
  /** HARD (0): exact endpoints must carry an outward, non-tangent shaft. */
  endpointApproaches: number
  /** HARD (0): orthogonal routing must not emit diagonal segments. */
  diagonalSegments: number
  /** HARD (0): an edge certified 'straight' may not have bends. */
  unexplainedBends: number
  /** HARD (0): no edge may bend while a clear direct lane exists for it. */
  hitches: number
  /** HARD (0): node bounding boxes may not overlap. */
  nodeOverlaps: number
  /** HARD (0): a label pill must sit on its own route (Kakoulis–Tollis). */
  labelOffRoute: number
  /** HARD (0): edge segments through a non-incident node's interior. */
  edgeThroughNode: number
  /** Padded label/label, label/node and label/visible-route conflict pairs. */
  labelConflicts: number
  /** Purchase's strongest validated aesthetic — minimize. */
  edgeCrossings: number
  /** Purchase-validated — minimize. Excludes justified symmetric-convergence
   *  bends (bundle-certified fan-out/fan-in spokes): those are "as good as
   *  straight", the same edges findRouteHitches treats as non-hitches. */
  totalBends: number
  /** As totalBends, also excluding justified symmetric-convergence bends. */
  maxBendsPerEdge: number
  /** Fraction of edge ends sitting exactly on a canonical port. */
  portEndpointRate: number
  /** Fraction of edges with at least one end on a canonical port. */
  portAnchoredEdgeRate: number
  /** Largest cross-axis offset between a peer hub and its peer barycenter. */
  peerBarycenterDelta: number
  /** SOFT label-CENTRING metric: max over labelled edges of
   *  labelMidpointOffset (|projFrac(label) - 0.5|). 0 = every label centred on
   *  its route; →0.5 = a label jammed at an endpoint. This is the gap that let
   *  the symmetric-dogleg hugging through — labelOffRoute only proves a label is
   *  ON its route, never WELL-PLACED on it. 0 when no labelled edges. */
  worstLabelOffset: number
}

export interface RubricResult {
  metrics: RubricMetrics
  violations: RubricViolation[]
}

/**
 * Whether a point lies on the rendered outline of a shape, within `tol` px.
 * Shapes without an exact oracle yet fall back to the bbox perimeter, which
 * is exact at the four ports and approximate elsewhere.
 */
function onDesignatedPort(node: PositionedNode, p: Point): boolean {
  const near = (q: Point) => Math.abs(q.x - p.x) <= 0.5 && Math.abs(q.y - p.y) <= 0.5
  if ((Object.values(shapePorts(node)) as Point[]).some(near)) return true
  if (node.shape === 'diamond' && (Object.values(diamondFacetPorts(node)) as Point[]).some(near)) return true
  return false
}

export function onShapeOutline(node: PositionedNode, p: Point, tol = 1.5): boolean {
  const contact = renderedEndpointContact(node, p, tol)
  return contact.policy === 'none' || contact.onBoundary
}

/**
 * Rendered polygon outlines of the slanted shapes, restated from the
 * renderer's geometry (shear = w * 0.15 for the trapezoid/parallelogram
 * family; the asymmetric flag indents its left point by 12px).
 */
function slantedPolygonVertices(node: PositionedNode): Point[] {
  const { x, y, width: w, height: h } = node
  const inset = w * 0.15
  switch (node.shape) {
    case 'trapezoid': // wider bottom
      return [{ x: x + inset, y }, { x: x + w - inset, y }, { x: x + w, y: y + h }, { x, y: y + h }]
    case 'trapezoid-alt': // wider top
      return [{ x, y }, { x: x + w, y }, { x: x + w - inset, y: y + h }, { x: x + inset, y: y + h }]
    case 'lean-r': // parallelogram leaning right
      return [{ x: x + inset, y }, { x: x + w, y }, { x: x + w - inset, y: y + h }, { x, y: y + h }]
    case 'lean-l': // parallelogram leaning left
      return [{ x, y }, { x: x + w - inset, y }, { x: x + w, y: y + h }, { x: x + inset, y: y + h }]
    default: // asymmetric: flag with a pointed left edge
      return [{ x: x + 12, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x: x + 12, y: y + h }, { x, y: y + h / 2 }]
  }
}

/**
 * Whether an axis-aligned segment passes through a node's rendered footprint
 * (not merely its bbox — a route grazing the empty corner outside a circle's
 * disk or a diamond's facet is legal). Plain and explicitly decorated full
 * rectangles use their open interior; curved shapes retain the tolerance.
 */
export function segmentThroughShape(a: Point, b: Point, node: PositionedNode): boolean {
  const cx = node.x + node.width / 2
  const cy = node.y + node.height / 2
  const hw = node.width / 2
  const hh = node.height / 2
  const xLo = Math.min(a.x, b.x), xHi = Math.max(a.x, b.x)
  const yLo = Math.min(a.y, b.y), yHi = Math.max(a.y, b.y)
  // Independently restate the renderer's classic cylinder core (cap ry = 7).
  // Its curved caps keep the existing graze policy; their empty corners do
  // not justify a tolerance inside the core's straight, fully painted sides.
  if (node.shape === 'cylinder' && (node.semanticShape === undefined || node.semanticShape === 'cyl')
    && node.height > 14 && xHi > node.x && xLo < node.x + node.width
    && yHi > node.y + 7 && yLo < node.y + node.height - 7) return true
  const rectangularBody = (node.shape === 'rectangle' || node.shape === 'subroutine')
    && (node.semanticShape === undefined || node.semanticShape === 'rect' || node.semanticShape === 'fr-rect'
      || node.semanticShape === 'lin-rect' || node.semanticShape === 'div-rect' || node.semanticShape === 'win-pane')
  const inset = rectangularBody ? 0 : 0.5
  const inBbox = xHi > node.x + inset && xLo < node.x + node.width - inset &&
    yHi > node.y + inset && yLo < node.y + node.height - inset
  if (!inBbox) return false

  // For curved/pointed shapes, occlusion means penetrating DEEPER than the
  // stroke width (2px): a route that grazes a diamond tip or a circle's rim
  // by a hairline is not a legible defect, and dense corridors sometimes
  // provably admit nothing better. Rectangles stay strict: any interior
  // incursion is visible against a straight side.
  const GRAZE = 2.5
  switch (node.shape) {
    case 'ellipse':
    case 'circle':
    case 'doublecircle':
    case 'state-start':
    case 'state-end': {
      // Scale to a unit circle so ellipses work too, then test segment distance.
      const sa = { x: (a.x - cx) / hw, y: (a.y - cy) / hh }
      const sb = { x: (b.x - cx) / hw, y: (b.y - cy) / hh }
      return pointToSegmentDistance({ x: 0, y: 0 }, sa, sb) < 1 - GRAZE / Math.min(hw, hh)
    }
    case 'stadium': {
      const r = hh
      const coreA = { x: cx - (hw - r), y: cy }
      const coreB = { x: cx + (hw - r), y: cy }
      return segmentToSegmentDistance(a, b, coreA, coreB) < r - GRAZE
    }
    case 'diamond':
    case 'hexagon':
    case 'trapezoid':
    case 'trapezoid-alt':
    case 'lean-r':
    case 'lean-l':
    case 'asymmetric': {
      const raw = node.shape === 'diamond'
        ? [
          { x: cx, y: node.y }, { x: node.x + node.width, y: cy },
          { x: cx, y: node.y + node.height }, { x: node.x, y: cy },
        ]
        : node.shape === 'hexagon'
          ? (() => {
            const inset = node.height / 4
            return [
              { x: node.x + inset, y: node.y }, { x: node.x + node.width - inset, y: node.y },
              { x: node.x + node.width, y: cy }, { x: node.x + node.width - inset, y: node.y + node.height },
              { x: node.x + inset, y: node.y + node.height }, { x: node.x, y: cy },
            ]
          })()
          : slantedPolygonVertices(node)
      const shrink = Math.max(0, 1 - GRAZE / Math.min(hw, hh))
      const verts = raw.map(v => ({ x: cx + (v.x - cx) * shrink, y: cy + (v.y - cy) * shrink }))
      return segmentThroughConvexPolygon(a, b, verts)
    }
    default:
      return true // rect-like (and cylinder, whose footprint is its bbox)
  }
}

function segmentThroughConvexPolygon(a: Point, b: Point, verts: Point[]): boolean {
  const inside = (p: Point): boolean => {
    for (let i = 0; i < verts.length; i++) {
      const v1 = verts[i]!, v2 = verts[(i + 1) % verts.length]!
      if ((v2.x - v1.x) * (p.y - v1.y) - (v2.y - v1.y) * (p.x - v1.x) < -0.5) return false
    }
    return true
  }
  const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }
  if (inside(a) || inside(b) || inside(mid)) return true
  for (let i = 0; i < verts.length; i++) {
    if (segmentsIntersect(a, b, verts[i]!, verts[(i + 1) % verts.length]!)) return true
  }
  return false
}

function segmentToSegmentDistance(a: Point, b: Point, c: Point, d: Point): number {
  if (segmentsIntersect(a, b, c, d)) return 0
  return Math.min(
    pointToSegmentDistance(a, c, d), pointToSegmentDistance(b, c, d),
    pointToSegmentDistance(c, a, b), pointToSegmentDistance(d, a, b),
  )
}

function segmentsIntersect(a: Point, b: Point, c: Point, d: Point): boolean {
  const det = (b.x - a.x) * (d.y - c.y) - (b.y - a.y) * (d.x - c.x)
  if (Math.abs(det) < 1e-9) return false
  const t = ((c.x - a.x) * (d.y - c.y) - (c.y - a.y) * (d.x - c.x)) / det
  const u = ((c.x - a.x) * (b.y - a.y) - (c.y - a.y) * (b.x - a.x)) / det
  return t > 0.001 && t < 0.999 && u > 0.001 && u < 0.999
}

/** Shared visible-route predicate, also used by public quality measurement. */
export function countEdgeCrossings(edges: readonly PositionedEdge[], involved?: ReadonlySet<number>): number {
  return countPolylineCrossings(edges.map(edge => ({ points: edge.points, visible: edge.style !== 'invisible' })), involved)
}

/** Same-endpoint parallel routes sharing visible collinear ink cannot be
 * distinguished along that span. Endpoint distance alone does not prove this. */
type InkEdge = Pick<PositionedEdge, 'source' | 'target' | 'style' | 'points'>

export function countParallelRouteOverlaps(edges: readonly InkEdge[], involved?: ReadonlySet<number>): number {
  const pairs = new Map<string, Array<{ edge: InkEdge; index: number }>>()
  edges.forEach((edge, index) => {
    if (edge.style === 'invisible' || edge.source === edge.target) return
    const key = JSON.stringify([edge.source, edge.target])
    const group = pairs.get(key) ?? []
    group.push({ edge, index }); pairs.set(key, group)
  })
  const sharesSpan = (a: InkEdge, b: InkEdge): boolean => {
    for (let i = 1; i < a.points.length; i++) for (let j = 1; j < b.points.length; j++) {
      const p = a.points[i - 1]!, q = a.points[i]!, r = b.points[j - 1]!, s = b.points[j]!
      if (Math.abs(p.x - q.x) <= 0.01 && Math.abs(r.x - s.x) <= 0.01 && Math.abs(p.x - r.x) <= 0.5 && Math.min(Math.max(p.y, q.y), Math.max(r.y, s.y)) - Math.max(Math.min(p.y, q.y), Math.min(r.y, s.y)) > 1) return true
      if (Math.abs(p.y - q.y) <= 0.01 && Math.abs(r.y - s.y) <= 0.01 && Math.abs(p.y - r.y) <= 0.5 && Math.min(Math.max(p.x, q.x), Math.max(r.x, s.x)) - Math.max(Math.min(p.x, q.x), Math.min(r.x, s.x)) > 1) return true
    }
    return false
  }
  let overlaps = 0
  for (const group of pairs.values()) for (let i = 0; i < group.length; i++) for (let j = i + 1; j < group.length; j++) {
    const a = group[i]!, b = group[j]!
    if ((!involved || involved.has(a.index) || involved.has(b.index)) && sharesSpan(a.edge, b.edge)) overlaps++
  }
  return overlaps
}


export function portEndpointRate(positioned: Pick<PositionedGraph, 'nodes' | 'edges'>, visibleOnly = false): number {
  const nodes = new Map(positioned.nodes.map(node => [node.id, node]))
  let measured = 0, attached = 0
  for (const edge of positioned.edges) {
    if (visibleOnly && edge.style === 'invisible') continue
    for (const [id, point] of [[edge.source, edge.points[0]], [edge.target, edge.points.at(-1)]] as const) {
      const node = nodes.get(id)
      if (!node) continue
      measured++
      if (point && onDesignatedPort(node, point)) attached++
    }
  }
  return measured === 0 ? 1 : attached / measured
}

function pointToSegmentDistance(p: Point, a: Point, b: Point): number {
  const dx = b.x - a.x
  const dy = b.y - a.y
  const lenSq = dx * dx + dy * dy
  if (lenSq === 0) return Math.hypot(p.x - a.x, p.y - a.y)
  const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / lenSq))
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy))
}

/**
 * Distance from an axis-aligned rectangle (a label pill) to a segment; 0 when
 * they touch or overlap. Unlike point-to-segment from the pill CENTRE, this
 * treats a label whose BODY meets the route as on-route — the correct test for
 * self-loops, where ELK legitimately parks the label beside the small loop stub
 * so the pill's near edge touches the stub while its centre sits a pill-width away.
 */
function rectToSegmentDistance(cx: number, cy: number, hw: number, hh: number, a: Point, b: Point): number {
  const inside = (p: Point) => p.x >= cx - hw && p.x <= cx + hw && p.y >= cy - hh && p.y <= cy + hh
  if (inside(a) || inside(b)) return 0
  const corners: Point[] = [
    { x: cx - hw, y: cy - hh }, { x: cx + hw, y: cy - hh },
    { x: cx + hw, y: cy + hh }, { x: cx - hw, y: cy + hh },
  ]
  let best = Infinity
  for (let i = 0; i < 4; i++) best = Math.min(best, segmentToSegmentDistance(corners[i]!, corners[(i + 1) % 4]!, a, b))
  return best
}

/**
 * Arc-length position (0..1) along a polyline of the closest point on the route
 * to `pt` — the fractional projection of a label onto its own edge. 0 is the
 * source end, 1 the target end, 0.5 the route's arc-length midpoint.
 */
function projFrac(pt: Point, pts: Point[]): number {
  let total = 0
  const seglen: number[] = []
  for (let i = 1; i < pts.length; i++) {
    const d = Math.hypot(pts[i]!.x - pts[i - 1]!.x, pts[i]!.y - pts[i - 1]!.y)
    seglen.push(d); total += d
  }
  let best = Infinity, bestArc = 0, acc = 0
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1]!, b = pts[i]!, dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy
    let t = l2 ? ((pt.x - a.x) * dx + (pt.y - a.y) * dy) / l2 : 0
    t = Math.max(0, Math.min(1, t))
    const px = a.x + t * dx, py = a.y + t * dy, d = Math.hypot(pt.x - px, pt.y - py)
    if (d < best) { best = d; bestArc = acc + t * seglen[i - 1]! }
    acc += seglen[i - 1]!
  }
  return total ? bestArc / total : 0.5
}

/**
 * Label-CENTRING metric (SOFT): how far a label's projection onto its own route
 * is from the route midpoint. `labelMidpointOffset = |projFrac(labelPosition) -
 * 0.5|`; 0 is perfectly centred, →0.5 is jammed against an endpoint.
 *
 * Why this is its own metric and not covered by labelOffRoute: labelOffRoute
 * (HARD) only checks a label sits ON its route (Kakoulis–Tollis association),
 * never WHERE along it. A symmetric re-route (co-rank fan-in / fan-out dogleg)
 * can leave a label HARD-clean — exactly on its route — yet hugging an endpoint,
 * which reads as belonging to the node rather than the edge. That hugging slips
 * past labelOffRoute, the HARD gate, and the byte-exact equivalence gate. This
 * metric is the missing centring check; dagre places edge labels at the route
 * midpoint, so a well-placed label scores ≈0.
 */
export function labelMidpointOffset(edge: PositionedEdge): number {
  if (!edge.label || !edge.labelPosition || edge.points.length < 2) return 0
  return Math.abs(projFrac(edge.labelPosition, edge.points) - 0.5)
}

function nodeCrossCenter(node: PositionedNode, direction: MermaidGraph['direction']): number {
  return direction === 'LR' || direction === 'RL'
    ? node.y + node.height / 2
    : node.x + node.width / 2
}

function nodeMainStart(node: PositionedNode, direction: MermaidGraph['direction']): number {
  return direction === 'LR' || direction === 'RL' ? node.x : node.y
}

function nodeMainEnd(node: PositionedNode, direction: MermaidGraph['direction']): number {
  return direction === 'LR' || direction === 'RL'
    ? node.x + node.width
    : node.y + node.height
}

function forwardish(source: PositionedNode, target: PositionedNode, direction: MermaidGraph['direction']): boolean {
  if (direction === 'LR') return nodeMainStart(target, direction) > nodeMainEnd(source, direction)
  if (direction === 'RL') return nodeMainEnd(target, direction) < nodeMainStart(source, direction)
  if (direction === 'BT') return nodeMainEnd(target, direction) < nodeMainStart(source, direction)
  return nodeMainStart(target, direction) > nodeMainEnd(source, direction)
}

function samePeerLayer(nodes: PositionedNode[], direction: MermaidGraph['direction'], tolerance = 1): boolean {
  if (nodes.length < 2) return false
  const starts = nodes.map(node => nodeMainStart(node, direction))
  return Math.max(...starts) - Math.min(...starts) <= tolerance
}

function nodeInsideGroups(node: PositionedNode, groups: PositionedGroup[]): boolean {
  const visit = (items: PositionedGroup[]): boolean => items.some(group =>
    (node.x >= group.x - 0.5 && node.y >= group.y - 0.5 &&
      node.x + node.width <= group.x + group.width + 0.5 &&
      node.y + node.height <= group.y + group.height + 0.5) || visit(group.children))
  return visit(groups)
}


// The sym metric: largest cross-axis offset between a PORT_EXACT peer hub and
// its peer barycenter — directly the fan-in/fan-out symmetry the centering
// optimizes. LABELED spokes are INCLUDED (a mixed-label fan-in is exactly the
// case the co-rank default squares up; excluding its labeled spoke hid the win,
// so the metric measured nothing there). The peer-layer test is relaxed to the
// SAME 28px tolerance centerPeerBarycenters uses to decide a fan-in's sources
// are same-rank peers, so the metric and the centering pass agree on which
// fan-ins count: a co-ranked mixed-label fan-in is now seen and reads ≈0 when
// the hub is centered, instead of being invisible. The shape gate MATCHES the
// relaxed centerPeerBarycenters guard: the HUB may be any PORT_EXACT shape (a
// DECISION diamond, round, stadium, …) and so may a FAN-IN peer, so a diamond
// hub/source centering now registers instead of being invisible; FAN-OUT peers
// stay rectangle-only (that side is owned by applySymmetricFanoutEmissions).
// (Still requires distinct, mutually-unreachable peers on one flow layer.)
const SYM_PEER_LAYER_TOL = 28
function peerBarycenterDelta(positioned: PositionedGraph, graph: MermaidGraph): number {
  const reaches = graphReachability(graph.edges)
  const nodeMap = new Map(positioned.nodes.map(n => [n.id, n]))
  const bySource = new Map<string, PositionedNode[]>()
  const byTarget = new Map<string, PositionedNode[]>()
  for (const edge of positioned.edges) {
    const source = nodeMap.get(edge.source)
    const target = nodeMap.get(edge.target)
    if (!source || !target || !forwardish(source, target, graph.direction)) continue
    if (!bySource.has(edge.source)) bySource.set(edge.source, [])
    bySource.get(edge.source)!.push(target)
    if (!byTarget.has(edge.target)) byTarget.set(edge.target, [])
    byTarget.get(edge.target)!.push(source)
  }
  let worst = 0
  // Peer-shape gate mirrors centerPeerBarycenters exactly so the metric measures
  // precisely what the pass optimizes: FAN-IN peers may be any PORT_EXACT shape,
  // FAN-OUT peers stay rectangle-only (applySymmetricFanoutEmissions owns non-rect
  // fan-out spread; the metric must not claim a fan-out the pass never centres).
  const update = (hub: PositionedNode | undefined, peers: PositionedNode[], side: 'in' | 'out') => {
    if (!hub || peers.length < 2 || peers.length > 6 || !samePeerLayer(peers, graph.direction, SYM_PEER_LAYER_TOL)) return
    if (!PORT_EXACT.has(hub.shape) || nodeInsideGroups(hub, positioned.groups)) return
    const peerShapeOk = (peer: PositionedNode) => side === 'in' ? PORT_EXACT.has(peer.shape) : peer.shape === 'rectangle'
    if (!peers.every(peer => peerShapeOk(peer) && !nodeInsideGroups(peer, positioned.groups))) return
    if (new Set(peers.map(peer => peer.id)).size !== peers.length) return
    for (let i = 0; i < peers.length; i++) for (let j = 0; j < peers.length; j++) {
      if (i !== j && reaches(peers[i]!.id, peers[j]!.id)) return
    }
    const barycenter = peers.reduce((sum, peer) => sum + nodeCrossCenter(peer, graph.direction), 0) / peers.length
    worst = Math.max(worst, Math.abs(nodeCrossCenter(hub, graph.direction) - barycenter))
  }
  for (const [source, targets] of bySource) update(nodeMap.get(source), targets, 'out')
  for (const [target, sources] of byTarget) update(nodeMap.get(target), sources, 'in')
  return worst
}

/**
 * Score a positioned layout against the rubric. Pure and deterministic:
 * identical input produces identical metrics.
 */
export function assessLayout(graph: MermaidGraph, positioned: PositionedGraph, style: ResolvedRenderStyle = resolveRenderStyle({})): RubricResult {
  return assessLayoutGeometry(graph, positioned, style, true)
}

interface ProducedGeometryBounds { nodes: Float64Array; edges: Float64Array }

/** One observation of constructor-produced primitive geometry, never retained
 * across passes. The generic public entry keeps its live getter observations. */
function producedGeometryBounds(positioned: PositionedGraph): ProducedGeometryBounds | undefined {
  const nodes = new Float64Array(positioned.nodes.length * 4)
  const edges = new Float64Array(positioned.edges.length * 4)
  for (let index = 0; index < positioned.nodes.length; index++) {
    const { x, y, width, height } = positioned.nodes[index]!
    if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(width) || !Number.isFinite(height)
      || !Number.isFinite(x + width) || !Number.isFinite(y + height) || width < 0 || height < 0) return undefined
    const at = index * 4
    nodes[at] = x; nodes[at + 1] = y; nodes[at + 2] = x + width; nodes[at + 3] = y + height
  }
  for (let index = 0; index < positioned.edges.length; index++) {
    const points = positioned.edges[index]!.points
    let left = Infinity, top = Infinity, right = -Infinity, bottom = -Infinity
    for (const point of points) {
      if (!Number.isFinite(point.x) || !Number.isFinite(point.y)) return undefined
      left = Math.min(left, point.x); top = Math.min(top, point.y)
      right = Math.max(right, point.x); bottom = Math.max(bottom, point.y)
    }
    const at = index * 4
    edges[at] = left; edges[at + 1] = top; edges[at + 2] = right; edges[at + 3] = bottom
  }
  return { nodes, edges }
}

function assessLayoutGeometry(graph: MermaidGraph, positioned: PositionedGraph, style: ResolvedRenderStyle, withSoftMetrics: boolean, produced?: ProducedGeometryBounds): RubricResult {
  // Built without severity, then enriched + sorted by impact at the return.
  const violations: Array<Omit<RubricViolation, 'severity'>> = []
  const nodeMap = new Map(positioned.nodes.map(n => [n.id, n]))

  let offOutline = 0
  let endpointApproaches = 0
  let diagonal = 0
  let unexplainedBends = 0
  let labelOffRoute = 0
  let totalBends = 0
  let maxBends = 0
  let portAnchoredEdges = 0
  let worstLabelOffset = 0

  for (const e of positioned.edges) {
    const id = `${e.source}->${e.target}`
    const bends = Math.max(0, e.points.length - 2)
    if (e.style !== 'invisible') {
      const approaches = invalidEndpointApproaches(e, nodeMap.get(e.source), nodeMap.get(e.target))
      if (approaches) {
        endpointApproaches += approaches
        violations.push({ metric: 'endpointApproaches', detail: `${id}: ${approaches} inward or tangent exact endpoint shaft(s)` })
      }
    }
    // Justified-bend exemption: a bend that is part of a SYMMETRIC convergence
    // (a fan-out/fan-in bundle, or a co-ranked mixed-label fan-in's dogleg) is
    // "as good as straight" — the bend is structurally necessary to converge and
    // the symmetry it buys offsets the cost, the same idiom every reference
    // layered drawer (and our own fan-out emitter) uses. So it does not count
    // toward totalBends/maxBendsPerEdge. We key off the SAME 'bundle' certificate
    // findRouteHitches uses to skip these edges (route-contracts.ts), so the bend
    // penalty and the HARD hitch-invariant AGREE on what is justified. This does
    // NOT touch unexplainedBends (which fires only on 'straight'-certified edges,
    // and a bundle edge is never 'straight') or hitches (HARD, unchanged).
    const justifiedConvergenceBend = withSoftMetrics && hasBundleRouteExemption(e)
    if (withSoftMetrics && e.style !== 'invisible' && !justifiedConvergenceBend) {
      totalBends += bends
      maxBends = Math.max(maxBends, bends)
    }

    if (bends > 0 && e.routeCertificate?.invariant === 'straight') {
      unexplainedBends += bends
      violations.push({ metric: 'unexplainedBends', detail: `${id} certified straight with ${bends} bends` })
    }

    for (let i = 1; i < e.points.length; i++) {
      const a = e.points[i - 1]!, b = e.points[i]!
      if (Math.abs(a.x - b.x) > 0.01 && Math.abs(a.y - b.y) > 0.01) {
        diagonal++
        violations.push({ metric: 'diagonalSegments', detail: `${id} segment ${i}` })
      }
    }

    for (const [nodeId, pt, label] of [
      [e.source, e.points[0]!, 'source'],
      [e.target, e.points[e.points.length - 1]!, 'target'],
    ] as const) {
      const node = nodeMap.get(nodeId)
      if (!node) continue
      if (!pt || !onShapeOutline(node, pt)) {
        offOutline++
        violations.push({ metric: 'offOutlineEndpoints', detail: pt ? `${id} ${label} on ${nodeId}(${node.shape}) at (${pt.x.toFixed(1)},${pt.y.toFixed(1)})` : `${id} missing ${label} endpoint on ${nodeId}` })
      }
    }
    if (withSoftMetrics) {
      const srcNode = nodeMap.get(e.source)
      const tgtNode = nodeMap.get(e.target)
      const onPort = (node: PositionedNode | undefined, pt: Point | undefined) => node && pt ? onDesignatedPort(node, pt) : false
      if (onPort(srcNode, e.points[0]!) || onPort(tgtNode, e.points[e.points.length - 1]!)) portAnchoredEdges++
    }

    if (e.label && e.labelPosition && e.points.length >= 2) {
      // Layout retains the text the renderer actually draws. The explicit
      // style fallback admits callers constructing older unprepared artifacts.
      const m = e.labelBlock ?? graphTextBlock(e.label, style, 'edge')
      const allow = (m.height + 16) / 2 + 4
      // A self-loop's label legitimately sits BESIDE the small loop stub (ELK's
      // native placement), so its CENTRE is a pill-width from the stub while its
      // body touches it. Measure pill-to-route for self-loops; centre-to-route
      // for ordinary edges, where the label is meant to sit ON the line.
      const selfLoop = e.source === e.target
      let best = Infinity
      for (let i = 1; i < e.points.length; i++) {
        best = Math.min(best, selfLoop
          ? rectToSegmentDistance(e.labelPosition.x, e.labelPosition.y, (m.width + 16) / 2, (m.height + 16) / 2, e.points[i - 1]!, e.points[i]!)
          : pointToSegmentDistance(e.labelPosition, e.points[i - 1]!, e.points[i]!))
      }
      if (best > allow) {
        labelOffRoute++
        violations.push({ metric: 'labelOffRoute', detail: `${id} label ${best.toFixed(1)}px from its route (allowed ${allow.toFixed(1)})` })
      }
      // SOFT label-CENTRING aggregate: track the worst (most off-centre) label.
      if (withSoftMetrics) worstLabelOffset = Math.max(worstLabelOffset, labelMidpointOffset(e))
    }
  }

  let edgeThroughNode = 0
  let edgeIndex = 0
  for (const e of positioned.edges) {
    let nodeIndex = 0
    for (const node of positioned.nodes) {
      const ordinal = nodeIndex++
      if (node.id === e.source || node.id === e.target) continue
      if (produced) {
        const edge = edgeIndex * 4, box = ordinal * 4
        // Closed bounding boxes only remove impossible pairs. The original
        // shape predicate, segment order and authored-node order remain exact.
        if (produced.edges[edge + 2]! < produced.nodes[box]! || produced.edges[edge]! > produced.nodes[box + 2]!
          || produced.edges[edge + 3]! < produced.nodes[box + 1]! || produced.edges[edge + 1]! > produced.nodes[box + 3]!) continue
      }
      for (let i = 1; i < e.points.length; i++) {
        if (segmentThroughShape(e.points[i - 1]!, e.points[i]!, node)) {
          edgeThroughNode++
          violations.push({ metric: 'edgeThroughNode', detail: `${e.source}->${e.target} segment ${i} through ${node.id}` })
          break
        }
      }
    }
    edgeIndex++
  }

  const crossings = withSoftMetrics ? countEdgeCrossings(positioned.edges) : 0

  let nodeOverlaps = 0
  for (let i = 0; i < positioned.nodes.length; i++) {
    for (let j = i + 1; j < positioned.nodes.length; j++) {
      const a = positioned.nodes[i]!, b = positioned.nodes[j]!
      let ox: number, oy: number
      if (produced) {
        oy = Math.min(produced.nodes[i * 4 + 3]!, produced.nodes[j * 4 + 3]!) - Math.max(produced.nodes[i * 4 + 1]!, produced.nodes[j * 4 + 1]!)
        if (oy <= 0.5) continue
        ox = Math.min(produced.nodes[i * 4 + 2]!, produced.nodes[j * 4 + 2]!) - Math.max(produced.nodes[i * 4]!, produced.nodes[j * 4]!)
      } else {
        ox = Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x)
        oy = Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y)
      }
      if (ox > 0.5 && oy > 0.5) {
        nodeOverlaps++
        violations.push({ metric: 'nodeOverlaps', detail: `${a.id} overlaps ${b.id}` })
      }
    }
  }

  const hitchList = findRouteHitches(positioned, graph, style)
  for (const h of hitchList) violations.push({ metric: 'hitches', detail: `${h.edge} deviates ${h.deviationPx}px with a clear lane` })

  return {
    metrics: {
      edges: positioned.edges.length,
      offOutlineEndpoints: offOutline,
      endpointApproaches,
      diagonalSegments: diagonal,
      unexplainedBends,
      hitches: hitchList.length,
      nodeOverlaps,
      labelOffRoute,
      edgeThroughNode,
      labelConflicts: withSoftMetrics ? measureLabelConflicts(positioned, style).total : 0,
      edgeCrossings: crossings,
      totalBends,
      maxBendsPerEdge: maxBends,
      portEndpointRate: withSoftMetrics ? portEndpointRate(positioned) : 0,
      portAnchoredEdgeRate: positioned.edges.length === 0 ? 1 : portAnchoredEdges / positioned.edges.length,
      peerBarycenterDelta: withSoftMetrics ? peerBarycenterDelta(positioned, graph) : 0,
      worstLabelOffset,
    },
    violations: violations
      .map(v => ({ ...v, severity: rubricSeverity(v.metric) }))
      .sort((a, b) => RUBRIC_SEVERITY_ORDER[a.severity] - RUBRIC_SEVERITY_ORDER[b.severity]),
  }
}

/** Requested pass-budget metrics share the final rubric's predicates without
 * running unrelated hard checks, collision pairs or label/hitch searches. */
export function measureRubricMetrics(
  graph: MermaidGraph,
  positioned: PositionedGraph,
  requested: readonly RubricMetric[],
  style: ResolvedRenderStyle,
  bundled: ReadonlySet<PositionedEdge> = new Set(),
): PassMetrics {
  return measureGeometryMetrics(graph, positioned, requested, style, bundled)
}

/** Private measured-producer consumer: its literal node/route records contain
 * the current primitive geometry. No caller brand or cross-pass cache applies. */
export function measureProducedRubricMetrics(
  graph: MermaidGraph, positioned: PositionedGraph, requested: readonly RubricMetric[],
  style: ResolvedRenderStyle, bundled: ReadonlySet<PositionedEdge>,
): PassMetrics {
  return measureGeometryMetrics(graph, positioned, requested, style, bundled,
    requested.includes('hard') ? producedGeometryBounds(positioned) : undefined)
}

function measureGeometryMetrics(
  graph: MermaidGraph, positioned: PositionedGraph, requested: readonly RubricMetric[],
  style: ResolvedRenderStyle, bundled: ReadonlySet<PositionedEdge>, produced?: ProducedGeometryBounds,
): PassMetrics {
  const result: PassMetrics = {}
  let hard: RubricResult | undefined
  for (const metric of requested) {
    switch (metric) {
      case 'hard': {
        hard = assessLayoutGeometry(graph, positioned, style, false, produced)
        result.hard = hardViolations(hard).length
        break
      }
      case 'crossings': result.crossings = countEdgeCrossings(positioned.edges); break
      case 'portRate': result.portRate = portEndpointRate(positioned, true); break
      case 'symErr': result.symErr = peerBarycenterDelta(positioned, graph); break
      case 'parallelOverlaps': result.parallelOverlaps = countParallelRouteOverlaps(positioned.edges); break
      case 'opposingOverlaps': result.opposingOverlaps = countOpposingRouteOverlaps(positioned.edges); break
      case 'endpointApproaches': {
        if (produced && hard) { result.endpointApproaches = hard.metrics.endpointApproaches; break }
        const nodes = new Map(positioned.nodes.map(node => [node.id, node]))
        result.endpointApproaches = positioned.edges.reduce((sum, edge) => sum + (edge.style === 'invisible' ? 0 : invalidEndpointApproaches(edge, nodes.get(edge.source), nodes.get(edge.target))), 0)
        break
      }
      case 'bends': result.bends = positioned.edges.reduce((sum, edge) => sum + (edge.style === 'invisible' || (edge.routeCertificate ? hasBundleRouteExemption(edge) : bundled.has(edge) && hasConstructedBundleRoute(edge)) ? 0 : Math.max(0, edge.points.length - 2)), 0); break
      case 'straight': result.straight = positioned.edges.filter(edge => edge.style !== 'invisible' && edge.points.length === 2).length; break
    }
  }
  return result
}

/** The hard rubric metrics — must be zero for every diagram, always. */
export const HARD_METRICS = [
  'offOutlineEndpoints', 'endpointApproaches', 'diagonalSegments', 'unexplainedBends',
  'hitches', 'nodeOverlaps', 'labelOffRoute', 'edgeThroughNode',
] as const

export function hardViolations(result: RubricResult): RubricViolation[] {
  const hard = new Set<string>(HARD_METRICS)
  return result.violations.filter(v => hard.has(v.metric))
}
