import { readFileSync } from 'node:fs'
Bun.plugin({name:'retained-build-plugin-before',setup(build){build.onLoad({filter:/[/\\]scripts[/\\]build[/\\]runtime-render-contract\.ts$/},()=>({contents:readFileSync('/tmp/pr449-week-comparison-20261101/trinity-image-delivery-cost-20261109/runtime-render-contract-before.ts','utf8'),loader:'ts'}))}})
