## What changes

**Draft; keep ELK as the default.** This PR repairs shared SVG ownership and measurement, improves selected Native layouts, and adds an opt-in Trinity backend. It does not establish that Trinity can replace ELK. Source `e387064d03db1b3e909d9e114aa8aae8dd040d01`, current main `e7cb05baa7f68154942a9ce9c6e9aaaee163dc94`. Defaults, versions and original limits remain unchanged.

The substantive changes are:

- Bind proof to actual SVG writes and occurrence ownership, preserving mutable/getter, UTF16, CSS and definitions isolation. Native and ELK now deliver ER256 in four directions within the original 400k geometry cap; previously refused BT/RL use 385344 Native / 371874 ELK operations.
- Repair Native endpoint capacity, invisible constraints, shortening clearance, component packing and nonlinear forests. The recorded forest comparison reduces wire 700.04→397.71 versus ELK396.47 and area 226466→165356 versus ELK176727. Sparse256's implemented historical area gap is **+5.04%**; the +0.97% backfill remains unshipped. [Dated comparison and scope](https://github.com/adewale/agentic-mermaid/blob/fb8258f17fadf2996e15aa4c82a0973b1cefae4f/rebase-c366-reconsider-20261107/README.md).
- Give canonical sharp-shaft Requirement the same physical demand across all three backends. This shared repair also improves ELK: crowded containment circles move 7.67/10.77→20px apart against 11px needed. Selected hidden pixels fall 180→0. Trinity's flat Requirement projection reduces 18→6 bends and wire 1072.96→507.03; compound locals retain centered contacts. [Actual ink and adverse costs](https://github.com/adewale/agentic-mermaid/blob/91400dc282c7717ffa9bf658c83351969dc679de/trinity-common-requirement-checkpoint-20261109/README.md).
- Introduce explicit measured placement/routed results and a real, bounded Trinity solver. Public scope includes rectangular/rounded Flowchart and State scopes, fixed State circles, canonical Class scopes, flat ER/Requirement and single-container Architecture forests. Closed-scope decision diamonds reuse canonical facets. The routed slice remains limited to 64 subjects / 128 edges. Unsupported inputs decline unless fallback was requested; exhaustion remains hard.
- Preserve original containment during shared fanout proposals. Our finishing pass moved an ELK leaf 2.1545px outside its frame after correct raw layout. Reusing existing snapshots and rollback restores TB/BT delivery before route/label publication. [Reproduction and costs](https://github.com/adewale/agentic-mermaid/blob/5520235500263602ded1024df60f6ffd217ec227/trinity-fanout-containment-checkpoint-20261109/README.md).
- Render explicitly sized, rectangular inline PNGs through the shared parser, measurement and drawing path. Native/ELK replace their vector placeholder with the actual image; Trinity adds delivery. Picture/caption geometry is shared with public label bounds. A distinct raster mark carries the resource through default, rough and hybrid drawing; raster paint remains **unmeasured and unverified**. Remote/unsupported media stays inert, with no fetch or decoder. Strict security allows only the exact self-contained PNG href on an unprefixed image element. Existing custom backends still render ordinary diagrams and reject actual image use unless they declare support. No new cache or relaxed cap.

## Current correctness comparison

Same frozen 30 inputs and explicit backend / fallback:none:

| Outcome | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| SVG delivered |28|28|28|
| Proof passed |27|27|27|
| Raster proof unverified |1|1|1|
| Shared invalid-option errors |2|2|2|

This cohort does not establish whole-workload equivalence. The fresh 90-cell qualification retains 81 byte-exact whole SVGs/entire receipts, three image products with unverified proof, and six unchanged errors. Before, Native/ELK's placeholder passed vector proof while failing actual-image meaning; Trinity refused. After, all three render the authored PNG and keep that raster uncertainty explicit.

Public image owners check all three solvers × four directions × default/rough/hybrid: actual href and viewport, more than 900 red pixels, caption separation, matching public label bounds, UTF16 labels, identities/endpoints and deterministic products. Canonical frozen Inter rasters change 0→9025–9216 red pixels. These pixel observations do not grant a reusable raster certificate. The earlier 613-criterion ledger retains its recorded revision rather than being silently promoted to a current fidelity score. [All current evidence](https://github.com/adewale/agentic-mermaid/blob/4137edf4d9680744a2e0d187b2b1577606c084bb/trinity-controlled-image-checkpoint-20261109/README.md).

## Equal-work performance and memory

Current controlled-image LR, complete SVG + entire receipt serialized in fresh Node24 processes. Two replicas/cell; imports, GC, compression and writes are separate. All 60 image calls return/unverified. There is no timing ratio against the old placeholder or refusal.

| Metric | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| Area |44804.08|44804.08|45485.79|
| Written wire / bends / crossings |48 /0/0|48 /0/0|48.75 /0/0|
| First target cache0 wall ms; import separate |394.54|281.16|187.66|
| Uncached repeat2 wall / CPU ms |52.75 /93.19|41.78 /58.52|28.60 /53.65|
| Original edit / repeated edit cache0 wall ms |40.57 /40.11|34.97 /35.05|21.92 /44.18|
| Cached repeat2 / repeated edit wall ms |11.02 /28.74|6.29 /16.84|5.13 /19.54|
| API-return heap cache0 repeat2 MiB |47.09–47.31|36.90–36.91|36.26–36.30|
| Lifetime peak RSS cache0 repeat2 MiB |182.00–188.93|172.17–177.63|169.61–183.19|
| Full response gzip9 / Brotli11 bytes |2442 /2105|2443 /2107|2455 /2118|

Trinity uses 1.52% more area and 1.56% more wire than ELK here, and loses the repeated-edit timing to Native. Reserving the actual picture also increases Native/ELK area from 32393.93 to 44804.08; the placeholder did less work. Ranges overlap. Memory includes imports, harness and retained products, not isolated solver peak or settled retention. Cache0/1 switches only the existing layout cache; other derived caches remain. No general speed, p95 or memory winner follows.

Forty equal-work before/current ELK LR control calls keep exact products. Edit CPU114.77→116.52ms and repeated-edit wall68.14→68.44ms are adverse. All100 complete streams match timed serialization lengths; eight unique gzip9/Brotli11 products decode exactly. [Raw samples, controls and limitations](https://github.com/adewale/agentic-mermaid/blob/4137edf4d9680744a2e0d187b2b1577606c084bb/trinity-controlled-image-checkpoint-20261109/README.md). [Earlier full-cohort costs](https://github.com/adewale/agentic-mermaid/blob/86869bd66c21f73db5c33928c242ed7a9b50186b/trinity-frozen-cost-checkpoint-20261109/README.md) retain adverse cached Flowchart/Architecture costs; this small case does not replace them.

## Distribution cost

Current packaging contract under implementation: keep the canonical image-layout functions in their existing browser measurement module to remove the extra helper request introduced by the image slice. Source/Node modules and runtime math stay unchanged. The build projection must preserve the canonical PNG-reference import and reject unexpected runtime imports or initialization; complete SVG/receipt equality and initial versus later reachability are checked in Sequence-first and Flowchart-first orders. The external probe removes one request per graph lane, saves167–194gzip bytes but adds2–26Brotli bytes; Sequence adds1gzip/27Brotli bytes with unchanged requests. These costs remain explicit and imply no latency improvement.

Actual original 13-input lazy-browser product union; all three Trident lanes pass. Binding overhead is separate from product bytes:

| Metric | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| gzip9 bytes |860644|488886|482171|
| Brotli11 bytes |690694|419125|413060|
| Requests including binding |44|50|51|
| Image change: gzip / Brotli growth |+2288 /+1936|+2353 /+1991|+2351 /+1993|

The change adds one request per lane. Separate controlled-image browser lanes also pass. These are actual fetched modules compressed offline, not compressed-wire or startup measurements. Distribution budgets remain failed and unraised: the earlier9ec standalone measured1335329gzip against1334500, and the demo313916 against302500. These standalone/demo measurements are dated to9ec; this milestone builds the lazy product.

## Visual evidence

Baseline SHA: `c0099d8cebe2d88b31199ec8d67210b349ae558a`.
Current SHA: `e387064d03db1b3e909d9e114aa8aae8dd040d01`. These are actual canonical SVG renders, with manifest-verified Inter and system fonts disabled. Before, Native/ELK draw a placeholder and Trinity emits no SVG. After, the red square is the authored PNG, with the caption below it; Trinity retains its slightly larger layout.

| Native/ELK before | Native/ELK after | Trinity after |
| --- | --- | --- |
| ![Placeholder before](https://raw.githubusercontent.com/adewale/agentic-mermaid/4137edf4d9680744a2e0d187b2b1577606c084bb/trinity-controlled-image-checkpoint-20261109/ELK-before-LR.png) | ![Authored PNG after](https://raw.githubusercontent.com/adewale/agentic-mermaid/4137edf4d9680744a2e0d187b2b1577606c084bb/trinity-controlled-image-checkpoint-20261109/ELK-after-LR.png) | ![Trinity authored PNG](https://raw.githubusercontent.com/adewale/agentic-mermaid/4137edf4d9680744a2e0d187b2b1577606c084bb/trinity-controlled-image-checkpoint-20261109/Trinity-after-LR.png) |

```mermaid
flowchart LR
Art@{ img: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/iZk9HQAAAABJRU5ErkJggg==", label: "Icon", w: 32, h: 32, constraint: "on" }
Art --> Target[Target]
```

## Verification and remaining losses

Reproduce with `bun test src/__tests__/graph-layout-selection.test.ts -t 'actual sized inline PNG' --timeout 30000`. There are221 passing owning tests across10files, core/repository types and lint pass. Typed-model and security tests are red before the repairs; actual-use custom-backend rejection is separately red→green. Review found and corrected icon-precedence and global-registration regressions. Independent scope/security/ownership review finds no remaining supported blocker in this slice. Full suite runs in CI.

[Exact-head CI42630591780](https://github.com/adewale/agentic-mermaid/actions/runs/42630591780) is running; Ruff and action pinning pass. Previous c009 exact-head CI42622039576 completed/failure. This PR is not ready.

Remaining: Sparse32 emitted-proof exhaustion at400k; Native compound/halo losses; Trinity compound TB29 versus ELK13 crossings; broader unsupported domains, unknown raster paint, adverse cached costs and failed distribution budgets. The full-halo, single source-permutation and stopped ER shortcuts remain falsified/unshipped. Original2dad baseline/equivalent pinned Pele runtime remain unavailable. Replacement24 stays sealed; ELK retirement remains deferred.

[Dated five-hotspot profile and cache inventory](https://github.com/adewale/agentic-mermaid/blob/e387064d03db1b3e909d9e114aa8aae8dd040d01/docs/design/system/layout-0.6-performance-review.md). No new cache or invented speedup is added by the image repair.
