# Canonical image helper packaging: independent decision

Recommend the small projection inside the existing coalesceRuntimePrimitives build path. It removes the extra request introduced by the image slice, reuses an existing packaging owner, and need not alter source/API/runtime calculations. This is proportionate if it remains one fail-closed module projection rather than a new build framework. No production edits or new experiments by this reviewer.

The original external probe's actual 13-input portfolio recorded one fewer request per backend and gzip savings of 181/167/194 bytes for ELK/Native/Trinity. Brotli was adverse by 26/20/2 bytes. Sequence's unchanged request count came with gzip +1 and Brotli +27 bytes in all lanes. These historical probe measurements are retained; final guarded-production results below supersede them for the shipping decision. Neither acquisition measures a latency improvement.

The probe's broad import-line removal should not ship unchanged. The existing runtimeRenderContractPlugin already has exact-path resolution and AST helpers that validate expected import names and declaration inventories. Remove only the known host import and the known image-leaf dependency imports; preserve the canonical isInlinePng dependency and fail on unexpected runtime imports or initialization statements. Do not silently discard future side effects or relocate relative imports incorrectly. All redirected imports must resolve to one combined module, with the host's self-import removed, so no duplicated function owner, shadow implementation or new cycle is created.

The image leaf currently contains only a type alias and three stateless functions; it owns no private brands, WeakMaps, caches, identity tokens or mutable initialization. Co-location therefore has no current authority-state split to repair. It must preserve exact positive-dimension coercion, own metadata checks, icon priority, fit selection, caption reservation and actual emitted PNG href. Keep the source/Node/IIFE and noncoalescing build paths untouched. The projection must not activate image paint proof or relax reference security.

The important remaining comparisons are concrete and bounded: actual before/after SVG plus entire receipts for the existing image and authored-edit products; the invalid/unsupported media cases retaining their outcome; and actual non-Graph Sequence products. Include loading Sequence first versus Flowchart first, because redirecting parser's imageDimension import to graph-measurement changes module reachability and can move dependencies earlier. Check initial-loader and later-request bytes separately from whole-union bytes; fewer requests alone does not prove a better critical path. Existing actual builds already demonstrate the sampled portfolio and Sequence deliveries return; use the existing owners rather than add a new qualification framework.

No blocker found in the proposed module-level co-location itself. The implementation boundary is exact canonical dependency projection, with full-product equality and the Brotli/Sequence adverse values retained. If productionization requires a general graph rewriter, duplicated declarations or new initialization protocol, stop at this external probe instead.

## Final production review and disposition

No blocker found in the targeted production diff. It lives entirely under the existing coalesceRuntimePrimitives branch. Exact resolved paths select the image leaf and measurement host; withoutRuntimeImport verifies the known host import and the one canonical PNG import before removing them. runtimeDeclarations verifies the expected ImageNode/imageDimension/flowchartImageViewport/flowchartImageContent declaration inventory and rejects unexpected runtime imports or top-level statements. The canonical PNG import is reintroduced using its absolute resolved original module path. The extension to runtimeDeclarations preserves its existing default source behavior for all other callers. No broad import regex from the probe ships.

This retains one canonical stateless helper owner, removes its host self-import, introduces no cache/brand/storage/math change, and leaves noncoalescing source/Node/IIFE paths unchanged. The existing owning-test addition checks actual dynamically loaded viewport/caption/dimension behavior, including rejection of boolean dimension coercion. That fixture passes in both arms; it is not claimed as the red witness for removing a real browser request.

Final actual production portfolio figures against e387:

| Backend | Requests | gzip bytes (delta) | Brotli bytes (delta) |
| --- | --- | --- | --- |
| ELK | 43 (−1) | 860463 (−181) | 690650 (−44) |
| Native | 49 (−1) | 488723 (−163) | 419058 (−67) |
| Trinity | 50 (−1) | 481980 (−191) | 412994 (−66) |

Initial loading retains four requests, identical raw/Brotli bytes, and gzip +2 bytes. Actual final Sequence-only output retains 15 requests, gzip 226578 versus 226580 (−2), and Brotli 188798 versus 188776 (+22, adverse). Keep that Sequence regression and initial gzip cost visible; this is not a universal compression improvement.

Coordinator evidence reports all 60 actual Chromium SVG+entire-receipt calls exact across 12 unique products, three backends, Sequence-first/Flowchart-first loading, authored edits and repeats; the 13-input portfolio and image-only lanes pass. This addresses the concrete reachability/initialization concern without claiming broad semantic qualification or runtime speedup. I reviewed source and retained facts, not reran those products or checks.

The output-directory overlap was an acquisition provenance issue, not a source correctness result. Retained trial assets, recovered metadata, and the isolated 94-member production-metafile artifact keep trial versus production operands explicit. Asset hashes bind measured files only; they are not correctness proofs. Initial esbuild EPERM remains a retained failed attempt. Recommendation remains to promote this narrow existing-plugin projection, with no new framework or additional gate.
