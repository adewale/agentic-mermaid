import { build } from '/tmp/pr449-main-integration-20261029-762/node_modules/tsup/dist/index.js'
import config from '/tmp/pr449-main-integration-20261029-762/tsup.browser-lazy.config.ts'
import { readFileSync } from 'node:fs'
import { resolve, dirname } from 'node:path'
const root = '/tmp/pr449-main-integration-20261029-762', image = root+'/src/flowchart-image.ts', measurement = root+'/src/layout/graph-measurement.ts'
const probe = { name: 'same-canonical-image-producer-union', setup(build: any) {
  build.onResolve({filter: /[/\\]flowchart-image\.ts$/}, (args: any) => resolve(args.resolveDir,args.path) === image ? {path:measurement}:undefined)
  build.onLoad({filter: /[/\\]layout[/\\]graph-measurement\.ts$/}, (args: any) => {
    if(args.path !== measurement) return undefined
    const source = readFileSync(measurement,'utf8'), imported = "import { flowchartImageViewport, flowchartImageContent } from '../flowchart-image.ts'\n"
    if(!source.includes(imported)) throw Error('canonical image producer import changed')
    const leaves = readFileSync(image,'utf8').replace(/^import .+\n/gm,'')
    return { contents:source.replace(imported,'')+"\nimport { isInlinePng } from '../shared/inline-png.ts'\n"+leaves,loader:'ts',resolveDir:dirname(measurement) }
  })
}}
await build({...config, config:false, dts:false, clean:false, esbuildPlugins:[probe,...config.esbuildPlugins],outDir:import.meta.dir+'/dist'})
