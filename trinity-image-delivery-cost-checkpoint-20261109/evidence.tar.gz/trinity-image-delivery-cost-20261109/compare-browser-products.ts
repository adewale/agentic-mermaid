import { chromium } from '/tmp/pr449-main-integration-20261029-762/node_modules/playwright/index.mjs'
import { createServer } from 'node:http'
import { readFileSync,writeFileSync,mkdirSync } from 'node:fs'
import { join,resolve,extname } from 'node:path'
import { gzipSync,brotliCompressSync,constants } from 'node:zlib'
import { createHash } from 'node:crypto'
const out=import.meta.dir, roots={baseline:'/tmp/pr449-week-comparison-20261101/trinity-controlled-image-20261109/dist/browser-lazy',candidate:out+'/production-dist/browser-lazy'}
const image=JSON.parse(readFileSync(out+'/CASE.json','utf8')).source, sequence='sequenceDiagram\nA->>B: Hello'
const sources={image,sequence,imageEdit:image.replace('label: "Icon"','label: "Icon revised"'),sequenceEdit:sequence.replace('Hello','Hello revised')}
const fileFor=(url:string)=>{const m=/^\/(baseline|candidate)\/(.*)$/.exec(url);if(!m)return undefined;const base=roots[m[1] as keyof typeof roots],file=resolve(base,decodeURIComponent(m[2]!));return file.startsWith(base+'/')?file:undefined}
const server=createServer((req,res)=>{if(req.url==='/blank'){res.setHeader('content-type','text/html');res.end('<!doctype html><body>');return}const f=fileFor(new URL(req.url!,'http://local').pathname);try{if(!f)throw Error('path');res.setHeader('content-type',extname(f)==='.js'?'text/javascript':'application/octet-stream');res.end(readFileSync(f))}catch{res.writeHead(404).end()}})
await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const address=server.address() as {port:number},origin='http://127.0.0.1:'+address.port
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium'}),rows:any[]=[],refs=new Map<string,string>()
mkdirSync(out+'/whole-browser-products',{recursive:true})
try{for(const arm of ['baseline','candidate']as const)for(const first of ['image','sequence']as const)for(const backend of ['elk','agentic','trinity']){
 const context=await browser.newContext({serviceWorkers:'block'}),fetched=new Set<string>();context.on('request',r=>{const u=new URL(r.url());if(u.origin===origin&&u.pathname!=='/blank')fetched.add(u.pathname)})
 await context.route('**/*',route=>new URL(route.request().url()).origin===origin?route.continue():route.abort())
 const page=await context.newPage();await page.goto(origin+'/blank');await page.evaluate(async url=>{(globalThis as any).candidateApi=await import(url)},origin+'/'+arm+'/index.js')
 const initial=[...fetched],calls:any[]=[]
 for(const name of[first,first==='image'?'sequence':'image','imageEdit','sequenceEdit','image']as const){
  const serialized=await page.evaluate(async({source,backend})=>{const p=await(globalThis as any).candidateApi.renderMermaidSVGWithReceiptAsync(source,{graphLayout:{backend,fallback:'none'},embedFontImport:false});return JSON.stringify({svg:p.svg,receipt:p.receipt})},{source:sources[name],backend})
  const key=backend+':'+name.replace(/Edit$/,'Edit'),prior=refs.get(key);if(prior!==undefined&&serialized!==prior)throw Error('Whole product differs: '+arm+':'+first+':'+key);refs.set(key,serialized)
  const sha=createHash('sha256').update(serialized).digest('hex');writeFileSync(out+'/whole-browser-products/'+sha+'.json.gz',gzipSync(serialized,{level:9}));const parsed=JSON.parse(serialized);calls.push({name,bytes:Buffer.byteLength(serialized),sha256:sha,proof:parsed.receipt.layoutCertification?.status})
 }
 const costs=(paths:string[])=>paths.reduce((a,path)=>{const b=readFileSync(fileFor(path)!);a.requests++;a.raw+=b.length;a.gzip9+=gzipSync(b,{level:9}).length;a.brotli11+=brotliCompressSync(b,{params:{[constants.BROTLI_PARAM_QUALITY]:11}}).length;return a},{requests:0,raw:0,gzip9:0,brotli11:0})
 rows.push({arm,first,backend,calls,initial:costs(initial),final:costs([...fetched]),initialFiles:initial,allFiles:[...fetched]});console.log(JSON.stringify(rows.at(-1)));await context.close()
}}finally{await browser.close();await new Promise<void>(r=>server.close(()=>r()))}
writeFileSync(out+'/WHOLE-BROWSER-COMPARISON.json',JSON.stringify({calls:rows.reduce((n,r)=>n+r.calls.length,0),uniqueProducts:refs.size,wholeSvgAndReceiptExact:true,scope:'Actual published baseline and guarded-production lazy products in Chromium. Fresh contexts, Sequence-first/Flowchart-first plus interleaved edits/repeats,3explicit graph backends. Initial/final fetched product bytes compressed offline, no latency or wire claim. Runtime equivalence validation, not new layout/visible progress.',rows},null,2)+'\n')
