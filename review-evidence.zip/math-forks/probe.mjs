import {writeFileSync,mkdirSync,readFileSync} from 'node:fs'
import {createRequire} from 'node:module'
import {decodeXML} from '/workspace/agentic-mermaid/node_modules/entities/dist/esm/index.js'
import * as beautiful from 'beautiful-mermaid'
import * as zombie from 'zombie-mermaid'
import * as agentic from '/workspace/.cloud-setup/upstream-implementation-2026-10-30/consumer/node_modules/agentic-mermaid/dist/index.js'
import {renderMermaidPNG} from '/workspace/.cloud-setup/upstream-implementation-2026-10-30/consumer/node_modules/agentic-mermaid/dist/agent.js'
const sdk={beautiful,zombie,agentic}
const cases=[
 ['fraction','flowchart LR\nA["$$\\frac{a}{b}$$"]'],
 ['mixed','flowchart LR\nA["Cost $$x^2$$ per request"]'],
 ['unknown-command','flowchart LR\nA["$$\\invalidMath{x}$$"]'],
 ['unclosed-delimiter','flowchart LR\nA["Cost $$x^2"]'],
 ['unicode','flowchart LR\nA["α + β = γ; x²"]'],
 ['nu-command','flowchart LR\nA["$$\\nu + \\nabla f$$"]'],
 ['sequence','sequenceDiagram\nA->>B: Cost $$\\frac{a}{b}$$'],
 ['class-member','classDiagram\nclass A {\n  $$x^2$$ value\n}'],
 ['markdown-label','flowchart LR\nA["`**Cost** $$x^2$$`"]'],
 ['markdown-document','# Example\n\n```mermaid\nflowchart LR\nA["$$x^2$$"]\n```'],
 ['stream-incomplete-quote','flowchart LR\nA["Cost $$x'],
 ['stream-complete-quote','flowchart LR\nA["Cost $$x^2$$"]'],
]
const out='/workspace/.cloud-setup/math-fork-comparison-2026-10-30'
mkdirSync(`${out}/output`,{recursive:true})
const results=[]
for(const[name,api]of Object.entries(sdk))for(const[id,source]of cases){
 const row={project:name,id,source}
 for(const [kind,fn]of [['svg',api.renderMermaidSVG],['ascii',api.renderMermaidASCII]]){
  try{
   if(typeof fn!=='function'){row[kind]={status:'no-export'};continue}
   const rendered=await fn(source)
   const value=typeof rendered==='string'?rendered:JSON.stringify(rendered)
   writeFileSync(`${out}/output/${name}-${id}.${kind==='ascii'?'txt':'svg'}`,value)
   row[kind]={status:'rendered',...(kind==='svg'?{text:[...value.matchAll(/<text\b[^>]*>([\s\S]*?)<\/text>/g)].map(m=>decodeXML(m[1].replace(/<[^>]*>/g,''))),mathMarkup:/(?:<math\b|katex|<mfrac\b|<msup\b)/i.test(value),foreignObject:/<foreignObject\b/.test(value)}:{output:value})}
  }catch(e){row[kind]={status:'error',name:e.name,message:e.message}}
 }
 results.push(row)
}
const png=await renderMermaidPNG(cases[0][1])
writeFileSync(`${out}/output/agentic-fraction.png`,png)
writeFileSync(`${out}/results.json`,JSON.stringify({runtime:process.version,exports:Object.fromEntries(Object.entries(sdk).map(([name,api])=>[name,Object.keys(api).filter(x=>/render.*(?:PNG|SVG|ASCII)/.test(x))])),png:{project:'agentic',bytes:png.byteLength},results},null,2))
console.log(JSON.stringify(results.map(r=>({project:r.project,id:r.id,svg:r.svg,asciiStatus:r.ascii.status})),null,2))
