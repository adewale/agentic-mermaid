# Beautiful, Agentic and Zombie Mermaid: math behavior — 30 October 2026

The three browserless forks **do not typeset mathematical labels** in the paths checked. They render a formula-looking label through their ordinary text pipeline. This is observable behavior, not an inference from missing dependencies.

## Versions and evidence

Public npm artifacts executed with Node 24.19.0:

- `beautiful-mermaid@1.1.3`; registry `gitHead` is `65f4e0ab8c289e9691a9e5bc4f9eac7108cf449b`. Source inspected independently at current main `2ac8bbbb060ca0a65a6a21f3200bd99b1587b488`.
- `zombie-mermaid@5.12.0`. Its registry metadata did not provide `gitHead`; source inspected independently at current main `507a2263b8cc181dff18dd61ddd95eeb15d7169c`. Do not claim those source snapshots identify the exact package build commit.
- Agentic Mermaid's locally packed, unpublished `0.5.4` candidate from the preceding task, based on `83744a4e1ae5c9d3821ba8a283811367fd31eade`. A repeat of the fraction source through SVG, terminal and `verifyMermaid` on current source commit `354a9e97de5e125d2dec74fc2fd879b65bae8fb7` (package version `0.5.5`) gives the same raw TeX and verification result; see `current-agentic.json`. The historical tarball does not identify the current release version.

`consumer/probe.mjs` exercises twelve sources in SVG and terminal output for each project: **72 render attempts**. Full inputs, outcomes and SVG/text artifacts are in `results.json` and `output/`. PNG was also exercised through Agentic's agent entry and Zombie's installed CLI. Artifact identities are in `beautiful-package.json`, `zombie-package.json` and the consumer lock file. These are bounded examples, not every TeX command, family, platform or font.

## What happens in each situation

| Situation | Beautiful 1.1.3 | Agentic candidate 0.5.4 | Zombie 5.12.0 |
| --- | --- | --- | --- |
| `A["$$\frac{a}{b}$$"]` | Raw delimiters and TeX commands in SVG `<text>` and terminal cells; no fraction layout | Same | Same |
| Mixed prose: `Cost $$x^2$$ per request` | Ordinary label text; `^2` is not raised | Same | Same |
| Invalid command `$$\invalidMath{x}$$`, or unmatched `Cost $$x^2` | Renders text; no typesetter validation/error | Same | Same |
| Sequence message containing a fraction | Message includes raw TeX | Same | Same |
| Class member `$$x^2$$ value` | Raw math text, with ordinary class formatting (`value: $$x^2$$`) | Raw math text | Raw math text |
| Unicode `α + β = γ; x²` | Those Unicode characters remain in SVG/terminal text; font coverage is a separate question | Same | Same |
| `$$\nu + \nabla f$$` | Ordinary escaped-line-break handling consumes each `\n`: lines become `$$`, `u +`, `abla f$$` | Same | Same |
| Markdown-formatted label | Bold text works, math stays text; this package also leaves outer backticks visible in the tested label | Bold works, outer Markdown backticks removed; math stays text | Same as Agentic |
| Entire Markdown document passed to `renderMermaidSVG` | Invalid-header error | Unrecognized-header error | Invalid-header error |
| Incomplete streaming label `A["Cost $$x` | Returns a provisional node labeled `A` | Rejects incomplete flowchart syntax | Returns a provisional node labeled `A` |
| Completed streaming label | Full label appears as ordinary text, including `$$` | Same | Same |

“Raw TeX” therefore needs a qualification: these renderers do **not promise a verbatim TeX transport**. Their normal line-break, Markdown, class-member and family parsing rules still apply. The `\nu`/`\nabla` example is especially concrete: successful rendering does not establish preservation of formula meaning.

Agentic's `verifyMermaid` on the complete fraction example returns `ok: true`, no warnings and checks `{renderability: 'passed', sourceLoss: 'not-detected', taskCorrectness: 'not-checked'}` (`verify-result.json`). This establishes the existing rendering contract, **not** mathematical correctness or mathematical typesetting. No math-specific warning or implementation was added by this research.

## Why the source produces these results

Beautiful's [normalizer](https://github.com/lukilabs/beautiful-mermaid/blob/2ac8bbbb060ca0a65a6a21f3200bd99b1587b488/src/multiline-utils.ts#L16) converts `\n`, HTML breaks and Markdown-lite emphasis; its [writer](https://github.com/lukilabs/beautiful-mermaid/blob/2ac8bbbb060ca0a65a6a21f3200bd99b1587b488/src/multiline-utils.ts#L154) emits escaped `<text>` and `<tspan>`. Its [public dispatch](https://github.com/lukilabs/beautiful-mermaid/blob/2ac8bbbb060ca0a65a6a21f3200bd99b1587b488/src/index.ts#L111) chooses diagram parsers/layout/writers, not a TeX renderer.

Zombie's [normalizer](https://github.com/dfadler/zombie-mermaid/blob/507a2263b8cc181dff18dd61ddd95eeb15d7169c/packages/core/src/multiline-utils.ts#L17) and [text writer](https://github.com/dfadler/zombie-mermaid/blob/507a2263b8cc181dff18dd61ddd95eeb15d7169c/packages/core/src/multiline-utils.ts#L271) follow the same text model, with additional entity/Markdown handling. No math span or typesetter was found in the inspected parser/core/renderer/config paths. Its [optional Inter subset loader](https://github.com/dfadler/zombie-mermaid/blob/507a2263b8cc181dff18dd61ddd95eeb15d7169c/packages/svg-renderer/src/embedded-font.ts#L9) embeds ordinary font data; embedding Inter does not turn TeX commands into mathematical layout.

Agentic's [normalizer](https://github.com/adewale/agentic-mermaid/blob/83744a4e1ae5c9d3821ba8a283811367fd31eade/src/multiline-utils.ts#L22) and [prepared display runs](https://github.com/adewale/agentic-mermaid/blob/83744a4e1ae5c9d3821ba8a283811367fd31eade/src/shared/display-text.ts#L143) own ordinary display interpretation. There is no math span/typesetter in this inspected path. The repository has a KaTeX **override** for its wider dependency graph; that is not a native math rendering feature or a runtime import in this pipeline.

## PNG and fonts

- Beautiful's checked package exposes SVG and terminal rendering, not a PNG renderer or CLI. A downstream rasterizer would rasterize its existing text SVG; it would not discover and typeset TeX by itself. No downstream Beautiful rasterizer was executed here.
- Agentic's public `renderMermaidPNG` is on `agentic-mermaid/agent` (not the root entry used for the SVG probe). It rasterizes the graphical projection through resvg with bundled/caller font selection. The fraction probe produced a 5,117-byte PNG, visually inspected: the node says `$$\frac{a}{b}$$`, not a fraction. Source: [PNG entry](https://github.com/adewale/agentic-mermaid/blob/83744a4e1ae5c9d3821ba8a283811367fd31eade/src/agent/png.ts#L143).
- Zombie's [CLI PNG adapter](https://github.com/dfadler/zombie-mermaid/blob/507a2263b8cc181dff18dd61ddd95eeb15d7169c/src/cli/png.ts#L19) uses its optional resvg dependency. The installed CLI produced a 2,217-byte PNG, visually inspected: it too shows the TeX text. This is a CLI capability, even though the root library exports no `renderMermaidPNG` function.

Unicode notation is a useful existing text capability, not a replacement for fractions, matrices, stretchy delimiters or mathematical alignment. Ordinary SVG fonts, embedded subsets, terminal glyph coverage and PNG fallback fonts affect which Unicode glyphs appear, but none of these three forks gains a math engine by choosing a font.

## Markdown and streaming are host responsibilities

The raw renderer APIs accept Mermaid source, not a Markdown document. Agentic additionally has a static `render-markdown` command, and the candidate's `verify --markdown` checks extracted Mermaid fences; neither typesets standalone Markdown math. A host may use a separate Markdown math plugin, but that does not make formulas inside an SVG label work.

The incomplete-input result is a batch-render snapshot, **not a benchmark or a supported streaming-session contract**. Neither the error nor the provisional `A` drawing owns chunk completion, preserving a last good artifact or cancellation. A Streamdown-like host must decide when to render and how to present incomplete content. Mathematical syntax is only one part of that workflow.

For users migrating formula-heavy Mermaid documents, all three forks have the same broad limitation in these probes: replacing Mermaid with one of them changes a typeset formula into text, and some TeX sequences also interact with ordinary label escapes. This explains the migration concern without proposing or implementing math support.
