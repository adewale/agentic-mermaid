import sys,json,pathlib
root=pathlib.Path('/workspace/.cloud-setup/math-derivatives-comparison-2026-10-30')
sys.path.insert(0,str(root/'fasouto__termaid/source/src'))
from termaid import render
labels=[r'$$x^2$$',r'cost $$\frac{a}{b}$$ units',r'$$\unknown{z}$$',r'$$x^2']
rows=[]
for label in labels:
 for use_ascii in [False,True]:
  source='flowchart LR\nA["'+label+'"]'
  try:rows.append({'label':label,'useAscii':use_ascii,'output':render(source,use_ascii=use_ascii,max_label_width=80)})
  except Exception as e:rows.append({'label':label,'useAscii':use_ascii,'error':repr(e)})
json.dump({'version':'0.10.0','sha':'78a6f312c4ffeda8b1e20be3887a4f2be1ebf026','rows':rows},open(root/'termaid-results.json','w'),indent=2)
for row in rows:print(json.dumps(row))
