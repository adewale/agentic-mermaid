import { chromium } from '/workspace/agentic-mermaid/node_modules/playwright/index.mjs'
import { renderMermaidSVG } from '/workspace/agentic-mermaid/src/index.ts'
import { writeFileSync } from 'node:fs'
const out='/workspace/.cloud-setup/upstream-implementation-2026-10-30/accessibility'
const source='flowchart LR\n A[Start] -->|next| B[Finish]'
const variants=[{name:'default',svg:renderMermaidSVG(source,{security:'strict'})},{name:'explicit-high-contrast',svg:renderMermaidSVG(source,{security:'strict',style:'accessible-high-contrast'})}]
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']})
const rows:any[]=[]
try{
 for(const media of [{name:'normal',forcedColors:'none',contrast:'no-preference'},{name:'more',forcedColors:'none',contrast:'more'},{name:'forced',forcedColors:'active',contrast:'no-preference'}]){
  const page=await browser.newPage({viewport:{width:1000,height:700}})
  let externalRequests=0
  await page.route('**/*',route=>{externalRequests++;return route.abort()})
  await page.emulateMedia({forcedColors:media.forcedColors as any,contrast:media.contrast as any})
  for(const v of variants){
   await page.setContent(`<body style="margin:20px;background:white"><h1>${media.name} / ${v.name}</h1><div id="inline">${v.svg}</div><img id="image" src="data:image/svg+xml;base64,${Buffer.from(v.svg).toString('base64')}" /></body>`)
   await page.locator('#image').evaluate((image:any)=>image.decode())
   const observed=await page.evaluate(()=>{
    const image=document.querySelector('#image') as HTMLImageElement
    const canvas=document.createElement('canvas');canvas.width=image.naturalWidth;canvas.height=image.naturalHeight
    const ctx=canvas.getContext('2d')!;ctx.drawImage(image,0,0)
    const data=ctx.getImageData(0,0,canvas.width,canvas.height).data
    const counts=new Map<string,number>()
    for(let i=0;i<data.length;i+=4){if(data[i+3]===0)continue;const key=[data[i],data[i+1],data[i+2],data[i+3]].join(',');counts.set(key,(counts.get(key)??0)+1)}
    const svg=document.querySelector('#inline svg')!
    const connector=svg.querySelector('path[marker-end],polyline[marker-end],line[marker-end]')
    const text=svg.querySelector('text')!
    return{matches:{forced:matchMedia('(forced-colors: active)').matches,more:matchMedia('(prefers-contrast: more)').matches},inline:{textFill:getComputedStyle(text).fill,connectorStroke:connector?getComputedStyle(connector).stroke:null,connectorWidth:connector?getComputedStyle(connector).strokeWidth:null},image:{width:canvas.width,height:canvas.height,colors:[...counts].sort((a,b)=>b[1]-a[1]).slice(0,7)}}
   })
   rows.push({media:media.name,variant:v.name,externalRequests,...observed})
   await page.screenshot({path:`${out}/${media.name}-${v.name}.png`})
  }
  await page.close()
 }
 writeFileSync(`${out}/results.json`,JSON.stringify({browser:browser.version(),platform:process.platform,scope:'Chromium media emulation on Linux; not a real Windows High Contrast or assistive-technology audit',rows},null,2))
 console.log(JSON.stringify(rows.map(r=>({media:r.media,variant:r.variant,matches:r.matches,inline:r.inline,externalRequests:r.externalRequests})),null,2))
}finally{await browser.close()}
