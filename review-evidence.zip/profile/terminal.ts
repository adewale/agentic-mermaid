import { readFileSync, writeFileSync } from 'node:fs'
import { renderMermaidASCIIWithReceipt } from '/workspace/agentic-mermaid/src/index.ts'
const out='/workspace/.cloud-setup/upstream-implementation-2026-10-30/profile'
function runTerminal(source:string){const r=renderMermaidASCIIWithReceipt(source,{colorMode:'none'});return{text:r.text,receipt:JSON.stringify(r.receipt)}}
const rows:any[]=[]
for(const fixture of ['flowchart-basic','fan-in-fan-out','cyclic-labelled-15-chains','cyclic-labelled-18-cuts']){
 const source=readFileSync(`/workspace/agentic-mermaid/eval/layout-compare/fixtures/${fixture}.mmd`,'utf8')
 let first:ReturnType<typeof runTerminal>|undefined
 for(let round=0;round<3;round++){
  const started=performance.now()
  try{const r=runTerminal(source);first??=r;rows.push({fixture,round,ms:performance.now()-started,status:'rendered',sameText:r.text===first.text,sameReceipt:r.receipt===first.receipt,characters:r.text.length})}
  catch(e){rows.push({fixture,round,status:'refused',error:String(e)})}
 }
}
writeFileSync(`${out}/terminal-results.json`,JSON.stringify({kind:'diagnostic source attribution; no speed comparison',rows},null,2))
console.log(JSON.stringify(rows))
