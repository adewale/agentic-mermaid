import { readFileSync, writeFileSync } from 'node:fs'
import { renderMermaidSVGWithReceipt } from '/workspace/agentic-mermaid/src/index.ts'
import { LAYOUT_PIPELINE } from '/workspace/agentic-mermaid/src/layout-engine.ts'
import { withRenderStageObserver } from '/workspace/agentic-mermaid/src/render-stages.ts'
import { withPerformanceExperiments, PERFORMANCE_EXPERIMENTS } from '/workspace/agentic-mermaid/src/experimental-performance.ts'
const root='/workspace/agentic-mermaid'
const out='/workspace/.cloud-setup/upstream-implementation-2026-10-30/profile'
const rows:any[]=[]
const passTotals=new Map<string,{calls:number,ms:number}>()
const originals=LAYOUT_PIPELINE.map(pass=>pass.run)
const fixtures=['flowchart-basic','fan-in-fan-out','cyclic-labelled-15-chains','cyclic-labelled-18-cuts']
for(const fixture of fixtures)for(const style of [undefined,'publication-figure']){
 const source=readFileSync(`${root}/eval/layout-compare/fixtures/${fixture}.mmd`,'utf8')
 const options=style?{style}:{}
 let baseline:any
 try{baseline=withPerformanceExperiments(PERFORMANCE_EXPERIMENTS.filter(f=>f!=='position-cache'),()=>{const r=renderMermaidSVGWithReceipt(source,options);return{svg:r.svg,receipt:JSON.stringify(r.receipt)}})}catch(e){rows.push({fixture,style,status:'baseline-refused',error:String(e)});continue}
 for(const mode of ['uncached','cached'] as const)for(let round=0;round<2;round++){
  const passes:any[]=[];const stages:any[]=[]
  LAYOUT_PIPELINE.forEach((pass,i)=>{pass.run=ctx=>{const start=performance.now();try{return originals[i]!(ctx)}finally{passes.push({id:pass.id,ms:performance.now()-start})}}})
  const started=performance.now()
  try{
   const rendered=withPerformanceExperiments(mode==='uncached'?PERFORMANCE_EXPERIMENTS.filter(f=>f!=='position-cache'):PERFORMANCE_EXPERIMENTS,()=>withRenderStageObserver(s=>stages.push(s),()=>{const r=renderMermaidSVGWithReceipt(source,options);return{svg:r.svg,receipt:JSON.stringify(r.receipt)}}))
   rows.push({fixture,style,mode,round,ms:performance.now()-started,status:'rendered',sameSvg:rendered.svg===baseline.svg,sameReceipt:rendered.receipt===baseline.receipt,stages,passes})
   for(const p of passes){const prior=passTotals.get(p.id)??{calls:0,ms:0};prior.calls++;prior.ms+=p.ms;passTotals.set(p.id,prior)}
  }catch(e){rows.push({fixture,style,mode,round,status:'refused',error:String(e)})}
  finally{LAYOUT_PIPELINE.forEach((pass,i)=>{pass.run=originals[i]!})}
  writeFileSync(`${out}/results.json`,JSON.stringify({kind:'diagnostic source attribution; not a release performance comparison',source:'83744a4e plus working numeric/text/discovery/Markdown changes',pipeline:LAYOUT_PIPELINE.map(p=>({id:p.id,after:p.after,mutates:p.mutates,proposal:p.proposal,freezesNodes:p.freezesNodes})),rows,passTotals:[...passTotals].map(([id,v])=>({id,...v})).sort((a,b)=>b.ms-a.ms)},null,2))
 }
 console.log(JSON.stringify({fixture,style,rows:rows.length}))
}
