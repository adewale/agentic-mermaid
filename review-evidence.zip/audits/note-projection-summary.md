# Private operation-note delivery repair

Changes are limited to `scripts/build/runtime-render-contract.ts` and
`src/__tests__/browser-runtime-metadata-projection.test.ts`; no minifier,
ceiling, glyph, wrapping or layout changes were made by this agent.

The private editor accepts mutation operations but does not expose the SDK's
operation-discovery API. Its bundle retained literal `withNote` discovery prose
from the shared shape-validation tables. Only when both existing
`sourceOnlySceneAdmission` and `!schemaDocumentation` are selected, the build
now projects literal annotation calls onto a spread copy of their original spec.
This preserves property-getter evaluation, copying and all admission fields.
Dynamic note expressions remain original calls, preserving argument order,
coercion and throws. The exact pure annotation-helper shape is checked before
any transform; changed semantics fail the build. Public Node/default browser
and documentation-enabled builds retain their discovery notes.

Actual full standalone editor rebuilt after the Unicode graph-caption repair:

| Metric | Actual | Unchanged cap | Headroom |
|---|---:|---:|---:|
| Raw HTML bytes | 4,732,168 | 4,736,000 | 3,832 |
| gzip level9 bytes | 1,419,646 | 1,421,000 | 1,354 |

Eleven tests pass across the existing metadata-projection and runtime-minify
suites. New cases check four scope combinations (public notes retained), twelve
accepted/rejected mutations covering required fields, primitive types, enums,
nullability and omitted defaults, exact public/private validation diagnostics,
spread getters, dynamic-note evaluation order and throws, and refusal of a
helper with added effects. `git diff --check` is clean.

The ordinary SWC and Bun syntax variants explored in scratch did not meet both
caps and were not adopted. Final source/CI qualification remains with the root
agent; no commits or push were performed here.

## Final committed head

The implementation is committed in PR #590 at **`d6b830e8608b2e07b99ed2861559bcdfeb07daef`**. The existing metadata/minifier suites were independently rerun at that head: **11 pass, 0 fail, 276 assertions**. The private projection remains limited to `sourceOnlySceneAdmission && !schemaDocumentation`; public features, minifier settings and both payload ceilings remain intact. The byte counts above are the measured pre-rebase editor generation with the Unicode repair included, not a claim that a historical generated file was rebuilt from the rebased head. Root is regenerating and qualifying the final delivery artifact.
