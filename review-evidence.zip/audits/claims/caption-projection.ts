import assert from 'node:assert/strict'
import {writeFileSync} from 'node:fs'
import {parseRegisteredMermaid,asFlowchart,serializeMermaid,layoutMermaid,renderMermaidSVG} from '/workspace/agentic-mermaid/src/agent/index.ts'
import {withPerformanceObserver} from '/workspace/agentic-mermaid/src/performance-observations.ts'
import {withPerformanceExperiments,PERFORMANCE_EXPERIMENTS} from '/workspace/agentic-mermaid/src/experimental-performance.ts'
import {layoutGraphSync} from '/workspace/agentic-mermaid/src/layout-engine.ts'
import {createTextMeasurementExecution,withTextMeasurementExecution} from '/workspace/agentic-mermaid/src/text-measurement-profile.ts'
import {auditRenderedRoutes} from '/workspace/agentic-mermaid/src/agent/rendered-route-audit.ts'
const variants=[['hint','flowchart LR\nCaptionCacheA -->|<b>\u00ad\u200b</b>| CaptionCacheB'],['plain','flowchart LR\nCaptionCacheA --> CaptionCacheB']]
const parsed=variants.map(([id,source])=>{const p=parseRegisteredMermaid(source);assert.ok(p.ok);return{id,source,p:p.value,before:structuredClone(p.value),serialized:serializeMermaid(p.value)}})
const rows=[]
for(const backend of ['agentic','elk'])for(const style of [undefined,'publication-figure'])for(const cached of [false,true]){
 const experiments=cached?PERFORMANCE_EXPERIMENTS:PERFORMANCE_EXPERIMENTS.filter(x=>x!=='position-cache')
 const observations=[]
 const outputs=new Map()
 withPerformanceExperiments(experiments,()=>withPerformanceObserver(o=>observations.push(o),()=>{
  for(let round=0;round<2;round++)for(const v of parsed){
   const options={graphLayout:{backend,fallback:'none'},...(style?{style}:{})}
   const layout=layoutMermaid(v.p,options)
   assert.equal(layout.edges[0].label,undefined)
   assert.deepEqual(auditRenderedRoutes(layout),[])
   const svg=renderMermaidSVG(v.p,options)
   assert.ok(!svg.includes('class="edge-label"'))
   assert.deepEqual(v.p,v.before)
   assert.equal(serializeMermaid(v.p),v.serialized)
   const previous=outputs.get(v.id)
   if(previous)assert.equal(svg,previous)
   outputs.set(v.id,svg)
  }
 }))
 rows.push({backend,style,cached,cacheObservations:observations.filter(o=>o.kind==='cache'&&o.owner==='positioned-layout')})
}
const visible=parseRegisteredMermaid('flowchart LR\nA -->|v\u00ad\u200b| B');assert.ok(visible.ok)
const graph=asFlowchart(visible.value).body.graph
const before=structuredClone(graph)
const execution=createTextMeasurementExecution({id:'audit:visible-zero-advance',version:'1.0.0',measure:()=>0},'Inter')
const custom=[]
for(const backend of ['agentic','elk']){
 const positioned=withTextMeasurementExecution(execution,()=>layoutGraphSync(graph,{graphLayout:{backend,fallback:'none'}}))
 const edge=positioned.edges[0]
 assert.equal(edge.label,'v\u00ad\u200b')
 assert.ok(edge.labelPosition)
 assert.ok(edge.labelBlock.lineBlocks.some(line=>line.runs.some(run=>run.text==='v')))
 assert.deepEqual(graph,before)
 custom.push({backend,label:edge.label,width:edge.labelBlock.width,lines:edge.labelBlock.lines})
}
writeFileSync('/workspace/.cloud-setup/upstream-audit-2026-10-30/claims/caption-projection-d6b830e8.json',JSON.stringify({head:'d6b830e8608b2e07b99ed2861559bcdfeb07daef',rows,custom},null,2))
console.log('Caption COW/source/cold-warm cache controls and visible zero-advance controls pass for both producers.')
