import {renderResolvedScene} from '/workspace/agentic-mermaid/src/index.ts'
import {describeSdkPayload} from '/workspace/agentic-mermaid/src/mcp/sdk-discovery.ts'
import {writeFileSync} from 'node:fs'
import assert from 'node:assert/strict'
const scene=renderResolvedScene('flowchart LR\nA-->B')
const marker=scene.parts.flatMap(part=>part.primitives.map(primitive=>({partId:part.id,...primitive}))).find(primitive=>primitive.kind==='path'&&primitive.marker)
const discovery=describeSdkPayload({capability:'resolved-scene'})
assert.equal(discovery.coordinates,'primitive-local')
assert.equal(discovery.matrix,'local-to-root-user-space')
assert.ok(marker && marker.kind==='path' && marker.matrix[4] !== 0 && marker.matrix[5] !== 0)
const result={head:'d6b830e8608b2e07b99ed2861559bcdfeb07daef',advertisedCoordinates:discovery.coordinates,advertisedMatrix:discovery.matrix,marker}
writeFileSync('/workspace/.cloud-setup/upstream-audit-2026-10-30/claims/discovery-coordinates-d6b830e8.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result))
