import {readFileSync,writeFileSync} from 'node:fs'
import assert from 'node:assert/strict'
import {executeInSandbox} from '/workspace/agentic-mermaid/src/mcp/sandbox.ts'
const text=readFileSync('/workspace/agentic-mermaid/docs/api.md','utf8')
const section=text.slice(text.indexOf('Pass this JavaScript body to Code Mode'))
const body=/^```js\s*\n([\s\S]*?)^```/m.exec(section)?.[1]
assert.ok(body,'Code Mode example must be a JavaScript body')
const result=await executeInSandbox(body,{trace:true})
assert.equal(result.ok,true,JSON.stringify(result))
assert.equal((result.value as any).version,2)
assert.equal((result.value as any).parts.length,3)
assert.ok((result.value as any).parts.every((p:any)=>typeof p.id==='string'&&p.primitives.length>0))
const refusal=await executeInSandbox(body.replace('renderResolvedScene(source)','renderResolvedScene(source, {shadow:true})'))
assert.equal(refusal.ok,true,JSON.stringify(refusal))
const {message,...fields}=refusal.value as any
assert.deepEqual(fields,{ok:false,code:'RESOLVED_SCENE_UNSUPPORTED_ARTWORK',partId:'node:A',feature:'filter'})
assert.match(message,/node:A.*filter/)
writeFileSync('/workspace/.cloud-setup/upstream-audit-2026-10-30/claims/documented-code-mode-d6b830e8.json',JSON.stringify({head:'d6b830e8608b2e07b99ed2861559bcdfeb07daef',body,result,refusal},null,2))
console.log('Documented JavaScript body executes through the actual executeInSandbox; success returns three parts and refusal returns typed fields.')
