import {build} from '/workspace/agentic-mermaid/node_modules/esbuild/lib/main.js'
import {runtimeRenderContractPlugin} from '/workspace/agentic-mermaid/scripts/build/runtime-render-contract.ts'
import {writeFileSync} from 'node:fs'
import assert from 'node:assert/strict'
const source="export {describeOps,validateOp,admitOpRecord} from './src/agent/op-schema.ts'"
const userText='Keep this note: $$x^2$$; literal prose, withNote and <tag>; \u00ad\u200b'
const cases=[
 {family:'state',op:{kind:'add_note',target:'A',text:userText},accepted:true},
 {family:'state',op:{kind:'set_note_text',index:0,text:userText},accepted:true},
 {family:'state',op:{kind:'add_floating_note',id:'N',text:userText,parent:null},accepted:true},
 {family:'state',op:{kind:'add_note',target:'A',text:userText,side:'up'},accepted:false},
 {family:'state',op:{kind:'add_note',target:'A',text:userText,note:'unknown user field'},accepted:false},
 {family:'state',op:{kind:'add_note',target:'A',text:{note:'not string'}},accepted:false},
 {family:'class',op:{kind:'add_note',text:userText},accepted:true},
]
const outputs=[]
for(const options of [{},{schemaDocumentation:false},{sourceOnlySceneAdmission:true},{schemaDocumentation:false,sourceOnlySceneAdmission:true}]){
 const result=await build({stdin:{contents:source,resolveDir:'/workspace/agentic-mermaid',loader:'ts'},platform:'node',format:'esm',bundle:true,write:false,plugins:[runtimeRenderContractPlugin(options)]})
 const api=await import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString('base64')}`)
 const publicNote=api.describeOps('state').remove_state.find((f:any)=>f.name==='recursive').note
 if(options.schemaDocumentation===false&&options.sourceOnlySceneAdmission)assert.equal(publicNote,undefined)
 else assert.match(publicNote,/refuse a non-empty composite/)
 const observations=cases.map(({family,op,accepted})=>{
  const before=structuredClone(op)
  const admission=api.admitOpRecord(op)
  assert.equal(admission.ok,true)
  assert.deepEqual(JSON.parse(JSON.stringify(admission.value)),before)
  assert.deepEqual(op,before)
  const verdict=api.validateOp(family,op)
  assert.equal(verdict===null,accepted,JSON.stringify({family,op,verdict}))
  return {admission,verdict}
 })
 outputs.push({options,publicNote,observations})
}
for(const output of outputs.slice(1))assert.deepEqual(output.observations,outputs[0].observations)
writeFileSync('/workspace/.cloud-setup/upstream-audit-2026-10-30/claims/private-note-projection.json',JSON.stringify({head:'d6b830e8608b2e07b99ed2861559bcdfeb07daef',userText,outputs},null,2))
console.log('Private note projection: four option combinations preserve user note content and admission/validation; public discovery prose retained.')
