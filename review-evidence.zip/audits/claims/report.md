# Adversarial claims audit

Reviewed candidate `5ec6ceb567cba50d0d17d6e1643a63a5ff01e85e` against main `4c72d1c8`, 30 October 2026. Read the integrated math report, upstream lessons, project index, API/style documentation, relevant discovery/error source and full change inventory. No repository edits.

## Finding

### P2 — new discovery metadata misidentifies primitive coordinates (resolved)

`src/scene/resolved-types.ts:84` advertises `coordinates: 'root-user-space'`. Public resolved primitives retain **local** coordinates and a matrix mapping them to root space. This distinction matters to the new machine-discovery consumer: interpreting `d`/`x`/`y` directly in root space misplaces actual artwork.

Concrete public example: `renderResolvedScene('flowchart LR\nA-->B')` returns an arrowhead path `M0 0L8 2.5L0 5Z` and matrix `[1,0,0,1,140,55.95]`, while `describeSdkPayload({capability:'resolved-scene'})` advertises root-user-space. Ignoring the matrix draws this marker around the origin rather than at its owned edge endpoint.

`docs/api.md` already accurately explains local geometry/paint units plus the root transform. Make discovery equally explicit, for example `coordinates:'primitive-local'` and `matrix:'local-to-root-user-space'`. This is a metadata correction; it does not require flattening paths or changing primitive/version semantics.

Reproduction and output: `discovery-coordinates.ts`, `discovery-coordinates.json` beside this report.

## Checked claims with no additional finding

- Beautiful/Agentic/Zombie report correctly distinguishes executed package versions from independently inspected source commits and labels 72 attempts rather than 72 successes. The historical Agentic0.5.4 tarball is not misrepresented as current0.5.5. Formula, mixed prose, invalid command, unmatched delimiter, nu/nabla newline interpretation and batch incomplete-input observations agree with retained actual outputs. The report does not equate `verifyMermaid.ok` with typesetting or task correctness.
- Independently re-read Mermaid's pinned math docs/common helper: Flowchart/Sequence scope, lazy KaTeX, default MathML, legacy stylesheet requirement, browser measurement, throwOnError and tiny-build limits agree with the prose. Upstream issue measurements are identified as unrerun reports.
- Independently re-read Merman's pinned math abstraction/Cargo feature and ADR0097: optional pure-Rust backend and explicit artifact/feature boundary match the report. The text does not turn authored paint-audit findings into independently rerun binary evidence.
- Independently re-read streamdown-pele's adapter and lock: `renderOptions` are forwarded and the lock selects1.6.0 under^1.6.0; the report correctly makes newer math support conditional on actual installed Pele and callback.
- Independently re-read Excalidraw's actual adapter options/dependency and flowchart label conversion: pinned Pele1.8.0 is used without a resolver, converted labels are plain decoded text, and other families use resolver-free render options. The report does not claim actual canvas export tests.
- Independently re-read mermaid-rs-renderer's math normalizer and actual-SVG authored test: scalar superscripts, plain fractions/radicals, unknown-command backslash removal and unmatched delimiter handling match the report. “Approximation” is correctly separated from raw literal transport and full typesetting.
- API docs accurately retain the distinction between Scene part IDs and source node IDs; new typed artwork refusal errors and uncaught execute text envelopes are distinguished. Runtime neutrality was exercised through actual installed browser/worker entry in prior evidence rather than asserted from absence of direct Node imports alone.
- Routing report is explicitly pre-rebase diagnostic attribution, with output/receipt controls, profiler/startup limits and no speedup/reorder claim. Contrast claims identify Chromium emulation and exclude real Windows/assistive-technology validation. Markdown docs scope extraction to top-level fences and disclose nested-container limits.

## Publication/readiness checks for root

The maintained reports name files such as `results.json`, `current-agentic.json`, `termaid-results.json` and package identity snapshots. They are session artifacts, not files under docs/project. Their provenance remains reviewable only if the PR's evidence attachment/archive actually contains and locates them. This is a final-description/evidence checklist item while root prepares the upload, not a demonstrated missing-artifact finding against an existing PR.

The comparison explicitly excludes four preliminary-discovery projects and is not a census of all Mermaid derivatives. Keep that limit visible rather than expanding “all others” into an unsupported universal claim.

## Limits

No native math engine, foreign browser math exporter, new Windows high-contrast session or additional arbitrary TeX corpus was executed during this audit. Spot-checks of source-only derivative rows validate their stated mechanism, not every backend or published artifact. This audit covers wording/provenance/discovery meaning; it is not a full implementation/security/performance audit of all source changes.

## Final replay — finding resolved

At final candidate `70842c1c18c071f5b098be836956fb62da33fac6`, the public proof returns `coordinates:'primitive-local'` and `matrix:'local-to-root-user-space'`. The actual local marker path and its nonidentity translation remain unchanged. The metadata now describes the emitted representation accurately. The owning discovery test also passes with both explicit semantics. Exact replay output is `discovery-coordinates-70842c1c.json`; its focused test log is `coordinates-test-70842c1c.log`. No claims findings remain open.

Read the draft `/workspace/.cloud-setup/upstream-pr-2026-10-30/pr-body.md` at this revision. Its problem/result descriptions, comparison scope, repaired-audit findings and explicit earlier-candidate/final-CI separation match the evidence. In particular, the whole `origin/main...HEAD` changed-file inventory contains no geometry/reference/golden/image baseline repins, so that risk statement is accurate for the complete PR, not merely the follow-up commits. Evidence-upload and final-CI prose is explicitly provisional and must be replaced with the actual results/links before readiness; these draft placeholders are not reported as defects. No new demonstrated inaccuracies were found.

## Combined-candidate replay — d6b830e8608b2e07b99ed2861559bcdfeb07daef

Replayed the public coordinate proof, hint-caption source/cache/custom-zero-advance controls and actual documented JavaScript Code Mode body at this exact committed candidate (main base5f76). All pass, with no new demonstrated claims/caption finding. Final replay JSON/log files use suffix`-d6b830e8`. The caption check still records separate authored-source cache misses followed by successful hits, without input graph/serialized-source mutation; both producers retain visible zero-advance captions. The documented body returns three parts, and its filter-refusal branch returns typed fields through the real sandbox.

The newly added private mutation-schema prose projection was also independently spot-checked. Its loader is installed only when `sourceOnlySceneAdmission && !schemaDocumentation`. The exact pure `withNote(spec,note)=>({...spec,note})` helper is checked before projection, literal calls become fresh spread copies, and dynamic note arguments remain executable. Shape validation does not read the omitted `note` documentation property. Four compiled plugin-option combinations preserve admission/validation outcomes and caller note strings (including TeX, tag-like text and discretionary hints); public discovery notes remain intact unless both private flags are set. Existing new projection tests pass2cases/59assertions, including getter evaluation, dynamic throws and refusal of changed helper semantics. See`private-note-projection.json` and`private-note-projection-tests.log`.

No source files were edited by this reviewer. Installed canonical TypeScript replay on the final packed artifact remains pending until `qualified-pack.json` is available; the older14:39artifact is not treated as this head's package evidence.

## Final installed-artifact confirmation

Fresh qualified tarball `agentic-mermaid@0.5.5`, SHA1`a1d78bd889d170087f42a30304d8cd7b5724ee12`, built from production candidate`d6b830e8608b2e07b99ed2861559bcdfeb07daef`, was installed into a new consumer directory. All six canonical TypeScript examples from the actual API documentation compile using the existing e2e consumer gate's exact compiler flags and execute under Node24.19.0 with zero stderr. The documented JavaScript body matches the copy in the installed package and succeeds through its real stdio MCP`execute` tool, returning three parts. The same body with an explicit filter option exercises the catch and returns the documented typed error fields. The source`executeInSandbox` body check also passes at D6.

These are separate interface checks: the Code Mode function body is JavaScript with top-level return, while the canonical TypeScript examples remain standalone modules. No owning test or production source was weakened or edited by this reviewer. Evidence:`canonical-api-results-d6b830e8.json`, `installed-doc-code-mode-d6b830e8.json`, their logs and the qualified package metadata. This local consumer ran Node24, not Node22. No claims finding remains open.

Final PR head`ae46880e0779f0726ff9bf5b01bb216b6a578b41` differs from D6 only by a non-null assertion in `src/__tests__/browser-runtime-metadata-projection.test.ts`. Verified the complete revision delta: no production, documentation, dependency, package or build-script changes. The D6 production/artifact/source checks therefore apply to this final head's unchanged runtime and docs; CI qualification of the changed test remains root-owned.
