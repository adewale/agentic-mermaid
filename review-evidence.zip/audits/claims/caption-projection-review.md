# Pending hint-only caption projection audit

Reviewed the pending `src/layout-engine.ts` `graphWithDisplayCaptions` change after commit70842c1c (working tree), 30 October2026. No repository edits and no additional demonstrated finding.

## Hypotheses exercised

- Hint-only captions and unlabelled edges could share cached geometry while leaking source metadata between parsed diagrams.
- Clearing a projected label could mutate the authored input graph or retained labelContent.
- A custom font returning zero advance for visible text could cause that caption to be removed.
- Fixing the ELK producer could leave Agentic or styled rendering inconsistent.

`caption-projection.ts` alternates two separately parsed sources with the same nodes/endpoints: unlabelled and a bold SHY+ZWSP-only caption. It exercises Agentic and ELK, default and publication styles, with the position cache disabled/enabled, across two rounds of public layout and SVG calls. Parsed graph snapshots and serialized sources remain unchanged; labels produce no edge-label ink; route audits remain empty; repeated SVG is byte-stable. Each of the four cache-enabled arms records **2misses and6hits**, consistent with separate authored-source keys and successful warm reuse. Cache-disabled arms each record8bypasses.

A second direct-producer control provides trusted custom text metrics returning width0 for visible `v` beside unused hints. Both producers retain the caption, its positioned anchor and prepared visible line `v`, with width0. The projection uses display-run text presence, not zero metrics, to decide omission.

The source walk supports these observations. The full positioning key contains admitted source/options before layout projection. The helper copy-on-writes the graph's edge array and only the selected edge object; untouched input graph/node/maps remain caller-owned. Existing `resolveLabelContent` checks that content.value matches the current label, so a projected empty label does not reuse incompatible authored hint content. ELK extraction binds current authored edge metadata after any solver result reuse. The original graph is still checked by `assertMermaidGraphWork` before projection. Both producer paths enter the existing shared geometry/route certification pipeline without changing pass order or limits.

## Limits

This checks the stated cache/source/visible-zero-advance hypotheses and two producer/style controls, not every diagram family, authored style, custom callback side effect or cache eviction sequence. It does not benchmark the additional text-preparation probe or make a performance claim. Evidence is in `caption-projection.json` and `caption-projection.log`; owning property tests are maintained separately by the implementation agent.

## Combined-candidate replay — d6b830e8608b2e07b99ed2861559bcdfeb07daef

Replayed the public coordinate proof, hint-caption source/cache/custom-zero-advance controls and actual documented JavaScript Code Mode body at this exact committed candidate (main base5f76). All pass, with no new demonstrated claims/caption finding. Final replay JSON/log files use suffix`-d6b830e8`. The caption check still records separate authored-source cache misses followed by successful hits, without input graph/serialized-source mutation; both producers retain visible zero-advance captions. The documented body returns three parts, and its filter-refusal branch returns typed fields through the real sandbox.

The newly added private mutation-schema prose projection was also independently spot-checked. Its loader is installed only when `sourceOnlySceneAdmission && !schemaDocumentation`. The exact pure `withNote(spec,note)=>({...spec,note})` helper is checked before projection, literal calls become fresh spread copies, and dynamic note arguments remain executable. Shape validation does not read the omitted `note` documentation property. Four compiled plugin-option combinations preserve admission/validation outcomes and caller note strings (including TeX, tag-like text and discretionary hints); public discovery notes remain intact unless both private flags are set. Existing new projection tests pass2cases/59assertions, including getter evaluation, dynamic throws and refusal of changed helper semantics. See`private-note-projection.json` and`private-note-projection-tests.log`.

No source files were edited by this reviewer. Installed canonical TypeScript replay on the final packed artifact remains pending until `qualified-pack.json` is available; the older14:39artifact is not treated as this head's package evidence.

## Final installed-artifact confirmation

Fresh qualified tarball `agentic-mermaid@0.5.5`, SHA1`a1d78bd889d170087f42a30304d8cd7b5724ee12`, built from production candidate`d6b830e8608b2e07b99ed2861559bcdfeb07daef`, was installed into a new consumer directory. All six canonical TypeScript examples from the actual API documentation compile using the existing e2e consumer gate's exact compiler flags and execute under Node24.19.0 with zero stderr. The documented JavaScript body matches the copy in the installed package and succeeds through its real stdio MCP`execute` tool, returning three parts. The same body with an explicit filter option exercises the catch and returns the documented typed error fields. The source`executeInSandbox` body check also passes at D6.

These are separate interface checks: the Code Mode function body is JavaScript with top-level return, while the canonical TypeScript examples remain standalone modules. No owning test or production source was weakened or edited by this reviewer. Evidence:`canonical-api-results-d6b830e8.json`, `installed-doc-code-mode-d6b830e8.json`, their logs and the qualified package metadata. This local consumer ran Node24, not Node22. No claims finding remains open.

Final PR head`ae46880e0779f0726ff9bf5b01bb216b6a578b41` differs from D6 only by a non-null assertion in `src/__tests__/browser-runtime-metadata-projection.test.ts`. Verified the complete revision delta: no production, documentation, dependency, package or build-script changes. The D6 production/artifact/source checks therefore apply to this final head's unchanged runtime and docs; CI qualification of the changed test remains root-owned.
