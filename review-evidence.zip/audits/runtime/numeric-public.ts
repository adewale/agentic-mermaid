import {renderMermaidSVG,renderMermaidASCII} from '/workspace/agentic-mermaid/src/index.ts'
const plain=(x:number)=>{const s=String(x);if(!/[eE]/.test(s))return s;const [v,es]=s.split('e');const e=Number(es);const neg=v!.startsWith('-');const a=(neg?v!.slice(1):v!).split('.');const digits=a.join('');const pos=a[0]!.length+e;return (neg?'-':'')+(pos<=0?'0.'+'0'.repeat(-pos)+digits:pos>=digits.length?digits+'0'.repeat(pos-digits.length):digits.slice(0,pos)+'.'+digits.slice(pos))}
const rows:any[]=[]
for(const [min,max] of [[Number.MIN_VALUE,2*Number.MIN_VALUE],[1e-320,1e-319],[-1e308,1e308],[-Number.MAX_VALUE,Number.MAX_VALUE],[1e308,1e308*(1+2*Number.EPSILON)]]) for(const horizontal of [false,true])for(const numericX of [false,true]){
 const source=`xychart-beta${horizontal?' horizontal':''}\nx-axis ${numericX?`${plain(min!)} --> ${plain(max!)}`:'[A,B]'}\ny-axis ${plain(min!)} --> ${plain(max!)}\nline [${plain(min!)},${plain(max!)}]`
 const row:any={min,max,horizontal,numericX}
 for(const [name,render] of [['svg',renderMermaidSVG],['ascii',renderMermaidASCII]] as const)try{const text=render(source);row[name]={status:/NaN|Infinity/.test(text)?'nonfinite':'rendered',length:text.length}}catch(e){row[name]={error:String(e)}}
 rows.push(row)
}
console.log(JSON.stringify(rows,null,2))
