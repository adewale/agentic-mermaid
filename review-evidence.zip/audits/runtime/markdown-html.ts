import {mermaidMarkdownBlocks} from '/workspace/agentic-mermaid/src/cli/markdown.ts'
import {verifyMarkdownBlocks} from '/workspace/agentic-mermaid/src/cli/index.ts'
const source='<!--\n```mermaid\nnot a diagram\n```\n-->\n\n~~~mermaid\nflowchart LR\nA-->B\n~~~'
console.log(JSON.stringify({source,extracted:mermaidMarkdownBlocks(source),verified:verifyMarkdownBlocks(source)},null,2))
