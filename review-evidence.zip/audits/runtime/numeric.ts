import {linearTicks,getDataXValues} from '/workspace/agentic-mermaid/src/xychart/axis-utils.ts'
import {linearFraction} from '/workspace/agentic-mermaid/src/shared/linear-range.ts'
const buf=new ArrayBuffer(8),f=new Float64Array(buf),u=new BigUint64Array(buf)
function nextUp(x:number){if(x===0)return Number.MIN_VALUE;f[0]=x;u[0]!+=x>0?1n:-1n;return f[0]!}
const failures:any[]=[]
let count=0
const starts=[0,Number.MIN_VALUE,-Number.MIN_VALUE,Number.MAX_VALUE,-Number.MAX_VALUE,1,-1,...Array.from({length:616},(_,i)=>10**(i-308))]
for(const a of starts){
 for(const scale of [1+Number.EPSILON,1+4*Number.EPSILON,1.1,2,10]){
  let b=a===0?Number.MIN_VALUE:nextUp(a*scale)
  if(!Number.isFinite(b)||a===b)continue
  const min=Math.min(a,b),max=Math.max(a,b)
  try{
   const t=linearTicks(min,max),r=linearTicks(max,min)
   if(t.some((v,i)=>!Number.isFinite(v)||v<min||v>max||i>0&&v<=t[i-1]!)||JSON.stringify(r)!==JSON.stringify([...t].reverse()))failures.push({min,max,t,r})
   const v=getDataXValues({xAxis:{range:{min,max}},series:[]},7)
   if(v.some((x,i)=>!Number.isFinite(x)||x<min||x>max||i>0&&x<v[i-1]!))failures.push({min,max,v})
   for(const x of v){const q=linearFraction(x,min,max);if(!Number.isFinite(q)||q<0||q>1)failures.push({min,max,x,q})}
  }catch(error){failures.push({min,max,error:String(error)})}
  count++
 }
}
console.log(JSON.stringify({count,failures},null,2))
