import {verifyMermaid} from '/workspace/agentic-mermaid/src/agent/index.ts'
import {renderResolvedScene} from '/workspace/agentic-mermaid/src/index.ts'
const source='flowchart TD\nA["&"] -->|\u200b| B["&"]\nB --> C["&"]'
for(const backend of ['agentic','elk'] as const){
 const options={graphLayout:{backend,fallback:'none' as const}}
 const v=verifyMermaid(source,{renderOptions:options}),r=renderResolvedScene(source,options)
 console.log(JSON.stringify({backend,ok:v.ok,warnings:v.warnings,parts:r.parts.map(p=>p.id)}))
}
