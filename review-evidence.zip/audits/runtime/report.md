# Adversarial runtime audit

Candidate inspected: `354a9e97de5e125d2dec74fc2fd879b65bae8fb7` on base `4c72d1c8266a48c31a4ebc5f4f33a0eb0fe648a0`.
No repository edits were made by this reviewer.

## Confirmed P2 — HTML comments/raw blocks are treated as live Mermaid fences

Owner: `src/cli/markdown.ts:13-22`, consumed by both `verifyMarkdownBlocks` and `renderMarkdownBlocks` in CLI.

Input:

    <!--
    ```mermaid
    not a diagram
    ```
    -->

    ~~~mermaid
    flowchart LR
    A-->B
    ~~~

The extractor returns 2 blocks; verification reports UNKNOWN_HEADER at physical line 3 and fails even though the only CommonMark Mermaid fence is valid. Marked (already present in node_modules) independently classifies the first region as an `html` token and the second as a `code` token. `<pre>` and `<div>` raw blocks likewise produce false positives.

`markdown-html.json` contains extraction and verification output; `markdown-oracle.json` contains the independent Markdown token classifications.

This is introduced in the new verify mode; old render-markdown's raw regex already had the latent false positive. Fix at the shared extractor's Markdown-context boundary and extend its existing owner tests. Merely treating the comment example as a Mermaid parser special case would preserve the bad assumption.

Adjacent limitation: quote fences (`> ```mermaid`) and deeply nested list fences are not found. Source calls the implementation top-level, but docs currently promise every Mermaid fence. Either implement containers or explicitly narrow docs/help/PR claims and disclose that exclusion.

## Checks with no findings

- 40 public SVG/terminal renders spanning adjacent smallest subnormals, subnormal ranges, both finite extremes and near-offset-MAX domains, across vertical/horizontal and categorical/numeric x axes, all rendered without nonfinite content (`numeric-public.json`).
- 3,103 finite numeric domains ranging from subnormal to near-MAX, adjacent representable offsets, positive/negative/reversed axes. Ticks were finite, strictly ordered, bounded and reversed consistently; 7-sample interpolation and linear fractions remained finite/bounded (`numeric.json`). No huge tick-density/resource stress because that helper's production consumers use fixed bounded counts.
- 1,000 deterministic mixed-Unicode strings × styled/plain × 6 pixel/cell budgets. Authored visible content survived after discretionary markers and inserted hyphens were accounted for; resulting run spans stayed bounded (`text-properties.json`). Cases include combining marks, ZWJ emoji, CJK, multiple hints and formatting split across grapheme pieces.
- describe_sdk schema validates exactly one family/capability, rejects null/wrong enum values and unknown properties; both family operation and resolved capability discovery succeed (`schemas.txt`).
- Focused source suites cover Code Mode typed errors, local/hosted render policy and constructor escape controls, SDK discovery and terminal discretionary text (`focused.log`: 85 passing tests). Pixel metrics/preparation suites also pass (including custom measurement/style tests, `text-font-tests.log`).

This does not establish all Markdown grammar, all custom measurement profiles, universal font raster fidelity, all runtime admission budgets or every family/style's resolved primitive support. Those are not claimed by the probes.

## Repair replay — 50b51037298c09978580f8fd19b966df77f9d5a9

The original P2 is resolved. HTML comments and raw blocks no longer expose their fence-looking text to verification; the original report now yields one valid live diagram only.

The first repair at 5ec6ceb5 needed paragraph-boundary fixes for HTML custom tags after indented code, and for underline-looking text that was not a heading. These adjacent failures are resolved in 50b51037, as are empty ordered-list and blockquote boundaries. All 28 general HTML-context cases and all 38 bounded prefix cases agree with the independent CommonMark 0.31.2 AST on which Mermaid fences are top-level. The existing Markdown owning suite passes.

Marked and CommonMark disagree on two contexts (reference definitions immediately followed by custom tags, and an empty list marker followed by a custom tag). The audit used authoritative CommonMark behavior for final expectations rather than treating the Marked lexer as decisive. The temporary CommonMark dependency is installed only in this scratch audit directory; no production dependency was added.

Documentation/help now explicitly bound support to top-level fences and disclose nested-container extraction as host-owned. No further runtime findings remain from this review. This statement does not claim complete CommonMark conformance or support for nested fences.
