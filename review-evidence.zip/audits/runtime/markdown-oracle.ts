import {marked} from '/workspace/agentic-mermaid/node_modules/marked/lib/marked.esm.js'
import {mermaidMarkdownBlocks} from '/workspace/agentic-mermaid/src/cli/markdown.ts'
const examples={comment:'<!--\n```mermaid\nnot a diagram\n```\n-->\n\n~~~mermaid\nflowchart LR\nA-->B\n~~~',pre:'<pre>\n```mermaid\nnot a diagram\n```\n</pre>',htmlDiv:'<div>\n```mermaid\nnot a diagram\n```\n</div>',codeList:'- example:\n  ```mermaid\n  flowchart LR\n  A-->B\n  ```',quote:'> ```mermaid\n> flowchart LR\n> A-->B\n> ```'}
for(const [name,source] of Object.entries(examples)) console.log(JSON.stringify({name,extract:mermaidMarkdownBlocks(source),tokens:marked.lexer(source).map(t=>({type:t.type,lang:'lang' in t?t.lang:undefined,text:'text' in t?t.text:undefined}))},null,2))
