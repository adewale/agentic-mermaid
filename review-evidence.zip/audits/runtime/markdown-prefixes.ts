import commonmark from './oracle/node_modules/commonmark/dist/commonmark.js'
import {mermaidMarkdownBlocks} from '/workspace/agentic-mermaid/src/cli/markdown.ts'
const p=new commonmark.Parser()
const prefixes=['# heading','##\theading','heading\n===','heading\n-','***','- - -','___','---','    code','\tcode','=','====','--','-','+','*','1.','1)','- ','+ ','* ','1. ','1) ','>','> ','> quote','- item','1. item','Paragraph','Paragraph\n    continuation','Paragraph\n=','Paragraph\n--','Paragraph\n+','Paragraph\n>','Paragraph\n1.','[ref]: /url','[ref]: /url\n    "title"','```\ncode\n```']
const rows=prefixes.map(prefix=>{
 const source=prefix+'\n<widget>\n~~~mermaid\nnot a diagram\n~~~\n</widget>'
 const ast=p.parse(source),top=[];for(let c=ast.firstChild;c;c=c.next)top.push({type:c.type,info:c.info,literal:c.literal})
 const expected=top.filter(x=>x.type==='code_block'&&x.info==='mermaid').length
 const actual=mermaidMarkdownBlocks(source).length
 return{prefix,expected,actual,equal:expected===actual,top}
})
console.log(JSON.stringify({rows,mismatches:rows.filter(x=>!x.equal)},null,2))
