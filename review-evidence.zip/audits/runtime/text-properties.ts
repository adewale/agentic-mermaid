import {preparePixelText} from '/workspace/agentic-mermaid/src/shared/prepared-text.ts'
import {prepareCellText} from '/workspace/agentic-mermaid/src/ascii/prepared-text.ts'
const failures:any[]=[]
const tokens=['a','b','é','👩‍💻','界','e\u0301','\u00ad','\u200b']
let state=1831
const rnd=(n:number)=>{state=(Math.imul(state,1664525)+1013904223)|0;return(state>>>0)%n}
const strip=(s:string)=>s.replace(/[\u00ad\u200b]/g,'')
for(let i=0;i<1000;i++){
 let source=Array.from({length:2+rnd(12)},()=>tokens[rnd(tokens.length)]).join('')
 for(const styled of [false,true]){
  const actual=styled?source.split('').map((s,i)=>i%2?`<b>${s}</b>`:s).join(''):source
  for(const limit of [1,2,3,5,12,30]){
   try{
    const c=prepareCellText(actual,{maxWidth:limit,hyphenate:false,display:styled?'formatted':'literal'})
    // Authored soft hyphens insert '-' even with automatic hyphenation disabled.
    let visible=c.lines.join('')
    if(!visible.replaceAll('-','').includes(strip(source).replaceAll('-','')))failures.push({kind:'cell',actual,limit,lines:c.lines,source,breaks:c.breaks})
    const p=preparePixelText(actual,{fontSize:14,fontWeight:400,maxWidth:limit,display:styled?'formatted':'literal'})
    visible=p.lineBlocks.flatMap(l=>l.runs).map(r=>r.text).join('').replaceAll('-','')
    if(visible!==strip(source))failures.push({kind:'pixel',actual,limit,lines:p.lines,source,breaks:p.breaks})
    for(const run of p.lineBlocks.flatMap(l=>l.runs)){
     if(run.sourceStart<0||run.sourceEnd>actual.length||run.sourceStart>run.sourceEnd)failures.push({kind:'span',run,actual})
    }
   }catch(error){failures.push({source,actual,limit,error:String(error)})}
  }
 }
 if(failures.length>30)break
}
console.log(JSON.stringify({failures},null,2))
