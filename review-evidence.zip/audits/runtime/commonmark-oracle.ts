import commonmark from './oracle/node_modules/commonmark/dist/commonmark.js'
import {readFileSync} from 'node:fs'
import {mermaidMarkdownBlocks} from '/workspace/agentic-mermaid/src/cli/markdown.ts'
const p=new commonmark.Parser()
const rows=JSON.parse(readFileSync('/workspace/.cloud-setup/upstream-audit-2026-10-30/runtime/markdown-final.json','utf8')).rows.map(({name,source}:any)=>{
 const ast=p.parse(source),top=[];let child=ast.firstChild
 while(child){top.push({type:child.type,literal:child.literal,info:child.info});child=child.next}
 const expected=top.filter(x=>x.type==='code_block'&&x.info==='mermaid').map(x=>x.literal.replace(/\n$/,''))
 const actual=mermaidMarkdownBlocks(source).map(x=>x.source)
 return{name,source,expected,actual,equal:JSON.stringify(expected)===JSON.stringify(actual),top}
})
console.log(JSON.stringify({version:'commonmark0.31.2',rows,mismatches:rows.filter((x:any)=>!x.equal)},null,2))
