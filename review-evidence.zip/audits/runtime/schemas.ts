import {createDescribeSdkTool,describeSdkPayload} from '/workspace/agentic-mermaid/src/mcp/sdk-discovery.ts'
import {withClosedMcpInputSchema,validateMcpToolArguments} from '/workspace/agentic-mermaid/src/mcp/tool-surface.ts'
const tool=withClosedMcpInputSchema(createDescribeSdkTool())
const args=[{},{family:'flowchart'},{capability:'resolved-scene'},{family:'flowchart',capability:'resolved-scene'},{family:null},{capability:null},{family:'flowchart',detail:'fields',extra:1},{capability:'resolved-scene',detail:'signatures'},Object.create(null)]
console.log(args.map(value=>{const errors=validateMcpToolArguments(tool,value);let result;try{result=describeSdkPayload(value)}catch(e){result=String(e)};return{value,errors,result:typeof result==='object'?{ok:result.ok,capability:result.capability,family:result.family}:result}}))
