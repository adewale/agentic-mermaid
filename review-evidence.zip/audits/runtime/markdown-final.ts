import {marked} from '/workspace/agentic-mermaid/node_modules/marked/lib/marked.esm.js'
import {mermaidMarkdownBlocks} from '/workspace/agentic-mermaid/src/cli/markdown.ts'
const sample='~~~mermaid\nnot a diagram\n~~~'
const examples={
 equalsAtStart:`=\n<widget>\n${sample}\n</widget>`,equalsLongAtStart:`====\n<widget>\n${sample}\n</widget>`,twoDashAtStart:`--\n<widget>\n${sample}\n</widget>`,indentedContinuation:`Paragraph\n    code\n<widget>\n${sample}\n</widget>`,tabCode:`\tcode\n<widget>\n${sample}\n</widget>`,
 comment:`<!--\n${sample}\n-->`,pre:`<pre>\n${sample}\n</pre>`,div:`<div>\n${sample}\n</div>`,custom:`<widget>\n${sample}\n</widget>`,
 plainParagraph:`text\n<widget>\n${sample}\n</widget>`,heading:`# heading\n<widget>\n${sample}\n</widget>`,setext:`heading\n===\n<widget>\n${sample}\n</widget>`,thematic:`***\n<widget>\n${sample}\n</widget>`,
 indentedCode:`    code\n<widget>\n${sample}\n</widget>`,reference:`[ref]: /url\n<widget>\n${sample}\n</widget>`,emptyList:`-\n<widget>\n${sample}\n</widget>`,list:`- item\n<widget>\n${sample}\n</widget>`,blockquote:`> text\n<widget>\n${sample}\n</widget>`,
 uppercasePre:`<PRE class="test">\n${sample}\n</PRE>`,rawWhitespace:` <textarea\n>${sample}\n</textarea>`,inlineRaw:`<pre></pre>\n${sample}`,inlineComment:`<!-- done -->\n${sample}`,processing:`<?xml version="1.0"\n${sample}\n?>`,cdata:`<![CDATA[\n${sample}\n]]>`,declaration:`<!DOCTYPE html\n${sample}\n>`,
 customAttribute:`<custom-widget foo='bar' data-x=abc>\n${sample}\n</custom-widget>`,invalidCustom:`<custom-widget foo=>\n${sample}\n</custom-widget>`,invalidCustomWhitespace:`<custom-widget / >\n${sample}\n</custom-widget>`,
}
const rows=Object.entries(examples).map(([name,source])=>{const tokens=marked.lexer(source);const expected=tokens.filter(t=>t.type==='code'&&t.lang==='mermaid').map(t=>t.text);const actual=mermaidMarkdownBlocks(source).map(t=>t.source);return{name,source,expected,actual,equal:JSON.stringify(expected)===JSON.stringify(actual),tokens:tokens.map(t=>({type:t.type,text:'text' in t?t.text:undefined}))}})
console.log(JSON.stringify({rows,mismatches:rows.filter(r=>!r.equal)},null,2))
