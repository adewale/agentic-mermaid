import {marked} from '/workspace/agentic-mermaid/node_modules/marked/lib/marked.esm.js'
import {mermaidMarkdownBlocks} from './markdown-head.ts'
import {verifyMermaid} from '/workspace/agentic-mermaid/src/agent/core.ts'
import {writeFileSync} from 'node:fs'
const cases=[
 ['indented code then HTML', '    indented example\n<custom-widget>\n```mermaid\nnot a diagram\n```\n'],
 ['paragraph continuation then HTML', 'Paragraph\n    continuation\n<custom-widget>\n```mermaid\nflowchart LR\nA-->B\n```\n'],
]
const rows=cases.map(([name,markdown])=>{
const actual=mermaidMarkdownBlocks(markdown)
const tokens=marked.lexer(markdown,{gfm:false})
const expected=tokens.filter((x:any)=>x.type==='code'&&/^mermaid(?:\s|$)/i.test(x.lang??''))
return {name,markdown,actual,actualVerification:actual.map(x=>verifyMermaid(x.source)),expected,tokenKinds:tokens.map(x=>x.type)}
})
writeFileSync('/workspace/.cloud-setup/upstream-audit-2026-10-30/interfaces/minimal-results.json',JSON.stringify({head:'5ec6ceb567cba50d0d17d6e1643a63a5ff01e85e',rows},null,2))
console.log(rows.map(x=>({name:x.name,extracted:x.actual.length,expected:x.expected.length,verify:x.actualVerification.map(v=>v.ok)})))
