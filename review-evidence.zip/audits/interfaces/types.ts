import ts from '/workspace/agentic-mermaid/node_modules/typescript/lib/typescript.js'
import {SDK_CORE_DECLARATION} from '/workspace/agentic-mermaid/src/mcp/sdk-discovery.ts'
import {SDK_RESOLVED_SCENE_DECLARATIONS} from '/workspace/agentic-mermaid/src/mcp/generated/sdk-types.ts'
import {writeFileSync} from 'node:fs'
const file='/workspace/.cloud-setup/upstream-audit-2026-10-30/interfaces/combined-types.ts'
writeFileSync(file,`${SDK_CORE_DECLARATION}\n${SDK_RESOLVED_SCENE_DECLARATIONS}\nconst scene=mermaid.renderResolvedScene('flowchart LR\\nA-->B');\nconst primitive = scene.parts[0].primitives[0];\n`)
const program=ts.createProgram([file],{strict:true,noEmit:true,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.NodeNext,moduleResolution:ts.ModuleResolutionKind.NodeNext,skipLibCheck:true,types:[],lib:['lib.es2022.d.ts']})
const diags=ts.getPreEmitDiagnostics(program).map(d=>({code:d.code,message:ts.flattenDiagnosticMessageText(d.messageText,'\n'),line:d.file&&d.start!==undefined?d.file.getLineAndCharacterOfPosition(d.start).line+1:undefined}))
writeFileSync('/workspace/.cloud-setup/upstream-audit-2026-10-30/interfaces/combined-types-results.json',JSON.stringify(diags,null,2))
console.log(JSON.stringify(diags,null,2))
