import assert from 'node:assert/strict'
import {marked} from '/workspace/agentic-mermaid/node_modules/marked/lib/marked.esm.js'
import {mermaidMarkdownBlocks} from '/workspace/agentic-mermaid/src/cli/markdown.ts'
import {writeFileSync} from 'node:fs'
const cases=[
 ['indented code then HTML','    indented example\n<custom-widget>\n```mermaid\nnot a diagram\n```\n',0],
 ['tab-indented code then HTML','\tindented example\n<custom-widget>\n```mermaid\nnot a diagram\n```\n',0],
 ['paragraph indentation remains paragraph','Paragraph\n    continuation\n<custom-widget>\n```mermaid\nflowchart LR\nA-->B\n```\n',1],
]
const rows=[]
for(const [name,markdown,count] of cases){
 const actual=mermaidMarkdownBlocks(markdown as string)
 const expected=marked.lexer(markdown as string,{gfm:false}).filter((x:any)=>x.type==='code'&&/^mermaid(?:\s|$)/i.test(x.lang??''))
 assert.equal(actual.length,count);assert.equal(actual.length,expected.length)
 rows.push({name,actual,expected})
}
writeFileSync('/workspace/.cloud-setup/upstream-audit-2026-10-30/interfaces/final-markdown-results.json',JSON.stringify({revision:'70842c1c18c071f5b098be836956fb62da33fac6',rows},null,2))
console.log('Three Markdown ownership controls match independent lexer')
