import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
import {writeFileSync} from 'node:fs'
import {executeInSandbox} from '/workspace/agentic-mermaid/src/mcp/sandbox.ts'
import {createTracingMermaid} from '/workspace/agentic-mermaid/src/mcp/facade.ts'
import {HOSTED_CODE_MODE_HOST_POLICY} from '/workspace/agentic-mermaid/src/render-host-policy.ts'
import {createDescribeSdkTool,describeSdkPayload} from '/workspace/agentic-mermaid/src/mcp/sdk-discovery.ts'
import {validateMcpToolArguments} from '/workspace/agentic-mermaid/src/mcp/tool-surface.ts'
import {renderMermaidSVG,verifyNoExternalRefs} from '/workspace/agentic-mermaid/src/index.ts'
const cases=[
 ['nested immutable result',`const s=mermaid.renderResolvedScene('flowchart LR\\nA-->B');let blocked=0;for(const f of [()=>s.parts[0].id='x',()=>s.parts.push({}),()=>s.parts[0].primitives[0].paint.fill='#bad',()=>s.parts[0].primitives[0].matrix[0]=99,()=>Object.defineProperty(s.parts[0],'id',{value:'x'}),()=>Object.setPrototypeOf(s.parts[0],{})])try{f()}catch(_){blocked++}return {blocked,same:s.svg===mermaid.renderMermaidSVG('flowchart LR\\nA-->B')}`,{blocked:6,same:true}],
 ['nested prototype routes',`const s=mermaid.renderResolvedScene('flowchart LR\\nA-->B');const p=s.parts[0].primitives[0];return {constructors:[s.constructor,s.parts.constructor,s.parts[0].constructor,p.constructor,p.paint.constructor,p.matrix.constructor].filter(x=>x!==undefined).length,protos:[s,s.parts,s.parts[0],p,p.paint,p.matrix].map(x=>Object.getPrototypeOf(x)===null)}`,{constructors:0,protos:[true,true,true,true,true,true]}],
 ['unsupported error metadata readonly',`try{mermaid.renderResolvedScene('flowchart LR\\nA-->B',{shadow:true})}catch(e){let blocked=0;for(const f of [()=>e.code='bad',()=>Object.defineProperty(e,'feature',{value:'bad'}),()=>e.partId='bad'])try{f()}catch(_){blocked++}return {blocked,code:e.code,partId:e.partId,feature:e.feature,message:typeof e.message==='string',name:e.name}}`,{blocked:3,code:'RESOLVED_SCENE_UNSUPPORTED_ARTWORK',partId:'node:A',feature:'filter',message:true,name:'ResolvedSceneError'}],
 ['plain JSON result',`const s=mermaid.renderResolvedScene('flowchart LR\\nA-->B');return {version:s.version,parts:s.parts.map(p=>({id:p.id,primitives:p.primitives.map(p=>p.kind)}))}`,undefined],
 ['forged diagram rejected',`try{mermaid.renderResolvedScene({kind:'flowchart',body:{},canonicalSource:'flowchart LR\\nA-->B'})}catch(e){return /must come from mermaid.parseRegisteredMermaid/.test(e.message)}`,true],
 ['trusted parsed diagram works',`const p=mermaid.parseRegisteredMermaid('flowchart LR\\nA-->B');return p.ok&&mermaid.renderResolvedScene(p.value).parts.length`,3],
]
const rows=[]
for(const [name,code,expected] of cases){const result=await executeInSandbox(code as string,{timeoutMs:30000});assert.equal(result.ok,true,JSON.stringify({name,result}));if(expected!==undefined)assert.deepEqual(result.value,expected);rows.push({name,result})}
const hosted=createTracingMermaid(undefined,undefined,undefined,HOSTED_CODE_MODE_HOST_POLICY)
let callbackCount=0
const source='flowchart LR\nA-->B'
const result=hosted.renderResolvedScene(source,{security:'default',embedFontImport:true,onConfigDiagnostic:()=>callbackCount++})
assert.equal(result.svg,renderMermaidSVG(source,{security:'strict',embedFontImport:false}));assert.deepEqual(verifyNoExternalRefs(result.svg),{ok:true,refs:[]})
const tool=createDescribeSdkTool()
for(const args of [{},{family:'flowchart',capability:'resolved-scene'},{capability:'bad'},{capability:'resolved-scene',detail:'bad'}])assert.ok(validateMcpToolArguments(tool,args).length,JSON.stringify(args))
for(const args of [{capability:'resolved-scene'},{capability:'resolved-scene',detail:'signatures'},{family:'flowchart'}])assert.equal(validateMcpToolArguments(tool,args).length,0,JSON.stringify(args))
const detail=describeSdkPayload({capability:'resolved-scene'})
assert.ok((detail.declaration as string).includes('version: 2;'));assert.ok((detail.declaration as string).includes('node: unknown;'));assert.ok((detail.declaration as string).includes('interface ResolvedPath'))
writeFileSync('/workspace/.cloud-setup/upstream-audit-2026-10-30/interfaces/api-results.json',JSON.stringify({revision:execFileSync('git',['rev-parse','HEAD'],{cwd:'/workspace/agentic-mermaid',encoding:'utf8'}).trim(),rows,hostPolicySvg:true,validation:true,canonicalPrimitiveFields:true,callbackCount},null,2))
console.log('6 Code Mode adversarial probes plus host policy, schema admission and canonical type discovery passed')
