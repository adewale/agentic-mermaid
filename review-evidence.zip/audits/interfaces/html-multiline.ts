import {marked} from '/workspace/agentic-mermaid/node_modules/marked/lib/marked.esm.js'
import {mermaidMarkdownBlocks} from './markdown-head.ts'
for(const open of ['<custom-widget\n data-name="example">','<custom-widget data-name="first\nsecond">','<custom-widget \n>','<custom-widget\n>','<custom-widget\n data-name=example>']){
 const markdown=open+'\n```mermaid\nnot a diagram\n```'
 console.log(JSON.stringify({open,actual:mermaidMarkdownBlocks(markdown),tokens:marked.lexer(markdown,{gfm:false})}))
}
