import {marked} from '/workspace/agentic-mermaid/node_modules/marked/lib/marked.esm.js'
import {mermaidMarkdownBlocks} from '/workspace/agentic-mermaid/src/cli/markdown.ts'
import {writeFileSync} from 'node:fs'
const prefixes=['','Paragraph','Paragraph\ncontinued','    indented code','\tindented code','    ```text\n    example\n    ```','# Heading','Heading\n=======','---','***','____','Paragraph\n---','Paragraph\n===','Paragraph\n- - -','Paragraph\n***']
const opens=['<custom-widget>','<custom-widget attr="v">','</custom-widget>','<span>','<span attr="v">','<div>','<div >','<div\t>','<div\f>','<script>','<!--','<?xml','<!DOCTYPE','<![CDATA[']
const rows=[]
for(const prefix of prefixes)for(const open of opens)for(const gap of ['','\n']){
 const markdown=`${prefix?prefix+'\n':''}${open}\n${gap}\`\`\`mermaid\nflowchart LR\nA-->B\n\`\`\``
 const actual=mermaidMarkdownBlocks(markdown).map(x=>x.source.trim())
 const tokens=marked.lexer(markdown,{gfm:false})
 const expected=tokens.filter((x:any)=>x.type==='code'&&/^mermaid(?:\s|$)/i.test(x.lang??'')).map((x:any)=>x.text.trim())
 if(JSON.stringify(actual)!==JSON.stringify(expected))rows.push({prefix,open,gap,markdown,actual,expected,tokens})
}
writeFileSync('/workspace/.cloud-setup/upstream-audit-2026-10-30/interfaces/markdown-results.json',JSON.stringify({cases:prefixes.length*opens.length*2,mismatches:rows},null,2))
console.log('Cases',prefixes.length*opens.length*2,'mismatches',rows.length)
for(const row of rows.slice(0,12))console.log(JSON.stringify({prefix:row.prefix,open:row.open,gap:row.gap,actual:row.actual,expected:row.expected,tokenKinds:row.tokens.map((x:any)=>x.type)}))
