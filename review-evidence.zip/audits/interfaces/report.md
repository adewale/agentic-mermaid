# Adversarial interfaces audit

Requested candidate: `5ec6ceb567cba50d0d17d6e1643a63a5ff01e85e`, base `4c72d1c8`.
No repository files were edited by this reviewer. Scratch probes and results are beside this report. Parent has begun editing fixes during review, so the Markdown reproducer imports `markdown-head.ts`, captured directly from the requested commit, rather than the mutable working file.

## P2 — HTML ownership after an indented code block is misclassified

At candidate `src/cli/markdown.ts:42`, a nonblank indented code line sets `paragraph = true`. The following complete custom HTML tag therefore cannot start HTML ownership, because `htmlBlockEnd` only recognizes such tags when `!paragraph`.

Minimal top-level Markdown (no nested list or blockquote):

````markdown
    indented example
<custom-widget>
```mermaid
not a diagram
```
````

The existing independent `marked@9.1.6` lexer produces an indented-code token followed by an HTML token: **zero Mermaid code blocks**. Candidate extraction produces one block at line4; the existing verifier returns `ok:false`. Thus `am verify --markdown` falsely fails on code-looking contents owned by an HTML block. The same occurs with a tab-indented example.

Evidence: `minimal.ts`, `minimal-results.json`, plus the 420-case `markdown.ts` exploration. This is incomplete coverage of the existing false-positive class in `render-markdown`'s old regex and a correctness defect in the new Markdown verification feature. It is not an introduced host/security escape.

A fix must preserve the reverse control:

````markdown
Paragraph
    continuation
<custom-widget>
```mermaid
flowchart LR
A-->B
```
````

Here the indented line continues the existing paragraph, so the custom tag cannot interrupt it; the Mermaid fence **is** live. Blindly classifying every indented line as a new code block would hide this diagram.

The broad exploratory matrix found 52 differences against marked, but I am not treating all as product bugs: marked itself differs from the CommonMark HTML rules for some tabbed HTML tags and processing-instruction continuations. The concrete indented-code case above agrees with both the block semantics and the independent parser.

## P3 / integration clarification — initial and discovered declarations cannot be concatenated

The initial SDK declaration defines `interface ResolvedScene` with `version:number`, `parts:unknown[]` and `frame:unknown[]`. The on-demand discovery declaration defines the same interface using `version:2`, `parts:ResolvedPart[]` and `frame:ResolvedPrimitive[]`.

A TypeScript consumer assembling `SDK_CORE_DECLARATION + describe_sdk({capability:'resolved-scene'}).declaration` gets three TS2717 duplicate-property errors, and `scene.parts[0].primitives` remains TS2571/unknown. `types.ts` produces the concrete diagnostic receipt in `combined-types-results.json`.

This is introduced by the new declaration surface. Existing public npm declarations and the standalone full SDK declaration compile; the executable API is unaffected. Current docs describe field discovery but do not explicitly promise concatenating these fragments, so I do **not** claim it violates a documented code-generation contract. Either make augmentation work or explicitly describe the rich declaration as a replacement/reference rather than an additive fragment. This is a type-discovery integration caveat, not a security finding.

## Safety and policy hypotheses disproved by focused probes

`api.ts` passes six actual Code Mode cases covering:

- nested writes to scene parts, primitive paint and matrices, plus property-definition and prototype changes;
- constructor/prototype routes from the full scene, part array, parts, primitives, paint and matrices;
- attempts to mutate/replace structured `ResolvedSceneError` fields;
- plain-data result marshalling of selected nested primitives;
- forged parsed-diagram rejection;
- trusted parsed-diagram acceptance.

The same probe confirms caller `{security:'default',embedFontImport:true}` cannot weaken the host-owned strict projection for the new API, no external references appear, mutually exclusive discovery branches are admitted/rejected correctly, and discovery retains canonical version2/path/opaque-node fields. `api-results.json` records all results.

Three affected repository suites pass: **66 tests, 0 failures**, with the canonical 30000ms timeout (`focused-tests.log`). This is focused review, not a full-suite run or a formal sandbox proof. No constructor escape, host-policy bypass, prototype leak or partial-scene acceptance was found in the tested boundaries.

## Math report checks

The integrated report preserves the material source distinctions from this review: mermaid-rs-renderer does text approximation; Streamdown's Markdown math and diagram plugin are separate; streamdown-pele's repository lock is pre-math Pele1.6.0 and new capability needs an installed math-capable Pele plus resolver; Excalidraw supplies no math resolver and converts supported labels into plain text; official CLI/editor/MCP delegate to Mermaid. Source observations and Termaid runtime observations remain explicitly separated. No additional research-claim finding was found in those rows. The other reviewer owns Beautiful/Agentic/Zombie artifact claims.

## Fix verification addendum

The root agent addressed both findings. Independent recheck on `50b51037298c09978580f8fd19b966df77f9d5a9` plus the then-uncommitted SDK declaration edits confirms:

- Markdown indented-code/custom-HTML fixture now extracts zero Mermaid blocks; the paragraph-continuation control still extracts one.
- Initial declaration now advertises canonical literal version2 and shared scalar fields, leaving detailed parts/frame for the augmenting declaration. Concatenated declarations and real primitive access produce **zero TypeScript diagnostics** (`combined-types-green-results.json`). The original four diagnostic records are retained in `combined-types-red-results.json`.
- All six actual Code Mode membrane probes, strict-host-policy control, schema admission and canonical discovery checks pass again.

No remaining blocking finding was identified in the assigned interfaces. This addendum is a working-tree recheck pending the root agent's final commit binding; it does not claim untouched CI or release readiness.

## Final committed-candidate binding

Independently repeated the type composition, six actual Code Mode/API membrane probes, strict hosted render-policy control, schema admission, canonical field checks and three Markdown ownership controls on **`70842c1c18c071f5b098be836956fb62da33fac6`** with a clean working tree. All pass. The initial and discovered declarations now compose with **zero diagnostics**; space/tab-indented code followed by custom HTML yields no false Mermaid block, while indented paragraph continuation retains its real Mermaid fence.

Both reported defects are resolved in this committed candidate. No remaining finding was identified in this review's assigned boundaries. Receipts: `api-results.json`, `combined-types-results.json`, `final-markdown-results.json`. The original immutable-revision reproducer and historical diagnostics remain available for comparison. Full CI status is owned by the root agent and is not inferred from these focused checks.
