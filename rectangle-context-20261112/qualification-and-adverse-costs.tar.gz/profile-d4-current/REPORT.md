# Current d4 warm profile

Ten fully consumed public Native100 renders, cache off; sampled self and inclusive times stay separate. Inspector/GC overhead is recorded separately; nested inclusive totals must not be summed. These are profile costs, not a latency comparison.

| Function | Source | Self total / mean ms | Inclusive total / mean ms |
|---|---|---:|---:|
| copyInner | src/scene/native-paint-emission.ts:228 | 105.743 / 10.574 | 143.721 / 14.372 |
| include | src/scene/bounds.ts:358 | 80.545 / 8.055 | 93.230 / 9.323 |
| assessLayoutGeometry | src/layout-rubric.ts:493 | 48.696 / 4.870 | 96.321 / 9.632 |
| copy | src/scene/native-paint-emission.ts:410 | 43.848 / 4.385 | 154.421 / 15.442 |
| certifyNativePaint | src/scene/paint-certification.ts:1435 | 27.921 / 2.792 | 219.231 / 21.923 |

The marker-region include function serializes the full marker into a repaint equality key per occurrence. Any removal must preserve actual resource/orientation/unit-scale/transform equality; paint equality alone is insufficient. Copy/paint work is being removed at its actual producer, with generic fallbacks retained. No speedup estimate is asserted from these bounds.

## Matching interventions and limits

| Spot / current source line | Matching case | Proposed change | Expected speedup |
|---|---|---|---|
| copyInner, native-paint-emission.ts:228 | Data-oriented producer reuse | Consume exact completed geometry/text operands at the actual write; retain fresh generic capture for mutable/getter inputs. It reads almost every field, so AoS→SoA is not established by this profile. | Unmeasured. 10.574ms sampled self per render is an attribution, not an achievable elapsed saving. |
| marker region include, bounds.ts:358 | Data-oriented representation | Avoid rebuilding a full resource+pose serialization where the existing actual-resource identity and pose operands can express the same equality. Keep unknown orientation, transforms, units, geometry and generic serialization behavior. | Unmeasured. A separate whole Native100 observation attributes only1.344ms to298 JSON.stringify calls/91783 UTF16 units; spread/slice allocation and hull work are separate. The whole8.055ms self cost cannot be assigned to JSON. |
| assessLayoutGeometry, layout-rubric.ts:493 | Repeated hash lookup | Resolve stable internal endpoint ordinals once and address flat node arrays only if a causal trial improves cost; generic reordered/sparse receivers keep their behavior. | Unmeasured; the earlier combined numeric-endpoint experiment failed, so it supplies no positive estimate and is not being replayed. |
| copy, native-paint-emission.ts:410 | Existing cache/retained plan | Reuse existing completed marker/text producer operands within this transaction rather than add a result cache or another geometry IR. Distinct text still requires its actual capture. | Unmeasured. Its inclusive time contains copyInner and must not be added to that row. |
| certifyNativePaint, paint-certification.ts:1435 | Data-oriented staged consumption | Reuse only completed context/geometry/text facts at their owning producer, preserving independent bounds, CSS, references, pair/operation caps and final ink checks. Scratch indexes remain bounded to the proof. | Unmeasured. The21.923ms inclusive mean contains nested work; removing checks is not an optimization. |

No independent sequential awaits occur in these synchronous hotspots. This profile does not justify pointer-bit packing, a wholesale SoA conversion or more caches. No production changes are made by this report.

## Existing caches and retained state in the measured path

- Layout-result cache: hides expensive fresh/edit work behind exact-input hits. Disabled in this profile and excluded from the100ms fresh-work claim. Do not extend it.
- Native textPlans, native-paint-emission.ts:180/410: retains reflection instructions within one emission while materializing required receiver graphs. This amortizes repeated processing; it does not resolve the cost of distinct labels.
- Xml capture names/attributes/texts Maps, svg-writer.ts:127: amortize repeated lexical scans per capture. They can hide duplicated string validation; fixed actual-writer events are the relevant removal, not another literal cache. Cached bytes never grant write custody.
- Measured graph footprints Map, measured-graph-producer.ts:167: structural marker reservations avoid repeated construction. Its key construction may hide a slower representation; no demonstrated replacement speedup exists.
- Route marker execution/peer snapshots, route-marker-clearance.ts:45/271: guarded per-pass geometry reuse after the earlier quadratic work removal. These are not persistent render-result caches.
- Paint strokeAlpha, pathContours, occurrenceBounds and actualShaftParts Maps, paint-certification.ts:1702–1707: proof-local scratch indexes that prevent repeated occurrence work. They do not certify a later output.
- connectorLabelBlocks WeakMap, bounds.ts:438: retains a prepared text block by descriptor. Mutable/getter behavior and the actual receiver remain separate contracts.
- renderedCertificates WeakMap, paint-certification.ts:48: returned RenderedLayout API state, not a cache that qualifies new or edited drawings.
- Captured-leaf, XML-write, group, written-polyline, text ownership and completed resource registries: private custody and transaction state. Their mere presence does not demonstrate a slow algorithm; deleting identity checks would change correctness.
- Render-option validationRootSchema: existing schema cache, currently retaining a full duplicated public projection at d4. The active candidate reduces it to the transitive JSON definitions required by selected field fragments, leaving public schema copies complete; its allocation observations are retained separately.

Current production remains d4. Native100 has one112.24ms process despite a95.86ms median; edit/tail/memory costs remain adverse. Larger proof suite is10P2U, Chain300 both unknown. Active producer and browser changes are unshipped and cannot yet be claimed as latency or completion wins.
