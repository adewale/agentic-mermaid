# Independent comparator priority-local review

Read-only inspection of current `compound-lazy-visibility.ts` and its compound-boundary caller. No production edits, tests, renders, profiles, builds, network or new agents. The proposal was to compute priority(a)/priority(b) once in local variables and reuse their numeric results for the relational/tie test.

**Disposition agreed with coordinator: stop this speculative micro-optimization, without benchmark or production change. Do not introduce new flags, protocols, descriptor checks or ownership machinery for it.** The static getter counterexample below is a helper-boundary distinction, not a demonstrated supported-product defect or an exploit claim.

## Supported producer versus helper boundary

`route(starts, goal)` retains its goal parameter directly. `locate(goal)` reads coordinates; it does not snapshot, validate own descriptors or replace the object. `priority` subsequently reads goal.x/y on each invocation and obtains distance through a dynamically dispatched private Map.get.

However, the supported compound router constructs start/end anchors from fresh simplified quotient points or escape literals before calling this helper. Simplification copies points into new ordinary records and escape returns ordinary own x/y values. The only production createLazyVisibilityGrid call found is this compound boundary path. For those ordinary synchronous inputs, no private distance table or goal value changes within a `less` comparison. Reusing its numeric results therefore preserves relational/tie behavior, including equal priorities, without persistent caching or new allocation. Heap swap spending remains once per comparison. Arbitrary instrumentation of private Map.get/Math operations is not independently an intended public protocol whose call counts must be frozen.

I found no concrete new throw, wrong owned ink or supported mutable/getter/CSS/definition/ownership failure from this ordinary private-data substitution. Do not present the example below as such a failure or infer that every internal helper promises all accessor read counts.

## Exact static accessor counterexample at the unenforced helper boundary

Construct an empty-obstacle grid with bounds (0,0,width=2,height=2), an ordinary anchor (1,2), and terminals ordered as follows, both with penalty zero:

1. port (2,0), stub (2,1).
2. port (0,0), stub (0,1).

The generated x/y coordinate arrays are [0,1,2]. The first terminal produces state 17 and the second state 11 (vertical axis state). Each has stored distance 1. In the first enqueue comparison, a=11, b=17, each priority has a base cost of 2: distance 1 plus vertical heuristic 1.

Pass a separate goal object with y=2 and an x getter. Let x return 1 for `locate`, then 2,2,1,1 for the next four comparator reads (and 1 thereafter). Under the existing expression:

- priority(a)=4, priority(b)=2; `4 < 2` is false.
- The repeated calls yield priority(a)=3, priority(b)=3; equality holds and 11<17, so `less` returns true.

Under the proposed numeric locals, left=4 and right=2 are retained; both the relational test and equality test are false. The first heap ordering decision differs. A stable-valued counting getter would also observe fewer reads, without necessarily changing the resulting path. No runtime execution was performed; this follows directly from the inspected expressions and coordinate/state arithmetic.

This demonstrates that accepting arbitrary accessor-bearing helper arguments is not equivalent to the actual producer's plain-anchor invariant. It does not show that a public rendering request can supply that goal object or acquire the private distance tables.

## Value and stopping rationale

The current completed-delivery profile attributes 6.558 ms self / 9.379 ms inclusive to less per repeated Trinity call, from only two samples. That motivates a possible experiment but establishes neither attainable savings nor end-to-end benefit. The proposal introduces no data cache/storage/cap change, yet deciding to enforce a more general private-helper protocol solely for this subtraction would exceed its demonstrated value.

The coordinator elected not to benchmark or change production. Preserve the exact static example and the supported-input distinction, leave the rejected heap-directory trial stopped, and do not claim either an optimization win or a supported-product correctness defect from this review.
