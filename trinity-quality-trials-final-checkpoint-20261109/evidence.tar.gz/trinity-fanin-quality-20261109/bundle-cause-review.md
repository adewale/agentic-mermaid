# Lazy graph-free family payload: bounded cause review

Reviewed current source `3f2c26bd860eadcfb48746eabb45801ab8e07c7a` and retained Class-stage `dist/metafile-esm.json` / browser products. No builds, renders, tests, profiles, network or source edits. Only dependency traversal and existing metadata reads were performed. The stopped header-height, heap and image probes were not repeated.

**Result: the proposed graph-router/Trinity leak is not present in the retained sequence/timeline static closure. No large removable shared Scene/paint owner was demonstrated. Do not start a production subtraction on the evidence of module size alone.**

## Exact dependency result

Following emitted non-dynamic imports using the same entry + render-core + family + YAML roots as `scripts/build/browser-lazy-report.ts:62–74,139–150,189–196` yields:

| Family | Retained emitted closure | Retained raw bytes | Reported current CI raw bytes | Existing raw cap |
| --- | ---: | ---: | ---: | ---: |
| Sequence | 14 modules | 801,186 | 801,181 | 667,000 |
| Timeline | 10 modules | 741,862 | 741,867 | 617,000 |

The ±5-byte differences identify these as retained-artifact calculations, not exact current CI acquisitions. Both include the real YAML provider (100,108 bytes), as the existing budget requires. Neither closure includes Trinity implementation or loader, Trinity graph producer, measured graph producer, compound boundary router, Native implementation, or ELK. Those owners have separate emitted modules outside these closures. A demand-only edge is not a static inclusion.

The largest shared emitted file is `chunk-D971EB51.js`, **599,808 actual emitted bytes**. It is the consolidated six-module all-family intersection, not the graph solver. This consolidation operates on already-common static dependencies (`scripts/build/consolidate-browser-runtime.ts:24–43`); no evidence here supports rerunning the previously stopped grouping-removal experiment.

## Source-only Scene admission is already projected

The relevant build seam is enabled: `runtime-render-contract.ts:372–380` resolves full `external-data-snapshot.ts` to `external-data-snapshot.browser.ts`. The retained graph contains the latter (172 pre-compaction contribution bytes). Full external snapshot facade, external Scene projection and external validator owners are absent. Thus this is not an accidentally retained full external Scene API.

The **51,083-byte pre-compaction contribution** from `scene-validation-core.ts` is not a removable external-only module:

- `scene/native-drawing.ts:11,113–126` uses `createNativeSceneValidator` on actual writes and enforces final SVG limits.
- `external-data-snapshot.browser.ts:18–29` retains internal structural/cross-check admission. `scene-data-snapshot.ts:255–272` refuses external input while preserving bounded snapshots, ownership and stronger subsequent admission.
- `validateSceneDocument` explicitly rejects external mode without external checks; its shared node validators also serve internal drawing and backend conformance.
- `scene/backend.ts:224–271` still requires executable built-in backend conformance before drawing; source-only input does not make that obligation dead. Rough/hybrid and internal Scene fallback remain supported by lazy rendering.

The retained shared contributions of `paint-certification.ts` (73,651), `backend-conformance.ts` (23,851), `svg-writer.ts` (19,247) and `native-paint-emission.ts` (18,619) likewise have active final paint/write/conformance consumers. These are pre-compaction attributions, not additive post-build removable savings. Sequence/timeline being graph-free does not make them free of connectors, labels, Scene serialization or final paint checks.

Some external-mode branches remain syntactically co-located in the shared validator. This establishes no separate removable module or safe large subtraction. Specializing that entire validator would be a new transformation requiring proof of preserved internal/ambient/error behavior; the complete 51,083-byte attribution is only a loose owner-size ceiling, most of which is required. It cannot be represented as an available saving.

## Small import mismatch found, not recommended for this deficit

`positioned-views/geometry.ts:7` re-exports retained label helpers from graph-specific `agent/layout-to-rendered.ts`, whose live graph converter imports `layout/geometry.ts` and edge selectors. Those owners are present in the common output: 1,854 + 2,322 + 297 = **4,473 pre-compaction contribution bytes total**, before subtracting the required label helpers. A pure label-helper leaf could separate this ownership, but other graph consumers remain and final chunk savings are unknown. This is neither the 124–134 KB deficit's cause nor a justified next production change; the coordinator explicitly asked to avoid that low-value extraction.

## Decision

No demonstrable high-value producer/import subtraction is selected. The retained dependency graph supports a shared correctness-runtime cost, not accidental solver loading. Preserve final proof, snapshots, optional backends and original budgets; report CI's failed limits. A further implementation proposal needs a concrete unreachable owner or repeated immutable payload with actual emitted ownership evidence, not a broad validator rewrite or an assumed saving equal to a module's size.
