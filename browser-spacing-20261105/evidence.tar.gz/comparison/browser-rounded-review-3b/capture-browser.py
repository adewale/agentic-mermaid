import pathlib,subprocess,sys,os,json,time
phase=sys.argv[1]
repo=pathlib.Path('/tmp/pr449-main-ci-base-f9ec8c115' if phase=='main' else '/tmp/pr449-main-integration-20261029-762')
out=pathlib.Path('/tmp/pr449-week-comparison-20261101/browser-rounded-review-3b')/phase
out.mkdir(exist_ok=True)
source=repo/'e2e/browser.test.ts'; original=source.read_bytes()
needle="      const currentPath = join(SCREENSHOT_DIR, `current-${testCase.name}.png`)"
replacement="      await Bun.write(join(process.env.PR449_BROWSER_CAPTURE_DIR!, `${testCase.name}.svg`), svgHtml)\n"+needle
assert original.decode().count(needle)==1
(out/'browser.test.before.ts').write_bytes(original)
env=os.environ.copy();env.update(PATH='/tmp/pr449-campaign-bin:'+env['PATH'],PLAYWRIGHT_BROWSERS_PATH='/workspace/pr449-playwright',PR449_BROWSER_CAPTURE_DIR=str(out))
started=time.monotonic();result=None
try:
 source.write_text(original.decode().replace(needle,replacement))
 with open(out/'owner.log','w') as log:
  result=subprocess.run(['bun','test','e2e/browser.test.ts','--test-name-pattern','rounded header fills','--timeout','240000'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
finally:
 source.write_bytes(original)
 assert source.read_bytes()==original
 for image in (repo/'e2e/screenshots').glob('current-*.png'):
  (out/image.name).write_bytes(image.read_bytes())
 (out/'STATUS.json').write_text(json.dumps({'phase':phase,'runtimeRevision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'captureOnlyTestOverlay':True,'testSourceRestoredByteExact':True,'exitCode':result.returncode if result else None,'wallSeconds':time.monotonic()-started},indent=2)+'\n')
sys.exit(result.returncode if result else 99)
