import pathlib,subprocess,os,json,gzip,time
repo=pathlib.Path('/tmp/pr449-main-integration-20261029-762')
out=pathlib.Path('/tmp/pr449-week-comparison-20261101/browser-rounded-review-3b')
source=repo/'src/layout/passes/fanout.ts';original=source.read_bytes();html=repo/'editor.html';candidate_html=html.read_bytes()
baseline=subprocess.check_output(['git','show','3b35c1b3d3387df2d61323071b3c9678b06f1445:src/layout/passes/fanout.ts'],cwd=repo)
assert b'keepsCenteredTerminalBodies' in original and b'keepsCenteredTerminalBodies' not in baseline
(out/'candidate-editor.html.gz').write_bytes(gzip.compress(candidate_html,compresslevel=9))
(out/'candidate-fanout.ts').write_bytes(original);(out/'baseline-fanout.ts').write_bytes(baseline)
env=os.environ.copy();env.update(PATH='/tmp/pr449-campaign-bin:'+env['PATH'],AM_EDITOR_BUILD_METAFILE=str(out/'baseline-editor-metafile.json'))
started=time.monotonic();result=None
try:
 source.write_bytes(baseline)
 with open(out/'paired-payload-baseline.log','w') as log:result=subprocess.run(['bun','run','scripts/site/editor.ts'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:raise RuntimeError('Baseline build failed; inspect retained log')
 (out/'baseline-editor.html.gz').write_bytes(gzip.compress(html.read_bytes(),compresslevel=9))
finally:
 source.write_bytes(original);html.write_bytes(candidate_html)
 assert source.read_bytes()==original and html.read_bytes()==candidate_html
before=json.loads((out/'baseline-editor-metafile.json').read_text());after=json.loads((out/'current-editor-metafile.json').read_text())
report={'sourceBefore':'3b35c1b3d3387df2d61323071b3c9678b06f1445','sourceAfter':'69af97a12aefe1140095064312a7f32b3f5e5714','sourceAndCandidateHtmlRestoredByteExact':True,'controlledDifference':'Only fanout.ts reverted to its pre-intervention version for one complete equivalent standalone editor build; same installed deps, Bun1.4.4 and recipe. No cache changes.','before':{k:before[k] for k in ['htmlBytes','htmlGzipBytes','workerBytes','packedWorkerBytes','compressedRuntimeBytes']},'after':{k:after[k] for k in ['htmlBytes','htmlGzipBytes','workerBytes','packedWorkerBytes','compressedRuntimeBytes']},'delta':{k:after[k]-before[k] for k in ['htmlBytes','htmlGzipBytes','workerBytes','packedWorkerBytes','compressedRuntimeBytes']},'baselineBuildWallSeconds':time.monotonic()-started,'scope':'Download cost; no execution-speed or build-speed ratio.'}
(out/'PAIRED-PAYLOAD.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
