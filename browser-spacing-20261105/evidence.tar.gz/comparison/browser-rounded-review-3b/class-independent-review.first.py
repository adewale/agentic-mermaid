# Saved browser products only; no build/browser/public rendering or golden writes.
from pathlib import Path
import json,xml.etree.ElementTree as E,re,copy,struct,hashlib
p=Path('/tmp/pr449-week-comparison-20261101/browser-rounded-review-3b');N='{http://www.w3.org/2000/svg}'
b=(p/'main/class-rounded-fill.svg').read_text();a=(p/'candidate/class-rounded-fill.svg').read_text();br=E.fromstring(b);ar=E.fromstring(a)
def cls(r,c):return next(e for e in r.iter()if e.get('class')==c)
def group(r,id):return next(e for e in r.iter(N+'g')if e.get('data-id')==id)
def label(t):return ''.join(t.itertext())
def f(v):return format(v,'.12g')
def translatepath(d,dy):
 tok=re.findall(r'[MHAVZ]|-?\d+(?:\.\d+)?',d);i=0;parts=[]
 while i<len(tok):
  cmd=tok[i];i+=1;n={'M':2,'H':1,'A':7,'V':1,'Z':0}[cmd];v=tok[i:i+n];i+=n
  if cmd in ['M','A']:v[-1]=f(float(v[-1])+dy)
  if cmd=='V':v[0]=f(float(v[0])+dy)
  parts.append((cmd,v))
 return parts
def canonical(r):return (r.tag,dict(r.attrib),r.text or '',[canonical(c)for c in r])
expected={'WebApp':['WebApp','+ render()','+ fetchData()'],'ApiService':['ApiService','+ request()']};arms={}
for name,r in [('main',br),('candidate',ar)]:
 nodes=[e for e in r.iter(N+'g')if e.get('class')=='class-node'];assert [e.get('data-id')for e in nodes]==list(expected)
 boxes={}
 for id,texts in expected.items():
  g=group(r,id);assert [label(t)for t in g.iter(N+'text')]==texts;rect=next(e for e in g if e.tag==N+'rect');boxes[id]=dict(rect.attrib)
  assert float(rect.get('rx'))==float(rect.get('ry'))==10
 rel=cls(r,'class-relationship');assert [rel.get(k)for k in ['data-from','data-to','data-type','data-marker-at','data-label']]==['WebApp','ApiService','association','to','calls']
 points=[list(map(float,v.split(',')))for v in rel.get('points').split()];assert points[0]==[106.9,145.2];assert points[-1]==[106.9,float(boxes['ApiService']['y'])];assert points[-1][1]>points[0][1]
 wb=boxes['WebApp'];ab=boxes['ApiService'];assert points[0][1]==float(wb['y'])+float(wb['height']);assert points[-1][0]==float(ab['x'])+float(ab['width'])/2
 overlay=cls(r,'class-marker-overlay');assert overlay.get('points')==rel.get('points');assert overlay.get('marker-end')==rel.get('marker-end')=='url(#cls-arrow)'
 resources=[e for e in r.iter(N+'marker')if e.get('id')=='cls-arrow'];assert len(resources)==1
 for body in boxes.values():
  x,y,w,h,stroke=[float(body[k])for k in ['x','y','width','height','stroke-width']];assert x-stroke/2>=0 and y-stroke/2>=0 and x+w+stroke/2<=float(r.get('width')) and y+h+stroke/2<=float(r.get('height'))
 calls=next(e for e in r if e.tag==N+'text'and label(e)=='calls');arms[name]={'root':dict(r.attrib),'cards':boxes,'caption':dict(calls.attrib),'normalDockPoints':points,'opaqueBodyStroke':True,'paintedBodiesWithinViewport':True}
assert E.tostring(group(br,'WebApp'))==E.tostring(group(ar,'WebApp'))
assert E.tostring(br.find(N+'defs'))==E.tostring(ar.find(N+'defs'))
bg=group(br,'ApiService');ag=group(ar,'ApiService');assert len(list(bg.iter()))==len(list(ag.iter()))
apiDiff=[]
for old,new in zip(bg.iter(),ag.iter()):
 assert old.tag==new.tag and (old.text or'')==(new.text or'')
 for key in dict.fromkeys([*old.attrib,*new.attrib]):
  x,y=old.get(key),new.get(key)
  if x==y:continue
  if key in ['y','y1','y2']:assert abs(float(x)-float(y)-3)<1e-8
  elif key=='d':assert translatepath(x,0)==translatepath(y,3)
  else:raise AssertionError(('unexpected ApiService attribute',key,x,y))
  apiDiff.append({'tag':new.tag.removeprefix(N),'attribute':key,'main':x,'candidate':y})
assert len(apiDiff)==9
# Inverse only the independently observed translations plus root dimensions/scope.
inverse=copy.deepcopy(ar);inverse.attrib=dict(br.attrib);oldscope=br.get('class');newscope=ar.get('class')
inverse.find(N+'style').text=inverse.find(N+'style').text.replace(newscope,oldscope)
next(e for e in inverse if e.get('data-backdrop')=='page').set('height','412')
for c in [cls(inverse,'class-relationship'),cls(inverse,'class-marker-overlay')]:c.set('points','106.9,145.2 106.9,286.8')
for old,new in zip(bg.iter(),group(inverse,'ApiService').iter()):
 for k in ['y','y1','y2']:
  if k in new.attrib:new.set(k,f(float(new.get(k))+3))
 if 'd'in new.attrib:
  assert translatepath(new.get('d'),3)==translatepath(old.get('d'),0)
  new.set('d',old.get('d'))
next(e for e in inverse if e.tag==N+'text'and label(e)=='calls').set('y','208')
assert canonical(inverse)==canonical(br)
paths={'main':p/'main/current-class-rounded-fill.png','candidate':p/'candidate/current-class-rounded-fill.png','ci':p/'ci/current-class-rounded-fill.png','golden':Path('/tmp/pr449-main-integration-20261029-762/e2e/screenshots/baseline-class-rounded-fill.png')}
png={k:{'dimensions':list(struct.unpack('>II',path.read_bytes()[16:24])),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}for k,path in paths.items()}
report={'scope':'Independent saved browser DOMSVG and screenshot review; no build/render/test/source/golden writes.','source':'classDiagram\n  class WebApp {\n    +render()\n    +fetchData()\n  }\n  class ApiService {\n    +request()\n  }\n  WebApp --> ApiService : calls','arms':arms,'allOwnedNamesMethodsRelationshipCaptionPreserved':True,'webAppRawDomBytesExact':True,'markerDefinitionBytesExact':True,'normalContactsAndMatchedOverlay':True,'apiServiceOnlyRigidMinus3pxTranslation':apiDiff,'apiHeaderGeometry':'Rounded10px upper corners, unchanged125.7×44.2 header inside unchanged125.7×85.2 body; header label stays at half-height22.1. All member/divider/header geometry translates together.','knownWholeSvgDifferencesOnly':{'rootHeight':[412,409],'rootScopeRename':True,'backdropHeight':[412,409],'ApiServiceYDelta':-3,'carrierAndOverlayTerminalYDelta':-3,'callsYDelta':-1.5},'inverseKnownDifferencesMatchesWholeMainDomTree':True,'pngArtifacts':png,'actualScreenReview':'Both retained browser screenshots inspected: names and all three methods readable, rounded header fills remain inside their outlines, connected shaft and open arrow visible; candidate is the same drawing with3px less inter-card spacing. No new visible clipping or detached header observed.','judgment':'Updating only this existing Class browser PNG is justified as intentional actual3px halo label allocation drift, not an unexplained regression. No additional causal control needed: source-proven known halo change and complete inverse DOM equality account for every delta.','limits':['Pixel glyph/head attribution not tested here; visible screenshot inspection is separate from correspondence/normal contacts.','CI screenshot has same215×410 dimensions as retained local candidate but different encoded bytes; no cross-platform byte equivalence claimed.','Main owning five-family browser test passed. Candidate owner stopped at Class dimension mismatch; later ER/Journey/Timeline current cases remain unqualified until root runs owner after review.','No proofP used as a visible-quality substitute; no new broad ink or universal-font claim.'],'frozen':True}
(p/'CLASS-INDEPENDENT-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'knownDeltaInverseExact':True,'sourceMeaningPreserved':True,'ApiAttrDifferences':len(apiDiff),'png':png,'judgment':report['judgment']},indent=2))
