# Ordinary Native halo reservation: already falsified

Static-only review of current source; no runtime probes, tests, profiles or source edits. **Stop: replacing ordinary Native's zero with the existing owned halo extension is the exact previously stopped intervention, not a distinct new causal trial.**

## First-stage mismatch is real

`src/layout/measured-graph-producer.ts:238–248` includes the complete halo for `owned-routed` requests and for the legacy ancestor special case, but uses zero for an ordinary legacy Native edge. With `LABEL_PILL_PADDING=8`, it supplies the text block plus16px in each dimension. `src/renderer.ts:485–505` uses the same text block and adds `8 + labelHaloExtension(...)` on each side, writing a rounded rectangle with background fill and no stroke. `src/shared/edge-label-geometry.ts:10–11` defines the extension as `max(4, lineWidth * (thick ? 2 : 1) * 2)`.

The exact retained input is historical201 plus three `n0 ~~~ n7` constraints, with TB/BT direction replacement; see `trinity-label-halo-20261109/JOB.json`. The selected label is `n6→n2`, text `edge 16 xxxxxxxxxxxxxxxxxxx`; the lost head belongs to `n5→n3`. `INK.json` records its actual TB written halo at x159.075,y254.875,width174.15,height38.3, fill#FFFFFF, stroke none. At the ordinary 4px extension, the producer's corresponding pill reservation is166.15×30.3 and the underlying text block150.15×14.3 (dimensions derived from the emitted halo and the shared padding formula, not a newly captured producer trace). Thus the missing8px in each reserved dimension is real opaque paint, not merely a hypothetical stroke envelope. Actual selected-head masks record66hidden/72attenuated pixels in each TB/BT product.

This is the earliest reservation mismatch. It is not proof that fixing this one dimension is sufficient: legacy Native subsequently routes, completes and selects among candidates, and the final positions need not retain a simple monotone relationship to initial reservations.

## Exact intervention already acquired

The retained `trinity-label-halo-20261109/measured-producer.full-halo.ts:235–236` replaces only ordinary zero with `labelHaloExtension(edge, style.lineWidth)`. The later `measured-producer.charged-halo.ts:235–237` restricts the new use to routed requests and charges8 existing work units; owned/ancestor branches remain unchanged. This is precisely the proposed reuse, already implemented outside production.

It fixed the selected TB/BT pair: `INK-CANDIDATE.json` records0hidden/0attenuated. It also changed347 of554 completed enrolled SVGs, with three P→U and three U→P transitions (`COHORT-COMPARISON.json`). Acquisition stopped after an actual regression: generated-cyclic13's n5→n1 head went from0 to13hidden and0 to22attenuated pixels under another head (`REGRESSION13-INK.json`). The latter is independent actual-ink evidence, not only a conservative certificate change. The README records the stopped decision. No rerun is needed to rediscover this causal result.

The later body-gap fallback was a different, label-only intervention. Its selected pixel improvement and933gzip-byte cost do not invalidate or erase the earlier full-reservation regression; it too remains unshipped.

## Nearby contracts and why this is not harmless reuse

- **Native candidates:** every primary/authored/compact production calls the same preparation owner (`agentic-producer-core.ts:116–133,158–167`). Wider label dummy bodies can change rank geometry, routing, candidate eligibility and selection. The final score is label conflicts, route overlaps, crossings, bends and area (`:178–205`), not the exact selected-head marginal mask. Retained generated-cyclic17 changes SVG while staying P→P (`COHORT-COMPARISON.json`); that row does not prove which internal compact candidate won. Do not infer stability of Native17 from a final P or a public attempt count. It is a relevant candidate-selection regression control, not evidence for an untested new fix.
- **Authority/CSS:** the helper computes canonical geometric demand from the resolved style; it does not establish final opacity, CSS resolution, marker shape or written-byte equivalence. Its canonical halo has no stroke; inline carrier stroke must not be substituted for the renderer's `style.lineWidth` halo formula. Unknown or later-modified CSS remains subject to existing final proof. A producer dimension cannot authorize new paint facts.
- **Getters/determinism:** the new helper call reads edge.style and style.lineWidth at preparation time. The actual writer still reads its own current values. Do not memoize these reads across products, treat earlier measurements as fresh emitted authority, or remove final mutable/getter checks. Same-owned scalar arithmetic can be deterministic for ordinary inputs without establishing invariance under arbitrary accessors.
- **Caps:** even the charged trial changed placement broadly, affecting later routing and proof work. Small arithmetic cost is not a bound on downstream work. Original limits, hard failures, candidate accounting and final certification must remain; the retained paid trial did so and still regressed.

A true future proposal needs a different demonstrated causal mechanism, not the same full-halo branch renamed “owned dimensions.” This review identifies none and recommends stopping this hypothesis.
