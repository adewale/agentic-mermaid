import { readFileSync, writeFileSync } from 'node:fs'
import { scanSvgStartTags } from '/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts'
import { countPolylineCrossings } from '/tmp/pr449-main-integration-20261029-762/src/shared/edge-crossings.ts'
import { countOpposingRouteOverlaps, countParallelRouteOverlaps } from '/tmp/pr449-main-integration-20261029-762/src/layout-rubric.ts'
import { gzipSync,brotliCompressSync,constants } from 'node:zlib'
const root=import.meta.dir, rows=[]
for (const arm of ['candidate-contained','candidate-nested']) for (const {backend,direction,status} of JSON.parse(readFileSync(root+'/'+arm+'/DIRECTIONS.json','utf8'))) {
 if(status!=='returned')continue
 const stem=backend+'-'+direction, id=arm+':'+direction
 const svg=readFileSync(root+'/'+arm+'/products/'+stem+'.svg','utf8'), tags=scanSvgStartTags(svg).map(t=>({name:t.name,attrs:Object.fromEntries(t.attributes.map(a=>[a.name,a.value]))})), rootTag=tags.find(t=>t.name==='svg')!.attrs
 const edges=tags.filter(t=>t.attrs['data-role']==='edge'&&(t.attrs.points||t.attrs.d)).map(t=>{const xy=(t.attrs.points??t.attrs.d)!.match(/[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?/gi)!.map(Number);if(t.attrs.d && /[CQASTHV]/i.test(t.attrs.d.replace(/[eE][-+]?\d+/g,'')))throw Error('Curved/unsupported path cannot be timed as a polyline');return{source:t.attrs['data-from']!,target:t.attrs['data-to']!,style:'solid' as const,points:Array.from({length:xy.length/2},(_,i)=>({x:xy[i*2]!,y:xy[i*2+1]!}))}})
 if(edges.length !== 3)throw Error('Missing emitted routes')
 let wire=0,bends=0
 for(const edge of edges){let last='';for(let i=1;i<edge.points.length;i++){const a=edge.points[i-1]!,b=edge.points[i]!,len=Math.hypot(b.x-a.x,b.y-a.y);if(!len)continue;wire+=len;const axis=a.x===b.x?'v':a.y===b.y?'h':'diagonal';if(axis==='diagonal')throw Error('nonorthogonal SVG');if(last&&last!==axis)bends++;last=axis}}
 rows.push({arm,id,backend,width:Number(rootTag.width),height:Number(rootTag.height),area:Number(rootTag.width)*Number(rootTag.height),edges:edges.length,wire,bends,crossings:countPolylineCrossings(edges),parallelOverlaps:countParallelRouteOverlaps(edges),opposingOverlaps:countOpposingRouteOverlaps(edges),svgBytes:Buffer.byteLength(svg),gzip9:gzipSync(svg,{level:9}).length,brotli11:brotliCompressSync(svg,{params:{[constants.BROTLI_PARAM_QUALITY]:11}}).length})
}
writeFileSync(root+'/SVG-METRICS.json',JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows))
