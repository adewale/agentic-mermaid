# Quotient descendant order: static causal review

Reviewed current HEAD `39135ac82c67d2783e8211ccdb73714e372a4919`; root's unrelated shared fanout changes were present and untouched. No runtime probes, renders, tests or benchmarks. Source references below are repository-relative at this revision. Retained products are evidence from the earlier compound run, not a new current-head measurement.

**Conclusion: the information loss is real, but the proposed single flat-edge permutation is not a justified next intervention for this witness.** Target order already follows descendant geometry. Ordering instead by source geometry selects the same partition as the stopped source-order probe, which improved TB but worsened the other three directions. A permutation can also change channel tie order; that is an additional causal variable, not evidence that descendant ordering fixes the loss.

## First information loss and available data

`src/layout/agentic-compound-core.ts:53–74` walks authored edge occurrences, lifts each endpoint to its representative at the lowest common scope, and retains occurrence indices in `hosted` and `lifted`. All eight K2,4 edges become parallel A→B edges. Original descendant endpoints remain available in `input.edges[index]`; they are not destroyed globally.

At lines82–99, child scopes are solved before the parent local graph is constructed. `placeChild(id)` returns a `MeasuredScope` with the actual child placement, direction and padding translation (`src/layout/measured-scopes.ts:4–5,17–25`). The compiler takes only child width/height at lines89–90, then replaces source/target at lines92–95. Thus the first omission is specifically the parent's ordering input: the local solver receives no descendant coordinates or separate endpoint ordering constraint.

For this two-level fixture, actual relative cross-axis leaf centers can be obtained from the returned child placement before parent solving; the unknown parent translation does not affect their within-frame order. This is not generally equivalent to node ID order: mixed scope directions, nested descendants, unequal sizes and final chosen docking faces matter. Repeatedly calling `placeChild` would repeat solves; it must not be used as an unmetered lookup. The callback's existing return values would need explicit bounded retention if used. The caller's final `scopes` array is returned only after the complete placement call and is unavailable inside this callback at that time.

`src/layout/trinity-compound.ts:41–65` forwards the flat edge records unchanged into the neutral measured solver. It restores physical node contact data but supplies no descendant-order metadata. Node `modelOrder` is not a substitute: Trinity explicitly rejects it (`trinity.ts:55`).

## Source order differs from target order

`trinity.ts:215–245` creates dummy vertices in local edge occurrence order. For eight parallel A→B paths, the dummy barycenters tie: each has the same predecessor A and successor B. Four sweeps retain previous row order on equal scores. This is existing barycenter logic with insufficient endpoint information, not absence of a crossing-order pass.

Both ends then follow that same dummy order: source peers sort by the first path neighbor, target peers by the penultimate (`trinity.ts:248–254`). Compound scope contacts retain centered ports; the later neighbor-lane projection is root-only (`trinity.ts:296–315`).

Retained `trinity-community-ports-20261109/products/trinity-TB.layout.json` provides concrete geometry:

- Source centers: a1=287.388, a2=375.388.
- Target centers: b1=179.780, b2=280.852, b3=381.924, b4=482.996.
- The occurrence/label order is a1b1,a2b1,a1b2,a2b2,a1b3,a2b3,a1b4,a2b4.

Therefore current order is already target-major in actual increasing x. Source-major geometry gives indices `[0,2,4,6,1,3,5,7]`, exactly the partition imposed by the retained `trinity-fanin-quality-20261109/trinity-source-order-trial.ts:208–216`. That probe changed the initial dummy row and charged sort work. Its README records TB crossings29→22, BT10→21, LR/RL9→14, with wire worsening in every direction and unchanged area. It was stopped. Sorting by descendant geometry rather than its equivalent fixture partition does not supply a distinct causal treatment here.

Two endpoint orders are intrinsically different for K2,4. A single dummy order cannot simultaneously group all source branches and all target branches. How to distribute unavoidable inversions among the source fan, label lanes and target fan is a routing/objective question; selecting source-major unconditionally is not the missing correction. Current endpoint faces and header-constrained return paths are chosen later, so descendant center order alone is not a complete crossing objective. Carrier intersections also remain distinct from independently qualified visible ink.

## Occurrence ownership and counterfactual limits

A private permutation must preserve each whole measured edge record: minSpan, source/target support spans, label dimensions, marker facts and any admitted physical metadata (`measured-graph.ts:20–24`; spread in compound core line95). It must apply an inverse mapping before returning local edge geometry. Projection currently assumes `placed.edges[index]` corresponds exactly to `hosted[scope][index]` (compound core104–108). Merely sorting `flat.edges` would attach routes/labels to the wrong authored occurrences. Existing owning test `src/__tests__/graph-layout-selection.test.ts:69–83` checks ordered identities, labels, SVG carriers and repeatability.

Even with correct inverse mapping, a full edge permutation is not proven byte-equivalent to the old dummy-row probe: it also permutes channel step insertion (`trinity.ts:319–324`), whose feedback/track ranking includes index tie breaks (`channel-tracks.ts:57–72`). It would mix the already-falsified source partition with a channel-order change. The later shared boundary routing still traverses original `lifted` occurrence order (`compound-boundary-routes.ts:718,1243`), so changing that too would be a separate strategy-order intervention.

**Stop this proposed single-permutation hypothesis.** No new probe or production ordering interface is warranted from this evidence. A future distinct hypothesis would first need a demonstrated, geometry-specific choice of *separate* endpoint constraints or an objective that accounts for both attachment regions while preserving actual labels, headers, marker support, all direction controls and the shared work ledger. That is a design question, not a small supported patch identified here. No quality or performance gain is claimed.
