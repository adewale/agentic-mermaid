from pathlib import Path
import json,gzip,statistics,collections
p=Path(__file__).parent;runs=json.load(open(p/'COST-RUNS.json'))['runs'];groups={};refs={};allExact=True;states=collections.Counter();result=[]
for run in runs:
 d=p/run['directory'];x=json.loads(gzip.decompress((d/'RESULT.json.gz').read_bytes()));groups.setdefault(run['kind']+':'+run['backend']+':'+run['cache'],[]).append(x)
 for row in x['rows']:states[(row['status'],row.get('proof',{}).get('status'))]+=1
 for phase in ['warmup','repeat1','repeat2','edit','edit2']:
  value=tuple(gzip.decompress((d/(phase+suffix+'.gz')).read_bytes()) for suffix in ['.svg','.receipt.json']);key=(run['kind'],run['backend'] if run['kind']=='contained' else 'flat', 'edit' if phase.startswith('edit') else 'original');refs.setdefault(key,value);allExact &= value==refs[key]
 result.append({'run':run,'rows':x['rows']})
report={'baseline':'39135ac82c67d2783e8211ccdb73714e372a4919','completeCalls':sum(states.values()),'outcomes':[{'status':a,'proof':b,'count':n} for (a,b),n in states.items()],'allWholeSVGAndReceiptExact':allExact,'runs':result,'scope':'Current uncommitted three-backend repaired contained diamondTB full products; existing ELK containedLR before/candidate control. No ratios against prior Trinity refusal. Two diamond replicas/cell and four control replicas/arm; no general speed, memory or p95 claim.'}
(p/'COST-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
metrics=[]
for phase in ['cold-render','repeat1','repeat2','edit','edit2']:
 vals={k:[next(r for r in x['rows'] if r['phase']==phase) for x in v] for k,v in groups.items()}
 item={'phase':phase}
 for variant,rr in vals.items():
  item[variant]={key:{'median':statistics.median(row[key] for row in rr),'min':min(row[key] for row in rr),'max':max(row[key] for row in rr),'all':[row[key] for row in rr]} for key in ['wallMs','cpuMs','peakRssKiB']}
 metrics.append(item)
(p/'COST-SUMMARY.json').write_text(json.dumps({'outcomes':report['outcomes'],'exact':allExact,'metrics':metrics},indent=2)+'\n')
for item in metrics:
 print(item['phase'],{v:{k:round(item[v][k]['median'],3) for k in ['wallMs','cpuMs','peakRssKiB']} for v in item if v!='phase'})
print(report['outcomes'], 'entire product exact',allExact)
