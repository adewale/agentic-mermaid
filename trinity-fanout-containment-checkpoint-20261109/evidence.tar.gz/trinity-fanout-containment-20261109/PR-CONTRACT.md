## What changes

**Draft; retain ELK.** Head `39135ac82c67d2783e8211ccdb73714e372a4919`, base `e7cb05baa7f68154942a9ce9c6e9aaaee163dc94`. This PR repairs shared SVG ownership/measurement, improves selected Native workloads and adds opt-in Trinity. Defaults, versions and original limits are unchanged; omitted Flowchart layout retains the forest fast path already in main. ELK retirement is unqualified.

- Bind proof to actual SVG writes and occurrence ownership, preserving mutable/getter/CSS/definitions isolation and cumulative budgets.
- Reuse ER measurements/finalization: Native and ELK deliver ER256 in four directions at the original400k geometry limit; formerly refused BT/RL use385344 Native/371874 ELK operations. Refused work gets no speed ratio.
- Repair Native endpoint capacity, phantom paint demand from invisible constraints, shortening clearance, component packing and forests.
- Introduce explicit measured placement/routed results and selected-backend evidence. Trinity supports bounded rectangular/rounded Flowchart and State scopes, fixed State circles, canonical Class scopes with members/notes/cardinalities, flat ER/Requirement and single-container Architecture forests. Routed admission remains64subjects/128edges; Architecture's existing placement slice is separate. Unknown domains decline unless fallback was requested; exhaustion stays hard.
- Share canonical sharp-shaft Requirement demand across all three solvers. ELK translates endpoint support to actual ports/growth; emitted cards consume selected dimensions. Crowded containment-circle centers move7.67/10.77→20px versus11px required; a selected pair's hidden pixels180→0. [Repair, actual ink and adverse costs](https://github.com/adewale/agentic-mermaid/blob/91400dc282c7717ffa9bf658c83351969dc679de/trinity-common-requirement-checkpoint-20261109/README.md).
- Project flat-root Trinity contacts toward reserved neighbor lanes before routing. Requirement TB bends18→6, wire1072.96→507.03, area244079.95→242350.83, crossings0. Compound locals retain centered contacts because their external corridors are absent from local IR. [Three-way Requirement evidence and mixed costs](https://github.com/adewale/agentic-mermaid/blob/004cc22d0c46d053a708a95d5a6cf92f5ada74d5/trinity-root-ports-checkpoint-20261109/CURRENT-THREE-WAY.md).
- Add flat canonical decision diamonds: the existing labelled fan, inlet and feedback change12 directional Trinity refusals into12 returned/proof-passed products. The shape owner supplies exact facets and joined-stroke support; actual marker-roster facts are captured once into paid private bytes. Unmarked multiport facets and singleton cardinal marked ends are supported. Closed compound scopes reuse local facets when EVERY edge joins sibling leaves without boundary artwork. Any lifted edge, even unrelated to the diamond, remains unsupported; loops and marked multiport faces still decline. Native/ELK's public diamond output is unchanged. Enclosed and nested mixed-direction fans add eight further returned/P Trinity products from typed refusals without changing the boundary router.

The earlier profiled heap/priority reuse preserves storage, ties, charges and full products. Its40-call paired result has overlapping ranges and no general speedup claim. [Five self/inclusive hotspots, cache inventory and stopped hypotheses](https://github.com/adewale/agentic-mermaid/blob/39135ac82c67d2783e8211ccdb73714e372a4919/docs/design/system/layout-0.6-performance-review.md); [paired raw results](https://github.com/adewale/agentic-mermaid/blob/77aa38c73ad6e4846bd7dffdfa95bf56366ff8c0/trinity-lazy-priority-checkpoint-20261109/README.md).

Current shared correctness repair under qualification: the existing fanout geometry transaction must preserve every target's prior containing frame. Raw ELK TB/BT contains R, but the optional symmetry proposal ejects it2.1545px and all four final attempts refuse. Reuse existing target/group snapshots, the0.5px containment predicate and rollback; reject that proposal before route/label mutation. Preserve valid main-axis group expansion, authored identities/parents, definitions/style/getter capture and all limits. No new cache, clipping change, frame growth or final-certificate weakening.

## Correctness and delivery

| Frozen30 original inputs | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| Returned / proof-passed | 28 | 28 | 27 |
| Unsupported image | 0 | 0 | 1 |
| Shared invalid-option errors | 2 | 2 | 2 |

These vectors are unchanged. The new diamond supplement is outside that denominator. Native/ELK's image return is a placeholder whose actual-image criterion fails. Proof-passed is not complete visible correctness. The retained613-criterion authored-meaning/finalSVG ledger is ELK575passed/6unsupported/29blocked/3failed, Native576/6/28/3, Trinity564/19/28/2; all19 Trinity unsupported criteria belong to the one image input. Parser/prelude credit is separate from selected-solver delivery.

The flat-diamond milestone requalified83 byte-exact frozen whole SVGs/entire receipts, six errors and one Trinity image refusal. The closed-scope milestone retains66 existing Native/ELK SVG/receipt/layout files and40 flat-diamond full products exactly; those are validation. Frozen30 is not replayed or given supplemental credit here. Public owners inspect authored identities/endpoints/labels, actual emitted facets, frame headers and parent/membership. Sampled canonical PNGs retain connected shafts and visible heads. Rough/hybrid ink remains unqualified. Contained ELK TB/BT still refuse because a shared finishing pass moves R2.1545px outside Stage after correct raw layout; that defect is separately traced, not hidden or repaired by this extension. [Full current outcomes and scope](https://github.com/adewale/agentic-mermaid/blob/9f3f7c5e155a33d44d4e7c75434cc774429a4cef/trinity-compound-diamond-checkpoint-20261109/README.md).

Earlier scoped Native gains remain dated: forest wire700.04→397.71 versus ELK396.47, area226466→165356 versus176727. Sparse256's implemented historical area gap is+5.04%; the+0.97% backfill remains unshipped. [Prior comparison](https://github.com/adewale/agentic-mermaid/blob/fb8258f17fadf2996e15aa4c82a0973b1cefae4f/rebase-c366-reconsider-20261107/README.md).

## Current contained-decision comparison

Same authored LR source with a containing frame, explicit backend/fallback:none; full SVG and entire receipt serialized. All60 current calls return/P. Two fresh Node24 replicas/cell; imports, GC, compression and artifact writes are separate. TB/BT ELK refusals remain enrolled and receive no timing ratio.

| Metric | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| Area |149483.43|137021.99|129115.99|
| Written shaft wire / bends / crossings |658.85 /4/0|437.44 /4/0|434.99 /4/0|
| First target cache0 wall ms; import separate |407.23|196.44|167.90|
| Repeat2 cache0 wall / CPU ms |65.13 /119.76|36.23 /71.42|29.15 /60.94|
| Original label edit cache0 wall ms |64.31|34.47|22.47|
| Repeat2 cache1 wall ms |8.70|12.96|7.12|
| Original label edit cache1 wall ms |89.25|38.82|35.89|
| API-return heap cache0repeat2 MiB |62.33–62.69|40.48–40.53|39.30–39.54|
| Lifetime RSS cache0repeat2 MiB |191.72–209.58|170.45–186.21|185.00–186.45|
| Complete response gzip9 / Brotli11 |2833 /2412|2868 /2456|2857 /2441|

Trinity TB has6bends versus Native4 despite shorter wire. Memory includes harness/imports/retained products; no isolated solver peak, settled-retention or general superiority follows. Forty before/candidate flat-diamond control calls retain exact whole products: cold wall170.87→177.15ms and edit2 wall22.30→25.83 are adverse, with overlapping ranges. All100 timed serialized lengths match actual gzip9/Brotli11 streams and decode exactly. [Current full costs, memory, cache observations and recovery](https://github.com/adewale/agentic-mermaid/blob/9f3f7c5e155a33d44d4e7c75434cc774429a4cef/trinity-compound-diamond-checkpoint-20261109/README.md).

[Prior flat-fan costs and invalid-control exclusion](https://github.com/adewale/agentic-mermaid/blob/a937680f5eb35827c7da65466d1b9aa436f8c4a5/trinity-diamond-contact-checkpoint-20261109/README.md) remain dated. The [frozen30 cost report](https://github.com/adewale/agentic-mermaid/blob/86869bd66c21f73db5c33928c242ed7a9b50186b/trinity-frozen-cost-checkpoint-20261109/README.md), source3f2, retains360serial processes/1248attempts:1140returned/P,96invalid-option errors,12image refusals. Cached Flowchart and Architecture costs are adverse for Trinity; new narrow samples do not replace that workload scope.

## Distribution cost

Actual original13-input lazy-browser product union; all three lanes and the separate diamond browser case pass existing Trident qualification. Product bytes exclude the separately retained binding:

| Metric | ELK | Native | Trinity |
| --- | ---: | ---: | ---: |
| gzip9 bytes | 858332 | 486509 | 479796 |
| Brotli11 bytes | 688752 | 417128 | 411061 |
| Requests including binding | 43 | 49 | 50 |
| Closed-scope gzip / Brotli delta | −6 /+7 | −14 /+31 | +112 /+113 |

Request counts are unchanged by this extension; flat-diamond support previously added two per lane. These are actual fetched modules compressed offline; raw serving is not compressed-wire/startup or total-package measurement. Last standalone measurement at3f2 is1338451gzip bytes,3951 above the original1334500cap; it is not freshly rebuilt for this feature. No new cache or budget increase hides these costs.

## Visual evidence

Baseline SHA: `9ec32417a7a0fafa340b9bf05db1ae66e029fa42`.
Current SHA: `39135ac82c67d2783e8211ccdb73714e372a4919`. Trinity previously declined this contained workflow; there is no before SVG. These compare the unchanged ELK LR control and new Trinity delivery, using actual finalSVGs, manifest-verified Inter and system fonts off.

```mermaid
flowchart LR
subgraph Stage[Choose a path]
Q{Decision} -->|left| L[Left]
Q -->|middle| M[Middle]
Q -.->|right| R[Right]
end
```

ELK control, LR:
![ELK contained decision fan](https://raw.githubusercontent.com/adewale/agentic-mermaid/9f3f7c5e155a33d44d4e7c75434cc774429a4cef/trinity-compound-diamond-checkpoint-20261109/contained-ELK-LR.png)

Trinity delivery, LR:
![Trinity contained decision fan](https://raw.githubusercontent.com/adewale/agentic-mermaid/9f3f7c5e155a33d44d4e7c75434cc774429a4cef/trinity-compound-diamond-checkpoint-20261109/contained-Trinity-LR.png)

[Nested mixed-direction workflow](https://raw.githubusercontent.com/adewale/agentic-mermaid/9f3f7c5e155a33d44d4e7c75434cc774429a4cef/trinity-compound-diamond-checkpoint-20261109/nested-Trinity-LR.png), [TB Trinity delivery](https://raw.githubusercontent.com/adewale/agentic-mermaid/9f3f7c5e155a33d44d4e7c75434cc774429a4cef/trinity-compound-diamond-checkpoint-20261109/contained-Trinity-TB.png), all SVGs, receipts, layouts and failed probes are in the [verified checkpoint](https://github.com/adewale/agentic-mermaid/blob/9f3f7c5e155a33d44d4e7c75434cc774429a4cef/trinity-compound-diamond-checkpoint-20261109/README.md).

## Reproduce and verify

Run `bun test src/__tests__/graph-layout-selection.test.ts src/__tests__/trinity-layout.test.ts --timeout 30000`. The prior producer fails four extended public owners at the first enclosed row; row aborts limit independent red claims. Current225 owning checks across5files, core/repository types and lint pass. Earlier flat-diamond coverage had497checks and nine red owners. Independent review repaired an introduced ellipse-inheritance regression and found no remaining supported blocker. Only new diamond metadata is own-only; the previous ellipse contract is preserved. Full suite runs in CI.

## Remaining losses and CI

[Exact-head CI42615901490](https://github.com/adewale/agentic-mermaid/actions/runs/42615901490) is in progress; no readiness claim. [Previous CI42597120679](https://github.com/adewale/agentic-mermaid/actions/runs/42597120679) completed/failure: unit shard1, quality, payload and advisory jobs failed; unit shards2/3 passed. Pending work is not ready.

Native compound TB arc/BT no-corridor refusals, Trinity compound TB29 versus ELK13 crossings, controlled images, shared Sparse32 emitted-proof exhaustion at400k, Native TB/BT marker/halo loss, historical crossing276 and adverse distribution costs remain. The pending-stub shortcut, global port projection and Native label-gap prototype stay stopped/unshipped. Blanket compound-diamond admission and cardinal-only boundary terminals also stay unshipped: later terminals and miter-obstacle support still need a complete boundary contract. No late routing-repair phase ships. Original2dad baseline/equivalent pinned Pele runtime remain unavailable; Replacement24 stays sealed. Adoption and retirement are deferred.
