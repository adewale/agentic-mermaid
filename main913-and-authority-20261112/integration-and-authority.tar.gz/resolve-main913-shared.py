from pathlib import Path
import subprocess,re
root=Path('/dev/shm/pr449-four-final-20261111/main913-integration');g=root.parent/'recovery-ae-c4/recovery.git';main='9136b07efb8944a1058de9834b18fe5916884174';backup=root.parent/'main913-root-conflict-inputs';backup.mkdir(exist_ok=True)
def blob(rel):return subprocess.check_output(['git',f'--git-dir={g}','show',main+':'+rel]).decode()
def put(rel,text):
 p=root/rel;q=backup/rel;q.parent.mkdir(parents=True,exist_ok=True)
 if not q.exists():q.write_bytes(p.read_bytes())
 p.write_text(text)
def conflicts(rel,choose):
 s=(root/rel).read_text();n=0
 def resolve(m):
  nonlocal n;n+=1;return choose(n,m[1],m[2])
 out=re.sub(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> [^\n]+\n',resolve,s,flags=re.M|re.S);assert n,rel;put(rel,out)
# Preserve the established option owner, moving Main's new contract rules there.
conflicts('src/render-contract.ts',lambda n,a,b:a)
rel='src/render-option-contract.ts';s=(root/rel).read_text();up=blob('src/render-contract.ts')
s=s.replace("import { safeCssColor, safeCssPaint }", "import { cssColorSpellings, isRecognizableCssColor, safeCssColor, safeCssPaint }")
start=s.index('const STYLE_SPEC_SCHEMA =');end=s.index('const STYLE_INPUT_SCHEMA',start);a=up.index('/**\n * The StyleSpec record');b=up.index('const STYLE_INPUT_SCHEMA',a);s=s[:start]+up[a:b]+s[end:];s=s.replace('    STYLE_SPEC_SCHEMA,',"    { $ref: '#/$defs/styleSpec' },")
a=s.index('const SHADOW_OPTION_FAMILIES =');b=s.index('] as const satisfies readonly DiagramKind[]',a)+len('] as const satisfies readonly DiagramKind[]');x=up.index('const SHADOW_OPTION_FAMILIES =');y=up.index('] as const satisfies readonly DiagramKind[]',x)+len('] as const satisfies readonly DiagramKind[]');s=s[:a]+up[x:y]+s[b:]
for field in ['layoutHints','layoutSafety','padding','nodeSpacing','layerSpacing']:
 line=next(l for l in up.splitlines()if l.startswith('  '+field+':'))
 s,count=re.subn(r'^  '+field+r':[^\n]*$',lambda m:line,s,flags=re.M);assert count==1,field
anchor="  if (runtimeValidator === 'safeCssFontFamily'"
a=up.index("  if ((runtimeValidator === 'safeCssColor'");b=up.index(anchor,a);i=s.index(anchor);s=s[:i]+up[a:b]+s[i:]
a=up.index('/** Option names callers guess');b=up.index('/** Validate the shared advanced JSON',a);i=s.index('/** Validate the shared advanced JSON');s=s[:i]+up[a:b]+s[i:]
s=s.replace('      problems.push(`unknown render option "${field}"`)', '      const hint = misplacedRenderOptionHint(field)\n      problems.push(`unknown render option "${field}"${hint ? `; ${hint}` : \'\'}`)')
s=s.replace('$defs: { jsonValue: cloneSchema(JSON_VALUE_SCHEMA) },','$defs: renderOptionsSchemaDefinitions(),')
a=up.index('/** The local definitions `sharedRenderOptionsJsonSchema()`');b=up.index('export interface ResolvedAppearance',a);i=s.index('/** Public StyleInput projection');s=s[:i]+up[a:b].rstrip()+'\n';put(rel,s)
rel='src/render-contract.ts';s=(root/rel).read_text();s=s.replace("import { styleSpecJsonSchema } from './scene/style-spec.ts'\n",'');s=s.replace("import { cssColorSpellings, isRecognizableCssColor, safeCssColor, safeCssPaint }", "import { safeCssColor, safeCssPaint }");s=s.replace('  sharedRenderOptionsJsonSchema,\n', '  sharedRenderOptionsJsonSchema,\n  renderOptionsSchemaDefinitions,\n  misplacedRenderOptionHint,\n');put(rel,s)
# Main's terminal admission now retains unknown fields for shared diagnostics.
conflicts('src/shared-render-options.ts',lambda n,a,b:b)
# Combine actual-write ownership with Main's drawable-failure/report semantics.
def graphics(n,a,b):
 if n==1:return a.replace('PaintLayoutCertificationError, MAX_', 'PaintLayoutCertificationError, paintFailureIsDrawable, MAX_')
 if n==2:return '    if (paintCertificationRefuses(request, layoutCertification)) throw new PaintLayoutCertificationError(layoutCertification)\n    let actualWriteBound = false\n'
 if n==3:return b.replace("if (layoutCertification?.repairs.length && executionPlan.backend?.inputName === 'default')", "if (layoutCertification?.repairs.length && (executionPlan.consumer?.kind === 'native-drawing' || executionPlan.backend?.inputName === 'default'))")
 raise AssertionError(n)
conflicts('src/graphical-render.ts',graphics);rel='src/graphical-render.ts';s=(root/rel).read_text().replace('import { isOriginalEnrolledDefaultBackend }','import { isBuiltInBackend, isOriginalEnrolledDefaultBackend }')
s=s.replace("certification.status === 'failed' && resolvedRenderExecutionPlanOf(request).backend?.inputName === 'default'", "certification.status === 'failed' && (resolvedRenderExecutionPlanOf(request).consumer?.kind === 'native-drawing' || resolvedRenderExecutionPlanOf(request).backend?.inputName === 'default')")
s=s.replace("&& resolvedRenderExecutionPlanOf(request).backend?.inputName === 'default' && paintFailureIsDrawable(certification)", "&& (resolvedRenderExecutionPlanOf(request).consumer?.kind === 'native-drawing' || resolvedRenderExecutionPlanOf(request).backend?.inputName === 'default') && paintFailureIsDrawable(certification)")
s=s.replace("if ((effectiveOptions.layoutSafety === 'strict' && layoutCertification.status !== 'passed') || layoutCertification.status === 'failed') throw new PaintLayoutCertificationError(layoutCertification)", "if (paintCertificationRefuses(request, layoutCertification)) throw new PaintLayoutCertificationError(layoutCertification)");put(rel,s)
# Preserve actual occurrence bounds and Main's clipped-ink classification.
def paint(n,a,b):
 assert n==1
 a=a.replace("issue({ code: 'UNMEASURED_PAINT', id: primitive.id, message: 'Final viewport does not contain retained paint' }, true)", 'unmeasuredPaint(primitive.id, CLIPPED_RETAINED_PAINT, true)')
 return a.replace("unmeasuredPaint(target.primitive.id, 'Final viewport does not contain serialized marker paint', true)", 'unmeasuredPaint(target.primitive.id, CLIPPED_MARKER_PAINT, true)')
conflicts('src/scene/paint-certification.ts',paint)
# Keep private captured/certified transitions and genuine late Scene writes.
def positioned(n,a,b):
 if n==1:return a.replace('const certification = certifyNativePaint(', 'const certification = withGeometryCertification(certifyNativePaint(').replace('outputSupported: !request.appearance.colors.shadow })', 'outputSupported: !request.appearance.colors.shadow }), layout)')
 if n==2:return a.replace('entry.certification = certifyScenePaint(', 'entry.certification = withGeometryCertification(certifyScenePaint(').replace('sceneWriteReceipt: written ? entry.writes : undefined })', 'sceneWriteReceipt: written ? entry.writes : undefined }), layout)')
 raise AssertionError(n)
conflicts('src/scene/positioned.ts',positioned)
# Main's trusted XML character normalization joins the PR's paid writer path.
conflicts('src/scene/scene-validation-core.ts',lambda n,a,b:"import { xmlCarriableText } from '../shared/text-controls.ts'\n"+a)
# Keep the exact incoming owner-maintained caps and reviewed raster baseline.
for rel in ['scripts/build/browser-lazy-budgets.json','src/__tests__/testdata/section-b-brand-evidence.png']:
 data=subprocess.check_output(['git',f'--git-dir={g}','show',main+':'+rel]);p=root/rel;q=backup/rel;q.parent.mkdir(parents=True,exist_ok=True)
 if not q.exists():q.write_bytes(p.read_bytes())
 p.write_bytes(data)
print('Resolved shared runtime/option conflicts; remaining generated/reference conflicts require owning regeneration/review.')
