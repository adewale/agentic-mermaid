import { sceneInspectionRuntime } from './scene-backend.ts'
import type { ScenePaintGeometry, ScenePaintGeometryInspection, NativePaintSource } from '../scene/inspection.ts'
import type { SceneWriteWork } from '../scene/serialization.ts'

export function hasSceneWriteEmissionOccurrence(primitive: ScenePaintGeometry): boolean { return sceneInspectionRuntime()?.hasSceneWriteEmissionOccurrence(primitive) ?? false }
export function hasScenePathEmissionOccurrence(primitive: ScenePaintGeometry): boolean { return sceneInspectionRuntime()?.hasScenePathEmissionOccurrence(primitive) ?? false }
export function scenePathEmissionWorkOf(inspection: ScenePaintGeometryInspection): SceneWriteWork | undefined { return sceneInspectionRuntime()?.scenePathEmissionWorkOf(inspection) }

export function scenePrimitiveSource(primitive: ScenePaintGeometry): import('../scene/ir.ts').SceneNode | undefined { return sceneInspectionRuntime()?.scenePrimitiveSource(primitive) }
export function scenePaintPrimitiveSource(primitive: ScenePaintGeometry): NativePaintSource | undefined { return sceneInspectionRuntime()?.scenePaintPrimitiveSource(primitive) }

export function hasSceneImmutablePaintRoster(inspection: ScenePaintGeometryInspection): boolean { return sceneInspectionRuntime()?.hasSceneImmutablePaintRoster(inspection) ?? false }
