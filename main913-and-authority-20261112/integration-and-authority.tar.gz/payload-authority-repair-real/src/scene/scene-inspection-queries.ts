/** Read-only custody queries; all issuers remain with the atomic Scene walk. */
export { hasSceneImmutablePaintRoster, scenePrimitiveSource, scenePaintPrimitiveSource, hasSceneWriteEmissionOccurrence, hasScenePathEmissionOccurrence, scenePathEmissionWorkOf } from './scene-inspection.ts'
