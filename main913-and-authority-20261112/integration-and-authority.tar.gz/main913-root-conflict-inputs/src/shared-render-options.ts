import type { RenderOptions } from './types.ts'
<<<<<<< HEAD
import { NON_SERIALIZABLE_RENDER_OPTION_FIELDS, SHARED_RENDER_OPTION_FIELDS } from './render-option-contract.ts'
=======
import { isTerminalOutputOptionField } from './terminal-contract.ts'
>>>>>>> 9136b07efb8944a1058de9834b18fe5916884174

/** The RenderOptions projection of a terminal request. The terminal adapter
 * owns its cell-grid controls and its projection-diagnostic callback; every
 * other field, an unknown one included,
 * enters shared render admission, so a terminal render refuses an unknown or
 * misspelt option exactly as an SVG render does. */
export function sharedRenderOptionsOf(options: RenderOptions): RenderOptions {
  return Object.fromEntries(
    Object.entries(options).filter(([field, value]) => value !== undefined && field !== 'onProjectionDiagnostic' && !isTerminalOutputOptionField(field)),
  ) as RenderOptions
}
