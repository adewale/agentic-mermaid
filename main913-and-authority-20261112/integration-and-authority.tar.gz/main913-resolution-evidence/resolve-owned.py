from pathlib import Path
import subprocess,re
r=Path('/dev/shm/pr449-four-final-20261111/main913-integration')
def stage(n,p):return subprocess.check_output(['git','show',f':{n}:{p}'],cwd=r,text=True)
def conflict(s,fn):return re.sub(r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> 9136b07efb8944a1058de9834b18fe5916884174\n',lambda m:fn(m.group(1),m.group(2)),s,flags=re.S)
p=r/'src/__tests__/er-layout-backends.test.ts';s=p.read_text();s=conflict(s,lambda ours,theirs:ours.replace("import { renderMermaidSVGWithReceipt }", "import { renderMermaidASCII, renderMermaidSVGWithReceipt }"));p.write_text(s)
p=r/'src/er/layout.ts';s=p.read_text();s=conflict(s,lambda ours,theirs:theirs+ours[ours.index('  const labelBounds'):]);p.write_text(s)
p=r/'src/layout/passes/fanout.ts';s=p.read_text();s=conflict(s,lambda ours,theirs:ours.replace('expandGroupsForMainShift, sourceEmissionPort','expandGroupsForMainShift, moveKeepsGroupContainment, sourceEmissionPort'));p.write_text(s)
p=r/'src/layout/passes/obstacle-routing.ts';ours=stage(2,str(p.relative_to(r)));main=stage(3,str(p.relative_to(r)));current=p.read_text()
start=main.index('export function rerouteEdgesThroughNodes(');end=main.index('\nexport function collapseTinyBundledHitches',start)
section=main[start:end]
section=section.replace("groups: readonly PositionedGroup[] = []): {", "groups: readonly PositionedGroup[] = [], style?: GraphPaintStyle): {")
o=ours[ours.index('  const paintWork = graphInkWork()'):ours.index('  // Headers are live reserved geometry')]
# Restore actual painted circle/shaft admission, including the shared work bound.
a=section.index('  const throughNode = ');b=section.index('  // Headers are live reserved geometry',a);section=section[:a]+o+section[b:]
old="      if (!throughNode(route, skip) && routeClearOfNodes(route, nodes, skip, chargeWork) && clearHeaders(route) && admit(route)) return route"
new="""      if (!throughNode(route, skip) && routeClearOfNodes(route, nodes, skip, chargeWork) && clearHeaders(route)) {
        if (admit(route)) return route
        // A rejected painted band first tries the existing local terminal
        // repair before spending its bounded ink work on more global lanes.
        if (paintedRepair && !triedTerminals) {
          const local = detourTerminals(pts, skip, admit)
          if (local) return local
        }
      }"""
assert old in section;section=section.replace(old,new)
pos=section.index('  // Last resort: a segment')
helper="""  const detourTerminals = (pts: Point[], skip: ReadonlySet<string>, admit: (trial: Point[]) => boolean): Point[] | null => {
    if (triedTerminals) return null
    triedTerminals = true
    const route = detourTerminalSegment(pts, skip, admit)
    if (route) return route
    chargeWork?.(pts.length)
    return detourTerminalSegment(pts.toReversed(), skip, trial => admit(trial.toReversed()))?.reverse() ?? null
  }
"""
section=section[:pos]+helper+section[pos:]
old="""  for (const edge of edges) {
    chargeWork?.(1)
    if (edge.source === edge.target || edge.points.length < 2) continue"""
new="""  for (const edge of edges) {
    currentEdge = edge; paintedRepair = false; triedTerminals = false
    chargeWork?.(1)
    if (edge.source === edge.target || edge.points.length < 2) continue"""
assert old in section;section=section.replace(old,new,1)
old="    if (!entersBand && !throughNode(edge.points, skip)) continue // no-op gate: only fires on edgeThroughNode or a header-band entry"
new="""    if (!entersBand && !throughNode(edge.points, skip)) {
      if (!paintedContact || !nodes.some(node => !skip.has(node.id) && paintedContact(edge, edge.points, node) === true)) continue
      paintedRepair = true
    }"""
assert old in section;section=section.replace(old,new)
section=section.replace("const keepsApproach = (trial: Point[]): boolean => [true, false].every((start, end) => wasOutward[end] !== true || outward(trial, start) === true)","const keepsApproach = (trial: Point[]): boolean => [true, false].every((start, end) => wasOutward[end] !== true || outward(trial, start) === true) && admitPaint(trial)")
old="""    let route = shiftInteriorSegment(edge.points, skip, keepsApproach) ?? bracketOverBand(edge.points, skip, keepsApproach)
      ?? detourTerminalSegment(edge.points, skip, keepsApproach)
    if (!route) {
      chargeWork?.(edge.points.length) // reverse-domain reference initialization
      route = detourTerminalSegment(edge.points.toReversed(), skip, trial => keepsApproach(trial.toReversed()))?.reverse() ?? null
    }"""
new="""    let route = shiftInteriorSegment(edge.points, skip, keepsApproach) ?? bracketOverBand(edge.points, skip, keepsApproach)
    if (!route && !triedTerminals) route = detourTerminals(edge.points, skip, keepsApproach)"""
assert old in section;section=section.replace(old,new)
old="""    const savedCert = edge.routeCertificate
    edge.points = route
    recertifyReroutedEdge(edge, savedCert, nodeMap.get(edge.source), nodeMap.get(edge.target))
    if (edge.label) edge.labelPosition = calculatePathMidpoint(route)"""
new="    commitReroutedEdge(edge, { points: route, labelPosition: edge.label ? calculatePathMidpoint(route) : edge.labelPosition }, nodeMap.get(edge.source), nodeMap.get(edge.target))"
assert old in section;section=section.replace(old,new)
cs=current.index('export function rerouteEdgesThroughNodes(');ce=current.index('\nexport function collapseTinyBundledHitches',cs)
current=current[:cs]+section+current[ce:]
# The remaining import/comment conflict is a union of both behaviors.
current=conflict(current,lambda a,b:a+b if a.startswith('import') else a)
current=current.replace("import { commitReroutedEdge, shapePorts", "import { commitReroutedEdge, recertifyReroutedEdge, shapePorts")
current=current.replace("import { terminalHookLength, simpleOrthogonal, type LabelMetricsStyle } from '../route-geometry.ts'\n",'')
# Signature/comment already replaced from Main; retain actual paint guard documentation.
current=current.replace(" * Fires ONLY on an edge the rubric already flags edgeThroughNode", " * A supplied style additionally admits proved actual circle/shaft contacts.\n * Otherwise fires ONLY on an edge the rubric already flags edgeThroughNode")
p.write_text(current)
