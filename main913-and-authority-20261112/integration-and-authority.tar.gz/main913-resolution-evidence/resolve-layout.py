from pathlib import Path
import re
r=Path('/dev/shm/pr449-four-final-20261111/main913-integration')
p=r/'src/layout-engine.ts';s=p.read_text()
def choose(m):
 a,b=m.group(1),m.group(2)
 if 'positionedGeometryFindings' in b:return '\n'.join(line for line in b.splitlines() if "from './layout/pass.ts'" not in line)+'\n'
 if "from './layout/passes/index.ts'" in b:return ''
 if 'function groupTitleWidth' in b:return b[b.index('/** Placement body of an empty group'):]
 if 'export interface LayoutPassContext' in b:return ''
 if 'function finishGraphGeometry' in b:return ''
 raise RuntimeError((a[:100],b[:100]))
s=re.sub(r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> 9136b07efb8944a1058de9834b18fe5916884174\n',choose,s,flags=re.S)
s=s.replace('finishGraphGeometry, hasParallelPair, type LayoutRouteProposal','finishGraphGeometry, hasParallelPair, hasTitleBandDetour, type LayoutRouteProposal')
s=s.replace('TITLE_BAND_DETOURS.has(positioned)','hasTitleBandDetour(positioned)')
p.write_text(s)
p=r/'src/layout/legacy-completion.ts';s=p.read_text()
s=s.replace('rerouteEdgesThroughNodes, alignForkRejoinPeerCenters','rerouteEdgesThroughNodes, repairInwardEndpointApproaches, repairResidualDiagonals, alignForkRejoinPeerCenters')
s=s.replace('  frozen: boolean\n}', '  frozen: boolean\n  /** Routes rebuilt around a reserved title band, retained for placement selection. */\n  titleBandRepairs?: number\n}')
s=s.replace('alignLayerNodes(c.nodes, c.edges, c.graph.direction)', 'alignLayerNodes(c.nodes, c.edges, c.graph.direction, c.groups)')
old='    run: c => { rerouteEdgesThroughNodes(c.nodes, c.edges, c.graph, undefined, c.groups, c.style); repairMarkerTerminals({ nodes: c.nodes, edges: c.edges, groups: c.groups }, c.graph, c.style) },'
new="""    run: c => {
      const rerouted = rerouteEdgesThroughNodes(c.nodes, c.edges, c.graph, undefined, c.groups, c.style)
      c.titleBandRepairs = rerouted.titleBandRepairs
      repairInwardEndpointApproaches(c.nodes, c.edges, c.groups, edge => c.bundled.has(edge))
      repairMarkerTerminals({ nodes: c.nodes, edges: c.edges, groups: c.groups }, c.graph, c.style)
      repairInwardEndpointApproaches(c.nodes, c.edges, c.groups, edge => c.bundled.has(edge), true)
    },"""
assert old in s;s=s.replace(old,new)
needle="""  {
    id: 'translateGeometryToNonNegativeOrigin'"""
assert needle in s;s=s.replace(needle,"""  {
    id: 'repairResidualDiagonals', doc: 're-route a residual diagonal while preserving both endpoint approaches (edge-only, freeze-safe)',
    after: ['closeRouteContracts'], mutates: ['edges'],
    run: c => { repairResidualDiagonals(c.nodes, c.edges, c.groups, edge => c.bundled.has(edge)) },
  },
"""+needle)
old="""  return {
    genericBundled: ctx.genericBundled,
    positioned: {
      width,
      height,
      nodes,
      edges,
      groups,
      ...(ctx.notes.length > 0 ? { notes: ctx.notes } : {}),
    },
  }
}"""
new="""  const positioned: PositionedGraph = {
    width, height, nodes, edges, groups,
    ...(ctx.notes.length > 0 ? { notes: ctx.notes } : {}),
  }
  if (ctx.titleBandRepairs) TITLE_BAND_DETOURS.add(positioned)
  return { genericBundled: ctx.genericBundled, positioned }
}

// Placement-only callers discard the generic routes, and therefore query only
// title widths. Rendered candidates also retain Main's title-detour preference.
const TITLE_BAND_DETOURS = new WeakSet<PositionedGraph>()
export function hasTitleBandDetour(positioned: PositionedGraph): boolean { return TITLE_BAND_DETOURS.has(positioned) }"""
assert old in s;s=s.replace(old,new)
p.write_text(s)
p=r/'src/layout/passes/obstacle-routing.ts';s=p.read_text().replace('<<<<<<< HEAD\n','');p.write_text(s)
