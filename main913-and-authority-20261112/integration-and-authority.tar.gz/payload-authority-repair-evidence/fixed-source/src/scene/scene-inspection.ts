import { isAdmittedSceneDocument } from './scene-admission-state.ts'
import { beginSceneWriteInspection, type SceneWriteReceipt } from './scene-write-capture.ts'
import { assertInertGroup } from './group-emission.ts'
import type { SceneDoc, SceneNode, SceneOwner } from './ir.ts'
import { composeMatrices, IDENTITY_MATRIX, transformMatrix, type AffineMatrix } from './transforms.ts'
import { createSceneGeometryRecorder, ownerSnapshot, multiplySceneOpacity, sceneGroupOpacity, type ScenePaintGeometry, type NativePaintSource, type ScenePaintInspection, type ScenePaintGeometryInspection, type TextDetails } from './inspection.ts'
import type { SceneWriteWork } from './serialization.ts'
const textPaintFreeze = Object.freeze
const sources = new WeakMap<ScenePaintGeometry, Exclude<SceneNode, { kind: 'group' }>>()
const immutablePaintRosters = new WeakSet<ScenePaintGeometryInspection>()
export function hasSceneImmutablePaintRoster(inspection: ScenePaintGeometryInspection): boolean { return immutablePaintRosters.has(inspection) }
const servedSources = new WeakMap<ScenePaintGeometry, NativePaintSource>()
export function scenePrimitiveSource(primitive: ScenePaintGeometry): SceneNode | undefined { return sources.get(primitive) }
export function scenePaintPrimitiveSource(primitive: ScenePaintGeometry): NativePaintSource | undefined { return servedSources.get(primitive) ?? sources.get(primitive) }
const scenePathOccurrences = new WeakSet<ScenePaintGeometry>()
const sceneWriteOccurrences = new WeakSet<ScenePaintGeometry>()
const sceneWriteWork = new WeakMap<ScenePaintGeometryInspection, SceneWriteWork>()
export function hasSceneWriteEmissionOccurrence(primitive: ScenePaintGeometry): boolean { return sceneWriteOccurrences.has(primitive) }
export function hasScenePathEmissionOccurrence(primitive: ScenePaintGeometry): boolean { return scenePathOccurrences.has(primitive) }
export function scenePathEmissionWorkOf(inspection: ScenePaintGeometryInspection): SceneWriteWork | undefined { return sceneWriteWork.get(inspection) }


/** Inspect the actual lowered primitives, retaining paint order and ownership.
 * Bounds are conservative occupied regions, not a claim of pixel-exact ink.
 * Opaque content and missing geometry remain explicit missing evidence.
 */
export function inspectScenePrimitives(scene: SceneDoc): ScenePaintInspection {
  return inspectScene(scene, (text, block, includeFont) => ({
    source: block?.prepared.source ?? text,
    displayed: block ? block.lineBlocks.map(line => line.runs.map(run => run.text).join('')).join('\n') : text,
    ...(includeFont && block?.fontFamily ? { fontFamily: block.fontFamily } : {}),
  })) as ScenePaintInspection
}

export function inspectScenePaintGeometry(scene: SceneDoc, receipt?: SceneWriteReceipt): ScenePaintGeometryInspection {
  const writes = beginSceneWriteInspection(receipt, scene)
  const inspection = inspectScene(scene, undefined, writes, receipt !== undefined ? 'all' : isAdmittedSceneDocument(scene) ? 'marked' : false)
  if (writes) sceneWriteWork.set(inspection, writes.work())
  return inspection
}

function inspectScene(scene: SceneDoc, retainText?: TextDetails, writes?: ReturnType<typeof beginSceneWriteInspection>, requireWritten: false | 'marked' | 'all' = false): ScenePaintGeometryInspection {
  const recorder = createSceneGeometryRecorder(scene, retainText, isAdmittedSceneDocument(scene) ? scene.colors.font : undefined)
  const walk = (nodes: readonly SceneNode[], prefix: string, parent: AffineMatrix, ancestors: readonly SceneOwner[], conditional = false, groupOpacity = 1, untransformed = true): void => {
    nodes.forEach((node, index) => {
      const key = `${prefix}.${index}`
      if (node.kind === 'group') {
        const emitted = assertInertGroup(node)
        const own = node.identity ?? { id: node.id, role: node.role }
        walk(node.children.map(child => child.node), key, composeMatrices(parent, transformMatrix(node.transform)), textPaintFreeze([...ancestors, ownerSnapshot(own)]), conditional || node.visibility === 'conditional' || emitted.style || node.paint?.fill !== undefined, multiplySceneOpacity(groupOpacity, sceneGroupOpacity(node.paint?.opacity)), untransformed && !node.transform)
      } else {
        const written = writes?.node(node)
        // Without a receipt, unmarked legacy inspection still owns its inline
        // label diagnostics. Explicit receipts and marked carriers remain strict.
        const missingWrite = requireWritten && node.kind === 'connector' && node.lineStyle !== 'invisible' && !written
          && (requireWritten === 'all' || !!node.markers.start || !!node.markers.end || node.markers.mid.length > 0)
        const batch = recorder.leaf(node, key, parent, ancestors, conditional || !!written?.conditional || !!missingWrite, groupOpacity, written?.served, untransformed)
        // The math helper receives no private issuer/callback. Only this genuine
        // receipt walk can associate its numerical batch with Scene custody.
        for (let order = batch.first.order; order < batch.end; order++) {
          const primitive = recorder.geometryAt(order)!
          sources.set(primitive, node)
          if (batch.source) servedSources.set(primitive, batch.source)
          if (order === batch.first.order && primitive.visibility !== 'conditional') {
            if (written?.served) sceneWriteOccurrences.add(primitive)
            if (written?.path) scenePathOccurrences.add(primitive)
          }
        }
      }
    })
  }
  walk(scene.parts, 'scene', IDENTITY_MATRIX, textPaintFreeze([]))
  const data = recorder.finish()
  const inspection = textPaintFreeze({ version: 1 as const, family: data.family, bounds: data.bounds, primitives: data.geometry, coverage: data.coverage })
  immutablePaintRosters.add(inspection)
  return inspection
}
