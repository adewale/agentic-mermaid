import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';import{createHash}from'node:crypto';import{Resvg}from'/tmp/pr449-main-integration-20261029-762/node_modules/@resvg/resvg-js/index.js';import{HOSTED_FONT_RESOURCES}from'/tmp/pr449-main-integration-20261029-762/src/font-manifest.ts';import{inlineFontVarForRaster}from'/tmp/pr449-main-integration-20261029-762/src/theme.ts';import{prepareResvgMarkerOrientation}from'/tmp/pr449-main-integration-20261029-762/src/resvg-marker-orientation.ts';
import{scanSvgStartTags,decodedSvgAttributeValue}from'/tmp/pr449-main-integration-20261029-762/src/svg-structure.ts';
const root='/tmp/pr449-main-integration-20261029-762',out='/tmp/pr449-week-comparison-20261101/outcome-plan-a195-20261107';
const fonts=HOSTED_FONT_RESOURCES.filter(f=>f.family==='Inter').map(f=>{const p=root+'/'+f.path;if(createHash('sha256').update(readFileSync(p)).digest('hex')!==f.sha256)throw Error('font mismatch');return p});const rows=[];
for(const backend of ['agentic','elk'])for(const direction of ['BT','RL']){
 const svg=gunzipSync(readFileSync(`${out}/capture-after-${backend}-${direction}/actual.svg.gz`)).toString();
 const tags=scanSvgStartTags(svg), boxes=['N127','N128'].map(id=>{const tag=tags.find(t=>decodedSvgAttributeValue(t,'data-id')===`entity-rect:${id}`)!;return Object.fromEntries(['x','y','width','height'].map(k=>[k,Number(decodedSvgAttributeValue(tag,k))]))});
 const logicalCrop={left:Math.max(0,Math.min(...boxes.map(b=>b.x))-25),top:Math.max(0,Math.min(...boxes.map(b=>b.y))-25),right:Math.max(...boxes.map(b=>b.x+b.width))+25,bottom:Math.max(...boxes.map(b=>b.y+b.height))+25};
 const crop={left:Math.floor(logicalCrop.left*2),top:Math.floor(logicalCrop.top*2),right:Math.ceil(logicalCrop.right*2),bottom:Math.ceil(logicalCrop.bottom*2)};
 const picture=new Resvg(prepareResvgMarkerOrientation(inlineFontVarForRaster(svg)),{background:'#fff',crop,fitTo:{mode:'zoom',value:2},font:{fontFiles:fonts,fontDirs:[],loadSystemFonts:false,defaultFontFamily:'Inter'}}).render().asPng();
 const name=`ER256-${backend}-${direction}-middle-integer-crop`;writeFileSync(`${out}/${name}.png`,picture);rows.push({name,logicalCrop,crop,svgSHA256:createHash('sha256').update(svg).digest('hex'),font:'manifest-verified Inter; system fonts disabled',claim:'Actual finalSVG crop of N127/N128 and their labelled relationship; earlier result is a refusal. Not full-diagram glyph attribution or readability qualification.'});
}
writeFileSync(out+'/VISUALS.json',JSON.stringify(rows,null,2));console.log(rows.map(r=>r.name));
